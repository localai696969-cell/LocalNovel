# Colab Live Browser (Android app riêng)

## Vì sao hướng này tốt hơn Firefox addon

| | Firefox addon | App riêng (WebView) |
|---|---|---|
| Foreground Service | Không tạo được, phải mượn qua audio-session | Tự khai báo thật, `startForegroundService()` |
| WakeLock | Không có API | `PowerManager.PARTIAL_WAKE_LOCK` trực tiếp |
| Cần chữ ký / Nightly | Có (AMO hoặc unlock signature) | Không — sideload APK tự build, cài thẳng |
| Override Page Visibility API | Không thể (sandbox) | Có thể (`onPageFinished` inject sớm) |
| `isTrusted` cho click giả lập | false | false (giới hạn của mọi WebView/Chromium engine, không riêng gì app này) |

## Cách build KHÔNG CẦN PC — dùng GitHub Actions

1. Tạo 1 repo GitHub mới (public hoặc private đều được, Actions free cho cả 2
   loại repo trong giới hạn phút chạy miễn phí hàng tháng).
2. Upload toàn bộ nội dung thư mục `colab-live-browser/` (đã kèm sẵn
   `.github/workflows/build.yml`) lên repo — có thể làm trực tiếp trên web
   GitHub bằng cách kéo-thả file/folder vào, không cần git CLI hay PC.
3. Vào tab **Actions** của repo — workflow "Build APK" sẽ tự chạy khi bạn
   push lên nhánh `main`. Nếu không thấy tự chạy, bấm **Run workflow** thủ
   công (workflow đã bật `workflow_dispatch`).
4. Đợi build xong (vài phút) — vào lại **Actions → lần chạy vừa xong →
   phần Artifacts phía dưới** → tải file `colab-live-browser-debug-apk.zip`,
   giải nén ra được `app-debug.apk`.
5. Chuyển APK vào điện thoại (qua Google Drive, Telegram Saved Messages,
   USB...) rồi cài trực tiếp — bật "Cài đặt từ nguồn không xác định" nếu được hỏi.

Toàn bộ bước này làm được **hoàn toàn trên điện thoại/trình duyệt web**, không
cần máy tính, không cần Android Studio.

## Cách build bằng Android Studio (nếu sau này có PC)

1. Cài **Android Studio** (Windows/Mac/Linux — không build được trực tiếp trên điện thoại).
2. File → New → Project → chọn **Empty Views Activity**, package name đặt là
   `com.colablive.keeper` để khớp sẵn với code trong này.
3. Copy đè 3 file:
   - `app/src/main/AndroidManifest.xml`
   - `app/src/main/java/com/colablive/keeper/MainActivity.kt`
   - `app/src/main/java/com/colablive/keeper/KeepAliveService.kt`
   - `app/build.gradle` (merge phần `dependencies` nếu project mẫu đã có sẵn dependency khác)
4. Sync Gradle (Android Studio tự nhắc), sau đó **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
5. Copy file APK trong `app/build/outputs/apk/debug/app-debug.apk` sang điện thoại,
   bật "Cài đặt từ nguồn không xác định" nếu được hỏi, cài trực tiếp — **không cần
   chữ ký Mozilla, không cần Nightly, không dính vấn đề gì của bước trước.**

## Bước đầu chạy trên máy: cấp quyền thủ công

- Sau khi mở app lần đầu, vào **Settings → Apps → Colab Live Browser → Battery →
  Không hạn chế** (giống khuyến nghị trước, vẫn nên làm dù đã có Foreground Service,
  vì một số ROM hãng thứ 3 vẫn có lớp kill riêng ngoài chuẩn Android).
- Android 13+ sẽ hỏi quyền hiển thị thông báo (`POST_NOTIFICATIONS`) — bắt buộc
  đồng ý, vì Foreground Service yêu cầu phải có notification hiển thị liên tục.

## Bật Auto-Click thật (Accessibility) — bắt buộc thao tác thủ công 1 lần

Sau khi cài app, mở app → bấm nút **"Bật Auto-Click (Accessibility)"** → màn
hình Settings hệ thống hiện ra → tìm "Colab Live Browser" trong danh sách →
bật lên. Android **bắt buộc** bước thủ công này cho mọi app dùng Accessibility
Service, không có API nào cho phép app tự bật quyền này — đây là biện pháp bảo
mật cố định của Android, không có cách nào lách qua bằng code.

**Đánh đổi cần chấp nhận**: để đảm bảo tap rơi đúng vào nút Connect (không rơi
nhầm app khác), app sẽ tự đưa mình lên foreground trước mỗi lần tap — nghĩa là
**màn hình sẽ sáng lên trong chốc lát mỗi phút** kể cả khi bạn đang dùng app
khác hoặc màn hình đang tắt. Đây không phải bug, mà là giới hạn vật lý của cơ
chế input injection (tap toạ độ tuyệt đối cần app ở đúng vị trí z-order trên
cùng). Nếu ưu tiên "màn hình luôn tắt" hơn "độ tin cậy của click", có thể đổi
sang dùng `performAction(ACTION_CLICK)` trên node ảo (không cần foreground)
bằng cách sửa lại `findAndTapConnectButton()` — nhưng như đã nói, khi đó
`isTrusted` không được đảm bảo `true` nữa.

## Giới hạn còn lại (đã giảm nhiều, nhưng chưa về 0)

- Cách `dispatchGesture` gần như chắc chắn tạo `isTrusted = true`, nhưng
  "gần như chắc chắn" chứ không phải tài liệu chính thức nào của Google cam
  kết 100% — cách chắc ăn nhất vẫn là bạn tự thử nghiệm thực tế.
- Foreground Service + WakeLock giảm mạnh khả năng bị Android OS kill, nhưng
  ROM một số hãng (Xiaomi/MIUI, Huawei/EMUI, Oppo/ColorOS...) có thêm lớp quản
  lý pin riêng ngoài chuẩn AOSP, vẫn có thể kill app "cứng đầu" nếu người dùng
  không tắt tối ưu pin thủ công cho app này trong Settings riêng của hãng.
- Hard limit 12h + việc Google preempt GPU giữa chừng vẫn là giới hạn phía
  server, không app nào ở phía client giải quyết được (như đã thống nhất từ
  đầu, không nằm trong phạm vi cần xử lý ở đây).

## Có thể mở rộng thêm (nếu muốn)

- Dùng **GeckoView** (thư viện engine của Firefox, Mozilla cho nhúng vào app
  riêng) thay cho WebView chuẩn của Android nếu muốn tương thích trang web tốt
  hơn WebView hệ thống (một số máy cài WebView cũ/thiếu cập nhật).
- Thêm `BroadcastReceiver` lắng nghe `BOOT_COMPLETED` để tự khởi động lại app
  sau khi thiết bị reboot.
