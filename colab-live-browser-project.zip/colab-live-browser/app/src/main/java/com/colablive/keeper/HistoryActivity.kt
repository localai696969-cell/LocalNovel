package com.colablive.keeper

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.format.DateUtils
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.colablive.keeper.core.BrowserHistory
import com.colablive.keeper.core.ProfileSlots

/**
 * Màn hình LỊCH SỬ DUYỆT WEB — tính năng thiếu thật trước đây (người dùng
 * yêu cầu làm). Đọc từ `BrowserHistory` (xem file đó để biết cách lưu +
 * lý do không dùng API History "chính chủ" của GeckoView).
 *
 * Cách mở URL đã chọn: `setResult()` trả `open_url` về Activity đã mở màn
 * hình này (`MainActivity` mở qua `startActivityForResult`), rồi
 * `MainActivity` tự `engine.loadUrl()` ở tab đang active — không tự mở
 * Activity mới ở đây vì màn hình này không có `engine` sống để dùng.
 */
class HistoryActivity : AppCompatActivity() {

    private var slotIndex = 0
    private lateinit var listLayout: LinearLayout

    // Hiển thị tối đa 1 lượt để tránh chậm máy nếu lịch sử rất dài (đã giới
    // hạn tối đa 3000 mục lưu trong BrowserHistory, nhưng vẽ hết 3000 dòng
    // 1 lúc vẫn có thể giật — hiện 300 mục gần nhất trước, có nút xem thêm.
    private var displayLimit = 300
    private var allEntries: List<BrowserHistory.Entry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        slotIndex = intent.getIntExtra("slot_index", 0)
        render()
    }

    private fun render() {
        val density = resources.displayMetrics.density
        val padding = (12 * density).toInt()

        allEntries = BrowserHistory.readEntries(this, slotIndex)

        val clearButton = Button(this).apply {
            text = "🗑 Xoá toàn bộ lịch sử"
            setOnClickListener { confirmClear() }
        }

        listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        buildRows()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@HistoryActivity).apply {
                text = "Lịch sử — Khe $slotIndex (${ProfileSlots.getSlotAssignmentDisplay(this@HistoryActivity, slotIndex)})"
                textSize = 13f
                setTextColor(Color.GRAY)
                setPadding(padding, padding, padding, 0)
            })
            addView(clearButton)
            addView(
                ScrollView(this@HistoryActivity).apply { addView(listLayout) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
    }

    private fun buildRows() {
        listLayout.removeAllViews()
        if (allEntries.isEmpty()) {
            listLayout.addView(TextView(this).apply {
                text = "Chưa có lịch sử nào."
                setPadding(0, (24 * resources.displayMetrics.density).toInt(), 0, 0)
            })
            return
        }
        val density = resources.displayMetrics.density
        val shown = allEntries.take(displayLimit)
        val ripple = android.util.TypedValue().also {
            theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
        }.resourceId

        shown.forEach { entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, (10 * density).toInt(), 0, (10 * density).toInt())
                isClickable = true
                isFocusable = true
                setBackgroundResource(ripple)
                setOnClickListener {
                    setResult(RESULT_OK, Intent().putExtra("open_url", entry.url))
                    finish()
                }
                setOnLongClickListener {
                    confirmDeleteOne(entry)
                    true
                }
            }
            row.addView(TextView(this).apply {
                text = entry.title.ifBlank { entry.url }
                textSize = 15f
                setTextColor(Color.BLACK)
                maxLines = 1
            })
            row.addView(TextView(this).apply {
                text = entry.url
                textSize = 12f
                setTextColor(Color.GRAY)
                maxLines = 1
            })
            row.addView(TextView(this).apply {
                text = DateUtils.getRelativeTimeSpanString(entry.time)
                textSize = 11f
                setTextColor(Color.LTGRAY)
            })
            listLayout.addView(row)
        }
        if (allEntries.size > displayLimit) {
            listLayout.addView(Button(this).apply {
                text = "Xem thêm (còn ${allEntries.size - displayLimit} mục)"
                setOnClickListener {
                    displayLimit += 300
                    buildRows()
                }
            })
        }
    }

    private fun confirmDeleteOne(entry: BrowserHistory.Entry) {
        AlertDialog.Builder(this)
            .setMessage("Xoá mục lịch sử này?\n${entry.title.ifBlank { entry.url }}")
            .setPositiveButton("Xoá") { _, _ ->
                BrowserHistory.deleteEntry(this, slotIndex, entry.url, entry.time)
                Toast.makeText(this, "Đã xoá", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("Xoá toàn bộ lịch sử?")
            .setMessage("Không thể hoàn tác.")
            .setPositiveButton("Xoá hết") { _, _ ->
                BrowserHistory.clear(this, slotIndex)
                Toast.makeText(this, "Đã xoá lịch sử", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }
}
