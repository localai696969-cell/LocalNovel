package com.colablive.keeper

import android.app.Dialog

import android.Manifest
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.*
import com.colablive.keeper.features.colablive.ColabLiveKeeperFeature
import java.io.File
import com.colablive.keeper.features.downloads.DownloadManagerFeature
import com.colablive.keeper.features.downloads.SaveLocationDialog
import com.colablive.keeper.features.fingerprint.FingerprintSpoofFeature
import org.json.JSONObject
import org.mozilla.geckoview.GeckoView
import java.net.URLEncoder

open class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var engine: GeckoViewEngine

    // Trạng thái tương tác của người dùng — để vòng lặp Auto Behavior KHÔNG
    // chen vào lúc đang gõ/chạm (xem GeckoViewEngine.startAutoBehavior).
    @Volatile private var imeVisibleNow = false
    @Volatile private var lastTouchUptimeMs = 0L
    private var selectionFallback: SelectionFallbackMenu? = null

    private fun userIsInteracting(): Boolean =
        imeVisibleNow || (android.os.SystemClock.uptimeMillis() - lastTouchUptimeMs < 45_000L)

    override fun dispatchTouchEvent(ev: android.view.MotionEvent?): Boolean {
        if (ev != null) {
            lastTouchUptimeMs = android.os.SystemClock.uptimeMillis()
            try { selectionFallback?.onTouch(ev) } catch (e: Exception) { /* không để lỗi phụ làm hỏng cảm ứng */ }
        }
        return super.dispatchTouchEvent(ev)
    }
    private lateinit var urlBar: EditText
    private lateinit var urlSuggestionsPopup: android.widget.ListPopupWindow
    private lateinit var tabBar: HorizontalScrollView
    private lateinit var tabBarCollapseButton: ImageButton
    private var tabBarExpanded = true
    private lateinit var tabContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var refreshButton: ImageButton
    private lateinit var bookmarkButton: ImageButton
    private lateinit var pinButton: ImageButton
    private lateinit var menuButton: ImageButton
    private lateinit var newTabButton: ImageButton
    private lateinit var tabSwitcherButton: TextView
    private lateinit var toolbarContainer: LinearLayout
    private lateinit var colabLiveButton: Button
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — Tìm trong trang, giống Ctrl+F.
    // `findBarContainer` mặc định GONE, chỉ hiện khi bấm menu "🔎 Tìm
    // trong trang". Xem `showFindInPageBar()`/`hideFindInPageBar()`.
    private lateinit var findBarContainer: LinearLayout
    private lateinit var findBarInput: EditText
    private lateinit var findBarCounter: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var slotIndex = 0
    private val tabViews = mutableMapOf<String, View>()
    // TÍNH NĂNG MỚI (người dùng yêu cầu, giống Chrome: bấm vào dải màu
    // header của nhóm để THU GỌN/MỞ RỘNG — ẩn hết card bên trong, chỉ còn
    // lại dải màu). Lưu ở cấp Activity, RAM-only (khớp đúng cách `groups`
    // của engine cũng chỉ lưu RAM, xem GeckoViewEngine.kt).
    // TÍNH NĂNG MỚI (người dùng yêu cầu, giống Chrome — xem ảnh chụp màn
    // hình "2 mục" kèm menu Chọn tất cả/Đóng các thẻ/Thêm vào nhóm/Đánh
    // dấu/Chia sẻ): trạng thái CHỌN NHIỀU TAB trong lưới. Đặt cấp
    // Activity (không phải local trong showTabSwitcher()) vì
    // `createTabCard()` là hàm riêng của class, cần đọc/sửa được cùng
    // state này khi xử lý tap chọn/bỏ chọn từng card.
    private val selectedTabIds = mutableSetOf<String>()
    private var selectionModeActive = false
    // Gán bởi showTabSwitcher() mỗi lần mở — cho phép createTabCard() (ở
    // xa, không cùng closure) yêu cầu vẽ lại lưới + thanh tiêu đề sau khi
    // tap chọn/bỏ chọn 1 card. Dọn về null lúc dialog đóng.
    private var activeTabSwitcherRefresh: (() -> Unit)? = null
    private val collapsedGroupIds = mutableSetOf<String>()
    // TÍNH NĂNG MỚI (người dùng yêu cầu) — ảnh thu nhỏ THẬT của từng tab,
    // giống Chrome. Chụp bằng `GeckoView.capturePixels()` (API chính thức
    // của GeckoView, xác nhận qua Javadoc — trả về đúng ảnh Bitmap của nội
    // dung web đang hiển thị thật, không phải giả lập). CHỈ chụp được ảnh
    // của tab ĐANG HIỂN THỊ thật trên `geckoView` (widget dùng chung cho
    // mọi tab, chỉ 1 tab gắn vào nó tại 1 thời điểm) — nên PHẢI chụp NGAY
    // TRƯỚC KHI chuyển sang tab khác, xem `switchToTabCapturingThumbnail()`.
    // Lưu trong RAM (không phải file) vì đã hạ độ phân giải rất nhỏ
    // (200x120) — nhẹ, đủ cho card xem trước, tránh tốn thêm I/O đĩa.
    private val tabThumbnails = mutableMapOf<String, android.graphics.Bitmap>()
    private var gracefulCloseReceiver: android.content.BroadcastReceiver? = null
    private var keepAliveStoppedReceiver: android.content.BroadcastReceiver? = null
    // Xem chú thích ở gracefulCloseReceiver phía trên — chặn onPause() ghi
    // đè saveTabsState() lần 2 (rỗng) sau khi đã lưu đúng lúc bắt đầu đóng
    // khe đàng hoàng.
    private var tabsSavedForShutdown = false
    // Xem BUG THẬT ở setupDragDrop() — giữ tham chiếu DragAndDropPermissions
    // sống từ ACTION_DROP tới ACTION_DRAG_ENDED, không release ngay.
    private var pendingDragPermissions: android.view.DragAndDropPermissions? = null
    // Dùng cho fix "kéo-thả không hoạt động" — xem setupDragDrop() +
    // onFilePromptListener: lưu URI vừa được thả (ACTION_DROP) để tự động
    // giải quyết FilePrompt sắp bắn ra ngay sau đó, không mở lại hộp thoại
    // chọn file từ đầu bắt người dùng chọn lại lần 2.
    // FIX BUG THẬT (kéo-thả nhiều file chỉ nhận 1 — xem chú thích lớn ở
    // GeckoViewEngine.onFilePromptListener): đổi từ 1 Uri sang danh sách.
    private var lastDroppedFileUris: List<Uri> = emptyList()
    private var lastDroppedFileUriTime: Long = 0L
    /**
     * Dùng cho luồng "hỏi ngay từ đầu, tải chạy song song" — xem
     * `GeckoViewEngine.onDownloadStartedListener` + `maybeFinalizeBgDownload()`.
     * Key = uri của response — ghép 2 tín hiệu bất đồng bộ (kết quả dialog
     * + file đã drain xong) xảy ra KHÔNG theo thứ tự cố định (dialog có thể
     * xong trước hoặc sau khi drain xong, tuỳ người dùng thao tác nhanh hay
     * chậm) lại thành 1 hành động cuối cùng duy nhất.
     */
    private class PendingBgDownload {
        var saveResult: SaveLocationDialog.SaveResult? = null
        var dialogDone = false
        var tempFilePath: String? = null
        var drainDone = false
    }
    private val pendingBgDownloads = mutableMapOf<String, PendingBgDownload>()

    /**
     * Chỉ thật sự hành động (copy file vào nơi đã chọn, hoặc huỷ/dọn file
     * tạm) khi CẢ HAI tín hiệu đã có — nếu chỉ mới có 1 trong 2, chờ tiếp,
     * KHÔNG làm gì (hàm này được gọi lại từ CẢ 2 callback, mỗi khi 1 trong
     * 2 tín hiệu tới).
     */
    private fun maybeFinalizeBgDownload(uri: String) {
        val pending = pendingBgDownloads[uri] ?: return
        if (!pending.dialogDone || !pending.drainDone) return
        pendingBgDownloads.remove(uri)
        val result = pending.saveResult
        val tempPath = pending.tempFilePath
        val tempFile = tempPath?.let { java.io.File(it) }
        if (result == null || !result.confirmed) {
            // Người dùng đã huỷ ở dialog (dù drain xong hay chưa cũng không
            // còn cần file tạm nữa) — dọn sạch, không để rác lại (đúng bài
            // học rút ra từ bug rò rỉ 800MB đã sửa trước đó).
            tempFile?.delete()
            Toast.makeText(this, "Đã huỷ tải", Toast.LENGTH_SHORT).show()
            return
        }
        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
        if (tempFile != null && tempFile.exists() && tempFile.length() > 0) {
            val customPath = if (result.locationType == "custom") result.directory else null
            downloadFeature?.moveLocalFileToChosenLocation(this, tempFile, result.fileName, result.locationType, customPath)
            Toast.makeText(this, "Đang lưu: ${result.fileName}", Toast.LENGTH_SHORT).show()
        } else {
            // Drain lỗi/file rỗng — đã có log chi tiết ở phía GeckoViewEngine,
            // ở đây chỉ cần báo người dùng biết, không âm thầm im lặng.
            Toast.makeText(this, "Tải lỗi: không nhận được dữ liệu file", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val RC_FILE_PICKER = 1001
        private const val RC_NOTIFICATIONS = 1002
        private const val RC_HISTORY = 1003
        private const val RC_BOOKMARKS = 1004
        private const val RC_ADDON_INSTALL = 1005
        private const val PERMISSION_NOTIFICATIONS = Manifest.permission.POST_NOTIFICATIONS
        // TÍNH NĂNG MỚI (người dùng yêu cầu): "mở mới trình duyệt" (bấm icon
        // trên màn hình chính / app drawer, KHÔNG PHẢI Android tự đưa task
        // đã chạy sẵn lên lại — xem giải thích ở đầu onCreate()) giờ hiện
        // MÀN HÌNH CHỌN KHE/PROFILE (`ProfilePickerActivity`, đúng giao diện
        // "Chuyển Khe" đã có sẵn) TRƯỚC, thay vì vào thẳng trình duyệt luôn.
        // Cờ này đánh dấu "đã qua màn hình chọn, CHO PHÉP vào thẳng trình
        // duyệt" — gắn bởi 2 nơi DUY NHẤT được phép bỏ qua màn hình chọn:
        // `ProfilePickerActivity.openSlot()` (người dùng vừa tự bấm chọn ở
        // màn hình đó) và `doRestartSlot()` (khởi động lại SAU KHI người
        // dùng vừa đổi profile gán cho khe — cũng coi như đã "chọn" rồi,
        // không bắt chọn lại lần 2 ngay lập tức).
        const val EXTRA_SKIP_PICKER = "skip_picker"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // QUAN TRỌNG: launcher (bấm icon màn hình chính) KHÔNG gửi kèm extra
        // tuỳ ý — "slot_index" chỉ có khi CHÍNH APP tự mở 1 khe khác. Bấm
        // thẳng icon "Khe 1/2/3" (activity-alias, chạy process ":slot1/2/3"
        // riêng) sẽ không có extra này — nếu chỉ dựa extra, mọi khe sẽ luôn
        // nghĩ mình là khe 0, khiến 2 tiến trình khác nhau cùng cố mở CHUNG 1
        // thư mục hồ sơ Gecko (`gecko_profile_slot_0`) cùng lúc — Gecko có
        // khoá hồ sơ, việc này có thể khiến GeckoRuntime khởi tạo lỗi/crash ở
        // tiến trình mở sau. Nguồn đáng tin cậy thật là TÊN TIẾN TRÌNH đang chạy.
        slotIndex = if (intent.hasExtra("slot_index")) {
            intent.getIntExtra("slot_index", 0)
        } else {
            ProfileSlots.getCurrentSlotIndex(this)
        }
        // CHẨN ĐOÁN TRỰC TIẾP — dòng này lộ ra ĐÚNG nguồn nào quyết định
        // slotIndex của Activity đang chạy: nếu intent CÓ "slot_index" thì
        // dùng giá trị đó (bỏ qua tên tiến trình hoàn toàn) — nếu nơi gọi
        // startActivity truyền sai giá trị này, MainActivity sẽ nhận sai
        // mà không hề đụng tới getCurrentSlotIndex() chút nào. Log rõ CẢ 2
        // để so sánh trực tiếp, không đoán.
        val rawProcessNameCheck = if (android.os.Build.VERSION.SDK_INT >= 28) android.app.Application.getProcessName() else "(SDK<28)"
        DebugLog.log("CHẨN ĐOÁN MainActivity.onCreate: intent.hasExtra(slot_index)=${intent.hasExtra("slot_index")}, intent.slot_index=${intent.getIntExtra("slot_index", -999)}, processName_THẬT='$rawProcessNameCheck', slotIndex_CUỐI_CÙNG=$slotIndex")

        // TÍNH NĂNG MỚI (người dùng yêu cầu): "mở mới trình duyệt" hiện màn
        // hình CHỌN KHE/PROFILE trước, KHÔNG vào thẳng trình duyệt — xem
        // giải thích đầy đủ ở `EXTRA_SKIP_PICKER`. Đặt gate NGAY ĐẦU
        // onCreate() (trước MỌI dòng đụng tới GeckoRuntime/UI thật bên
        // dưới) — nếu launch này KHÔNG mang cờ xác nhận, chuyển hẳn sang
        // `ProfilePickerActivity` rồi `finish()` ngay, không tốn tài nguyên
        // tạo GeckoRuntime/session cho 1 Activity sắp bị đóng ngay sau đó.
        //
        // CHỈ áp dụng cho lần TẠO MỚI Activity thật (`onCreate`) — không
        // đụng gì tới `onResume()`/`onRestart()` khi Android tự đưa 1 task
        // ĐÃ CHẠY SẴN lên lại (bấm icon lúc app đang chạy nền, hoặc chọn từ
        // Recent Apps) — 2 trường hợp đó KHÔNG gọi lại `onCreate()`, nên
        // không bị hỏi lại, đúng ý "chỉ hỏi khi MỞ MỚI".
        if (!intent.getBooleanExtra(EXTRA_SKIP_PICKER, false)) {
            DebugLog.log("Khe $slotIndex: mở MỚI (không có cờ EXTRA_SKIP_PICKER) — chuyển sang màn hình chọn khe/profile trước khi vào trình duyệt")
            startActivity(Intent(this, ProfilePickerActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            finish()
            return
        }

        ForegroundState.broadcastActiveSlot(this, slotIndex)
        updateTaskDescription() // nhãn thẻ trong Recent Apps — xem hàm bên dưới

        /**
         * BUG CỰC KỲ NGHIÊM TRỌNG — lần sửa TRƯỚC (chỉ `engine.release()` +
         * đợi ack) người dùng test lại VẪN mất dữ liệu. Nghĩ lại kỹ hơn:
         * `engine.release()` chỉ đóng CÁC TAB (`GeckoSession.close()`) — đây
         * KHÔNG đồng nghĩa với việc Gecko đã ghi xong cookie/phiên đăng nhập
         * xuống đĩa! Kho lưu cookie trong Gecko chạy như 1 dịch vụ RIÊNG,
         * độc lập với việc đóng tab — đóng tab không tự động ép dịch vụ đó
         * flush ngay. Cách THẬT SỰ đảm bảo Gecko ghi hết dữ liệu là tắt hẳn
         * `GeckoRuntime` (`runtime.shutdown()`) — đây mới đúng là điểm Gecko
         * dọn dẹp/flush toàn bộ trước khi thoát.
         *
         * Trước đây KHÔNG dám gọi `shutdown()` vì sợ lặp lại đúng bug đã sửa
         * ở mục 8g (gọi `release()`/quên khỏi map mà KHÔNG shutdown khiến
         * tạo runtime lần 2 trong process còn sống bị Gecko từ chối). Nhưng
         * ở ĐÂY khác: broadcast này CHỈ được gửi từ đúng 1 chỗ duy nhất —
         * `ProfilePickerActivity.restartSlot()` — và ngay sau khi nhận được,
         * process này CHẮC CHẮN bị kill/exit ngay sau đó (xem
         * `doRestartSlot()`), không bao giờ còn cơ hội tạo GeckoRuntime nào
         * khác trong CHÍNH process này nữa — nên `shutdown()` ở đây an toàn,
         * không tái diễn bug 8g.
         */
        gracefulCloseReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                DebugLog.log("Khe $slotIndex: nhận broadcast đóng đàng hoàng — đóng tab + TẮT HẲN GeckoRuntime (đảm bảo flush thật) trước khi finish()")
                // BUG THẬT tìm được qua lần theo đúng thứ tự gọi hàm (người
                // dùng báo: "backup and restore profile bị lỗi khi thiếu
                // tab" — KHÔNG phải suy đoán, đã xác nhận chắc chắn xảy ra
                // MỖI LẦN, không phải ngẫu nhiên):
                //
                // Thứ tự CŨ: engine.release() [xoá tabMeta] → shutdown() →
                // gửi ACK [ProfilePickerActivity bắt đầu nén zip NGAY] →
                // finish() → Android tự gọi onPause() → onPause() gọi
                // engine.saveTabsState() → lúc này tabMeta ĐÃ RỖNG (do
                // release() xoá ở bước đầu) → saveTabsState() ghi mảng RỖNG
                // → code có `if (arr.length()==0) tabStateFile().delete()`
                // → saved_tabs.json bị XOÁ THẲNG, đúng lúc file này có thể
                // đang được đóng gói vào .zip backup (export chạy ngay khi
                // nhận ACK, có thể đọc file NGAY LÚC file vừa bị xoá/ghi
                // rỗng). Đây là lỗi THỨ TỰ chắc chắn xảy ra, không phải race
                // hiếm gặp — ảnh hưởng CẢ luồng export lẫn luồng đổi/gán lại
                // hồ sơ bình thường (restartSlot() dùng chung cơ chế này).
                //
                // Sửa: gọi saveTabsState() NGAY ĐẦU TIÊN, TRƯỚC KHI
                // release() xoá tabMeta — đảm bảo file trên đĩa phản ánh
                // đúng danh sách tab tại thời điểm đóng. Đồng thời đặt cờ
                // `tabsSavedForShutdown` để CHẶN saveTabsState() ghi đè lần
                // 2 (rỗng) khi onPause() tự động chạy sau finish() — nếu
                // không chặn, đúng bug y hệt vẫn xảy ra ở lần gọi thứ 2.
                // FIX MỚI — giả thuyết CHƯA 100% xác nhận bằng log thật
                // (cần lần tái hiện tiếp theo + mở CrashReportActivity để
                // xác nhận chắc chắn), nhưng có căn cứ cụ thể: tra chính
                // Mozilla Bugzilla (bug 1680407) cho thấy đúng kiểu lỗi
                // native GeckoView từng gây "FATAL EXCEPTION: main —
                // RuntimeException: GeckoRuntime is shutting down" khi CÓ
                // message/callback nội bộ của Gecko (IPC từ luồng nền native)
                // đang xếp hàng trong Looper CHÍNH của tiến trình, đến lượt
                // xử lý ĐÚNG LÚC/NGAY SAU khi shutdown() vừa được gọi trong
                // CÙNG tiến trình. Với "ghi đè hồ sơ khe ĐANG chạy" — khe 0
                // và ProfilePickerActivity/ImportBackupService dùng CHUNG 1
                // tiến trình (không có android:process riêng) — nên đây là
                // ứng viên hợp lý nhất cho lỗi "biến mất hoàn toàn, không 1
                // dòng log, cả tiến trình khởi động lại" (ngoại lệ dạng này
                // ném trên main thread → crash handler bắt được nhưng
                // process vẫn bị kill theo đúng thiết kế hiện tại của crash
                // handler).
                //
                // Sửa phòng thủ: bọc try/catch quanh saveTabsState()/
                // release()/shutdown() — nếu đúng là lỗi này, giờ sẽ CHỈ ghi
                // log chi tiết + vẫn gửi ACK để import không bị treo chờ,
                // KHÔNG để ngoại lệ lọt ra ngoài receiver (nơi nó sẽ crash
                // toàn tiến trình theo đường Thread.UncaughtExceptionHandler).
                try {
                    engine.saveTabsState()
                    tabsSavedForShutdown = true
                    engine.release()
                    GeckoRuntimeProvider.shutdown(slotIndex)
                    DebugLog.log("Khe $slotIndex: đã shutdown xong — gửi ACK")
                } catch (t: Throwable) {
                    DebugLog.log(
                        "Khe $slotIndex: [CHẨN ĐOÁN] LỖI khi đóng khe đàng hoàng — " +
                            "${t.javaClass.name}: ${t.message} — đã CHẶN không cho crash " +
                            "toàn tiến trình, vẫn gửi ACK để import/export phía " +
                            "ProfilePickerActivity không bị treo chờ mãi."
                    )
                }
                sendBroadcast(Intent(ProfileSlots.gracefulCloseAckAction(slotIndex)).apply { setPackage(packageName) })
                finish()
            }
        }
        // ContextCompat.registerReceiver (không phải registerReceiver() thẳng)
        // vì cờ RECEIVER_NOT_EXPORTED + overload 3 tham số chỉ có từ API 33 —
        // app này minSdk 26, gọi thẳng sẽ crash NoSuchMethodError trên máy cũ.
        ContextCompat.registerReceiver(
            this,
            gracefulCloseReceiver,
            android.content.IntentFilter(ProfileSlots.gracefulCloseAction(slotIndex)),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        // Xem chú thích ở KeepAliveService::onStartCommand() ACTION_STOP —
        // nghe broadcast NỘI BỘ service tự phát ra SAU KHI đã dừng xong
        // (do người dùng bấm "Dừng" trên thanh thông báo), để đồng bộ lại
        // nút "Colab Live" trong toolbar NGAY LẬP TỨC — không cần người
        // dùng tự điều hướng lại mới thấy đúng trạng thái.
        keepAliveStoppedReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: Intent?) {
                val stoppedSlotIndex = intent?.getIntExtra("slot_index", -1) ?: -1
                if (stoppedSlotIndex == slotIndex) {
                    DebugLog.log("Khe $slotIndex: nhận KEEPALIVE_STOPPED_FROM_NOTIFICATION — đồng bộ lại nút Colab Live")
                    refreshColabLiveButton()
                }
            }
        }
        ContextCompat.registerReceiver(
            this,
            keepAliveStoppedReceiver,
            android.content.IntentFilter(KeepAliveService.ACTION_STOPPED_FROM_NOTIFICATION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        DebugLog.log("MainActivity.onCreate: slot=$slotIndex, bắt đầu setupUI()")
        setupUI()
        DebugLog.log("MainActivity.onCreate: setupUI xong, bắt đầu setupEngine() (tạo GeckoRuntime — điểm nghi ngờ crash native cao nhất)")
        setupEngine()
        DebugLog.log("MainActivity.onCreate: setupEngine xong, bắt đầu setupDragDrop()")
        setupDragDrop()
        DebugLog.log("MainActivity.onCreate: setupDragDrop xong, bắt đầu initServices()")
        initServices()
        DebugLog.log("MainActivity.onCreate: initServices xong, bắt đầu requestPermissions()")
        requestPermissions()
        DebugLog.log("MainActivity.onCreate: HOÀN TẤT")
    }

    private fun initServices() {
        // BUG THẬT đã tìm ra (người dùng báo: thanh thông báo "Colab Live —
        // đang giữ kết nối" ĐÃ chạy ngay từ lúc khởi động trình duyệt, TRƯỚC
        // cả khi trang Colab tải xong, TRƯỚC cả khi bấm nút xanh "Colab
        // Live" trong toolbar): dòng `KeepAliveService.start(this)` này
        // chạy VÔ ĐIỀU KIỆN ở MỌI lần `onCreate()` — tức MỌI lần mở app,
        // MỌI khe — hoàn toàn không kiểm tra cờ `colablive_keepalive_on`
        // (AppPrefs). Trong khi đó, nút "Colab Live" ở toolbar (xem
        // `updateColabLiveButton()`/handler click ở dòng ~881-913) mới
        // chính là nơi THIẾT KẾ ĐÚNG để bật/tắt service này theo lựa chọn
        // thật của người dùng — dòng ở đây chạy song song, đá lên trên,
        // vô hiệu hoá hoàn toàn ý nghĩa của cái nút đó.
        // SỬA: chỉ khởi động lại service nếu người dùng đã TỪNG bật nó ở
        // phiên trước (giữ đúng trạng thái xuyên suốt việc app bị hệ thống
        // giết rồi mở lại) — không còn tự bật vô điều kiện.
        if (com.colablive.keeper.core.AppPrefs.getBoolean(this, slotIndex, "colablive_keepalive_on", false)) {
            KeepAliveService.start(this, slotIndex, "MainActivity.initServices() — khôi phục vì cờ colablive_keepalive_on đã lưu là true từ phiên trước")
        }
        requestIgnoreBatteryOptimizations()
        // BUG THẬT liên quan (người dùng báo: "trình duyệt khi khởi động
        // cực kỳ chậm và nặng"): cleanupOrphanedTempFiles() làm I/O đĩa
        // (liệt kê + xoá file) TRỰC TIẾP TRÊN MAIN THREAD, ngay trong luồng
        // khởi động app — ĐÚNG lúc mọi việc khác (tạo GeckoRuntime, mở
        // tab, vẽ UI) cũng đang tranh giành main thread. Nếu thư mục temp
        // tích tụ NHIỀU file mồ côi qua nhiều lần tải lỗi (rất có thể xảy
        // ra đúng lúc này, vì các lỗi download khác trong dự án chưa chắc
        // đã hết), số file cần xoá càng nhiều, khởi động càng chậm dần
        // theo thời gian — khớp với mô tả "chậm đến mức bấm đăng nhập
        // Google không kịp". CHƯA XÁC NHẬN đây là nguyên nhân DUY NHẤT của
        // toàn bộ độ chậm (GeckoRuntime.create() tự nó vốn đã chậm, đây là
        // đặc tính đã biết của GeckoView, không phải bug) — nhưng dọn file
        // KHÔNG có lý do gì phải chặn main thread, chuyển sang luồng nền
        // là cải thiện an toàn, đúng hướng bất kể có phải nguyên nhân
        // chính hay không.
        Thread {
            com.colablive.keeper.features.downloads.AudioExtractor.cleanupOrphanedTempFiles(this)
        }.start()
        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
        downloadFeature?.initEngine(this)
        // Đăng ký lắng nghe thay đổi số download đang chạy — xem chú thích
        // đầy đủ ở `refreshKeepAliveServiceState()` (bug Doze mode chặn
        // mạng cho cả tab ghim lẫn download lớn). Gọi ngay 1 lần ở đây để
        // đồng bộ đúng trạng thái ban đầu (phòng trường hợp có download từ
        // phiên trước còn "đang chạy" theo dữ liệu cũ, dù thực tế khó xảy
        // ra vì executor mới tinh mỗi lần app khởi động lại).
        DownloadManagerFeature.setOnActiveDownloadsChangedListener(this) { refreshKeepAliveServiceState() }
        refreshKeepAliveServiceState()

        // Setup proxy cho slot này
        setupProxyForSlot()

        // Load trang mặc định — hoặc URL được truyền vào từ "Mở ở khe khác"
        // (nhấn giữ link ở khe khác, chọn mở link này ở khe này)
        //
        // THEO YÊU CẦU: khôi phục lại các tab đang mở từ lần trước (giống
        // Chrome/Firefox thật) thay vì luôn mở trang chủ trắng — xem
        // `GeckoViewEngine.restoreTabsIfAny()`. Nếu người dùng đang cố mở 1
        // URL cụ thể (`openUrl` != null, từ "Mở ở khe khác") thì ưu tiên mở
        // đúng URL đó trước, không khôi phục (tránh gây nhầm lẫn "tôi bấm mở
        // link này mà sao lại ra tab cũ").
        val openUrl = intent.getStringExtra("open_url")
        if (openUrl != null) {
            engine.createTab(openUrl)
        } else if (reusedExistingEngine) {
            // Engine vừa được GẮN LẠI (không phải tạo mới) — tab đã sống sẵn
            // trong RAM từ trước, KHÔNG được đụng vào restoreTabsIfAny()/tạo
            // tab trang chủ (sẽ tạo tab TRÙNG hoặc tải lại tab đang có sẵn).
            // Chỉ cần đồng bộ lại UI (omnibox/nút back-forward/chế độ ẩn
            // danh) cho khớp với trạng thái THẬT hiện có, vì các View này là
            // View MỚI của Activity mới, đang rỗng/mặc định.
            updateOmnibox(engine.currentUrl() ?: "")
            updateNavButtons()
            updatePrivateModeUI()
        } else if (!engine.restoreTabsIfAny()) {
            val homeUrl = AppPrefs.getString(this, slotIndex, "home_url", "https://www.google.com")
            engine.createTab(homeUrl)
        }
        refreshTabBar()
    }

    /**
     * BUG THẬT (người dùng báo Colab tự ngắt kết nối khi tắt màn hình): app
     * chưa từng xin miễn trừ "Tối ưu hoá pin" (Battery Optimization) —
     * KHÔNG có dòng gọi `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` nào
     * trong toàn bộ code trước đây. Dù có Foreground Service + WakeLock,
     * Android vẫn có thể áp Doze/App Standby lên app nếu app không nằm
     * trong danh sách miễn trừ pin — khiến kết nối mạng nền (WebSocket của
     * Colab) bị treo. Xin quyền này CÙNG với việc sửa khoảng hở WakeLock
     * (xem `KeepAliveService.kt`) — cả 2 đều cần thiết, sửa 1 mình không đủ.
     *
     * LƯU Ý: trên các máy OEM tự chỉnh sửa Android mạnh (Xiaomi/MIUI,
     * Huawei, Oppo, Vivo...) — đúng loại máy trong Hardware Profile giả lập
     * của app này — riêng quyền hệ thống Android CHUẨN này KHÔNG đủ, hãng
     * còn có cơ chế diệt app nền RIÊNG (VD MIUI "Tự khởi động"/"Khoá app
     * trong Recent"). Việc đó nằm ngoài phạm vi code sửa được, người dùng
     * cần tự vào Cài đặt hãng để thêm.
     */
    private fun requestIgnoreBatteryOptimizations() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                DebugLog.log("requestIgnoreBatteryOptimizations lỗi (${e.message}) — 1 số ROM chặn intent này, không crash app")
            }
        }
    }

    private fun setupProxyForSlot() {
        val proxyType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        if (proxyType > 0) {
            val host = AppPrefs.getString(this, slotIndex, "proxy_host", "")
            val port = AppPrefs.getString(this, slotIndex, "proxy_port", "").toIntOrNull() ?: 0
            val user = AppPrefs.getString(this, slotIndex, "proxy_user", "")
            val pass = AppPrefs.getString(this, slotIndex, "proxy_pass", "")

            if (host.isNotEmpty() && port > 0) {
                engine.setupProxy(host, port, user, pass)
                DebugLog.log("Slot $slotIndex proxy: $host:$port")
            }
        }
    }

    // ===== UI Setup =====

    /** Quy đổi dp -> pixel thật theo mật độ màn hình — dùng để tránh lặp lại
     * bug "48 PIXEL THÔ tưởng là 48dp" (xem giải thích lớn ở `setupUI()`). */
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // Lưu URL THẬT ĐẦY ĐỦ riêng — omnibox chỉ HIỂN THỊ rút gọn (tên miền)
    // khi không focus, cần giữ giá trị gốc để hiện lại đầy đủ lúc bấm vào.
    private var lastLoadedUrl: String = ""

    /**
     * Rút gọn URL về "tên miền" để hiện trong omnibox khi KHÔNG focus,
     * đúng hành vi Chrome thật (VD "https://m.youtube.com/watch?v=xyz..."
     * → "m.youtube.com"). Trả về nguyên URL nếu không parse được domain
     * (VD "about:blank", url rỗng) thay vì làm rỗng ô địa chỉ.
     */
    private fun displayHostOnly(url: String): String {
        if (url.isBlank()) return ""
        return try {
            val uri = Uri.parse(url)
            uri.host ?: url
        } catch (e: Exception) {
            url
        }
    }

    /** Gọi mỗi khi URL thật sự đổi (trang mới load xong / chuyển tab) —
     * cập nhật cả giá trị gốc lẫn hiển thị rút gọn đúng, tôn trọng việc ô
     * đang được focus hay không (không cướp focus/chèn chữ khi người dùng
     * đang gõ dở). */
    /**
     * BUG GỐC đã tìm ra (ảnh chụp: mọi tab đều hiện chấm tròn xanh lè
     * giống hệt nhau, không phân biệt được trang nào với trang nào):
     * `BrowserTab.favicon` có sẵn field từ trước nhưng CHƯA TỪNG được gán
     * ở bất kỳ đâu trong toàn bộ code — luôn `null`, `createTabChip()` tự
     * rơi vào nhánh dự phòng (`presence_online`, chấm tròn xanh) cho MỌI
     * tab. GeckoView KHÔNG có callback "nhận được favicon" sẵn như WebView
     * cũ (`onReceivedIcon`) — phải tự đọc thẻ `<link rel="icon">` qua JS
     * rồi tự tải ảnh bằng HTTP thường.
     */
    /**
     * BUG THẬT đã tìm ra (người dùng báo icon tab vẫn xanh lè dù đã sửa
     * field name ở eval_bridge): `content_scripts` của eval_bridge chạy ở
     * `document_idle` — đây là tín hiệu ĐỘC LẬP với lúc GeckoView tự báo
     * "trang tải xong" (kích hoạt `onPageLoadedListener`, nơi gọi hàm
     * này) — KHÔNG đảm bảo thứ tự trước/sau nhau. Nếu gọi `evaluateJs()`
     * NGAY khi trang vừa báo tải xong mà content script CHƯA KỊP connect
     * port, script bị phát ra 0 port (không lỗi, không log gì — chỉ âm
     * thầm không ai nhận), callback không bao giờ được gọi. Thêm cơ chế
     * TỰ THỬ LẠI (tối đa 3 lần, giãn cách tăng dần) nếu chưa có phản hồi.
     */
    /**
     * BUG THẬT KHÁC đã tìm ra (đọc lại code, không phải đoán): tham số
     * `tabId` TRƯỚC ĐÂY được tính lại bằng `engine.getActiveTab()?.id` ở
     * ĐẦU hàm — nghĩa là MỖI LẦN hàm này được gọi ĐỆ QUY để thử lại (dòng
     * `fetchFaviconForActiveTab(pageUrl, attempt + 1)` bên dưới), nó lại tự
     * lấy tab đang active LÚC ĐÓ, KHÔNG giữ đúng tab ban đầu định lấy
     * favicon. Nếu người dùng chuyển tab trong khoảng 1.5–4.5s đang chờ
     * thử lại, lần thử lại sẽ ÂM THẦM đổi mục tiêu sang tab MỚI đang active
     * — trong khi `engine.evaluateJs()` (không truyền tabId, luôn ngầm
     * định nhắm vào tab active hiện tại của engine) VẪN sẽ bắn script vào
     * đúng tab mới đó. Kết quả: tab ban đầu (đã xác nhận còn đúng
     * `pageUrl`, còn thiếu favicon) bị BỎ RƠI giữa chừng, không ai lấy
     * favicon hộ nữa. Đây là nguồn gốc thật của "favicon vẫn lỗi" — cơ chế
     * cross-tab check ở `evaluateJsForTab` (GeckoViewEngine) không cứu
     * được vì nó chỉ chặn KẾT QUẢ trả về chéo tab, không chặn được việc
     * (do bug) tự đổi mục tiêu ngay từ lúc GỬI request.
     *
     * SỬA: giữ NGUYÊN đúng 1 `tabId` xuyên suốt toàn bộ chuỗi thử lại (chỉ
     * lấy 1 LẦN DUY NHẤT ở lời gọi đầu tiên). Trước khi bắn `evaluateJs()`
     * (vốn luôn ngầm định nhắm tab active hiện tại), kiểm tra tab mục tiêu
     * CÓ CÒN LÀ tab active không — nếu không còn, DỪNG HẲN, không âm thầm
     * đổi mục tiêu (tab active mới, nếu cần favicon, đã có
     * `onTabSwitchedListener` riêng lo khi chuyển tới).
     */
    private fun fetchFaviconForActiveTab(pageUrl: String, tabId: String? = null, attempt: Int = 1) {
        val activeTabIdNow = engine.getActiveTab()?.id ?: return
        val targetTabId = tabId ?: activeTabIdNow
        if (targetTabId != activeTabIdNow) {
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] DỪNG ngay từ đầu — tab mục tiêu ($targetTabId) không còn là tab active ($activeTabIdNow), pageUrl=$pageUrl attempt=$attempt")
            return
        }
        var handled = false
        engine.evaluateJs(
            // FIX: script IIFE dạng (function(){...return x;})() — kết quả
            // IIFE tính ra nhưng new Function() bên trong content.js không
            // nhận được vì thiếu return ở cấp cao nhất → value = undefined →
            // result = "OK" (không có ": <url>") → favicon không bao giờ tải.
            // Đã sửa gốc ở content.js (prepend "return (...)") nhưng giữ
            // dạng IIFE này cho đúng chuẩn — content.js mới bọc lại đúng.
            """
            (function() {
                var links = document.querySelectorAll('link[rel~="icon"], link[rel="shortcut icon"]');
                var best = null;
                for (var i = 0; i < links.length; i++) {
                    var l = links[i];
                    if (l.href) {
                        best = l.href;
                        break;
                    }
                }
                if (!best) best = location.origin + '/favicon.ico';
                return best;
            })();
            """.trimIndent()
        ) { result ->
            handled = true
            // BUG QUAN SÁT ĐƯỢC (người dùng hỏi thẳng: "có nhìn thấy trang
            // claude cho cái favicon nào không???"): TRƯỚC ĐÂY mọi nhánh
            // dưới đây đều IM LẶNG khi thất bại (return@evaluateJs không
            // log gì) — nghĩa là nếu JS trả về sai định dạng, hoặc trang
            // không có link icon nào (kể cả fallback /favicon.ico), KHÔNG
            // CÓ CÁCH NÀO biết được từ log, chỉ đoán mò. Thêm log ở MỌI
            // nhánh — lần tới nếu favicon vẫn lỗi, log sẽ cho biết CHÍNH
            // XÁC dừng ở bước nào (kết quả JS thô, hay HTTP lỗi, hay tab đã
            // đổi trang trước khi tải xong) thay vì phải hỏi/đoán tiếp.
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] pageUrl=$pageUrl attempt=$attempt kết quả JS thô='$result'")
            // Định dạng thật trả về từ eval_bridge: "OK: <giá trị>" (thành
            // công) hoặc "LOI: <thông báo lỗi>" (thất bại) — KHÔNG phải
            // chuỗi JSON thô như code lúc đầu lỡ giả định sai.
            if (result == null || !result.startsWith("OK")) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] DỪNG — kết quả không phải 'OK...' (null hoặc lỗi từ content script)")
                return@evaluateJs
            }
            val faviconUrl = result.removePrefix("OK: ").removePrefix("OK").trim()
                .takeIf { it.isNotBlank() && it != "null" && it != "undefined" }
            if (faviconUrl == null) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] DỪNG — faviconUrl rỗng/null/undefined sau khi bóc tách")
                return@evaluateJs
            }
            Thread {
                try {
                    val conn = java.net.URL(faviconUrl).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 5000
                    conn.readTimeout = 5000
                    conn.instanceFollowRedirects = true
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] đang tải $faviconUrl — HTTP ${conn.responseCode}")
                    // Đọc toàn bộ bytes MỘT LẦN (không dùng inputStream.use{}
                    // trực tiếp cho BitmapFactory nữa) — vì nếu BitmapFactory
                    // thất bại (ảnh SVG), cần thử lại bằng SVG decoder trên
                    // CÙNG dữ liệu, không thể đọc InputStream 2 lần.
                    val bytes = conn.inputStream.use { it.readBytes() }
                    conn.disconnect()
                    var bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bitmap == null) {
                        /**
                         * FIX BUG THẬT (log xác nhận: claude.ai favicon
                         * '...cd02a42d9-Vq_H3mgS.svg' tải HTTP 200 thành
                         * công nhưng BitmapFactory.decodeStream LUÔN trả về
                         * null): `BitmapFactory` chỉ đọc được ảnh RASTER
                         * (PNG/JPEG/WEBP/GIF/BMP) — hoàn toàn KHÔNG hỗ trợ
                         * SVG (định dạng vector, cần 1 trình phân tích XML
                         * + rasterize riêng, không phải decode bytes ảnh
                         * thông thường). claude.ai (và nhiều trang hiện đại
                         * khác) dùng SVG cho favicon vì gọn nhẹ, sắc nét mọi
                         * độ phân giải — nên bug này không chỉ ảnh hưởng 1
                         * trang, mà MỌI trang có favicon SVG đều gặp y hệt.
                         * Thử lại bằng thư viện `androidsvg` — nếu bytes tải
                         * về là SVG hợp lệ, parse + rasterize thành Bitmap ở
                         * kích thước cố định 64x64 (đủ nét cho icon tab nhỏ,
                         * không cần độ phân giải cao hơn).
                         */
                        bitmap = try {
                            val svg = com.caverock.androidsvg.SVG.getFromString(String(bytes, Charsets.UTF_8))
                            val w = 64
                            val h = 64
                            svg.setDocumentWidth(w.toFloat())
                            svg.setDocumentHeight(h.toFloat())
                            val svgBitmap = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
                            val canvas = android.graphics.Canvas(svgBitmap)
                            svg.renderToCanvas(canvas)
                            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] giải mã SVG THÀNH CÔNG cho $faviconUrl (BitmapFactory fail nhưng androidsvg đọc được — xác nhận đúng nguyên nhân là định dạng SVG)")
                            svgBitmap
                        } catch (svgError: Exception) {
                            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] thử SVG cũng thất bại cho $faviconUrl: ${svgError.javaClass.simpleName}: ${svgError.message} — thật sự không phải ảnh hợp lệ (có thể server trả HTML lỗi 404)")
                            null
                        }
                    }
                    if (bitmap != null) {
                        val finalBitmap = bitmap // val bất biến để Kotlin smart-cast được trong lambda runOnUiThread bên dưới (var bị closure capture thì không smart-cast được)
                        runOnUiThread {
                            // Chỉ gán nếu tab vẫn còn tồn tại VÀ vẫn đang ở
                            // đúng trang lúc bắt đầu tải icon (không gán nhầm
                            // icon cũ vào tab đã điều hướng sang trang khác
                            // trong lúc chờ tải favicon).
                            val tab = engine.getTabs().find { it.id == targetTabId }
                            if (tab != null && tab.url == pageUrl) {
                                tab.favicon = finalBitmap
                                refreshTabBar()
                                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] GÁN THÀNH CÔNG cho tab $targetTabId (${finalBitmap.width}x${finalBitmap.height})")
                            } else {
                                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] BỎ QUA gán — tab không còn tồn tại hoặc đã đổi trang (tab?.url=${tab?.url}, pageUrl=$pageUrl)")
                            }
                        }
                    } else {
                        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] BitmapFactory.decodeStream trả về null cho $faviconUrl (HTTP OK nhưng không giải mã được ảnh — có thể server trả về HTML lỗi 404 thay vì ảnh thật)")
                    }
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN favicon] lỗi tải HTTP ($faviconUrl): ${e.javaClass.simpleName}: ${e.message}")
                }
            }.start()
        }
        if (attempt < 3) {
            Handler(Looper.getMainLooper()).postDelayed({
                // Chỉ thử lại nếu tab vẫn còn tồn tại, vẫn đúng trang, VÀ
                // vẫn chưa có favicon (tránh thử lại vô nghĩa nếu lần trước
                // đã thành công hoặc người dùng đã điều hướng sang trang
                // khác). Truyền LẠI đúng `targetTabId` này (không để lần
                // gọi tiếp theo tự tính lại từ tab active — xem bug ở trên).
                val tab = engine.getTabs().find { it.id == targetTabId }
                if (!handled && tab != null && tab.url == pageUrl && tab.favicon == null) {
                    fetchFaviconForActiveTab(pageUrl, targetTabId, attempt + 1)
                }
            }, 1500L * attempt)
        }
    }

    /**
     * Xem chú thích "TÍNH NĂNG THIẾU" ở nơi gắn TextWatcher cho urlBar.
     * Gợi ý TAB ĐANG MỞ trước (bấm để chuyển nhanh, không mở tab mới trùng
     * — đúng hành vi Chrome), sau đó LỊCH SỬ (mới nhất trước). Giới hạn
     * tổng cộng 8 dòng — đủ hữu ích, không che hết màn hình trên máy nhỏ.
     */
    private fun updateUrlSuggestions(query: String) {
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            urlSuggestionsPopup.dismiss()
            return
        }
        val q = trimmed.lowercase()

        data class Suggestion(val label: String, val sub: String, val isTab: Boolean, val target: String)

        val tabMatches = engine.getTabs()
            .filter { it.url.lowercase().contains(q) || it.title.lowercase().contains(q) }
            .take(4)
            .map { Suggestion(it.title.ifBlank { it.url }, "🔵 Tab đang mở — ${it.url}", true, it.id) }

        val historyMatches = com.colablive.keeper.core.BrowserHistory.readEntries(this, slotIndex)
            .asReversed() // mới nhất trước (readEntries trả về theo thứ tự ghi, cũ->mới)
            .filter { it.url.lowercase().contains(q) || it.title.lowercase().contains(q) }
            .distinctBy { it.url }
            .take(8 - tabMatches.size)
            .map { Suggestion(it.title.ifBlank { it.url }, "🕐 ${it.url}", false, it.url) }

        val suggestions = tabMatches + historyMatches
        if (suggestions.isEmpty()) {
            urlSuggestionsPopup.dismiss()
            return
        }

        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = suggestions.size
            override fun getItem(position: Int) = suggestions[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
                val item = suggestions[position]
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                }
                row.addView(TextView(this@MainActivity).apply {
                    text = item.label
                    textSize = 14f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                row.addView(TextView(this@MainActivity).apply {
                    text = item.sub
                    textSize = 11f
                    setTextColor(Color.GRAY)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                return row
            }
        }
        /**
         * BUG THẬT (người dùng chỉ ra qua trải nghiệm: bấm gợi ý "claude
         * chat" nhưng lại điều hướng tới tìm kiếm "colab" — dữ liệu CŨ):
         * `ListPopupWindow` KHÔNG đảm bảo đồng bộ đúng khi gọi lại
         * `setAdapter()` NHIỀU LẦN trong lúc popup ĐANG hiển thị (gõ nhanh
         * → `updateUrlSuggestions()` chạy lại liên tục) — danh sách hiển
         * thị và vị trí/listener mới nhất có thể lệch nhau, khiến bấm vào
         * dòng ĐANG THẤY lại kích hoạt closure của LẦN GỌI TRƯỚC (dữ liệu
         * cũ). Sửa: DISMISS hẳn rồi mới dựng lại từ đầu mỗi lần gọi hàm
         * này — ép Android luôn build lại đồng bộ, tránh dùng lại state
         * còn sót của lần hiển thị trước.
         */
        urlSuggestionsPopup.dismiss()
        urlSuggestionsPopup.setAdapter(adapter)
        urlSuggestionsPopup.height = android.widget.ListPopupWindow.WRAP_CONTENT
        urlSuggestionsPopup.setOnItemClickListener { _, _, position, _ ->
            val item = suggestions[position]
            urlSuggestionsPopup.dismiss()
            urlBar.clearFocus()
            if (item.isTab) {
                switchToTabCapturingThumbnail(item.target)
            } else {
                navigateToUrl(item.target)
            }
        }
        urlSuggestionsPopup.show()
    }

    private fun updateOmnibox(url: String) {
        lastLoadedUrl = url
        if (!urlBar.hasFocus()) {
            urlBar.setText(displayHostOnly(url))
        }
        updateBookmarkButton(url)
        updatePinButton(url)
        refreshColabLiveButton(url)
    }

    /**
     * Cập nhật hiện/ẩn + màu/nhãn nút "Colab Live" theo URL hiện tại + trạng
     * thái bật/tắt đã lưu. Gọi từ `updateOmnibox()` (mỗi lần điều hướng) và
     * ngay sau khi người dùng bấm nút (để phản hồi tức thì không cần đợi
     * điều hướng lại).
     */
    private fun refreshColabLiveButton(urlOverride: String? = null) {
        if (!::colabLiveButton.isInitialized) return
        val url = urlOverride ?: lastLoadedUrl
        val isColab = url.contains("colab.research.google.com")
        colabLiveButton.visibility = if (isColab) View.VISIBLE else View.GONE
        if (!isColab) return
        val isOn = com.colablive.keeper.core.AppPrefs.getBoolean(this, slotIndex, "colablive_keepalive_on", false)
        if (isOn) {
            colabLiveButton.text = "⏱ Colab Live — Đang giữ kết nối (bấm để tắt)"
            colabLiveButton.setBackgroundColor(Color.parseColor("#E53935"))
            colabLiveButton.setTextColor(Color.WHITE)
        } else {
            colabLiveButton.text = "▶ Bật Colab Live (giữ kết nối khi tắt màn hình)"
            colabLiveButton.setBackgroundColor(Color.parseColor("#388E3C"))
            colabLiveButton.setTextColor(Color.WHITE)
        }
    }

    private fun updateBookmarkButton(url: String) {
        if (!::bookmarkButton.isInitialized) return
        val isBookmarked = com.colablive.keeper.core.BrowserBookmarks.isBookmarked(this, slotIndex, url)
        bookmarkButton.setImageResource(if (isBookmarked) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)
    }

    private fun updatePinButton(url: String) {
        if (!::pinButton.isInitialized) return
        val host = try { android.net.Uri.parse(url).host } catch (e: Exception) { null }
        val isPinned = host != null && com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.isDomainPinned(this, slotIndex, host)
        pinButton.setImageResource(if (isPinned) android.R.drawable.ic_menu_myplaces else android.R.drawable.ic_menu_mylocation)
        pinButton.alpha = if (isPinned) 1.0f else 0.5f
    }

    /**
     * BUG THẬT NGHIÊM TRỌNG (người dùng báo, có tái hiện rõ ràng: ghim tab
     * Drive chạy nền, upload file 300MB, tắt màn hình — hơn 1 giờ vẫn chưa
     * xong dù bản sửa mục 51 (`setPriorityHint(PRIORITY_HIGH)`) đã chạy
     * đúng mỗi lần onPause — xác nhận qua log thật). Đã tra cứu web thật
     * (developer.android.com + nhiều nguồn khác) xác nhận: `PRIORITY_HIGH`
     * chỉ ảnh hưởng ưu tiên NỘI BỘ của tiến trình con Gecko (né bị GIẾT bởi
     * OOM killer) — HOÀN TOÀN KHÔNG liên quan tới Doze mode của chính
     * Android. Doze CHẶN MẠNG CHO TOÀN BỘ THIẾT BỊ (kể cả BỎ QUA wake lock
     * thường) sau 1 khoảng thời gian màn hình tắt + máy đứng yên, TRỪ KHI
     * app đang chạy 1 FOREGROUND SERVICE THẬT (có thông báo cố định) — đây
     * là 2 TẦNG HOÀN TOÀN KHÁC NHAU, mục 51 sửa đúng tầng 1 (ưu tiên tiến
     * trình) nhưng bug thật nằm ở tầng 2 (Doze chặn mạng cấp hệ điều hành).
     *
     * May mắn là `KeepAliveService` (foreground service thật + WakeLock,
     * đã sửa đúng theo từng khe ở các lượt trước — xem chú thích đầy đủ
     * trong chính file đó) ĐÃ TỒN TẠI SẴN, nhưng TRƯỚC ĐÂY chỉ được gọi cho
     * tính năng "Auto Behavior"/nút Colab Live — HOÀN TOÀN không liên quan
     * gì tới tính năng "ghim chạy nền" (`BackgroundKeepAliveFeature`). 2
     * tính năng nghe tên gần giống nhau nhưng trước đây là 2 cơ chế tách
     * biệt hoàn toàn, không cái nào gọi cái kia.
     *
     * MỞ RỘNG THÊM (cùng nguyên nhân gốc, người dùng báo tiếp: file 1GB/3GB
     * tải xuống "chẳng được bao nhiêu" — trong khi file vài trăm KB-vài MB
     * tải xong bình thường): tải xuống chạy qua thread pool RIÊNG của
     * `DownloadEngine`, KHÔNG liên quan gì tới tab/session GeckoView — nếu
     * màn hình tắt trong lúc tải file LỚN (kéo dài hàng chục phút/hàng
     * giờ), CÙNG 1 Doze mode này áp dụng y hệt cho các luồng tải xuống đó.
     * Khớp đúng: file nhỏ tải NHANH (xong trước khi Doze kịp kích hoạt),
     * file lớn tải LÂU (rơi vào đúng lúc Doze đã kích hoạt) thì bị chặn.
     * Đã thêm `DownloadEngine.hasActiveDownloads()`/`onActiveDownloadsChanged`
     * — gộp chung điều kiện vào đây.
     *
     * SỬA: dùng LẠI ĐÚNG `KeepAliveService` đã có sẵn (không phát minh cơ
     * chế mới) — bất cứ khi nào có ÍT NHẤT 1 tab đang ghim chạy nền HOẶC
     * ÍT NHẤT 1 download đang chạy, khởi động foreground service thật cho
     * khe này; khi KHÔNG còn lý do nào (không tab ghim, không download,
     * không Auto Behavior), dừng lại (tiết kiệm pin). Gọi hàm này ở MỌI
     * điểm trạng thái ghim/download có thể đổi: ghim/bỏ ghim đơn, ghim/gỡ
     * ghim hàng loạt, bắt đầu/kết thúc download, và `onPause()` (đảm bảo
     * chắc chắn service đang chạy đúng TRƯỚC KHI có khả năng mất mạng do
     * Doze).
     */
    private fun refreshKeepAliveServiceState() {
        if (!::engine.isInitialized) return
        val anyPinned = engine.getTabs().any { tab ->
            val host = try { android.net.Uri.parse(tab.url).host } catch (e: Exception) { null }
            host != null && com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.isDomainPinned(this, slotIndex, host)
        }
        val anyDownloadActive = DownloadManagerFeature.hasActiveDownloads(this)
        if (anyPinned || anyDownloadActive) {
            val reason = when {
                anyPinned && anyDownloadActive -> "có tab đang ghim chạy nền VÀ có download đang chạy"
                anyPinned -> "có tab đang ghim chạy nền (BackgroundKeepAliveFeature)"
                else -> "có download đang chạy (DownloadEngine)"
            }
            KeepAliveService.start(this, slotIndex, "$reason — cần foreground service thật để sống sót qua Doze mode, PRIORITY_HIGH không đủ")
        } else {
            // QUAN TRỌNG: KHÔNG được gọi stop() vô điều kiện ở đây —
            // `KeepAliveService` còn dùng chung cho "Auto Behavior"/nút
            // Colab Live (cờ `colablive_keepalive_on`), không phải service
            // riêng của tính năng ghim/download. Nếu Auto Behavior đang
            // bật, service này VẪN CẦN chạy vì lý do KHÁC — gọi stop() vô
            // điều kiện ở đây sẽ giết NHẦM service mà Auto Behavior đang
            // cần. Chỉ dừng khi CẢ 3 lý do đều không còn cần.
            val autoBehaviorOn = com.colablive.keeper.core.AppPrefs.getBoolean(this, slotIndex, "colablive_keepalive_on", false)
            if (!autoBehaviorOn) {
                KeepAliveService.stop(this, slotIndex)
            }
        }
    }

    /**
     * Chỉ báo trực quan tab ẩn danh — đúng theo Chrome thật (toolbar/status
     * bar chuyển màu tối #202124 khi đang ở tab ẩn danh, dễ phân biệt ngay
     * không cần đọc URL). Gọi mỗi khi chuyển tab / tạo tab mới.
     */
    private fun updatePrivateModeUI() {
        val isPrivate = engine.getActiveTab()?.isPrivate == true
        if (isPrivate) {
            toolbarContainer.setBackgroundColor(Color.parseColor("#202124"))
            urlBar.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#3C4043"))
                cornerRadius = dp(24).toFloat()
            }
            urlBar.setTextColor(Color.WHITE)
            urlBar.setHintTextColor(Color.LTGRAY)
            window.statusBarColor = Color.parseColor("#202124")
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            }
        } else {
            toolbarContainer.setBackgroundColor(Color.parseColor("#F8F9FA"))
            urlBar.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#F1F3F4"))
                cornerRadius = dp(24).toFloat()
            }
            urlBar.setTextColor(Color.BLACK)
            urlBar.setHintTextColor(Color.GRAY)
            window.statusBarColor = Color.parseColor("#F8F9FA")
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
    }

    private fun setupUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // Toolbar container
        toolbarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F8F9FA"))
        }

        // Tab bar — dạng VÒNG TRÒN cuộn ngang (theo yêu cầu người dùng,
        // kèm ảnh tham khảo + bản GeckoView cũ của chính project này) —
        // ĐẢO NGƯỢC lại quyết định trước đó (mục 8zz8, khi đó bỏ hẳn dải
        // tab vì nghĩ Chrome không có) sau khi người dùng làm rõ đây là
        // kiểu giao diện họ THỰC SỰ muốn, không phải lỗi hiểu Chrome.
        // Thêm nút mũi tên (^) thu gọn/mở lại — không có trong ảnh gốc
        // nhưng hợp lý để không chiếm chỗ màn hình khi không cần, người
        // dùng tự bật lại khi muốn.
        tabBarCollapseButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.arrow_up_float)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                tabBarExpanded = !tabBarExpanded
                tabBar.visibility = if (tabBarExpanded) View.VISIBLE else View.GONE
                setImageResource(if (tabBarExpanded) android.R.drawable.arrow_up_float else android.R.drawable.arrow_down_float)
            }
        }
        toolbarContainer.addView(tabBarCollapseButton, ViewGroup.LayoutParams(dp(32), dp(32)))

        tabBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            val tabLayout = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(12, 8, 12, 8)
            }
            tabContainer = tabLayout
            // TÍNH NĂNG MỚI (người dùng yêu cầu) — kéo-thả đổi vị trí tab.
            // Tính chỉ số chèn dựa trên vị trí X của điểm thả so với TÂM
            // từng chip đã có (không tính riêng nút "+" ở cuối — luôn giữ
            // nó ở cuối cùng). `DRAG_LOCATION` cập nhật liên tục lúc kéo
            // (chưa dùng để tránh vẽ lại UI liên tục gây giật), chỉ xử lý
            // thật ở `ACTION_DROP`.
            var chipHighlightView: View? = null
            fun clearChipHighlight() {
                chipHighlightView?.setBackgroundColor(Color.TRANSPARENT)
                chipHighlightView = null
            }
            tabContainer.setOnDragListener { _, event ->
                when (event.action) {
                    android.view.DragEvent.ACTION_DRAG_STARTED -> true
                    android.view.DragEvent.ACTION_DRAG_LOCATION -> {
                        val chipViews = tabViews.entries.toList()
                        var nearest: View? = null
                        for (entry in chipViews) {
                            val chip = entry.value
                            if (event.x >= chip.x && event.x <= chip.x + chip.width) {
                                nearest = chip
                                break
                            }
                        }
                        if (nearest !== chipHighlightView) {
                            clearChipHighlight()
                            nearest?.setBackgroundColor(Color.parseColor("#331A73E8")) // xanh mờ, chỉ để báo "sắp chèn cạnh đây"
                            chipHighlightView = nearest
                        }
                        true
                    }
                    android.view.DragEvent.ACTION_DRAG_EXITED, android.view.DragEvent.ACTION_DRAG_ENDED -> {
                        clearChipHighlight()
                        true
                    }
                    android.view.DragEvent.ACTION_DROP -> {
                        val draggedId = event.localState as? String ?: return@setOnDragListener false
                        val chipViews = tabViews.entries.toList() // giữ đúng thứ tự hiện tại trên UI (đã bỏ qua tab thuộc nhóm đang thu gọn)
                        var neighborTabId: String? = null
                        for (entry in chipViews) {
                            val chip = entry.value
                            val chipCenterX = chip.x + chip.width / 2f
                            if (event.x < chipCenterX) {
                                neighborTabId = entry.key
                                break
                            }
                        }
                        // FIX BUG THẬT (người dùng báo: "group tab trên
                        // thanh tab không kéo di chuyển vị trí được như tab
                        // thường") — `localState` bắt đầu bằng "grp:" nghĩa
                        // là đang kéo CẢ 1 NHÓM (xem `createGroupChipCluster`/
                        // `createGroupPillChip`), không phải 1 tab lẻ. Tách
                        // riêng nhánh này TRƯỚC khi chạy logic tab lẻ cũ bên
                        // dưới — dùng đúng `neighborTabId` vừa tính (tab
                        // KHÔNG thuộc nhóm đang kéo gần điểm thả nhất) làm
                        // mốc "chèn cả khối vào trước tab này".
                        if (draggedId.startsWith("grp:")) {
                            val groupId = draggedId.removePrefix("grp:")
                            DebugLog.log("MainActivity: kéo-thả CẢ NHÓM '$groupId' tới trước tab '$neighborTabId' trên thanh chip ngang")
                            engine.moveGroup(groupId, neighborTabId)
                            clearChipHighlight()
                            refreshTabBar()
                            return@setOnDragListener true
                        }
                        val draggedTabId = draggedId
                        // SỬA BUG TIỀM ẨN: quy đổi lại vị trí HIỂN THỊ (bỏ
                        // qua tab đang ẩn vì thuộc nhóm thu gọn) về đúng chỉ
                        // số THẬT trong engine.getTabs() — nếu dùng thẳng chỉ
                        // số trong `tabViews`, sẽ lệch khi có nhóm đang thu
                        // gọn (ẩn bớt chip phía trước).
                        val rawTabs = engine.getTabs()
                        val targetIndex = neighborTabId?.let { nid -> rawTabs.indexOfFirst { it.id == nid } }
                            ?.takeIf { it >= 0 } ?: rawTabs.size
                        // TÍNH NĂNG MỚI (người dùng báo đúng: "tab đã nhóm
                        // kéo ra không ra khỏi nhóm được") — quy tắc đơn
                        // giản, dễ đoán: bất kỳ lượt kéo-thả đổi vị trí nào
                        // (thanh chip ngang không hỗ trợ gộp nhóm bằng kéo-
                        // thả, chỉ có ở lưới tab) đều gỡ tab khỏi nhóm hiện
                        // tại nếu có.
                        val draggedTab = rawTabs.find { it.id == draggedTabId }
                        if (draggedTab?.groupId != null) {
                            DebugLog.log("MainActivity: kéo-thả tab '$draggedTabId' RA KHỎI nhóm (groupId cũ='${draggedTab.groupId}') trên thanh chip ngang")
                            engine.setTabGroup(draggedTabId, null)
                        }
                        DebugLog.log("MainActivity: kéo-thả tab '$draggedTabId' tới vị trí $targetIndex")
                        engine.moveTab(draggedTabId, targetIndex)
                        clearChipHighlight()
                        refreshTabBar()
                        true
                    }
                    else -> true
                }
            }
            addView(tabLayout, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        toolbarContainer.addView(tabBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Nhãn LUÔN HIỂN THỊ "đang ở Khe nào / hồ sơ nào" — trước đây thông
        // tin này chỉ hiện trong tiêu đề 1 vài dialog (vd "Menu (Slot 1)"),
        // không có gì hiển thị thường trực trong lúc duyệt web, dễ nhầm
        // đang ở khe nào khi mở nhiều khe cùng lúc. Chỉ cần đọc 1 lần lúc
        // tạo UI vì việc đổi gán hồ sơ luôn khởi động lại khe (xem
        // `ProfilePickerActivity.restartSlot`), nên giá trị không đổi trong
        // suốt vòng đời Activity này.
        val slotLabel = TextView(this).apply {
            text = "Khe $slotIndex — ${ProfileSlots.getSlotAssignmentDisplay(this@MainActivity, slotIndex)}"
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#616161"))
            setPadding(16, 4, 16, 4)
        }
        toolbarContainer.addView(slotLabel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // URL + Navigation bar
        //
        // BUG THẬT đã sửa (người dùng phản ánh "icon nhí nhí khó nhấn"): các
        // nút back/forward/refresh/tab/menu trước đây có kích thước
        // `ViewGroup.LayoutParams(48, 48)` — đây là 48 PIXEL THÔ, không phải
        // 48dp! Trên màn hình mật độ điểm ảnh cao (3x, rất phổ biến) thì 48px
        // chỉ tương đương ~16dp thật — thấp hơn NHIỀU so với khuyến nghị tối
        // thiểu 48dp của Material Design cho vùng chạm ngón tay, nên khó
        // bấm trúng là đúng, không phải cảm giác. Sửa: đổi hết sang `dp(48)`
        // (hàm quy đổi theo mật độ màn hình thật), thêm đệm bên trong icon +
        // hiệu ứng gợn sóng khi chạm (giống Material/Chrome) cho dễ bấm và
        // có phản hồi rõ ràng khi chạm trúng.
        //
        // THEO YÊU CẦU: gom back/forward/refresh vào menu 3 chấm thay vì để
        // cố định trên thanh công cụ — đúng như Chrome thật làm (Chrome
        // KHÔNG có nút Back riêng trên thanh công cụ, dùng nút/vuốt Back của
        // hệ thống — app này đã tự làm đúng việc đó từ trước, xem
        // `onBackPressed()` phía dưới gọi `engine.goBack()`). Forward/Reload
        // chuyển vào `showMenu()`. Vẫn giữ nguyên các biến `backButton`/
        // `forwardButton`/`refreshButton` (không xoá) vì vài chỗ khác trong
        // file còn cập nhật trạng thái enable/alpha của chúng — chỉ không
        // gắn vào `navBar` để không chiếm chỗ trên màn hình nữa.
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            gravity = Gravity.CENTER_VERTICAL
        }

        val rippleBg = android.util.TypedValue().also {
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
        }.resourceId

        backButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.goBack() }
        }
        forwardButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.goForward() }
        }
        refreshButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_rotate)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { engine.reload() }
        }

        // Omnibox kiểu Chrome: bo tròn viên thuốc, nền xám nhạt, không viền —
        // thay vì ô nhập viền vuông mặc định trước đây. Giờ rộng hơn nhiều
        // vì không còn phải chia chỗ với 3 nút back/forward/refresh nữa.
        //
        // THEO YÊU CẦU "giống Chrome": Chrome CHỈ hiện TÊN MIỀN khi ô địa
        // chỉ KHÔNG được focus (VD "youtube.com" thay vì cả URL dài đầy
        // tham số) — bấm vào mới hiện URL ĐẦY ĐỦ để sửa, kèm chọn hết chữ
        // sẵn để gõ đè nhanh. Trước đây ô này luôn hiện URL đầy đủ, kể cả
        // lúc không bấm vào — không giống Chrome, dài dòng khó đọc.
        urlBar = EditText(this).apply {
            hint = "Tìm kiếm hoặc nhập URL"
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#F1F3F4"))
                cornerRadius = dp(24).toFloat()
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setSingleLine(true)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            /**
             * BUG THẬT (người dùng báo: "nhấn đè vào thanh url mà menu hiện
             * chỉ có mục tự động điền, còn mấy cái mục khác như sao chép,
             * cắt, dán... thì không thấy đâu"). Đã rà toàn bộ code app —
             * KHÔNG có `customSelectionActionModeCallback`/
             * `customInsertionActionModeCallback` nào bị ghi đè, không có
             * theme/style nào chỉnh `actionMode`, không có code Autofill
             * nào của app — nghĩa là app KHÔNG chủ động chặn Cut/Copy/Paste.
             * Nguyên nhân thật nhiều khả năng nhất: `inputType` có
             * `TYPE_TEXT_VARIATION_URI` khiến Android Autofill Framework
             * (dịch vụ autofill của máy — Google/Samsung Pass/trình quản lý
             * mật khẩu...) coi đây là 1 trường "giống URL đăng nhập", tự
             * CHIẾM lấy toolbar long-press để chỉ hiện gợi ý tự động điền
             * của NÓ, đè mất toolbar Cut/Copy/Paste/Chọn tất cả tiêu chuẩn
             * — đây là hành vi Autofill Framework CỦA HỆ THỐNG, không phải
             * app tự làm, nhưng CÓ CÁCH tắt được từ phía app: đặt
             * `importantForAutofill = NO` báo cho hệ thống "trường này
             * KHÔNG tham gia autofill" — CHÍNH Chrome thật cũng làm y hệt
             * cho thanh địa chỉ của nó vì đúng lý do này (autofill can
             * thiệp UX gõ URL bình thường). Không phải suy đoán vu vơ — đây
             * là API chuẩn, có chủ đích, đúng dùng cho đúng lớp vấn đề này.
             */
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    navigateToUrl(text.toString())
                    clearFocus()
                    true
                } else false
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    setText(lastLoadedUrl)
                    /**
                     * BUG THẬT (người dùng báo: "nhấn vào url ko như bên
                     * chrome tự động chọn hết toàn bộ url luôn" — dù
                     * `selectAll()` đã có sẵn ở đây từ trước): lỗi Android
                     * kinh điển — khi 1 EditText NHẬN FOCUS do người dùng
                     * CHẠM vào nó, thứ tự xử lý thật là: (1) hệ thống gọi
                     * `onFocusChangeListener` NGAY LẬP TỨC lúc bắt đầu xử lý
                     * touch-down (focus đổi trước khi chạm xong hẳn), gọi
                     * `selectAll()` ở đây → chọn hết chữ; (2) NHƯNG sự kiện
                     * touch-UP vẫn tiếp tục được xử lý SAU ĐÓ bởi chính
                     * EditText — hành vi mặc định của Android là tự đặt lại
                     * con trỏ (`setSelection`) vào ĐÚNG vị trí toạ độ vừa
                     * chạm, GHI ĐÈ mất `selectAll()` vừa gọi. Kết quả: mắt
                     * thường thấy như `selectAll()` "không có tác dụng gì".
                     * Sửa: bọc `selectAll()` trong `post{}` — đẩy việc gọi
                     * xuống SAU khi toàn bộ vòng xử lý touch (kể cả touch-up
                     * tự đặt con trỏ) đã chạy xong trong cùng khung hình,
                     * đảm bảo `selectAll()` luôn là hành động SAU CÙNG,
                     * không bị ghi đè nữa — đây là cách khắc phục chuẩn được
                     * cộng đồng Android xác nhận cho đúng lỗi timing này.
                     */
                    post { selectAll() }
                } else {
                    setText(displayHostOnly(lastLoadedUrl))
                    urlSuggestionsPopup.dismiss()
                }
            }
            /**
             * TÍNH NĂNG THIẾU (người dùng yêu cầu): "Thanh url khi gõ chữ
             * ko như chrome, hiện ra danh sách url lịch sử, url tab đang
             * mở... khi chỉ gõ vài ký tự". XÁC NHẬN đúng — trước đây urlBar
             * KHÔNG có bất kỳ TextWatcher/gợi ý nào cả, chỉ có mỗi hành vi
             * chọn hết chữ lúc focus. Thêm dropdown gợi ý: khớp TAB ĐANG MỞ
             * (ưu tiên hiện trước — bấm vào để CHUYỂN NHANH tới tab đó,
             * đúng như Chrome, không mở tab mới trùng) + LỊCH SỬ (khớp
             * host/tiêu đề, mới nhất trước). Dùng lại đúng dữ liệu có sẵn
             * (`engine.getTabs()`, `BrowserHistory.readEntries()`), không
             * cần thêm hạ tầng mới.
             */
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    if (!urlBar.hasFocus()) return // tránh tự trigger khi code TỰ set text (blur/load trang)
                    val text = s?.toString().orEmpty()
                    /**
                     * TÍNH NĂNG MỚI (người dùng yêu cầu): "nhập nhiều url
                     * thành nhiều tab, có lựa chọn bỏ vào group tab nào".
                     * Vào từ urlBar: dán 1 danh sách nhiều dòng vào đây —
                     * urlBar là ô 1 dòng nên KHÔNG đợi bấm Enter/Go (phím Go
                     * chỉ gửi được dòng cuối cùng, các dòng trước bị "nuốt"
                     * mất) — phát hiện ngay khi Editable có ký tự xuống dòng
                     * (dán xong là `afterTextChanged` chạy ngay, có 
 thật
                     * trong chuỗi dù `SingleLineTransformationMethod` hiển
                     * thị trông như 1 dòng). `post{}` để dọn field SAU khi
                     * vòng xử lý Editable hiện tại xong hẳn (sửa Editable
                     * ngay trong chính callback của nó dễ vỡ IllegalState).
                     */
                    if (text.contains("\n")) {
                        val urls = parseUrlLines(text)
                        urlSuggestionsPopup.dismiss()
                        urlBar.post {
                            urlBar.setText("")
                            when {
                                urls.size >= 2 -> showBulkGroupAssignDialog(urls)
                                urls.size == 1 -> { navigateToUrl(urls[0]); urlBar.clearFocus() }
                            }
                        }
                        return
                    }
                    updateUrlSuggestions(text)
                }
            })
        }
        urlSuggestionsPopup = android.widget.ListPopupWindow(this).apply {
            anchorView = urlBar
            width = android.widget.ListPopupWindow.MATCH_PARENT
            isModal = false
        }
        navBar.addView(urlBar, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        // BUG THẬT đã sửa (người dùng chỉ ra): "Tiến tới"/"Tải lại trang"
        // trên Chrome THẬT là ICON ngay trên thanh công cụ, KHÔNG phải dòng
        // CHỮ trong menu 3 chấm — phiên trước hiểu sai, nhét cả 2 vào
        // showMenu() dạng text. `forwardButton`/`refreshButton` (bên trên)
        // đã được TẠO SẴN đầy đủ icon từ trước nhưng chưa từng gắn vào
        // `navBar` — chỉ cần thêm vào đây, bỏ 2 dòng chữ tương ứng khỏi
        // showMenu(). Không thêm `backButton` ở đây (giữ nguyên quyết định
        // cũ) vì nút/vuốt Back hệ thống đã tự làm đúng việc đó.
        navBar.addView(forwardButton, ViewGroup.LayoutParams(dp(40), dp(40)))
        navBar.addView(refreshButton, ViewGroup.LayoutParams(dp(40), dp(40)))

        // Nút SAO bookmark nhanh 1 chạm — đã hứa "để dành lượt sau", giờ
        // làm luôn theo yêu cầu. Đổi hình đầy/rỗng theo đúng trạng thái
        // bookmark của trang ĐANG XEM, cập nhật ở `updateBookmarkButton()`
        // (gọi từ `updateOmnibox()` — cùng chỗ mọi lần URL đổi).
        bookmarkButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.btn_star_big_off)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                val url = engine.currentUrl() ?: return@setOnClickListener
                if (engine.getActiveTab()?.isPrivate == true) {
                    Toast.makeText(this@MainActivity, "Tab ẩn danh không lưu bookmark", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val title = engine.getActiveTab()?.title ?: url
                val nowBookmarked = com.colablive.keeper.core.BrowserBookmarks.toggle(this@MainActivity, slotIndex, url, title)
                updateBookmarkButton(url)
                Toast.makeText(this@MainActivity, if (nowBookmarked) "Đã thêm bookmark" else "Đã bỏ bookmark", Toast.LENGTH_SHORT).show()
            }
        }
        navBar.addView(bookmarkButton, ViewGroup.LayoutParams(dp(40), dp(40)))

        // TÍNH NĂNG MỚI (người dùng yêu cầu): nút ghim nhanh 1 chạm ngay
        // trên thanh URL — thêm/bỏ tên miền của tab ĐANG XEM khỏi danh sách
        // "chạy nền" của `BackgroundKeepAliveFeature`, không cần vào tận
        // Cài đặt gõ tay. Đổi hình ghim đầy/rỗng theo đúng trạng thái, cập
        // nhật ở `updatePinButton()` (gọi từ `updateOmnibox()` — cùng chỗ
        // `updateBookmarkButton()` đã làm cho nút sao).
        pinButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_myplaces)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                val url = engine.currentUrl() ?: return@setOnClickListener
                val host = try { android.net.Uri.parse(url).host } catch (e: Exception) { null }
                if (host.isNullOrBlank()) return@setOnClickListener
                val nowPinned = !com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.isDomainPinned(this@MainActivity, slotIndex, host)
                if (nowPinned) {
                    com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.addDomain(this@MainActivity, slotIndex, host)
                } else {
                    com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.removeDomain(this@MainActivity, slotIndex, host)
                }
                updatePinButton(url)
                // FIX BUG THẬT (ghim chạy nền không thật sự chạy nền khi
                // tắt màn hình — xem chú thích đầy đủ ở
                // `refreshKeepAliveServiceState()`): mỗi khi trạng
                // thái ghim đổi, khởi động/dừng đúng foreground service
                // thật ngay lập tức — không đợi tới onPause() mới xử lý,
                // để service đã chạy sẵn kịp thời trước khi có khả năng
                // người dùng tắt màn hình ngay sau khi vừa ghim.
                refreshKeepAliveServiceState()
                // FIX ĐỒNG BỘ (người dùng yêu cầu): 3 chỗ liên quan "chạy
                // nền" (nút ghim đơn trên thanh URL, lưới nhiều tab, Cài
                // đặt) đều đọc/ghi CHUNG 1 nguồn dữ liệu duy nhất
                // (`BackgroundKeepAliveFeature` → 1 key AppPrefs) — không
                // có 3 bản sao rời rạc để lệch nhau. Cái CÒN THIẾU chỉ là
                // GỌI LẠI đúng hàm "vẽ lại" của 2 chỗ kia ngay sau khi 1
                // chỗ vừa đổi dữ liệu — ở đây: nếu lưới nhiều tab đang mở
                // cùng lúc (ít khi xảy ra vì đây là dialog riêng, nhưng
                // vẫn gọi cho chắc, vô hại nếu null/không mở), làm nó vẽ
                // lại ngay để huy hiệu ghim trên card tab cùng domain này
                // hiện đúng NGAY, không cần đóng mở lại lưới mới thấy.
                activeTabSwitcherRefresh?.invoke()
                Toast.makeText(
                    this@MainActivity,
                    if (nowPinned) "Đã ghim '$host' — chạy nền khi chuyển tab khác" else "Đã bỏ ghim '$host'",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        navBar.addView(pinButton, ViewGroup.LayoutParams(dp(40), dp(40)))

        newTabButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_input_add)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
            }
        }
        navBar.addView(newTabButton, ViewGroup.LayoutParams(dp(48), dp(48)))

        // Nút "N tab" kiểu Chrome — bấm mở lưới xem/chuyển/đóng tab, thay
        // vì phải cuộn dải chip ngang khi có nhiều tab.
        tabSwitcherButton = TextView(this).apply {
            text = "1"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            background = android.graphics.drawable.GradientDrawable().apply {
                setStroke(dp(2), Color.DKGRAY)
                cornerRadius = dp(6).toFloat()
            }
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, rippleBg)
            setOnClickListener { showTabSwitcher() }
        }
        // BUG BUILD đã sửa: `ViewGroup.LayoutParams` (lớp cha) KHÔNG có
        // marginStart/marginEnd — chỉ `ViewGroup.MarginLayoutParams` (và các
        // lớp con như `LinearLayout.LayoutParams`) mới có. Trước đây viết
        // nhầm `ViewGroup.LayoutParams` ở đây → "Unresolved reference" lúc
        // build. navBar là LinearLayout nên đổi đúng sang `LinearLayout.LayoutParams`.
        navBar.addView(tabSwitcherButton, LinearLayout.LayoutParams(dp(40), dp(40)).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })

        menuButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_more)
            setBackgroundResource(rippleBg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { showMenu() }
        }
        navBar.addView(menuButton, ViewGroup.LayoutParams(dp(48), dp(48)))

        toolbarContainer.addView(navBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        /**
         * TÍNH NĂNG MỚI (người dùng yêu cầu): nút bật/tắt nhanh Colab Live —
         * chỉ hiện khi trang hiện tại là colab.research.google.com, để
         * người dùng chủ động bật `KeepAliveService` (giữ WakeLock + hiện
         * đồng hồ đếm thời gian trên thanh thông báo — xem KeepAliveService)
         * ngay khi bắt đầu chạy notebook, thay vì phải tự đoán/vào Cài đặt.
         * Ẩn hẳn (View.GONE) khi không ở trang Colab để không chiếm chỗ vô
         * ích ở các trang khác — cập nhật trạng thái ẩn/hiện + màu trong
         * `updateOmnibox()` mỗi khi điều hướng.
         */
        colabLiveButton = Button(this).apply {
            textSize = 11f
            setPadding(dp(8), dp(2), dp(8), dp(2))
            visibility = View.GONE
            setOnClickListener {
                val isOn = com.colablive.keeper.core.AppPrefs.getBoolean(this@MainActivity, slotIndex, "colablive_keepalive_on", false)
                if (isOn) {
                    // FIX ĐỐI XỨNG (xem chú thích đầy đủ ở
                    // `refreshKeepAliveServiceState()`): TRƯỚC ĐÂY
                    // dừng `KeepAliveService` VÔ ĐIỀU KIỆN khi tắt Colab
                    // Live — nếu lúc đó CŨNG có ít nhất 1 tab đang ghim
                    // chạy nền, sẽ giết NHẦM service mà tính năng ghim vẫn
                    // đang cần. Chỉ dừng khi KHÔNG còn tab nào ghim nữa.
                    val anyTabPinned = engine.getTabs().any { tab ->
                        val h = try { android.net.Uri.parse(tab.url).host } catch (e: Exception) { null }
                        h != null && com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.isDomainPinned(this@MainActivity, slotIndex, h)
                    }
                    if (!anyTabPinned) {
                        KeepAliveService.stop(this@MainActivity, slotIndex)
                    }
                    // Chỉ tắt priority hint nếu Auto Behavior không được BẬT
                    // RIÊNG từ trước (Cài đặt > Tính năng) — không tắt nhầm
                    // 1 tính năng người dùng đã tự bật độc lập với nút này.
                    val autoBehaviorWasOnBefore = com.colablive.keeper.core.AppPrefs.getBoolean(this@MainActivity, slotIndex, "colablive_button_enabled_auto_behavior", false)
                    if (autoBehaviorWasOnBefore) {
                        com.colablive.keeper.core.AppPrefs.setBoolean(this@MainActivity, slotIndex, "auto_behavior", false)
                        engine.stopAutoBehavior()
                        com.colablive.keeper.core.AppPrefs.setBoolean(this@MainActivity, slotIndex, "colablive_button_enabled_auto_behavior", false)
                    }
                    com.colablive.keeper.core.AppPrefs.setBoolean(this@MainActivity, slotIndex, "colablive_keepalive_on", false)
                    Toast.makeText(this@MainActivity, "Đã tắt Colab Live", Toast.LENGTH_SHORT).show()
                } else {
                    KeepAliveService.start(this@MainActivity, slotIndex, "Người dùng bấm nút Colab Live trong toolbar (bật)")
                    // BUG THẬT đã tìm và sửa trước đây (xem PROJECT_STATUS.md
                    // mục 8zm/8zzu, comment ở GeckoViewEngine.startAutoBehavior):
                    // setPriorityHint(PRIORITY_HIGH) giữ tiến trình con Gecko
                    // KHÔNG bị hạ ưu tiên khi mất surface (tắt màn hình) CHỈ áp
                    // dụng khi có media phát HOẶC Auto Behavior đang bật —
                    // KHÔNG tự động bật chỉ vì đang ở trang Colab. Nút này phải
                    // tự bật luôn "auto_behavior" (nếu người dùng chưa bật sẵn)
                    // để tab Colab thật sự được nâng PRIORITY_HIGH, không chỉ
                    // có WakeLock (WakeLock giữ CPU thức nhưng KHÔNG ngăn được
                    // GeckoView tự hạ ưu tiên tiến trình con của riêng nó).
                    val autoBehaviorAlreadyOn = com.colablive.keeper.core.AppPrefs.getBoolean(this@MainActivity, slotIndex, "auto_behavior", false)
                    if (!autoBehaviorAlreadyOn) {
                        com.colablive.keeper.core.AppPrefs.setBoolean(this@MainActivity, slotIndex, "auto_behavior", true)
                        engine.startAutoBehavior()
                        com.colablive.keeper.core.AppPrefs.setBoolean(this@MainActivity, slotIndex, "colablive_button_enabled_auto_behavior", true)
                    }
                    com.colablive.keeper.core.AppPrefs.setBoolean(this@MainActivity, slotIndex, "colablive_keepalive_on", true)
                    Toast.makeText(this@MainActivity, "Đã bật Colab Live — xem đồng hồ đếm trên thanh thông báo", Toast.LENGTH_LONG).show()
                }
                refreshColabLiveButton()
            }
        }
        toolbarContainer.addView(colabLiveButton, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)))

        // Progress bar
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        toolbarContainer.addView(progressBar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4))

        root.addView(toolbarContainer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Bóng đổ mỏng dưới toolbar — Chrome dùng elevation thật (Material)
        // để tạo cảm giác toolbar "nổi" trên nội dung trang, không phải chỉ
        // đường viền phẳng. Không set màu status bar tối ở đây vì theme mặc
        // định của Activity đã đủ dùng, tránh đụng vào theme toàn app.
        toolbarContainer.elevation = dp(4).toFloat()
        window.statusBarColor = Color.parseColor("#F8F9FA")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }

        // TÍNH NĂNG MỚI (người dùng yêu cầu) — thanh "Tìm trong trang",
        // giống Chrome/Ctrl+F. Đặt NGAY TRÊN geckoView (dưới toolbar) —
        // không dùng Dialog nổi vì Chrome thật để thanh này dính liền vào
        // layout, không che khuất phần trên cùng trang đang xem. Mặc định
        // GONE — chỉ hiện khi `showFindInPageBar()` được gọi từ menu.
        findBarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setBackgroundColor(Color.parseColor("#F1F3F4"))
            visibility = View.GONE
            elevation = dp(2).toFloat()
        }
        findBarInput = EditText(this).apply {
            hint = "Tìm trong trang..."
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            // Tìm NGAY khi gõ (giống Chrome — không cần bấm Enter), nhưng
            // debounce nhẹ 200ms để không gọi find() dồn dập mỗi ký tự gõ
            // nhanh (find() chạy qua GeckoResult — gọi liên tục vẫn AN
            // TOÀN vì lệnh sau luôn ghi đè kết quả lệnh trước, nhưng
            // debounce đỡ tốn native call vô ích).
            var debounceRunnable: Runnable? = null
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    debounceRunnable?.let { handler.removeCallbacks(it) }
                    val query = s?.toString() ?: ""
                    val runnable = Runnable { performFindInPage(query, forward = true) }
                    debounceRunnable = runnable
                    handler.postDelayed(runnable, 200L)
                }
            })
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                    performFindInPage(text.toString(), forward = true)
                    true
                } else false
            }
        }
        findBarContainer.addView(findBarInput)
        findBarCounter = TextView(this).apply {
            text = ""
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(dp(8), 0, dp(8), 0)
        }
        findBarContainer.addView(findBarCounter)
        findBarContainer.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.arrow_up_float)
            setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Tìm lùi"
            setOnClickListener { performFindInPage(findBarInput.text.toString(), forward = false) }
        }, ViewGroup.LayoutParams(dp(40), dp(40)))
        findBarContainer.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.arrow_down_float)
            setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Tìm tiếp"
            setOnClickListener { performFindInPage(findBarInput.text.toString(), forward = true) }
        }, ViewGroup.LayoutParams(dp(40), dp(40)))
        findBarContainer.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Đóng tìm kiếm"
            setOnClickListener { hideFindInPageBar() }
        }, ViewGroup.LayoutParams(dp(40), dp(40)))
        root.addView(findBarContainer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // GeckoView
        geckoView = GeckoView(this)
        root.addView(geckoView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        /**
         * LỊCH SỬ (xem comment dài trong AndroidManifest.xml — cùng 1 bug):
         * đã thử 3 phương án cho việc bàn phím che khung chat khi gõ vào ô
         * nhập của trang web. Chỉ CÓ 1 phương án từng được xác nhận đúng
         * bằng ảnh chụp/test thật: `android:windowSoftInputMode="adjustResize"`
         * khai báo ở Manifest (KHÔNG cần code Kotlin nào thêm — bản thân
         * adjustResize đã tự co state cửa sổ, LinearLayout `root` có
         * `geckoView` weight=1 sẽ tự co theo, không cần tự tính padding
         * IME thủ công). 2 phương án sau (đổi sang adjustNothing + tự
         * padding, rồi tháo padding dựa vào Bugzilla #1920755) đều CHỈ LÀ
         * SUY ĐOÁN chưa từng build/test thật, và người dùng xác nhận bằng
         * test thật là bản mới nhất làm MẤT LUÔN fix gốc (bàn phím che lại
         * khung chat). Đã PHỤC HỒI adjustResize ở Manifest.
         *
         * Phần dưới đây CHỈ còn xử lý padding TOP cho status bar (không
         * liên quan gì IME/bàn phím) — vẫn cần vì `setDecorFitsSystemWindows(false)`
         * khiến app vẽ tràn lên vùng status bar.
         *
         * CẢNH BÁO CHO LẦN SAU (tra cứu chính thức từ Android Developers,
         * bài "Insets handling tips for Android 15's edge-to-edge
         * enforcement"): hành vi tự động pad root view của `adjustResize`
         * khi kết hợp `setDecorFitsSystemWindows(false)` CHỈ đúng khi
         * `targetSdk` < 35 (dự án hiện đang `targetSdk 34`, `compileSdk 36`
         * — xem app/build.gradle). Từ targetSdk 35 trở lên, framework
         * KHÔNG còn tự pad nữa — nếu sau này bump targetSdk lên 35+ mà
         * không kiểm tra lại, bug bàn phím che khung chat sẽ TÁI PHÁT, và
         * lúc đó bắt buộc phải tự thêm `ViewCompat.setOnApplyWindowInsetsListener`
         * đọc `WindowInsetsCompat.Type.ime()` để tự pad thủ công (đây mới
         * là lúc cách làm ở lượt sửa (a)/(b) trước đó mới thật sự cần
         * thiết — chỉ là bị áp dụng NHẦM THỜI ĐIỂM, khi targetSdk còn là
         * 34 thì chưa cần).
         *
         * SỬA LẦN 4 (người dùng xác nhận qua ảnh chụp thật: bàn phím VẪN
         * che khung chat dù đã "phục hồi adjustResize" — giả định ở đoạn
         * trên rằng targetSdk<35 thì KHÔNG cần tự pad IME hoá ra SAI hoặc
         * KHÔNG ĐỦ trong thực tế build/test này): tra cứu lại, tìm được
         * nguồn khác — thảo luận Kotlin Slack #compose-android có kỹ sư
         * AndroidX/Google (Alex Vanyo) xác nhận trực tiếp: "If you are
         * using setDecorFitsSystemWindows(window, false) and adjustResize
         * ... you'll need to apply the imePadding ... so that the size of
         * the container changes" — không giới hạn theo targetSdk nào cả.
         * Tức 1 khi ĐÃ gọi `setDecorFitsSystemWindows(false)` (dòng ngay
         * dưới đây), app đã lấy toàn bộ trách nhiệm xử lý inset — bao gồm
         * CẢ IME — từ hệ thống, bất kể targetSdk bao nhiêu. Đã thêm lại
         * padding IME thủ công (khác bản (b) cũ ở chỗ: CHỈ pad đúng 1 lớp
         * ở view `root` này, không đụng gì thêm ở nơi khác — tránh lặp lại
         * kiểu lỗi "chồng padding 2 lớp" mà bản (b) có thể đã mắc phải,
         * dù không còn bằng chứng cụ thể bản (b) sai chỗ nào vì code đó đã
         * bị xoá từ lâu). Đã thêm log chẩn đoán đầy đủ ngay dưới để lần
         * test tới có bằng chứng thật (imeVisible, imeBottom px, chiều cao
         * view) thay vì phải đoán tiếp nếu vẫn còn lỗi.
         */
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        }
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val systemBarsInset = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            val imeInset = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime())
            val imeVisible = insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.ime())
            /**
             * SỬA LẦN 6 — ĐẢO LẠI "SỬA LẦN 5" (mục 69.1 PROJECT_STATUS.md), có bằng
             * chứng log thật thay vì suy luận:
             *
             * 1) BẰNG CHỨNG `adjustResize` KHÔNG CÒN TÁC DỤNG: dòng log
             *    "[CHẨN ĐOÁN bàn phím]" cho thấy `rootHeight=2400px` KHÔNG ĐỔI
             *    dù `imeVisible=true imeBottom=949..1046px`. Nếu `adjustResize`
             *    còn co cửa sổ thì `root` phải ngắn đi ~1000px. Nguyên nhân:
             *    dòng `window.setDecorFitsSystemWindows(false)` ngay phía trên
             *    (thêm ở lượt 8zz-ee, chưa bao giờ gỡ) chuyển toàn bộ trách
             *    nhiệm inset (kể cả IME) sang app — `adjustResize` một mình
             *    KHÔNG làm gì nữa. Bản "lần 5" bỏ pad IME nên bàn phím đè lên
             *    ô chat (đúng triệu chứng người dùng báo).
             *
             * 2) BẰNG CHỨNG "bàn phím rớt" KHÔNG DO pad IME: bản "lần 5" đã
             *    bỏ pad IME mà log VẪN cho thấy imeVisible true→false→true
             *    liên tục mỗi ~10s. Thủ phạm thật là vòng lặp Auto Behavior
             *    (`GeckoViewEngine.startAutoBehavior`): nhân bản mỗi lần load
             *    trang, gọi `.focus()` sang nút đầu tiên của trang → Gecko ẩn
             *    bàn phím. Đã sửa ở đó. Vì vậy pad IME ở đây là ĐÚNG và cần.
             *
             * Pad bottom = max(IME, thanh điều hướng): khi bàn phím ẩn thì
             * chừa chỗ cho thanh điều hướng (trước đây nội dung chui xuống
             * dưới nó vì đã tắt decorFitsSystemWindows), khi hiện thì
             * `imeInset.bottom` đã bao gồm luôn phần thanh điều hướng.
             * `insets` trả về NGUYÊN VẸN (không tiêu thụ) — đúng như bản "lần
             * 4" người dùng từng xác nhận hết che khung chat.
             */
            val navInset = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.navigationBars())
            val bottomPad = maxOf(imeInset.bottom, navInset.bottom)
            imeVisibleNow = imeVisible
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN bàn phím] insets đổi — imeVisible=$imeVisible imeBottom=${imeInset.bottom}px navBottom=${navInset.bottom}px systemBarsTop=${systemBarsInset.top}px rootHeight=${view.height}px → padBottom=${bottomPad}px")
            view.setPadding(0, systemBarsInset.top, 0, bottomPad)
            insets
        }


        setContentView(root)
    }

    // FIX BUG THẬT NGHIÊM TRỌNG (xem giải thích đầy đủ ở `GeckoViewEngine.
    // rebindView()`) — cờ này cho `onCreate()` biết `setupEngine()` vừa
    // GẮN LẠI vào 1 engine đã sống sẵn (không phải tạo mới), để bỏ qua
    // hẳn bước `restoreTabsIfAny()`/tạo tab trang chủ bên dưới — tab đã có
    // sẵn, đụng vào chỉ tổ tải lại từ đầu.
    private var reusedExistingEngine = false

    private fun setupEngine() {
        val existing = GeckoViewEngine.forSlot(slotIndex)
        if (existing != null) {
            DebugLog.log("Khe $slotIndex: TÌM THẤY engine đang sống trong tiến trình (Activity vừa bị Android tự huỷ+tạo lại, KHÔNG phải mở mới thật) — gắn lại vào GeckoView mới, KHÔNG tải lại tab nào cả")
            existing.rebindView(geckoView)
            engine = existing
            reusedExistingEngine = true
        } else {
            engine = GeckoViewEngine(this, geckoView, slotIndex)
            reusedExistingEngine = false
        }
        engine.userInteractionGuard = { userIsInteracting() }
        selectionFallback = SelectionFallbackMenu(this, geckoView) { engine }
        updateNavButtons() // trạng thái mờ/đậm đúng ngay từ đầu, trước khi có sự kiện điều hướng đầu tiên (tab mới thường canGoBack/Forward đều false)
        updatePrivateModeUI() // màu toolbar mặc định đúng ngay từ đầu (chưa có tab nào thì coi như không ẩn danh)

        // FIX BUG THẬT (xem chú thích chi tiết ở GeckoSession.ContentDelegate.
        // onFullScreen — GeckoViewEngine.kt): trước đây callback này CHƯA
        // TỪNG được cài — nhấn nút toàn màn hình trên player, GeckoView có
        // báo hiệu nhưng KHÔNG CÓ AI xử lý để ẩn thanh URL/dải tab của
        // CHÍNH app đi, nên video "fullscreen" thật ra vẫn bị ép trong
        // phần khung còn lại của trang → nhìn như méo/"vướng url". Sửa: ẩn
        // hẳn toolbarContainer + vào chế độ immersive khi vào fullscreen,
        // khôi phục lại khi thoát — đúng như javadoc chính thức Mozilla
        // khuyến nghị ("implementation would set the Activity... to full
        // screen").
        engine.onFullScreenListener = { fullScreen ->
            if (fullScreen) {
                toolbarContainer.visibility = View.GONE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
            } else {
                toolbarContainer.visibility = View.VISIBLE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                // Zoom đã bị TẮT HẲN lúc vào fullscreen (xem onFullScreen ở
                // GeckoViewEngine) — tính lại đúng zoom cho tab hiện tại.
                engine.reapplyZoomForActiveTab()
            }
        }

        engine.onPageStartedListener = {
            // Cho tab bar biết NGAY để vẽ spinner "đang tải" — xem chú
            // thích đầy đủ ở khai báo `onPageStartedListener` trong
            // GeckoViewEngine.kt.
            refreshTabBar()
        }

        engine.onPageLoadedListener = { url ->
            updateOmnibox(url)
            updateNavButtons()
            ForegroundState.broadcastActiveSlot(this, slotIndex, url)
            // Tab ẨN DANH không ghi lịch sử — đúng hành vi Chrome thật.
            if (engine.getActiveTab()?.isPrivate != true) {
                engine.recordHistoryVisit(url)
            }
            fetchFaviconForActiveTab(url) // xem chú thích ở hàm — BUG GỐC khiến mọi tab hiện icon chấm xanh giống hệt nhau
            // Vẽ lại NGAY để spinner "đang tải" biến mất đúng lúc trang
            // xong — không đợi favicon tải xong (favicon là HTTP request
            // riêng, có thể chậm hơn/lỗi độc lập, không nên khoá icon báo
            // "đã tải xong trang" vào đó).
            refreshTabBar()
            FeatureRegistry.enabledFeatures(this, slotIndex).forEach {
                it.onPageFinished(this, slotIndex, engine, url)
            }
        }

        engine.onPageErrorListener = { url, code ->
            DebugLog.log("Page error: $url code=$code")
        }

        engine.onTitleChangedListener = { title ->
            updateTabTitle(title)
            if (engine.getActiveTab()?.isPrivate != true) {
                engine.currentUrl()?.let { engine.updateLastHistoryTitle(it, title) }
            }
        }

        engine.onProgressChangedListener = { progress ->
            progressBar.progress = progress
            progressBar.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
        }

        engine.onNewTabRequestedListener = { url ->
            // Không tự tạo tab nữa — GeckoViewEngine.onNewSession() giờ đã
            // tự tạo VÀ đăng ký đúng tab cho popup (kèm session THẬT, có
            // window.opener hoạt động — xem giải thích lớn ở đó, sửa lỗi
            // "credential propagation unsuccessful" của Colab). Gọi
            // `createTab()` thêm ở đây sẽ tạo ra 1 tab THỨ HAI trùng lặp,
            // không có window.opener, cùng URL — chỉ cần vẽ lại thanh tab.
            refreshTabBar()
        }

        engine.onTabSwitchedListener = {
            updateOmnibox(engine.currentUrl() ?: "")
            updateNavButtons()
            refreshTabBar()
            updatePrivateModeUI()
            // BUG THẬT (người dùng báo favicon vẫn chấm xanh dù đã có logic
            // tải favicon) — `fetchFaviconForActiveTab()` CHỈ được gọi từ
            // `onPageLoadedListener`, tức là chỉ chạy khi GeckoView bắn sự
            // kiện "trang tải xong" cho 1 lượt ĐIỀU HƯỚNG THẬT. Tab được
            // khôi phục qua `session.restoreState()` (xem
            // `GeckoViewEngine.switchToTab()`/`createTabWithState()`) không
            // đảm bảo bắn lại đúng sự kiện đó như tải trang mới — tab đó có
            // thể VĨNH VIỄN không bao giờ được kích hoạt tải favicon, kể cả
            // sau khi đã hiển thị xong nội dung. Thêm lưới an toàn: mỗi lần
            // chuyển tab, nếu tab đang active CHƯA có favicon, chủ động
            // gọi lại (chỉ 1 chuỗi thử — hàm tự có cơ chế thử lại riêng).
            val active = engine.getActiveTab()
            if (active != null && active.favicon == null && active.url.isNotBlank() && active.url != "about:blank") {
                fetchFaviconForActiveTab(active.url)
            }
        }

        engine.onLongPressLinkListener = { uri, text ->
            runOnUiThread { showLinkContextMenu(uri, text) }
        }

        engine.onDownloadRequestedListener = { url, fileName ->
            val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
            downloadFeature?.startDownloadWithPolicy(this, url, fileName)
        }

        /**
         * Xem chú thích lớn ở `GeckoViewEngine.onDownloadStartedListener` —
         * bắn NGAY khi bắt đầu tải ngầm (trước khi drain xong), để hỏi
         * SaveLocationDialog SONG SONG với việc tải, thay vì bắt người dùng
         * chờ tải xong hẳn mới được hỏi (khác Chrome — người dùng chỉ ra
         * đúng, đã sửa lại cho khớp).
         */
        engine.onDownloadStartedListener = { url, fileName ->
            runOnUiThread {
                val pending = PendingBgDownload()
                pendingBgDownloads[url] = pending
                val suggestedName = fileName
                SaveLocationDialog(this).show(url, suggestedName) { result ->
                    pending.saveResult = result
                    pending.dialogDone = true
                    maybeFinalizeBgDownload(url)
                }
            }
        }

        // TÍNH NĂNG MỚI (người dùng hỏi: "cài extension từ URL có làm giống
        // Firefox/Chrome — vào trang store rồi tải về dùng được không?") —
        // xem giải thích đầy đủ ở `GeckoViewEngine.handleExtensionDownloadResponse()`.
        // Chỉ cần báo kết quả bằng Toast ở đây, việc tải + gọi
        // `webExtensionController.install()` + lưu vào danh sách addon đã
        // cài đều đã làm xong bên trong engine.
        engine.onAddonInstallResultListener = { success, name, error ->
            runOnUiThread {
                if (success) {
                    Toast.makeText(this, "Đã cài addon: ${name ?: "(không rõ tên)"}", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Cài addon thất bại: ${error ?: "không rõ lỗi"}", Toast.LENGTH_LONG).show()
                }
            }
        }

        /**
         * Xem chú thích lớn ở `GeckoViewEngine.onDownloadBodyReadyListener`
         * — bản sửa gốc cho bug "download kẹt vài trăm byte" (file cần
         * đăng nhập, VD export claude.ai). Giờ CHỈ còn nhiệm vụ lưu lại
         * đường dẫn file đã drain xong — việc hỏi tên/nơi lưu đã chuyển
         * sang chạy SONG SONG ở `onDownloadStartedListener` phía trên, kết
         * quả cuối cùng được ghép lại ở `maybeFinalizeBgDownload()`.
         */
        engine.onDownloadBodyReadyListener = { url, fileName, tempFilePath ->
          runOnUiThread {
            val pending = pendingBgDownloads.getOrPut(url) { PendingBgDownload() }
            if (tempFilePath != null && java.io.File(tempFilePath).let { it.exists() && it.length() > 0 }) {
                pending.tempFilePath = tempFilePath
                pending.drainDone = true
                maybeFinalizeBgDownload(url)
            } else {
                // File tạm rỗng/không tồn tại (drain lỗi) — huỷ luôn phần
                // dialog đang chờ (nếu có) và fallback về luồng cũ (đúng
                // cho file công khai, KHÔNG đúng cho file cần đăng nhập —
                // nhưng còn hơn không làm gì).
                pendingBgDownloads.remove(url)
                val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                downloadFeature?.startDownloadWithPolicy(this, url, fileName)
            }
          }
        }

        engine.onFilePromptListener = { mimeTypes, isMultiple ->
            // Xem chú thích đầy đủ ở `setupDragDrop()` (nhánh ACTION_DROP):
            // nếu FilePrompt này bắn ra trong vòng vài giây sau 1 lượt
            // kéo-thả, RẤT CÓ THỂ chính là Gecko đang cần app resolve hộ
            // URI của file VỪA THẢ (theo javadoc chính thức
            // `FilePrompt.confirm()` — "passes the file URI back to
            // content") — dùng THẲNG URI đó, không mở lại picker bắt chọn
            // lần 2 (đó là lý do kéo-thả "không có tác dụng" từ góc nhìn
            // người dùng). Giới hạn cửa sổ 8s (rộng hơn thời gian giữ quyền
            // 6s ở setupDragDrop 1 chút) để không lỡ nhận nhầm 1 FilePrompt
            // không liên quan (VD người dùng bấm nút "Chọn file" thường sau
            // khi vừa kéo-thả xong việc khác) là do vừa thả.
            val droppedUris = lastDroppedFileUris
            val droppedRecently = droppedUris.isNotEmpty() &&
                System.currentTimeMillis() - lastDroppedFileUriTime < 8000L
            if (droppedRecently) {
                lastDroppedFileUris = emptyList()
                DebugLog.log("Khe $slotIndex: FilePrompt (mimeTypes=${mimeTypes?.joinToString(",")}, isMultiple=$isMultiple) tự resolve bằng ${droppedUris.size} URI vừa kéo-thả ($droppedUris), KHÔNG mở lại file picker")
                Thread {
                    // FIX BUG THẬT (đúng người dùng báo, tiếp tục từ chú
                    // thích lớn ở GeckoViewEngine.onFilePromptListener): copy
                    // TẤT CẢ file đã thả (không chỉ file đầu), rồi dùng
                    // `resolveFilePromptMultiple()` (overload Uri[] — xác
                    // nhận có thật qua Javadoc chính thức GeckoView) để trả
                    // ĐỦ file cho trang, thay vì luôn chỉ trả 1 file.
                    val safeUris = droppedUris.mapNotNull { copyToAppStorageAsFileProviderUri(it) }
                    DebugLog.log("Khe $slotIndex: kéo-thả — copy xong ${safeUris.size}/${droppedUris.size} file (thiếu nghĩa là 1 vài file copy lỗi, rơi về mở picker thường nếu KHÔNG file nào copy được)")
                    runOnUiThread {
                        if (safeUris.isNotEmpty()) {
                            engine.resolveFilePromptMultiple(this, safeUris.toTypedArray())
                        } else {
                            // Copy thất bại (VD quyền đã hết hạn) — rơi về
                            // đúng luồng cũ, ít nhất người dùng vẫn chọn
                            // được file theo cách thủ công thay vì bị kẹt.
                            showFilePicker(mimeTypes, isMultiple)
                        }
                    }
                }.start()
            } else {
                showFilePicker(mimeTypes, isMultiple)
            }
        }

        startFeatureTickLoop()
    }

    /**
     * Vòng lặp tick 60s/lần cho các feature cần hành vi định kỳ (vd Colab Live
     * Keeper chế độ DOM — bấm nút Connect lại). Trước đây `onTick` được viết
     * đầy đủ trong ColabLiveKeeperFeature nhưng KHÔNG CÓ GÌ GỌI TỚI NÓ, nên
     * chế độ DOM (mặc định) không có tác dụng gì dù đã bật switch trong Settings.
     */
    private val featureTickRunnable = object : Runnable {
        override fun run() {
            FeatureRegistry.enabledFeatures(this@MainActivity, slotIndex).forEach {
                it.onTick(this@MainActivity, slotIndex, engine, engine.currentUrl())
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun startFeatureTickLoop() {
        handler.removeCallbacks(featureTickRunnable)
        handler.postDelayed(featureTickRunnable, 60_000L)
    }

    private fun navigateToUrl(input: String) {
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            // BUG THẬT (người dùng báo: "gõ about:config vào thanh URL thì
            // nó hiện ra trang Google tìm kiếm") — trước đây chỉ nhận diện
            // URL thật khi bắt đầu bằng http(s):// hoặc có dấu "." (kiểu
            // "example.com"); "about:config" không khớp cả 2 điều kiện đó
            // (không có dấu "." nào) nên rơi thẳng xuống nhánh cuối, bị coi
            // là 1 câu tìm kiếm Google bình thường. Thêm nhận diện riêng
            // cho tiền tố "about:" (about:config, about:blank, about:cache,
            // about:addons, about:debugging, about:crashes, about:memory,
            // v.v. — đều là các trang nội bộ hợp lệ của Gecko, đã bật
            // `aboutConfigEnabled(true)` từ trước nên load được thật).
            input.startsWith("about:") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}"
        }
        lastLoadedUrl = url // cập nhật lạc quan — tránh omnibox nháy về domain CŨ 1 nhịp khi mất focus trước lúc trang mới load xong
        engine.loadUrl(url)
    }

    private fun updateNavButtons() {
        backButton.isEnabled = engine.canGoBack()
        backButton.alpha = if (engine.canGoBack()) 1f else 0.3f
        forwardButton.isEnabled = engine.canGoForward()
        forwardButton.alpha = if (engine.canGoForward()) 1f else 0.3f
    }

    private fun updateTabTitle(title: String) {
        // Tiêu đề chỉ đổi cho tab đang active — vẽ lại cả thanh tab cho đơn giản
        // và luôn nhất quán (số lượng tab thường nhỏ, chi phí không đáng kể).
        refreshTabBar()
    }

    /**
     * Vẽ lại toàn bộ thanh tab từ danh sách tab thật của engine.
     * Trước đây thanh tab được khai báo nhưng KHÔNG BAO GIỜ có view nào được
     * thêm vào `tabContainer` — tạo tab mới không hiện gì, không bấm chuyển
     * được. Đây là hàm khắc phục, gọi lại mỗi khi danh sách/tab active/tiêu
     * đề thay đổi.
     */
    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu) — ảnh thu nhỏ thật của tab. Chụp
     * ảnh tab ĐANG hiển thị (nếu khác tab đích) TRƯỚC KHI chuyển, rồi mới
     * gọi `engine.switchToTab()`. Dùng hàm này ở MỌI nơi UI hiện đang gọi
     * `engine.switchToTab()` trực tiếp (chip tab, lưới tab...) để luôn có
     * ảnh mới nhất trước khi rời tab.
     *
     * `capturePixels()` chỉ hoạt động khi GeckoSession đã sẵn sàng render
     * (`isCompositorReady`) — nếu chưa sẵn sàng (VD tab vừa tạo, chưa vẽ
     * khung hình nào) sẽ trả về lỗi qua GeckoResult — bắt lỗi và bỏ qua
     * (giữ ảnh cũ nếu có, không có thì card chỉ hiện chữ như trước đây).
     */
    private fun switchToTabCapturingThumbnail(targetTabId: String) {
        val currentTab = engine.getActiveTab()
        if (currentTab != null && currentTab.id != targetTabId && ::geckoView.isInitialized) {
            try {
                geckoView.capturePixels().accept({ bitmap ->
                    if (bitmap != null) {
                        try {
                            val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, 200, 120, true)
                            tabThumbnails[currentTab.id] = scaled
                        } catch (e: Exception) {
                            DebugLog.log("switchToTabCapturingThumbnail: lỗi resize ảnh thu nhỏ cho tab ${currentTab.id} — ${e.message}")
                        }
                    }
                }, { error ->
                    DebugLog.log("switchToTabCapturingThumbnail: capturePixels() lỗi cho tab ${currentTab.id} (bình thường nếu tab chưa từng vẽ khung hình nào) — ${error?.message}")
                })
            } catch (e: Exception) {
                DebugLog.log("switchToTabCapturingThumbnail: gọi capturePixels() ném exception — ${e.message}")
            }
        }
        engine.switchToTab(targetTabId)
    }

    private fun refreshTabBar() {
        tabContainer.removeAllViews()
        tabViews.clear()
        val activeId = engine.getActiveTab()?.id
        val tabs = engine.getTabs()
        val ordered = orderedTabsWithGroupHeaders(tabs).map { it.first }
        var i = 0
        while (i < ordered.size) {
            val tab = ordered[i]
            val gid = tab.groupId
            if (gid != null) {
                val group = engine.getGroups().find { it.id == gid }
                // Gom hết các tab LIỀN KỀ cùng nhóm (đã được xếp liền
                // nhau sẵn bởi orderedTabsWithGroupHeaders ở trên).
                val block = mutableListOf(tab)
                var j = i + 1
                while (j < ordered.size && ordered[j].groupId == gid) {
                    block.add(ordered[j])
                    j++
                }
                if (group != null && gid in collapsedGroupIds) {
                    tabContainer.addView(createGroupPillChip(group, block.size))
                } else if (group != null) {
                    tabContainer.addView(createGroupChipCluster(group, block, activeId))
                } else {
                    block.forEach { t ->
                        val chip = createTabChip(t, t.id == activeId)
                        tabViews[t.id] = chip
                        tabContainer.addView(chip)
                    }
                }
                i = j
            } else {
                val chip = createTabChip(tab, tab.id == activeId)
                tabViews[tab.id] = chip
                tabContainer.addView(chip)
                i++
            }
        }
        // "+" ở cuối dải vòng tròn — đúng theo ảnh tham khảo. Nút riêng
        // trên toolbar (`newTabButton`) vẫn giữ nguyên, không xoá — vẫn
        // cần dùng được khi dải này đang thu gọn. Bọc trong LinearLayout
        // dọc giống hệt `createTabChip` (thêm dòng trống bên dưới cho
        // thẳng hàng, vì tab chip giờ cao hơn do có thêm tên tab).
        tabContainer.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(4, 4, 4, 4) }
            addView(FrameLayout(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
                addView(ImageButton(this@MainActivity).apply {
                    setImageResource(android.R.drawable.ic_input_add)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        shape = android.graphics.drawable.GradientDrawable.OVAL
                        setColor(Color.parseColor("#F1F3F4"))
                    }
                    layoutParams = FrameLayout.LayoutParams(dp(44), dp(44)).apply { gravity = Gravity.CENTER }
                    setOnClickListener {
                        val tab = engine.createTab("https://www.google.com")
                        engine.switchToTab(tab.id)
                        refreshTabBar()
                    }
                })
            })
            addView(TextView(this@MainActivity).apply {
                text = " "
                textSize = 9f
                layoutParams = LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT)
            })
        })
        if (::tabSwitcherButton.isInitialized) {
            tabSwitcherButton.text = tabs.size.toString()
        }
    }

    /**
     * Vòng tròn cho 1 tab — theo đúng ảnh tham khảo người dùng gửi: hình
     * tròn (favicon nếu có, icon mặc định nếu chưa tải xong), tab ĐANG
     * ACTIVE có viền xanh bao quanh + nút X đè góc trên-phải để đóng
     * nhanh (tab không active không hiện X ngay trên vòng tròn — bấm vào
     * để chuyển tới rồi đóng, giữ giao diện gọn như ảnh gốc).
     */
    /** Viên thuốc nhỏ đại diện cho 1 nhóm ĐANG THU GỌN trên thanh chip
     * ngang — bấm vào để mở lại (hiện đủ chip từng tab trong nhóm). */
    private fun createGroupPillChip(group: com.colablive.keeper.core.TabGroup, count: Int): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(4, 4, 4, 4) }
            addView(TextView(this@MainActivity).apply {
                text = "▶ ${group.name} ($count)"
                setTextColor(Color.WHITE)
                textSize = 10f
                maxLines = 1
                setPadding(dp(8), dp(14), dp(8), dp(14))
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.parseColor(group.colorHex))
                }
            })
            isClickable = true
            setOnClickListener {
                collapsedGroupIds.remove(group.id)
                refreshTabBar()
            }
            // FIX BUG THẬT (người dùng báo: "group tab trên thanh tab
            // không kéo di chuyển vị trí được như tab thường") — TRƯỚC
            // ĐÂY viên thuốc này chỉ có `setOnClickListener` (mở lại
            // nhóm), không hề gắn kéo-thả. Dùng ĐÚNG cơ chế đã có sẵn cho
            // tab lẻ (`startDragAndDrop` + `localState`), chỉ khác tiền
            // tố "grp:" để `tabContainer.setOnDragListener` phân biệt
            // được đây là kéo CẢ NHÓM chứ không phải 1 tab — xem xử lý ở
            // ACTION_DROP bên dưới.
            setOnLongClickListener { view ->
                val clipData = ClipData.newPlainText("group_id", "grp:${group.id}")
                val shadow = View.DragShadowBuilder(view)
                view.startDragAndDrop(clipData, shadow, "grp:${group.id}", 0)
                true
            }
        }
    }

    /** Bọc TOÀN BỘ chip của 1 nhóm (đã gom liền kề) trong 1 khung nền màu
     * MỜ theo đúng màu nhóm — giống Chrome: nhóm là 1 khối có màu nền
     * riêng biệt hẳn trên thanh tab, không lẫn với tab thường/nhóm khác
     * như trước đây (đúng vấn đề người dùng chỉ ra qua ảnh khoanh đỏ).
     * Nhãn nhỏ ở đầu khối bấm được để thu gọn lại. */
    private fun createGroupChipCluster(
        group: com.colablive.keeper.core.TabGroup,
        members: List<com.colablive.keeper.core.BrowserTab>,
        activeId: String?
    ): View {
        val baseColor = Color.parseColor(group.colorHex)
        val translucent = Color.argb(50, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(translucent)
                setStroke(dp(2), baseColor)
            }
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(TextView(this@MainActivity).apply {
                text = "▼\n${group.name}"
                setTextColor(baseColor)
                textSize = 9f
                gravity = Gravity.CENTER
                setPadding(dp(4), 0, dp(4), 0)
                isClickable = true
                setOnClickListener {
                    collapsedGroupIds.add(group.id)
                    refreshTabBar()
                }
                // FIX BUG THẬT (người dùng báo: "group tab trên thanh tab
                // không kéo di chuyển vị trí được như tab thường") — cùng
                // cơ chế "grp:<id>" như `createGroupPillChip`, gắn vào
                // đúng NHÃN của nhóm (không gắn cả cụm `LinearLayout` cha
                // để không "nuốt" mất sự kiện kéo-thả của từng tab con
                // bên trong nhóm, vốn vẫn cần kéo RA KHỎI nhóm được như
                // trước — xem `createTabChip`).
                setOnLongClickListener { view ->
                    val clipData = ClipData.newPlainText("group_id", "grp:${group.id}")
                    val shadow = View.DragShadowBuilder(view)
                    view.startDragAndDrop(clipData, shadow, "grp:${group.id}", 0)
                    true
                }
            })
            members.forEach { t ->
                val chip = createTabChip(t, t.id == activeId)
                tabViews[t.id] = chip
                addView(chip)
            }
        }
    }

    private fun createTabChip(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean): View {
        val circleSize = dp(44)
        // BUG THẬT (người dùng báo icon vẫn xanh lè, favicon vẫn có thể
        // thất bại tuỳ trang) — khôi phục TÊN TAB hiện dưới vòng tròn,
        // đúng như bản GeckoView gốc của project — không chỉ dựa mỗi vào
        // favicon (có thể lỗi/không có) để phân biệt tab. Đổi wrapper
        // thành cột dọc (vòng tròn + tên rút gọn bên dưới) thay vì chỉ có
        // 1 vòng tròn trơ trọi.
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(4, 4, 4, 4) }
        }

        val circleFrame = android.widget.FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }

        val circle = android.widget.FrameLayout(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(circleSize, circleSize).apply {
                gravity = Gravity.CENTER
            }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(if (tab.isPrivate) Color.parseColor("#3C4043") else Color.WHITE)
                if (isActive) setStroke(dp(3), Color.parseColor("#1A73E8"))
            }
            isClickable = true
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, it, true)
            }.resourceId)
            setOnClickListener {
                if (tab.id != engine.getActiveTab()?.id) {
                    switchToTabCapturingThumbnail(tab.id)
                }
            }
            // TÍNH NĂNG MỚI (người dùng yêu cầu) — kéo-thả đổi vị trí tab
            // giống Chrome. Dùng đúng API kéo-thả chuẩn của Android
            // (`startDragAndDrop`) — không cần thư viện thêm, đã sẵn có
            // sẵn cơ chế nhận thả file/URL khác trong app (`setupDragDrop`)
            // nên chắc chắn tương thích. `ClipData` chỉ mang đúng `tab.id`
            // dạng text thường — không phải file/URI thật, chỉ dùng nội bộ
            // trong `tabContainer.setOnDragListener` bên dưới.
            setOnLongClickListener { view ->
                val clipData = android.content.ClipData.newPlainText("tab_id", tab.id)
                val shadow = View.DragShadowBuilder(view)
                view.startDragAndDrop(clipData, shadow, tab.id, 0)
                true
            }
            clipToOutline = false
        }

        val icon = ImageView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(dp(24), dp(24)).apply { gravity = Gravity.CENTER }
            val favicon = tab.favicon
            if (favicon != null) {
                setImageBitmap(favicon)
            } else if (tab.isPrivate) {
                setImageResource(android.R.drawable.ic_lock_lock)
                setColorFilter(Color.WHITE)
            } else {
                // BUG THẬT liên quan (người dùng báo icon các "khe"/trình
                // duyệt giống hệt nhau, khó phân biệt): chấm tròn xanh lá cố
                // định `presence_online` là icon HỆ THỐNG DÙNG CHUNG, không
                // đổi theo khe nào cả — khi nhiều tab ở nhiều khe khác nhau
                // đều chưa tải xong favicon, tất cả hiện identical, người
                // dùng không phân biệt được đang ở khe nào chỉ qua icon này.
                // Tên tab bên dưới (TextView displayName) đã có sẵn giúp
                // phân biệt theo TRANG, nhưng không giúp phân biệt theo KHE.
                // Sửa: vẽ chấm tròn màu RIÊNG theo slotIndex khi chưa có
                // favicon, để ngay cả lúc favicon chưa tải, người dùng vẫn
                // nhận ra đang ở khe nào qua màu.
                val slotColors = intArrayOf(
                    Color.parseColor("#1A73E8"), // Khe 0 — xanh dương
                    Color.parseColor("#34A853"), // Khe 1 — xanh lá
                    Color.parseColor("#FBBC04"), // Khe 2 — vàng cam
                    Color.parseColor("#EA4335")  // Khe 3 — đỏ
                )
                val color = slotColors[slotIndex % slotColors.size]
                val dotSize = dp(20)
                val bmp = android.graphics.Bitmap.createBitmap(dotSize, dotSize, android.graphics.Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bmp)
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
                canvas.drawCircle(dotSize / 2f, dotSize / 2f, dotSize / 2f, paint)
                setImageBitmap(bmp)
            }
        }
        circle.addView(icon)
        circleFrame.addView(circle)

        /**
         * TÍNH NĂNG THIẾU (người dùng báo: "ko có icon biểu hiện trang load
         * xong hết như các trình duyệt khác"): `tab.isLoading` đã được cập
         * nhật đúng ở `GeckoViewEngine` (`onPageStart`/`onPageStop`) từ
         * trước nhưng CHƯA TỪNG được đọc ở bất kỳ đâu trong UI. Vẽ spinner
         * đè lên trên favicon/chấm tròn khi đang tải — đúng pattern quen
         * thuộc Chrome/Firefox (spinner trong lúc tải, biến mất lộ favicon
         * ra khi xong). `onPageStartedListener`/refresh ngay khi
         * `onPageLoadedListener` bắn (xem MainActivity, chỗ gán 2 listener
         * đó) đảm bảo tab bar vẽ lại đúng lúc để spinner này xuất hiện/biến
         * mất kịp thời, không đợi thao tác khác kích hoạt refreshTabBar().
         */
        if (tab.isLoading) {
            circleFrame.addView(ProgressBar(this, null, android.R.attr.progressBarStyleSmall).apply {
                layoutParams = android.widget.FrameLayout.LayoutParams(dp(48), dp(48)).apply { gravity = Gravity.CENTER }
                indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#1A73E8"))
            })
        }

        if (isActive) {
            circleFrame.addView(ImageButton(this).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                setBackgroundColor(Color.parseColor("#1A73E8"))
                layoutParams = android.widget.FrameLayout.LayoutParams(dp(20), dp(20)).apply {
                    gravity = Gravity.TOP or Gravity.END
                }
                setColorFilter(Color.WHITE)
                setOnClickListener {
                    if (engine.getTabs().size <= 1) {
                        Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    engine.closeTab(tab.id)
                    tabThumbnails.remove(tab.id)
                    refreshTabBar()
                }
            })
        }
        wrapper.addView(circleFrame)

        wrapper.addView(TextView(this).apply {
            val displayName = tab.title.takeIf { it.isNotBlank() }
                ?: (try { Uri.parse(tab.url).host } catch (e: Exception) { null })
                ?: tab.url
            text = displayName
            textSize = 9f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setTextColor(if (tab.isPrivate) Color.LTGRAY else Color.DKGRAY)
            layoutParams = LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        return wrapper
    }

    /**
     * Lưới xem/chuyển/đóng tab kiểu Chrome (bấm nút "N" cạnh nút + trên
     * thanh công cụ) — thay vì phải dò dải chip ngang khi có nhiều tab.
     */
    private fun showTabSwitcher() {
        // TÍNH NĂNG MỚI: chụp thumbnail tab đang active NGAY TRƯỚC KHI mở
        // dialog lưới tab — đảm bảo card của tab đang mở luôn có ảnh xem trước
        // thật (capturePixels() chỉ chụp được tab đang render trên GeckoView).
        // Chờ kết quả async qua GeckoResult rồi mới dựng dialog để ảnh có mặt
        // ngay lần đầu vẽ lưới, không phải vẽ lại sau.
        val activeId = engine.getActiveTab()?.id
        fun buildAndShowDialog() {
            val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar)

            val grid = GridLayout(this).apply {
                columnCount = 2
                setPadding(24, 24, 24, 24)
            }

            lateinit var titleLabel: TextView

            // BUG THẬT ĐÃ SỬA (người dùng báo: kéo-thả trong lưới làm ĐỨNG
            // MÁY, phải ép reset cứng): trước đây callback ACTION_DROP gọi
            // `dialog.dismiss()` RỒI NGAY LẬP TỨC `showTabSwitcher()` (đệ
            // quy, dựng dialog MỚI TOANH + gọi lại `capturePixels()` —
            // native call đồng bộ hoá với Gecko compositor) — TẤT CẢ xảy
            // ra NGAY TRONG callback ACTION_DROP, tức là NGAY TRONG lúc
            // Android drag-and-drop framework CÒN ĐANG dispatch DragEvent
            // qua view tree (framework còn cần gửi tiếp ACTION_DRAG_ENDED
            // tới view nguồn). Việc huỷ + tạo lại toàn bộ cây view của
            // chính window đang xử lý sự kiện kéo-thả, kết hợp thêm 1 lệnh
            // gọi native đồng bộ (capturePixels), là tình huống tái nhập
            // (re-entrancy) kinh điển gây deadlock main thread → ANR →
            // đúng như log cho thấy: 1 dòng log kéo-thả rồi im bặt ~2 phút,
            // không có dòng nào khác kể cả onPause/onResume, đúng dấu hiệu
            // main thread bị khoá cứng.
            //
            // SỬA: KHÔNG dismiss+dựng lại dialog nữa. Thay vào đó, rebuild
            // TRỰC TIẾP các card con của `grid` (đã có sẵn, đang hiển thị)
            // theo thứ tự tab mới — dùng lại đúng dialog đang mở, KHÔNG gọi
            // lại capturePixels() (không cần thiết, ảnh thumbnail cũ vẫn
            // còn hợp lệ trong `tabThumbnails`). Toàn bộ việc sửa view
            // hierarchy được đẩy ra khỏi lượt dispatch DragEvent hiện tại
            // bằng `handler.post { }` — đợi drag-drop framework xử lý xong
            // hẳn (bao gồm ACTION_DRAG_ENDED) rồi mới động vào view tree.
            fun rebuildGrid() {
                val freshTabs = engine.getTabs()
                grid.removeAllViews()
                orderedTabsWithGroupHeaders(freshTabs).forEach { (tab, needsHeader) ->
                    if (needsHeader) {
                        tab.groupId?.let { gid ->
                            engine.getGroups().find { it.id == gid }?.let { group ->
                                val memberCount = freshTabs.count { it.groupId == gid }
                                grid.addView(createGroupHeader(group, memberCount, { rebuildGrid() }, { rebuildGrid() }))
                            }
                        }
                    }
                    // TÍNH NĂNG MỚI — nhóm đang thu gọn thì bỏ qua card,
                    // chỉ còn lại dải màu header (giống Chrome).
                    if (tab.groupId == null || tab.groupId !in collapsedGroupIds) {
                        grid.addView(createTabCard(tab, tab.id == engine.getActiveTab()?.id, dialog))
                    }
                }
                grid.addView(createNewTabCard(dialog))
                titleLabel.text = "${freshTabs.size} tab đang mở"
            }

            // Theo dõi card đang được highlight lúc kéo (để khôi phục viền
            // gốc khi rời khỏi/kết thúc kéo) + chế độ hiện tại (gộp nhóm
            // hay đổi vị trí) để ACTION_DROP dùng lại đúng quyết định vừa
            // hiển thị cho người dùng thấy, không tính lại khác đi.
            var dragHighlightView: View? = null
            var dragGroupTargetTabId: String? = null // != null nghĩa là đang ở chế độ GỘP NHÓM với tab này

            fun clearDragHighlight() {
                val v = dragHighlightView
                // GradientDrawable không có getter đọc lại stroke hiện có,
                // nên không "khôi phục chính xác" viền gốc được — chỉ tắt
                // viền tạm ở đây; `rebuildGrid()` (gọi ngay sau ở
                // ACTION_DRAG_ENDED) mới là nơi đảm bảo viền THẬT (theo
                // nhóm/active) được vẽ lại đúng, tránh bị kẹt viền tạm nếu
                // người dùng huỷ kéo giữa chừng không thả.
                (v?.background as? android.graphics.drawable.GradientDrawable)?.setStroke(0, 0)
                dragHighlightView = null
                dragGroupTargetTabId = null
            }

            fun computeHover(event: android.view.DragEvent, draggedTabId: String?): Triple<Int, View?, String?> {
                // Trả về (targetIndex THẬT trong engine.getTabs() để ĐỔI VỊ
                // TRÍ, card đang hover để tô viền, tabId để GỘP NHÓM nếu
                // đang ở vùng lõi của 1 card khác tab đang kéo).
                val rawTabs = engine.getTabs()
                val displayList = orderedTabsWithGroupHeaders(rawTabs).map { it.first }
                var targetIndex = rawTabs.size
                var hoverChild: View? = null
                var groupTabId: String? = null
                var displayIdx = 0
                for (i in 0 until grid.childCount - 1) { // trừ card "Tab mới" cuối
                    val child = grid.getChildAt(i)
                    // Bỏ qua header nhóm (TextView) — chỉ card tab thật
                    // (LinearLayout, xem createTabCard) mới tính vào chỉ số.
                    if (child !is LinearLayout) continue
                    val thisTab = displayList.getOrNull(displayIdx) ?: continue
                    displayIdx++
                    val left = child.x
                    val top = child.y
                    val right = left + child.width
                    val bottom = top + child.height
                    if (event.x in left..right && event.y in top..bottom) {
                        hoverChild = child
                        val insetX = child.width * 0.25f
                        val insetY = child.height * 0.25f
                        val inCore = event.x in (left + insetX)..(right - insetX) &&
                                     event.y in (top + insetY)..(bottom - insetY)
                        if (inCore && thisTab.id != draggedTabId) {
                            groupTabId = thisTab.id
                        }
                    }
                    val centerX = child.x + child.width / 2f
                    val centerY = child.y + child.height / 2f
                    if (event.y < centerY || (event.y < centerY + child.height / 2f && event.x < centerX)) {
                        if (targetIndex == rawTabs.size) {
                            val rawIdx = rawTabs.indexOfFirst { it.id == thisTab.id }
                            targetIndex = if (rawIdx >= 0) rawIdx else rawTabs.size
                        }
                    }
                }
                return Triple(targetIndex, hoverChild, groupTabId)
            }

            grid.setOnDragListener { _, event ->
                when (event.action) {
                    android.view.DragEvent.ACTION_DRAG_STARTED -> true
                    android.view.DragEvent.ACTION_DRAG_LOCATION -> {
                        val draggedTabId = event.localState as? String
                        val (_, hoverChild, groupTabId) = computeHover(event, draggedTabId)
                        if (hoverChild !== dragHighlightView) {
                            clearDragHighlight()
                            if (hoverChild != null) {
                                val bg = hoverChild.background as? android.graphics.drawable.GradientDrawable
                                if (bg != null) {
                                    dragHighlightView = hoverChild
                                }
                            }
                        }
                        dragGroupTargetTabId = groupTabId
                        (dragHighlightView?.background as? android.graphics.drawable.GradientDrawable)?.setStroke(
                            dp(4),
                            if (groupTabId != null) Color.parseColor("#FBBC04") else Color.parseColor("#1A73E8")
                        )
                        true
                    }
                    android.view.DragEvent.ACTION_DRAG_EXITED -> {
                        clearDragHighlight()
                        true
                    }
                    android.view.DragEvent.ACTION_DRAG_ENDED -> {
                        clearDragHighlight()
                        handler.post { rebuildGrid() }
                        true
                    }
                    android.view.DragEvent.ACTION_DROP -> {
                        val draggedTabId = event.localState as? String
                            ?: return@setOnDragListener false
                        val (targetIndex, _, groupTabId) = computeHover(event, draggedTabId)
                        val tabs = engine.getTabs()
                        val fromIndex = tabs.indexOfFirst { it.id == draggedTabId }
                        if (groupTabId != null) {
                            // TÍNH NĂNG MỚI — thả lên giữa 1 tab khác = gộp
                            // nhóm, giống Chrome. Nếu tab đích đã có sẵn
                            // nhóm, gia nhập nhóm đó; nếu chưa, tự tạo nhóm
                            // mới rồi gán CẢ 2 tab (đang kéo + đích) vào.
                            val targetTab = tabs.find { it.id == groupTabId }
                            val existingGroupId = targetTab?.groupId
                            val finalGroupId = existingGroupId ?: run {
                                val palette = listOf("#1A73E8", "#EA4335", "#FBBC04", "#34A853", "#9C27B0", "#00ACC1")
                                val idx = engine.getGroups().size % palette.size
                                val newGroup = engine.createGroup("Nhóm ${engine.getGroups().size + 1}", palette[idx])
                                engine.setTabGroup(groupTabId, newGroup.id)
                                newGroup.id
                            }
                            engine.setTabGroup(draggedTabId, finalGroupId)
                            DebugLog.log("MainActivity: kéo-thả tab '$draggedTabId' vào nhóm của tab '$groupTabId' (groupId=$finalGroupId)")
                            refreshTabBar()
                            handler.post { rebuildGrid() }
                        } else if (fromIndex >= 0 && targetIndex != fromIndex) {
                            val draggedTab = tabs.find { it.id == draggedTabId }
                            if (draggedTab?.groupId != null) {
                                DebugLog.log("MainActivity: kéo-thả tab '$draggedTabId' RA KHỎI nhóm (groupId cũ='${draggedTab.groupId}') do thả ở chế độ đổi vị trí, không phải gộp nhóm")
                                engine.setTabGroup(draggedTabId, null)
                            }
                            DebugLog.log("MainActivity: kéo-thả tab '$draggedTabId' trong lưới: $fromIndex → $targetIndex")
                            engine.moveTab(draggedTabId, targetIndex)
                            refreshTabBar()
                            // Trì hoãn rebuild ra khỏi lượt dispatch DragEvent
                            // hiện tại — xem chú thích lớn ở trên.
                            handler.post { rebuildGrid() }
                        }
                        clearDragHighlight()
                        true
                    }
                    else -> true
                }
            }

            val initialTabs = engine.getTabs()
            orderedTabsWithGroupHeaders(initialTabs).forEach { (tab, needsHeader) ->
                if (needsHeader) {
                    tab.groupId?.let { gid ->
                        engine.getGroups().find { it.id == gid }?.let { group ->
                            val memberCount = initialTabs.count { it.groupId == gid }
                            grid.addView(createGroupHeader(group, memberCount, { rebuildGrid() }, { rebuildGrid() }))
                        }
                    }
                }
                if (tab.groupId == null || tab.groupId !in collapsedGroupIds) {
                    grid.addView(createTabCard(tab, tab.id == activeId, dialog))
                }
            }
            grid.addView(createNewTabCard(dialog))

            val scroll = ScrollView(this).apply { addView(grid) }

            fun exitSelectionMode() {
                selectionModeActive = false
                selectedTabIds.clear()
            }

            fun doCloseSelected() {
                val ids = selectedTabIds.toList()
                if (ids.isEmpty()) return
                if (engine.getTabs().size - ids.size < 1) {
                    Toast.makeText(this@MainActivity, "Không thể đóng hết mọi tab", Toast.LENGTH_SHORT).show()
                    return
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Đóng ${ids.size} tab?")
                    .setPositiveButton("Đóng") { _, _ ->
                        ids.forEach { id -> engine.closeTab(id); tabThumbnails.remove(id) }
                        exitSelectionMode()
                        refreshTabBar()
                        activeTabSwitcherRefresh?.invoke()
                    }
                    .setNegativeButton("Huỷ", null)
                    .show()
            }

            fun doAddSelectedToGroup() {
                val ids = selectedTabIds.toList()
                if (ids.isEmpty()) return
                val palette = listOf("#1A73E8", "#EA4335", "#FBBC04", "#34A853", "#9C27B0", "#00ACC1")
                val idx = engine.getGroups().size % palette.size
                val newGroup = engine.createGroup("Nhóm ${engine.getGroups().size + 1}", palette[idx])
                ids.forEach { id -> engine.setTabGroup(id, newGroup.id) }
                DebugLog.log("MainActivity: thêm ${ids.size} tab đã chọn vào nhóm mới '${newGroup.name}' (${newGroup.id})")
                exitSelectionMode()
                refreshTabBar()
                activeTabSwitcherRefresh?.invoke()
            }

            fun doBookmarkSelected() {
                val ids = selectedTabIds.toList()
                if (ids.isEmpty()) return
                var count = 0
                engine.getTabs().filter { it.id in ids }.forEach { t ->
                    if (!t.isPrivate) {
                        com.colablive.keeper.core.BrowserBookmarks.toggle(this@MainActivity, slotIndex, t.url, t.title.ifEmpty { t.url })
                        count++
                    }
                }
                Toast.makeText(this@MainActivity, "Đã đánh dấu $count tab", Toast.LENGTH_SHORT).show()
                exitSelectionMode()
                activeTabSwitcherRefresh?.invoke()
            }

            fun doShareSelected() {
                val ids = selectedTabIds.toList()
                if (ids.isEmpty()) return
                val urls = engine.getTabs().filter { it.id in ids }.joinToString("\n") { it.url }
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, urls)
                }
                startActivity(Intent.createChooser(shareIntent, "Chia sẻ ${ids.size} tab"))
            }

            // TÍNH NĂNG MỚI (người dùng yêu cầu): ghim hàng loạt nhiều tab
            // đã chọn vào danh sách "chạy nền" cùng lúc — cùng ý nghĩa với
            // nút ghim đơn lẻ trên thanh URL, chỉ khác là áp dụng cho tất cả
            // tab đang chọn ở lưới tab thay vì gõ tay từng cái.
            fun doPinSelectedForBackground() {
                val ids = selectedTabIds.toList()
                if (ids.isEmpty()) return
                var count = 0
                engine.getTabs().filter { it.id in ids }.forEach { t ->
                    val host = try { android.net.Uri.parse(t.url).host } catch (e: Exception) { null }
                    if (!host.isNullOrBlank()) {
                        com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.addDomain(this@MainActivity, slotIndex, host)
                        count++
                    }
                }
                Toast.makeText(this@MainActivity, "Đã ghim $count trang chạy nền", Toast.LENGTH_SHORT).show()
                exitSelectionMode()
                // FIX ĐỒNG BỘ (người dùng yêu cầu): nếu 1 trong các tab
                // vừa ghim hàng loạt TRÙNG domain với tab ĐANG MỞ (nút
                // ghim đơn trên thanh URL đang hiện), nút đó phải đổi
                // hình NGAY, không đợi điều hướng lại mới thấy đúng.
                if (::pinButton.isInitialized) updatePinButton(lastLoadedUrl)
                activeTabSwitcherRefresh?.invoke()
                refreshKeepAliveServiceState()
            }

            // TÍNH NĂNG MỚI (đối xứng với ghim hàng loạt ở trên, theo đúng
            // yêu cầu người dùng: "nếu gỡ chạy nền thì cũng cập nhật như
            // vậy" — nghĩa là cần có đường gỡ hàng loạt để test/dùng đối
            // xứng, không chỉ có chiều thêm). Dùng lại ĐÚNG 1 nguồn dữ
            // liệu chung (`removeDomain`), không phát minh cơ chế mới.
            fun doUnpinSelectedFromBackground() {
                val ids = selectedTabIds.toList()
                if (ids.isEmpty()) return
                var count = 0
                engine.getTabs().filter { it.id in ids }.forEach { t ->
                    val host = try { android.net.Uri.parse(t.url).host } catch (e: Exception) { null }
                    if (!host.isNullOrBlank()) {
                        com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.removeDomain(this@MainActivity, slotIndex, host)
                        count++
                    }
                }
                Toast.makeText(this@MainActivity, "Đã gỡ ghim $count trang", Toast.LENGTH_SHORT).show()
                exitSelectionMode()
                if (::pinButton.isInitialized) updatePinButton(lastLoadedUrl)
                activeTabSwitcherRefresh?.invoke()
                refreshKeepAliveServiceState()
            }

            val titleBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(24, 16, 24, 16)
            }

            fun rebuildTitleBar() {
                titleBar.removeAllViews()
                if (selectionModeActive) {
                    titleBar.addView(ImageButton(this@MainActivity).apply {
                        setImageResource(android.R.drawable.ic_menu_revert)
                        setBackgroundColor(Color.TRANSPARENT)
                        setOnClickListener {
                            exitSelectionMode()
                            activeTabSwitcherRefresh?.invoke()
                        }
                    })
                    titleBar.addView(TextView(this@MainActivity).apply {
                        text = "${selectedTabIds.size} mục"
                        textSize = 16f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        setPadding(dp(12), 0, 0, 0)
                    })
                    val iconRow = listOf(
                        Triple(android.R.drawable.checkbox_on_background, "Chọn tất cả") {
                            selectedTabIds.clear()
                            selectedTabIds.addAll(engine.getTabs().map { it.id })
                            activeTabSwitcherRefresh?.invoke()
                        },
                        Triple(android.R.drawable.ic_menu_delete, "Đóng các thẻ") { doCloseSelected() },
                        Triple(android.R.drawable.ic_menu_gallery, "Thêm vào nhóm") { doAddSelectedToGroup() },
                        Triple(android.R.drawable.btn_star_big_off, "Đánh dấu") { doBookmarkSelected() },
                        Triple(android.R.drawable.ic_menu_share, "Chia sẻ") { doShareSelected() },
                        Triple(android.R.drawable.ic_menu_myplaces, "Chạy nền") { doPinSelectedForBackground() },
                        Triple(android.R.drawable.ic_menu_close_clear_cancel, "Gỡ ghim") { doUnpinSelectedFromBackground() }
                    )
                    iconRow.forEach { (iconRes, desc, action) ->
                        titleBar.addView(ImageButton(this@MainActivity).apply {
                            setImageResource(iconRes)
                            setBackgroundColor(Color.TRANSPARENT)
                            contentDescription = desc
                            setOnClickListener { (action as () -> Unit)() }
                        })
                    }
                } else {
                    titleLabel = TextView(this@MainActivity).apply {
                        text = "${engine.getTabs().size} tab đang mở"
                        textSize = 16f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    titleBar.addView(titleLabel)
                    // TÍNH NĂNG MỚI — lối vào chế độ chọn nhiều tab
                    // (giống Chrome), tránh xung đột cử chỉ với long-
                    // press vốn đã dùng cho kéo-thả đổi vị trí.
                    titleBar.addView(ImageButton(this@MainActivity).apply {
                        setImageResource(android.R.drawable.ic_menu_agenda)
                        setBackgroundColor(Color.TRANSPARENT)
                        contentDescription = "Chọn nhiều tab"
                        setOnClickListener {
                            selectionModeActive = true
                            activeTabSwitcherRefresh?.invoke()
                        }
                    })
                    titleBar.addView(Button(this@MainActivity).apply {
                        text = "Đóng"
                        setOnClickListener { dialog.dismiss() }
                    })
                }
            }
            rebuildTitleBar()
            // GÁN THẬT (trước đây thiếu bước này — activeTabSwitcherRefresh
            // mãi mãi null, mọi nơi gọi `?.invoke()` đều là no-op): mỗi lần
            // cần vẽ lại (đổi chế độ chọn, đổi số lượng đã chọn, đổi tổng số
            // tab, thu gọn/mở rộng nhóm...) đều gọi lại CẢ lưới lẫn thanh
            // tiêu đề để đồng bộ 2 nơi.
            activeTabSwitcherRefresh = { rebuildGrid(); rebuildTitleBar() }
            dialog.setOnDismissListener {
                activeTabSwitcherRefresh = null
                selectionModeActive = false
                selectedTabIds.clear()
            }

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.WHITE)
                addView(titleBar)
                addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
            dialog.setContentView(root)
            dialog.show()
        }

        // Chụp tab đang active (nếu GeckoView sẵn sàng), rồi mở dialog.
        // Nếu capturePixels() thất bại (compositor chưa sẵn sàng), vẫn mở
        // dialog ngay — không để người dùng chờ mãi.
        val currentTab = engine.getActiveTab()
        if (currentTab != null && ::geckoView.isInitialized) {
            try {
                geckoView.capturePixels().accept({ bitmap ->
                    if (bitmap != null) {
                        try {
                            val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, 200, 120, true)
                            tabThumbnails[currentTab.id] = scaled
                        } catch (_: Exception) {}
                    }
                    runOnUiThread { buildAndShowDialog() }
                }, { _ ->
                    runOnUiThread { buildAndShowDialog() }
                })
            } catch (_: Exception) {
                buildAndShowDialog()
            }
        } else {
            buildAndShowDialog()
        }
    }

    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu) — hộp thoại nhóm tab. Cho phép:
     * tạo nhóm mới (chọn tên + 1 trong 6 màu định sẵn giống bảng màu nhóm
     * Chrome thật), thêm vào nhóm đã có, hoặc bỏ khỏi nhóm hiện tại.
     */
    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu): "nhập nhiều url thành nhiều tab,
     * có lựa chọn bỏ vào group tab nào" — đã rà toàn bộ codebase + tài liệu
     * kỹ thuật TRƯỚC lượt này, xác nhận CHƯA từng có (không có hàm mở hàng
     * loạt/bulk nào, "Nhóm tab" trước đây chỉ gán ĐƯỢC cho 1 tab đã mở sẵn).
     *
     * Vào từ CẢ 2 nơi theo đúng yêu cầu:
     *  1) Ô địa chỉ (urlBar) — dán thẳng danh sách nhiều dòng, xử lý ở
     *     TextWatcher phía trên (phát hiện ký tự xuống dòng ngay khi dán).
     *  2) Mục "📑 Mở nhiều URL" trong menu 3 chấm — gọi `showBulkOpenUrlsDialog()`.
     *
     * Cả 2 đường đều dẫn tới CÙNG 1 dialog gán nhóm bên dưới: gán TỪNG URL
     * vào TỪNG nhóm riêng (đáp ứng đúng lựa chọn "cái 2" của người dùng),
     * kèm 1 hàng "Áp dụng cho tất cả" ở đầu để đồng bộ nhanh xuống mọi dòng
     * — vẫn sửa lại được TỪNG dòng riêng sau khi áp dụng, không khoá cứng.
     */
    private fun parseUrlLines(text: String): List<String> =
        text.split("\n", "\r\n")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    /** Lối vào (2): dialog nhập tay/dán nhiều dòng, độc lập với urlBar. */
    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu, mục 73 PROJECT_STATUS.md): danh
     * sách tab vừa đóng, mới nhất ở đầu — bấm vào 1 dòng để mở lại ĐÚNG
     * session đó (không chỉ đúng URL, còn nguyên lịch sử back/forward bên
     * trong tab, xem `GeckoViewEngine.reopenClosedTab`).
     */
    private fun showRecentlyClosedTabsDialog() {
        val entries = engine.getRecentlyClosedTabs()
        if (entries.isEmpty()) {
            Toast.makeText(this, "Chưa có thẻ nào vừa đóng", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = entries.map { entry ->
            val title = entry.title.ifBlank { entry.url }
            "$title\n${entry.url}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Thẻ đã đóng gần đây")
            .setItems(labels) { _, index ->
                val tab = engine.reopenClosedTab(entries[index].entryId)
                if (tab != null) {
                    switchToTabCapturingThumbnail(tab.id)
                    refreshTabBar()
                } else {
                    Toast.makeText(this, "Thẻ này không còn mở lại được (có thể đã mở lại trước đó)", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun showBulkOpenUrlsDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        layout.addView(TextView(this).apply {
            text = "Dán hoặc gõ danh sách URL, mỗi dòng 1 địa chỉ:"
            setPadding(0, 0, 0, dp(8))
        })
        val input = EditText(this).apply {
            hint = "https://example.com\nhttps://example2.com\n..."
            gravity = Gravity.TOP or Gravity.START
            minLines = 6
            maxLines = 12
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        layout.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Mở nhiều URL")
            .setView(layout)
            .setPositiveButton("Tiếp tục") { _, _ ->
                val urls = parseUrlLines(input.text.toString())
                when {
                    urls.isEmpty() -> Toast.makeText(this, "Chưa nhập URL nào", Toast.LENGTH_SHORT).show()
                    urls.size == 1 -> navigateToUrl(urls[0])
                    else -> showBulkGroupAssignDialog(urls)
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    /**
     * Dialog chính: liệt kê từng URL kèm 1 Spinner chọn nhóm riêng ("Không
     * nhóm" / tên các nhóm có sẵn / "➕ Tạo nhóm mới…"). Danh sách nhãn của
     * MỌI spinner (hàng "áp dụng tất cả" + từng dòng URL) đều lấy từ CÙNG 1
     * `groups` — khi tạo nhóm mới, nhóm luôn được thêm vào CUỐI (ngay trước
     * mục sentinel "➕...") nên vị trí các mục cũ trong mọi spinner khác
     * KHÔNG đổi, chỉ cần dựng lại adapter mà không cần tính lại lựa chọn
     * hiện tại của từng dòng.
     */
    private fun showBulkGroupAssignDialog(urls: List<String>) {
        val groups = engine.getGroups().toMutableList()
        val spinners = mutableListOf<Spinner>()

        fun labels() = listOf("Không nhóm") + groups.map { it.name } + listOf("➕ Tạo nhóm mới…")
        fun newAdapter() = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels()).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        fun refreshAllAdapters() {
            val lbl = labels()
            spinners.forEach { sp ->
                val keep = sp.selectedItemPosition
                sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, lbl).apply {
                    setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                }
                if (keep in lbl.indices) sp.setSelection(keep)
            }
        }
        // Tạo nhóm rút gọn ngay trong luồng này (chỉ hỏi tên, dùng màu xanh
        // dương mặc định) — đổi tên/màu chi tiết hơn đã có sẵn ở "🏷 Nhóm
        // tab", không lặp lại UI chọn màu đầy đủ ở đây cho gọn.
        fun createGroupInline(onCreated: (TabGroup) -> Unit) {
            val nameInput = EditText(this).apply { hint = "Tên nhóm (VD: Công việc)" }
            AlertDialog.Builder(this)
                .setTitle("Tạo nhóm mới")
                .setView(nameInput)
                .setPositiveButton("Tạo") { _, _ ->
                    val name = nameInput.text.toString().trim().ifEmpty { "Nhóm mới" }
                    val group = engine.createGroup(name, "#4285F4")
                    groups.add(group)
                    refreshAllAdapters()
                    onCreated(group)
                }
                .setNegativeButton("Huỷ", null)
                .show()
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

        val applyAllRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(6))
        }
        applyAllRow.addView(TextView(this).apply {
            text = "Nhóm:"
            setPadding(0, dp(12), dp(8), 0)
        })
        val applyAllSpinner = Spinner(this).apply { adapter = newAdapter() }
        applyAllRow.addView(applyAllSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        layout.addView(applyAllRow)
        layout.addView(Button(this).apply {
            text = "↧ Áp dụng cho TẤT CẢ dòng bên dưới"
            setOnClickListener {
                val idx = applyAllSpinner.selectedItemPosition
                if (idx == labels().size - 1) {
                    createGroupInline { group -> spinners.forEach { it.setSelection(groups.indexOf(group) + 1) } }
                } else {
                    spinners.forEach { it.setSelection(idx) }
                }
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nGán riêng từng URL (vẫn sửa được sau khi áp dụng ở trên):"
            setPadding(0, dp(8), 0, dp(6))
        })

        val scroll = ScrollView(this)
        val listLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        urls.forEach { url ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(6), 0, dp(6))
            }
            row.addView(TextView(this).apply {
                text = url
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val sp = Spinner(this).apply { adapter = newAdapter() }
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position == labels().size - 1) {
                        createGroupInline { group -> sp.setSelection(groups.indexOf(group) + 1) }
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
            spinners.add(sp)
            row.addView(sp)
            listLayout.addView(row)
        }
        scroll.addView(listLayout)
        layout.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320)))

        AlertDialog.Builder(this)
            .setTitle("Mở ${urls.size} tab mới")
            .setView(layout)
            .setPositiveButton("Mở ${urls.size} tab") { _, _ ->
                var firstNewTabId: String? = null
                urls.forEachIndexed { i, url ->
                    val tab = engine.createTab(url, isPrivate = false)
                    if (firstNewTabId == null) firstNewTabId = tab.id
                    val pos = spinners[i].selectedItemPosition
                    val groupId = if (pos in 1..groups.size) groups[pos - 1].id else null
                    if (groupId != null) engine.setTabGroup(tab.id, groupId)
                }
                firstNewTabId?.let { switchToTabCapturingThumbnail(it) }
                refreshTabBar()
                Toast.makeText(this, "Đã mở ${urls.size} tab", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun showGroupAssignDialog(tab: com.colablive.keeper.core.BrowserTab, onDone: () -> Unit) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        layout.addView(TextView(this).apply {
            text = "Nhóm tab"
            textSize = 16f
            setPadding(0, 0, 0, dp(12))
        })
        if (tab.groupId != null) {
            layout.addView(Button(this).apply {
                text = "Bỏ khỏi nhóm hiện tại"
                setOnClickListener {
                    engine.setTabGroup(tab.id, null)
                    onDone()
                }
            })
        }
        engine.getGroups().forEach { group ->
            layout.addView(Button(this).apply {
                text = "Thêm vào '${group.name}'"
                setTextColor(Color.parseColor(group.colorHex))
                setOnClickListener {
                    engine.setTabGroup(tab.id, group.id)
                    onDone()
                }
            })
        }
        layout.addView(TextView(this).apply {
            text = "\nTạo nhóm mới:"
            setPadding(0, dp(8), 0, dp(4))
        })
        val nameInput = EditText(this).apply { hint = "Tên nhóm (VD: Công việc)" }
        layout.addView(nameInput)
        // Bảng màu định sẵn — đúng 6 màu nhóm Chrome hay dùng nhất, đủ để
        // phân biệt rõ ràng mà không cần tự chọn màu phức tạp.
        val presetColors = listOf(
            "#EA4335" to "Đỏ", "#FBBC04" to "Vàng", "#34A853" to "Xanh lá",
            "#4285F4" to "Xanh dương", "#A142F4" to "Tím", "#FF6D01" to "Cam"
        )
        var selectedColor = presetColors[0].first
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        val colorDots = mutableListOf<View>()
        presetColors.forEach { (hex, _) ->
            val dot = View(this).apply {
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                    if (hex == selectedColor) setStroke(dp(3), Color.BLACK)
                }
                setOnClickListener {
                    selectedColor = hex
                    colorDots.forEachIndexed { i, d ->
                        (d.background as android.graphics.drawable.GradientDrawable).setStroke(
                            if (presetColors[i].first == hex) dp(3) else 0, Color.BLACK
                        )
                    }
                }
            }
            colorDots.add(dot)
            colorRow.addView(dot, LinearLayout.LayoutParams(dp(32), dp(32)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        layout.addView(colorRow)
        layout.addView(Button(this).apply {
            text = "Tạo nhóm & thêm tab này"
            setOnClickListener {
                val name = nameInput.text.toString().trim().ifEmpty { "Nhóm mới" }
                val group = engine.createGroup(name, selectedColor)
                engine.setTabGroup(tab.id, group.id)
                onDone()
            }
        })
        AlertDialog.Builder(this)
            .setView(layout)
            .setNegativeButton("Đóng", null)
            .show()
    }

    /** Gom các tab CÙNG groupId thành 1 khối LIỀN KỀ (đúng hành vi Chrome:
     * 1 nhóm luôn là 1 dải liên tục trong danh sách tab, không rời rạc) —
     * nhóm nào có tab xuất hiện SỚM NHẤT trong danh sách gốc thì khối đó
     * đứng trước; thứ tự BÊN TRONG mỗi khối giữ nguyên theo tabs gốc. Trả
     * về danh sách (tab, cần chèn header nhóm ngay trước tab này hay không)
     * — chỉ tab ĐẦU TIÊN của mỗi khối nhóm mới cần header. */
    private fun orderedTabsWithGroupHeaders(
        tabs: List<com.colablive.keeper.core.BrowserTab>
    ): List<Pair<com.colablive.keeper.core.BrowserTab, Boolean>> {
        val ordered = mutableListOf<com.colablive.keeper.core.BrowserTab>()
        val seen = mutableSetOf<String>()
        for (tab in tabs) {
            if (tab.id in seen) continue
            if (tab.groupId != null) {
                val members = tabs.filter { it.groupId == tab.groupId }
                ordered.addAll(members)
                seen.addAll(members.map { it.id })
            } else {
                ordered.add(tab)
                seen.add(tab.id)
            }
        }
        val result = mutableListOf<Pair<com.colablive.keeper.core.BrowserTab, Boolean>>()
        var lastGroupId: String? = "___chưa_có_khối_nào___"
        for (tab in ordered) {
            val needsHeader = tab.groupId != null && tab.groupId != lastGroupId
            result.add(tab to needsHeader)
            lastGroupId = tab.groupId
        }
        return result
    }

    /** Header MÀU CHUNG cho cả khối nhóm — chiếm TRỌN CHIỀU RỘNG lưới
     * (GridLayout.spec(UNDEFINED, 2), ép tự xuống dòng đúng như 1 dải màu
     * thật của Chrome), thay cho việc mỗi card tự dán nhãn riêng lẻ trước
     * đây.
     *
     * TÍNH NĂNG MỚI (người dùng yêu cầu, giống Chrome):
     * - BẤM vào header → thu gọn/mở rộng (ẩn/hiện toàn bộ card trong
     *   nhóm, chỉ còn lại dải màu kèm số lượng tab — giống hệt hành vi
     *   Chrome khi bấm vào tên nhóm trên thanh tab).
     * - GIỮ LÂU vào header → đổi tên nhóm (trước đây tạo xong là CỐ ĐỊNH
     *   tên mãi mãi, không có cách nào sửa lại — bug thiếu sót thật).
     */
    private fun createGroupHeader(
        group: com.colablive.keeper.core.TabGroup,
        memberCount: Int,
        onToggleCollapse: () -> Unit,
        onRenamed: () -> Unit
    ): View {
        val isCollapsed = group.id in collapsedGroupIds
        return TextView(this).apply {
            text = "${if (isCollapsed) "▶" else "▼"}  ${group.name}${if (isCollapsed) " ($memberCount)" else ""}"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(group.colorHex))
            }
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 2, 1f)
                setMargins(8, 20, 8, 4)
            }
            isClickable = true
            setOnClickListener {
                if (!collapsedGroupIds.add(group.id)) collapsedGroupIds.remove(group.id)
                onToggleCollapse()
            }
            setOnLongClickListener {
                val input = EditText(this@MainActivity).apply { setText(group.name) }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Đổi tên nhóm")
                    .setView(input)
                    .setPositiveButton("Lưu") { _, _ ->
                        val newName = input.text.toString().trim()
                        if (newName.isNotEmpty()) {
                            group.name = newName
                            onRenamed()
                        }
                    }
                    .setNegativeButton("Huỷ", null)
                    .show()
                true
            }
        }
    }

    private fun createTabCard(tab: com.colablive.keeper.core.BrowserTab, isActive: Boolean, dialog: Dialog): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            // Chrome dùng VIỀN XANH quanh card cho tab đang active, không
            // chỉ đổi màu nền — dễ nhận ra hơn giữa lưới nhiều card giống
            // nhau. Bo góc (trước đây vuông cạnh, không giống Material/Chrome).
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(when {
                    tab.isPrivate -> Color.parseColor("#3C4043") // tối, đúng tông ẩn danh Chrome — phân biệt ngay cả khi không active
                    isActive -> Color.parseColor("#D2E3FC")
                    else -> Color.parseColor("#F1F3F4")
                })
                // TÍNH NĂNG MỚI (người dùng yêu cầu) — viền màu của NHÓM
                // (nếu có) ưu tiên hiện trước viền xanh "đang active", để
                // luôn nhận ra tab thuộc nhóm nào ngay cả khi đang mở nó.
                val group = tab.groupId?.let { gid -> engine.getGroups().find { it.id == gid } }
                when {
                    // TÍNH NĂNG MỚI — đang được CHỌN (chế độ chọn nhiều tab)
                    // ưu tiên hiện RÕ NHẤT, hơn cả viền nhóm/active, vì đây
                    // là hành động người dùng vừa làm ngay lúc này.
                    tab.id in selectedTabIds -> setStroke(dp(4), Color.parseColor("#0B57D0"))
                    group != null -> setStroke(dp(3), Color.parseColor(group.colorHex))
                    isActive -> setStroke(dp(2), Color.parseColor("#1A73E8"))
                }
            }
            elevation = dp(1).toFloat()
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId)
            setOnClickListener {
                if (selectionModeActive) {
                    if (!selectedTabIds.add(tab.id)) selectedTabIds.remove(tab.id)
                    activeTabSwitcherRefresh?.invoke()
                } else {
                    switchToTabCapturingThumbnail(tab.id)
                    dialog.dismiss()
                }
            }
            // Long-press: bắt đầu kéo-thả đổi vị trí tab trong lưới (ưu
            // tiên hơn mở nhóm tab để khớp với hành vi Chrome thật — giữ
            // kéo = di chuyển tab, không phải mở dialog). Nếu người dùng
            // muốn nhóm tab, có thể truy cập qua menu 3 chấm của khe.
            // Dùng cùng cơ chế startDragAndDrop + localState=tab.id như
            // thanh chip ngang để grid.setOnDragListener có thể nhận được.
            // VÔ HIỆU HOÁ khi đang ở chế độ chọn nhiều tab — kéo-thả không
            // có ý nghĩa gì lúc này, tránh xung đột cử chỉ.
            setOnLongClickListener { view ->
                if (selectionModeActive) return@setOnLongClickListener false
                val clipData = android.content.ClipData.newPlainText("tab_id_grid", tab.id)
                val shadow = View.DragShadowBuilder(view)
                view.startDragAndDrop(clipData, shadow, tab.id, 0)
                true
            }
        }

        // (Nhãn tên nhóm ĐÃ CHUYỂN sang 1 header dùng chung cho cả khối —
        // xem `createGroupHeader`/`orderedTabsWithGroupHeaders` — không còn
        // tự in riêng ở từng card nữa, để card CÙNG NHÓM trông thật sự như
        // 1 KHỐI liền mạch thay vì rời rạc từng cái tự dán nhãn.)

        // TÍNH NĂNG MỚI (người dùng yêu cầu) — hiện ảnh thu nhỏ THẬT nếu
        // đã có (chụp lúc rời tab đó, xem `switchToTabCapturingThumbnail`).
        // Chưa có ảnh (VD tab chưa từng bị rời đi, hoặc capturePixels()
        // thất bại) → không thêm ImageView, card chỉ hiện chữ như trước
        // đây — không làm hỏng layout nếu chưa có ảnh.
        tabThumbnails[tab.id]?.let { bitmap ->
            card.addView(android.widget.ImageView(this).apply {
                setImageBitmap(bitmap)
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(90)).apply {
                    setMargins(0, 8, 0, 8)
                }
                clipToOutline = true
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(8).toFloat()
                }
            })
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        // FIX ĐỒNG BỘ (người dùng yêu cầu): trước đây lưới nhiều tab
        // KHÔNG hề hiện tab nào đang nằm trong danh sách "chạy nền" —
        // chỉ nút ghim đơn trên thanh URL có hiện. Thêm huy hiệu nhỏ ở
        // đây, đọc TRỰC TIẾP từ CHÍNH 1 nguồn dữ liệu chung
        // (`BackgroundKeepAliveFeature.isDomainPinned`, không có bản sao
        // riêng nào) — mỗi lần lưới được vẽ lại (qua `activeTabSwitcherRefresh`,
        // đã gọi ở mọi chỗ ghim/bỏ ghim — xem 3 chỗ đã sửa: nút ghim đơn,
        // `doPinSelectedForBackground`/`doUnpinSelectedFromBackground`,
        // và `onResume()` sau khi đóng Cài đặt) huy hiệu này tự đúng theo
        // dữ liệu mới nhất, không cache riêng.
        val tabHostForPinBadge = try { android.net.Uri.parse(tab.url).host } catch (e: Exception) { null }
        val tabIsPinnedForBackground = tabHostForPinBadge != null &&
            com.colablive.keeper.features.keepalive.BackgroundKeepAliveFeature.isDomainPinned(this, slotIndex, tabHostForPinBadge)
        if (tabIsPinnedForBackground) {
            titleRow.addView(android.widget.ImageView(this).apply {
                setImageResource(android.R.drawable.ic_menu_myplaces)
                contentDescription = "Đang ghim chạy nền"
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply {
                    marginEnd = dp(4)
                }
            })
        }
        titleRow.addView(TextView(this).apply {
            text = (if (tab.isPrivate) "🕶 " else "") + (if (tab.id in selectedTabIds) "✓ " else "") + (tab.title.takeIf { it.isNotEmpty() } ?: tab.url)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            if (tab.isPrivate) setTextColor(Color.WHITE)
            if (tab.id in selectedTabIds) setTextColor(Color.parseColor("#0B57D0"))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (!selectionModeActive) {
            titleRow.addView(ImageButton(this).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                setBackgroundColor(Color.TRANSPARENT)
                layoutParams = LinearLayout.LayoutParams(36, 36)
                setOnClickListener {
                    if (engine.getTabs().size <= 1) {
                        Toast.makeText(this@MainActivity, "Không thể đóng tab cuối cùng", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    engine.closeTab(tab.id)
                    tabThumbnails.remove(tab.id)
                    refreshTabBar()
                    dialog.dismiss()
                    showTabSwitcher() // vẽ lại lưới cho khớp danh sách mới
                }
            })
        }
        card.addView(titleRow)

        card.addView(TextView(this).apply {
            text = tab.url
            textSize = 11f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(Color.GRAY)
        })
        return card
    }

    private fun createNewTabCard(dialog: Dialog): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#F1F3F4"))
                setStroke(dp(1), Color.parseColor("#DADCE0"))
            }
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            isClickable = true
            foreground = androidx.core.content.ContextCompat.getDrawable(this@MainActivity, android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId)
            addView(TextView(this@MainActivity).apply {
                text = "+"
                textSize = 28f
                setTextColor(Color.parseColor("#1A73E8"))
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = "Tab mới"
                textSize = 13f
                setTextColor(Color.parseColor("#1A73E8"))
                gravity = Gravity.CENTER
            })
            setOnClickListener {
                engine.createTab("https://www.google.com")
                refreshTabBar()
                dialog.dismiss()
            }
        }
    }

    /**
     * Dialog danh sách có ICON THẬT (không chỉ chữ) — thay cho
     * `AlertDialog.setItems()` cũ (chỉ hỗ trợ text đơn thuần, không gắn
     * được icon riêng cho từng dòng). Dùng chung cho menu chính lẫn menu
     * con "Tải xuống & Media".
     */
    private fun showIconMenu(title: String, items: List<Triple<Int, String, () -> Unit>>) {
        val density = resources.displayMetrics.density
        val listLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val dialog = AlertDialog.Builder(this).setTitle(title).setView(listLayout).create()
        items.forEach { (iconRes, label, action) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (14 * density).toInt())
                isClickable = true
                isFocusable = true
                val ripple = android.util.TypedValue().also {
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
                }.resourceId
                setBackgroundResource(ripple)
                setOnClickListener {
                    dialog.dismiss()
                    action()
                }
            }
            row.addView(ImageView(this).apply {
                setImageResource(iconRes)
                setColorFilter(Color.DKGRAY)
            }, LinearLayout.LayoutParams((24 * density).toInt(), (24 * density).toInt()).apply {
                marginEnd = (20 * density).toInt()
            })
            row.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(Color.BLACK)
            })
            listLayout.addView(row)
        }
        dialog.show()
    }

    private fun showDownloadMediaMenu() {
        val menuItems = mutableListOf(
            Triple(android.R.drawable.stat_sys_download, "IDM Downloads") { showIDMDialog() },
            // TÍNH NĂNG MỚI (người dùng yêu cầu) — "hiện những file đã tải
            // xuống". Đặt NGAY CẠNH "IDM Downloads" để dễ phân biệt: mục
            // trên là danh sách ĐANG TẢI (RAM, mất sau restart), mục này
            // là danh sách ĐÃ TẢI XONG (lưu bền, luôn còn sau restart).
            Triple(android.R.drawable.ic_menu_agenda, "📂 File đã tải xuống") { showDownloadedFilesList() },
            Triple(android.R.drawable.ic_menu_slideshow, "Sniff Media") { showSniffDialog() }
        )
        // BUG THẬT đã sửa: catchDownload()/downloadYouTube() đã được viết
        // sẵn đầy đủ (dùng NewPipeExtractor, xem
        // NewPipeDownloaderImpl.kt) nhưng KHÔNG CÓ NÚT NÀO trong toàn bộ
        // app gọi tới khi đang xem 1 video/playlist thật — người dùng chỉ
        // có cách dán URL tay vào "Test tải YouTube" trong Settings. Thêm
        // đúng 1 mục lấy URL tab hiện tại, tự nhận diện video/playlist.
        val currentUrl = engine.currentUrl()
        if (currentUrl != null && (currentUrl.contains("youtube.com") || currentUrl.contains("youtu.be"))) {
            // BUG THẬT (người dùng báo "không có lựa chọn tải audio"):
            // trước đây bấm thẳng vào `downloadYouTube()` (chỉ video), hoàn
            // toàn không có cách chọn "chỉ tải âm thanh" cho video ĐƠN LẺ —
            // dù `downloadYouTubeAudio()` đã viết sẵn đầy đủ, chỉ chưa có
            // nút nào gọi tới khi đang xem 1 video (khác playlist, ĐÃ có
            // lựa chọn audio-only trong `showPlaylistSelectionDialog`).
            // Sửa: hỏi Video/Audio trước khi tải, giống hệt cách playlist
            // đã làm — nhất quán trong toàn app.
            menuItems.add(Triple(android.R.drawable.stat_sys_download_done, "⬇️ Tải video YouTube đang xem") {
                AlertDialog.Builder(this)
                    .setTitle("Tải dạng nào?")
                    .setItems(arrayOf("🎬 Video (kèm âm thanh)", "🎵 Chỉ âm thanh")) { _, which ->
                        val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                        // FALLBACK: NewPipeExtractor lỗi thì tự động thử Sniff
                        // Media trên đúng trang đang mở, KHÔNG đảm bảo tìm
                        // được (StreamSniffer chỉ regex tĩnh HTML) — nhưng
                        // còn hơn im lặng.
                        if (which == 0) {
                            downloadFeature?.catchDownload(this, currentUrl, engine = engine, onYouTubeFailure = { showSniffDialog() })
                        } else {
                            downloadFeature?.downloadYouTubeAudio(this, currentUrl)
                        }
                        Toast.makeText(this, "Đang tải...", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            })
        }
        menuItems.add(Triple(android.R.drawable.ic_menu_save, "💾 Lưu Trang Web") { showWebArchiveDialog() })
        menuItems.add(Triple(android.R.drawable.ic_menu_preferences, "⚙️ Cài đặt Download") { showDownloadPolicySettings() })
        showIconMenu("Tải xuống & Media", menuItems)
    }

    private fun showMenu() {
        // BUG THẬT đã sửa: mục "Features" trước đây gọi thẳng
        // FeatureSettingsActivity nhưng KHÔNG truyền "feature_id" (activity
        // đó cần biết đúng 1 feature nào để hiển thị) — bấm vào chỉ hiện
        // Toast "Không tìm thấy feature" rồi tự đóng ngay, không dẫn tới
        // đâu cả. "Settings" (mục đầu) mới là màn hình liệt kê đúng TẤT CẢ
        // feature (kể cả "Phát media nền" mới thêm) rồi mới mở đúng 1 cái
        // khi bấm vào — đã bỏ mục "Features" trùng lặp/hỏng này.
        //
        // THEO YÊU CẦU "gọn gàng giống Chrome": trước đây danh sách PHẲNG
        // 12 mục, trộn lẫn thao tác duyệt web hay dùng (Tiến tới, Tải lại,
        // Lịch sử...) với công cụ debug/dev ít dùng (Debug Log, Test Cookie
        // Leak, Proxy Config, Xem crash gần nhất) — Chrome KHÔNG bao giờ để
        // công cụ nâng cao lẫn vào menu chính, luôn gom riêng. Gom 4 mục
        // debug/dev đó vào 1 submenu "🛠 Công cụ nâng cao" (giống cách đã
        // gom "Tải xuống & Media" ở phiên trước) — menu chính còn 9 mục,
        // toàn thao tác hay dùng khi duyệt web thường ngày.
        showIconMenu("Menu (Slot $slotIndex)", listOf(
            Triple(
                android.R.drawable.ic_menu_zoom,
                if (engine.isDesktopMode()) "🖥 Đang xem máy tính (bấm để về di động)" else "🖥 Xem bằng máy tính"
            ) { engine.toggleDesktopMode() },
            Triple(android.R.drawable.ic_menu_zoom, "🔍 Thu phóng trang này") { showZoomDialog() },
            Triple(android.R.drawable.ic_menu_search, "🔎 Tìm trong trang") { showFindInPageBar() },
            Triple(android.R.drawable.stat_sys_download, "📥 Tải xuống & Media") { showDownloadMediaMenu() },
            Triple(android.R.drawable.ic_lock_lock, "🕶 Tab ẩn danh mới") {
                val tab = engine.createTab("about:blank", isPrivate = true)
                switchToTabCapturingThumbnail(tab.id) // createTab() chỉ tự chuyển khi CHƯA có tab nào — cần chủ động chuyển ở đây vì thường đã có tab khác đang mở
                refreshTabBar()
                updatePrivateModeUI()
                Toast.makeText(this, "Đã mở tab ẩn danh — không lưu lịch sử, không khôi phục lại sau khi đóng app", Toast.LENGTH_LONG).show()
            },
            Triple(android.R.drawable.ic_menu_recent_history, "🕐 Lịch sử") {
                startActivityForResult(Intent(this, HistoryActivity::class.java).putExtra("slot_index", slotIndex), RC_HISTORY)
            },
            // TÍNH NĂNG MỚI (người dùng yêu cầu): "thẻ đã đóng gần đây, mở
            // lại vẫn còn lịch sử đằng sau nó" — KHÁC với "🕐 Lịch sử" ở
            // trên (danh sách URL đã ghé qua, mở lại chỉ tới đúng URL đó,
            // không có back/forward). Mục này mở lại ĐÚNG session đã đóng
            // (dùng `savedState` — xem `ClosedTabEntry`/`reopenClosedTab`),
            // bấm Back trong tab vừa mở lại vẫn lùi được về đúng các trang
            // đã ghé qua TRƯỚC KHI đóng tab, y hệt Chrome/Firefox thật.
            Triple(android.R.drawable.ic_menu_recent_history, "🗂 Thẻ đã đóng gần đây") { showRecentlyClosedTabsDialog() },
            // BUG THẬT tự gây ra, phát hiện khi thêm mục Zoom cạnh đây:
            // `BookmarkActivity`/`RC_BOOKMARKS`/`BrowserBookmarks` đã xây
            // xong hoàn chỉnh ở phiên trước nhưng QUÊN HẲN không có nút/mục
            // menu nào thực sự mở nó — tính năng coi như vô hình với người
            // dùng dù code đã đầy đủ.
            Triple(android.R.drawable.ic_menu_recent_history, "⭐ Bookmark đã lưu") {
                startActivityForResult(Intent(this, BookmarkActivity::class.java).putExtra("slot_index", slotIndex), RC_BOOKMARKS)
            },
            // SỬA THÊM (cùng gốc bug icon Recent Apps — xem chú thích lớn ở
            // AndroidManifest.xml về `relinquishTaskIdentity`): thêm cờ
            // FLAG_ACTIVITY_NEW_TASK để ProfilePickerActivity mở TASK RIÊNG
            // của chính nó, không chui chung vào task của MainActivity nữa
            // — loại bỏ hẳn khả năng nó tạm thời trở thành "task identity"
            // của khe đang mở, dù đã bỏ relinquishTaskIdentity ở manifest.
            Triple(android.R.drawable.ic_menu_gallery, "Chuyển Khe") { startActivity(Intent(this, ProfilePickerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
            Triple(android.R.drawable.ic_menu_send, "📋 Sao chép URL hiện tại") { copyToClipboard("URL", engine.currentUrl() ?: "") },
            Triple(android.R.drawable.ic_menu_manage, "Settings") {
                startActivity(Intent(this, SettingsActivity::class.java).putExtra("slot_index", slotIndex))
            },
            // BUG THẬT tự phát hiện: hàm showGroupAssignDialog() được viết
            // đầy đủ từ trước, nhưng lối vào cũ (long-press card trong
            // lưới tab) đã bị đổi ưu tiên sang kéo-thả đổi vị trí — comment
            // ở chỗ đó CLAIM "vẫn truy cập được qua menu 3 chấm" nhưng
            // KHÔNG HỀ có mục nào ở đây thật sự gọi hàm này — dead code,
            // đúng khớp báo cáo "gom nhóm tab mất luôn". Thêm lại đây,
            // dùng đúng tab đang active.
            Triple(android.R.drawable.ic_menu_gallery, "🏷 Nhóm tab") {
                val tab = engine.getActiveTab()
                if (tab == null) {
                    Toast.makeText(this, "Không có tab nào đang mở", Toast.LENGTH_SHORT).show()
                } else {
                    showGroupAssignDialog(tab) { refreshTabBar() }
                }
            },
            // TÍNH NĂNG MỚI (người dùng yêu cầu): lối vào THỨ 2 (ngoài dán
            // trực tiếp vào urlBar) cho tính năng "nhập nhiều URL thành
            // nhiều tab" — dùng khi muốn gõ tay/dán mà không thao tác qua
            // ô địa chỉ (VD copy từ 1 ghi chú dài, hoặc soạn ngay trong app).
            Triple(android.R.drawable.ic_menu_edit, "📑 Mở nhiều URL") { showBulkOpenUrlsDialog() },
            Triple(android.R.drawable.ic_menu_preferences, "🛠 Công cụ nâng cao") { showAdvancedToolsMenu() }
        ))
    }

    /**
     * TÍNH NĂNG MỚI (người dùng yêu cầu) — Tìm trong trang.
     *
     * Mở thanh tìm kiếm (`findBarContainer`), focus vào ô nhập và bật bàn
     * phím ngay (giống Chrome bấm "Tìm trong trang" là gõ được luôn, không
     * cần chạm thêm 1 lần vào ô input).
     */
    private fun showFindInPageBar() {
        findBarContainer.visibility = View.VISIBLE
        findBarInput.requestFocus()
        findBarCounter.text = ""
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.showSoftInput(findBarInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        // Nếu ô input đã có sẵn chữ từ lần tìm trước, tìm lại luôn để
        // highlight hiện ngay khi mở lại thanh (không bắt gõ lại từ đầu).
        if (findBarInput.text.isNotEmpty()) {
            performFindInPage(findBarInput.text.toString(), forward = true)
        }
    }

    /**
     * Đóng thanh tìm kiếm + xoá highlight trên trang qua
     * `engine.clearFindInPage()` (gọi `SessionFinder.clear()` thật —
     * không xoá thì vệt tô sáng vàng của lần tìm trước vẫn còn lưu lại
     * trên trang dù đã đóng thanh tìm kiếm, gây khó hiểu).
     */
    private fun hideFindInPageBar() {
        findBarContainer.visibility = View.GONE
        engine.clearFindInPage()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(findBarInput.windowToken, 0)
    }

    /**
     * Gọi `engine.findInPage()` (native `SessionFinder` — xem
     * `GeckoViewEngine.findInPage()`) và cập nhật ô đếm "3/12" theo kết
     * quả thật trả về. `total=0` (kể cả khi query không rỗng) nghĩa là
     * KHÔNG tìm thấy khớp nào trên trang — hiện rõ "Không tìm thấy" thay
     * vì để trống gây hiểu lầm là chưa tìm.
     */
    private fun performFindInPage(query: String, forward: Boolean) {
        if (query.isEmpty()) {
            findBarCounter.text = ""
            engine.clearFindInPage()
            return
        }
        engine.findInPage(query, forward = forward) { current, total ->
            findBarCounter.text = if (total == 0) "Không tìm thấy" else "$current/$total"
        }
    }

    /**
     * Nút "Thu phóng" giống hệt Chrome (ảnh người dùng gửi) — dùng ĐƯỢC
     * CHO BẤT KỲ TRANG NÀO theo ý muốn, khác hẳn zoom TỰ ĐỘNG chỉ áp cho
     * domain trong danh sách ngoại lệ (`applyDesktopLayoutZoomIfNeeded`).
     * Tái dùng ĐÚNG kỹ thuật đã xác nhận hoạt động (CSS `zoom`, GeckoView
     * 145 đã hỗ trợ — xem chú thích ở hàm đó) thay vì đoán 1 API zoom gốc
     * khác của GeckoView chưa từng tra cứu/xác nhận.
     */
    private fun showZoomDialog() {
        val currentUrl = engine.currentUrl() ?: ""
        var currentPercent = com.colablive.keeper.core.ZoomPrefs.getZoomForUrl(this, slotIndex, currentUrl)
        val label = TextView(this).apply {
            text = "$currentPercent%"
            textSize = 20f
            gravity = Gravity.CENTER
        }
        fun applyZoom() {
            com.colablive.keeper.core.ZoomPrefs.setZoomForUrl(this, slotIndex, currentUrl, currentPercent)
            // FIX BUG THẬT (người dùng báo: chỉnh zoom +/- không phản ứng
            // ngay, phải chuyển tab đi rồi quay lại mới đúng): script cũ
            // "document.documentElement.style.zoom = X; 'da chinh ...'" —
            // 2 câu lệnh phân tách bằng dấu ";" GIỮA DÒNG (không phải cuối
            // dòng) — khi content.js bọc "return (" + script + ")" (fix
            // chống undefined ở content.js) thì trở thành
            // "return (a = X; 'text')" — CÚ PHÁP JS KHÔNG HỢP LỆ (không thể
            // có dấu ";" ngăn cách statement bên trong 1 cặp ngoặc biểu
            // thức) → NÉM SYNTAX ERROR NGAY LÚC PARSE → toàn bộ script
            // KHÔNG CHẠY, kể cả phần gán zoom — bị content.js nuốt lỗi âm
            // thầm. Xác nhận lại bằng Node: chạy thử chính script này qua
            // đúng cơ chế bọc của content.js → "Unexpected token ';'".
            // `applyZoomCombined()` (chạy khi chuyển tab) dùng dạng IIFE
            // (function(){...})() nên KHÔNG bị lỗi này — đó là lý do
            // "chuyển tab quay lại thì đúng" (đường ống khác, không lỗi).
            // Sửa: KHÔNG tự viết script tay nữa — gọi lại đúng hàm
            // `reapplyZoomForActiveTab()` đã dùng dạng IIFE, đã chứng minh
            // hoạt động đúng ở chỗ khác.
            engine.reapplyZoomForActiveTab()
            label.text = "$currentPercent%"
        }
        val minusBtn = Button(this).apply {
            text = "－"
            setOnClickListener {
                if (currentPercent > 50) { currentPercent -= 10; applyZoom() }
            }
        }
        val plusBtn = Button(this).apply {
            text = "＋"
            setOnClickListener {
                if (currentPercent < 200) { currentPercent += 10; applyZoom() }
            }
        }
        val resetBtn = Button(this).apply {
            text = "Đặt lại"
            setOnClickListener { currentPercent = 100; applyZoom() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(32, 24, 32, 24)
            addView(minusBtn)
            addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { gravity = Gravity.CENTER })
            addView(plusBtn)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row)
            addView(resetBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Thu phóng trang này")
            .setView(container)
            .setPositiveButton("Xong", null)
            .show()
    }

    /**
     * Gom 4 mục debug/dev trước đây rải rác trong menu chính (chỉ người
     * phát triển mới cần dùng thường xuyên, người dùng thường không đụng
     * tới) — theo đúng cách Chrome KHÔNG bao giờ để công cụ nâng cao lẫn
     * vào menu duyệt web hàng ngày.
     */
    private fun showAdvancedToolsMenu() {
        showIconMenu("Công cụ nâng cao", listOf(
            Triple(android.R.drawable.ic_menu_info_details, "Debug Log") {
                startActivity(Intent(this, DebugLogActivity::class.java).putExtra("slot_index", slotIndex))
            },
            Triple(android.R.drawable.ic_menu_mapmode, "Proxy Config") { showProxyDialog() },
            Triple(android.R.drawable.ic_menu_add, "🧩 Quản lý Addon") { showAddonManagerDialog() },
            Triple(android.R.drawable.ic_menu_view, "Test Cookie Leak") { showLeakTestDialog() },
            Triple(android.R.drawable.ic_dialog_alert, "🩹 Xem crash gần nhất") {
                startActivity(Intent(this, CrashReportActivity::class.java).putExtra("slot_index", slotIndex))
            }
        ))
    }

    /**
     * TÍNH NĂNG THIẾU (người dùng báo: "Ko có phần addon để thêm addon từ
     * bên ngoài vào") — XÁC NHẬN đúng bằng cách grep toàn bộ MainActivity.kt
     * + SettingsActivity.kt: không có bất kỳ chỗ nào gọi
     * `webExtensionController.install()` hay có UI liên quan tới addon
     * ngoài (chỉ có 3 extension NỘI BỘ tự cài sẵn lúc khởi động — eval
     * bridge, proxy config, fingerprint spoof — không phải addon do người
     * dùng chọn). Thêm mới, dùng đúng API công khai của GeckoView
     * (`WebExtensionController.install(String uri)`) — đã tra cứu javadoc
     * chính thức (mozilla.github.io/geckoview/javadoc, class
     * WebExtensionController) để xác nhận chữ ký/hành vi thật, KHÔNG đoán.
     *
     * GIỚI HẠN THẬT QUAN TRỌNG tìm được khi tra cứu (không giấu, phải báo
     * rõ cho người dùng ngay trong UI, không chỉ trong comment): tài liệu
     * chính thức của chính `install(String)` ghi rõ — "Installed extensions
     * through this method need to be signed by Mozilla". Đây là giới hạn
     * CỨNG của Gecko bản Release (GeckoView chính là loại này) — pref
     * `xpinstall.signatures.required=false` chỉ có tác dụng trên
     * Nightly/DevEdition, KHÔNG áp dụng được cho GeckoView Release dùng
     * trong dự án này. Nghĩa là: file `.xpi` người dùng tự build hoặc tải
     * từ nguồn không qua ký của Mozilla (addons.mozilla.org) SẼ BỊ TỪ CHỐI
     * cài, không phải lỗi của code này — phải cảnh báo rõ trong dialog,
     * nếu không người dùng sẽ tưởng tính năng bị hỏng khi thật ra đang hoạt
     * động đúng như thiết kế của Gecko.
     *
     * CHƯA XÁC NHẬN (rủi ro còn lại, cần test thật): `install()` cần
     * `WebExtensionController.PromptDelegate.onInstallPromptRequest(...)`
     * để xác nhận quyền — dự án CHƯA đăng ký delegate này ở bất kỳ đâu.
     * Chưa rõ khi thiếu delegate, GeckoResult trả về sẽ tự treo mãi hay tự
     * từ chối — cần log thật sau khi build để biết, không khẳng định chắc
     * ở đây.
     */
    private fun showAddonManagerDialog() {
        val installedAddons = AppPrefs.getString(this, slotIndex, "installed_addons_csv", "")
            .split("|").filter { it.isNotBlank() }

        /**
         * BUG THẬT tìm ra (người dùng báo: "UI addon extension chỉ có cái
         * cảnh báo chứ chả có gì để thêm extension vào cả"): code TRƯỚC ĐÂY
         * gọi CẢ `.setMessage(...)` (đoạn cảnh báo dài về giới hạn ký addon)
         * VÀ `.setItems(...)` (3 lựa chọn thật: cài từ file/URL/xem danh
         * sách) TRÊN CÙNG 1 `AlertDialog`. Tra tài liệu chính thức Android
         * (developer.android.com/guide/topics/ui/dialogs) xác nhận: "Content
         * area: this can display a message, list, or other custom layout"
         * — CHỈ MỘT trong 3 thứ đó chiếm được vùng nội dung, không phải cả
         * 2 cùng lúc. Dùng chung `setMessage()` + `setItems()` là SAI CÁCH
         * DÙNG API, khiến 1 trong 2 bị đè mất tuỳ phiên bản/ROM Android —
         * đúng khớp triệu chứng "chỉ thấy cảnh báo, không có gì để bấm".
         *
         * SỬA: tách thành 2 bước tuần tự bằng 2 dialog THẬT riêng biệt
         * (API chuẩn, không có gì mơ hồ) — dialog 1 CHỈ hiện cảnh báo
         * (setMessage, có nút "Đã hiểu, tiếp tục"); bấm xong mới mở dialog
         * 2 CHỈ hiện danh sách lựa chọn thật (setItems, không kèm message).
         */
        AlertDialog.Builder(this)
            .setTitle("Quản lý Addon (Khe $slotIndex)")
            .setMessage(
                "⚠️ Giới hạn CỨNG của Gecko (đã tra cứu tài liệu chính thức, " +
                    "không phải lỗi app này): chỉ addon ĐÃ ĐƯỢC MOZILLA KÝ mới " +
                    "cài được. File .xpi tự build/tải từ GitHub thường sẽ bị từ " +
                    "chối. Muốn dùng addon riêng, cần ký qua addons.mozilla.org " +
                    "(kể cả dạng \"self-distribution\" không đăng công khai) " +
                    "trước khi cài ở đây.\n\n" +
                    "✅ Giờ có thể duyệt THẲNG tới addons.mozilla.org như trình " +
                    "duyệt thường, bấm \"Thêm vào Firefox\" — app tự phát hiện " +
                    "và cài luôn, không cần tự tìm/dán link .xpi nữa."
            )
            .setPositiveButton("Đã hiểu, tiếp tục") { _, _ ->
                showAddonOptionsDialog(installedAddons)
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun showAddonOptionsDialog(installedAddons: List<String>) {
        val items = arrayOf(
            "📂 Cài từ file .xpi trên máy",
            "🔗 Cài từ URL (link .xpi trực tiếp)",
            "📋 Xem addon đã cài (${installedAddons.size})"
        )
        AlertDialog.Builder(this)
            .setTitle("Quản lý Addon (Khe $slotIndex)")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pickAddonFile()
                    1 -> showInstallAddonByUrlDialog()
                    2 -> {
                        if (installedAddons.isEmpty()) {
                            Toast.makeText(this, "Chưa cài addon nào", Toast.LENGTH_SHORT).show()
                        } else {
                            AlertDialog.Builder(this)
                                .setTitle("Addon đã cài")
                                .setItems(installedAddons.map { it.substringAfter("::") }.toTypedArray(), null)
                                .setNegativeButton("Đóng", null)
                                .show()
                        }
                    }
                }
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun pickAddonFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            // Nhiều file manager không tự gán đúng MIME "application/x-xpinstall"
            // cho file .xpi (thực chất là 1 file zip đổi đuôi) — chấp nhận
            // rộng để không loại nhầm file hợp lệ, phần mở rộng được kiểm
            // lại sau khi copy nếu cần.
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/x-xpinstall", "application/zip", "application/octet-stream"))
        }
        startActivityForResult(Intent.createChooser(intent, "Chọn file .xpi"), RC_ADDON_INSTALL)
    }

    private fun showInstallAddonByUrlDialog() {
        val input = EditText(this).apply {
            hint = "https://.../addon.xpi"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        AlertDialog.Builder(this)
            .setTitle("Cài addon từ URL")
            .setMessage("Dán URL trực tiếp tới file .xpi (không phải trang addons.mozilla.org — trang đó không trả về file .xpi trực tiếp qua link thường):")
            .setView(input)
            .setPositiveButton("Cài") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotBlank()) installAddonFromUrl(url)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun installAddonFromPickedUri(uri: android.net.Uri) {
        val addonDir = java.io.File(filesDir, "addons").apply { mkdirs() }
        val destFile = java.io.File(addonDir, "addon_${System.currentTimeMillis()}.xpi")
        Thread {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().use { output -> input.copyTo(output) }
                } ?: throw java.io.IOException("openInputStream trả về null")
                runOnUiThread { installAddonFromLocalFile(destFile) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Không đọc được file: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun installAddonFromUrl(url: String) {
        val progressDialog = AlertDialog.Builder(this)
            .setTitle("Đang tải addon...")
            .setMessage(url)
            .setCancelable(false)
            .create()
        progressDialog.show()
        Thread {
            try {
                val addonDir = java.io.File(filesDir, "addons").apply { mkdirs() }
                val destFile = java.io.File(addonDir, "addon_${System.currentTimeMillis()}.xpi")
                val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.inputStream.use { input -> destFile.outputStream().use { output -> input.copyTo(output) } }
                runOnUiThread {
                    progressDialog.dismiss()
                    installAddonFromLocalFile(destFile)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progressDialog.dismiss()
                    Toast.makeText(this, "Tải addon thất bại: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun installAddonFromLocalFile(file: java.io.File) {
        val runtime = com.colablive.keeper.core.GeckoRuntimeProvider.getRuntime(slotIndex)
        if (runtime == null) {
            Toast.makeText(this, "GeckoRuntime của khe này chưa sẵn sàng, thử lại sau", Toast.LENGTH_SHORT).show()
            return
        }
        val fileUri = "file://${file.absolutePath}"
        runtime.webExtensionController.install(fileUri)
            .accept(
                { ext ->
                    if (ext != null) {
                        val name = ext.metaData?.name ?: file.name
                        val existing = AppPrefs.getString(this, slotIndex, "installed_addons_csv", "")
                        val updated = if (existing.isBlank()) "${ext.id}::$name" else "$existing|${ext.id}::$name"
                        AppPrefs.setString(this, slotIndex, "installed_addons_csv", updated)
                        runOnUiThread {
                            Toast.makeText(this, "✅ Đã cài addon: $name", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                { error ->
                    runOnUiThread {
                        Toast.makeText(this, "❌ Cài addon thất bại: $error", Toast.LENGTH_LONG).show()
                    }
                }
            )
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(label, text))
        Toast.makeText(this, "Đã sao chép: $text", Toast.LENGTH_SHORT).show()
    }

    /** Menu hiện ra khi nhấn giữ 1 liên kết trên trang (trước đây không làm gì cả). */
    /**
     * TÍNH NĂNG MỞ RỘNG (người dùng gửi ảnh chụp menu link của Chrome, hỏi
     * có làm được giống vậy không) — menu 4 mục cũ quá sơ sài so với Chrome
     * thật. Thêm các mục Chrome có mà giữ được ý nghĩa trong app này:
     * "Mở trong thẻ mới trong nhóm" (thêm tab mới vào ĐÚNG nhóm của tab
     * đang xem — nếu tab đang xem chưa thuộc nhóm nào thì tự tạo 1 nhóm 1-
     * tab mới, giống hệt hành vi Chrome thật), "Mở trong thẻ Ẩn danh"
     * (dùng thẳng `createTab(uri, isPrivate=true)` có sẵn), tách riêng
     * "Sao chép địa chỉ liên kết" (URL) và "Sao chép văn bản liên kết"
     * (chữ hiển thị của link, nếu có — nhiều link không có text thấy được,
     * ẩn mục này khi rỗng), và "Tải đường liên kết xuống" (nối thẳng vào
     * `DownloadManagerFeature.catchDownload` đã có sẵn, tự xử lý cả
     * trường hợp là link YouTube).
     *
     * CHỦ Ý KHÔNG THÊM: "Xem trước trang" (cần dựng hẳn 1 WebView preview
     * nổi riêng, phức tạp không tương xứng với 1 menu item) và "Thêm vào
     * danh sách đọc" (app này chưa có khái niệm reading-list nào cả — thêm
     * nút giả không hoạt động vi phạm đúng nguyên tắc "không giả vờ đã
     * xong" đã áp dụng xuyên suốt dự án, xem mục 33.4 trong
     * PROJECT_STATUS.md). "Mở trong cửa sổ mới" của Chrome không có khái
     * niệm tương đương trực tiếp trong app 4-khe này — giữ nguyên "Mở ở
     * khe khác…" đã có, vì đó chính là thứ gần nghĩa nhất (mở sang 1 tiến
     * trình/cửa sổ riêng biệt khác).
     */
    private fun showLinkContextMenu(uri: String, linkText: String?) {
        val activeTab = engine.getActiveTab()
        val hasLinkText = !linkText.isNullOrBlank() && linkText.trim() != uri.trim()
        val items = mutableListOf(
            "Mở trong tab mới",
            "Mở trong tab mới, thêm vào nhóm",
            "Mở trong tab Ẩn danh",
            "Mở ở khe khác…",
            "Sao chép địa chỉ liên kết"
        )
        if (hasLinkText) items.add("Sao chép văn bản liên kết")
        items.add("Tải đường liên kết xuống")
        items.add("Chia sẻ liên kết")

        AlertDialog.Builder(this)
            .setTitle(linkText?.takeIf { it.isNotBlank() } ?: uri)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "Mở trong tab mới" -> {
                        // FIX BUG THẬT (mục 76 PROJECT_STATUS.md) — gán opener
                        // để nút Back sau này quay đúng về tab này thay vì
                        // nhảy về tab 0 (xem chú thích đầy đủ ở createTab()).
                        engine.createTab(uri, openerTabId = activeTab?.id)
                        refreshTabBar()
                    }
                    "Mở trong tab mới, thêm vào nhóm" -> {
                        val newTab = engine.createTab(uri, openerTabId = activeTab?.id)
                        val groupId = activeTab?.groupId
                            ?: engine.createGroup("Nhóm mới", "#1A73E8").id
                        engine.setTabGroup(newTab.id, groupId)
                        refreshTabBar()
                    }
                    "Mở trong tab Ẩn danh" -> {
                        engine.createTab(uri, isPrivate = true, openerTabId = activeTab?.id)
                        refreshTabBar()
                    }
                    "Mở ở khe khác…" -> showOpenInSlotDialog(uri)
                    "Sao chép địa chỉ liên kết" -> copyToClipboard("link", uri)
                    "Sao chép văn bản liên kết" -> copyToClipboard("link text", linkText ?: "")
                    "Tải đường liên kết xuống" -> DownloadManagerFeature.catchDownload(this, uri, engine = engine)
                    "Chia sẻ liên kết" -> {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, uri)
                        }
                        startActivity(Intent.createChooser(shareIntent, "Chia sẻ liên kết"))
                    }
                }
            }
            .show()
    }

    /** Mở 1 URL cụ thể ở 1 khe KHÁC (không phải khe đang đứng) — mở tiến trình khe đó kèm URL qua extra "open_url". */
    private fun showOpenInSlotDialog(uri: String) {
        val slotOptions = (0..ProfileSlots.SLOT_COUNT).filter { it != slotIndex }
        val labels = slotOptions.map { ProfileSlots.getSlotName(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Mở liên kết ở khe nào?")
            .setItems(labels) { _, which ->
                val targetSlot = slotOptions[which]
                val className = ProfileSlots.componentClassNameForSlot(targetSlot)
                val intent = Intent().apply {
                    component = ComponentName(packageName, className)
                    putExtra("open_url", uri)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    // Người dùng VỪA chọn đích ở dialog này — không phải mở
                    // mới từ icon màn hình chính, bỏ qua màn hình chọn khe.
                    putExtra(EXTRA_SKIP_PICKER, true)
                }
                startActivity(intent)
            }
            .show()
    }

    /**
     * BUG THẬT (người dùng chỉ ra: "Proxy chỉ là cái vỏ ko hoạt động") —
     * XÁC NHẬN đúng bằng cách đọc code, không phải suy đoán: dialog này
     * TRƯỚC ĐÂY chỉ ĐỌC (`AppPrefs.getInt/getString`) và HIỂN THỊ cấu hình,
     * với dòng chỉ dẫn "Vào Settings > Fingerprint Spoof để thay đổi" —
     * nhưng grep toàn bộ `SettingsActivity.kt` xác nhận KHÔNG CÓ bất kỳ
     * dòng nào đọc/ghi "proxy_type"/"proxy_host"/"proxy_port" ở đó cả. Tức
     * là chỉ dẫn trong dialog trỏ tới 1 màn hình KHÔNG TỒN TẠI chức năng đó
     * — không có cách nào trong toàn bộ app để người dùng thực sự NHẬP
     * host/port/user/pass, nên `proxy_type` mãi mãi giữ giá trị mặc định 0
     * (Direct), khiến `registerProxyExtensionIfConfigured()` trong
     * `GeckoRuntimeProvider.kt` (cơ chế BACKEND đã làm đúng, đã kiểm tra —
     * đọc đúng key, đẩy đúng config `{type, host, port, username,
     * password}` xuống WebExtension `proxy_config`) không bao giờ có gì để
     * chạy. Đúng nghĩa "vỏ không hoạt động" — không phải vì backend sai, mà
     * vì THIẾU HẲN UI nhập liệu.
     *
     * Sửa: biến dialog này thành FORM NHẬP THẬT (loại proxy + host + port +
     * user/pass), lưu qua đúng các key mà `GeckoRuntimeProvider` đã đọc sẵn
     * — không cần sửa gì ở backend, chỉ cần nối UI vào đúng chỗ đã có sẵn.
     */
    private fun showProxyDialog() {
        val currentType = AppPrefs.getInt(this, slotIndex, "proxy_type", 0)
        val currentHost = AppPrefs.getString(this, slotIndex, "proxy_host", "")
        val currentPort = AppPrefs.getString(this, slotIndex, "proxy_port", "")
        val currentUser = AppPrefs.getString(this, slotIndex, "proxy_user", "")
        val currentPass = AppPrefs.getString(this, slotIndex, "proxy_pass", "")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }

        val typeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rdDirect = RadioButton(this).apply { id = 101; text = "Direct" }
        val rdHttp = RadioButton(this).apply { id = 102; text = "HTTP" }
        val rdSocks = RadioButton(this).apply { id = 103; text = "SOCKS5" }
        typeGroup.addView(rdDirect); typeGroup.addView(rdHttp); typeGroup.addView(rdSocks)
        typeGroup.check(when (currentType) { 1 -> 102; 2 -> 103; else -> 101 })

        val etHost = EditText(this).apply { hint = "Host (IP hoặc domain)"; setText(currentHost) }
        val etPort = EditText(this).apply {
            hint = "Port"; setText(currentPort)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val etUser = EditText(this).apply { hint = "Username (nếu có)"; setText(currentUser) }
        val etPass = EditText(this).apply {
            hint = "Password (nếu có)"; setText(currentPass)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        layout.addView(TextView(this).apply { text = "Loại proxy:" })
        layout.addView(typeGroup)
        layout.addView(etHost)
        layout.addView(etPort)
        layout.addView(etUser)
        layout.addView(etPass)
        layout.addView(TextView(this).apply {
            text = "Áp dụng qua WebExtension Proxy API — cần ĐÓNG VÀ MỞ LẠI khe " +
                "này sau khi lưu để có tác dụng (GeckoRuntimeProvider đăng ký proxy " +
                "extension lúc khe khởi động, không đổi được khi đang chạy).\n\n" +
                "⚠️ Proxy miễn phí có rủi ro bị log traffic — không dùng để đăng " +
                "nhập tài khoản quan trọng."
            textSize = 12f
            setPadding(0, dp(12), 0, 0)
        })

        AlertDialog.Builder(this)
            .setTitle("Proxy Config (Slot $slotIndex)")
            .setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("Lưu") { _, _ ->
                val type = when (typeGroup.checkedRadioButtonId) { 102 -> 1; 103 -> 2; else -> 0 }
                AppPrefs.setInt(this, slotIndex, "proxy_type", type)
                AppPrefs.setString(this, slotIndex, "proxy_host", etHost.text.toString().trim())
                AppPrefs.setString(this, slotIndex, "proxy_port", etPort.text.toString().trim())
                AppPrefs.setString(this, slotIndex, "proxy_user", etUser.text.toString().trim())
                AppPrefs.setString(this, slotIndex, "proxy_pass", etPass.text.toString())
                if (type != 0 && (etHost.text.isBlank() || etPort.text.isBlank())) {
                    Toast.makeText(this, "Đã lưu, nhưng thiếu Host/Port — GeckoRuntimeProvider sẽ bỏ qua proxy (xem log)", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Đã lưu cấu hình proxy — đóng và mở lại khe để áp dụng", Toast.LENGTH_LONG).show()
                }
            }
            .setNeutralButton("Xóa proxy (về Direct)") { _, _ ->
                AppPrefs.setInt(this, slotIndex, "proxy_type", 0)
                Toast.makeText(this, "Đã đặt lại Direct — đóng và mở lại khe để áp dụng", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun showLeakTestDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showLeakTestDialog(this, slotIndex, engine)
    }

    private fun showIDMDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showIDMDialog(this)
    }

    // TÍNH NĂNG MỚI (người dùng yêu cầu) — "hiện những file đã tải xuống".
    // Xem `DownloadManagerFeature.showDownloadedFilesList()` — KHÁC với
    // showIDMDialog() ở trên (chỉ hiện download đang chạy trong RAM, mất
    // sau khi app restart), hàm này đọc từ `DownloadHistoryStore` (lưu bền
    // trên đĩa), luôn hiện đúng file đã tải xong dù đã qua nhiều lần
    // app restart.
    private fun showDownloadedFilesList() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showDownloadedFilesList(this)
    }

    private fun showSniffDialog() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        // Lấy HTML từ trang hiện tại
        engine.evaluateJs("document.documentElement.outerHTML") { html ->
            html?.let {
                val links = downloadFeature?.sniffPage(this, it, engine.currentUrl() ?: "")
                links?.let { list ->
                    runOnUiThread {
                        downloadFeature?.showSniffedLinksDialog(this, list)
                    }
                }
            }
        }
    }

    private fun showWebArchiveDialog() {
        val currentUrl = engine.currentUrl() ?: return
        val currentTitle = engine.getActiveTab()?.title ?: "page"
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showWebArchiveDialog(this, currentUrl, currentTitle, geckoView)
    }

    private fun showDownloadPolicySettings() {
        val downloadFeature = FeatureRegistry.all().filterIsInstance<com.colablive.keeper.features.downloads.DownloadManagerFeature>().firstOrNull()
        downloadFeature?.showPolicySettings(this)
    }



    private fun showDownloadDialog(url: String, fileName: String) {
        AlertDialog.Builder(this)
            .setTitle("Tải xuống")
            .setMessage("$fileName\n$url")
            .setPositiveButton("Tải") { _, _ ->
                val downloadFeature = FeatureRegistry.all().filterIsInstance<DownloadManagerFeature>().firstOrNull()
                downloadFeature?.startDownload(this, url, fileName)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun showFilePicker(mimeTypes: Array<String>?, isMultiple: Boolean = false) {
        /**
         * ĐỔI HẲN CƠ CHẾ (không phải thử lại "copy vs không copy" — đây là
         * hướng khác hẳn, nhắm đúng vào THỜI GIAN SỐNG của quyền đọc URI,
         * chưa từng thử):
         *
         * `ACTION_GET_CONTENT` (cách cũ) cấp quyền đọc URI kết quả THƯỜNG
         * CHỈ CÓ HIỆU LỰC TRONG PHẠM VI/THỜI GIAN GẮN VỚI LƯỢT GỌI
         * ACTIVITY đó — không đảm bảo còn hiệu lực nếu việc đọc byte thật
         * xảy ra hơi trễ (bất đồng bộ, dù chỉ vài trăm mili-giây). Đây khớp
         * CHÍNH XÁC với triệu chứng đã thấy: `confirm()` (giao URI cho
         * Gecko) chạy được ngay lập tức — nhưng việc ĐỌC BYTE THẬT của
         * Gecko (bên trong tiến trình render riêng, chắc chắn có độ trễ dù
         * nhỏ) có thể xảy ra SAU KHI quyền đã hết hạn.
         *
         * `ACTION_OPEN_DOCUMENT` (Storage Access Framework) + cờ
         * `FLAG_GRANT_PERSISTABLE_URI_PERMISSION` + gọi
         * `takePersistableUriPermission()` cho quyền đọc SỐNG LÂU DÀI,
         * không phụ thuộc thời điểm đọc — đây là cơ chế CHUẨN, được tài
         * liệu Android khuyến nghị rõ ràng cho đúng tình huống "cần đọc
         * file được chọn ở 1 thời điểm sau đó, không phải ngay lập tức".
         * Nếu đúng nguyên nhân là hết hạn quyền (chưa từng thử hướng này
         * trước đây, luôn chỉ đổi qua lại data.data/clipData/copy), đây mới
         * là hướng thật sự khác, không phải lặp lại.
         */
        /**
         * BUG THẬT (xác nhận qua ảnh chụp màn hình người dùng gửi — mở "Duyệt
         * qua tệp trong các ứng dụng khác" chỉ thấy "Báo cáo lỗi", "Dấu vết
         * hệ thống", "Drive" — KHÔNG thấy "Cx File Explorer" dù app đó có cài
         * và người dùng đã khoanh đỏ chỉ rõ): `ACTION_OPEN_DOCUMENT` chỉ hiện
         * app nào đã đăng ký làm `DocumentsProvider` (Storage Access
         * Framework chuẩn) — Google Drive/Photos có đăng ký, nhưng nhiều file
         * manager bên thứ 3 (Cx File Explorer, ES File Explorer cũ, v.v.)
         * KHÔNG đăng ký DocumentsProvider, dù chúng vẫn đọc file bình thường
         * qua `ACTION_GET_CONTENT`. Đây là đánh đổi thật giữa 2 action:
         * ACTION_OPEN_DOCUMENT cho quyền đọc bền hơn (đã sửa ở #4 phía trên,
         * KHÔNG được bỏ) nhưng hẹp nguồn app hơn; ACTION_GET_CONTENT rộng
         * nguồn app hơn nhưng quyền đọc ngắn hạn hơn.
         *
         * Sửa: dùng `ACTION_GET_CONTENT` làm intent NỀN của chooser (để
         * Android liệt kê MỌI app cung cấp file, bao gồm cả file manager bên
         * thứ 3 như Cx File Explorer), rồi CHÈN THÊM `ACTION_OPEN_DOCUMENT`
         * vào qua `EXTRA_INITIAL_INTENTS` — người dùng thấy đủ cả 2 nguồn
         * trong cùng 1 hộp thoại chọn. Nếu người dùng chọn app đăng ký SAF
         * (Drive...) hiện trong danh sách gốc của getContent, quyền vẫn có
         * thể ngắn hạn hơn — nhưng ít nhất Cx File Explorer giờ xuất hiện
         * được, đúng vấn đề người dùng báo.
         */
        val openDocIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = mimeTypes?.firstOrNull() ?: "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            if ((mimeTypes?.size ?: 0) > 1) {
                putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            }
            // FIX BUG THẬT (đúng người dùng báo: "khung chat cho phép thêm
            // nhiều file cùng lúc nhưng thực tế chỉ được nhấn vào thêm có
            // một file thôi"): trang web yêu cầu chọn NHIỀU file
            // (`FilePrompt.Type.MULTIPLE`, đã có sẵn thông tin này từ
            // `onFilePromptListener` — trước đây bị BỎ QUA hoàn toàn, không
            // truyền tới đây) nhưng Intent chọn file KHÔNG hề khai báo
            // `EXTRA_ALLOW_MULTIPLE` — hệ thống Android mặc định LUÔN chỉ
            // cho chọn 1 nếu thiếu cờ này, bất kể UI trang web "cho phép"
            // thêm nhiều file đến đâu.
            if (isMultiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        val getContentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = mimeTypes?.firstOrNull() ?: "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            if ((mimeTypes?.size ?: 0) > 1) {
                putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            }
            if (isMultiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        val chooser = Intent.createChooser(getContentIntent, "Chọn file").apply {
            putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(openDocIntent))
        }
        startActivityForResult(chooser, RC_FILE_PICKER)
    }

    /**
     * BUG THẬT đã sửa — "kéo thả file từ Files app không hoạt động như
     * Chrome": code cũ ở đây gắn `setOnDragListener` riêng, và khi có file
     * thả vào thì gọi `engine.handleDropUri()` — hàm đó lại chỉ COPY file
     * vào cache rồi bắn ra 1 `CustomEvent('livebrowser:filedrop', ...)` tự
     * chế trên `window`. KHÔNG TRANG WEB THẬT NÀO lắng nghe sự kiện tự chế
     * này cả — trang web chuẩn dùng sự kiện `drop` HTML5 chuẩn với
     * `event.dataTransfer.files`, không phải sự kiện app tự đặt tên. Nghĩa
     * là kéo thả file trước giờ hoàn toàn KHÔNG hoạt động với bất kỳ trang
     * thật nào, kể cả khi copy file "thành công".
     *
     * Nghiêm trọng hơn: `View.setOnDragListener()` khi được gắn sẽ THAY THẾ
     * HẲN cơ chế xử lý kéo thả nội bộ mặc định của chính View đó (GeckoView
     * đã tự cài sẵn `onDragEvent()` để dịch `DragEvent` gốc của Android
     * thành đúng sự kiện `drop` chuẩn HTML5 cho trang web, y hệt cách Chrome
     * làm) — gắn listener tự chế ở đây đã CHE MẤT cơ chế đúng có sẵn của
     * GeckoView, không chỉ đơn thuần "thêm 1 cách kéo thả không hoạt động"
     * mà còn "chặn mất cách đã hoạt động sẵn".
     *
     * Sửa: bỏ hẳn listener tự chế — để GeckoView tự xử lý kéo thả theo đúng
     * cơ chế chuẩn nó đã có sẵn (giống Chrome/Firefox thật), không can
     * thiệp gì thêm ở tầng app nữa.
     */
    private fun setupDragDrop() {
        // SỬA LẠI (đã tra cứu lại tài liệu chính thức developer.android.com,
        // xác nhận bản sửa trước dùng API BỊA — `Window.addDragDropListener()`
        // / `DragAndDropListener` KHÔNG TỒN TẠI trong Android SDK, không có
        // trong trang tham chiếu android.view.Window chính thức).
        //
        // Sự thật đã xác nhận: drag event CHỈ có 2 cách nhận — override
        // `View.onDragEvent()` hoặc `View.OnDragListener` qua
        // `setOnDragListener()` — cả hai đều chỉ tồn tại ở cấp View, KHÔNG có
        // ở cấp Activity/Window. Không có "điểm quan sát riêng ở cấp Activity"
        // như comment gốc phía trên kỳ vọng.
        //
        // Thêm nữa: theo tài liệu concepts (Key concepts | Views | Android
        // Developers), khi 1 View con (GeckoView) nhận `ACTION_DROP` và trả về
        // true (đã xử lý), hệ thống KHÔNG gửi tiếp event đó lên listener của
        // View cha nữa — nên kể cả gắn `setOnDragListener` ở root layout (cha
        // của geckoView) thay vì ở geckoView cũng KHÔNG đảm bảo nhận được
        // ACTION_DROP một khi GeckoView đã tiêu thụ nó trước.
        //
        // Vì vậy: không có cách "quan sát riêng, không đụng gì đến GeckoView"
        // để tự gọi requestDragAndDropPermissions() ở tầng app. Quay lại đúng
        // hướng đã có ở mục 8r — để trống, tin tưởng hoàn toàn vào GeckoView
        // 145 (đã xác nhận qua Bugzilla Mozilla #1586471: nsDragService xử lý
        // nội bộ, bao gồm cả phần cấp quyền URI xuyên app).
        //
        // NHƯNG: người dùng đã test thật — kéo thả VẪN không hoạt động sau
        // khi để trống như trên. Nghĩa là giả thuyết "GeckoView tự lo hết"
        // SAI, hoặc đúng nhưng có điều kiện khác chưa rõ. Không đoán thêm
        // nữa — gắn listener THUẦN CHẨN ĐOÁN dưới đây để xem THỰC SỰ có
        // DragEvent nào tới geckoView hay không, và tới action nào (STARTED/
        // ENTERED/LOCATION/DROP/EXITED/ENDED). LUÔN return false — không tiêu
        // thụ event, không thay đổi hành vi thật, chỉ quan sát qua log.
        //
        // Đọc log sau khi thử kéo 1 file vào geckoView:
        //   - KHÔNG thấy dòng "DragEvent nhận được" nào cả → hệ thống/launcher
        //     không gửi event tới app này (vấn đề ở tầng ngoài GeckoView,
        //     ví dụ: launcher không hỗ trợ kéo file vào app khác, hoặc app
        //     không được khai báo nhận drag trong manifest/theme).
        //   - Thấy STARTED nhưng KHÔNG thấy DROP → GeckoView (hoặc View nào
        //     đó) đã từ chối/không accept drag ngay từ đầu (trả false cho
        //     ACTION_DRAG_STARTED), nên hệ thống không gửi tiếp DROP.
        //   - Thấy tới DROP → event có tới, vấn đề nằm ở việc GeckoView xử lý
        //     nội dung sau DROP (có thể thật sự cần requestDragAndDropPermissions
        //     hoặc cần can thiệp thêm) — lúc đó mới có cơ sở sửa tiếp, không
        //     phải đoán.
        geckoView.setOnDragListener { _, event ->
            val actionName = when (event.action) {
                android.view.DragEvent.ACTION_DRAG_STARTED -> "ACTION_DRAG_STARTED"
                android.view.DragEvent.ACTION_DRAG_ENTERED -> "ACTION_DRAG_ENTERED"
                android.view.DragEvent.ACTION_DRAG_LOCATION -> "ACTION_DRAG_LOCATION"
                android.view.DragEvent.ACTION_DRAG_EXITED -> "ACTION_DRAG_EXITED"
                android.view.DragEvent.ACTION_DROP -> "ACTION_DROP"
                android.view.DragEvent.ACTION_DRAG_ENDED -> "ACTION_DRAG_ENDED"
                else -> "UNKNOWN(${event.action})"
            }
            // Bỏ log riêng cho ACTION_DRAG_LOCATION — đây là action bắn ra
            // LIÊN TỤC (hàng chục lần/giây) suốt lúc kéo, chiếm gần hết log,
            // che mất mọi thứ khác. Đã xác nhận đủ (log trước) rằng chuỗi
            // event đi trọn qua LOCATION bình thường — không cần log lặp lại
            // action này nữa, chỉ log các mốc quan trọng (STARTED/ENTERED/
            // EXITED/DROP/ENDED).
            if (event.action != android.view.DragEvent.ACTION_DRAG_LOCATION) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] DragEvent nhận được tại geckoView — action=$actionName, clipDescription=${event.clipDescription}")
            }

            // CẬP NHẬT — đã tra ra: log lần trước cho thấy chuỗi event đi trọn
            // tới DROP/ENDED, nghĩa là GeckoView NỘI BỘ đã tự chấp nhận drag
            // (nếu từ chối ACTION_DRAG_STARTED thì Android đã ngừng gửi tiếp).
            // Xác nhận qua tra cứu: GeckoView 145 (bản project đang dùng) CÓ
            // thật `PanZoomController.onDragEvent()` — API thêm từ v124, đúng
            // bug #1586471 mà code gốc trích dẫn — không phải bịa. Vậy việc
            // "return false, để GeckoView tự xử lý qua fallback" trước đây
            // VỀ MẶT LÝ THUYẾT đã đúng hướng — nhưng ta chưa từng THẤY được
            // GeckoView thực sự trả về gì (chấp nhận hay từ chối nội dung),
            // vì đó là fallback nội bộ, không quan sát được qua log.
            //
            // Sửa: gọi THẲNG `panZoomController.onDragEvent()` ở đây — vừa
            // cấp quyền đọc URI (`requestDragAndDropPermissions`) TRƯỚC khi
            // Gecko cố đọc nội dung ở ACTION_DROP, vừa lấy được giá trị trả
            // về THẬT (true/false) để biết chính xác Gecko có chấp nhận nội
            // dung hay không — thay vì đoán qua 1 lớp fallback vô hình.
            if (event.action == android.view.DragEvent.ACTION_DROP) {
                try {
                    // TỰ SỬA LẠI (người dùng chất vấn đúng — bản trước viết
                    // "theo tài liệu chính thức Android, object phải được
                    // giữ tham chiếu sống, nếu không quyền bị thu hồi sớm"
                    // mà CHƯA thật sự tra cứu, chỉ là suy đoán). Đã
                    // web_search + đọc trực tiếp
                    // developer.android.com/develop/ui/views/touch-and-input/drag-drop/multi-window
                    // — tài liệu chính thức nói RÕ: "vòng đời quyền gắn với
                    // ACTIVITY dùng để gọi requestDragAndDropPermissions bị
                    // destroy, HOẶC gọi release(), TÙY CÁI NÀO ĐẾN TRƯỚC" —
                    // KHÔNG hề nói việc Kotlin không giữ biến tham chiếu tới
                    // object trả về sẽ khiến quyền bị thu hồi sớm. Claim
                    // trước đó là overclaim, không có nguồn xác nhận.
                    //
                    // Giữ lại patch này (lưu vào field `pendingDragPermissions`
                    // thay vì bỏ ngay) vì đây vẫn là THÓI QUEN AN TOÀN được
                    // khuyến nghị trong ví dụ mẫu chính thức của Android (gọi
                    // release() tường minh khi không cần nữa, thay vì phó mặc
                    // hoàn toàn cho vòng đời Activity) — nhưng KHÔNG khẳng
                    // định đây là nguyên nhân gốc của lỗi kéo-thả split-screen
                    // đã gặp. Nguyên nhân thật nhiều khả năng nằm ở phía APP
                    // NGUỒN (file manager) có hỗ trợ cờ DRAG_FLAG_GLOBAL hay
                    // không — xem log CHẨN ĐOÁN kéo-thả để biết có nhận được
                    // ACTION_DRAG_STARTED nào không trước khi nghi ngờ patch
                    // này.
                    pendingDragPermissions = requestDragAndDropPermissions(event)
                    DebugLog.log("Khe $slotIndex: đã requestDragAndDropPermissions() cho ACTION_DROP — đã giữ tham chiếu (thói quen an toàn, không chắc là nguyên nhân gốc — xem chú thích)")
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: requestDragAndDropPermissions() lỗi: ${e.message}")
                }
                // BUG THẬT đã tìm ra (đối chiếu log thật: ACTION_DROP lúc
                // 17:13:18, rồi `onFilePrompt: mimeTypes=.ipynb` bắn ra lúc
                // 17:13:21 — 3 GIÂY SAU): đã tra được javadoc chính thức
                // GeckoView (`GeckoSession.PromptDelegate.FilePrompt`) —
                // "Confirms the prompt and passes the file URI back to
                // content" — xác nhận `FilePrompt` là kênh DUY NHẤT để
                // Gecko nhận URI file, KỂ CẢ khi file đến từ kéo-thả trực
                // tiếp (không riêng gì bấm nút "Chọn file"). Code cũ ở
                // `onFilePromptListener` (xem bên dưới) không biết điều
                // này — luôn mở `showFilePicker()` từ đầu, bắt người dùng
                // CHỌN LẠI đúng file họ VỪA THẢ 3 giây trước — từ góc nhìn
                // người dùng, kéo-thả "không có tác dụng gì", chỉ tổ hiện
                // thêm 1 hộp thoại thừa.
                // SỬA: lưu lại URI vừa thả ở đây — `onFilePromptListener`
                // sẽ tự dùng URI này thay vì mở lại picker, nếu FilePrompt
                // đó bắn ra trong vòng vài giây sau khi thả.
                // FIX BUG THẬT (tra cứu web_search + đối chiếu với đúng
                // comment CÓ SẴN TRONG CHÍNH FILE NÀY ở
                // copyToAppStorageAsFileProviderUri: "GeckoView TỪ CHỐI
                // content://" — xác nhận thêm qua GitHub mozilla-mobile/
                // android-components #3009 trích Bugzilla Mozilla: GeckoView
                // không đọc được URI content:// từ file manager bên thứ 3,
                // cần file:// — CÙNG 1 giới hạn native với nhánh FilePrompt,
                // không phải 2 bug khác nhau). Nhánh FilePrompt né được bằng
                // cách tự copy ra file:// TRƯỚC khi đưa Gecko qua
                // `FilePrompt.confirm(uri)`. Nhánh KÉO-THẢ TRỰC TIẾP này
                // không có bước "confirm(uri)" nào — Gecko tự đọc thẳng
                // `ClipData` gốc bên trong `DragEvent`, app không có cách
                // "tráo" URI content://→file:// bên trong 1 DragEvent gốc
                // của hệ thống (tái tạo DragEvent với ClipData tuỳ ý chỉ
                // public từ API 31 — project này minSdk=26, không dùng được).
                //
                // SỬA: nếu có ít nhất 1 item mang URI THẬT (không phải chỉ
                // text) — tự đọc byte qua ContentResolver (né hẳn Gecko),
                // base64-encode, CHẠY JS tự dựng File/Blob/DataTransfer
                // chuẩn Web API và tự bắn sự kiện `drop` HTML5 THẬT vào đúng
                // phần tử dưới toạ độ thả — hoàn toàn né chỗ Gecko từ chối
                // content:// vì không còn dựa vào Gecko tự đọc ClipData gốc
                // nữa. Nếu làm được, TỰ TIÊU THỤ luôn action này (không gọi
                // panZoomController.onDragEvent cho riêng ACTION_DROP nữa)
                // để tránh Gecko cũng tự xử lý (dù lỗi) cùng lúc, gây chèn
                // text 2 lần hoặc xung đột. Cơ chế FilePrompt/lastDroppedFileUris
                // cũ bên dưới được GIỮ LẠI làm dự phòng — chỉ chạy khi
                // synthesis thất bại (ví dụ file quá lớn, vượt giới hạn
                // 20MB), để không mất hẳn đường lui nếu hướng mới có vấn đề
                // chưa lường hết.
                try {
                    val clipData = event.clipData
                    if (clipData != null && clipData.itemCount > 0) {
                        // CHẨN ĐOÁN THÊM (bug người dùng báo: ".txt kéo vào
                        // thì dán NỘI DUNG vào khung chat thay vì upload
                        // file, .zip thì không kéo được"): log CHI TIẾT
                        // từng item — có URI thật (content://) hay chỉ có
                        // text — vì `clipDescription` cũ chỉ cho biết DANH
                        // SÁCH MIME TYPE có mặt, không cho biết item có URI
                        // hay chỉ text thuần.
                        (0 until clipData.itemCount).forEach { i ->
                            val item = clipData.getItemAt(i)
                            DebugLog.log(
                                "Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] item[$i] — uri=${item?.uri}, " +
                                "có text=${item?.text != null} (độ dài=${item?.text?.length ?: 0}), " +
                                "có htmlText=${item?.htmlText != null}"
                            )
                        }
                        val droppedUris = (0 until clipData.itemCount).mapNotNull { i ->
                            clipData.getItemAt(i)?.uri
                        }
                        if (droppedUris.isNotEmpty()) {
                            // FIX KIẾN TRÚC (người dùng chỉ ra ĐÚNG câu hỏi
                            // mấu chốt: "nhấn tải lên thủ công có bị giới
                            // hạn dung lượng không, nếu không thì tại sao
                            // kéo-thả lại có" — xác nhận qua đọc code
                            // `resolveFilePrompt()`/`resolveFilePromptMultiple()`:
                            // 2 hàm đó gọi `prompt.confirm(context, uri)` —
                            // TRUYỀN THẲNG URI cho Gecko native, KHÔNG ĐỌC 1
                            // BYTE nào ở Kotlin — đây CHÍNH LÀ đường "Chrome
                            // thật" (File tham chiếu lazy) mà tôi từng kết
                            // luận sai là "không lộ qua API công khai" — nó
                            // CÓ lộ, nhưng CHỈ qua kênh `FilePrompt`
                            // (`onFilePrompt`), không qua được kênh kéo-thả
                            // trực tiếp (đã xác nhận qua log thật ở mục 45.3:
                            // native `panZoomController.onDragEvent` không
                            // bao giờ bắn `drop` DOM thật cho trang JS
                            // drop-zone). App đã CÓ SẴN cơ chế tự động hoá
                            // đường FilePrompt cho kéo-thả (`lastDroppedFileUris`
                            // + `onFilePromptListener` tự resolve — xem bên
                            // dưới) nhưng TRƯỚC ĐÂY chỉ THỤ ĐỘNG CHỜ 8 giây
                            // xem có gì đó tự làm `onFilePrompt` bắn ra hay
                            // không — với trang chỉ đọc `DataTransfer.files`
                            // thẳng trong JS (Drive), KHÔNG có gì tự bắn
                            // `onFilePrompt` cả nên luôn chờ hụt.
                            //
                            // SỬA ĐÚNG: nếu trang CÓ ít nhất 1 thẻ
                            // `<input type="file">` (dù ẩn, dù không phải
                            // chính ô nhận kéo-thả — nhiều trang, kể cả rất
                            // có thể cả Drive, vẫn giữ 1 input như vậy cho
                            // nút "Tải lên tệp" của chính nó), TỰ BẤM
                            // `.click()` vào đó bằng JS — thao tác này khiến
                            // GeckoView tự mở `onFilePrompt` THẬT (y hệt như
                            // người dùng tự bấm nút "Tải lên" của trang),
                            // rồi cơ chế `onFilePromptListener` CÓ SẴN Ở
                            // DƯỚI sẽ tự resolve bằng URI vừa thả — KHÔNG
                            // giới hạn dung lượng nào (đường native thật,
                            // bước copy trung gian `copyToAppStorageAsFileProviderUri`
                            // cũng chỉ stream theo buffer nhỏ qua
                            // `InputStream.copyTo()`, không nạp cả file vào
                            // RAM — xem hàm đó). CHỈ khi trang KHÔNG có
                            // input[type=file] nào (JS drop-zone thuần,
                            // hiếm hơn) mới cần rơi về nhánh chunk/base64 cũ
                            // (nhánh ĐÓ vẫn cần cap mềm vì buộc phải đưa
                            // byte qua JS theo đúng giới hạn spec `File()` —
                            // không né được, đã giải thích ở
                            // `synthesizeFileDrop()`).
                            //
                            // LƯU Ý VỀ THỨ TỰ THỰC THI (quan trọng, để hiểu
                            // đúng vì sao KHÔNG suppress `pzc.onDragEvent()`
                            // bên dưới cho nhánh này): `evaluateJs()` là bất
                            // đồng bộ — kết quả bấm input chỉ biết được SAU
                            // khi hàm này đã return, tức SAU khi dòng
                            // `accepted = ...` (dùng `handledBySynthesis`)
                            // đã chạy xong. Vì vậy nhánh click KHÔNG đặt
                            // `handledBySynthesis = true` — để native
                            // `pzc.onDragEvent()` vẫn chạy song song như
                            // bình thường. Điều này AN TOÀN vì đây CHÍNH LÀ
                            // hành vi đã có sẵn từ trước cho trường hợp
                            // "vượt cap" (native forwarding + tự chờ
                            // `lastDroppedFileUris` chạy song song) — không
                            // phải hành vi mới chưa kiểm chứng. Rủi ro
                            // "chèn text lặp" mà `handledBySynthesis` từng
                            // được thêm để né chỉ áp dụng cho nhánh
                            // `synthesizeFileDrop` (tự bắn `drop` DOM tổng
                            // hợp bằng JS — CÓ khả năng trùng lặp với native
                            // xử lý cùng ClipData); nhánh click KHÔNG tự bắn
                            // DOM event nào cả, chỉ gọi `.click()` 1 phần tử
                            // input thật, nên không có rủi ro tương tự.
                            // FIX BUG THẬT (người dùng chất vấn đúng, y hệt
                            // tinh thần mục 48: "sao bảo giới hạn khi trình
                            // duyệt khác làm được, upload thủ công (bấm nút
                            // Tải lên/pick) vẫn được?"): kết luận cũ ở mục
                            // 57 ("Drive KHÔNG có input[type=file]", dựa
                            // trên log "NO_INPUT_FOUND") là 1 KẾT LUẬN VỘI
                            // giống lỗi trích dẫn Bugzilla #607921 trước đây
                            // — script cũ chỉ gọi
                            // `document.querySelectorAll('input[type="file"]')`
                            // trên CHÍNH document gốc. Đây là hành vi CHUẨN
                            // đã ghi rõ trong spec DOM (không phải suy đoán):
                            // `querySelectorAll` KHÔNG BAO GIỜ xuyên qua
                            // ranh giới Shadow DOM (kể cả shadow root MỞ),
                            // và cũng không tự xuyên vào `<iframe>` (mỗi
                            // iframe có `document` RIÊNG). Google Drive —
                            // và hầu hết sản phẩm Google khác — dùng rất
                            // nhiều Web Components/Shadow DOM cho UI của
                            // họ; nút "Tải lên" mà người dùng bấm thủ công
                            // (xác nhận CHẠY ĐƯỢC, không giới hạn dung
                            // lượng) rất có thể đang thao tác đúng 1
                            // `input[type=file]` THẬT nằm SÂU trong shadow
                            // root hoặc trong 1 iframe cùng-origin — hoàn
                            // toàn không được `querySelectorAll` nông thấy
                            // tới, nên "NO_INPUT_FOUND" là KẾT QUẢ SAI (âm
                            // tính giả) do tìm không đủ sâu, KHÔNG PHẢI
                            // bằng chứng Drive thật sự thiếu input.
                            //
                            // Đã sửa: tìm SÂU đệ quy qua mọi shadow root MỞ
                            // (`element.shadowRoot`) và mọi iframe CÙNG
                            // origin (`iframe.contentDocument` — iframe
                            // khác origin sẽ tự ném lỗi truy cập, bắt lỗi
                            // và bỏ qua, đây là giới hạn bảo mật trình
                            // duyệt thật không né được, không phải thiếu
                            // sót của code). Giới hạn còn lại THÀNH THẬT:
                            // shadow root ĐÓNG (`{mode: 'closed'}`) vẫn
                            // KHÔNG thể truy cập được từ bên ngoài — đây là
                            // giới hạn kỹ thuật thật sự của web platform,
                            // không có cách nào ở tầng JS thông thường để
                            // né (kể cả Chrome/Firefox thật cũng vậy) —
                            // nhưng phần lớn framework (bao gồm các sản
                            // phẩm Google) mặc định dùng shadow root MỞ.
                            lastDroppedFileUris = droppedUris
                            lastDroppedFileUriTime = System.currentTimeMillis()
                            // FIX BUG THẬT (mục 77 PROJECT_STATUS.md — người
                            // dùng chất vấn đúng: "sửa Drive xong thì trang
                            // khác lại lỗi à?"). Rà lại toàn bộ luồng kéo-thả
                            // xác nhận KHÔNG có hardcode domain nào cả — lý
                            // do các lần trước "sửa trang A xong lại lỗi
                            // trang B" là vì code RẼ NHÁNH THẬT SỰ khác nhau
                            // tuỳ trang có `input[type=file]` hay không (phát
                            // hiện lúc chạy, không phải danh sách domain cố
                            // định) — mỗi nhánh có bug độc lập của riêng nó,
                            // bị lộ ra tuần tự khi test đúng loại trang rơi
                            // vào nhánh đó. Để đóng CẢ 2 nhánh cùng lúc bằng
                            // 1 fix chung: chốt CỐ ĐỊNH đúng 1 tabId NGAY TẠI
                            // ĐÂY (thời điểm chắc chắn còn đúng — vừa nhận
                            // ACTION_DROP) cho CẢ đường bấm input thật (ngay
                            // dưới) LẪN đường chunk/base64 dự phòng
                            // (`synthesizeFileDrop`) — không còn nhánh nào tự
                            // gọi `engine.getActiveTab()` riêng lẻ ở thời
                            // điểm khác nhau nữa.
                            val dropTabIdPinned = engine.getActiveTab()?.id
                            val clickInputScript = """
                                (function(){
                                    function timSauFileInputs(root, acc, iframeBoOwn) {
                                        if (!root) return;
                                        try {
                                            var inputs = root.querySelectorAll('input[type="file"]');
                                            for (var i = 0; i < inputs.length; i++) acc.push(inputs[i]);
                                            var all = root.querySelectorAll('*');
                                            for (var j = 0; j < all.length; j++) {
                                                var el = all[j];
                                                if (el.shadowRoot) timSauFileInputs(el.shadowRoot, acc, iframeBoOwn);
                                                if (el.tagName === 'IFRAME') {
                                                    try {
                                                        var doc = el.contentDocument;
                                                        if (doc) timSauFileInputs(doc, acc, iframeBoOwn);
                                                    } catch (e) { iframeBoOwn.count++; }
                                                }
                                            }
                                        } catch (e) { /* root lạ (VD ShadowRoot đóng lộ ra kiểu khác) — bỏ qua nhánh này */ }
                                    }
                                    var found = [];
                                    var iframeBoOwn = { count: 0 };
                                    timSauFileInputs(document, found, iframeBoOwn);
                                    if (found.length > 0) {
                                        found[0].click();
                                        return 'CLICKED_INPUT:' + found.length + ':SKIPPED_IFRAMES=' + iframeBoOwn.count;
                                    }
                                    return 'NO_INPUT_FOUND:SKIPPED_IFRAMES=' + iframeBoOwn.count;
                                })();
                            """.trimIndent()
                            if (dropTabIdPinned == null) {
                                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] HUỶ — không có tab active nào để neo thao tác kéo-thả")
                            } else {
                                engine.evaluateJsPinnedToTab(dropTabIdPinned, clickInputScript) { clickResult ->
                                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] thử bấm input[type=file] thật trên trang — kết quả: $clickResult")
                                if (clickResult != null && clickResult.startsWith("CLICKED_INPUT")) {
                                    // Đã bấm — chờ `onFilePromptListener` (đã
                                    // đăng ký sẵn, xem chỗ khác trong file)
                                    // tự resolve bằng `lastDroppedFileUris`.
                                    // Cơ chế cảnh báo 8s bên dưới vẫn giữ
                                    // làm lưới an toàn, đề phòng click không
                                    // thật sự mở được onFilePrompt vì lý do
                                    // gì đó (VD input bị JS chặn sự kiện
                                    // click lập trình). KHÔNG gọi
                                    // synthesizeFileDrop trong nhánh này —
                                    // không có cap dung lượng nào ở đường
                                    // click-input, khớp đúng khả năng thật
                                    // của "tải lên thủ công".
                                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] đã bấm input thật — chờ onFilePromptListener tự resolve, KHÔNG giới hạn dung lượng")
                                } else {
                                    // Trang không có input[type=file] nào —
                                    // rơi về nhánh chunk/base64 cũ (CÓ cap
                                    // mềm, chỉ vì buộc phải đưa byte qua JS
                                    // — xem chú thích đầy đủ ở
                                    // `synthesizeFileDrop()`).
                                    val dropXFracFallback = (event.x / geckoView.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                                    val dropYFracFallback = (event.y / geckoView.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                    val totalSizeFallback = droppedUris.sumOf { uri -> getDeclaredSizeOrZero(uri) }
                                    // NÂNG CAP (người dùng chỉ ra đúng: Drive
                                    // xác nhận KHÔNG có input[type=file]
                                    // (log "NO_INPUT_FOUND") — cap mềm này
                                    // giờ là LỰC CẢN DUY NHẤT còn lại cho
                                    // kéo-thả file lớn vào Drive. Vì cơ chế
                                    // chunk (mục 45.3) KHÔNG có giới hạn kỹ
                                    // thuật CỨNG nào (chỉ là cap TỰ ĐẶT vì
                                    // chưa test ở mức cao hơn) — nâng lên
                                    // 1GB. TRUNG THỰC: đây vẫn CHƯA test ở
                                    // mức file 1-3GB thật (nhiều trăm chunk,
                                    // nhiều round-trip qua cầu WebExtension
                                    // — có thể chậm hoặc lộ giới hạn bộ nhớ
                                    // JS/Gecko chưa từng gặp ở mức 300MB) —
                                    // không hứa chắc chắn hoạt động, chỉ là
                                    // gỡ bỏ giới hạn tự đặt không còn căn cứ.
                                    val maxSynthesisBytesSoftCap = 1024L * 1024 * 1024
                                    if (totalSizeFallback in 1..maxSynthesisBytesSoftCap) {
                                        synthesizeFileDrop(droppedUris, dropXFracFallback, dropYFracFallback, slotIndex, dropTabIdPinned)
                                    } else {
                                        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] không có input[type=file] trên trang VÀ vượt cap mềm chunk ($maxSynthesisBytesSoftCap byte) — chỉ còn cách chờ 8s xem có gì tự mở onFilePrompt không (khó, trang JS-drop-zone thuần thường không tự mở)")
                                    }
                                }
                            }
                            } // đóng nhánh else (dropTabIdPinned != null) — xem "if (dropTabIdPinned == null)" phía trên
                            // Lưới an toàn 8 giây (giữ nguyên như trước) —
                            // báo THẬT cho người dùng nếu SAU CẢ 2 nỗ lực
                            // trên (click-input lẫn chunk-fallback, nếu có
                            // chạy) vẫn không có gì tiêu thụ URI vừa thả.
                            handler.postDelayed({
                                if (lastDroppedFileUris.isNotEmpty()) {
                                    DebugLog.log(
                                        "Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] CẢNH BÁO — sau 8s, ${lastDroppedFileUris.size} URI vừa thả VẪN CHƯA được onFilePrompt nào tiêu thụ."
                                    )
                                    Toast.makeText(
                                        this@MainActivity,
                                        "Kéo-thả không thành công: trang này không nhận file thả trực tiếp. " +
                                            "Dùng nút tải lên riêng của trang thay vì kéo-thả.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    lastDroppedFileUris = emptyList()
                                }
                            }, 8000L)
                        }
                    }
                } catch (e: Exception) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] đọc clipData URI lỗi: ${e.message}")
                }
            }

            val pzc = geckoView.session?.panZoomController
            // ĐƠN GIẢN HOÁ (dọn theo đúng thiết kế mới ở trên — click-input
            // thật + fallback chunk): biến `handledBySynthesis` TRƯỚC ĐÂY
            // dùng để suppress `pzc.onDragEvent()` khi `synthesizeFileDrop`
            // (tự bắn `drop` DOM TỔNG HỢP bằng JS) đã xử lý — tránh Gecko
            // ĐỒNG THỜI diễn giải ClipData gốc, có thể gây chèn text lặp.
            // Thiết kế mới KHÔNG còn quyết định đồng bộ được việc có chạy
            // synthesis hay không (quyết định đó giờ nằm TRONG callback bất
            // đồng bộ của `evaluateJs()` — xem khối code phía trên), nên
            // không còn cách nào suppress đúng lúc nữa. Đây KHÔNG phải rủi
            // ro mới: để `pzc.onDragEvent()` luôn chạy song song với cơ chế
            // tự chờ `lastDroppedFileUris`/click-input của app CHÍNH LÀ hành
            // vi đã có sẵn và đã qua kiểm chứng thật cho MỌI trường hợp
            // "vượt cap" từ trước (xem log/kết luận mục 45.3) — chỉ mở rộng
            // áp dụng thêm cho trường hợp "trong cap nhưng không có input"
            // (chunk fallback) và trường hợp mới "có input, click thành
            // công" (đường không giới hạn dung lượng). Nhánh click-input
            // không tự bắn DOM event tổng hợp nào (chỉ `.click()` 1 phần tử
            // input thật) nên không có rủi ro chèn-text-lặp tương tự.
            val accepted = try {
                pzc?.onDragEvent(event) ?: false
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] panZoomController.onDragEvent() NÉM LỖI: ${e.message}")
                false
            }
            if (event.action != android.view.DragEvent.ACTION_DRAG_LOCATION) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN kéo-thả] panZoomController.onDragEvent($actionName) trả về = $accepted")
            }

            if (event.action == android.view.DragEvent.ACTION_DRAG_ENDED) {
                // Chỉ release() SAU KHI hệ thống báo drag đã kết thúc hẳn —
                // lúc này Gecko đã có đủ thời gian đọc byte thật (hoặc đã
                // thất bại vì lý do khác, không phải vì hết quyền do app tự
                // release quá sớm). Trễ nhẹ 1s trước khi release, phòng
                // trường hợp việc đọc bất đồng bộ ở tiến trình render riêng
                // của Gecko xảy ra NGAY SAU thời điểm callback ENDED bắn ra
                // (không đảm bảo Gecko đã đọc xong ngay tại đúng lúc ENDED).
                val permsToRelease = pendingDragPermissions
                pendingDragPermissions = null
                if (permsToRelease != null) {
                    // BUG THẬT (log thật cho thấy FilePrompt của Gecko cho
                    // file vừa thả có thể bắn ra tới ~3s SAU ACTION_DRAG_ENDED
                    // — xem chú thích ở nhánh ACTION_DROP phía trên): 1000ms
                    // trước đây QUÁ NGẮN, quyền đọc URI có thể đã bị release()
                    // trước khi `onFilePromptListener` kịp dùng lại URI đó để
                    // tự resolve (fix "kéo-thả không hoạt động"). Kéo dài lên
                    // 6000ms cho an toàn hơn — vẫn release() sau cùng như cũ,
                    // không giữ vĩnh viễn.
                    handler.postDelayed({
                        try {
                            permsToRelease.release()
                            DebugLog.log("Khe $slotIndex: đã release() DragAndDropPermissions sau ACTION_DRAG_ENDED")
                        } catch (e: Exception) {
                            DebugLog.log("Khe $slotIndex: release() DragAndDropPermissions lỗi: ${e.message}")
                        }
                    }, 6000L)
                }
            }

            // Trả THẲNG kết quả thật từ panZoomController — không trả `false`
            // cố định nữa. Lý do: nếu vẫn trả `false`, Android sẽ RƠI TIẾP
            // xuống `onDragEvent()` nội bộ của GeckoView (theo đúng cơ chế
            // OnDragListener→fallback đã xác nhận) — và nội bộ đó (nếu có)
            // NHIỀU KHẢ NĂNG cũng gọi lại `panZoomController.onDragEvent()`
            // giống hệt như mình vừa gọi ở trên → xử lý event 2 LẦN. Với
            // ACTION_DROP, xử lý 2 lần có thể gây đọc file 2 lần/lỗi tranh
            // chấp — rủi ro hơn là lợi. Trả `accepted` (kết quả thật) khiến
            // lệnh gọi trực tiếp của mình trở thành nguồn xử lý DUY NHẤT.
            accepted
        }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, PERMISSION_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_NOTIFICATIONS), RC_NOTIFICATIONS)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (com.colablive.keeper.core.FolderPickerBridge.handleActivityResult(this, requestCode, resultCode, data)) {
            return
        }
        if (requestCode == RC_HISTORY) {
            if (resultCode == RESULT_OK) {
                data?.getStringExtra("open_url")?.let { engine.loadUrl(it) }
            }
            return
        }
        if (requestCode == RC_BOOKMARKS) {
            if (resultCode == RESULT_OK) {
                data?.getStringExtra("open_url")?.let { engine.loadUrl(it) }
            }
            return
        }
        if (requestCode == RC_ADDON_INSTALL) {
            if (resultCode == RESULT_OK) {
                data?.data?.let { uri ->
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (e: Exception) {
                        DebugLog.log("RC_ADDON_INSTALL: takePersistableUriPermission lỗi (không chặn luồng): ${e.message}")
                    }
                    installAddonFromPickedUri(uri)
                }
            }
            return
        }
        if (requestCode == RC_FILE_PICKER) {
            /**
             * QUAY LẠI COPY FILE — LẦN NÀY CÓ BẰNG CHỨNG THẬT, KHÔNG PHẢI
             * ĐOÁN. Log thật gửi lên xác nhận: đưa thẳng URI (bản trước,
             * mục 8z) → `resolveFilePrompt` báo "confirm prompt thành
             * công" (không hề có exception phía Kotlin) → nhưng trang VẪN
             * báo "Unable to read file", với CẢ 2 provider khác nhau (SAF
             * Downloads lẫn 1 app quản lý file khác). Tức là `confirm()`
             * chạy được, nhưng việc ĐỌC BYTE THẬT xảy ra ở tầng SÂU HƠN bên
             * trong Gecko (rất có thể ở tiến trình render riêng) và tầng đó
             * không đọc được URI ngoài — CHỨNG MINH giả thuyết "vấn đề
             * quyền truy cập cross-process" ban đầu là ĐÚNG, không phải chỉ
             * là 1 khả năng.
             *
             * Copy file vào bộ nhớ RIÊNG của app này (qua FileProvider) né
             * được đúng vấn đề này vì không còn phụ thuộc provider ngoài —
             * mọi tiến trình của app đều có quyền đọc file trong bộ nhớ
             * riêng của chính app. Đưa lại cách này, giữ nguyên các phần đã
             * sửa trước đó (chạy nền tránh treo UI — mục 8t, tự dọn cache
             * cũ — mục 8s, đọc thêm clipData — mục 8x), chỉ thêm log rõ hơn
             * ở bước cuối để biết chắc chắn có tới `resolveFilePrompt`
             * không.
             */
            DebugLog.log("onActivityResult(RC_FILE_PICKER): resultCode=$resultCode, data.data=${data?.data}, data.clipData=${data?.clipData}")
            // FIX BUG THẬT (đúng người dùng báo: "chọn nhiều file nhưng chỉ
            // nhận được 1"): TRƯỚC ĐÂY chỉ lấy `getItemAt(0)` khi có
            // `clipData` (trường hợp chọn nhiều file qua
            // `EXTRA_ALLOW_MULTIPLE`) — luôn bỏ mọi file từ thứ 2 trở đi.
            // Lấy HẾT toàn bộ `itemCount`, cộng thêm `data.data` (trường hợp
            // chỉ chọn 1 file — khi đó `clipData` thường null,
            // `data.data` mới có giá trị) để không bỏ sót đường nào.
            val pickedUris: List<Uri> = if (resultCode == RESULT_OK) {
                val fromClipData = data?.clipData?.let { cd ->
                    (0 until cd.itemCount).mapNotNull { i -> cd.getItemAt(i)?.uri }
                } ?: emptyList()
                if (fromClipData.isNotEmpty()) fromClipData
                else data?.data?.let { listOf(it) } ?: emptyList()
            } else emptyList()
            if (pickedUris.isEmpty()) {
                DebugLog.log("onActivityResult(RC_FILE_PICKER): pickedUris rỗng (huỷ chọn file, hoặc resultCode != OK) — dismiss() prompt")
                engine.resolveFilePrompt(this, null)
                return
            }
            // Lấy quyền đọc DÀI HẠN ngay lập tức cho TỪNG uri (rẻ, đồng bộ)
            // — xem giải thích lớn ở `showFilePicker()`. Không để lỡ khoảng
            // thời gian nào giữa lúc nhận URI và lúc thật sự đọc nó.
            pickedUris.forEach { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                    DebugLog.log("takePersistableUriPermission lỗi cho $uri (không chặn luồng, vẫn thử đọc tiếp): ${e.message}")
                }
            }
            DebugLog.log("onActivityResult(RC_FILE_PICKER): pickedUris=$pickedUris (${pickedUris.size} file) — bắt đầu copy nền vào bộ nhớ riêng của app")
            val progressToast = Toast.makeText(this, "Đang xử lý ${pickedUris.size} file...", Toast.LENGTH_LONG)
            progressToast.show()
            Thread {
                val safeUris = pickedUris.mapNotNull { copyToAppStorageAsFileProviderUri(it) }
                DebugLog.log("onActivityResult(RC_FILE_PICKER): copy xong ${safeUris.size}/${pickedUris.size} file (thiếu nghĩa là 1 vài file copy lỗi, xem log ngay phía trên dòng này)")
                runOnUiThread {
                    progressToast.cancel()
                    if (safeUris.isEmpty()) {
                        Toast.makeText(this, "Không đọc được file đã chọn", Toast.LENGTH_SHORT).show()
                        engine.resolveFilePrompt(this, null)
                    } else {
                        DebugLog.log("onActivityResult(RC_FILE_PICKER): gọi engine.resolveFilePromptMultiple(${safeUris.size} file)")
                        engine.resolveFilePromptMultiple(this, safeUris.toTypedArray())
                    }
                }
            }.start()
        }
    }

    /**
     * Copy file được chọn vào bộ nhớ RIÊNG của app này rồi cấp quyền qua
     * `FileProvider` chuẩn (đã khai báo sẵn trong AndroidManifest.xml từ
     * trước, không cần thêm gì) — xem giải thích đầy đủ lý do ở
     * `onActivityResult` phía trên.
     */
    private fun cleanupOldUploadCache() {
        try {
            val dir = File(cacheDir, "uploads")
            val cutoff = System.currentTimeMillis() - 10 * 60 * 1000L
            dir.listFiles()?.forEach { f ->
                if (f.lastModified() < cutoff) f.delete()
            }
        } catch (e: Exception) {
            DebugLog.log("cleanupOldUploadCache lỗi: ${e.message}")
        }
    }

    /**
     * NGUYÊN NHÂN THẬT — đã TRA ĐƯỢC, không còn đoán: tra Bugzilla của
     * chính Mozilla (bug #1515440, "PromptDelegate.FileCallback.confirm
     * not handling URIs from content://...") xác nhận GeckoView's
     * `FilePrompt.confirm(Context, Uri)` CHỈ hỗ trợ URI dạng `file://` —
     * TỪ CHỐI mọi URI `content://`, KỂ CẢ từ `FileProvider` CỦA CHÍNH APP
     * NÀY (không phân biệt content:// đến từ provider ngoài hay provider
     * riêng — đều bị từ chối như nhau, lỗi log gốc bên phía Gecko là
     * "Only file URI is supported"). Đây là lý do CẢ 2 lần thử trước đều
     * thất bại: lần đưa thẳng URI ngoài (content://, mục 8z) VÀ lần copy
     * qua FileProvider (vẫn ra content://, mục 8za) — cả 2 đều dùng SAI
     * LOẠI URI, không liên quan gì đến việc có copy hay không, hay quyền
     * đọc dài/ngắn hạn.
     *
     * Cách khắc phục ĐÚNG kỹ sư Mozilla xác nhận trong bug đó: app tự đọc
     * dữ liệu content:// rồi đưa lại — nghĩa là copy file (đã làm đúng),
     * NHƯNG bước cuối phải dùng `Uri.fromFile(destFile)` (file://) thay vì
     * bọc qua FileProvider (content://) như trước. `Uri.fromFile()` không
     * kích hoạt `FileUriExposedException` ở đây vì đó chỉ áp dụng khi đưa
     * URI file:// vào 1 `Intent` gửi SANG APP KHÁC — còn `confirm()` là gọi
     * hàm Java trực tiếp trong tiến trình mình, không phải Intent.
     */
    /**
     * FIX BUG THẬT (mục 27 → 28) — kéo-thả file trực tiếp vào trang web bị
     * Gecko từ chối đọc vì URI là content:// (từ file manager bên thứ 3),
     * không phải file://. Xác nhận CHẮC CHẮN qua 2 nguồn độc lập:
     * (1) GitHub mozilla-mobile/android-components #3009 trích dẫn báo lỗi
     * Mozilla; (2) đúng comment CÓ SẴN TRONG FILE NÀY ở
     * `copyToAppStorageAsFileProviderUri` — log lỗi GỐC bên phía Gecko ghi
     * rõ "Only file URI is supported". Nhánh FilePrompt (chọn file qua nút
     * bấm) né được bằng cách tự copy ra file:// rồi gọi thẳng
     * `FilePrompt.confirm(uri)` — API Kotlin app tự gọi trực tiếp, không
     * đụng gì tới ClipData/DragEvent gốc của hệ thống. Kéo-thả trực tiếp
     * KHÔNG có đường tương đương — Gecko tự đọc `ClipData` bên trong
     * `DragEvent` gốc, và tái tạo `DragEvent` với `ClipData` tuỳ ý chỉ là
     * API public từ Android 12/API 31 (project này minSdk=26, không dùng
     * được cho mọi máy).
     *
     * Cách né: KHÔNG đưa gì cho Gecko đọc ClipData gốc nữa. Tự đọc byte
     * thật của từng URI bằng `ContentResolver` ở tầng Kotlin (nơi
     * content:// đọc bình thường, không bị từ chối gì cả — giới hạn "chỉ
     * nhận file://" là của riêng native code Gecko lúc dịch ClipData, không
     * phải giới hạn chung của Android), base64-encode, rồi chạy 1 đoạn JS
     * ngay trong trang: tự dựng `File`/`Blob`/`DataTransfer` bằng đúng Web
     * API chuẩn (không cần OS thật kéo file gì nữa, chuẩn HTML5 cho phép
     * script tự tạo các object này), tìm phần tử DOM đúng dưới toạ độ thả
     * qua `document.elementFromPoint()`, rồi tự bắn chuỗi sự kiện
     * `dragenter`/`dragover`/`drop` THẬT (constructor `DragEvent` chuẩn) —
     * từ góc nhìn code JS của trang web, đây là 1 lượt kéo-thả file thật
     * 100%, không biết gì về việc dữ liệu đến từ content:// hay được app
     * tự dựng lại.
     *
     * Giới hạn 20MB TỔNG (base64 phồng ~33% so với byte gốc) — vượt quá thì
     * ném exception để nhánh gọi (trong `setupDragDrop`) tự fallback về
     * hành vi cũ (cơ chế FilePrompt/lastDroppedFileUris), tránh base64 quá
     * lớn làm treo/crash tiến trình render của Gecko.
     *
     * `xFrac`/`yFrac`: toạ độ thả tính theo TỈ LỆ (0.0–1.0) trên kích thước
     * `geckoView` lúc thả — giả định `geckoView` lấp đầy toàn bộ viewport
     * hiển thị của trang (đúng với UI toàn màn hình hiện tại của app) để
     * suy ra toạ độ CSS thật qua `window.innerWidth`/`innerHeight` ngay
     * trong JS — cách này tự động khớp ĐÚNG mọi mức zoom/tỉ lệ pixel hiện
     * tại của trang (kể cả "zoom gộp" riêng của app), vì `window.innerWidth`
     * luôn phản ánh kích thước viewport CSS THẬT SỰ tại đúng thời điểm chạy,
     * không cần app tự tính toán quy đổi devicePixelRatio/zoom thủ công.
     * CHƯA build/test — chưa xác nhận có thanh nào che phủ geckoView khiến
     * giả định "lấp đầy toàn bộ viewport" sai lệch hay không.
     */
    /** Đọc nhanh cột SIZE metadata (KHÔNG đọc nội dung file) — dùng để quyết
     * định NGAY LẬP TỨC, đồng bộ có nên thử synthesis hay fallback, tránh
     * phải đọc hết byte mới biết file có quá lớn hay không. */
    private fun getDeclaredSizeOrZero(uri: Uri): Long {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (idx >= 0 && !cursor.isNull(idx)) cursor.getLong(idx) else 0L
                } else 0L
            } ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    /**
     * MỤC 45.3 — VIẾT LẠI theo hướng streaming/chunk (bản cũ base64 TOÀN
     * BỘ file thành 1 chuỗi rồi nhét vào 1 lệnh evaluateJs() DUY NHẤT —
     * đó là lý do có giới hạn 20MB, KHÔNG phải trần kỹ thuật của chính
     * API, chỉ là trần của CÁCH LÀM "1 khối liên tục").
     *
     * ĐÃ KIỂM CHỨNG (không phải suy đoán) trước khi chọn hướng này —
     * loại bỏ lần lượt các hướng khác:
     * 1. "Tin native GeckoView tự stream giống Chrome" — bị chính log
     *    thật trong app này bác bỏ: `panZoomController.onDragEvent()`
     *    nhận ACTION_DROP có URI content:// thật, được Gecko CHẤP NHẬN
     *    (trả về true, đi trọn STARTED→DROP→ENDED), nhưng luôn trổ ra
     *    `onFilePrompt` (ngữ nghĩa "mở picker") 3 giây sau — CHƯA BAO GIỜ
     *    quan sát được 1 sự kiện `drop` DOM thật với `File` data cho
     *    trang dùng JS drop-zone (Drive, không phải input[type=file]).
     *    Nghĩa là "File tham chiếu lazy tới content:// URI, đọc byte
     *    thật chỉ khi trang cần" (cách Chrome/Chromium làm — xác nhận
     *    qua chính mã nguồn Chromium: EventForwarder.java chỉ chuyển
     *    CHUỖI URI qua JNI, KHÔNG hề đọc byte ở tầng Java) là chi tiết
     *    NẰM Ở TẦNG NATIVE C++ của engine, KHÔNG lộ ra qua API công khai
     *    GeckoView cho app nhúng như app này — không có cách nào gọi tới
     *    từ Kotlin/Java.
     * 2. "Copy ra file:// rồi fetch('file://...') trong JS trang" — bị
     *    chặn bởi sandbox/CSP của chính trang (Drive không cho phép
     *    trang của nó tự ý fetch file:// hay origin lạ).
     * Hai hướng "đúng bản chất Chrome" đều không khả thi qua API công
     * khai GeckoView. Hướng còn lại — vẫn phải tự dựng File/Blob bằng JS
     * như bản cũ (đây là hạn chế THẬT của spec Web: `new File(bits, ...)`
     * chỉ nhận BufferSource/Blob/string làm `bits`, KHÔNG có kiểu nhận
     * 1 đường dẫn để đọc lazy — bất kỳ ai tự dựng File bằng JS, kể cả
     * đúng chuẩn, đều phải đưa byte thật vào JS trước) — nhưng SỬA cách
     * đưa byte vào: thay vì 1 khối base64 khổng lồ, đọc + gửi TỪNG CHUNK
     * nhỏ (CHUNK_BYTES), CHỜ xác nhận xong chunk này mới đọc/gửi chunk
     * tiếp theo (backpressure thật qua CountDownLatch) — không bao giờ
     * có quá 1 chunk "bay" giữa Kotlin và Gecko cùng lúc, và không bao
     * giờ có 1 chuỗi/mảng byte khổng lồ nào tồn tại nguyên khối ở bất kỳ
     * tầng nào. Cuối cùng gọi `new Blob(parts, ...)` với `parts` là 1
     * MẢNG nhiều Uint8Array nhỏ — Blob không đòi hỏi 1 vùng nhớ liên tục
     * khổng lồ để nối trước khi tạo.
     *
     * TRUNG THỰC VỀ GIỚI HẠN CÒN LẠI: cách này vẫn phải đưa TOÀN BỘ byte
     * của file qua cầu WebExtension port vào tiến trình Gecko trước sau
     * (không né được việc đó — xem lý do (2) ở trên). Trần thực tế bây
     * giờ là RAM khả dụng của tiến trình Gecko + thời gian chờ (nhiều
     * chunk hơn = lâu hơn), KHÔNG phải 1 con số cứng vì lý do kỹ thuật
     * như 20MB trước — nhưng vẫn CÓ giới hạn, không phải "giờ vô hạn".
     * MAX_SYNTHESIS_BYTES_SOFT_CAP ở nơi gọi hàm này (trong
     * `setupDragDrop`) là cap AN TOÀN tự đặt, CHƯA build/test để biết
     * trần thật ổn định của Gecko 145 trên thiết bị thật là bao nhiêu.
     */
    private fun synthesizeFileDrop(uris: List<Uri>, xFrac: Float, yFrac: Float, slotIndex: Int, pinnedTabId: String? = null) {
        // FIX BUG THẬT (mục 77 PROJECT_STATUS.md — kéo-thả file vào Drive
        // LUÔN ra "dispatched 0 file(s)", bất kể file to hay nhỏ, dù log
        // xác nhận toàn bộ chunk đã "gửi thành công"). Nguyên nhân gốc:
        // MỌI lời gọi `engine.evaluateJs(...)` trong hàm này (init builder,
        // từng chunk, lắp Blob cuối) trước đây đều dùng bản KHÔNG neo tab
        // cụ thể — hàm đó luôn chạy trên tab ĐANG ACTIVE TẠI THỜI ĐIỂM GỌI,
        // không phải tab nơi thao tác kéo-thả bắt đầu. Với file lớn, việc
        // gửi hàng trăm chunk kéo dài hàng chục giây — thừa thời gian để
        // tab active đổi giữa chừng (chuyển tab tay, hoặc do 1 tab nền
        // khác tự chuyển focus) — khi đó các lệnh JS về sau (đặc biệt bước
        // LẮP RÁP CUỐI) chạy NHẦM sang tab khác, đọc `window.__lbDrop_...`
        // rỗng ở đúng tab Drive → `Object.keys(builder).length === 0` →
        // "dispatched 0 file(s)" — không phải do Drive "từ chối" gì cả.
        //
        // Sửa: chốt CỐ ĐỊNH đúng 1 tabId (tab đang active NGAY LÚC BẮT ĐẦU
        // kéo-thả) ngay từ đầu hàm, dùng `engine.evaluateJsPinnedToTab()`
        // (mới thêm — xem `BrowserEngine.kt`) cho MỌI lệnh JS bên trong,
        // thay vì `engine.evaluateJs()` đi theo tab active hiện tại.
        // Ưu tiên tabId đã được neo TỪ TRƯỚC ngay lúc ACTION_DROP (tham số
        // `pinnedTabId`, xem `setupDragDrop()`) — đáng tin cậy hơn tự tra
        // lại `getActiveTab()` ở đây vì đã trôi qua ít nhất 1 vòng round-
        // trip JS (bước bấm input thật) kể từ lúc thả, tab active LÝ
        // THUYẾT có thể đã đổi trong khoảng đó. Chỉ tự tra lại khi hàm này
        // được gọi từ nơi khác không truyền tham số (hiện tại chỉ có 1 nơi
        // gọi, nhưng giữ fallback để hàm vẫn dùng độc lập được nếu cần).
        val dropTabId = pinnedTabId ?: engine.getActiveTab()?.id
        if (dropTabId == null) {
            DebugLog.log("Khe $slotIndex: [kéo-thả] HUỶ — không có tab active nào để neo thao tác kéo-thả")
            Toast.makeText(this, "Kéo-thả không thành công: không xác định được tab đích", Toast.LENGTH_LONG).show()
            return
        }
        fun evalOnDropTab(script: String, callback: ((String?) -> Unit)?) {
            engine.evaluateJsPinnedToTab(dropTabId, script, callback)
        }

        val CHUNK_BYTES = 4 * 1024 * 1024 // 4MB thô mỗi chunk (~5.3MB sau base64) — cân bằng giữa số round-trip và kích thước mỗi message qua cầu WebExtension port
        val dropId = "d${System.nanoTime()}_$slotIndex"
        val builderVar = "window.__lbDrop_$dropId"

        data class DropFile(val index: Int, val name: String, val mime: String, val uri: Uri, val declaredSize: Long)

        val files = uris.mapIndexed { idx, uri ->
            DropFile(
                index = idx,
                name = getFileNameFromUriPublic(uri) ?: "file_${System.currentTimeMillis()}_$idx",
                mime = contentResolver.getType(uri) ?: "application/octet-stream",
                uri = uri,
                declaredSize = getDeclaredSizeOrZero(uri)
            )
        }
        val totalDeclaredSize = files.sumOf { it.declaredSize }
        // Báo tiến độ cho file lớn — người dùng dễ tưởng app treo nếu
        // im lặng nhiều giây trong lúc gửi chunk (file 100-300MB có thể
        // mất vài chục giây do nhiều round-trip qua cầu WebExtension).
        if (totalDeclaredSize > 20L * 1024 * 1024) {
            handler.post {
                Toast.makeText(this@MainActivity, "Đang tải file lớn lên trang, vui lòng đợi...", Toast.LENGTH_SHORT).show()
            }
        }

        // AtomicBoolean thay vì `var` thường — biến này được ĐỌC/GHI từ
        // nhiều Thread khác nhau (Thread nền đọc file của từng file, main
        // thread trong callback evaluateJs) nên cần đảm bảo visibility
        // đúng giữa các thread (`@Volatile` không áp dụng được cho biến
        // local trong Kotlin/JVM).
        val failed = java.util.concurrent.atomic.AtomicBoolean(false)
        var totalChunksSent = 0

        // Hàng đợi các "công việc" chạy TUẦN TỰ — mỗi công việc tự gọi
        // `runNext()` khi xong (thành công) để lấy công việc kế tiếp,
        // đảm bảo KHÔNG BAO GIỜ 2 chunk (hay 1 chunk + bước lắp Blob
        // cuối) chạy chồng lên nhau.
        val queue = ArrayDeque<() -> Unit>()
        fun runNext() {
            if (failed.get()) return
            queue.removeFirstOrNull()?.invoke()
        }

        fun abortWithToast(reason: String) {
            if (!failed.compareAndSet(false, true)) return // đã abort từ nhánh khác rồi — tránh Toast/log lặp 2 lần
            DebugLog.log("Khe $slotIndex: [kéo-thả chunk $dropId] HUỶ — $reason")
            handler.post {
                // Dọn builder JS-side để không rò rỉ (dù thất bại giữa
                // chừng, các Uint8Array đã push vào `parts` cần được GC).
                evalOnDropTab("try { delete $builderVar; } catch(e) {}", null)
                Toast.makeText(
                    this@MainActivity,
                    "Kéo-thả không thành công: file quá lớn hoặc trang này không nhận file thả trực tiếp. " +
                        "Dùng nút tải lên riêng của trang thay vì kéo-thả.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        // Bước 1: khởi tạo builder rỗng cho từng file ở phía JS.
        queue.addLast {
            val initScript = buildString {
                append("(function(){ $builderVar = {}; ")
                files.forEach { f ->
                    append("$builderVar[${f.index}] = { name: ${JSONObject.quote(f.name)}, type: ${JSONObject.quote(f.mime)}, parts: [] }; ")
                }
                append("return 'INIT_OK'; })();")
            }
            handler.post {
                evalOnDropTab(initScript) { result ->
                    if (result == null || result.startsWith("ERR")) {
                        abortWithToast("init builder thất bại: $result")
                        return@evalOnDropTab
                    }
                    runNext()
                }
            }
        }

        // Bước 2: với MỖI file, đọc input stream theo từng chunk và gửi
        // tuần tự — việc đọc byte (blocking I/O) LUÔN chạy trên 1 Thread
        // nền riêng (không đụng main thread), còn việc chờ callback
        // evaluateJs xác nhận xong chunk dùng CountDownLatch để "khớp
        // nhịp" giữa Thread nền (đang đọc file) và callback bất đồng bộ
        // (chạy trên main thread) — đây là cơ chế backpressure thật.
        files.forEach { f ->
            queue.addLast {
                Thread {
                    var chunkIndex = 0
                    try {
                        val stream = contentResolver.openInputStream(f.uri)
                        if (stream == null) {
                            abortWithToast("không mở được input stream cho '${f.name}' (${f.uri})")
                            return@Thread
                        }
                        stream.use { input ->
                            val buffer = ByteArray(CHUNK_BYTES)
                            while (!failed.get()) {
                                val read = input.read(buffer)
                                if (read <= 0) break
                                val chunkBytes = if (read == buffer.size) buffer else buffer.copyOf(read)
                                val b64 = android.util.Base64.encodeToString(chunkBytes, android.util.Base64.NO_WRAP)
                                val chunkScript = """
                                    (function(){
                                        try {
                                            var b = $builderVar[${f.index}];
                                            var byteChars = atob('$b64');
                                            var byteArray = new Uint8Array(byteChars.length);
                                            for (var i = 0; i < byteChars.length; i++) byteArray[i] = byteChars.charCodeAt(i);
                                            // SỬA (mục 62.2 PROJECT_STATUS.md — nâng độ tin cậy thật cho
                                            // cap 1GB, không chỉ "nâng số rồi để đó chưa test"). Tra cứu
                                            // xác nhận (bài viết kỹ thuật "Why Your Browser Chokes on Big
                                            // Payloads" + tài liệu hệ thống Blob của Chromium): `atob()`
                                            // tạo ra 1 CHUỖI UTF-16 trung gian (`byteChars`) — mỗi ký tự
                                            // chiếm 2 byte dù chỉ biểu diễn đúng 1 byte nhị phân thật, tức
                                            // ĐỈNH bộ nhớ tạm thời cho MỖI CHUNK cao hơn hẳn kích thước
                                            // chunk thật (chunk 4MB có thể tạm chiếm 8-10MB trong khoảnh
                                            // khắc `byteChars` + `byteArray` cùng tồn tại). Với file 1GB
                                            // (~256 chunk), nếu GC không kịp dọn `byteChars` giữa các
                                            // chunk (biến cục bộ trong IIFE, về lý thuyết đã hết root
                                            // ngay khi hàm return, nhưng dọn TƯỜNG MINH vẫn tốt hơn dựa
                                            // hoàn toàn vào suy đoán thời điểm GC chạy — đúng khuyến nghị
                                            // "phải chủ động dereference nếu không cần nữa" của chính tài
                                            // liệu Chromium Blob): gán `null` ngay sau khi dùng xong,
                                            // trước khi hàm return, để KHÔNG phụ thuộc vào việc JS engine
                                            // tự nhận ra biến cục bộ hết phạm vi kịp thời trong 1 vòng
                                            // lặp gọi hàm này hàng trăm lần liên tiếp.
                                            byteChars = null;
                                            b.parts.push(byteArray);
                                            // SỬA (kéo-thả Drive HUỶ ở chunk #85/~320MB, log
                                            // 'lỗi: null' — xác nhận qua log thật người dùng gửi,
                                            // không phải suy đoán). Tra cứu (nodejs/performance#173,
                                            // yonatankra.com về GC khi push mảng lớn liên tục) xác
                                            // nhận: một mảng JS thường (`parts: []`) push liên tục
                                            // hàng trăm Uint8Array lớn khiến JS engine phải liên tục
                                            // cấp phát lại vùng nhớ liền kề cho TOÀN BỘ mảng (không
                                            // phải chỉ phần tử mới) — chi phí mỗi lần push TĂNG DẦN
                                            // theo độ dài mảng, không phải hằng số như tưởng. Với
                                            // CHUNK_BYTES=4MB, tới chunk #85 mảng đã giữ ~340MB dữ
                                            // liệu trong ~85 phần tử — độ trễ mỗi lần push cộng dồn
                                            // hoàn toàn có thể vượt quá timeout 15s nội bộ của
                                            // evaluateJsForTab (kết quả: callback không bao giờ tới,
                                            // Kotlin nhận null) — khớp đúng vị trí dừng quan sát được
                                            // (không phải dừng ngay đầu, không phải dừng ở cuối gần
                                            // giới hạn cap, mà dừng ở khoảng giữa khi mảng đã đủ lớn
                                            // để chi phí tích luỹ vượt ngưỡng).
                                            //
                                            // Sửa: gộp Blob TRUNG GIAN định kỳ mỗi 20 chunk (~80MB)
                                            // thay vì giữ mảng Uint8Array thô tăng vô hạn. Sau khi
                                            // gộp, mảng `parts` được THAY THẾ bằng 1 mảng mới chỉ
                                            // chứa các Blob đã gộp — không bao giờ có quá ~20 phần
                                            // tử Uint8Array thô cùng lúc, giữ chi phí mỗi lần push
                                            // gần như hằng số suốt quá trình, bất kể file lớn tới đâu.
                                            // new Blob() nhận cả Uint8Array lẫn Blob trong cùng mảng
                                            // nên bước lắp Blob cuối (assembleScript) không cần đổi gì.
                                            if (b.parts.length >= 20) {
                                                var merged = new Blob(b.parts, {type: b.type});
                                                b.parts = [merged];
                                            }
                                            return 'CHUNK_OK';
                                        } catch (e) {
                                            return 'ERR: ' + (e && e.message ? e.message : String(e));
                                        }
                                    })();
                                """.trimIndent()
                                val latch = java.util.concurrent.CountDownLatch(1)
                                handler.post {
                                    evalOnDropTab(chunkScript) { result ->
                                        totalChunksSent++
                                        if (result == null || result.startsWith("ERR")) {
                                            abortWithToast("chunk #$chunkIndex file '${f.name}' lỗi: $result")
                                        }
                                        latch.countDown()
                                    }
                                }
                                // Timeout chờ 1 chunk dài hơn timeout nội bộ
                                // 15s của evaluateJsForTab (đã có sẵn cơ chế
                                // tự huỷ + trả null nếu port không phản hồi —
                                // xem evaluateJsForTab) — 20s ở đây chỉ là
                                // lưới an toàn phụ, tránh Thread nền treo
                                // vĩnh viễn nếu vì lý do gì đó latch không
                                // bao giờ được đếm xuống.
                                val gotResponse = latch.await(20, java.util.concurrent.TimeUnit.SECONDS)
                                if (!gotResponse && !failed.get()) {
                                    abortWithToast("chunk #$chunkIndex file '${f.name}' không phản hồi sau 20s")
                                }
                                chunkIndex++
                                if (chunkIndex % 10 == 0) {
                                    DebugLog.log("Khe $slotIndex: [kéo-thả chunk $dropId] '${f.name}' đã gửi ~${chunkIndex * CHUNK_BYTES / (1024 * 1024)}MB")
                                }
                            }
                        }
                    } catch (e: Exception) {
                        abortWithToast("đọc file '${f.name}' lỗi: ${e.message}")
                        return@Thread
                    }
                    if (!failed.get()) runNext()
                }.start()
            }
        }

        // Bước 3: lắp Blob/File/DataTransfer THẬT từ các `parts` đã gom,
        // rồi bắn drop — GIỮ NGUYÊN logic INPUT_PATH/DROP_PATH đã xác
        // nhận đúng qua test thật ở 2 site khác nhau (chat.deepseek.com
        // dùng DROP_PATH, Colab dùng INPUT_PATH — xem chú thích gốc).
        queue.addLast {
            val assembleScript = """
                (function(){
                    try {
                        var builder = $builderVar || {};
                        var keys = Object.keys(builder).map(Number).sort(function(a,b){return a-b;});
                        var files = keys.map(function(k){
                            var f = builder[k];
                            var blob = new Blob(f.parts, {type: f.type});
                            return new File([blob], f.name, {type: f.type});
                        });
                        var dt = new DataTransfer();
                        files.forEach(function(f){ dt.items.add(f); });
                        delete $builderVar; // dọn ngay khi Blob thật đã lắp xong — không giữ 2 bản dữ liệu song song

                        // Xem chú thích gốc (mục cũ) về lý do bắn dragleave
                        // dọn dẹp SAU cả 2 nhánh — Gecko có thể đã tự kích
                        // hoạt overlay dragenter/dragover THẬT trên trang
                        // trước khi ta xử lý xong ACTION_DROP, nên cần dọn
                        // dù đi nhánh nào.
                        var fileInputs = document.querySelectorAll('input[type="file"]');
                        if (fileInputs.length > 0) {
                            var results = [];
                            for (var fi = 0; fi < fileInputs.length; fi++) {
                                try {
                                    fileInputs[fi].files = dt.files;
                                    fileInputs[fi].dispatchEvent(new Event('input', {bubbles: true}));
                                    fileInputs[fi].dispatchEvent(new Event('change', {bubbles: true}));
                                    results.push('input[' + fi + '] OK');
                                } catch (e2) {
                                    results.push('input[' + fi + '] LỖI: ' + (e2 && e2.message ? e2.message : String(e2)));
                                }
                            }
                            try {
                                document.dispatchEvent(new DragEvent('dragleave', {bubbles: true, cancelable: true, dataTransfer: dt}));
                            } catch (e3) { /* không sao nếu lỗi — chỉ là dọn dẹp thêm cho chắc */ }
                            return 'INPUT_PATH: tìm thấy ' + fileInputs.length + ' input[type=file] — ' + results.join('; ');
                        }

                        var cssX = ${xFrac} * window.innerWidth;
                        var cssY = ${yFrac} * window.innerHeight;
                        var el = document.elementFromPoint(cssX, cssY) || document.body;
                        ['dragenter','dragover','drop'].forEach(function(type){
                            var ev = new DragEvent(type, {bubbles: true, cancelable: true, dataTransfer: dt});
                            el.dispatchEvent(ev);
                        });
                        try {
                            document.dispatchEvent(new DragEvent('dragleave', {bubbles: true, cancelable: true, dataTransfer: dt}));
                        } catch (e3) { /* không sao nếu lỗi — chỉ là dọn dẹp thêm cho chắc */ }
                        return 'DROP_PATH (không tìm thấy input[type=file] nào, KHÔNG chắc trang có xử lý không): dispatched ' + files.length + ' file(s) to <' + (el.tagName || '?') + '>';
                    } catch (e) {
                        return 'ERR: ' + (e && e.message ? e.message : String(e));
                    }
                })();
            """.trimIndent()
            handler.post {
                evalOnDropTab(assembleScript) { result ->
                    DebugLog.log("Khe $slotIndex: [kéo-thả chunk $dropId] lắp Blob/File xong (tổng $totalChunksSent chunk đã gửi) — kết quả JS: $result")
                    if (result != null && result.startsWith("ERR")) {
                        handler.post {
                            Toast.makeText(
                                this@MainActivity,
                                "Kéo-thả không thành công: file quá lớn hoặc trang này không nhận file thả trực tiếp. " +
                                    "Dùng nút tải lên riêng của trang thay vì kéo-thả.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        }

        runNext()
    }

    private fun copyToAppStorageAsFileProviderUri(sourceUri: Uri): Uri? {
        return try {
            cleanupOldUploadCache()
            val fileName = getFileNameFromUriPublic(sourceUri) ?: "upload_${System.currentTimeMillis()}"
            val dir = File(cacheDir, "uploads").apply { mkdirs() }
            val destFile = File(dir, "${System.currentTimeMillis()}_$fileName")
            val bytesCopied = contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            }
            if (bytesCopied == null) {
                DebugLog.log("copyToAppStorageAsFileProviderUri: openInputStream trả về null cho $sourceUri — CHÍNH tiến trình app này cũng không đọc được nguồn (không phải vấn đề riêng của Gecko)")
                return null
            }
            DebugLog.log("copyToAppStorageAsFileProviderUri: copy xong $bytesCopied byte vào ${destFile.path} — dùng Uri.fromFile() (file://), KHÔNG dùng FileProvider (content://) vì GeckoView từ chối content://")
            Uri.fromFile(destFile)
        } catch (e: Exception) {
            DebugLog.log("copyToAppStorageAsFileProviderUri lỗi: ${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }

    private fun getFileNameFromUriPublic(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        return result ?: uri.lastPathSegment
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Khe này (singleTask) ĐÃ ĐANG CHẠY SẴN — Android gọi đây thay vì
        // onCreate() lại. Trước đây không xử lý gì cả, nên "Mở ở khe khác"
        // im lặng KHÔNG mở link nếu khe đích đã mở sẵn từ trước (chỉ đưa
        // khe đó lên foreground, giữ nguyên trang đang xem).
        val openUrl = intent.getStringExtra("open_url")
        if (openUrl != null) {
            engine.createTab(openUrl)
            refreshTabBar()
        }
    }

    /**
     * CHẨN ĐOÁN cho vụ "YouTube tắt tiếng khi khoá màn hình/chuyển app" —
     * bản visibility-spoof JS (BackgroundMediaFeature, mục 8b-8d) đã xác
     * nhận KHÔNG đủ (người dùng test bản mới nhất vẫn còn lỗi). Nguyên
     * nhân còn lại nhiều khả năng nằm ở tầng GeckoView/Android — ví dụ
     * GeckoView có thể tự huỷ Surface render (và có thể cả audio) khi
     * Activity mất hiển thị — nhưng đây là hành vi NỘI BỘ của thư viện
     * GeckoView, không có API public để đọc thẳng, và đoán mò API
     * (`GeckoSession.MediaSession.Delegate` chẳng hạn) mà không có mạng để
     * tra đúng chữ ký hàm RẤT dễ đoán sai → gãy build (đã từng xảy ra với
     * `element.linkText`, không muốn lặp lại).
     *
     * Nên thay vì đoán tiếp, ghi log các mốc vòng đời Activity — CHỈ dùng
     * API Android chuẩn, không đụng gì tới GeckoView. Sau khi bạn build
     * bản này, tái hiện lỗi (mở YouTube, khoá màn hình vài giây, mở lại),
     * vào Menu ⋮ → Debug Log, copy đoạn quanh lúc đó gửi lại — sẽ biết
     * chính xác Activity có bị onStop() không, cách nhau bao lâu, từ đó
     * mới sửa đúng chỗ thay vì đoán mò.
     */
    override fun onPause() {
        super.onPause()
        DebugLog.log("Khe $slotIndex: MainActivity.onPause() — Activity mất foreground")
        imeVisibleNow = false // mất foreground thì không còn "đang gõ" — để Auto Behavior chạy lại được khi tắt màn hình
        selectionFallback?.dismiss()
        // FIX BUG THẬT (upload Drive "đi ngủ" khi tắt màn hình dù đã ghim
        // chạy nền — xem chú thích đầy đủ ở
        // GeckoViewEngine.applyBackgroundPriorityForActiveTabIfExempt()):
        // đây là điểm móc DUY NHẤT bao trùm cả "tắt màn hình" lẫn "chuyển
        // sang app khác" (Android gọi onPause()/onStop() giống nhau cho cả
        // 2 kịch bản, không phân biệt được) — gọi TRƯỚC khi surface có thể
        // bị huỷ, để kịp báo Gecko giữ ưu tiên cao cho tab đang active nếu
        // nó nằm trong danh sách ghim.
        if (::engine.isInitialized) {
            engine.applyBackgroundPriorityForActiveTabIfExempt()
            // Lưới an toàn cuối (xem chú thích đầy đủ ở
            // `refreshKeepAliveServiceState()`): đã gọi hàm này ở
            // mọi điểm ghim/bỏ ghim thay đổi rồi, nhưng gọi LẠI ở đây
            // trước khi mất surface là để chắc chắn 100% — phòng trường
            // hợp trạng thái ghim đổi qua đường nào đó chưa lường hết
            // (VD: khôi phục từ backup profile có sẵn domain ghim mà
            // chưa từng qua các hàm trên trong phiên này).
            refreshKeepAliveServiceState()
        }
        // Lưu danh sách tab mỗi lần mất foreground — mốc lưu đáng tin cậy,
        // xem giải thích lớn ở `GeckoViewEngine.saveTabsState()`.
        // CHẶN ghi đè rỗng nếu đã lưu đúng lúc bắt đầu đóng khe đàng hoàng
        // (xem gracefulCloseReceiver) — release() đã xoá tabMeta trước khi
        // onPause() này chạy, gọi lại saveTabsState() ở đây sẽ ghi mảng
        // RỖNG và XOÁ file vừa lưu đúng, y hệt bug đã tìm và sửa.
        if (!tabsSavedForShutdown && ::engine.isInitialized) {
            engine.saveTabsState()
        }
    }

    override fun onStop() {
        super.onStop()
        DebugLog.log("Khe $slotIndex: MainActivity.onStop() — Activity không còn hiển thị (surface có thể bị huỷ ở đây)")
    }

    override fun onResume() {
        super.onResume()
        DebugLog.log("Khe $slotIndex: MainActivity.onResume() — Activity quay lại foreground")
        updateTaskDescription() // đề phòng người dùng đổi tên hồ sơ qua ProfilePickerActivity rồi quay lại (không tự khởi động lại tiến trình trong mọi trường hợp)
        // FIX ĐỒNG BỘ (người dùng yêu cầu: sửa domain "chạy nền" ở Cài đặt
        // thì nút ghim trên thanh URL + huy hiệu trên lưới tab phải tự cập
        // nhật, không cần thao tác gì thêm): `FeatureSettingsActivity`
        // (nơi hiện `BackgroundKeepAliveFeature.buildSettingsView()`) là 1
        // Activity RIÊNG — đóng nó lại thì `onResume()` của MainActivity
        // TỰ ĐỘNG được gọi theo đúng vòng đời chuẩn của Android, không cần
        // tự bắn callback/broadcast gì thêm giữa 2 Activity. Đây là điểm
        // MÓC tự nhiên duy nhất cần thêm để "Cài đặt" đồng bộ với 2 chỗ
        // còn lại — cả 2 hàm dưới đây đều tự đọc LẠI dữ liệu mới nhất từ
        // `AppPrefs` mỗi lần được gọi (không cache), nên gọi lại là đủ,
        // không cần biết CHÍNH XÁC Cài đặt vừa đổi gì.
        if (::pinButton.isInitialized) updatePinButton(lastLoadedUrl)
        activeTabSwitcherRefresh?.invoke()
        refreshKeepAliveServiceState()
    }

    /**
     * BUG THẬT (người dùng chụp ảnh Recent Apps — mọi thẻ khe đều hiện
     * cùng 1 icon/tên app mặc định, không phân biệt được khe nào là khe
     * nào): `taskAffinity` khai báo đúng trong Manifest (mỗi khe ĐÃ LÀ 1
     * thẻ Recent Apps riêng biệt thật) nhưng CHƯA TỪNG gọi
     * `setTaskDescription()` — API Android CHUYÊN DÙNG để đặt tên/icon
     * riêng cho từng thẻ Recent Apps, khác hẳn tên app chung khai báo tĩnh
     * trong Manifest (`android:label` ở mức <application>, giống nhau cho
     * mọi activity/task theo mặc định).
     */
    private fun updateTaskDescription() {
        val profileName = ProfileSlots.getSlotAssignment(this, slotIndex)
        val label = "Khe $slotIndex — $profileName"
        try {
            val icon = buildSlotTaskIcon(slotIndex)
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN TaskDescription] chuẩn bị gọi setTaskDescription() — label='$label', icon=${icon.width}x${icon.height}, slotIndex=$slotIndex")
            /**
             * BUG THẬT vẫn còn (ảnh chụp Recent Apps MỚI của người dùng
             * xác nhận: CẢ 2 thẻ khác khe vẫn hiện Y HỆT icon "địa cầu
             * xanh #1A73E8" — TRÙNG CHÍNH XÁC màu+hình `ic_launcher_background`/
             * `ic_launcher_foreground` (icon app TĨNH mặc định khai báo ở
             * <application> trong Manifest), dù log xác nhận
             * `setTaskDescription()` "ĐÃ GỌI XONG, không ném exception").
             *
             * Lượt sửa TRƯỚC (dùng `Builder().setIcon(resourceId)` trỏ tới
             * `ic_task_slot_N.xml` — 4 file VECTOR thuần, mỗi file 1 màu
             * riêng) đúng theo khuyến nghị deprecation của Android
             * Developers, NHƯNG log/ảnh mới vẫn cho thấy y hệt triệu chứng
             * cũ — tức lượt sửa đó CHƯA GIẢI QUYẾT ĐƯỢC (dù đúng theo tài
             * liệu, có thể do: (a) bản cài trên máy lúc chụp ảnh chưa build
             * lại với patch mới nhất — lỗi hay gặp xuyên suốt dự án này; hoặc
             * (b) `setIcon(int)` không decode đúng 1 file VECTOR thuần trên
             * ROM/launcher máy này, âm thầm rơi về icon app tĩnh — KHÔNG
             * đủ bằng chứng để khẳng định chắc chắn cái nào, không đoán
             * mù thêm).
             *
             * Sửa AN TOÀN không phụ thuộc phân biệt đúng 2 khả năng trên:
             * QUAY LẠI dùng constructor `TaskDescription(label, Bitmap)`
             * cho MỌI phiên bản SDK — dù bị đánh dấu `@Deprecated`, tài
             * liệu Android Developers chỉ ghi đây là KHUYẾN NGHỊ đổi cách
             * khác (ưu tiên hiệu năng/bộ nhớ), KHÔNG ghi là "không còn hoạt
             * động" — chỉ riêng `TaskDescription.getIcon()` (đọc lại icon)
             * mới thật sự "no longer supported", còn việc SET icon qua
             * Bitmap vẫn hoạt động đúng trên thực tế qua nhiều năm. Dùng
             * lại Bitmap RUNTIME (`buildSlotTaskIcon()` — vẽ vòng tròn màu
             * RIÊNG + SỐ KHE lớn ở giữa) cũng cho khả năng phân biệt CHẮC
             * CHẮN hơn hẳn 4 file vector chỉ khác màu (nếu 1 trong 2 khe
             * hiển thị sai màu do màn hình/mù màu, số vẫn đọc được).
             *
             * NẾU sau khi build lại vẫn còn y hệt icon tĩnh mặc định (đã
             * loại trừ được khả năng (a) — chắc chắn cài đúng bản mới),
             * đây sẽ là bằng chứng THẬT đầu tiên cho khả năng (b): launcher/
             * ROM máy không tôn trọng icon động qua Bitmap NỮA (giới hạn
             * ngoài tầm code, không phải do gọi sai API) — cần ảnh chụp
             * kèm rõ version app lúc đó để xác nhận, không đoán tiếp.
             */
            @Suppress("DEPRECATION")
            setTaskDescription(android.app.ActivityManager.TaskDescription(label, icon))
            DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN TaskDescription] setTaskDescription() ĐÃ GỌI XONG, không ném exception")
            /**
             * FIX LOG THẬT (đúng phê bình của người dùng: "tại sao không
             * tự làm log mà đẩy qua cho người dùng chạy adb"): thay vì bắt
             * người dùng tự chạy `adb shell dumpsys activity recents`,
             * TỰ ĐỌC LẠI ngay trong app xem hệ thống có thật sự lưu đúng
             * label/icon vừa set hay không, qua
             * `ActivityManager.getAppTasks()` — API CHÍNH THỨC, public,
             * không cần quyền đặc biệt, trả về danh sách task CỦA CHÍNH
             * APP NÀY kèm `taskInfo.taskDescription` hiện tại.
             *
             * Đây chính là "bằng chứng THẬT ở tầng hệ thống" mà lượt trước
             * phải nhờ người dùng chạy adb mới lấy được — giờ tự lấy được
             * ngay trong log bình thường, không cần thêm bước gì từ người
             * dùng nữa. Đọc NGAY SAU KHI gọi setTaskDescription() (cùng 1
             * lần gọi hàm, không có gì chen giữa) để chắc chắn không phải
             * do timing.
             *
             * Cách đọc: so khớp CHÍNH XÁC theo `taskId` của Activity hiện
             * tại (`this.taskId`) — vì `getAppTasks()` trả về TẤT CẢ task
             * của app (có thể nhiều khe cùng lúc), so theo taskId tránh
             * đọc nhầm task của khe KHÁC.
             */
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                val myTaskId = this.taskId
                val matchingTask = am.appTasks.firstOrNull { it.taskInfo?.taskId == myTaskId }
                if (matchingTask == null) {
                    DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN TaskDescription tự-kiểm] KHÔNG tìm thấy task nào có taskId=$myTaskId trong getAppTasks() (tổng ${am.appTasks.size} task) — bất thường, không đọc lại được để xác minh")
                } else {
                    val td = matchingTask.taskInfo?.taskDescription
                    val systemLabel = td?.label
                    // getIcon() bị deprecated ("no longer supported") nên
                    // KHÔNG gọi — chỉ đọc lại LABEL, đã đủ để xác minh hệ
                    // thống có tôn trọng setTaskDescription() của app này
                    // hay không (nếu label KHÔNG đúng, gần như chắc chắn
                    // icon cũng bị bỏ qua tương tự — 2 field cùng nằm
                    // trong 1 lần gọi setTaskDescription() như nhau).
                    if (systemLabel == label) {
                        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN TaskDescription tự-kiểm] ĐÚNG — hệ thống (getAppTasks) xác nhận đang lưu label='$systemLabel' khớp với những gì app vừa set. Nếu Recent Apps VẪN hiện icon/label sai dù dòng log NÀY đúng, bằng chứng CHẮC CHẮN chỉ ra lỗi nằm ở tầng RENDER của launcher/System UI (ngoài tầm code sửa được), không phải do app gọi sai.")
                    } else {
                        DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN TaskDescription tự-kiểm] SAI — app vừa set label='$label' nhưng getAppTasks() đọc lại được label='$systemLabel' (KHÔNG khớp). Đây là bằng chứng THẬT, ở tầng hệ thống, cho thấy setTaskDescription() bị hệ thống ÂM THẦM BỎ QUA hoặc GHI ĐÈ LẠI ngay sau đó bởi thứ gì khác — cần tra tiếp CÁI GÌ đang ghi đè, không phải launcher không render đúng.")
                    }
                }
            } catch (e: Exception) {
                DebugLog.log("Khe $slotIndex: [CHẨN ĐOÁN TaskDescription tự-kiểm] lỗi khi tự đọc lại qua getAppTasks(): ${e.javaClass.simpleName}: ${e.message}")
            }
        } catch (e: Exception) {
            DebugLog.log("updateTaskDescription lỗi: ${e.message}")
        }
    }

    /** Vẽ icon tròn MÀU RIÊNG theo khe + số khe lớn ở giữa — dùng cho thẻ
     * Recent Apps (xem `updateTaskDescription()`). Vẽ bằng Canvas thuần,
     * không cần asset ảnh nào — luôn khớp đúng SLOT_COUNT dù thêm/bớt khe
     * sau này (màu lặp lại theo chu kỳ nếu vượt quá danh sách màu). */
    private fun buildSlotTaskIcon(slotIndex: Int): android.graphics.Bitmap {
        val colors = intArrayOf(
            Color.parseColor("#1A73E8"), // Khe 0 — xanh dương
            Color.parseColor("#0F9D58"), // Khe 1 — xanh lá
            Color.parseColor("#F4511E"), // Khe 2 — cam
            Color.parseColor("#8E24AA")  // Khe 3 — tím
        )
        val bgColor = colors[slotIndex % colors.size]
        val size = dp(72)
        val bitmap = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val circlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = bgColor
            style = android.graphics.Paint.Style.FILL
        }
        val radius = size / 2f
        canvas.drawCircle(radius, radius, radius, circlePaint)
        val textPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = size * 0.5f
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        val textY = radius - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(slotIndex.toString(), radius, textY, textPaint)
        return bitmap
    }

    override fun onDestroy() {
        handler.removeCallbacks(featureTickRunnable)
        gracefulCloseReceiver?.let {
            try { unregisterReceiver(it) } catch (e: Exception) { /* đã bị gỡ trước đó, bỏ qua */ }
        }
        keepAliveStoppedReceiver?.let {
            try { unregisterReceiver(it) } catch (e: Exception) { /* đã bị gỡ trước đó, bỏ qua */ }
        }
        // LIÊN QUAN TRỰC TIẾP tới ColabLiveKeeperFeature (giữ phiên Colab
        // "sống" khi nền) + BackgroundMediaFeature: `onDestroy()` KHÔNG chỉ
        // xảy ra khi người dùng THẬT SỰ đóng khe — Android cũng gọi
        // `onDestroy()` khi tự thu hồi bộ nhớ của 1 Activity đang ở nền
        // (trong khi TIẾN TRÌNH + task vẫn còn, đúng như tình huống gây
        // crash ở mục 8g). TRƯỚC ĐÂY `engine.release()` (đóng TẤT CẢ tab,
        // gồm cả tab Colab/YouTube đang chạy nền) chạy VÔ ĐIỀU KIỆN mỗi lần
        // `onDestroy()` — nghĩa là mỗi lần Android âm thầm thu hồi Activity
        // nền, tab Colab/YouTube bị ĐÓNG THẬT (không phải chỉ tạm ẩn), làm
        // mất hết tác dụng của việc "giữ chạy nền" dù GeckoRuntime bên dưới
        // vẫn còn sống. Dùng `isFinishing` để phân biệt: đúng là đang đóng
        // hẳn khe (người dùng bấm back/thoát hẳn) thì mới đóng tab; còn
        // Android tự thu hồi Activity để dọn RAM (task/tiến trình vẫn còn)
        // thì GIỮ NGUYÊN tab, không đóng gì cả — lần sau `onCreate()` mở lại
        // (cùng tiến trình, xem 8g) sẽ tự thấy engine/tab cũ vẫn còn.
        if (isFinishing) {
            DebugLog.log("Khe $slotIndex: MainActivity.onDestroy() — isFinishing=true, đóng hẳn khe, đóng tab")
            // BUG THẬT (crash lúc mở app, log xác nhận
            // "UninitializedPropertyAccessException: lateinit property
            // engine has not been initialized" ngay tại dòng gọi
            // `engine.release()` này): lượt trước thêm gate
            // `EXTRA_SKIP_PICKER` ở đầu `onCreate()` — khi KHÔNG có cờ này,
            // hàm `finish()` được gọi để chuyển sang `ProfilePickerActivity`
            // NGAY TỪ ĐẦU, TRƯỚC CẢ `setupEngine()` (nơi duy nhất gán giá
            // trị cho `engine`). Activity bị `finish()` sớm như vậy vẫn có
            // `onDestroy()` chạy bình thường (đúng vòng đời Android), nhưng
            // lúc đó `engine` (lateinit) CHƯA TỪNG được gán — gọi
            // `engine.release()` vô điều kiện ở đây ném thẳng exception,
            // crash app NGAY LẦN MỞ ĐẦU TIÊN. Sửa: kiểm tra
            // `::engine.isInitialized` trước khi đụng vào `engine` — nếu
            // Activity bị đóng trước khi kịp khởi tạo engine (đúng trường
            // hợp gate picker này), không có gì để giải phóng cả, bỏ qua
            // an toàn thay vì crash.
            if (::engine.isInitialized) {
                engine.release()
            } else {
                DebugLog.log("Khe $slotIndex: onDestroy() — engine chưa từng được khởi tạo (Activity bị finish() sớm, ví dụ do gate màn hình chọn khe) — bỏ qua engine.release()")
            }
        } else {
            DebugLog.log("Khe $slotIndex: MainActivity.onDestroy() — isFinishing=false (Android tự thu hồi Activity nền), GIỮ tab đang chạy")
        }
        // BUG THẬT ĐÃ SỬA (nguyên nhân THẬT SỰ của crash "Only one
        // GeckoRuntime instance is allowed" — 2 lượt crash log gửi lên đều
        // do CHÍNH XÁC dòng này, không phải race condition ở restartSlot()
        // như suy đoán trước): GeckoRuntime BẮT BUỘC phải sống suốt vòng đời
        // TIẾN TRÌNH (process) — đây là giới hạn cứng của Gecko, không phải
        // của app này: tạo được ĐÚNG 1 lần cho cả đời tiến trình, "release"
        // bao nhiêu lần cũng không cho phép tạo lại lần 2 trong CÙNG process.
        //
        // Dòng `GeckoRuntimeProvider.release(slotIndex)` trước đây gọi ở
        // ĐÂY — trong `onDestroy()` của Activity — nhưng `onDestroy()` KHÔNG
        // đồng nghĩa với "tiến trình sắp chết"! Android có thể huỷ Activity
        // (thu hồi bộ nhớ nền, xoay màn hình, v.v.) trong khi TIẾN TRÌNH vẫn
        // sống — mà `KeepAliveService` lại đang CỐ Ý giữ tiến trình sống
        // (đúng mục đích của service đó). Kết quả: `release()` chỉ xoá khỏi
        // map trong bộ nhớ (`runtimes.remove()`) — KHÔNG hề gọi
        // `runtime.shutdown()` — nên GeckoRuntime native cũ vẫn còn sống
        // nguyên trong tiến trình. Lần sau mở lại Khe này (vẫn CÙNG tiến
        // trình vì chưa từng chết), code tưởng map trống nên cố tạo runtime
        // MỚI → Gecko từ chối thẳng vì tiến trình đã "dùng" 1 lần rồi → crash
        // NGAY LẬP TỨC, không phải hiếm — gần như CHẮC CHẮN xảy ra mỗi lần
        // Android tự dọn Activity nền trong khi KeepAliveService còn giữ
        // tiến trình sống.
        //
        // Sửa: KHÔNG gọi `GeckoRuntimeProvider.release()` ở đây nữa.
        // GeckoRuntime cứ để sống trong map suốt đời tiến trình — mở lại
        // Activity (dù trong cùng tiến trình) sẽ tự tìm thấy runtime đã có
        // sẵn qua `getOrPut`, dùng lại đúng cách GeckoView được thiết kế để
        // dùng (tạo runtime 1 lần, dùng suốt đời process — giống Firefox
        // thật làm), không cần tạo lại.
        super.onDestroy()
    }

    override fun onBackPressed() {
        // TÍNH NĂNG MỚI: giống Chrome — nếu thanh "Tìm trong trang" đang mở,
        // nút Back đóng thanh tìm kiếm TRƯỚC (và xoá highlight), KHÔNG điều
        // hướng lùi trang ngay — tránh việc người dùng mất trang đang xem
        // chỉ vì muốn đóng thanh tìm kiếm.
        if (::findBarContainer.isInitialized && findBarContainer.visibility == View.VISIBLE) {
            hideFindInPageBar()
            return
        }
        if (engine.canGoBack()) {
            engine.goBack()
            return
        }
        // SỬA BUG THẬT (người dùng báo qua ảnh chụp màn hình: "khi 1 tab
        // nhảy ra từ tab khác, nhấn quay lại thay vì quay lại tab mà nó
        // nhảy ra, thì lại thoát trình duyệt"). Nguyên nhân: nhánh
        // `engine.canGoBack()` ở trên chỉ hỏi GeckoSession của tab ĐANG
        // ACTIVE xem CHÍNH TRANG ĐÓ có lịch sử điều hướng lùi hay không
        // (tương đương `session.navigateBack()` của Gecko) — nó không hề
        // biết gì về khái niệm "tab này được 1 tab khác mở ra" (popup qua
        // `window.open()`/`target="_blank"`, xem `openerTabId` trong
        // `BrowserTab`). Một tab popup vừa mở, chưa từng tự điều hướng bên
        // trong nó, luôn có `canGoBack()=false` — trước đây rơi thẳng
        // xuống `super.onBackPressed()` và thoát hẳn app, dù về mặt UX
        // người dùng chỉ muốn quay lại tab đã mở ra nó.
        //
        // `closeTab()` (GeckoViewEngine.kt) ĐÃ CÓ SẴN logic đúng — tự quay
        // về `openerTabId` nếu tab đó còn tồn tại, việc còn thiếu chỉ là
        // GỌI nó từ đây thay vì thoát app thẳng. Áp dụng rộng hơn cả
        // popup: nếu còn NHIỀU HƠN 1 TAB đang mở (bất kể có opener hay
        // không), đóng tab hiện tại và quay về tab trước đó vẫn hợp lý
        // hơn thoát hẳn app — giống hành vi Chrome/Firefox thật (nút Back
        // hệ thống trên trình duyệt nhiều tab không thoát app ngay khi còn
        // tab khác). CHỈ thoát app thật khi đây là TAB DUY NHẤT còn lại.
        val currentTabs = engine.getTabs()
        val activeTab = engine.getActiveTab()
        if (activeTab != null && currentTabs.size > 1) {
            DebugLog.log(
                "Khe $slotIndex: onBackPressed — tab '${activeTab.id}' hết lịch sử lùi, " +
                    "còn ${currentTabs.size} tab khác đang mở (opener=${activeTab.openerTabId}) " +
                    "→ đóng tab này thay vì thoát app"
            )
            engine.closeTab(activeTab.id)
            return
        }
        super.onBackPressed()
    }


}
