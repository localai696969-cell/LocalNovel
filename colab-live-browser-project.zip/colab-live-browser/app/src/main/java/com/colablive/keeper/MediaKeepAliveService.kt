package com.colablive.keeper

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.colablive.keeper.core.DebugLog

/**
 * BUG THẬT đã tìm ra (người dùng báo: "nút phát media trên thanh thông báo
 * nhấn vào không tắt nhạc, trước kia thì nhấn vào là tắt nhạc"): trước lượt
 * sửa gate `KeepAliveService.start()` theo đúng cờ `colablive_keepalive_on`
 * (fix bug "thông báo Colab Live chạy trước khi vào Colab"), service đó
 * chạy VÔ ĐIỀU KIỆN ở MỌI lần mở app — vô tình giữ luôn PROCESS sống ở nền
 * (foreground service = ưu tiên cao hơn hẳn app thường, khó bị hệ thống
 * đóng băng/giết khi xuống nền). Sau khi gate lại đúng thiết kế, nếu người
 * dùng CHỈ nghe nhạc nền (không bật Colab Live), process không còn được
 * bảo vệ nữa — dễ bị hệ thống đóng băng/giết khi app xuống nền, khiến
 * `BroadcastReceiver` đăng ký ĐỘNG trong code (`mediaActionReceiver` ở
 * GeckoViewEngine — CHỈ tồn tại khi process còn sống, khác receiver khai
 * báo trong Manifest) ngừng nhận được broadcast từ nút bấm trên thông báo.
 *
 * SỬA ĐÚNG GỐC (không phải vá lại KeepAliveService cho mục đích khác):
 * dựng 1 foreground service THẬT RIêng cho việc phát media — permission
 * `FOREGROUND_SERVICE_MEDIA_PLAYBACK` đã khai báo sẵn trong Manifest từ
 * trước nhưng CHƯA TỪNG có service nào thật sự dùng tới. Chỉ chạy khi CÓ
 * media đang phát, dừng khi tạm dừng/dừng hẳn — HOÀN TOÀN độc lập với cờ
 * `colablive_keepalive_on`.
 *
 * ĐA TIẾN TRÌNH: mỗi khe (slot) là 1 tiến trình Android RIÊNG (`MainActivity`
 * dùng process mặc định, `MainActivitySlot1/2/3` dùng `:slot1`/`:slot2`/
 * `:slot3` — xem AndroidManifest.xml). Service KHÔNG có `android:process`
 * riêng sẽ LUÔN chạy ở process MẶC ĐỊNH bất kể ai gọi startForegroundService
 * — nếu khe 1/2/3 (process riêng) gọi thẳng `MediaKeepAliveService`, sẽ vô
 * tình khởi động process MẶC ĐỊNH thay vì giữ ĐÚNG process của chính khe đó
 * sống — không đạt được mục đích. Nên cần 3 class con RỖNG (giống hệt
 * pattern `MainActivitySlot1/2/3` trong `MainActivitySlots.kt`) khai báo
 * `<service>` riêng với `android:process` khớp đúng từng khe.
 */
open class MediaKeepAliveService : Service() {

    companion object {
        private const val EXTRA_NOTIF_ID = "notif_id"
        private const val EXTRA_NOTIFICATION = "notification"

        /** Trả về ĐÚNG class con khớp process của khe hiện tại — gọi từ GeckoViewEngine (biết sẵn slotIndex). */
        fun classForSlot(slotIndex: Int): Class<out MediaKeepAliveService> = when (slotIndex) {
            1 -> MediaKeepAliveServiceSlot1::class.java
            2 -> MediaKeepAliveServiceSlot2::class.java
            3 -> MediaKeepAliveServiceSlot3::class.java
            else -> MediaKeepAliveService::class.java
        }

        fun start(context: Context, serviceClass: Class<out MediaKeepAliveService>, notifId: Int, notification: Notification) {
            try {
                val intent = Intent(context, serviceClass).apply {
                    putExtra(EXTRA_NOTIF_ID, notifId)
                    putExtra(EXTRA_NOTIFICATION, notification)
                }
                ContextCompat.startForegroundService(context, intent)
            } catch (e: Exception) {
                DebugLog.log("MediaKeepAliveService.start() lỗi: ${e.message}")
            }
        }

        fun stop(context: Context, serviceClass: Class<out MediaKeepAliveService>) {
            try {
                context.stopService(Intent(context, serviceClass))
            } catch (e: Exception) {
                DebugLog.log("MediaKeepAliveService.stop() lỗi: ${e.message}")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notifId = intent?.getIntExtra(EXTRA_NOTIF_ID, 3000) ?: 3000
        val notification: Notification? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent?.getParcelableExtra(EXTRA_NOTIFICATION, Notification::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_NOTIFICATION)
            }
        } catch (e: Exception) {
            null
        }
        if (notification != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(notifId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                } else {
                    startForeground(notifId, notification)
                }
            } catch (e: Exception) {
                DebugLog.log("MediaKeepAliveService: startForeground() lỗi (${e.message}) — dừng ngay để tránh crash treo")
                stopSelf()
            }
        } else {
            // Intent rỗng (KHÔNG dùng START_STICKY ở đây — xem return bên
            // dưới — nên trường hợp này chỉ xảy ra nếu có gì đó gọi
            // onStartCommand mà quên truyền notification, không phải do
            // Android tự restart). Không có gì để hiện, dừng luôn thay vì
            // treo 1 service không có foreground notification (sẽ crash).
            stopSelf()
        }
        // CỐ Ý dùng START_NOT_STICKY (khác KeepAliveService dùng
        // START_STICKY): service này không có state nào đáng để Android tự
        // khôi phục — nếu bị hệ thống giết vì thiếu bộ nhớ, nhiều khả năng
        // CẢ TIẾN TRÌNH (gồm GeckoRuntime, media đang phát) cũng đã chết
        // theo, không có gì để "tiếp tục phát" nữa. Tự restart vô nghĩa ở
        // đây (không có Notification nào lưu sẵn để phục hồi) chỉ tổ rước
        // thêm rủi ro crash-do-thiếu-startForeground như đã sửa ở
        // KeepAliveService — không lặp lại lỗi tương tự cho service mới.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// Xem giải thích ĐA TIẾN TRÌNH ở comment lớn phía trên — 3 class con RỖNG,
// mỗi cái chỉ để có 1 tên class riêng khai báo <service> với android:process
// khớp đúng từng khe trong AndroidManifest.xml.
class MediaKeepAliveServiceSlot1 : MediaKeepAliveService()
class MediaKeepAliveServiceSlot2 : MediaKeepAliveService()
class MediaKeepAliveServiceSlot3 : MediaKeepAliveService()
