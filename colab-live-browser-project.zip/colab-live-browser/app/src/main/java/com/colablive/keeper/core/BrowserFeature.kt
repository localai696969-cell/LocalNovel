package com.colablive.keeper.core

import android.content.Context
import android.view.View

/**
 * Interface chung cho mọi tiện ích (feature) của trình duyệt.
 * Mỗi feature implement interface này, đăng ký vào FeatureRegistry.
 * Không đụng MainActivity hay engine cụ thể.
 */
interface BrowserFeature {
    /** ID duy nhất, dùng làm key SharedPreferences */
    val id: String

    /** Tên hiển thị trong UI */
    val displayName: String

    /** Mô tả ngắn cho UI (mặc định rỗng — feature nào cần thì override). */
    val description: String
        get() = ""

    /** Kiểm tra feature có bật cho khe này không */
    fun isEnabled(context: Context, slotIndex: Int): Boolean

    /** Bật/tắt feature cho khe này */
    fun setEnabled(context: Context, slotIndex: Int, enabled: Boolean)

    /** 
     * Xử lý sự kiện từ engine (navigation, load, etc.)
     * Được gọi bởi MainActivity khi có sự kiện liên quan.
     */
    fun onPageLoaded(context: Context, slotIndex: Int, url: String) {}
    fun onPageLoadError(context: Context, slotIndex: Int, url: String, errorCode: Int) {}

    /** Xử lý khi user drop file vào browser (drag & drop) */
    fun onDropFile(context: Context, slotIndex: Int, uri: android.net.Uri, mimeType: String?) {}

    /**
     * Trang hiện tại có phải mục tiêu của feature này không (vd Colab Live
     * Keeper chỉ quan tâm colab.research.google.com). Mặc định KHÔNG khớp
     * gì — feature nào không cần cơ chế theo-URL này (Download Manager,
     * Fingerprint Spoof...) không cần override.
     */
    fun matchesUrl(url: String?): Boolean = false

    /** Gọi mỗi khi 1 trang khớp `matchesUrl` load xong (onPageStop thành công). */
    fun onPageFinished(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}

    /**
     * Gọi định kỳ (xem MainActivity — vòng lặp tick) cho trang đang khớp
     * `matchesUrl`, dùng cho hành vi lặp lại theo chu kỳ (vd bấm nút Connect
     * lại của Colab Live Keeper ở chế độ DOM).
     */
    fun onTick(context: Context, slotIndex: Int, engine: BrowserEngine, url: String?) {}

    /** Chu kỳ (phút) giữa các lần onTick/tap accessibility — mặc định 20. */
    fun intervalMinutes(context: Context, slotIndex: Int): Int = 20

    /**
     * Danh sách text nút cần AutoClickAccessibilityService tìm và tap thật
     * (chế độ Accessibility). Rỗng = feature này không cần tap accessibility.
     */
    fun accessibilityTargetTexts(context: Context, slotIndex: Int): List<String> = emptyList()

    /** Xây dựng UI cấu hình cho feature này */
    fun buildSettingsView(context: Context, slotIndex: Int): View
}
