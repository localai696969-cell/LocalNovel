package com.colablive.keeper.core

object BuildMarker {
    const val VERSION = "4.4-evalbridge-diag"
    const val MARKER = "GeckoView + AutoBehavior + DNS + TimezoneSync + CookieLeakTest + IDM + StreamSniffer + WebArchive + PageConverter + DownloadPolicy"
    const val BUILD_DATE = "2026-08-09"
}
