package com.colablive.keeper.core

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.*

/**
 * Phát hiện cookie leak giữa các slot.
 * Mỗi slot tạo 1 marker cookie unique.
 * Kiểm tra xem slot này có thấy marker của slot khác không.
 *
 * QUAN TRỌNG: mỗi khe chạy trong TIẾN TRÌNH riêng (android:process=":slotN"),
 * nên một Map trong bộ nhớ của instance này CHỈ tồn tại trong tiến trình của
 * chính khe đang gọi — không bao giờ thấy được marker do khe khác (tiến
 * trình khác) set. Bản trước dùng `mutableMapOf` in-memory nên `checkLeak`
 * luôn trả về "Chưa có slot khác để so sánh", không thể phát hiện leak thật.
 * Sửa: lưu marker vào 1 file dùng chung trong `context.filesDir` — file này
 * nằm trên cùng 1 UID/app nên MỌI tiến trình của app đều đọc/ghi được, khác
 * hẳn SharedPreferences (bị cache theo instance/tiến trình).
 */
class CookieLeakDetector(private val context: Context) {

    private val testUrl = "https://example.com"
    private val markersFile: File get() = File(context.filesDir, "cookie_leak_test_markers.json")

    @Synchronized
    private fun readMarkers(): MutableMap<Int, String> {
        return try {
            if (!markersFile.exists()) return mutableMapOf()
            val json = JSONObject(markersFile.readText())
            val map = mutableMapOf<Int, String>()
            json.keys().forEach { k -> map[k.toInt()] = json.getString(k) }
            map
        } catch (e: Exception) {
            DebugLog.log("CookieLeakDetector readMarkers lỗi: ${e.message}")
            mutableMapOf()
        }
    }

    @Synchronized
    private fun writeMarkers(map: Map<Int, String>) {
        try {
            val json = JSONObject()
            map.forEach { (k, v) -> json.put(k.toString(), v) }
            markersFile.writeText(json.toString())
        } catch (e: Exception) {
            DebugLog.log("CookieLeakDetector writeMarkers lỗi: ${e.message}")
        }
    }

    /**
     * Tạo marker cookie cho slot.
     * Gọi sau khi slot mở và load trang.
     */
    fun setMarker(slotIndex: Int, engine: GeckoViewEngine) {
        val marker = "slot_${slotIndex}_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val map = readMarkers()
        map[slotIndex] = marker
        writeMarkers(map)

        // Inject marker cookie vào trang test
        engine.evaluateJs("""
            (function() {
                try {
                    document.cookie = "leak_test_marker=$marker; path=/; SameSite=Lax";
                    return "marker_set:$marker";
                } catch(e) {
                    return "error:" + e.message;
                }
            })()
        """) { result ->
            DebugLog.log("Leak marker set for slot $slotIndex: $marker")
        }
    }

    /**
     * Kiểm tra slot này có thấy marker của slot khác không.
     * Gọi sau khi setMarker và đợi 2-3 giây.
     */
    fun checkLeak(slotIndex: Int, engine: GeckoViewEngine, callback: (Boolean, String) -> Unit) {
        val otherMarkers = readMarkers().filter { it.key != slotIndex }.values.toList()

        if (otherMarkers.isEmpty()) {
            callback(false, "Chưa có slot khác để so sánh — mở thêm 1 khe khác, bấm 'Set Marker' ở khe đó rồi quay lại đây bấm 'Check Leak'")
            return
        }

        // Build JS để kiểm tra tất cả marker khác
        val checkJs = buildString {
            append("(function() {")
            append("var cookies = document.cookie;")
            append("var leaks = [];")
            otherMarkers.forEach { marker ->
                append("if (cookies.includes('$marker')) leaks.push('$marker');")
            }
            append("return leaks.length > 0 ? 'LEAK:' + leaks.join(',') : 'CLEAN';")
            append("})()")
        }

        engine.evaluateJs(checkJs) { result ->
            val isLeak = result?.startsWith("LEAK:") == true
            val detail = if (isLeak) {
                "Phát hiện cookie của slot khác: ${result?.removePrefix("LEAK:")}"
            } else {
                "Không phát hiện leak"
            }
            callback(isLeak, detail)
        }
    }

    /**
     * Test đầy đủ: Load trang test → Set marker → Đợi → Check leak.
     */
    fun runFullTest(slotIndex: Int, engine: GeckoViewEngine, callback: (Boolean, String) -> Unit) {
        // Load trang test trước
        engine.loadUrl(testUrl)

        // Đợi trang load xong rồi set marker
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            setMarker(slotIndex, engine)

            // Đợi 3 giây rồi check
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                checkLeak(slotIndex, engine, callback)
            }, 3000)
        }, 2000)
    }

    /**
     * Xóa tất cả markers (của MỌI khe — file dùng chung).
     */
    fun clearMarkers() {
        try {
            if (markersFile.exists()) markersFile.delete()
        } catch (e: Exception) {
            DebugLog.log("CookieLeakDetector clearMarkers lỗi: ${e.message}")
        }
    }
}
