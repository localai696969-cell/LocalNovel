package com.colablive.keeper.core

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.FileDescriptor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CrashBreadcrumb — công cụ chẩn đoán cho đúng loại lỗi "biến mất hoàn
 * toàn, không 1 dòng log nào" đã bị nghi ngờ là NATIVE crash bên trong
 * chính GeckoView SDK (xem PROJECT_STATUS.md mục 9). Loại lỗi này KHÔNG
 * thể bắt được bằng try/catch Kotlin ở bất kỳ đâu, kể cả
 * Thread.setDefaultUncaughtExceptionHandler toàn cục (chỉ bắt được
 * exception ở tầng JVM, không bắt được SIGSEGV/SIGABRT native).
 *
 * Cách hoạt động: TRƯỚC khi thực hiện 1 bước bị nghi ngờ rủi ro (ví dụ
 * đóng khe rồi làm việc nặng tiếp theo), ghi 1 dòng mô tả bước đó vào
 * file, kèm `fd.sync()` để đảm bảo dữ liệu THẬT SỰ nằm trên đĩa (không
 * chỉ trong buffer RAM) trước khi tiếp tục — quan trọng vì nếu crash
 * native xảy ra ngay sau đó, dữ liệu trong RAM chưa flush sẽ mất theo.
 * Nếu tiến trình sống sót qua bước đó, code gọi read()+clear() ngay khi
 * biết chắc đã an toàn.
 *
 * Ở lần khởi động TIẾP THEO của tiến trình (LiveBrowserApp.onCreate),
 * nếu file NÀY VẪN CÒN TỒN TẠI — bằng chứng CHẮC CHẮN 100% phiên trước đã
 * chết ngay tại (hoặc rất gần) đúng bước được ghi trong file, dù không có
 * bất kỳ log lỗi Kotlin/crash handler nào khác xác nhận được.
 */
object CrashBreadcrumb {
    private fun file(context: Context): File = File(context.filesDir, "crash_breadcrumb.txt")

    fun write(context: Context, stepDescription: String) {
        try {
            val f = file(context)
            val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
            FileOutputStream(f, false).use { fos ->
                fos.write("[$ts] $stepDescription".toByteArray(Charsets.UTF_8))
                fos.flush()
                try { fos.fd.sync() } catch (e: Exception) { /* 1 số thiết bị/filesystem không hỗ trợ fsync — bỏ qua, vẫn còn write()+flush() ở trên */ }
            }
        } catch (e: Exception) {
            // Không để lỗi ghi breadcrumb làm hỏng luồng chính — đây chỉ là công cụ chẩn đoán phụ trợ
        }
    }

    /**
     * Gọi 1 LẦN DUY NHẤT ở LiveBrowserApp.onCreate() (tiến trình chính,
     * không gọi ở tiến trình con Gecko helper). Trả về nội dung breadcrumb
     * NẾU phiên trước đó chết bất thường tại bước đó, đồng thời XOÁ file
     * để lần khởi động sau không báo lại sai.
     */
    fun checkAndClearAfterCrash(context: Context): String? {
        return try {
            val f = file(context)
            if (f.exists()) {
                val content = f.readText(Charsets.UTF_8)
                f.delete()
                content
            } else null
        } catch (e: Exception) {
            null
        }
    }

    fun clear(context: Context) {
        try { file(context).delete() } catch (e: Exception) { /* bỏ qua */ }
    }
}
