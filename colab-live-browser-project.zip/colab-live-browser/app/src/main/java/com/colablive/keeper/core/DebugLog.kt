package com.colablive.keeper.core

import android.content.Context
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log trong bộ nhớ (xem nhanh qua DebugLogActivity) VÀ GHI RA FILE NGAY LẬP
 * TỨC, flush đồng bộ mỗi dòng — không dùng buffer/ghi trễ.
 *
 * Lý do ghi đồng bộ dù chậm hơn: mục đích chính là sống sót qua CRASH NATIVE
 * (vd chính thư viện Gecko libxul.so crash ở tầng C++) — loại crash này giết
 * tiến trình NGAY LẬP TỨC, không hề chạy qua
 * `Thread.setDefaultUncaughtExceptionHandler` của Kotlin/Java (xem
 * LiveBrowserApp) — nên KHÔNG có cơ hội "ghi nốt trước khi thoát" giống như
 * crash Kotlin thường. Muốn có manh mối cho loại crash này, dữ liệu PHẢI đã
 * nằm trên đĩa TỪ TRƯỚC lúc crash xảy ra, không phải ghi tại thời điểm crash.
 */
object DebugLog {
    private const val MAX_ENTRIES = 300
    // Giới hạn file — KeepAliveService có thể chạy hàng giờ/ngày liên tục,
    // không giới hạn thì file phình vô hạn.
    private const val MAX_FILE_BYTES = 2 * 1024 * 1024

    private val entries = ArrayDeque<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private var logFile: File? = null

    /**
     * BUG THẬT đã tìm ra (người dùng phát hiện: mở Debug Log từ Khe 1
     * nhưng vẫn chỉ thấy log của Khe 0): trước đây MỌI khe dùng CHUNG 1
     * file `debug_log.txt` (tên cố định, không phân biệt khe) — VÀ
     * `DebugLogActivity` không khai báo `android:process` trong Manifest,
     * nên Android LUÔN chạy nó trong tiến trình MẶC ĐỊNH (= tiến trình
     * Khe 0, xem `MainActivitySlot1/2/3` mới có `android:process=":slotN"`
     * riêng, `MainActivity` gốc thì không) — bất kể bấm mở từ khe nào.
     * `entries` (danh sách trong bộ nhớ) vì vậy luôn là bộ nhớ CỦA TIẾN
     * TRÌNH KHE 0, không phải khe đang thao tác.
     *
     * Sửa: mỗi khe ghi vào file RIÊNG (`debug_log_slot<N>.txt`), và đọc
     * theo ĐÚNG `slotIndex` được truyền vào tường minh (qua Intent extra
     * `slot_index`, giống `HistoryActivity`/`BookmarkActivity` đã làm
     * đúng từ đầu) — không dựa vào tiến trình nào đang thực thi Activity,
     * đọc thẳng từ ĐĨA theo tên file đã biết trước, an toàn qua mọi tiến
     * trình.
     */
    private fun fileNameFor(slotIndex: Int) = "debug_log_slot$slotIndex.txt"

    /** Gọi 1 LẦN DUY NHẤT từ LiveBrowserApp.onCreate(), TRƯỚC mọi log() khác. */
    @Synchronized
    fun init(context: Context, slotIndex: Int) {
        if (logFile != null) return
        logFile = File(context.filesDir, fileNameFor(slotIndex))
        log("========== App process start ==========")
    }

    @Synchronized
    fun log(message: String) {
        val line = "[${timeFormat.format(Date())}] $message"
        entries.addLast(line)
        while (entries.size > MAX_ENTRIES) entries.removeFirst()

        val f = logFile ?: return
        try {
            if (f.exists() && f.length() > MAX_FILE_BYTES) trimFile(f)
            // FileWriter(append=true) mở/ghi/đóng mỗi lần — chậm hơn giữ
            // stream mở sẵn, nhưng ĐÓNG = flush thật xuống đĩa ngay, không
            // treo trong buffer OS/JVM chờ crash rồi mất.
            FileWriter(f, true).use { it.appendLine(line) }
        } catch (e: Exception) {
            // Không để lỗi ghi log làm hỏng luồng chính của app.
        }
    }

    private fun trimFile(f: File) {
        try {
            val lines = f.readLines()
            val keep = lines.takeLast(MAX_ENTRIES * 2)
            f.writeText(keep.joinToString("\n") + "\n")
        } catch (e: Exception) {
            // bỏ qua — thà giữ file cũ còn hơn crash khi đang cố dọn log
        }
    }

    @Synchronized
    fun getAll(): List<String> = entries.toList()

    /**
     * Đọc TOÀN BỘ nội dung file trên đĩa (nhiều hơn 300 dòng giữ trong bộ
     * nhớ) — dùng khi cần soát kỹ log của LẦN CHẠY TRƯỚC, sau khi app vừa
     * crash và mở lại (bộ nhớ `entries` đã mất, file thì còn).
     *
     * NHẬN `slotIndex` TƯỜNG MINH, KHÔNG dùng `logFile` (field instance —
     * chỉ đúng cho tiến trình gọi `init()`, sai hoàn toàn nếu Activity
     * đang chạy trong tiến trình KHÁC với khe người dùng muốn xem — đúng
     * bug đã tìm ra ở `DebugLogActivity`). Đọc thẳng theo tên file đã biết
     * trước từ `slotIndex` — an toàn dù đang ở tiến trình nào.
     */
    fun readFullFile(context: Context, slotIndex: Int): String {
        val f = File(context.filesDir, fileNameFor(slotIndex))
        return runCatching { f.readText() }.getOrDefault("(chưa có file log cho khe $slotIndex)")
    }

    /** Dọn log CỦA TIẾN TRÌNH ĐANG CHẠY (bộ nhớ + file riêng nó) — dùng
     * nội bộ khi cần, KHÔNG dùng cho nút "Xoá log" trên UI (xem
     * `clearFile(context, slotIndex)` — an toàn qua mọi tiến trình). */
    @Synchronized
    fun clear() {
        entries.clear()
        try {
            logFile?.writeText("")
        } catch (e: Exception) {
        }
    }

    /** Xoá ĐÚNG file của `slotIndex` chỉ định, không phụ thuộc tiến trình
     * đang thực thi lệnh gọi — dùng cho nút "Xoá log" trên UI (xem chú
     * thích ở `readFullFile`/`fileNameFor` về lý do cần tường minh
     * `slotIndex` thay vì dựa vào tiến trình hiện tại). */
    fun clearFile(context: Context, slotIndex: Int) {
        try {
            File(context.filesDir, fileNameFor(slotIndex)).writeText("")
        } catch (e: Exception) {
        }
    }
}
