package com.colablive.keeper.core.proxy

import com.colablive.keeper.core.DebugLog
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class ProxyCheckResult(val candidate: ProxyCandidate, val latencyMs: Long)

/**
 * Kiểm tra từng proxy ứng viên còn sống không + đo tốc độ (latency) — chạy
 * SONG SONG (thread pool) vì kiểm tra tuần tự hàng chục proxy, mỗi cái vài
 * giây timeout, sẽ quá lâu.
 *
 * Dùng https://www.gstatic.com/generate_204 làm URL test — endpoint chính
 * thức của Google dùng cho việc kiểm tra kết nối mạng (Android/Chrome tự
 * dùng nội bộ), cực nhẹ (trả về 204 No Content, gần như không có dữ liệu),
 * ít khả năng bị chặn/giới hạn tốc độ hơn so với gọi 1 trang web thường.
 */
object ProxyHealthChecker {
    private const val TEST_URL = "https://www.gstatic.com/generate_204"
    private const val PER_PROXY_TIMEOUT_SEC = 5L
    private const val MAX_CONCURRENT_CHECKS = 20

    /**
     * Kiểm tra toàn bộ danh sách, trả về proxy NHANH NHẤT còn sống (latency
     * thấp nhất trong số các proxy phản hồi thành công). null nếu không có
     * proxy nào sống. Hàm này BLOCKING — gọi trong background thread.
     */
    fun findFastestAlive(candidates: List<ProxyCandidate>, onProgress: (checked: Int, total: Int) -> Unit = { _, _ -> }): ProxyCheckResult? {
        if (candidates.isEmpty()) return null

        val executor = Executors.newFixedThreadPool(MAX_CONCURRENT_CHECKS)
        val results = java.util.Collections.synchronizedList(mutableListOf<ProxyCheckResult>())
        var checkedCount = 0

        val futures = candidates.map { candidate ->
            executor.submit {
                val result = checkOne(candidate)
                synchronized(this) {
                    checkedCount++
                    onProgress(checkedCount, candidates.size)
                }
                if (result != null) results.add(result)
            }
        }

        // Đợi tất cả xong, nhưng không quá lâu tổng thể — giới hạn tổng
        // thời gian chờ để tránh treo vô hạn nếu executor bị kẹt.
        futures.forEach {
            try {
                it.get(PER_PROXY_TIMEOUT_SEC + 2, TimeUnit.SECONDS)
            } catch (e: Exception) {
                // Timeout riêng lẻ — bỏ qua proxy đó, không chặn các proxy khác
            }
        }
        executor.shutdownNow()

        DebugLog.log("ProxyHealthChecker: ${results.size}/${candidates.size} proxy còn sống")
        return results.minByOrNull { it.latencyMs }
    }

    private fun checkOne(candidate: ProxyCandidate): ProxyCheckResult? {
        return try {
            val proxyType = if (candidate.type == "socks") Proxy.Type.SOCKS else Proxy.Type.HTTP
            val proxy = Proxy(proxyType, InetSocketAddress(candidate.host, candidate.port))
            val client = OkHttpClient.Builder()
                .proxy(proxy)
                .connectTimeout(PER_PROXY_TIMEOUT_SEC, TimeUnit.SECONDS)
                .readTimeout(PER_PROXY_TIMEOUT_SEC, TimeUnit.SECONDS)
                .build()
            val request = Request.Builder().url(TEST_URL).build()

            val start = System.currentTimeMillis()
            client.newCall(request).execute().use { response ->
                val latency = System.currentTimeMillis() - start
                if (response.code in 200..299 || response.code == 204) {
                    ProxyCheckResult(candidate, latency)
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            null // Proxy chết/timeout/từ chối kết nối — bỏ qua, không phải lỗi cần báo
        }
    }
}
