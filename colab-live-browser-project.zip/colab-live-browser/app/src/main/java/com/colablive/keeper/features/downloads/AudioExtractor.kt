package com.colablive.keeper.features.downloads

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.colablive.keeper.core.DebugLog
import java.io.File
import java.util.UUID

/**
 * Tách audio-only CỤC BỘ bằng FFmpeg — chỉ dùng khi NewPipeExtractor
 * KHÔNG có sẵn audio stream riêng cho video đó (xem
 * `DownloadManagerFeature.downloadYouTubeAudio()`), không phải đường
 * chính. Người dùng đã xác nhận chấp nhận APK nặng hơn (~15-30MB) để đổi
 * lấy độ bền — không phụ thuộc YouTube có luôn cung cấp audio stream
 * riêng hay không.
 *
 * YÊU CẦU RÕ TỪ NGƯỜI DÙNG (không phải tự thêm): "chỉ nặng apk, chứ
 * không phải mỗi lần convert audio lại tạo ra đống rác phình to trên bộ
 * nhớ" — nghĩa là các file TẠM (video gốc tải về chỉ để lấy audio, output
 * trung gian) PHẢI bị xoá ngay sau khi xong, kể cả khi FFmpeg lỗi giữa
 * chừng — dùng try/finally để đảm bảo dọn dẹp luôn chạy, không phụ thuộc
 * kết quả thành công hay thất bại. Có thêm hàm dọn rác mồ côi từ các lần
 * chạy trước bị crash giữa chừng (an toàn thêm 1 lớp).
 */
object AudioExtractor {

    private fun tempDir(context: Context): File {
        val dir = File(context.cacheDir, "audio_extract_tmp")
        dir.mkdirs()
        return dir
    }

    /**
     * Dọn TOÀN BỘ file tạm mồ côi còn sót lại từ các lần chạy trước (app
     * bị kill giữa chừng, FFmpeg crash không kịp chạy tới finally...). Gọi
     * 1 lần lúc khởi động app — an toàn, không đụng gì tới file đang tải
     * dở của người dùng (thư mục riêng, không lẫn với `downloads/`).
     */
    fun cleanupOrphanedTempFiles(context: Context) {
        try {
            val dir = tempDir(context)
            val files = dir.listFiles() ?: return
            var count = 0
            files.forEach { if (it.delete()) count++ }
            if (count > 0) DebugLog.log("AudioExtractor: dọn $count file tạm mồ côi từ lần chạy trước")
        } catch (e: Exception) {
            DebugLog.log("AudioExtractor.cleanupOrphanedTempFiles lỗi: ${e.message}")
        }
    }

    /**
     * Tách audio từ file video đã tải sẵn (`sourceVideoFile`), ghi kết quả
     * vào `destFile` (đích cuối cùng, người gọi tự quyết định — thường là
     * đường dẫn tạm khác, rồi copy tiếp sang MediaStore giống luồng tải
     * thường). LUÔN xoá `sourceVideoFile` (video gốc chỉ tải để lấy audio,
     * không có lý do giữ lại) VÀ file output trung gian nếu lỗi giữa
     * chừng — dùng try/finally, không phụ thuộc nhánh thành công.
     *
     * Dùng `-vn -acodec copy` (KHÔNG re-encode) khi có thể — chỉ tách
     * nguyên track audio ra khỏi container, nhanh (vài giây kể cả video
     * dài), không tốn CPU/pin như encode lại. Fallback sang re-encode AAC
     * (`-acodec aac`) nếu copy thất bại (1 số container hiếm không cho
     * copy thẳng track audio ra ngoài).
     */
    fun extractAudio(context: Context, sourceVideoFile: File, destFile: File, onResult: (success: Boolean, error: String?) -> Unit) {
        val tempOutput = File(tempDir(context), "${UUID.randomUUID()}.m4a")
        try {
            val copyCmd = "-y -i \"${sourceVideoFile.absolutePath}\" -vn -acodec copy \"${tempOutput.absolutePath}\""
            val session = FFmpegKit.execute(copyCmd)
            val copyOk = ReturnCode.isSuccess(session.returnCode) && tempOutput.exists() && tempOutput.length() > 0

            val finalOk = if (copyOk) {
                true
            } else {
                DebugLog.log("AudioExtractor: -acodec copy thất bại (${session.failStackTrace ?: session.returnCode}), thử re-encode AAC")
                tempOutput.delete()
                val reencodeCmd = "-y -i \"${sourceVideoFile.absolutePath}\" -vn -acodec aac -b:a 192k \"${tempOutput.absolutePath}\""
                val session2 = FFmpegKit.execute(reencodeCmd)
                ReturnCode.isSuccess(session2.returnCode) && tempOutput.exists() && tempOutput.length() > 0
            }

            if (finalOk) {
                destFile.parentFile?.mkdirs()
                tempOutput.copyTo(destFile, overwrite = true)
                onResult(true, null)
            } else {
                onResult(false, "FFmpeg không tách được audio (xem DebugLog để biết chi tiết lệnh đã chạy)")
            }
        } catch (e: Exception) {
            DebugLog.log("AudioExtractor.extractAudio lỗi: ${e.message}")
            onResult(false, e.message)
        } finally {
            // BẮT BUỘC chạy dù thành công hay lỗi — đúng yêu cầu "không để
            // rác phình to bộ nhớ". Xoá cả file tạm output LẪN video gốc
            // (video chỉ tải để lấy audio, giữ lại vô nghĩa + tốn dung
            // lượng gấp nhiều lần file audio thật cần).
            tempOutput.delete()
            sourceVideoFile.delete()
        }
    }
}
