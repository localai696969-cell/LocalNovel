package com.colablive.keeper.features.downloads

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.colablive.keeper.core.DebugLog
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Download Engine — Multi-thread (4 connections) + Pause/Resume (HTTP Range).
 */
class DownloadEngine(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val executor = Executors.newFixedThreadPool(8)
    private val downloads = ConcurrentHashMap<String, DownloadTask>()
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val THREAD_COUNT = 4
        // File nhỏ hơn ngưỡng này luôn tải đơn luồng — xem chú thích ở
        // `downloadWithResume()` lý do thật (không phải chỉ để tối ưu tốc
        // độ, mà để TRÁNH HẲN lớp bug do server bỏ qua Range request).
        const val MIN_MULTITHREAD_BYTES = 2L * 1024 * 1024 // 2MB
    }

    data class DownloadTask(
        val id: String,
        val url: String,
        val fileName: String,
        val filePath: String,
        val saveLocation: String = "downloads", // "downloads"/"documents"/"pictures"/"movies"/"music"/"custom" — xem SaveLocationDialog
        val customPath: String? = null, // chỉ dùng khi saveLocation == "custom"
        var totalBytes: Long = -1,
        val downloadedBytes: AtomicLong = AtomicLong(0),
        val isPaused: AtomicBoolean = AtomicBoolean(false),
        val isCancelled: AtomicBoolean = AtomicBoolean(false),
        val isComplete: AtomicBoolean = AtomicBoolean(false),
        var publicUri: Uri? = null,
        val progressListeners: MutableList<(Int, Long, Long) -> Unit> = mutableListOf(),
        val statusListeners: MutableList<(DownloadStatus) -> Unit> = mutableListOf()
    )

    enum class DownloadStatus { PENDING, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED }

    /**
     * BUG THẬT đã sửa (mục còn treo từ "Lượt 1" — chưa từng hoàn thiện dù
     * đã sửa "lưu sai chỗ" ở phiên trước đó): `SaveLocationDialog` cho
     * người dùng chọn 1 trong 6 nơi lưu (Downloads/Documents/Pictures/
     * Movies/Music/Tuỳ chọn) nhưng lựa chọn đó CHƯA TỪNG được truyền tới
     * đây — file luôn lưu 1 chỗ cố định bất kể người dùng chọn gì (đúng
     * hiện tượng người dùng mô tả: "IDM báo lưu ở A nhưng file luôn nằm ở
     * B"). Thêm tham số `saveLocation`/`customPath`, dùng xuyên suốt tới
     * `finalizeDownload()` để chọn đúng MediaStore collection.
     */
    fun startDownload(
        url: String,
        fileName: String,
        headers: Map<String, String> = emptyMap(),
        saveLocation: String = "downloads",
        customPath: String? = null
    ): String {
        val id = System.currentTimeMillis().toString()
        val downloadDir = File(context.getExternalFilesDir(null), "downloads")
        downloadDir.mkdirs()
        val filePath = File(downloadDir, fileName).absolutePath

        val task = DownloadTask(id = id, url = url, fileName = fileName, filePath = filePath, saveLocation = saveLocation, customPath = customPath)
        downloads[id] = task
        executor.execute { downloadWithResume(task, headers) }
        return id
    }

    /**
     * TẢI TỪ FILE CỤC BỘ ĐÃ CÓ SẴN (không qua mạng lần nào) — dùng cho
     * đúng trường hợp `GeckoViewEngine.onExternalResponse()` đã drain sẵn
     * `response.body` (bytes GeckoView tải VỚI cookie phiên trình duyệt
     * thật) ra file tạm. Đây là bản sửa gốc cho bug "download kẹt ở vài
     * trăm byte" (file cần đăng nhập trước đây bị `startDownload()` tải
     * LẠI qua OkHttp không cookie, ra trang lỗi nhỏ thay vì file thật).
     * Vẫn tạo `DownloadTask` đầy đủ để hiện đúng trong danh sách UI + %
     * tiến trình thật — chỉ khác bước "tải" là COPY cục bộ (nhanh, không
     * cần mạng) thay vì HTTP request.
     */
    fun startDownloadFromLocalFile(sourceFile: File, fileName: String, saveLocation: String = "downloads", customPath: String? = null): String {
        val id = System.currentTimeMillis().toString()
        val downloadDir = File(context.getExternalFilesDir(null), "downloads")
        downloadDir.mkdirs()
        val filePath = File(downloadDir, fileName).absolutePath
        val totalSize = sourceFile.length()

        val task = DownloadTask(id = id, url = sourceFile.absolutePath, fileName = fileName, filePath = filePath, saveLocation = saveLocation, customPath = customPath, totalBytes = totalSize)
        downloads[id] = task
        executor.execute {
            try {
                notifyStatus(task, DownloadStatus.RUNNING)
                sourceFile.inputStream().use { input ->
                    File(filePath).outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            if (task.isCancelled.get()) return@execute
                            output.write(buffer, 0, read)
                            val downloaded = task.downloadedBytes.addAndGet(read.toLong())
                            notifyProgress(task, downloaded, totalSize)
                        }
                    }
                }
                task.isComplete.set(true)
                notifyStatus(task, DownloadStatus.COMPLETED)
                finalizeDownload(task)
                // File tạm nguồn (trong cacheDir) không cần giữ nữa — đã
                // copy xong sang đích thật.
                sourceFile.delete()
            } catch (e: Exception) {
                DebugLog.log("startDownloadFromLocalFile lỗi: ${e.message}")
                notifyStatus(task, DownloadStatus.FAILED)
            }
        }
        return id
    }

    private fun downloadWithResume(task: DownloadTask, headers: Map<String, String>) {
        try {
            notifyStatus(task, DownloadStatus.RUNNING)

            val headRequest = Request.Builder().url(task.url).head().apply {
                headers.forEach { (k, v) -> header(k, v) }
            }.build()

            val headResponse = client.newCall(headRequest).execute()
            val acceptRanges = headResponse.header("Accept-Ranges")
            val contentLength = headResponse.header("Content-Length")?.toLongOrNull() ?: -1
            task.totalBytes = contentLength

            // BUG THẬT đã tìm ra (mục còn treo "file nhỏ tải lỗi" — khớp
            // đúng ảnh chụp màn hình `config.json` vài KB kẹt mãi ở "Tạm
            // dừng"): header `Accept-Ranges: bytes` chỉ là server QUẢNG
            // CÁO có hỗ trợ Range nói chung — không đảm bảo server THỰC SỰ
            // tôn trọng Range cho MỌI request. Nhiều server/CDN (đặc biệt
            // với file nhỏ/sinh động như JSON config) ÂM THẦM BỎ QUA header
            // Range và trả `200 OK` kèm TOÀN BỘ file thay vì `206 Partial
            // Content` — code cũ chỉ kiểm tra `response.isSuccessful` (đúng
            // với CẢ 200 lẫn 206), không phân biệt được, khiến CẢ 4 luồng
            // cùng nhận về TOÀN BỘ file rồi ghi đè chồng chéo lên nhau ở
            // các offset khác nhau (seek theo vị trí đoạn của luồng đó) —
            // hỏng file/không bao giờ đủ byte để hoàn tất. File càng nhỏ
            // càng dễ gặp (nhiều server không buồn xử lý Range cho response
            // quá nhỏ, không đáng công). Vì chia luồng cũng chẳng lợi gì về
            // tốc độ với file nhỏ (overhead 4 kết nối cho vài KB còn chậm
            // hơn 1 kết nối), cách sửa AN TOÀN NHẤT: file nhỏ hơn ngưỡng
            // LUÔN tải đơn luồng — né hẳn lớp bug này thay vì vá từng
            // trường hợp. Với file LỚN, vẫn giữ kiểm tra `206` chặt hơn ở
            // `downloadChunk()` bên dưới để phòng thủ thêm 1 lớp.
            if (acceptRanges == "bytes" && contentLength >= MIN_MULTITHREAD_BYTES) {
                downloadMultiThread(task, headers)
            } else {
                downloadSingleThread(task, headers)
            }
        } catch (e: Exception) {
            DebugLog.log("Download error: ${e.message}")
            notifyStatus(task, DownloadStatus.FAILED)
        }
    }

    private fun downloadMultiThread(task: DownloadTask, headers: Map<String, String>) {
        val file = RandomAccessFile(task.filePath, "rw")
        file.setLength(task.totalBytes)
        val chunkSize = task.totalBytes / THREAD_COUNT
        val threads = mutableListOf<Thread>()

        for (i in 0 until THREAD_COUNT) {
            val start = i * chunkSize
            val end = if (i == THREAD_COUNT - 1) task.totalBytes - 1 else (i + 1) * chunkSize - 1
            val thread = Thread { downloadChunk(task, file, start, end, headers) }
            threads.add(thread)
            thread.start()
        }
        threads.forEach { it.join() }
        file.close()

        if (!task.isCancelled.get()) {
            if (task.downloadedBytes.get() >= task.totalBytes) {
                task.isComplete.set(true)
                finalizeDownload(task)
                notifyStatus(task, DownloadStatus.COMPLETED)
            } else {
                notifyStatus(task, DownloadStatus.PAUSED)
            }
        }
    }

    private fun downloadChunk(task: DownloadTask, file: RandomAccessFile, start: Long, end: Long, headers: Map<String, String>) {
        var position = start
        while (position < end && !task.isCancelled.get()) {
            while (task.isPaused.get() && !task.isCancelled.get()) {
                Thread.sleep(100)
            }
            if (task.isCancelled.get()) break

            try {
                val request = Request.Builder().url(task.url)
                    .header("Range", "bytes=$position-$end")
                    .apply { headers.forEach { (k, v) -> header(k, v) } }
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return
                    // Lớp phòng thủ thứ 2 (file LỚN vẫn có thể gặp server/CDN
                    // bỏ qua Range ở edge case hiếm) — 206 = server xác nhận
                    // ĐÚNG đang trả đoạn ta yêu cầu; 200 nghĩa là server lờ
                    // Range, trả FULL file — nếu cứ ghi ở `position` (offset
                    // giữa file) như đoạn thật thì sẽ hỏng file. Coi là lỗi,
                    // để vòng lặp ngoài tự thử lại (không throw để tránh crash
                    // luồng, retry raise nguy cơ vô hạn thấp vì đa số trường
                    // hợp thật đã né được nhờ ngưỡng `MIN_MULTITHREAD_BYTES`).
                    if (response.code != 206) {
                        DebugLog.log("downloadChunk: server trả mã ${response.code} (không phải 206 Partial Content) cho Range bytes=$position-$end — bỏ qua lần thử này, thử lại")
                        Thread.sleep(1000)
                        return@use
                    }
                    response.body?.byteStream()?.use { input ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            if (task.isCancelled.get()) break
                            while (task.isPaused.get() && !task.isCancelled.get()) Thread.sleep(100)
                            synchronized(file) {
                                file.seek(position)
                                file.write(buffer, 0, read)
                            }
                            position += read
                            val downloaded = task.downloadedBytes.addAndGet(read.toLong())
                            notifyProgress(task, downloaded, task.totalBytes)
                        }
                    }
                }
            } catch (e: Exception) {
                Thread.sleep(1000)
            }
        }
    }

    private fun downloadSingleThread(task: DownloadTask, headers: Map<String, String>) {
        val request = Request.Builder().url(task.url).apply {
            headers.forEach { (k, v) -> header(k, v) }
        }.build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                notifyStatus(task, DownloadStatus.FAILED)
                return
            }
            val file = File(task.filePath)
            file.outputStream().use { output ->
                response.body?.byteStream()?.use { input ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        if (task.isCancelled.get()) break
                        while (task.isPaused.get() && !task.isCancelled.get()) Thread.sleep(100)
                        output.write(buffer, 0, read)
                        val downloaded = task.downloadedBytes.addAndGet(read.toLong())
                        notifyProgress(task, downloaded, task.totalBytes)
                    }
                }
            }
        }
        if (!task.isCancelled.get()) {
            task.isComplete.set(true)
            finalizeDownload(task)
            notifyStatus(task, DownloadStatus.COMPLETED)
        }
    }

    /**
     * Sau khi tải xong vào thư mục riêng của app (nhanh/ổn định, ghi random-access
     * đa luồng), sao chép file sang thư mục Downloads công khai qua MediaStore để
     * người dùng thấy được trong app Files/Downloads. Chạy đồng bộ trên thread tải
     * (đã là background thread) — không chặn UI.
     */
    /**
     * "Hoàn tất" 1 file ĐÃ CÓ SẴN trên đĩa (không qua HTTP download) — dùng
     * cho `downloadYouTubeAudio()` khi cần tái sử dụng đúng logic chọn
     * MediaStore collection theo `saveLocation` (đã viết ở
     * `copyToPublicDownloads`) cho output của FFmpeg, thay vì viết lại
     * logic đó lần 2 ở nơi khác.
     */
    fun finalizeLocalFile(sourceFile: File, fileName: String, saveLocation: String, customPath: String?): Uri? {
        if (!sourceFile.exists() || sourceFile.length() == 0L) return null
        return copyToPublicDownloads(fileName, sourceFile, saveLocation, customPath)
    }

    /**
     * Tải đồng bộ (chặn thread gọi tới) — dùng cho các nhu cầu nội bộ cần
     * CÓ NGAY file thật trên đĩa để xử lý tiếp (VD: tải tạm video để
     * `AudioExtractor` tách audio), khác với `startDownload()` (bất đồng
     * bộ, đa luồng, có UI theo dõi tiến trình — không phù hợp cho việc tải
     * tạm nội bộ không cần hiện lên danh sách IDM). PHẢI gọi từ thread nền
     * sẵn (không phải main thread).
     */
    fun downloadFileBlocking(url: String, destFile: File): Boolean {
        return try {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return false
                destFile.parentFile?.mkdirs()
                response.body?.byteStream()?.use { input ->
                    destFile.outputStream().use { output -> input.copyTo(output) }
                } ?: return false
            }
            destFile.exists() && destFile.length() > 0
        } catch (e: Exception) {
            DebugLog.log("downloadFileBlocking lỗi: ${e.message}")
            false
        }
    }

    private fun finalizeDownload(task: DownloadTask) {
        try {
            val sourceFile = File(task.filePath)
            if (!sourceFile.exists() || sourceFile.length() == 0L) {
                DebugLog.log("Finalize skip — file rỗng hoặc không tồn tại: ${task.filePath}")
                return
            }
            val uri = copyToPublicDownloads(task.fileName, sourceFile, task.saveLocation, task.customPath)
            task.publicUri = uri
            if (uri != null) {
                DebugLog.log("Đã sao chép sang '${task.saveLocation}': ${task.fileName}")
                /**
                 * BUG THẬT đã tìm ra (người dùng báo: "có mấy tab mà dung
                 * lượng vọt lên tới 800mb dữ liệu người dùng" — kiểm tra
                 * bằng ảnh chụp Cài đặt > Ứng dụng > Bộ nhớ, xác nhận thật):
                 * `sourceFile` ở đây (`task.filePath` =
                 * `externalFilesDir/downloads/$fileName`) VỪA được copy
                 * xong sang nơi lưu công khai thật (Downloads/Pictures/SAF
                 * tuỳ người dùng chọn) — nhưng KHÔNG BAO GIỜ bị xoá sau đó.
                 * Hàm này được gọi từ 3 nơi khác nhau trong file (luồng tải
                 * URL thường qua `downloadWithResume`, luồng file cục bộ
                 * `startDownloadFromLocalFile`, và 1 luồng khác) — nghĩa là
                 * MỌI lượt tải thành công đều để lại 1 BẢN SAO THỪA VĨNH
                 * VIỄN trong bộ nhớ riêng của app, cộng dồn theo thời gian.
                 * Khớp chính xác: log thật cho thấy file .mp4 692MB được
                 * tải LẶP LẠI 2 lần trong cùng 1 phiên — nếu cả 2 bản đều bị
                 * bỏ quên ở đây, chỉ riêng 2 file đó đã ngót 1.4GB, khớp với
                 * "800MB dữ liệu người dùng" người dùng đo được.
                 * Sửa: xoá `sourceFile` NGAY sau khi xác nhận copy công khai
                 * THÀNH CÔNG (`uri != null`) — nếu copy THẤT BẠI, cố tình
                 * GIỮ LẠI file này (khớp đúng log dòng kế bên: "file vẫn còn
                 * ở ${task.filePath}") để người dùng còn đường lấy lại file
                 * đã tải, không mất trắng.
                 */
                try {
                    if (sourceFile.delete()) {
                        DebugLog.log("Đã xoá file trung gian sau khi copy công khai thành công: ${task.filePath}")
                    }
                } catch (e: Exception) {
                    DebugLog.log("Xoá file trung gian lỗi (không nghiêm trọng, chỉ tốn thêm dung lượng): ${e.message}")
                }
            } else {
                DebugLog.log("Sao chép sang '${task.saveLocation}' THẤT BẠI: ${task.fileName} (file vẫn còn ở ${task.filePath})")
            }
        } catch (e: Exception) {
            DebugLog.log("finalizeDownload lỗi: ${e.message}")
        }
    }

    /**
     * Chọn đúng MediaStore collection theo lựa chọn THẬT của người dùng ở
     * `SaveLocationDialog` — trước đây luôn hardcode `MediaStore.Downloads`
     * bất kể người dùng chọn gì (xem chú thích ở `startDownload()`).
     */
    private fun copyToPublicDownloads(fileName: String, sourceFile: File, saveLocation: String, customPath: String?): Uri? {
        // ƯU TIÊN nhánh SAF (Storage Access Framework) NẾU customPath là 1
        // "tree URI" thật (bắt đầu bằng "content://", do người dùng chọn
        // qua FolderPickerBridge — xem SaveLocationDialog) — hoạt động
        // trên MỌI phiên bản Android (DocumentFile không bị giới hạn bởi
        // Scoped Storage như MediaStore ở nhánh cũ bên dưới), khác hẳn
        // path gõ tay kiểu cũ (chuỗi thường, VD "/storage/emulated/0/X")
        // vẫn CHỈ hoạt động ở nhánh Android ≤9 bên dưới như trước.
        if (saveLocation == "custom" && !customPath.isNullOrBlank() && customPath.startsWith("content://")) {
            return try {
                val treeUri = Uri.parse(customPath)
                val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, treeUri)
                if (dir == null || !dir.canWrite()) {
                    DebugLog.log("SAF: không ghi được vào thư mục đã chọn (quyền bị thu hồi hoặc thư mục đã bị xoá) — customPath=$customPath")
                    return null
                }
                // Trùng tên thì DocumentFile tự động đổi tên (thêm hậu tố),
                // không ghi đè âm thầm — hành vi chuẩn của Android cho SAF.
                val mimeType = guessMimeType(fileName)
                val newFile = dir.createFile(mimeType, fileName) ?: return null
                context.contentResolver.openOutputStream(newFile.uri)?.use { out ->
                    sourceFile.inputStream().use { input -> input.copyTo(out) }
                } ?: return null
                newFile.uri
            } catch (e: Exception) {
                DebugLog.log("Ghi qua SAF lỗi: ${e.message}")
                null
            }
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val mimeType = guessMimeType(fileName)
                val (collection, relativeDir) = when (saveLocation) {
                    "pictures" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
                    "movies" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
                    "music" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
                    // "documents"/"custom": KHÔNG có collection MediaStore riêng
                    // thân thiện như Images/Video/Audio/Downloads — dùng
                    // MediaStore.Files (collection chung, API 29+, chấp nhận
                    // RELATIVE_PATH bất kỳ) — cách CHÍNH THỨC được Android
                    // khuyến nghị cho trường hợp này kể từ Scoped Storage.
                    "documents" -> MediaStore.Files.getContentUri("external") to Environment.DIRECTORY_DOCUMENTS
                    "custom" -> {
                        // ĐÃ CÓ SAF Ở TRÊN (đầu hàm) cho path dạng "content://" —
                        // nhánh này giờ chỉ còn là fallback hiếm gặp (VD
                        // customPath cũ dạng chuỗi thường còn sót từ trước khi
                        // có SAF, hoặc trống) — Scoped Storage Android 10+ vẫn
                        // KHÔNG cho ghi thẳng theo path chuỗi thường qua
                        // MediaStore, nên vẫn phải rơi về Downloads thay vì lưu
                        // sai chỗ không ai biết.
                        if (!customPath.isNullOrBlank()) {
                            DebugLog.log("customPath ('$customPath') không phải URI SAF hợp lệ — lưu vào Downloads thay thế (dùng nút 'Chọn thư mục' trong dialog để có URI SAF thật)")
                        }
                        MediaStore.Files.getContentUri("external") to Environment.DIRECTORY_DOWNLOADS
                    }
                    else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativeDir)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = resolver.insert(collection, values) ?: return null
                resolver.openOutputStream(uri)?.use { out ->
                    sourceFile.inputStream().use { input -> input.copyTo(out) }
                } ?: run {
                    resolver.delete(uri, null, null)
                    return null
                }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                uri
            } else {
                // Android 9 trở xuống: chưa có Scoped Storage, ghi thẳng file
                // theo ĐÚNG thư mục người dùng chọn (kể cả "custom" — path tuỳ
                // ý người dùng gõ, hoạt động thật trên Android cũ vì
                // WRITE_EXTERNAL_STORAGE cho phép ghi bất kỳ đâu ngoài — khác
                // hẳn Android 10+ bị Scoped Storage chặn, xem log THẤT BẠI
                // rõ ràng thay vì âm thầm sai chỗ như trước).
                @Suppress("DEPRECATION")
                val publicDir = when (saveLocation) {
                    "pictures" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    "movies" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                    "music" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                    "documents" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                    "custom" -> if (!customPath.isNullOrBlank()) File(customPath) else Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    else -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                }
                publicDir.mkdirs()
                val destFile = uniqueDestFile(publicDir, fileName)
                sourceFile.copyTo(destFile, overwrite = true)
                Uri.fromFile(destFile)
            }
        } catch (e: Exception) {
            DebugLog.log("copyToPublicDownloads lỗi (saveLocation=$saveLocation): ${e.message}")
            null
        }
    }

    /** Tránh ghi đè file trùng tên trên Android cũ (không có tự động rename như MediaStore). */
    private fun uniqueDestFile(dir: File, fileName: String): File {
        var candidate = File(dir, fileName)
        if (!candidate.exists()) return candidate
        val dotIndex = fileName.lastIndexOf('.')
        val base = if (dotIndex > 0) fileName.substring(0, dotIndex) else fileName
        val ext = if (dotIndex > 0) fileName.substring(dotIndex) else ""
        var i = 1
        while (candidate.exists()) {
            candidate = File(dir, "$base($i)$ext")
            i++
        }
        return candidate
    }

    private fun guessMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun pauseDownload(id: String) {
        val task = downloads[id] ?: return
        task.isPaused.set(true)
        notifyStatus(task, DownloadStatus.PAUSED)
    }

    fun resumeDownload(id: String) {
        val task = downloads[id] ?: return
        if (task.isComplete.get()) return
        task.isPaused.set(false)
        notifyStatus(task, DownloadStatus.RUNNING)
    }

    fun cancelDownload(id: String) {
        val task = downloads[id] ?: return
        task.isCancelled.set(true)
        notifyStatus(task, DownloadStatus.CANCELLED)
    }

    fun deleteDownload(id: String) {
        val task = downloads[id] ?: return
        task.isCancelled.set(true)
        File(task.filePath).delete()
        downloads.remove(id)
    }

    fun getDownload(id: String): DownloadTask? = downloads[id]
    fun getAllDownloads(): List<DownloadTask> = downloads.values.toList()
    fun isPaused(id: String): Boolean = downloads[id]?.isPaused?.get() ?: false
    fun isComplete(id: String): Boolean = downloads[id]?.isComplete?.get() ?: false

    fun addProgressListener(id: String, listener: (Int, Long, Long) -> Unit) {
        downloads[id]?.progressListeners?.add(listener)
    }

    fun addStatusListener(id: String, listener: (DownloadStatus) -> Unit) {
        downloads[id]?.statusListeners?.add(listener)
    }

    private fun notifyProgress(task: DownloadTask, downloaded: Long, total: Long) {
        val progress = if (total > 0) ((downloaded * 100) / total).toInt() else 0
        handler.post { task.progressListeners.forEach { it(progress, downloaded, total) } }
    }

    private fun notifyStatus(task: DownloadTask, status: DownloadStatus) {
        handler.post { task.statusListeners.forEach { it(status) } }
    }

    fun shutdown() {
        executor.shutdown()
    }
}
