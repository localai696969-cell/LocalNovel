package com.colablive.keeper.features.downloads

import android.content.Context
import android.net.Uri
import com.colablive.keeper.core.DebugLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * LỊCH SỬ FILE ĐÃ TẢI XUỐNG — tính năng thiếu thật (người dùng yêu cầu:
 * "hiện những file đã tải xuống").
 *
 * BUG GỐC đã xác định trước khi thêm file này: `DownloadEngine.getAllDownloads()`
 * (dùng bởi cả `IDMDownloadDialog` lẫn `DownloadManagerFeature.showDownloadList()`
 * cũ) chỉ đọc từ 1 `ConcurrentHashMap` SỐNG TRONG BỘ NHỚ (RAM) của
 * `DownloadEngine` — KHÔNG hề được ghi xuống đĩa ở đâu cả. Vì app này bị
 * RESTART RẤT THƯỜNG XUYÊN trong thực tế sử dụng (xem PROJECT_STATUS.md —
 * ghi đè/xoá hồ sơ, chuyển khe, crash... đều khởi động lại tiến trình),
 * danh sách download hiện trong 2 dialog trên BIẾN MẤT HOÀN TOÀN mỗi lần
 * app restart — dù file THẬT SỰ vẫn còn nguyên trên máy (đã copy công
 * khai qua MediaStore/SAF ở `DownloadEngine.finalizeDownload()` từ trước
 * khi restart xảy ra). Đây chính là nguyên nhân hiện tượng "không hiện
 * file đã tải xuống" — không phải file bị mất, mà là DANH SÁCH hiển thị
 * chưa từng được lưu lại.
 *
 * Sửa bằng cách LƯU BỀN 1 bản ghi nhẹ (tên file, URI công khai thật, MIME,
 * dung lượng, thời điểm, nơi lưu) MỖI KHI 1 download hoàn tất thành công.
 * Chỉ cần gọi `record()` từ ĐÚNG 1 CHỖ DUY NHẤT
 * (`DownloadEngine.finalizeDownload()`, nơi ĐÃ XÁC NHẬN copy công khai
 * xong, có URI thật trong tay) — không cần sửa từng nơi gọi
 * `startDownload()`/`startDownloadFromLocalFile()` rải rác khắp codebase
 * (YouTube, HLS, sniffed link, ebook, web archive...).
 *
 * Ghi trực tiếp JSON ra `context.filesDir` (KHÔNG dùng SharedPreferences —
 * tránh giới hạn kích thước XML thường gặp nếu danh sách dài, và để dễ
 * đọc/debug bằng mắt qua `adb pull` nếu cần) — cùng kỹ thuật atomic
 * tmp-file-rồi-rename đã dùng ở `BrowserHistory` (tránh file half-written
 * nếu app bị kill giữa lúc ghi — đúng loại bug đã gặp nhiều lần với
 * `saved_tabs.json`/`history.json` trước đây).
 *
 * KHÔNG lưu theo từng hồ sơ/khe (khác `BrowserHistory`) — file đã tải
 * xuống nằm ở bộ nhớ CÔNG KHAI chung của máy (Downloads/Pictures/SAF...),
 * không thuộc riêng 1 hồ sơ Gecko nào, nên hợp lý hơn khi dùng chung 1
 * danh sách cho mọi khe/hồ sơ (tải ở khe nào cũng thấy trong cùng 1 danh
 * sách "File đã tải xuống").
 */
object DownloadHistoryStore {
    private const val MAX_ENTRIES = 500
    private val lock = Any()

    private fun storeFile(context: Context): File =
        File(context.filesDir, "download_history.json")

    private fun readArray(context: Context): JSONArray {
        val f = storeFile(context)
        if (!f.exists()) return JSONArray()
        return try { JSONArray(f.readText()) } catch (e: Exception) { JSONArray() }
    }

    private fun writeArray(context: Context, arr: JSONArray) {
        val f = storeFile(context)
        val tmp = File(f.parentFile, "download_history.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(f)
    }

    data class Entry(
        val fileName: String,
        val uri: String,
        val mimeType: String,
        val sizeBytes: Long,
        val timestamp: Long,
        val saveLocation: String
    )

    /**
     * Gọi NGAY SAU KHI 1 download đã copy công khai xong thành công
     * (`uri != null` ở `DownloadEngine.finalizeDownload()`). Chạy đồng bộ
     * — hàm gọi (`finalizeDownload`) đã ở trên luồng nền của executor
     * riêng, không có rủi ro chặn UI thread.
     */
    fun record(context: Context, fileName: String, uri: Uri, mimeType: String, sizeBytes: Long, saveLocation: String) {
        synchronized(lock) {
            try {
                val arr = readArray(context)
                arr.put(JSONObject().apply {
                    put("fileName", fileName)
                    put("uri", uri.toString())
                    put("mimeType", mimeType)
                    put("sizeBytes", sizeBytes)
                    put("timestamp", System.currentTimeMillis())
                    put("saveLocation", saveLocation)
                })
                // Giới hạn số bản ghi — bài học từ bug "cache phình vô hạn"
                // (mục 8s trong PROJECT_STATUS.md), không lặp lại lỗi đó ở
                // đây. Cắt bớt bản ghi CŨ NHẤT, giữ lại MAX_ENTRIES bản mới
                // nhất.
                val trimmed = if (arr.length() > MAX_ENTRIES) {
                    JSONArray().also {
                        for (i in (arr.length() - MAX_ENTRIES) until arr.length()) it.put(arr.get(i))
                    }
                } else arr
                writeArray(context, trimmed)
            } catch (e: Exception) {
                DebugLog.log("DownloadHistoryStore.record lỗi: ${e.message}")
            }
        }
    }

    /** Mới nhất trước — giống Chrome Downloads: file tải gần đây nhất nằm
     * trên cùng danh sách. */
    fun getAll(context: Context): List<Entry> {
        synchronized(lock) {
            return try {
                val arr = readArray(context)
                val list = mutableListOf<Entry>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Entry(
                            fileName = o.optString("fileName"),
                            uri = o.optString("uri"),
                            mimeType = o.optString("mimeType", "application/octet-stream"),
                            sizeBytes = o.optLong("sizeBytes", -1),
                            timestamp = o.optLong("timestamp", 0),
                            saveLocation = o.optString("saveLocation", "downloads")
                        )
                    )
                }
                list.sortedByDescending { it.timestamp }
            } catch (e: Exception) {
                DebugLog.log("DownloadHistoryStore.getAll lỗi: ${e.message}")
                emptyList()
            }
        }
    }

    /**
     * Xoá 1 bản ghi khỏi LỊCH SỬ HIỂN THỊ — KHÔNG tự xoá file thật trên
     * máy (xoá file thật cần API khác nhau tuỳ URI là MediaStore hay SAF
     * hay file:// thường, xem
     * `DownloadManagerFeature.showDownloadedFilesList()` — nơi gọi tự lo
     * xoá file thật TRƯỚC rồi mới gọi hàm này để dọn bản ghi).
     */
    fun remove(context: Context, uri: String) {
        synchronized(lock) {
            try {
                val arr = readArray(context)
                val newArr = JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("uri") != uri) newArr.put(o)
                }
                writeArray(context, newArr)
            } catch (e: Exception) {
                DebugLog.log("DownloadHistoryStore.remove lỗi: ${e.message}")
            }
        }
    }
}
