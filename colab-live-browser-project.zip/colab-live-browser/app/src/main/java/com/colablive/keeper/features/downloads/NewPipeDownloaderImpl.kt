package com.colablive.keeper.features.downloads

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * BUG GỐC ĐÃ TÌM RA (lý do thật khiến tải YouTube trước đây luôn lỗi dù code
 * gọi API `StreamInfo.getInfo()`/`PlaylistInfo.getInfo()` trông hợp lý):
 * NewPipeExtractor BẮT BUỘC phải có 1 implementation thật của `Downloader`
 * (lớp trừu tượng, KHÔNG có implementation mặc định nào cả) và gọi
 * `NewPipe.init(downloader)` ĐÚNG 1 LẦN trước khi dùng bất kỳ API nào của
 * thư viện — thiếu bước này thì MỌI lệnh gọi extractor đều ném lỗi ngay lập
 * tức. `grep "NewPipe.init"` trong toàn bộ project trước phiên này ra
 * RỖNG — chưa từng có ở bất kỳ đâu.
 *
 * Port lại Kotlin từ chính file tham chiếu CHÍNH THỨC của app NewPipe gốc
 * (`DownloaderImpl.java`, tra cứu trực tiếp qua web search trước khi viết,
 * không đoán chữ ký API — dự án này đã từng bị lỗi nhiều lần vì đoán API
 * sai, xem PROJECT_STATUS.md mục 0a/"Đã tra được"):
 * https://github.com/TeamNewPipe/NewPipe/blob/dev/app/src/main/java/org/schabi/newpipe/DownloaderImpl.java
 *
 * Lược bỏ phần cookie "Restricted Mode"/`ReCaptchaActivity` của app gốc
 * (không cần cho mục đích tải file offline ở đây), giữ nguyên phần lõi:
 * User-Agent giả trình duyệt thật (YouTube chặn nếu thiếu/UA mặc định của
 * OkHttp), xử lý mã 429 (bị YouTube yêu cầu xác minh reCAPTCHA), đọc/ghi
 * header đúng cách, đọc body thành String.
 */
class NewPipeDownloaderImpl private constructor() : Downloader() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    @Throws(IOException::class, ReCaptchaException::class)
    override fun execute(request: Request): Response {
        val httpMethod = request.httpMethod()
        val url = request.url()
        val headers = request.headers()
        val dataToSend = request.dataToSend()

        val requestBody = dataToSend?.toRequestBody()

        val requestBuilder = okhttp3.Request.Builder()
            .method(httpMethod, requestBody)
            .url(url)
            .addHeader("User-Agent", USER_AGENT)

        headers.forEach { (headerName, headerValueList) ->
            requestBuilder.removeHeader(headerName)
            headerValueList.forEach { headerValue ->
                requestBuilder.addHeader(headerName, headerValue)
            }
        }

        client.newCall(requestBuilder.build()).execute().use { response ->
            if (response.code == 429) {
                throw ReCaptchaException("reCaptcha Challenge requested", url)
            }
            val responseBodyToReturn = response.body?.string()
            val latestUrl = response.request.url.toString()
            return Response(
                response.code,
                response.message,
                response.headers.toMultimap(),
                responseBodyToReturn,
                latestUrl
            )
        }
    }

    companion object {
        // Đúng UA app NewPipe gốc dùng — YouTube kiểm tra UA để chọn định
        // dạng phản hồi, UA mặc định của OkHttp ("okhttp/4.x") dễ bị chặn.
        private const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

        val instance: NewPipeDownloaderImpl by lazy { NewPipeDownloaderImpl() }
    }
}
