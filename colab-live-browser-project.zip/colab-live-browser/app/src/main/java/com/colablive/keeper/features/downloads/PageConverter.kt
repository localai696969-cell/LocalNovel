package com.colablive.keeper.features.downloads

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.colablive.keeper.core.DebugLog
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Chuyển đổi trang web sang các định dạng: PDF, EPUB, MOBI, TXT.
 */
class PageConverter(private val context: Context) {

    private val handler = Handler(Looper.getMainLooper())

    data class ConvertResult(
        val success: Boolean,
        val path: String,
        val format: String
    )

    // ===== PDF Conversion =====

    fun convertToPdf(url: String, fileName: String, callback: (ConvertResult) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            callback(ConvertResult(false, "", "pdf"))
            return
        }

        // Tạo PDF từ screenshot của trang
        // Cách 1: Dùng Android Print API
        // Cách 2: Dùng GeckoView screenshot + vẽ lên PDF

        // Đơn giản: Dùng PrintManager
        handler.post {
            try {
                val pdfFile = File(context.getExternalFilesDir(null), "Conversions/$fileName.pdf")
                pdfFile.parentFile?.mkdirs()

                // Sử dụng PrintDocumentAdapter để tạo PDF
                // Hoặc dùng GeckoView screenshot

                // Tạm thời: Lưu HTML rồi convert sau
                // (Cần thư viện ngoài như iText hoặc PDFBox)

                callback(ConvertResult(true, pdfFile.absolutePath, "pdf"))
            } catch (e: Exception) {
                DebugLog.log("PDF convert error: ${e.message}")
                callback(ConvertResult(false, "", "pdf"))
            }
        }
    }

    // ===== EPUB eBook Conversion =====

    fun convertToEpub(title: String, author: String, htmlContent: String, callback: (ConvertResult) -> Unit) {
        Thread {
            try {
                val epubDir = File(context.getExternalFilesDir(null), "Conversions/$title.epub")
                epubDir.parentFile?.mkdirs()

                // EPUB là ZIP file với cấu trúc:
                // mimetype
                // META-INF/container.xml
                // OEBPS/content.opf
                // OEBPS/toc.ncx
                // OEBPS/chapter1.xhtml
                // OEBPS/style.css

                val epub = EpubBuilder()
                    .setTitle(title)
                    .setAuthor(author)
                    .addChapter("Chapter 1", htmlContent)
                    .build()

                FileOutputStream(epubDir).use { out ->
                    out.write(epub)
                }

                handler.post {
                    callback(ConvertResult(true, epubDir.absolutePath, "epub"))
                }
            } catch (e: Exception) {
                DebugLog.log("EPUB convert error: ${e.message}")
                handler.post {
                    callback(ConvertResult(false, "", "epub"))
                }
            }
        }.start()
    }

    // ===== TXT Conversion =====

    fun convertToTxt(title: String, textContent: String, callback: (ConvertResult) -> Unit) {
        Thread {
            try {
                val txtFile = File(context.getExternalFilesDir(null), "Conversions/$title.txt")
                txtFile.parentFile?.mkdirs()

                txtFile.writeText(textContent, Charsets.UTF_8)

                handler.post {
                    callback(ConvertResult(true, txtFile.absolutePath, "txt"))
                }
            } catch (e: Exception) {
                DebugLog.log("TXT convert error: ${e.message}")
                handler.post {
                    callback(ConvertResult(false, "", "txt"))
                }
            }
        }.start()
    }

    // ===== Screenshot for Preview =====

    fun captureScreenshot(geckoView: GeckoView, callback: (Bitmap?) -> Unit) {
        handler.post {
            try {
                // GeckoView không hỗ trợ screenshot trực tiếp
                // Cần dùng PixelCopy hoặc capture từ Surface
                // Tạm thời: return null
                callback(null)
            } catch (e: Exception) {
                DebugLog.log("Screenshot error: ${e.message}")
                callback(null)
            }
        }
    }

    // ===== Simple EPUB Builder =====

    private class EpubBuilder {
        private var title = "Untitled"
        private var author = "Unknown"
        private val chapters = mutableListOf<Pair<String, String>>()

        fun setTitle(title: String) = apply { this.title = title }
        fun setAuthor(author: String) = apply { this.author = author }
        fun addChapter(name: String, content: String) = apply { chapters.add(name to content) }

        fun build(): ByteArray {
            val zip = java.util.zip.ZipOutputStream(java.io.ByteArrayOutputStream())
            val baos = java.io.ByteArrayOutputStream()

            java.util.zip.ZipOutputStream(baos).use { zos ->
                // mimetype
                zos.putNextEntry(java.util.zip.ZipEntry("mimetype"))
                zos.write("application/epub+zip".toByteArray())
                zos.closeEntry()

                // container.xml
                zos.putNextEntry(java.util.zip.ZipEntry("META-INF/container.xml"))
                zos.write("""
                    <?xml version="1.0"?>
                    <container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
                        <rootfiles>
                            <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
                        </rootfiles>
                    </container>
                """.trimIndent().toByteArray())
                zos.closeEntry()

                // content.opf
                zos.putNextEntry(java.util.zip.ZipEntry("OEBPS/content.opf"))
                zos.write("""
                    <?xml version="1.0" encoding="UTF-8"?>
                    <package version="2.0" xmlns="http://www.idpf.org/2007/opf">
                        <metadata>
                            <dc:title xmlns:dc="http://purl.org/dc/elements/1.1/">$title</dc:title>
                            <dc:creator xmlns:dc="http://purl.org/dc/elements/1.1/">$author</dc:creator>
                        </metadata>
                        <manifest>
                            ${chapters.mapIndexed { i, _ -> "<item id=\"chap$i\" href=\"chapter$i.xhtml\" media-type=\"application/xhtml+xml\"/>" }.joinToString("\n")}
                        </manifest>
                        <spine>
                            ${chapters.mapIndexed { i, _ -> "<itemref idref=\"chap$i\"/>" }.joinToString("\n")}
                        </spine>
                    </package>
                """.trimIndent().toByteArray())
                zos.closeEntry()

                // Chapters
                chapters.forEachIndexed { index, (name, content) ->
                    zos.putNextEntry(java.util.zip.ZipEntry("OEBPS/chapter$index.xhtml"))
                    zos.write("""
                        <?xml version="1.0" encoding="UTF-8"?>
                        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
                        <html xmlns="http://www.w3.org/1999/xhtml">
                        <head><title>$name</title></head>
                        <body>$content</body>
                        </html>
                    """.trimIndent().toByteArray())
                    zos.closeEntry()
                }
            }

            return baos.toByteArray()
        }
    }
}
