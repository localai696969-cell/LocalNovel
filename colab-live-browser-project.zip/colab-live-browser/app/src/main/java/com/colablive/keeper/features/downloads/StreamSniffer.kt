package com.colablive.keeper.features.downloads

import android.content.Context
import android.webkit.URLUtil
import com.colablive.keeper.core.DebugLog
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.regex.Pattern

/**
 * Bắt link video/audio từ trang web stream.
 * Hỗ trợ: HLS (.m3u8), DASH (.mpd), video trực tiếp, audio stream.
 */
class StreamSniffer(private val context: Context) {

    data class StreamLink(
        val url: String,
        val title: String,
        val type: String, // "video", "audio", "hls", "dash"
        val quality: String,
        val size: Long = -1
    )

    private val videoPatterns = listOf(
        Pattern.compile("https?://[^\\s\"<>]+\\.(mp4|webm|mkv|avi|mov|flv)(\\?[^\\s\"<>]*)?"),
        Pattern.compile("https?://[^\\s\"<>]+\\.(m3u8)(\\?[^\\s\"<>]*)?"),
        Pattern.compile("https?://[^\\s\"<>]+\\.(mpd)(\\?[^\\s\"<>]*)?"),
        Pattern.compile("https?://[^\\s\"<>]+/video/[^\\s\"<>]+"),
        Pattern.compile("https?://[^\\s\"<>]+/stream/[^\\s\"<>]+"),
        Pattern.compile("https?://[^\\s\"<>]+/api/[^\\s\"<>]+[Vv]ideo[^\\s\"<>]*"),
        Pattern.compile("https?://[^\\s\"<>]+manifest[^\\s\"<>]*"),
    )

    private val audioPatterns = listOf(
        Pattern.compile("https?://[^\\s\"<>]+\\.(mp3|aac|ogg|wav|flac|m4a)(\\?[^\\s\"<>]*)?"),
        Pattern.compile("https?://[^\\s\"<>]+/audio/[^\\s\"<>]+"),
        Pattern.compile("https?://[^\\s\"<>]+/api/[^\\s\"<>]+[Aa]udio[^\\s\"<>]*"),
    )

    /**
     * Sniff từ HTML content của trang.
     */
    fun sniffFromHtml(html: String, baseUrl: String): List<StreamLink> {
        val links = mutableListOf<StreamLink>()

        // Tìm video links
        videoPatterns.forEach { pattern ->
            val matcher = pattern.matcher(html)
            while (matcher.find()) {
                val url = matcher.group()
                if (URLUtil.isValidUrl(url)) {
                    val type = when {
                        url.contains(".m3u8") -> "hls"
                        url.contains(".mpd") -> "dash"
                        else -> "video"
                    }
                    links.add(StreamLink(
                        url = url,
                        title = extractTitle(html, url),
                        type = type,
                        quality = "Unknown"
                    ))
                }
            }
        }

        // Tìm audio links
        audioPatterns.forEach { pattern ->
            val matcher = pattern.matcher(html)
            while (matcher.find()) {
                val url = matcher.group()
                if (URLUtil.isValidUrl(url)) {
                    links.add(StreamLink(
                        url = url,
                        title = extractTitle(html, url),
                        type = "audio",
                        quality = "Unknown"
                    ))
                }
            }
        }

        // Tìm trong JSON/script tags
        links.addAll(sniffFromScripts(html))

        // Tìm trong meta tags
        links.addAll(sniffFromMeta(html))

        return links.distinctBy { it.url }
    }

    /**
     * Sniff từ JavaScript/scripts trong trang.
     */
    private fun sniffFromScripts(html: String): List<StreamLink> {
        val links = mutableListOf<StreamLink>()

        // Tìm JSON chứa video URLs
        val jsonPattern = Pattern.compile("var\\s+\\w+\\s*=\\s*(\\{[^;]+\\});", Pattern.DOTALL)
        val matcher = jsonPattern.matcher(html)

        while (matcher.find()) {
            try {
                val jsonStr = matcher.group(1)
                val json = JSONObject(jsonStr)
                extractUrlsFromJson(json, links)
            } catch (e: Exception) {
                // Bỏ qua JSON không hợp lệ
            }
        }

        // Tìm m3u8/mpd URLs trong scripts
        val streamPattern = Pattern.compile("['\"](https?://[^'\"]+\\.(m3u8|mpd))['\"]")
        val streamMatcher = streamPattern.matcher(html)
        while (streamMatcher.find()) {
            val url = streamMatcher.group(1)
            links.add(StreamLink(
                url = url,
                title = "Stream",
                type = if (url.contains("m3u8")) "hls" else "dash",
                quality = "Auto"
            ))
        }

        return links
    }

    /**
     * Sniff từ meta tags.
     */
    private fun sniffFromMeta(html: String): List<StreamLink> {
        val links = mutableListOf<StreamLink>()

        // og:video
        val ogVideoPattern = Pattern.compile("<meta[^>]+property=[\"']og:video[\"'][^>]+content=[\"']([^\"']+)[\"']")
        val matcher = ogVideoPattern.matcher(html)
        while (matcher.find()) {
            val url = matcher.group(1)
            links.add(StreamLink(url = url, title = "OG Video", type = "video", quality = "OG"))
        }

        return links
    }

    /**
     * Trích xuất URLs từ JSONObject đệ quy.
     */
    private fun extractUrlsFromJson(json: JSONObject, links: MutableList<StreamLink>) {
        json.keys().forEach { key ->
            try {
                val value = json.get(key)
                when (value) {
                    is String -> {
                        if (value.startsWith("http") && 
                            (value.contains(".mp4") || value.contains(".m3u8") || 
                             value.contains(".mpd") || value.contains(".webm"))) {
                            links.add(StreamLink(
                                url = value,
                                title = json.optString("title", "Video"),
                                type = if (value.contains("m3u8")) "hls" else "video",
                                quality = json.optString("quality", "Unknown")
                            ))
                        }
                    }
                    is JSONObject -> extractUrlsFromJson(value, links)
                    is JSONArray -> {
                        for (i in 0 until value.length()) {
                            val item = value.get(i)
                            if (item is JSONObject) extractUrlsFromJson(item, links)
                        }
                    }
                }
            } catch (e: Exception) {}
        }
    }

    /**
     * Lấy thông tin stream (size, quality).
     */
    fun probeStream(url: String): StreamLink? {
        return try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "HEAD"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")

            val contentType = connection.contentType ?: ""
            val contentLength = connection.contentLength.toLong()

            val type = when {
                contentType.contains("video") -> "video"
                contentType.contains("audio") -> "audio"
                url.contains("m3u8") -> "hls"
                url.contains("mpd") -> "dash"
                else -> "unknown"
            }

            connection.disconnect()

            StreamLink(
                url = url,
                title = URLUtil.guessFileName(url, null, contentType),
                type = type,
                quality = "${contentLength / 1024 / 1024}MB",
                size = contentLength
            )
        } catch (e: Exception) {
            DebugLog.log("Probe stream error: ${e.message}")
            null
        }
    }

    private fun extractTitle(html: String, url: String): String {
        // Thử lấy title từ <title> tag
        val titlePattern = Pattern.compile("<title>([^<]+)</title>")
        val matcher = titlePattern.matcher(html)
        if (matcher.find()) {
            return matcher.group(1).trim()
        }
        return URLUtil.guessFileName(url, null, null)
    }
}
