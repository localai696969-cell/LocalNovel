package com.colablive.keeper.features.downloads

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.colablive.keeper.core.DebugLog
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.select.Elements
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.concurrent.Executors

/**
 * Tải trang web như trên PC — lưu HTML + resources riêng biệt.
 * Cấu trúc:
 *   page_name/
 *     index.html
 *     css/
 *       style.css
 *     js/
 *       script.js
 *     images/
 *       logo.png
 */
class WebArchiver(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .build()
    private val executor = Executors.newFixedThreadPool(4)
    private val handler = Handler(Looper.getMainLooper())

    data class ArchiveResult(
        val success: Boolean,
        val path: String,
        val fileCount: Int,
        val totalSize: Long
    )

    /**
     * Tải toàn bộ trang web.
     */
    fun archivePage(url: String, pageTitle: String, callback: (ArchiveResult) -> Unit) {
        executor.execute {
            try {
                val safeName = pageTitle.replace(Regex("[\\/:*?\"<>|]"), "_").take(50)
                val baseDir = File(context.getExternalFilesDir(null), "WebArchives/$safeName")
                baseDir.mkdirs()

                // Tạo thư mục con
                val cssDir = File(baseDir, "css").apply { mkdirs() }
                val jsDir = File(baseDir, "js").apply { mkdirs() }
                val imgDir = File(baseDir, "images").apply { mkdirs() }
                val fontDir = File(baseDir, "fonts").apply { mkdirs() }

                // Tải HTML gốc
                val html = downloadText(url) ?: throw Exception("Cannot download HTML")
                val doc = Jsoup.parse(html, url)

                var fileCount = 1 // index.html
                var totalSize = html.length.toLong()

                // Xử lý CSS links
                val cssLinks = doc.select("link[rel=stylesheet]")
                cssLinks.forEach { link ->
                    val href = link.attr("abs:href")
                    if (href.isNotEmpty()) {
                        val cssFile = downloadResource(href, cssDir)
                        if (cssFile != null) {
                            link.attr("href", "css/${cssFile.name}")
                            fileCount++
                            totalSize += cssFile.length()
                        }
                    }
                }

                // Xử lý JS scripts
                val jsScripts = doc.select("script[src]")
                jsScripts.forEach { script ->
                    val src = script.attr("abs:src")
                    if (src.isNotEmpty()) {
                        val jsFile = downloadResource(src, jsDir)
                        if (jsFile != null) {
                            script.attr("src", "js/${jsFile.name}")
                            fileCount++
                            totalSize += jsFile.length()
                        }
                    }
                }

                // Xử lý images
                val images = doc.select("img[src]")
                images.forEach { img ->
                    val src = img.attr("abs:src")
                    if (src.isNotEmpty()) {
                        val imgFile = downloadResource(src, imgDir)
                        if (imgFile != null) {
                            img.attr("src", "images/${imgFile.name}")
                            fileCount++
                            totalSize += imgFile.length()
                        }
                    }
                }

                // Xử lý fonts
                val fonts = doc.select("link[rel=preload][as=font], @font-face")
                // ... tương tự

                // Xử lý background images trong CSS inline
                val inlineStyles = doc.select("[style*='url(']")
                // ... tương tự

                // Lưu HTML đã sửa
                val indexFile = File(baseDir, "index.html")
                FileOutputStream(indexFile).use { out ->
                    out.write(doc.html().toByteArray(Charsets.UTF_8))
                }

                handler.post {
                    callback(ArchiveResult(true, baseDir.absolutePath, fileCount, totalSize))
                }

            } catch (e: Exception) {
                DebugLog.log("Archive error: ${e.message}")
                handler.post {
                    callback(ArchiveResult(false, "", 0, 0))
                }
            }
        }
    }

    /**
     * FIX BUG THẬT (phát hiện qua audit code, không phải người dùng báo):
     * `WebArchiveDialog.getHtmlContent()`/`getTextContent()` trước đây LUÔN
     * gọi `callback(null)` — nghĩa là 2 nhánh "EPUB" và "TXT" trong
     * `WebArchiveDialog.startDownload()` LUÔN nhận `html ?: ""` = chuỗi
     * RỖNG, tạo ra file EPUB/TXT 0 nội dung dù dialog báo "✅ đã tạo!" (giả
     * thành công). Thêm 2 hàm public ở đây thay vì viết logic HTTP mới ở
     * `WebArchiveDialog` — tái dùng ĐÚNG `downloadText()` + `OkHttpClient`
     * đã có sẵn và đã chứng minh hoạt động qua `archivePage()`.
     */
    fun fetchRawHtml(url: String, callback: (String?) -> Unit) {
        executor.execute {
            val html = downloadText(url)
            handler.post { callback(html) }
        }
    }

    fun fetchPlainText(url: String, callback: (String?) -> Unit) {
        executor.execute {
            val html = downloadText(url)
            val text = html?.let {
                try {
                    Jsoup.parse(it, url).text()
                } catch (e: Exception) {
                    DebugLog.log("fetchPlainText: lỗi parse Jsoup (${e.message})")
                    null
                }
            }
            handler.post { callback(text) }
        }
    }

    private fun downloadText(url: String): String? {
        return try {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    response.body?.string()
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun downloadResource(url: String, destDir: File): File? {
        return try {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val fileName = url.substringAfterLast("/").takeIf { it.isNotEmpty() }
                        ?: "resource_${System.currentTimeMillis()}"
                    val safeFileName = fileName.replace(Regex("[\\/:*?\"<>|]"), "_")
                    val file = File(destDir, safeFileName)
                    FileOutputStream(file).use { out ->
                        response.body?.byteStream()?.copyTo(out)
                    }
                    file
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun getArchivePreview(path: String): String {
        val dir = File(path)
        if (!dir.exists()) return ""

        val sb = StringBuilder()
        sb.appendLine("📁 ${dir.name}")
        sb.appendLine("   📄 index.html")

        File(dir, "css").listFiles()?.forEach { sb.appendLine("   🎨 css/${it.name}") }
        File(dir, "js").listFiles()?.forEach { sb.appendLine("   ⚡ js/${it.name}") }
        File(dir, "images").listFiles()?.forEach { sb.appendLine("   🖼️ images/${it.name}") }
        File(dir, "fonts").listFiles()?.forEach { sb.appendLine("   🔤 fonts/${it.name}") }

        return sb.toString()
    }
}
