package com.localnovel.mnnbridge

import android.content.Context
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import org.json.JSONObject

// Lớp trung gian giữa Flutter (Dart, qua MethodChannel/EventChannel) và
// tầng native MnnNative (JNI/C++). Hỗ trợ 2 slot model độc lập (main +
// translation) — Dart truyền "slot" trong mỗi lệnh gọi để chỉ định làm
// việc với model nào, cho phép giữ cả 2 cùng lúc trong RAM (máy khỏe)
// hoặc xả từng cái theo tuần tự (máy yếu) mà không cần đổi code native.
//
// Bọc quanh Foreground Service (GenerationService) trong lúc nạp
// model/sinh văn bản — cần thiết vì luồng dịch tuần tự (dịch → sinh →
// dịch ngược) có thể mất vài phút, nếu không có Foreground Service,
// Android sẽ kill tiến trình khi app xuống nền hoặc tắt màn hình.
class MnnBridge(
    private val appContext: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
) : MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    private var eventSink: EventChannel.EventSink? = null
    private var currentJob: Job? = null

    // TỒN ĐỌNG mục 2.3 đã sửa: trước đây mỗi lệnh loadModel/generate tự
    // start/stop Foreground Service riêng, khiến luồng dịch tuần tự nhiều
    // bước (dịch → sinh → dịch ngược) có khoảng hở ngắn giữa các bước lúc
    // service bị dừng rồi khởi động lại. Giờ tầng Dart (TranslationService)
    // có thể gọi "beginPipeline" 1 lần ở đầu chuỗi nhiều bước, các lệnh
    // loadModel/generate ở giữa chỉ updateStage() (không start/stop), rồi
    // "endPipeline" ở cuối mới thật sự dừng service. Khi KHÔNG trong pipeline
    // (vd 1 lệnh generate đơn lẻ từ khung chat khi tắt dịch thuật), hành vi
    // cũ (tự start/stop từng lệnh) vẫn giữ nguyên.
    private var pipelineActive = false

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        val slot = call.argument<Int>("slot") ?: MnnNative.SLOT_MAIN
        when (call.method) {
            "beginPipeline" -> {
                val stage = call.argument<String>("stage") ?: "Đang chuẩn bị..."
                pipelineActive = true
                GenerationService.start(appContext, stage)
                result.success(null)
            }
            "updateStage" -> {
                val stage = call.argument<String>("stage") ?: "Đang xử lý..."
                GenerationService.updateStage(appContext, stage)
                result.success(null)
            }
            "endPipeline" -> {
                pipelineActive = false
                GenerationService.stop(appContext)
                result.success(null)
            }
            "loadModel" -> {
                val configPath = call.argument<String>("configPath")
                if (configPath == null) {
                    result.error("BAD_ARGS", "Thiếu configPath", null)
                    return
                }
                if (pipelineActive) {
                    GenerationService.updateStage(appContext, "Đang nạp model...")
                } else {
                    GenerationService.start(appContext, "Đang nạp model...")
                }
                scope.launch {
                    try {
                        // backendPreference = 0: luôn thử QNN trước, không
                        // kiểm tra danh sách máy được phép — máy nào chạy
                        // được thì tận dụng, không thì tự rơi về GPU/CPU.
                        val ok = MnnNative.nativeLoadModel(slot, configPath, 0)
                        val backend = if (ok) MnnNative.nativeActiveBackend(slot) else "loi"
                        result.success(mapOf("success" to ok, "backend" to backend))
                    } catch (e: Throwable) {
                        result.error("LOAD_FAILED", e.message ?: "Lỗi nạp model không rõ nguyên nhân", null)
                    } finally {
                        if (!pipelineActive) GenerationService.stop(appContext)
                    }
                }
            }
            "generate" -> {
                val prompt = call.argument<String>("prompt")
                val stageLabel = call.argument<String>("stageLabel") ?: "Đang sinh văn bản..."
                val temperature = call.argument<Double>("temperature") ?: 0.9
                val topP = call.argument<Double>("topP") ?: 0.9
                val topK = call.argument<Int>("topK") ?: 40
                val repetitionPenalty = call.argument<Double>("repetitionPenalty") ?: 1.05
                val maxNewTokens = call.argument<Int>("maxNewTokens") ?: 1024
                if (prompt == null) {
                    result.error("BAD_ARGS", "Thiếu prompt", null)
                    return
                }
                // Tên khóa JSON khớp đúng tài liệu chính thức MNN (llm_config.json).
                val configJson = JSONObject().apply {
                    put("temperature", temperature)
                    put("top_p", topP)
                    put("top_k", topK)
                    put("repetition_penalty", repetitionPenalty)
                    put("max_new_tokens", maxNewTokens)
                }.toString()

                if (pipelineActive) {
                    GenerationService.updateStage(appContext, stageLabel)
                } else {
                    GenerationService.start(appContext, stageLabel)
                }
                currentJob = scope.launch {
                    try {
                        MnnNative.nativeGenerate(slot, prompt, configJson, object : MnnNative.TokenCallback {
                            override fun onToken(token: String, done: Boolean) {
                                eventSink?.success(mapOf("token" to token, "done" to done, "slot" to slot))
                            }
                        })
                        result.success(null)
                    } catch (e: Throwable) {
                        eventSink?.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                        result.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                    } finally {
                        if (!pipelineActive) GenerationService.stop(appContext)
                    }
                }
            }
            "cancelGenerate" -> {
                currentJob?.cancel()
                pipelineActive = false
                GenerationService.stop(appContext)
                result.success(null)
            }
            "unload" -> {
                scope.launch {
                    MnnNative.nativeUnload(slot)
                    result.success(null)
                }
            }
            "isLoaded" -> {
                result.success(MnnNative.nativeIsLoaded(slot))
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }
}
