import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/story_models.dart';
import '../services/ai_provider.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import '../services/settings_service.dart';
import '../services/summary_service.dart';
import '../services/style_service.dart';
import '../services/translation_service.dart';

class ChapterEditorScreen extends StatefulWidget {
  final Chapter chapter;
  const ChapterEditorScreen({super.key, required this.chapter});

  @override
  State<ChapterEditorScreen> createState() => _ChapterEditorScreenState();
}

class _ChapterEditorScreenState extends State<ChapterEditorScreen> {
  late TextEditingController titleCtrl;
  late TextEditingController contentCtrl;
  final outlineCtrl = TextEditingController();
  final db = DatabaseService.instance;
  bool checking = false;
  bool generating = false;
  bool fleshingOut = false;
  bool savingBackground = false;
  bool rewriting = false;
  String? warning;
  // Khi dịch thuật trung gian đang bật, luồng dịch→sinh→dịch ngược không
  // stream từng chữ được (phải dịch xong toàn bộ mới trả kết quả) — hiện
  // tiến trình theo từng giai đoạn qua biến này, giống cách chat_screen.dart
  // đã làm, để người viết biết app còn đang chạy chứ không bị treo.
  String? aiStage;
  List<String> activeEntries = [];
  List<StyleProfile> styles = [];
  StyleProfile? selectedStyle;

  @override
  void initState() {
    super.initState();
    titleCtrl = TextEditingController(text: widget.chapter.title);
    contentCtrl = TextEditingController(text: widget.chapter.content);
    warning = widget.chapter.consistencyWarning;
    contentCtrl.addListener(_refreshPreview);
    _loadStyles();
    _refreshPreview();
  }

  Future<void> _loadStyles() async {
    final s = await db.allStyleProfiles(widget.chapter.novelId);
    setState(() => styles = s);
  }

  Future<RagService> _rag() async => RagService(
        db,
        await SettingsService().currentEmbeddingService(),
        novelId: widget.chapter.novelId,
        contextBudgetChars: await SettingsService().loadRagBudget(),
      );

  // Xem trước lorebook: hiển thị ngay những entry Story Bible nào sẽ
  // được nạp vào AI cho đoạn văn hiện tại, để người viết yên tâm là
  // đúng nhân vật/luật đang được tham chiếu trước khi bấm sinh văn bản.
  DateTime _lastPreviewRequest = DateTime.now();
  Future<void> _refreshPreview() async {
    final requestTime = DateTime.now();
    _lastPreviewRequest = requestTime;
    await Future.delayed(const Duration(milliseconds: 500));
    if (_lastPreviewRequest != requestTime) return; // đã có thay đổi mới hơn, bỏ qua
    if (contentCtrl.text.trim().isEmpty) {
      setState(() => activeEntries = []);
      return;
    }
    final rag = await _rag();
    final entries = await rag.previewActiveEntries(contentCtrl.text);
    if (mounted) setState(() => activeEntries = entries);
  }

  Future<void> _save({bool silent = false}) async {
    widget.chapter.title = titleCtrl.text;
    widget.chapter.content = contentCtrl.text;
    widget.chapter.updatedAt = DateTime.now();
    await db.upsertChapter(widget.chapter);
    if (!silent && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu chương')));
    }
    _updateSummaryAndIndexInBackground();
  }

  // Chạy nền, không chặn UI: tóm tắt chương (lớp bộ nhớ nén cho các
  // chương xa) rồi cập nhật embedding để chương này tìm được qua truy
  // xuất ngữ nghĩa từ các chương sau này.
  Future<void> _updateSummaryAndIndexInBackground() async {
    if (widget.chapter.content.trim().isEmpty) return;
    setState(() => savingBackground = true);
    try {
      final provider = await SettingsService().currentProvider();
      final summary = await SummaryService().summarizeChapter(widget.chapter, provider);
      widget.chapter.autoSummary = summary;
      await db.upsertChapter(widget.chapter);
      final rag = await _rag();
      await rag.indexChapter(widget.chapter);
    } catch (_) {
      // lỗi nền (ví dụ mất mạng khi dùng API) không cần làm phiền người viết
    } finally {
      if (mounted) setState(() => savingBackground = false);
    }
  }

  Future<void> _continueWithAI() async {
    setState(() {
      generating = true;
      aiStage = null;
    });
    try {
      final provider = await SettingsService().currentProvider();
      final rag = await _rag();
      final systemPrompt = await rag.buildSystemPrompt(
        userInstruction: 'Viết tiếp đúng mạch văn, giữ giọng văn hiện có, không lặp lại nội dung cũ.'
            '${selectedStyle != null ? ' Văn phong: ${selectedStyle!.profileDescription}' : ''}',
        currentText: contentCtrl.text,
      );
      // Áp dụng tham số sinh văn bản (temperature/top_p/top_k/repetition_penalty/
      // max_new_tokens) người dùng đã lưu ở GenerationSettingsScreen — trước đây
      // màn này vẫn dùng giá trị mặc định cứng (maxTokens: 800), chưa đọc cấu
      // hình đã lưu.
      final genCfg = await SettingsService().loadGenerationConfig();
      final result = await _generateRespectingTranslation(
        provider: provider,
        systemPrompt: systemPrompt,
        userPrompt: contentCtrl.text,
        genCfg: genCfg,
      );
      setState(() => contentCtrl.text = '${contentCtrl.text}\n\n$result');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      setState(() {
        generating = false;
        aiStage = null;
      });
    }
  }

  // Gọi model tôn trọng cả 2 cấu hình: tham số sinh văn bản của người dùng
  // VÀ tùy chọn dịch thuật trung gian (nếu bật). Dùng chung cho "Viết tiếp",
  // "Đắp thịt", và In-line AI Rewrite — tránh lặp lại logic rẽ nhánh 3 nơi.
  Future<String> _generateRespectingTranslation({
    required AIProvider provider,
    required String systemPrompt,
    required String userPrompt,
    required ({double temperature, double topP, int topK, double repetitionPenalty, int maxNewTokens}) genCfg,
  }) async {
    final translationOn = await TranslationService(SettingsService()).isEnabled;
    if (translationOn) {
      return TranslationService(SettingsService()).generateWithOptionalTranslation(
        mainProvider: provider,
        systemPrompt: systemPrompt,
        userPrompt: userPrompt,
        temperature: genCfg.temperature,
        maxTokens: genCfg.maxNewTokens,
        onStage: (stage) {
          if (mounted) setState(() => aiStage = stage);
        },
      );
    }
    return provider.generate(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: genCfg.temperature,
      maxTokens: genCfg.maxNewTokens,
      topP: genCfg.topP,
      topK: genCfg.topK,
      repetitionPenalty: genCfg.repetitionPenalty,
    );
  }

  // "Đắp thịt": nhận outline sơ sài người dùng gõ, sinh ra văn xuôi đầy
  // đủ theo văn phong đã chọn, có thoại và miêu tả — không chỉ liệt kê
  // lại outline.
  Future<void> _fleshOutOutline() async {
    if (outlineCtrl.text.trim().isEmpty) return;
    setState(() {
      fleshingOut = true;
      aiStage = null;
    });
    try {
      final provider = await SettingsService().currentProvider();
      final rag = await _rag();
      final genCfg = await SettingsService().loadGenerationConfig();
      final prompt = await StyleService().buildFleshOutPrompt(
        outline: outlineCtrl.text,
        style: selectedStyle,
        rag: rag,
      );
      final result = await _generateRespectingTranslation(
        provider: provider,
        systemPrompt: prompt.systemPrompt,
        userPrompt: prompt.userPrompt,
        genCfg: genCfg,
      );
      setState(() {
        contentCtrl.text = contentCtrl.text.trim().isEmpty ? result : '${contentCtrl.text}\n\n$result';
        outlineCtrl.clear();
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      setState(() {
        fleshingOut = false;
        aiStage = null;
      });
    }
  }

  Future<void> _checkConsistency() async {
    setState(() => checking = true);
    try {
      widget.chapter.content = contentCtrl.text;
      final provider = await SettingsService().currentProvider();
      final rag = await _rag();
      final prompt = await rag.buildConsistencyCheckPrompt(widget.chapter);
      final result = await provider.generate(
        systemPrompt: 'Bạn là biên tập viên kiểm tra tính nhất quán của tiểu thuyết dài kỳ.',
        userPrompt: prompt,
        maxTokens: 400,
      );
      final ok = result.trim().toUpperCase().startsWith('OK');
      widget.chapter.consistencyChecked = true;
      widget.chapter.consistencyWarning = ok ? null : result.trim();
      await db.upsertChapter(widget.chapter);
      setState(() => warning = widget.chapter.consistencyWarning);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      setState(() => checking = false);
    }
  }

  // ---------------- In-line AI Rewrite ----------------
  // Bôi đen 1 đoạn văn trong nội dung chương → menu lệnh nhanh (sửa lỗi
  // chính tả, viết sinh động hơn, rút ngắn, đổi ngôi kể) → thay thế đúng
  // đoạn đã chọn bằng kết quả AI. Được gắn vào contextMenuBuilder của
  // TextField nội dung chương (thêm 1 mục vào menu bôi đen mặc định của
  // Flutter, bên cạnh Copy/Paste/Select all có sẵn).
  Widget _buildEditingContextMenu(BuildContext context, EditableTextState editableTextState) {
    final selection = editableTextState.textEditingValue.selection;
    final selectedText = selection.isValid ? selection.textInside(editableTextState.textEditingValue.text) : '';
    final buttonItems = List<ContextMenuButtonItem>.from(editableTextState.contextMenuButtonItems);
    if (selectedText.trim().isNotEmpty) {
      buttonItems.insert(
        0,
        ContextMenuButtonItem(
          label: 'Viết lại bằng AI',
          onPressed: () {
            editableTextState.hideToolbar();
            _showRewriteMenu(selection, selectedText);
          },
        ),
      );
    }
    return AdaptiveTextSelectionToolbar.buttonItems(
      anchors: editableTextState.contextMenuAnchors,
      buttonItems: buttonItems,
    );
  }

  Future<void> _showRewriteMenu(TextSelection selection, String selectedText) async {
    final options = <(String label, IconData icon, String instruction)>[
      (
        'Sửa lỗi chính tả',
        Icons.spellcheck,
        'Sửa lỗi chính tả, ngữ pháp và dùng từ sai trong đoạn văn sau, giữ nguyên nội dung, '
            'tình tiết và văn phong, không viết lại toàn bộ, không thêm bớt ý.',
      ),
      (
        'Viết sinh động hơn',
        Icons.auto_awesome_outlined,
        'Viết lại đoạn văn sau sinh động, giàu hình ảnh và cảm xúc hơn, giữ nguyên tình tiết '
            'và thông tin cốt truyện, không đổi diễn biến.',
      ),
      (
        'Rút ngắn',
        Icons.compress_outlined,
        'Rút ngắn đoạn văn sau còn khoảng một nửa độ dài, giữ đúng ý chính và tình tiết quan '
            'trọng, bỏ bớt phần rườm rà.',
      ),
      (
        'Đổi ngôi kể',
        Icons.swap_horiz_outlined,
        'Đổi ngôi kể của đoạn văn sau: nếu đang là ngôi thứ nhất ("tôi") thì đổi sang ngôi thứ '
            'ba, nếu đang là ngôi thứ ba thì đổi sang ngôi thứ nhất; giữ nguyên nội dung, chỉ đổi '
            'cách xưng hô và ngôi kể.',
      ),
    ];

    final chosen = await showModalBottomSheet<(String, String)>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
              child: Text(
                'Viết lại bằng AI (${selectedText.trim().length} ký tự đã chọn)',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
            ...options.map((o) => ListTile(
                  leading: Icon(o.$2),
                  title: Text(o.$1),
                  onTap: () => Navigator.pop(context, (o.$1, o.$3)),
                )),
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
    if (chosen != null) {
      await _applyRewrite(selection, selectedText, chosen.$1, chosen.$2);
    }
  }

  Future<void> _applyRewrite(TextSelection selection, String selectedText, String actionLabel, String instruction) async {
    setState(() {
      rewriting = true;
      aiStage = null;
    });
    try {
      final provider = await SettingsService().currentProvider();
      final genCfg = await SettingsService().loadGenerationConfig();
      final systemPrompt = 'Bạn là biên tập viên tiểu thuyết dài kỳ. Chỉ trả về đúng đoạn văn đã được '
          'xử lý theo yêu cầu, không thêm giải thích, không thêm ghi chú, không thêm dấu ngoặc kép '
          'bao quanh, không lặp lại phần văn bản nằm ngoài đoạn được yêu cầu.';
      final userPrompt = '$instruction\n\nĐoạn văn cần xử lý:\n"""\n$selectedText\n"""';
      final result = await _generateRespectingTranslation(
        provider: provider,
        systemPrompt: systemPrompt,
        userPrompt: userPrompt,
        genCfg: genCfg,
      );
      final cleaned = result.trim();
      final fullText = contentCtrl.text;
      // Bảo vệ trường hợp nội dung chương đã đổi trong lúc chờ AI trả lời
      // (vd người dùng gõ tiếp trong khi chờ, có thể mất vài phút với model
      // lớn) — chỉ thay thế nếu đúng đoạn văn bản gốc còn khớp nguyên vị trí,
      // tránh ghi đè nhầm chỗ khác trong chương.
      final stillMatches = selection.start >= 0 &&
          selection.end <= fullText.length &&
          fullText.substring(selection.start, selection.end) == selectedText;
      if (stillMatches) {
        final newText = fullText.replaceRange(selection.start, selection.end, cleaned);
        setState(() {
          contentCtrl.value = contentCtrl.value.copyWith(
            text: newText,
            selection: TextSelection.collapsed(offset: selection.start + cleaned.length),
          );
        });
      } else {
        await Clipboard.setData(ClipboardData(text: cleaned));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Nội dung đã thay đổi trong lúc chờ AI ($actionLabel) — đã sao chép kết quả, dán thủ công.'),
          ));
        }
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      setState(() {
        rewriting = false;
        aiStage = null;
      });
    }
  }

  Future<void> _showOutlineSheet() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: StatefulBuilder(builder: (context, setSheetState) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Đắp thịt cốt truyện', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 4),
              const Text(
                'Gõ vài gạch đầu dòng định hướng, AI sẽ triển khai thành văn xuôi đầy đủ.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: outlineCtrl,
                maxLines: 5,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: '- Thanh Vũ đối mặt Hắc Diễm Tôn tại cửa vực\n- Phát hiện Hắc Diễm Tôn mất một tay\n- Trận đấu kết thúc bằng một lời thề báo thù',
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<StyleProfile?>(
                value: selectedStyle,
                decoration: const InputDecoration(labelText: 'Văn phong', border: OutlineInputBorder()),
                items: [
                  const DropdownMenuItem(value: null, child: Text('Mặc định')),
                  ...styles.map((s) => DropdownMenuItem(value: s, child: Text(s.name))),
                ],
                onChanged: (v) => setSheetState(() => selectedStyle = v),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: fleshingOut
                    ? null
                    : () async {
                        Navigator.pop(context);
                        await _fleshOutOutline();
                      },
                icon: const Icon(Icons.auto_fix_high_outlined),
                label: const Text('Triển khai thành chương'),
              ),
            ],
          );
        }),
      ),
    );
  }

  @override
  void dispose() {
    contentCtrl.removeListener(_refreshPreview);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Bận chung: có AI đang chạy ở bất kỳ tác vụ nào (viết tiếp/đắp thịt/
    // kiểm tra/rewrite) — khóa các nút khác + khóa sửa nội dung chương lại
    // trong lúc AI rewrite đang thay thế đoạn văn, tránh đụng độ vị trí.
    final busy = generating || fleshingOut || checking || rewriting;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Soạn chương'),
        actions: [
          if (savingBackground)
            const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
            ),
          IconButton(onPressed: () => _save(), icon: const Icon(Icons.save_outlined)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tiêu đề chương')),
            const SizedBox(height: 8),
            if (warning != null)
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(8)),
                child: Text(warning!, style: TextStyle(color: Colors.orange.shade900, fontSize: 12)),
              ),
            if (activeEntries.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: activeEntries
                      .map((e) => Chip(
                            label: Text(e, style: const TextStyle(fontSize: 11)),
                            visualDensity: VisualDensity.compact,
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ))
                      .toList(),
                ),
              ),
            if (aiStage != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(children: [
                  const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                  const SizedBox(width: 8),
                  Expanded(child: Text(aiStage!, style: TextStyle(fontSize: 12, color: Colors.grey.shade700))),
                ]),
              ),
            Expanded(
              child: TextField(
                controller: contentCtrl,
                maxLines: null,
                expands: true,
                enabled: !rewriting,
                textAlignVertical: TextAlignVertical.top,
                // Bôi đen 1 đoạn văn sẽ hiện thêm mục "Viết lại bằng AI" bên
                // cạnh Copy/Paste/Chọn tất cả mặc định của Flutter.
                contextMenuBuilder: _buildEditingContextMenu,
                decoration: const InputDecoration(
                  hintText: 'Nội dung chương... (bôi đen 1 đoạn để dùng "Viết lại bằng AI")',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: busy ? null : _checkConsistency,
                  icon: checking
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.fact_check_outlined),
                  label: const Text('Kiểm tra'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: busy ? null : _showOutlineSheet,
                  icon: const Icon(Icons.auto_fix_high_outlined),
                  label: const Text('Đắp thịt'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.icon(
                  onPressed: busy ? null : _continueWithAI,
                  icon: generating
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome_outlined),
                  label: const Text('Viết tiếp'),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
