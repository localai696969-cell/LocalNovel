import 'package:flutter/material.dart';
import '../services/settings_service.dart';
import 'file_browser_screen.dart';

class TranslationSettingsScreen extends StatefulWidget {
  const TranslationSettingsScreen({super.key});
  @override
  State<TranslationSettingsScreen> createState() => _TranslationSettingsScreenState();
}

class _TranslationSettingsScreenState extends State<TranslationSettingsScreen> {
  final settings = SettingsService();
  bool enabled = false;
  String modelPath = '';
  String targetLanguage = 'tiếng Anh';
  String stylePrompt = '';
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final e = await settings.loadTranslationEnabled();
    final p = await settings.loadTranslationModelPath();
    final lang = await settings.loadTranslationTargetLanguage();
    final style = await settings.loadTranslationStylePrompt();
    setState(() {
      enabled = e;
      modelPath = p ?? '';
      targetLanguage = lang;
      stylePrompt = style;
      loading = false;
    });
  }

  Future<void> _save() async {
    await settings.saveTranslationEnabled(enabled);
    await settings.saveTranslationModelPath(modelPath);
    await settings.saveTranslationTargetLanguage(targetLanguage);
    await settings.saveTranslationStylePrompt(stylePrompt);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu cài đặt dịch thuật')));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final langCtrl = TextEditingController(text: targetLanguage);
    final styleCtrl = TextEditingController(text: stylePrompt);
    final pathCtrl = TextEditingController(text: modelPath);

    return Scaffold(
      appBar: AppBar(title: const Text('Dịch thuật trung gian'), actions: [
        TextButton(onPressed: _save, child: const Text('Lưu', style: TextStyle(color: Colors.white))),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text(
          'Nhiều model viết truyện hay lại không được huấn luyện nhiều trên '
          'tiếng Việt, viết trực tiếp dễ ra câu ngô nghê, lặp từ vô nghĩa, ký '
          'tự lạ. Bật tính năng này để: dịch câu hỏi/outline sang ngôn ngữ '
          'model hiểu tốt → model chính sinh văn bản → dịch kết quả về tiếng '
          'Việt. Luôn chạy TUẦN TỰ (không phải song song) — xem "Tối ưu AI '
          'local" để biết máy có nên giữ cả 2 model trong RAM hay không.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const Divider(height: 24),
        SwitchListTile(
          title: const Text('Bật dịch thuật trung gian'),
          subtitle: const Text('Tắt theo mặc định — chỉ bật nếu thấy AI viết tiếng Việt lỗi'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: pathCtrl,
          decoration: const InputDecoration(labelText: 'Thư mục model dịch thuật (MNN, nên chọn model nhỏ 0.3B-1.5B)'),
          onChanged: (v) => modelPath = v,
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: OutlinedButton.icon(
            onPressed: () async {
              final picked = await Navigator.push<String>(
                context,
                MaterialPageRoute(builder: (_) => const FileBrowserScreen(pickDirectory: true)),
              );
              if (picked != null) setState(() => modelPath = picked);
            },
            icon: const Icon(Icons.folder_open_outlined, size: 16),
            label: const Text('Duyệt thư mục'),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: langCtrl,
          decoration: const InputDecoration(labelText: 'Ngôn ngữ trung gian (model chính hiểu tốt nhất)'),
          onChanged: (v) => targetLanguage = v,
        ),
        const SizedBox(height: 12),
        TextField(
          controller: styleCtrl,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Chỉ dẫn phong cách dịch (thêm vào prompt dịch cả 2 chiều)',
            hintText: 'Vd: Giữ đúng văn phong tiểu thuyết, tự nhiên, không dịch máy móc từng chữ.',
          ),
          onChanged: (v) => stylePrompt = v,
        ),
      ]),
    );
  }
}
