# LocalNovel — Project Architecture & Implementation Spec

Tài liệu này tổng hợp toàn bộ kiến trúc, công nghệ, lỗi đã gặp/đã tránh, và
backlog của dự án **LocalNovel** — app Flutter hỗ trợ viết tiểu thuyết dài kỳ
(1000+ chương) bằng AI, chạy trên Android, ưu tiên AI local tận dụng GPU/NPU.
Dùng tài liệu này làm ngữ cảnh đầu vào cho phiên làm việc mới.

---

## 1. Tổng quan dự án & Cấu hình phần cứng mục tiêu

- **Nền tảng**: Android, viết bằng Flutter/Dart
- **Máy test chính**: Asus Zenfone 8 — chip **Snapdragon 888** (tên mã Qualcomm nội bộ **SM8350**), Hexagon 780 NPU (thế hệ **V68**), Adreno 660 GPU, **16GB RAM**, chạy **Android 13**
- **Build**: hoàn toàn qua **GitHub Actions** (không có máy tính/Android Studio) — người dùng chỉ thao tác qua trình duyệt điện thoại: upload file zip mã nguồn lên GitHub, dán nội dung `build.yml`, bấm "Run workflow", tải APK về từ mục Artifacts, cài thủ công
- **Yêu cầu số 1, không thương lượng của người dùng (ĐÃ CẬP NHẬT — xem mục 5.53)**: model AI local bắt buộc phải chạy được **tối thiểu GPU**. Ban đầu ưu tiên tuyệt đối là NPU, nhưng đã điều tra và xác nhận (mục 5.53): công cụ CHÍNH THỨC trưởng thành nhất của Qualcomm cho LLM-trên-NPU (Genie/AI Hub Models) yêu cầu tối thiểu **Hexagon v73** — Snapdragon 888/Hexagon 780 của máy test là **v68**, thấp hơn 2 thế hệ. Quyết định đã thống nhất với người dùng: **chấp nhận GPU (OpenCL) làm đường chính, tối ưu hết mức**; QNN/NPU chuyển thành lựa chọn thử nghiệm CÓ THỂ BẬT THỦ CÔNG (`backendPreference=3`), không còn nằm trên đường mặc định. CPU-only vẫn bị coi là "vứt".
- **Repo cấu trúc**: 1 file zip (`local_novel.zip`) chứa toàn bộ `lib/` (Dart) + `android_native/` (Kotlin/C++ sẽ được ghép vào project Android lúc build) + `pubspec.yaml`; `build.yml` là workflow GitHub Actions dán trực tiếp trên web GitHub (không nằm trong zip).

---

## 2. Kiến trúc phần mềm

### 2.1. Interface AI chung — `AIProvider` (không phải `IInferenceProvider`)

File: `lib/services/ai_provider.dart`. Interface trừu tượng, 3 implementation:

- `LocalLlamaProvider` (`lib/services/providers/local_provider.dart`) — gọi vào tầng native MNN-LLM + QNN qua **Platform Channel** (KHÔNG dùng `dart:ffi`)
- `AnthropicProvider` (`lib/services/providers/anthropic_provider.dart`)
- `OpenAICompatibleProvider` (`lib/services/providers/openai_compatible_provider.dart`) — dùng cho OpenAI hoặc bất kỳ endpoint tương thích chuẩn OpenAI

Interface có: `generate()` (non-streaming), `generateStream()` (streaming), `isReady()`. Tham số sinh văn bản: `temperature`, `maxTokens`, `topP`, `topK`, `repetitionPenalty` — đều có default, người dùng chỉnh trong màn "Tham số sinh văn bản".

Model/provider **không hardcode** — người dùng tự thêm nhiều `LocalModelEntry` (nhiều model local) và nhiều `ApiProviderEntry` (nhiều provider API), chọn 1 cái đang active. Đổi model/provider giữa chừng **không mất bối cảnh** vì Story Bible/lịch sử chat lưu SQLite, tách biệt hoàn toàn khỏi provider đang dùng.

### 2.2. Kiến trúc native AI — MNN-LLM + QNN qua Platform Channel

**Lịch sử quan trọng cần biết**: dự án đã đổi engine AI local **4 lần** trước khi tới MNN:
`fllama` → `lib_llama_cpp` → `flutter_llama` → `llama_cpp_dart` (netdur) → **MNN-LLM (Alibaba) + QNN (Qualcomm)** (hiện tại).

Lý do đổi lần cuối: `llama_cpp_dart` do 1 cá nhân duy trì, API đổi liên tục, **chưa từng xác nhận chạy được GPU/NPU thật trên Android**. MNN-LLM được chọn vì:
- Có sản phẩm thật đã public ("MNN Chat" trên Google Play) chứng minh QNN NPU chạy thật trên Snapdragon 8-series
- Benchmark thật đo trên chính Zenfone 8 của người dùng (app MNN Chat gốc): **Prefill 129.8 t/s, Decode 16.7 t/s trên backend OpenCL (GPU)** — nhanh hơn ~15-16 lần so với CPU thuần (~1 tok/s) của các engine cũ
- Snapdragon 888/SM8350 nằm trong danh sách chip Qualcomm/Microsoft chính thức test QNN

**Kiến trúc native** (`android_native/`):
```
android_native/app/src/main/
  cpp/
    mnn_bridge.cpp       — JNI, gọi API công khai MNN (llm.hpp, class Llm)
    CMakeLists.txt       — biên dịch mnn_bridge.cpp, link với libMNN.so build ở bước trước
  kotlin/com/localnovel/
    MainActivity.kt      — đăng ký MethodChannel + EventChannel, xin quyền POST_NOTIFICATIONS
    mnnbridge/
      MnnNative.kt       — khai báo external fun JNI
      MnnBridge.kt       — xử lý MethodCallHandler + EventChannel.StreamHandler, điều phối GenerationService
      GenerationService.kt — Foreground Service + WakeLock
```

**2 SLOT MODEL ĐỘC LẬP** (multi-context thật, không giả): `slot 0` = model chính (viết truyện), `slot 1` = model dịch thuật trung gian. Mỗi slot có `Llm*` riêng trong `mnn_bridge.cpp` (mảng `g_slots[2]`), có thể cùng tồn tại trong RAM hoặc xả riêng từng cái — quyết định ở tầng Dart (`TranslationService`), không hardcode ở tầng native.

Cầu nối gọi native theo cơ chế **ĐÃ ĐỔI (mục 5.53) — mặc định đi thẳng GPU đã tối ưu, QNN chuyển thành thử nghiệm CÓ THỂ BẬT THỦ CÔNG**:
```
backendPreference=0/1 (mặc định) → OpenCL (GPU, đã tối ưu precision/memory/thread_num) → lỗi thì mới rơi xuống CPU
backendPreference=2 → ép CPU
backendPreference=3 (thử nghiệm, người dùng tự bật) → thử QNN trong tiến trình con cách ly + timeout 90s → lỗi/treo thì rơi xuống OpenCL → CPU
```
Lý do đổi: Hexagon v68 (Snapdragon 888) dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU (yêu cầu v73+, xem mục 5.53) — thử QNN mỗi lần mở model chỉ tốn thời gian chờ vô ích, không có cơ hội thành công thật trên máy này.

Dart gọi qua `MethodChannel('com.localnovel/mnn_method')` (lệnh 1 lần: loadModel/generate/unload/isLoaded/cancelGenerate) và `EventChannel('com.localnovel/mnn_stream')` (luồng token trả về, lọc theo `slot`).

### 2.3. Foreground Service — chạy nền không bị Android kill

Lý do: luồng dịch tuần tự (dịch → sinh văn → dịch ngược) có thể mất vài phút tới hàng giờ (chạy overnight), Android sẽ kill tiến trình nếu app xuống nền/tắt màn hình mà không có Foreground Service.

`GenerationService.kt`: Foreground Service + `PARTIAL_WAKE_LOCK` (trần an toàn 8 tiếng, đủ cho tác vụ qua đêm, tự nhả nếu quên gọi stop để tránh hao pin vô hạn nếu có lỗi). `foregroundServiceType="dataSync"` (suy luận hợp lý nhất, Android không có type "AI inference" riêng — nếu bị từ chối lúc chạy thì đổi sang `specialUse`, **CHƯA XÁC NHẬN 100%**). Bật/tắt tự động quanh mỗi lệnh `loadModel`/`generate` trong `MnnBridge.kt`.

**TỒN ĐỌNG CHƯA XONG**: mỗi lệnh generate hiện tự start/stop service riêng — với luồng dịch tuần tự nhiều bước (dịch → sinh → dịch ngược), nên gộp thành **1 lần start ở đầu pipeline, update nội dung thông báo giữa các bước qua `updateStage()`, chỉ stop ở cuối** — tránh khoảng hở ngắn giữa các bước. Chưa sửa.

### 2.4. Đa truyện (multi-novel)

Mọi bảng nội dung (`characters`, `world_rules`, `timeline_events`, `chapters`, `style_profiles`, `chat_sessions`, `chat_messages`, `imported_documents`) đều có cột `novel_id`. `local_models`/`api_providers` KHÔNG gắn theo novel (tài nguyên máy dùng chung). Máy nâng cấp từ bản cũ (1 truyện) tự động migrate dữ liệu vào 1 "Truyện của tôi" mặc định — không mất dữ liệu (`database_service.dart`, hàm `_migrateToMultiNovel`).

`main.dart`: `NovelGateScreen` (tự vào thẳng truyện active nếu đã chọn trước đó) → `NovelListScreen` (tạo/chọn/xóa truyện) → `RootScreen` (5 tab: Chương/Bách khoa/Trợ lý AI/Tài liệu/Cài đặt, dùng `IndexedStack` giữ trạng thái khi chuyển tab).

### 2.5. RAG (Retrieval-Augmented Generation) — 1 tầng, chưa phân tầng

`RagService` kết hợp 3 cơ chế: luật cứng (luôn nạp), khớp từ khóa (Character/WorldRule.keywords), truy xuất embedding ngữ nghĩa (cosine similarity, `EmbeddingService` — ưu tiên embedding thật nếu có, dự phòng vector "hashing" thuần Dart). Toàn bộ giới hạn trong `novelId`, có ngân sách ký tự (`contextBudgetChars`) theo hồ sơ thiết bị.

**GAP THẬT CHƯA LÀM**: chỉ có 1 tầng tóm tắt (mỗi chương → 3-5 câu, `summary_service.dart`). **CHƯA CÓ** tóm tắt phân tầng đệ quy (tier 2: nén cụm ~10 chương thành "tóm tắt cung"; tier 3: nén toàn bộ thành "bản đồ kịch bản" tổng thể) — cần thiết thật sự cho truyện triệu chữ, đã xác nhận là gap hợp lệ, chưa code.

---

## 3. Thư viện & Công nghệ đã chọn (Tech Stack)

| Lớp | Công nghệ | Ghi chú |
|---|---|---|
| UI/Framework | Flutter/Dart | An toàn dài hạn, Google chính thức |
| Lưu trữ | SQLite qua `sqflite` | Ổn định, có FTS4 cho tìm kiếm toàn văn chương |
| Gọi API cloud | HTTP thuần (không SDK riêng) | An toàn tuyệt đối, không phụ thuộc hãng nào ngừng hỗ trợ |
| AI local (engine) | **MNN-LLM** (Alibaba), build từ mã nguồn qua NDK/CMake trong CI, cờ `-DMNN_BUILD_LLM=true -DMNN_OPENCL=true -DMNN_QNN=true -DMNN_ARM82=true` | Core do Alibaba duy trì, không phải cá nhân |
| AI local (NPU) | **QNN SDK** (Qualcomm), bản "Community" tải công khai không cần đăng nhập: `https://softwarecenter.qualcomm.com/api/download/software/sdks/Qualcomm_AI_Runtime_Community/All/2.40.0.251030/v2.40.0.251030.zip` | Copy `include/QNN` + `lib` vào `MNN/source/backend/qnn/3rdParty/` trước khi build |
| Cầu nối Flutter↔Native | **Platform Channel** (MethodChannel/EventChannel) — KHÔNG dùng `dart:ffi` | Tránh lỗi dlopen .so đã ám cả dự án trước đây |
| Xuất file | Tự dựng EPUB/DOCX/TXT bằng `archive` package (không dùng thư viện xuất bản ngoài) | EPUB hiện đơn giản, chưa có bìa/mục lục thật |
| CI/CD | GitHub Actions, NDK mới nhất (tự dò bản mới nhất qua `sdkmanager --list`, KHÔNG ghim NDK 21 vì quá cũ) | Xem mục 5 — nhiều lỗi build đã xảy ra ở đây |

**Cân nhắc đã loại bỏ** (không dùng, đã so sánh kỹ trước khi quyết định MNN):
- ONNX Runtime GenAI + QNN EP: engine lõi rất chắc (Maven Central chính thức), nhưng gói GenAI cho Android "Java API pending" (chưa publish chính thức) — kém chín hơn MNN tại thời điểm quyết định.
- MediaPipe LLM Inference (Google), MNN gốc Tencent (nhầm lẫn — thực ra là NCNN của Tencent, chỉ mạnh thị giác máy tính, không có LLM binding Flutter): đều yêu cầu bỏ định dạng GGUF, không phải yêu cầu cứng của người dùng nhưng MNN vẫn thắng nhờ bằng chứng thật cụ thể hơn.

---

## 4. Logic các tính năng chính

### 4.1. Story Bible / Lorebook
`Character`, `WorldRule` (có `isHardRule`), `TimelineEvent` — mỗi entry có `keywords` kích hoạt kiểu lorebook NovelAI. Xem trước lorebook khi soạn chương (chip hiện nhân vật/luật đang được nạp).

### 4.2. Chương & xuất bản
CRUD chương, cảnh báo mâu thuẫn (`consistencyWarning`), tìm kiếm FTS toàn văn theo `novelId`. Xuất EPUB/DOCX/TXT (`export_service.dart`).

### 4.3. Chat đa phiên
Nhiều `ChatSession` mỗi truyện, lưu bền vững `ChatMessageRecord` (kèm `providerLabel` — biết tin nhắn nào do model nào trả lời). Xuất cuộc trò chuyện ra TXT/DOCX.

### 4.4. Tài liệu (dịch/tóm tắt cuốn chiếu)
`DocumentService` chia file `.txt`/`.md` thành chunk, xử lý tuần tự (dịch hoặc tóm tắt), ráp kết quả, xuất file. **Giai đoạn 2 (PDF/DOCX/ảnh) CHƯA làm** — chủ động hoãn để tránh rủi ro build.

### 4.5. Văn phong & đắp thịt outline
`StyleService` — mô tả văn phong bằng lời hoặc học từ mẫu văn CỦA CHÍNH người dùng (không lưu nguyên văn tác phẩm người khác, tránh vi phạm bản quyền). "Đắp thịt" outline sơ sài thành chương đầy đủ.

### 4.6. Tối ưu thiết bị
`DeviceProfileService` đọc `/proc/meminfo` + mã chipset thật, `BenchmarkService` đo tốc độ token/giây thực tế (có chặn số liệu vô lý — bài học từ lỗi cũ khi `fllama` từng trả kết quả giả). RAG budget tùy theo hồ sơ máy.

### 4.7. Tham số sinh văn bản
Màn `GenerationSettingsScreen`: `temperature`, `top_p`, `top_k`, `repetition_penalty`, `max_new_tokens` — lưu qua `SettingsService`, áp dụng lại mỗi lần gọi `generate()`/`generateStream()` qua JSON gửi xuống `set_config()` của MNN (tên khóa JSON xác nhận đúng theo tài liệu chính thức MNN: `temperature`, `top_p`, `top_k`, `repetition_penalty`, `max_new_tokens`).

**ĐÃ NỐI**: khung chat (`chat_screen.dart`) VÀ `chapter_editor_screen.dart` (Viết tiếp/Đắp thịt/In-line AI Rewrite đều đọc `SettingsService().loadGenerationConfig()`).

### 4.8. Dịch thuật trung gian
Vấn đề giải quyết: model viết truyện hay thường không train nhiều tiếng Việt, viết trực tiếp dễ ra câu ngô nghê/lặp từ vô nghĩa/ký tự lạ.

`TranslationService`: tùy chọn bật/tắt (mặc định TẮT). Khi bật: dịch câu hỏi/outline sang ngôn ngữ đích (mặc định tiếng Anh) bằng model dịch nhỏ ở **slot 1** → gọi model chính ở **slot 0** sinh văn bản → dịch kết quả về tiếng Việt bằng slot 1. **Luôn chạy tuần tự** (không song song), gộp cả 3 bước vào 1 phiên Foreground Service duy nhất (`beginPipeline`/`updateStage`/`endPipeline`). Quyết định giữ hay xả slot 1 giữa các bước: `SettingsService.loadTranslationKeepResidentMode()` — 'auto' (theo RAM máy, ngưỡng `ramKeepResidentThresholdMb = 6000`) / 'always' / 'never', cấu hình thủ công được ở màn "Tối ưu AI local".

**ĐÃ NỐI**: khung chat VÀ `chapter_editor_screen.dart`.

### 4.9. In-line AI Rewrite
Bôi đen đoạn văn trong `chapter_editor_screen.dart` (qua `TextField.contextMenuBuilder`, thêm mục vào menu bôi đen mặc định của Flutter) → menu lệnh nhanh: chữa lỗi chính tả, viết sinh động hơn, rút ngắn, đổi ngôi kể. Có bảo vệ nếu nội dung đổi trong lúc chờ AI (không ghi đè nhầm chỗ, fallback copy vào clipboard).

### 4.10. Version snapshot (undo AI viết đè) — MỚI
`ChapterVersion` (bảng `chapter_versions`) — chụp lại nội dung chương TRƯỚC mỗi lần "Viết tiếp"/"Đắp thịt"/"Viết lại bằng AI" có khả năng ghi đè. Tối đa `maxVersionsPerChapter = 20` bản mỗi chương, vượt quá tự xóa bản cũ nhất (tránh phình DB vô hạn qua hàng nghìn lần bấm AI). Màn `ChapterVersionsScreen` (mở qua menu "⋮" trong `chapter_editor_screen.dart`) xem/khôi phục — khôi phục cũng tự chụp lại trạng thái hiện tại trước, nên không bao giờ mất hoàn toàn dù khôi phục nhầm.

### 4.11. Tìm kiếm toàn văn UI — MỚI
Tầng DB (`chapters_fts`, FTS4) đã có sẵn từ trước qua `searchChapters()`, chỉ dùng ngầm cho RAG — trước đây KHÔNG có ô tìm kiếm cho người dùng tự tra cứu. `SearchScreen` (mở qua icon kính lúp trong `ChaptersScreen`) tìm ngay khi gõ (không debounce, FTS4 đủ nhanh), hiện đoạn trích quanh từ khóa khớp đầu tiên.

### 4.12. Glossary + chống lặp từ — MỚI
`GlossaryTerm` (bảng `glossary_terms`) — từ điển tra nhanh cho địa danh/thuật ngữ riêng của truyện, khác Story Bible ở chỗ KHÔNG tự động nạp vào prompt AI (không có `keywords` kích hoạt). Quản lý ở tab "Thuật ngữ" trong `StoryBibleScreen`.

`RepetitionAnalyzer` (`repetition_analyzer_service.dart`, thuần Dart không phụ thuộc Flutter) — thống kê từ/cụm bị lặp nhiều. Có xử lý riêng cho đặc thù tiếng Việt: đếm cả âm tiết đơn (unigram) LẪN cụm 2 âm tiết liền nhau (bigram), vì 1 "từ" tiếng Việt thường gồm nhiều âm tiết cách nhau bởi dấu cách — đếm âm tiết đơn riêng lẻ sẽ nhiễu do các âm tiết phổ biến (một, người...) lặp lại là bình thường. Có danh sách hư từ (`stopSyllables`) loại khỏi thống kê, và phát hiện riêng "lặp gần" (từ/cụm dồn vào rất ít đoạn văn — kiểu lặp gây khó chịu khi đọc nhất). Mở qua menu "⋮" → "Kiểm tra lặp từ" trong `chapter_editor_screen.dart`.

### 4.13. Story Bible nâng cao: phân loại thẻ + auto-mention — MỚI
`Character.category` (Nhân vật chính/phụ/Phản diện/Khác) và `WorldRule.category` (Luật lệ/Địa điểm/Vũ khí/Tổ chức/Vật phẩm/Khác) — trường phân loại RIÊNG, tách khỏi `role`/mô tả tự do, hiện dưới dạng chip trong danh sách. Nhân tiện sửa 1 bug có sẵn: `_addRule` trước đây LUÔN đặt `isHardRule: true` bất kể người dùng nhập gì ở ô từ khóa — giờ có `SwitchListTile` thật để chọn.

Auto-mention: gõ `@` trong nội dung chương → hiện hàng gợi ý tên nhân vật khớp (lọc theo phần đã gõ sau `@`), bấm để chèn. **Đơn giản hóa có chủ đích**: hàng gợi ý cố định ngay phía trên ô nội dung (không phải overlay bám theo đúng vị trí con trỏ) — tránh phải tính toán vị trí con trỏ bằng `TextPainter` (dễ sai lệch, không kiểm chứng được nếu không build/test thật nhiều vòng). Đánh đổi chấp nhận được: vẫn đúng chức năng, chỉ khác vị trí hiển thị.

### 4.14. EPUB bìa + mục lục thật — MỚI
Trước đây EPUB có mục lục qua `toc.ncx` (điều hướng bên trong app đọc sách) nhưng KHÔNG có ảnh bìa và không có trang mục lục hiện ngay trong nội dung sách. Giờ:
- Ảnh bìa tự sinh bằng `dart:ui` (`Canvas`/`ParagraphBuilder` vẽ gradient + tên truyện + tác giả) — không cần người dùng tự chuẩn bị ảnh (app cố tình không có `file_picker`, xem mục 5.2-tương-tự lý do lịch sử build).
- Thêm `nav.xhtml` (EPUB3 nav document, `properties="nav"`) — vừa là trang "Mục lục" THẬT nằm trong nội dung sách (trang đầu tiên sau bìa), vừa tương thích các reader hiện đại (Apple Books, KOReader...) ưu tiên `nav.xhtml` hơn `toc.ncx`. Giữ `toc.ncx` song song cho reader cũ — nâng `content.opf` lên `version="3.0"` nhưng vẫn khai `<spine toc="ncx">` để tương thích ngược.

### 4.15. Sao lưu & khôi phục toàn bộ dữ liệu — MỚI
`BackupService` xuất TOÀN BỘ dữ liệu (mọi truyện) thành JSON đóng gói trong `.zip`, chia sẻ qua `share_plus`. Khôi phục qua `FileBrowserScreen` (chọn file `.zip`/`.json`, tái dùng — không cần thêm `file_picker`).

**Quyết định thiết kế quan trọng**: xuất JSON (đi qua các hàm `query()` bình thường) thay vì copy thẳng file `.db` nhị phân — tránh phụ thuộc journal mode/WAL còn dở dang lúc copy, và khi khôi phục đi qua đúng các hàm `upsert*()` sẵn có (tự đồng bộ lại `chapters_fts`...) thay vì ghi đè thẳng file. **KHÔNG xuất API key** (nằm ở `flutter_secure_storage` riêng, tách biệt có chủ đích vì bảo mật) — người dùng cần nhập lại API key thủ công sau khi khôi phục trên máy mới, nhưng danh sách provider/model local (tên, base URL, model ID) vẫn khôi phục đầy đủ.

### 4.16. Quy trình viết tiểu thuyết: Dàn ý/Tuyến truyện/Mục tiêu/Quyển
**Phát hiện thiếu tài liệu (2026-09-06)**: comment trong `database_service.dart` (`_backupTables`) từ lâu đã ghi "5 bảng của tính năng 'quy trình viết tiểu thuyết' (mục 4.16/5.77 tài liệu kiến trúc)" — nhưng mục đó CHƯA TỪNG được viết, dù code đã tồn tại đầy đủ từ trước (comment nói dối chính nó, giống lỗi `recordWordSnapshot()` đã ghi ở mục N). Bổ sung ở đây để đồng bộ:

- **`PlotBeat`** (tab "Dàn ý" trong Story Bible): các nút thắt cốt truyện đã lên kế hoạch, không gắn cứng vào 1 chương cụ thể — dùng làm nguyên liệu khi AI viết chương (`plot_summary_prefer_outline`, xem mục 4.7).
- **`PlotThread`** (tab "Tuyến truyện"): theo dõi các mạch truyện đang mở/đã đóng xuyên suốt nhiều chương (vd "bí ẩn thân thế nhân vật X") — `chapters.thread_ids` liên kết chương nào thuộc tuyến nào.
- **`WritingGoal`** + `daily_word_log` (tab "Mục tiêu"): mục tiêu số từ/ngày hoặc theo hạn, `recordWordSnapshot()` (gọi trong `_save()` ở `chapter_editor_screen.dart`) ghi lại số từ luỹ kế mỗi lần lưu chương để tính streak/biểu đồ "14 ngày gần nhất".
- **`Volume`** (Quyển): nhóm chương thành các quyển/tập — dùng làm mốc phạm vi hiệu lực cho Nhân vật/Luật thế giới (`effectiveFromVolumeId`/`effectiveToVolumeId`, xem mục 4.17 và `_pickScope()` trong `story_bible_screen.dart`), không có tab riêng, quản lý qua màn danh sách chương.

---

### 4.17. Kiểm tra & khôi phục dữ liệu bị lỗi — MỚI (2026-09-05)
Ra đời sau sự cố mục T (xem mục 5): tính năng "Tạo lại tất cả ghi chú" từng có thể ghi đè đoạn văn trong chương bằng thông báo lỗi nội bộ (dạng `⚠️ [...]`, xem hằng số `kAiFailureMarker` ở `ai_provider.dart`) mà không ai nhận ra ngay. Thay vì bắt người dùng tự mở từng chương dò bằng mắt, `DataIntegrityService` (`data_integrity_service.dart`) tự quét toàn bộ chương của 1 truyện tìm dấu hiệu đó, tự tìm bản `ChapterVersion` gần nhất KHÔNG dính lỗi (tận dụng cơ chế snapshot đã có sẵn ở mục 4.10) làm gợi ý khôi phục. `DataIntegrityScreen` (mở qua icon 🩺 trên `ChaptersScreen`) hiện danh sách + nút "Khôi phục" 1 chạm — tự chụp lại bản hiện tại trước khi ghi đè, không mất gì dù bấm nhầm.

**Giới hạn cố tình chưa xử lý**: nếu chương chưa từng có snapshot sạch (vd bị lỗi ngay từ bản đầu tiên, hoặc snapshot sạch đã bị dọn do vượt `maxVersionsPerChapter=20`), công cụ chỉ báo "không tự khôi phục được", không đoán mò/tự viết lại — người dùng cần tự sửa tay đoạn đó.

---

## 5. Lỗi đã gặp & bài học kỹ thuật quan trọng (tránh lặp lại)

Đây là phần quan trọng nhất để phiên sau không đi lại đúng đường cũ:

1. **Không đoán API — luôn đọc log/tài liệu thật trước khi viết code.** Toàn bộ chuỗi đổi engine AI (fllama → lib_llama_cpp → flutter_llama → llama_cpp_dart) đều do đoán sai tên hàm/tham số của package, gây hàng chục vòng build-lỗi-sửa. Nguyên tắc rút ra: trước khi viết cầu nối vào 1 thư viện mới, phải tra cứu (web search/đọc header thật qua bước build in log) — không suy luận từ tên hàm nghe hợp lý.

2. **`libllama.so not found` (đã giải quyết bằng cách đổi kiến trúc)**: nguyên nhân gốc là gói `llama_cpp_dart` không đóng gói sẵn thư viện native, phải tự tải AAR — rất mong manh. Giải pháp triệt để: đổi hẳn sang MNN + biên dịch native trực tiếp trong CI, dùng Platform Channel thay FFI (loại bỏ hoàn toàn kiểu lỗi dlopen).

3. **NDK 21 quá cũ, không hỗ trợ SVE2/KleidiAI**: lỗi `clang++: error: the clang compiler does not support '-march=...+sve2'`. Nguyên nhân: MNN dùng tối ưu ARM mới (KleidiAI/SME2) nhưng README của MNN khuyến nghị NDK 21 đã lỗi thời so với code thật. **Sửa**: luôn tự dò NDK mới nhất qua `sdkmanager --list`, không ghim version cứng.

4. **`QnnInterface.h file not found`**: `-DMNN_QNN=true` cần header/lib thật của Qualcomm QNN SDK, MNN không mang theo sẵn (SDK độc quyền). **Sửa**: tải QNN SDK bản Community công khai, copy vào `MNN/source/backend/qnn/3rdParty/`.

5. **Đường dẫn tương đối bị lệch khi `working-directory` đổi giữa các step GitHub Actions**: đặt `QNN_SDK_ROOT` bằng đường dẫn tương đối ở 1 step, dùng lại ở step khác có `working-directory` khác → sai đường dẫn dù CMake không báo lỗi cú pháp. **Bài học**: mọi biến môi trường dùng xuyên step PHẢI là đường dẫn tuyệt đối.

6. **`find_library` chỉ tìm đúng path cố định, không tìm thấy `libMNN.so`**: MNN đặt file `.so` không đúng chỗ đoán trước. **Sửa**: dùng `file(GLOB_RECURSE ...)` quét toàn bộ thư mục install thay vì đoán 1-2 path cố định.

7. **APK "release" build ra không cài được ("gói có vẻ không hợp lệ")**: bản release không có signing key (mã nguồn công khai không kèm khóa ký riêng). **Sửa**: dùng `assembleDebug` cho mục đích test (tự động ký bằng debug keystore).

8. **Android 14+ bắt buộc khai báo `foregroundServiceType`** — dùng `dataSync` (suy luận hợp lý nhất, **chưa xác nhận 100%** là lựa chọn đúng, có thể cần đổi `specialUse` nếu bị từ chối lúc chạy thật).

9. **Danh sách chip được phép dùng QNN trong app "MNN Chat" của Alibaba (`sQnnLibMap`) là hardcode riêng của họ, KHÔNG phải giới hạn kỹ thuật thật của QNN** — quyết định của dự án: không copy theo whitelist đó, luôn thử QNN trực tiếp trên mọi máy, bắt lỗi rồi rơi xuống GPU/CPU.

10. **Chưa xác minh, nghi ngờ là bịa**: tên hàm `MNN::Interpreter::releaseCache` (được đề xuất từ 1 tài liệu ngoài) — tra không ra bằng chứng, CHƯA đưa vào code. Nếu phiên sau cần quản lý KV cache giữa các đoạn xử lý (tóm tắt phân tầng, dịch tuần tự nhiều đoạn), phải đọc lại `llm.hpp` thật (đã từng in ra log CI 1 lần, hỏi người dùng có còn giữ log đó không) trước khi thêm lời gọi hàm nào.

11. **Snapdragon 888 (Zenfone 8) là chip 2021, không nằm trong danh sách máy Alibaba tự test ổn định** (README MNN cũ ghi rõ chỉ test kỹ trên OnePlus 13/Xiaomi 14 Ultra — chip 2025) — rủi ro ổn định runtime tổng quát (không riêng QNN) chưa loại trừ hoàn toàn, cần theo dõi khi test thật.

12. **`AnthropicProvider`/`OpenAICompatibleProvider` thiếu tham số so với interface `AIProvider`**: lỗi build lần đầu thật (Build APK #30) — `generate()`/`generateStream()` của 2 provider cloud này thiếu `topP`/`topK`/`repetitionPenalty` (chỉ có ở bản khai báo interface và ở `LocalLlamaProvider`), Dart bắt lỗi ngay ở bước biên dịch (`kernel_snapshot_program failed`), không phải lỗi runtime. **Đã sửa**: thêm đủ 3 tham số vào cả 2 provider — Anthropic Messages API nhận thẳng `top_p`/`top_k`, OpenAI-compatible nhận `top_p` + xấp xỉ `repetitionPenalty` bằng `frequency_penalty` (map thô `repetitionPenalty - 1.0`), `top_k` gửi kèm cho các endpoint tương thích mở rộng (llama.cpp server, vLLM, Ollama) dù không phải chuẩn OpenAI chính thức. Bài học: khi thêm tham số mới vào 1 interface dùng chung nhiều implementation, phải rà lại TẤT CẢ implementation, không chỉ implementation đang cần dùng ngay lúc đó.

13. **Cảnh báo (chưa phải lỗi) — Kotlin Gradle Plugin (KGP) legacy ở `device_info_plus`/`share_plus`**: log build in cảnh báo các bản Flutter tương lai sẽ FAIL nếu plugin còn áp dụng KGP kiểu cũ thay vì "Built-in Kotlin". Build #30 vẫn qua được bước này (chỉ warning), nhưng cần theo dõi: nếu 1 phiên bản Flutter sau này thật sự chặn cứng, phải nâng version 2 package này trong `pubspec.yaml` lên bản đã hỗ trợ Built-in Kotlin (tra changelog thật trước khi đổi version, không đoán).

14. **`translation_settings_screen.dart` hứa hẹn 1 mục ở màn "Tối ưu AI local" nhưng chưa từng code**: text giới thiệu ghi "xem 'Tối ưu AI local' để biết máy có nên giữ cả 2 model trong RAM hay không", nhưng màn đó chưa từng có phần này (phát hiện qua ảnh chụp màn hình thật của người dùng). **Đã sửa**: thêm mục "Dịch thuật trung gian — giữ model trong RAM" vào `local_optimization_screen.dart` (hiện RAM máy phát hiện được, ngưỡng tự động, và `SegmentedButton` cho 3 chế độ Tự động/Luôn giữ/Luôn xả — lưu qua `SettingsService.saveTranslationKeepResidentMode`, `TranslationService._shouldKeepResident()` đọc lại đúng lựa chọn này thay vì luôn tự đoán theo RAM). Thêm nút điều hướng thẳng từ màn dịch thuật sang màn tối ưu. Bài học: khi 1 màn hình VIẾT text nhắc tới 1 màn khác, phải THẬT SỰ đi kiểm tra màn kia có đúng như mô tả không, không được giả định.

15. **`TextField.labelText` bị cắt "..." khi field trống/chưa focus và label dài**: label chỉ hiển thị đủ nhiều dòng khi đã "float" lên trên (field có nội dung hoặc đang được focus) — khi field trống và chưa chạm vào, label render inline trong khung 1 dòng nên bị ellipsis. **Đã sửa** ở field "Thư mục model dịch thuật": rút ngắn `labelText`, chuyển phần giải thích dài xuống `helperText` (luôn hiển thị, tự xuống dòng qua `helperMaxLines`). Cần rà lại các `TextField` khác trong app có `labelText` dài tương tự nếu người dùng báo gặp lại vấn đề này ở màn hình khác.

16. **`dart:ui` (`Canvas`/`ParagraphBuilder`) dùng được trong 1 service thuần, không cần widget**: để sinh ảnh bìa EPUB (mục 4.14) không cần `file_picker` hay ảnh có sẵn — vẽ trực tiếp bằng `dart:ui` ngay trong `export_service.dart` (không phải file `.dart` UI/widget). Hoạt động được vì Flutter engine đã khởi tạo sẵn khi hàm này được gọi (luôn gọi sau khi app đã chạy, từ 1 hành động người dùng bấm nút xuất bản) — **CHƯA build/test thật để xác nhận không có vấn đề threading/timing nào** (lý thuyết đúng theo tài liệu Flutter, nhưng đây là lần đầu dự án dùng `dart:ui` trực tiếp ngoài widget tree).

17. **Khi thêm cột mới vào bảng đã tồn tại qua nhiều đời migration, luôn dùng `PRAGMA table_info` kiểm tra tồn tại trước khi `ALTER TABLE ADD COLUMN`** (mẫu `addColumnIfMissing` đã có sẵn từ migration v1→v2, tái dùng y hệt cho v2→v3 ở mục 4.10/4.13) — an toàn nếu 1 máy nào đó lỡ chạy migration 2 lần (vd do lỗi mất kết nối DB giữa chừng), không bị lỗi "duplicate column".

18. **[NGHIÊM TRỌNG NHẤT TỪ TRƯỚC TỚI NAY] `flutter create --org com.localnovel --project-name local_novel` sinh ra package THẬT là `com.localnovel.local_novel` (org + tên project ghép lại), KHÔNG PHẢI chỉ `com.localnovel`** — nhưng bước "Ghép code native (Kotlin + JNI) vào project Android" trong `build.yml` từ trước tới giờ luôn copy `MainActivity.kt` (file THẬT, có đăng ký `MethodChannel`) vào `scaffold/android/app/src/main/kotlin/com/localnovel/MainActivity.kt` — SAI đường dẫn, thiếu `/local_novel`. Hậu quả: file thật nằm ở nhầm chỗ (class thừa, không ai gọi tới), còn `AndroidManifest.xml` (đúng theo package thật `com.localnovel.local_novel`) vẫn khai báo dùng bản `MainActivity` MẶC ĐỊNH RỖNG do chính `flutter create` tự sinh — bản này build/cài/chạy giao diện đều bình thường (không lỗi biên dịch, không crash lúc mở app) nhưng KHÔNG ĐĂNG KÝ `MethodChannel` NÀO CẢ. Kết quả: **mọi tính năng dùng model local (chat, đo tốc độ...) đều lỗi `MissingPluginException` ngay từ Build APK #30 tới #33** — nghĩa là **chưa từng có bản build nào trước đó thực sự chạm tới code native/JNI/MNN cả**, toàn bộ những gì tưởng đã "xác nhận" trước đó (QNN, Foreground Service...) đều CHƯA từng được kiểm chứng thật.
    **Đã sửa** (từ Build APK #34): bước "Ghép code native" giờ **tự dò** đường dẫn + package thật bằng cách tìm file `MainActivity.kt`/`.java` mặc định mà `flutter create` vừa sinh ra (`find scaffold/android/app/src/main -name 'MainActivity.kt' -o -name 'MainActivity.java'`), đọc dòng `package ...` bên trong để biết package thật, xóa bản mặc định, copy file thật vào ĐÚNG chỗ + tự sửa dòng `package` cho khớp — không hardcode đường dẫn nữa.
    **Bài học lớn nhất**: khi 1 quy trình build có bước "sinh khung tự động rồi ghép code riêng vào", PHẢI xác minh runtime thật xem code ghép vào có đúng là code ĐANG CHẠY hay không (vd bằng cách cho code tự in ra 1 dấu hiệu nhận biết), không được tin ngầm định chỉ vì build "thành công" và app "mở lên bình thường" — 2 thứ này hoàn toàn không đảm bảo code native thật sự được dùng.

19. **Hạ tầng ghi log chẩn đoán 3 tầng (Dart/Kotlin/C++) khi chưa có ADB/logcat thật**: xây dựng `DebugLogService` (Dart, ghi trước/sau mỗi lệnh gọi `invokeMethod` rủi ro) + `kLog()` (Kotlin, ghi trước/sau mỗi bước trong `onMethodCall`) + `nativeLog()` (C++, ghi từng dòng trong `nativeGenerate`/`nativeLoadModel`) — TẤT CẢ ghi vào CÙNG 1 file, flush đĩa ngay lập tức (không đợi buffer), để nếu app crash cứng (SIGSEGV, native, không throw exception Kotlin/C++ bắt được), dòng log CUỐI CÙNG còn sống sót trên đĩa cho biết chính xác code dừng ở đâu. Đây là kỹ thuật chẩn đoán thay thế tạm cho logcat/tombstone thật khi người dùng không có máy tính + ADB. Xem trực tiếp trong app qua Cài đặt → "Log debug" (`DebugLogScreen`), không cần vào Files.

20. **Ghi file vào `/storage/emulated/0/Download/` cần quyền `MANAGE_EXTERNAL_STORAGE` ĐƯỢC CẤP THẬT (qua Cài đặt hệ thống), không tự có chỉ vì khai báo trong `AndroidManifest.xml`** — lần đầu thử ghi log debug vào `Download`, cả Kotlin lẫn C++ đều ghi thất bại ÂM THẦM (lỗi bị code tự bắt rồi bỏ qua, không báo gì) vì quyền này chưa từng được người dùng bật tay. **Đã sửa**: chuyển hẳn sang ghi vào thư mục RIÊNG của app (`appContext.filesDir` phía Kotlin, truyền xuống C++ qua hàm `nativeSetLogDir()` gọi 1 lần lúc khởi động) — thư mục này luôn ghi được, không cần xin quyền gì cả.

21. **`getApplicationDocumentsDirectory()` (Dart, gói `path_provider`) KHÔNG trùng thư mục với `context.filesDir` (Kotlin) trên Android** — dù nghe tên tưởng tương đương. Đã tra cứu xác nhận: `getApplicationDocumentsDirectory()` map sang 1 thư mục riêng (`.../app_flutter`), còn `getApplicationSupportDirectory()` mới đúng là map sang `getFilesDir()`. Khi cần Dart đọc lại đúng file mà tầng Kotlin/C++ vừa ghi vào `filesDir`, PHẢI dùng `getApplicationSupportDirectory()`, không phải `getApplicationDocumentsDirectory()` — nếu không sẽ không bao giờ đọc được file dù nó ghi ra thành công.

22. **`backendPreference` (QNN tự động / ép GPU / ép CPU) giờ đọc từ Cài đặt (`SettingsService.loadBackendPreference()`), không còn hardcode `0` trong `MnnBridge.kt` nữa** — cho phép người dùng tự đổi qua lại giữa 3 chế độ ngay trong app để khoanh vùng lỗi native theo backend, KHÔNG cần build lại APK mỗi lần thử. Bài học: khi đang debug 1 vấn đề mà giả thuyết hàng đầu là "lỗi backend X", nên ưu tiên làm tham số đó CẤU HÌNH ĐƯỢC từ UI trước khi thử sửa cứng trong code — tiết kiệm rất nhiều vòng build (mỗi vòng build native mất 15-20+ phút).

23. **[Đã LOẠI TRỪ, không phải nguyên nhân]** Từng nghi ngờ tham số `max_new_tokens = 0` truyền cứng cho `llm->response(...)` gây crash native (SIGSEGV) — sửa thành `-1` nhưng **crash vẫn xảy ra y hệt**, xác nhận qua log debug thật. Giả thuyết này đã bị loại bỏ hoàn toàn. Bài học: 1 giả thuyết nghe hợp lý về mặt kỹ thuật (khớp với "tài liệu chính thức không ai truyền 0") vẫn PHẢI được xác nhận bằng thực nghiệm thật trước khi coi là đã sửa xong — không dừng lại ở "nghe có vẻ đúng".

24. **[NGUYÊN NHÂN THẬT của crash native, đã xác nhận bằng log thật] R8/ProGuard đổi tên class/hàm Kotlin trong bản `--release`, làm JNI `GetMethodID("onToken", "(Ljava/lang/String;Z)V")` trả về `NULL`** — log debug xác nhận tên lớp thật lúc chạy của callback bị đổi thành `a0.a` (dấu hiệu R8 đổi tên kinh điển). Vì `GetMethodID` trả `NULL` không phải throw C++ exception (mà là "pending exception" phía JVM), nếu code cũ không kiểm tra `NULL` trước khi gọi tiếp `CallVoidMethod` sẽ crash cứng ngay (SIGSEGV/undefined behavior) — đúng khớp mọi triệu chứng quan sát được (crash y hệt ở mọi backend QNN/GPU/CPU, vì đây là lỗi ở TẦNG GỌI JNI, không liên quan gì tới backend suy luận).
    **Phát hiện quan trọng khác**: theo tài liệu chính thức Flutter, các bản gần đây **KHÔNG tắt được** code shrinking (R8) cho bản release nữa (cờ `--no-shrink` hết tác dụng, "Code shrinking is always enabled in release builds") — thử set `minifyEnabled false` trong `build.gradle` qua `sed` KHÔNG có tác dụng (đã xác nhận qua thực nghiệm, không phải chỉ tra tài liệu suông).
    **Cách sửa ĐÚNG** (khuyến nghị chính thức cho JNI + R8): thêm luật ProGuard `-keep class com.localnovel.** { *; }` (rộng, giữ nguyên cả package thay vì chỉ đúng `TokenCallback`, phòng hờ chỗ khác cũng dùng JNI tương tự) vào `proguard-rules.pro`, VÀ kiểm tra/tự chèn dòng `proguardFiles ...` vào khối `buildTypes { release { ... } }` của `build.gradle`/`build.gradle.kts` nếu còn thiếu (khung `flutter create` mặc định KHÔNG chắc đã có sẵn dòng này) — làm bằng Python (không dùng `sed` mù quáng) để xác nhận chắc chắn đã thêm đúng chỗ, in lại nội dung sau khi sửa để đối chiếu.
    **Bài học viết script build**: heredoc bash (`<< 'EOF' ... EOF`) LỒNG bên trong khối `run: |` của YAML rất dễ vỡ — YAML literal block scalar yêu cầu MỌI dòng (kể cả dòng kết thúc heredoc) phải thụt lề nhất quán, nhưng bash heredoc lại yêu cầu dòng kết thúc phải sát lề trái (trừ khi dùng `<<-` với TAB, không phải space) — 2 yêu cầu xung đột nhau. Cách né an toàn: dùng `python3 -c "..."` với code Python truyền qua 1 chuỗi (có thể nhiều dòng trong chuỗi double-quote của bash, bash hỗ trợ xuống dòng thật trong chuỗi), tránh hẳn heredoc lồng nhau. Luôn kiểm tra lại bằng `python3 -c "import yaml; yaml.safe_load(open('build.yml'))"` sau khi sửa `build.yml` bằng tay/script, và mô phỏng chạy thử đoạn script trích ra trong môi trường giả lập trước khi gửi cho người dùng chạy thật trên GitHub Actions (tiết kiệm được 1 vòng build/test mất 15-20 phút mỗi lần sai).

25. **Toàn bộ `onMethodCall` của `MnnBridge.kt` trước đây KHÔNG có try/catch bao ngoài cùng** — nghĩa là bất kỳ exception Kotlin nào ném ra TRỰC TIẾP trong hàm này (không phải trong coroutine, nên `finally`/`catch` của coroutine không với tới được) sẽ làm crash toàn bộ app ngay lập tức, không kịp gọi `result.error(...)` để báo cho Dart biết. Đã thêm 1 lớp try/catch bao ngoài cùng (`onMethodCall` gọi `onMethodCallInner` bên trong try/catch, bắt `Throwable`, log + trả lỗi qua `result.error(...)` thay vì để crash) — áp dụng cho MỌI lỗi Kotlin tương lai ở tầng này, không chỉ lỗi đã biết. Bài học: `MethodChannel.MethodCallHandler.onMethodCall` không tự động được Flutter engine bọc try/catch — bất kỳ handler nào có logic đủ phức tạp (gọi Android API có thể ném exception như Foreground Service, file I/O...) đều nên tự bọc try/catch ngay từ đầu, không đợi tới khi crash thật mới thêm.

26. **[GHI LẠI MUỘN — lỗi này đã xảy ra và ĐÃ ĐƯỢC SỬA ở phiên trước, nhưng chưa từng được chép vào tài liệu này] Lỗi `RuntimeException: Methods marked with @UiThread must be executed on the main thread`** — sau khi mục 24 (ProGuard) được sửa, `llm->response()` chạy trọn vẹn lần đầu tiên (không còn crash native), nhưng `eventSink?.success(...)` (gửi token về Flutter qua `EventChannel`) và `result.success(...)`/`result.error(...)` (trả kết quả `MethodChannel`) đang bị gọi từ luồng nền `Dispatchers.Default` (dùng để nạp/sinh model nặng, tránh treo UI) — trong khi Flutter bắt buộc 2 lệnh này phải chạy trên luồng chính (UI thread). **Cách sửa đã áp dụng**: bọc toàn bộ 7 chỗ gọi `eventSink?.success/error` và `result.success/error` nằm bên trong `scope.launch { ... }` (luồng nền) bằng `mainHandler.post { ... }` (đẩy đúng lệnh gọi lại Flutter về luồng chính), còn phần tính toán nặng (nạp/sinh model) vẫn giữ nguyên ở luồng nền, không đổi. **Xác nhận qua code hiện tại**: `MnnBridge.kt` đã có đủ các chỗ bọc này. **Xác nhận qua log thật** (`debug_log.txt` ngày 2026-07-26): không còn xuất hiện lỗi `@UiThread` nữa — lỗi này coi như đã đóng, chỉ là tài liệu quên cập nhật, nay bổ sung lại cho đủ lịch sử.

27. **[BUG MỚI PHÁT HIỆN VÀ ĐÃ SỬA — 2026-07-27] `SettingsService.currentProvider()` dựng 1 `LocalLlamaProvider()` MỚI mỗi lần được gọi**, thay vì tái sử dụng instance cũ. Vì cờ `_loaded` (đánh dấu model đã nạp hay chưa) nằm trên instance, không phải static/toàn cục, mỗi lần `chat_screen.dart`/`chapter_editor_screen.dart` gọi `SettingsService().currentProvider()` (tức là mỗi lần gửi tin nhắn/bấm AI) đều tạo instance mới với `_loaded=false` → luôn gọi lại `loadModel` native dù model không đổi. Xác nhận qua `debug_log.txt`: cả 3 lần chat cách nhau 5-10 giây đều có dòng `ensureLoaded... CHUẨN BỊ gọi loadModel native`. Không gây crash (MNN dùng mmap nên "nạp lại" vẫn nhanh vì trang nhớ đã có sẵn trong cache của hệ điều hành từ lần trước), nhưng tốn thời gian dựng lại không cần thiết mỗi lần chat. **Đã sửa**: thêm cache tĩnh (`_cachedLocalProvider`/`_cachedLocalModelPath`) trong `SettingsService`, chỉ tạo `LocalLlamaProvider` mới khi `modelPath` thật sự đổi (người dùng đổi model trong Cài đặt).

28. **[ĐANG DEBUG — CHƯA CÓ KẾT LUẬN CUỐI, đây là việc ưu tiên số 1 hiện tại] `llm->response()` chạy xong không crash, nhưng luôn trả về chuỗi RỖNG (`do dai ket qua=0`)** ở cả 3 lần thử trong `debug_log.txt` (kể cả lần `max_new_tokens=1024`, prompt 494 ký tự). Quan sát quan trọng nhất: khoảng thời gian giữa lúc Kotlin gọi `nativeGenerate` và lúc nó trả về chỉ ~1ms theo dấu thời gian tầng Kotlin — trong khi theo benchmark thật của chính máy này (mục 3, bảng tech stack: decode ~16.7 token/giây trên OpenCL), dù chỉ sinh đúng 1 token cũng không thể xong trong 1ms. Kết luận tạm thời: `response()` gần như chắc chắn KHÔNG chạy forward-pass thật nào — dừng ngay ở điều kiện dừng (EOS) từ token đầu tiên, không phải do máy chậm hay lỗi backend. Nghi ngờ hàng đầu: model `Orion-zhen-Qwen2.5-7B-Instruct-Uncensored-MNN-q4-chinh` (convert qua `LocalNovel_Convert_Model_To_MNN.ipynb`, dùng đúng `llmexport.py` chính thức của MNN — không phải script tự chế, nên ít khả năng lỗi quy trình convert) có `tokenizer_config.json`/`generation_config.json`/EOS token id lệch chuẩn so với bản Qwen2.5 gốc do đây là bản fine-tune "Uncensored" của bên thứ ba. **Đã thêm vào `mnn_bridge.cpp`** (chưa build/test): (a) đo thời gian thật bằng `std::chrono` quanh `llm->response()` để xác nhận chắc chắn giả thuyết "không chạy forward-pass thật" thay vì suy đoán qua log Kotlin; (b) log 120 ký tự đầu + 120 ký tự cuối của prompt thật (thay `\n` bằng `|`) để kiểm tra định dạng prompt gửi xuống native có đúng như kỳ vọng không; (c) log cảnh báo rõ khi kết quả rỗng, gợi ý hướng nghi ngờ. **Việc cần làm tiếp**: build lại với bản sửa này, đọc log mới để xác nhận/loại trừ giả thuyết; nếu xác nhận đúng, thử convert + test lại bằng 1 model Qwen2.5 gốc (không phải bản uncensored) để cô lập xem lỗi nằm ở bản convert cụ thể này hay ở tầng code.

30. **[CẬP NHẬT QUAN TRỌNG — tiếp tục mục 28, dựa trên bằng chứng thật, KHÔNG còn nghi ngờ model nữa] Đã cô lập được: lỗi KHÔNG nằm ở model, mà ở code cầu nối.** Trình tự bằng chứng, theo đúng thời gian thật xảy ra:
    - **CI (build #45-47)**: gặp lỗi build hoàn toàn khác, không liên quan tới MNN — `Could not find method kotlin()` khi biên dịch package Dart `jni` (bị kéo vào gián tiếp qua 1 plugin khác). Truy ra tận gốc: package `jni` (bản `1.0.1`, đã xác nhận qua log là bản mới nhất hiện có, không có bản nào mới hơn để nâng cấp) chỉ tự áp dụng plugin Kotlin khi `AGP major version < 9`; scaffold Flutter (bản `3.44.7`, đã pin) mặc định sinh ra AGP `9.0.1` → điều kiện đó sai → khối `kotlin { compilerOptions {...} }` trong chính `build.gradle` của `jni` không tìm thấy extension tương ứng → lỗi. **Đã sửa**: hạ AGP xuống `8.13.0` (đúng version Google xác nhận đi kèm Gradle `8.13` — "AGP 8.13 now requires Gradle 8.13"), hạ Gradle wrapper xuống `8.13`, hạ Kotlin xuống `2.1.20` (phần này chỉ có bằng chứng gián tiếp, chưa xác nhận 100% là cặp version tối ưu nhất, nhưng đã build qua được nên coi như đạt yêu cầu tối thiểu). Build APK từ đó đã qua được ổn định.
    - **Test cô lập model (2026-07-28)**: convert thêm 1 bản `Qwen/Qwen2.5-1.5B-Instruct` CHÍNH THỨC (không phải fine-tune "Uncensored"), qua đúng `LocalNovel_Convert_Model_To_MNN.ipynb`, dùng đúng `llmexport.py` chính thức của MNN. Kết quả: **lỗi giống hệt bản Uncensored** — `llm->response()` vẫn trả rỗng, `THOI GIAN THAT (ms)=0` ở cả 2 model, cả 2 prompt khác nhau hoàn toàn (chat có Story Bible lẫn benchmark cố định). → **Loại bỏ hoàn toàn giả thuyết "lỗi do tokenizer/EOS của bản Uncensored"** đã đặt ra ở mục 28 — không phải lỗi model, mà là lỗi hệ thống ở tầng code, ảnh hưởng như nhau bất kể model nào.
    - **Đọc `llm.hpp` THẬT** (lấy trực tiếp từ log CI, bước "In cấu trúc thư mục install thật" vốn đã in sẵn từ trước, chỉ là chưa ai đọc tới — đúng việc đã ghi nợ ở mục 5.10): xác nhận chữ ký `response(const std::string&, std::ostream*, const char*, int max_new_tokens=-1)` khớp chính xác 100% với cách `mnn_bridge.cpp` đang gọi — không phải lỗi tham số. Nhưng phát hiện 2 điều quan trọng chưa từng khai thác:
      - `set_config()` trả về `bool` (thành công/thất bại) — code cũ **bỏ qua hoàn toàn** giá trị này, không hề biết JSON cấu hình có thực sự được MNN chấp nhận hay không.
      - `class Llm` có `getContext()` trả về `const LlmContext*` — struct này MNN tự ghi lại `status` (enum `LlmStatus`: `NORMAL_FINISHED`/`MAX_TOKENS_FINISHED`/`INTERNAL_ERROR`/`TIMEOUT`...), `prompt_len`, `gen_seq_len`, `prefill_us`/`decode_us` thật — đây là nguồn duy nhất cho biết **chính xác** lý do MNN dừng sinh văn bản, thay vì phải suy đoán qua thời gian chạy như trước giờ.
    - **Đã thêm vào `mnn_bridge.cpp`** (chưa build/test): log giá trị `bool` thật của `set_config()`, và log toàn bộ `LlmContext` (status/prompt_len/gen_seq_len/prefill_us/decode_us) ngay sau mỗi lần `response()`. **Việc cần làm ngay ở phiên tiếp theo**: build lại, đọc đúng dòng log `LlmContext THAT — status=...` — con số đó sẽ cho biết chính xác hướng sửa (nếu `status=INTERNAL_ERROR`, tìm lỗi nội bộ MNN; nếu `prompt_len=0`, lỗi nằm ở bước tokenize/encode prompt, có thể liên quan tới `initRuntime()`/`load()` chưa hoàn tất đúng cách dù trả về `success:true`).

31. **[BUG MỚI PHÁT HIỆN VÀ ĐÃ SỬA — 2026-07-28] Cắt chuỗi preview prompt trong log (mục 5.28) làm hỏng cả file `native_debug.txt`.** `preview.substr(0, 120)`/`substr(size-120)` cắt theo byte, không theo ký tự — tiếng Việt có dấu dùng UTF-8 nhiều byte/ký tự, nếu điểm cắt rơi giữa 1 ký tự nhiều byte sẽ tạo chuỗi byte không hợp lệ. App đọc file log bằng UTF-8 (`File.readAsString()`) gặp đoạn hỏng đó ném `FileSystemException: Failed to decode data using encoding 'utf-8'`, hỏng toàn bộ file log (không đọc được cả các dòng quan trọng phía sau, kể cả `LlmContext` mới thêm ở mục 5.30) — không phải chỉ 1 dòng bị lỗi. **Đã sửa**: thêm 2 hàm `utf8SafeHead`/`utf8SafeTail`, lùi/tiến điểm cắt tới đúng ranh giới ký tự (bỏ qua continuation byte dạng `10xxxxxx`) trước khi cắt, đảm bảo không bao giờ cắt giữa 1 ký tự UTF-8 nhiều byte nữa.

33. **[NGHI NGỜ NGUYÊN NHÂN GỐC MẠNH NHẤT TỪ TRƯỚC TỚI NAY — 2026-07-28, tiếp tục mục 30] Ép backend OpenCL để loại trừ QNN — lỗi vẫn giống hệt, loại bỏ luôn nghi ngờ backend.** `status` vẫn `NOT_LOADED (-1)`, mọi trường `LlmContext` vẫn 0, dù đã ép chạy OpenCL thay vì QNN. Vì `NOT_LOADED` chính là giá trị khởi tạo MẶC ĐỊNH của `LlmContext` lúc vừa tạo, chưa từng bị đụng tới — kết luận: `response()` thoát ra ngay từ đầu, trước cả bước mã hoá prompt, không phụ thuộc backend nào. Truy ngược lên tận `createLLM()`: header thật (`llm.hpp`) đặt tên tham số là `config_path` — đường dẫn tới 1 FILE cấu hình, nhưng `local_provider.dart`/`mnn_bridge.cpp` từ đầu dự án luôn truyền thẳng đường dẫn THƯ MỤC model (`modelPath`) vào thẳng `createLLM()`, không phải file. Đối chiếu với `LocalNovel_Convert_Model_To_MNN.ipynb`: file cấu hình thật do notebook sinh ra tên là `llm_config.json` (xác nhận qua chính bước kiểm tra file bắt buộc của notebook, mục "Bước 6"). Nếu `createLLM` cố đọc 1 thư mục như thể là file JSON, tuỳ thư viện có thể không ném exception C++ nhưng cấu hình sẽ rỗng/mặc định hoàn toàn — khớp chính xác với MỌI triệu chứng quan sát được xuyên suốt từ mục 28 tới giờ (không crash, `LlmContext` chưa từng được đụng tới, giống hệt nhau ở mọi model/mọi backend). **Đã sửa**: `nativeLoadModel` giờ tự động dò đúng file cấu hình thật bên trong thư mục được truyền vào — ưu tiên `llm_config.json` (đúng tên notebook dùng), dự phòng `config.json` (quy ước MNN cũ hơn), chỉ dùng nguyên `path` gốc nếu bản thân nó đã là 1 file `.json` rồi (không đoán mù, có log cảnh báo rõ nếu không tìm thấy file nào). **CHƯA build/test** — đây là việc ưu tiên số 1 tuyệt đối cho phiên tiếp theo, nhiều khả năng là nguyên nhân gốc thật sự của toàn bộ chuỗi debug từ mục 28.

35. **[SỬA LẠI LẦN 2, DỰA TRÊN TÀI LIỆU CHÍNH THỨC MNN — 2026-07-29, tiếp tục mục 33] Ưu tiên sai thứ tự giữa `config.json` và `llm_config.json`.** Sau khi mục 33 sửa xong đường dẫn (dò đúng file bên trong thư mục thay vì dùng thẳng thư mục), `load()` vẫn trả về `false` ở cả 3 backend (QNN/OpenCL/CPU — xác nhận qua log thật, không phải giả thuyết). Tra cứu tài liệu chính thức `alibaba/MNN/transformers/README.md`: **`config.json` mới là file truyền thẳng vào `createLLM()`/`llm_demo` (mọi ví dụ dòng lệnh chính thức đều dùng `model_dir/config.json`)**; `llm_config.json` chỉ là file được chính `config.json` tự tham chiếu tới bên trong qua field `llm_config` (mặc định trỏ ngược lại `config.json` nếu field đó không có) — không phải điểm vào trực tiếp. Bản sửa ở mục 33 ưu tiên nhầm `llm_config.json` trước — sai thứ tự so với quy ước thật của MNN, dù cả 2 file đều tồn tại thật trong thư mục model (xác nhận qua ảnh chụp file explorer của người dùng: `config.json` 502B, `llm_config.json` 0,90kB). **Đã sửa**: đảo lại thứ tự — ưu tiên `config.json` trước, chỉ dùng `llm_config.json` làm dự phòng nếu không có `config.json`. **CHƯA build/test** — việc cần làm ngay phiên sau.

37. **[ĐANG NGHI NGỜ, ĐÃ ÁP DỤNG KHUYẾN NGHỊ CHÍNH THỨC MNN — 2026-07-29, tiếp tục mục 35] App crash ngay lập tức (không kịp ghi thêm log) ở lần đầu tiên `createLLM()` đọc đúng `config.json` thật, tham chiếu đầy đủ tới file weight thật.** Đây là lần đầu tiên xuyên suốt chuỗi debug mà code thực sự cố nạp dữ liệu nặng vào RAM (trước đó luôn đọc nhầm file, nên `load()` trả `false` gần như tức thì, không kịp chạm tới bước nạp weight thật). Máy test 16GB RAM (bổ sung vào mục 1, trước đây tài liệu chỉ ghi tên chip, thiếu RAM) — về lý thuyết đủ cho model 7B q4 (~4,85GB weight+embedding), nhưng RAM khả dụng thực tế tại thời điểm nạp có thể thấp hơn nhiều do hệ thống/app nền. Tra lại tài liệu chính thức MNN (đã đọc ở mục 35): có tuỳ chọn cấu hình `use_mmap` — "mặc định `false`, khuyến nghị bật `true` cho thiết bị di động" để tránh đúng kiểu OOM cấp phát 1 khối RAM liên tục lớn này. Code từ đầu dự án CHƯA từng bật tuỳ chọn này. **Đã sửa**: thêm `"use_mmap": true` vào JSON cấu hình gửi cho `set_config()` ở cả 3 backend (QNN/OpenCL/CPU), cả nhánh tự động lẫn ép buộc. **CHƯA build/test, CHƯA xác nhận đây có đúng là nguyên nhân hay không** — cần thử thêm cả model 1.5B nhỏ hơn (đã convert sẵn) để so sánh trước khi kết luận chắc chắn.

39. **[ĐANG DEBUG, ĐÃ THÊM CÔNG CỤ CHẨN ĐOÁN MỚI — 2026-07-29, tiếp tục mục 37] Xác nhận qua CI (`✅ CO use_mmap`, `✅ CO chot chan chong lenh`) rằng bản build ĐÚNG là mới nhất — loại bỏ hẳn nghi ngờ "test nhầm bản cũ".** Nhưng crash vẫn xảy ra y hệt ở CẢ model 7B lẫn 1.5B, đúng cùng 1 điểm (ngay sau log đường dẫn config, trước cả khi log "CHUAN BI goi Llm::createLLM()" — chỉ là 1 câu in chữ, không tính toán gì — kịp chạy). Vì model 1.5B không thể OOM trên máy 16GB, giả thuyết hết RAM (mục 37) gần như bị loại. Nghi ngờ mới: crash cứng thật (SIGSEGV hoặc bị hệ thống kill) xảy ra ngay trong `Llm::createLLM()` của thư viện MNN đã build sẵn — try/catch C++ không bắt được loại crash này. Thử dùng tính năng "Báo cáo lỗi" (bug report) của Android để lấy logcat thật nhưng không hoạt động trên máy người dùng (bấm không phản hồi). **Đã thêm**: bộ bắt tín hiệu crash (`signal handler`) tự viết trong `mnn_bridge.cpp` — bắt `SIGSEGV`/`SIGABRT`/`SIGBUS`/`SIGILL`/`SIGFPE`, tự ghi vào `native_debug.txt` bằng syscall thô (`open`/`write`/`close`, KHÔNG dùng `std::string`/cấp phát bộ nhớ động vì không an toàn trong ngữ cảnh signal handler thật) trước khi trả lại hành vi mặc định của hệ điều hành. Cài đặt 1 lần trong `nativeSetLogDir` (gọi sớm nhất lúc app khởi động).

40. **[CỘT MỐC LỚN NHẤT DỰ ÁN — 2026-07-30] LẦN ĐẦU TIÊN model local sinh ra văn bản thật thành công, kết thúc chuỗi debug từ mục 28.** Xác nhận qua log thật: `LlmContext status=1 (NORMAL_FINISHED)`, sinh ra 264 ký tự, `prompt_len=128`, `gen_seq_len=58`. Nguyên nhân cuối cùng: bộ bắt crash (mục 39) xác nhận **backend QNN crash cứng (`SIGSEGV`) mọi lúc, mọi model** ngay trong `llmSlot->load()`; **backend OpenCL (ép buộc, `backendPreference=1`) chạy được, không crash**. Kết luận: lỗi tích hợp QNN trên bản build này là thật, không liên quan gì tới toàn bộ chuỗi nguyên nhân đã sửa trước đó (đường dẫn config mục 33/35, quyền file, `use_mmap` mục 37...) — tất cả đều ĐÚNG và CẦN THIẾT, chỉ là QNN tự nó bị lỗi ở bước cuối cùng. **Việc cần làm tiếp**: đổi mặc định app dùng OpenCL thay vì thử QNN trước (tránh crash mỗi lần mở app), ghi nhận việc sửa QNN là backlog tối ưu sau, không phải chặn đường chính nữa. **Hiệu năng lần đầu rất chậm** (`decode_us=313505345` ~313 giây cho 58 token, `prefill_us=46756357` ~47 giây cho 128 token) — nghi ngờ hiện tượng "khởi động nguội" của OpenCL (GPU driver biên dịch kernel/shader lần đầu chạy), cần xác nhận qua lần sinh thứ 2 trong cùng phiên (không tải lại model) có nhanh hơn hẳn không. **Đã sửa thêm**: màu chữ phản hồi AI trong `chat_screen.dart` không tương phản với nền (chữ sáng mặc định theo theme tối đè lên nền `grey.shade100` sáng, gần như không đọc được) — đã chỉ định rõ `Colors.black87` cho khung AI và `onPrimaryContainer` cho khung người dùng.

42. **[PHÁT HIỆN QUAN TRỌNG — 2026-07-30] `GenerationService` (Foreground Service + WakeLock) chưa từng khai báo trong `AndroidManifest.xml`, khiến nó không có tác dụng thật từ đầu dự án.** Người dùng quan sát: khi tắt màn hình lúc đang sinh văn bản, đồng hồ đếm giây dừng hẳn, chạy tiếp khi bật màn hình lại — đúng hành vi Android đóng băng tiến trình khi không chạy đúng Foreground Service. Kiểm tra lại: `GenerationService.kt` viết đúng (start/stop/WakeLock `PARTIAL_WAKE_LOCK`), gọi đúng từ `MnnBridge.kt`, nhưng **`build.yml` chưa từng thêm bước khai báo `<service>` trong Manifest**, cũng thiếu quyền `FOREGROUND_SERVICE`/`WAKE_LOCK`. Với `compileSdk 35` (Android 15), thiếu `android:foregroundServiceType` trên khai báo `<service>` khiến `startForegroundService()` ném lỗi ngay khi gọi — rất có thể bị nuốt bởi try/catch bọc quanh (`MnnBridge.kt` dòng 44), khiến app tiếp tục chạy nhưng KHÔNG có Foreground Service/WakeLock thật, dễ bị hệ thống đóng băng khi màn hình tắt. Đây cũng giải thích số liệu `prefill_us` tăng bất thường (46,8s → 68,9s → 708,4s) qua các lần sinh trong log — nhiều khả năng không phải GPU chậm dần, mà là thời gian đóng băng khi màn hình tắt bị tính lẫn vào đồng hồ đo (`chrono` đo theo giờ tường, không phân biệt được lúc tiến trình bị đóng băng). **Đã sửa**: thêm bước vào `build.yml` khai báo `<service android:name="com.localnovel.mnnbridge.GenerationService" android:foregroundServiceType="dataSync" .../>` + 3 quyền còn thiếu. **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, thử sinh văn bản dài, tắt màn hình giữa chừng, xác nhận đồng hồ vẫn chạy tiếp (không đóng băng) và thời gian đo được ổn định qua nhiều lần, không tăng bất thường nữa.

43. **[BACKLOG, CHƯA ĐỦ BẰNG CHỨNG ĐỂ SỬA NGAY — 2026-07-30] Yêu cầu ép chạy QNN (NPU) thay vì OpenCL (GPU) để tăng tốc — theo kinh nghiệm người dùng, NPU thường nhanh hơn GPU tới 10 lần (dẫn chứng từ Stable Diffusion 1.5).** Về nguyên tắc, đúng — NPU thường nhanh và tiết kiệm điện hơn GPU nhiều cho suy luận LLM. Nhưng hiện tại **QNN đang crash cứng thật (`SIGSEGV`, xác nhận qua bộ bắt crash mục 39)** ngay trong `llmSlot->load()`, không phải vấn đề tốc độ — cần sửa được lỗi crash đó trước khi bàn tới việc "ép dùng". Chưa đủ bằng chứng để xác định chính xác nguyên nhân crash (cần bản backtrace symbolized thật, ví dụ qua `ndk-stack`/`addr2line` đối chiếu file `.so` debug, hiện chưa có công cụ này trong quy trình) — có thể do phiên bản QNN SDK 2.40.0 Community không khớp hoàn toàn driver Hexagon 780 thật trên Snapdragon 888, hoặc lỗi cấu hình graph riêng cho model 7B q4. Không nên tiếp tục đầu tư thời gian vào việc này trước khi mục 42 (Foreground Service) được xác nhận sửa xong, vì đó là vấn đề ảnh hưởng rộng hơn (mọi backend), còn QNN chỉ ảnh hưởng riêng tốc độ.

44. **[SỬA XONG — 2026-07-30] Chat không hiện chữ dần, phải đợi sinh xong hết mới thấy — người dùng phát hiện đúng.** Tầng Dart (`local_provider.dart`, `chat_screen.dart`) đã viết đúng cơ chế hiển thị từng chữ (`await for (chunk in stream) setState(() => reply.text += chunk)`), nhưng tầng C++ (`mnn_bridge.cpp`) trước đây gọi `llm->response(promptStr, &fullOutput, ...)` với `fullOutput` là 1 `std::ostringstream` THƯỜNG — chỉ gom chữ vào bộ nhớ, không đẩy ra JNI cho tới khi `response()` hoàn toàn kết thúc, rồi mới gọi `CallVoidMethod` đúng 1 lần duy nhất với toàn bộ văn bản. Trong khi đó, MNN nội bộ THẬT SỰ ghi (`operator<<`) vào đúng `ostream` được truyền vào ngay mỗi khi sinh xong 1 đoạn — chỉ là code chưa "nghe" được thời điểm đó. **Đã sửa**: viết lớp `JniStreamingBuf` kế thừa `std::streambuf`, chặn đúng điểm MNN ghi chữ vào (`xsputn`/`overflow`), gọi `CallVoidMethod` (JNI_FALSE, "chưa xong") ngay lập tức mỗi lần MNN ghi 1 đoạn, thay vì gom hết. Sau khi `response()` trả về, chỉ gửi thêm 1 tín hiệu rỗng kèm JNI_TRUE để báo "xong" (không gửi lại toàn bộ văn bản, vì Dart đã có sẵn cơ chế bỏ qua token rỗng, chỉ dùng cờ `done` để đóng stream — không cần sửa gì ở tầng Dart). **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, xác nhận chữ hiện dần từng đoạn khi chat, không còn đợi sinh xong hết mới thấy.

46. **[THAM KHẢO MNN CHAT CHÍNH THỨC — 2026-07-30, tiếp tục mục 43] Tìm được 2 khác biệt quan trọng giữa cách app này và MNN Chat (app chính thức Alibaba) xử lý QNN.** Đọc mã nguồn thật `apps/Android/MnnLlmChat/.../qnn/QnnModule.kt`: (1) MNN Chat nạp TƯỜNG MINH từng thư viện QNN bằng `System.load()` với đường dẫn tuyệt đối, đúng thứ tự, TRƯỚC khi gọi `Llm.createLLM()` — tài liệu ghi rõ "QNN libraries phải được nạp trước khi gọi createLLM để đăng ký backend đúng cách"; app này trước giờ chỉ đặt file `.so` vào `jniLibs/` và để Android tự nạp theo cơ chế JNI thông thường, không đảm bảo đúng thời điểm. (2) MNN Chat thiết lập 2 biến môi trường `ADSP_LIBRARY_PATH` và `LD_LIBRARY_PATH` trỏ đúng thư mục chứa file `.so`, để runtime RPC của Hexagon DSP tìm thấy thư viện skeleton/stub khi giao tiếp với NPU thật — app này **chưa từng thiết lập 2 biến này**. Ngoài ra phát hiện **thiếu hẳn 1 file `libQnnSystem.so`** ("thư viện giao diện quản lý backend QNN") trong danh sách 5 thành phần bắt buộc mà MNN Chat liệt kê — `build.yml` trước giờ chỉ copy 4/5 file. Xác nhận Snapdragon 888 (SM8350) đúng là Hexagon V68 theo bảng chính thức, khớp với `HEXAGON_ARCH="68"` đã dùng — không phải nguyên nhân. **Đã sửa**: thêm bước copy `libQnnSystem.so` vào `build.yml`; thêm hàm `setupQnnEnvironmentOnce()` trong `MnnBridge.kt` — thiết lập 2 biến môi trường qua `Os.setenv()` + nạp tường minh 5 thư viện QNN bằng `System.load()` đường dẫn tuyệt đối theo đúng thứ tự MNN Chat dùng, gọi đúng 1 lần trước khi thử QNN lần đầu. **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, đổi backend về "Tự động (QNN trước)", thử chat, xem QNN có còn crash không; nếu vẫn crash, đọc thêm `si_addr`/backtrace (mục 39 nâng cấp) để biết chính xác vị trí lỗi còn lại.

47. **[BACKLOG — đã bàn kỹ, CHỦ ĐỘNG HOÃN lại sau khi xong mục 28/33/35/37/39/40/42/44] Provider "GPU ngoài" (mượn/thuê GPU người khác, vd qua Colab) + lớp ẩn danh hoá thực thể.** Bối cảnh: người dùng muốn thêm 1 `AIProvider` mới gọi tới model chạy trên GPU không thuộc sở hữu mình (Colab free hoặc GPU thuê), với yêu cầu bảo mật cao nhất có thể đạt được thật (không phải ảo tưởng "tuyệt đối"). Đã thống nhất kiến trúc phòng thủ theo lớp, KHÔNG làm tới khi mục 28 xong (ưu tiên có model local chạy ổn định trước, giảm phụ thuộc GPU ngoài):
    - **Lớp 1 (ưu tiên cao nhất khi quay lại, rẻ nhất)**: ẩn danh hoá thực thể — thay tên nhân vật/địa danh/thuật ngữ riêng (đọc từ `Character`/`WorldRule`/`GlossaryTerm` có sẵn trong Story Bible) bằng placeholder trước khi gửi, map ngược khi nhận về. Chạy hoàn toàn ở Dart, không tốn hiệu năng GPU.
    - **Lớp 2**: không định danh người gửi (token phiên ngẫu nhiên, tài khoản Google phụ tách biệt khỏi tài khoản chính khi dùng Colab).
    - **Lớp 3**: rải yêu cầu qua nhiều provider/phiên khác nhau theo thời gian (kiến trúc `ApiProviderEntry` đã hỗ trợ sẵn nhiều provider) — không để 1 nơi tích luỹ toàn bộ 1 tác phẩm.
    - **Lớp 4**: không giữ Colab runtime chạy 24/7, không log phía server tự viết.
    - **Lớp 5**: TLS/HTTPS qua Cloudflare Tunnel hoặc ngrok (đã có sẵn theo yêu cầu ban đầu).
    - **Giới hạn đã thống nhất, KHÔNG được quên khi làm**: không lớp nào ở trên ngăn được chủ hạ tầng vật lý (Google/chủ GPU thuê) đọc plaintext nếu họ có quyền hypervisor — mức bảo vệ thật duy nhất cho việc đó là GPU Confidential Computing (NVIDIA H100/H200 CC, có ở 1 số gói GPU thuê riêng trả phí như Azure NCC H100 v5, KHÔNG có ở Colab miễn phí), chấp nhận ~5-15% chậm hơn. UI thêm provider "GPU ngoài" phải hiển thị rõ giới hạn này, không được quảng cáo là "an toàn tuyệt đối".
    - Việc cần code khi quay lại: module ẩn danh hoá 2 chiều (Dart) + `TrustedRemoteGpuProvider` (kế thừa `OpenAICompatibleProvider`) + khối cảnh báo rõ trong UI màn thêm provider.

48. **[SỬA XONG — 2026-07-31, tiếp tục mục 43] Bug nút "+" ở `story_bible_screen.dart` luôn mở "Nhân vật mới" bất kể đang ở tab nào (Nhân vật/Luật thế giới/Văn phong/Thuật ngữ) — xác nhận qua 3 ảnh chụp màn hình giống hệt nhau.** Nguyên nhân: `Builder(builder: (context) { final tabIndex = DefaultTabController.of(context).index; ... })` — `Builder` không tự động lắng nghe `TabController`; đọc `.index` bên trong nó chỉ lấy đúng giá trị tại lần build ĐẦU TIÊN của toàn màn hình, vuốt/chạm đổi tab sau đó KHÔNG kích hoạt build lại FAB (vì `TabController.index` đổi qua `notifyListeners()`, không qua cơ chế InheritedWidget rebuild thông thường). **Đã sửa (lần 1, có bug — xem mục 49)**: đổi `Builder` thành `AnimatedBuilder(animation: DefaultTabController.of(context), builder: ...)`.

49. **[BUG DO CHÍNH PHIÊN NÀY GÂY RA, ĐÃ SỬA TRIỆT ĐỂ CÙNG NGÀY — 2026-07-31] Bản sửa mục 48 làm toàn bộ tab "Bách khoa" hiện MÀN HÌNH TRẮNG XOÁ** (xác nhận qua ảnh chụp màn hình thật của người dùng — chỉ còn thanh điều hướng dưới, không còn AppBar/TabBar/nội dung/FAB nào). **Nguyên nhân**: `DefaultTabController.of(context)` đặt ở vị trí tham số `animation:` của `AnimatedBuilder` được tính TOÁN NGAY LẬP TỨC bằng `context` CỦA CHÍNH `build()` hàm này — context đó nằm ở vị trí TRÊN `DefaultTabController` trong cây widget thật sự dựng ra (vì `DefaultTabController` chính là widget được TRẢ VỀ bởi lời gọi `build()` này), không phải context nằm DƯỚI nó — nên `.of(context)` luôn thất bại ngay khi build, ném lỗi khiến build() không trả về được gì, và ở bản release Flutter ẩn traceback lỗi, chỉ hiện màn hình trắng/xám trơn thay vì "red screen of death" như bản debug. Đây chính xác là lý do bản gốc dùng `Builder` (không phải quên làm reactive) — `Builder` tạo ra 1 context MỚI, đúng vị trí bên dưới `DefaultTabController` một khi đã mount. **Đã sửa triệt để**: bỏ hẳn `DefaultTabController` khỏi cây widget, cho `_StoryBibleScreenState` (đã có sẵn `SingleTickerProviderStateMixin`) tự sở hữu 1 `TabController` riêng (`late final TabController _tabController`, khởi tạo ở `initState()`, `dispose()` đúng cách), gán trực tiếp vào `TabBar(controller: _tabController)`/`TabBarView(controller: _tabController)`, và FAB dùng thẳng `AnimatedBuilder(animation: _tabController, builder: (context, _) { final tabIndex = _tabController.index; ... })` — không còn `.of(context)` ở đâu trong màn hình này nữa, loại bỏ hẳn cả nhóm lỗi định phạm vi context (context scoping) liên quan tới `InheritedWidget`. **Bài học lớn**: khi 1 sửa lỗi cần đọc giá trị từ `XxxController.of(context)` bên trong 1 vị trí không phải `build(BuildContext context)` trực tiếp (ví dụ tham số của 1 widget con), phải kiểm tra kỹ CONTEXT NÀO đang được dùng có thực sự nằm DƯỚI ancestor widget cần tìm trong cây ĐàDỰNG hay không — nếu nghi ngờ, cách an toàn nhất luôn là cho `State` tự sở hữu `Controller` riêng thay vì phụ thuộc `Default*Controller.of(context)`.

50. **[SỬA XONG — 2026-07-31] `setState()` không kiểm tra `mounted` sau khi `await` AI sinh văn bản dài (30 giây tới vài phút) trong `chapter_editor_screen.dart` — lặp lại y hệt ở 4 hàm: `_continueWithAI`, `_fleshOutOutline`, `_checkConsistency`, `_applyRewrite`.** Người dùng báo "tạo chương thì cũng dễ bị văng" — đúng nguyên nhân: nếu thoát màn hình (back/chuyển tab) trong lúc đang chờ AI, khi tác vụ hoàn tất và gọi `setState()` trên 1 `State` đã bị huỷ (`dispose()`), Flutter ném `setState() called after dispose()`, crash. **Đã sửa**: thêm `if (!mounted) return;`/`if (mounted) {...}` bao quanh MỌI `setState()` xảy ra sau 1 điểm `await` trong cả 4 hàm trên, bao gồm cả nhánh `finally` (dùng để tắt cờ `generating`/`fleshingOut`/`checking`/`rewriting`).

51. **[SỬA XONG — 2026-07-31] `rag_service.dart` — model tự bịa ra nội dung Story Bible giả khi Story Bible thực tế đang TRỐNG.** Người dùng báo hiện tượng model trả lời như đã có sẵn 1 bộ Story Bible chi tiết (thế giới ma thuật, nhân vật chính...) dù mới gõ "alo", nghi ngờ spyware/bộ lọc ẩn — **xác nhận không phải**, là hallucination thuần tuý do lỗi prompt: `buildContext()` trả về chuỗi RỖNG khi chưa có luật thế giới/nhân vật/chương nào, nhưng `buildSystemPrompt()` vẫn viết cứng "Dưới đây là dữ liệu Story Bible... [để trống]... tham chiếu đúng Story Bible" — ra lệnh model tham chiếu 1 thứ không tồn tại, model 7B (đặc biệt bản "uncensored") chọn cách tự dựng nội dung cho hợp lý thay vì báo "không có dữ liệu". **Đã sửa**: khi context rỗng, đổi hẳn nội dung — nói thẳng "Story Bible hiện đang trống, TUYỆT ĐỐI KHÔNG được tự bịa", áp dụng cho cả `buildSystemPrompt()` (chat) và `buildConsistencyCheckPrompt()` (kiểm tra mâu thuẫn chương).

52. **[XÁC NHẬN QUAN TRỌNG NHẤT VỀ QNN, KẾT THÚC ĐIỀU TRA TỪ MỤC 43/46 — 2026-07-31] QNN crash SIGSEGV không phải lỗi packaging/config có thể vá bằng code — máy test nằm DƯỚI mức phần cứng tối thiểu mà chính Qualcomm công bố cho LLM-trên-NPU.** Tra cứu tài liệu chính thức Qualcomm AI Hub Models/Genie (công cụ LLM-trên-NPU trưởng thành nhất, do chính Qualcomm phát triển): yêu cầu tối thiểu **Hexagon architecture v73**. Snapdragon 888 dùng Hexagon 780 = **v68** (xác nhận qua Wikipedia + bảng ánh xạ kiến trúc Qualcomm) — thấp hơn 2 thế hệ (v73 ứng với Snapdragon 8 Gen 2 trở lên). RAM 16GB của máy dư thừa theo yêu cầu Qualcomm nêu cho model 7B — cái thiếu KHÔNG phải RAM, mà là thế hệ NPU. Giải thích hợp lý cho toàn bộ chuỗi crash: LLM có KV-cache đổi hình dạng đồ thị (shape) liên tục qua từng token, đòi hỏi QNN compiler (vốn biên dịch đồ thị TĨNH offline) phải tách thành hàng chục đồ thị con cố định — hỗ trợ attention/RoPE trên HTP mới được bổ sung ở các thế hệ Hexagon gần đây hơn hẳn hỗ trợ tích chập (convolution — thứ NPU đời cũ như v68 đã làm tốt từ lâu, giải thích vì sao NPU chạy Stable Diffusion 1.5 — đồ thị tĩnh, không đổi hình dạng — chạy tốt trên cùng máy này). Model dùng trong app (kể cả tự convert bằng `LocalNovel_Convert_Model_To_MNN.ipynb`) cũng CHƯA từng qua bước biên dịch riêng cho QNN (`generate_llm_qnn.py` + build cờ `-DMNN_QNN_CONVERT_MODE=ON`, cần QNN SDK trên máy tính) — càng củng cố kết luận trên. **Quyết định đã thống nhất với người dùng**: chấp nhận GPU (OpenCL) làm đường chính, tối ưu hết mức (mục 5.54); QNN chuyển hẳn thành lựa chọn thử nghiệm CÓ THỂ BẬT THỦ CÔNG, không xoá code (`backendPreference=3`), dành cho trường hợp đổi sang máy chip mới hơn (Snapdragon 8 Gen 2+) sau này.

53. **[NÂNG CẤP CƠ CHẾ AN TOÀN CHO QNN — 2026-07-31, thay thế mục 39 khi backendPreference=3 được bật] `sigsetjmp`/`siglongjmp` chỉ bắt được crash TỨC THỜI (SIGSEGV ngay lập tức), KHÔNG bắt được TREO VÔ HẠN.** Ảnh chụp màn hình thật cho thấy có lần "Đang chạy... 6545s" (~109 phút)/"1925s" (~32 phút) KHÔNG hề crash, chỉ đứng im không ra chữ — rất có thể QNN đang chờ phản hồi từ Hexagon DSP qua FastRPC mà không bao giờ trả lời, không phải signal nào cả. **Đã thay** cơ chế bắt crash bằng cách ly tiến trình con (`fork()` + `pipe()` + `poll()` với timeout 90 giây): tiến trình con thử `Llm::createLLM()` + `load()` backend QNN thuần C++ (không đụng JNI/JVM sau `fork()` — an toàn); tiến trình cha chờ kết quả có giới hạn thời gian bằng `poll()`, nếu tiến trình con CRASH (bắt qua `waitpid`) hoặc TREO quá 90s (chủ động `SIGKILL`), tiến trình cha (app thật) không hề bị ảnh hưởng, rơi xuống OpenCL ngay. Nếu probe báo thành công, tiến trình cha tự load lại QNN thật (không dùng chung bộ nhớ giữa 2 tiến trình được). Cơ chế này giờ chỉ chạy khi `backendPreference=3` (xem mục 52).

54. **[SỬA XONG — 2026-07-31, theo quyết định mục 52] Tối ưu tốc độ GPU thật sự theo đúng khuyến nghị chính thức MNN — trước đây thiếu hoàn toàn.** Config OpenCL cũ chỉ có `backend_type` + `use_mmap`, thiếu 3 tham số tài liệu MNN khuyến nghị rõ ràng để tăng tốc: `"precision": "low"` (ưu tiên fp16, nhanh hơn trên GPU di động Adreno), `"memory": "low"` (bật lượng tử hoá runtime, giảm băng thông bộ nhớ — nút thắt cổ chai lớn nhất khi chạy LLM trên GPU di động, không phải tốc độ tính toán thuần), `"thread_num": 68` (giá trị cụ thể tài liệu MNN chỉ định riêng cho suy luận OpenCL). Thêm `"tmp_path"` trỏ vào cache dir riêng của app (JNI mới `nativeSetCacheDir`, dùng `context.cacheDir` bên Kotlin) — MNN OpenCL tự lưu cache kết quả autotuning kernel vào đây, các lần load SAU tái sử dụng cache thay vì dò lại từ đầu mỗi lần mở model. Cập nhật UI `local_optimization_screen.dart`: nhãn "Tự động (QNN trước)" → "Tự động (GPU tối ưu)", thêm lựa chọn thứ 4 "Thử QNN (thử nghiệm)" ứng với `backendPreference=3`.

55. **[SỬA XONG — 2026-07-31] Xử lý tài liệu (dịch/tóm tắt) thiếu 2 việc: không có UI chỉnh prompt, và không thể tiếp tục dở dang nếu văng giữa chừng.** `DocumentService.processDocument()` đã có sẵn tham số `customInstruction` từ đầu nhưng CHƯA từng có UI nào truyền vào — người dùng phát hiện đúng. **Đã sửa**: thêm hộp thoại chỉnh prompt trước khi chạy (`_askCustomPrompt`) trong `document_screen.dart`, hiện sẵn prompt mặc định để người dùng biết đang dùng gì. Đồng thời `processDocument()` trước đây LUÔN xử lý lại từ đoạn đầu tiên kể cả đoạn đã có kết quả — với tài liệu dài (dễ dính lỗi native khi `generate()`, phần này KHÔNG được cách ly như bước `loadModel` ở mục 53), văng giữa chừng mất hết tiến độ. **Đã sửa**: thêm `resumeFromProgress` (mặc định `true`) — bỏ qua đoạn đã có `resultText`, chỉ xử lý tiếp đoạn còn thiếu.

56. **[SỬA XONG — 2026-07-31] Android 13+ "vuốt back dự đoán" (predictive back gesture) có thể thoát màn hình ngay giữa lúc AI đang chạy (tạo chương/dịch/tóm tắt), làm mất kết quả đang chờ dù mounted-guard (mục 50) đã tránh được crash.** Chưa xác định được cơ chế kỹ thuật chính xác 100% vì không có máy thật để dựng lại (nghi ngờ liên quan tới cách Flutter/Android 13+ xử lý cử chỉ back mới nếu app chưa khai báo rõ ràng qua `PopScope`), nhưng đây là hành vi Flutter khuyến nghị xử lý rõ ràng bằng `PopScope` (thay thế `WillPopScope` cũ) khi có tác vụ quan trọng đang chạy — dự án dùng Dart SDK `>=3.3.0` nên `PopScope` có sẵn. **Đã thêm**: `PopScope(canPop: !busy, onPopInvokedWithPop: ...)` bọc `Scaffold` trong cả `chapter_editor_screen.dart` (biến `busy` gộp sẵn 4 cờ `generating/fleshingOut/checking/rewriting`) và `document_screen.dart` (cờ mới `_processingDoc`) — chặn back trong lúc đang chạy, hiện rõ SnackBar giải thích + nút "Huỷ & thoát" để người dùng chủ động quyết định thay vì bị thoát âm thầm. **CHƯA build/test thật trên máy** — việc cần làm ở phiên sau: xác nhận vuốt back trong lúc đang chạy AI bị chặn đúng như mong đợi, không còn mất tiến độ.

57. **[TÍNH NĂNG MỚI, CHƯA build/test — 2026-07-31] Tìm kiếm web — bật/tắt THỦ CÔNG theo yêu cầu rõ ràng của người dùng ("không nhất thiết lúc nào cũng tìm kiếm mạng, khi nào cần thì mới bật").** Thêm `lib/services/web_search_service.dart` — gọi endpoint HTML rút gọn của DuckDuckGo (`html.duckduckgo.com/html/`, KHÔNG cần đăng ký API key), parse bằng package `html` (mới thêm vào `pubspec.yaml`) qua CSS selector cố định (`.result__body`, `.result__title`, `.result__snippet`) — có rủi ro DuckDuckGo đổi cấu trúc trang làm hỏng việc trích xuất, khi đó trả về danh sách rỗng và báo rõ cho người dùng thay vì crash/im lặng. Thêm nút bật/tắt (icon địa cầu) trong `chat_screen.dart` cạnh nút đính kèm tài liệu — mặc định TẮT, chỉ áp dụng cho phiên chat hiện tại (không lưu lại), khi bật hiện rõ giai đoạn "🔍 Đang tìm kiếm web..." trước khi tiếp tục sinh văn bản như bình thường. **Cân nhắc bảo mật/quyền hạn CHƯA xác nhận**: `AndroidManifest.xml` không nằm trong repo (được `flutter create` tự sinh trong `build.yml`), nên KHÔNG xác nhận được chắc chắn quyền `INTERNET` đã có sẵn hay chưa — suy luận hợp lý là CÓ (vì `AnthropicProvider`/`OpenAICompatibleProvider` đã dùng `http` package gọi mạng từ trước), nhưng cần xác nhận thật khi build/test lần đầu tính năng này. **Việc cần làm ở phiên sau**: build lại, bật thử tìm kiếm web trong chat, xác nhận có kết quả trả về thật (không lỗi mạng/quyền), và tinh chỉnh CSS selector nếu DuckDuckGo đã đổi cấu trúc HTML.

58. **[ĐÃ SỬA, CHƯA build/test — 2026-07-31] `build.yml` từng để các bước `cp` file QNN thất bại ÂM THẦM (`|| echo "THIẾU..."` không dừng build), có thể tạo ra APK "build thành công" nhưng thiếu hẳn file QNN mà không ai biết cho tới khi cài lên máy thật.** Dù QNN giờ không còn trên đường mặc định (mục 52), vẫn cần đúng cho `backendPreference=3` (thử nghiệm) hoạt động nếu người dùng chọn dùng. **Đã sửa**: mọi lệnh `cp` file QNN giờ DỪNG BUILD NGAY nếu thất bại (`|| { echo ...; exit 1; }`), và thêm bước xác minh CUỐI CÙNG ngay trên chính file APK (`unzip` thật, kiểm tra `lib/arm64-v8a/` có đủ 5 file QNN + `libmnn_bridge.so` không) trước khi upload artifact — không còn tin tưởng mù quáng vào "copy vào jniLibs xong là chắc chắn có trong APK".

59. **[SỬA XONG, ĐÃ XÁC NHẬN QUA LOG BUILD THẬT — 2026-07-31] Lỗi biên dịch Dart ở mục 56 (`PopScope`): dùng sai tên tham số `onPopInvokedWithPop` (không tồn tại — tự bịa nhầm tên).** Log build APK #67 báo lỗi rõ ràng ở cả 2 file `chapter_editor_screen.dart:642` và `document_screen.dart:234`: `Error: No named parameter with the name 'onPopInvokedWithPop'`. Tra cứu API `PopScope` thật của Flutter (bản pin trong CI là `stable-3.44.7`): tham số đúng là **`onPopInvokedWithResult`**, nhận `(bool didPop, Object? result)` — không phải `(bool didPop)` như đã viết nhầm. Lịch sử API: `onPopInvoked` (cũ, `(bool didPop)`) → deprecated từ Flutter 3.22 → thay bằng `onPopInvokedWithResult` (thêm tham số `result` kiểu generic). **Đã sửa** cả 2 chỗ dùng `onPopInvokedWithResult: (didPop, result) { ... }`. **Bài học**: khi dùng API Flutter có lịch sử đổi tên tham số qua nhiều phiên bản (như `PopScope`), phải tra cứu ĐÚNG PHIÊN BẢN Flutter đang pin trong `build.yml` (ở đây là `stable-3.44.7`) thay vì suy đoán tên tham số từ trí nhớ — nhất là khi có nhiều tên gần giống nhau dễ nhầm (`onPopInvoked`/`onPopInvokedWithResult`/tên bịa `onPopInvokedWithPop`).

61. **[SỬA XONG, CHƯA build/test — 2026-07-31] Cải tiến xử lý tài liệu dài (dịch/tóm tắt), theo 4 câu hỏi kiến trúc người dùng đặt ra — 3/4 điểm có lỗ hổng thật, đã sửa:**
    - **Thanh tiến trình**: trước chỉ có spinner tròn + chữ "d/t đoạn", giờ có `LinearProgressIndicator` hiện % thật.
    - **Chọn phạm vi đoạn**: trước LUÔN xử lý toàn bộ tài liệu, giờ có `RangeSlider` trong hộp thoại cấu hình (`_askProcessConfig`) cho chọn "từ đoạn __ đến đoạn __" — `processDocument()` nhận thêm `startIndex`/`endIndex` (0-based, dùng `sublist` trên danh sách đã `ORDER BY idx ASC` từ DB).
    - **Chạy nền khi tắt màn hình — LỖ HỔNG THẬT đã tìm ra và sửa**: `processDocument()` trước đây KHÔNG gọi `beginPipeline()`/`endPipeline()` (đã có sẵn từ trước, dùng cho `TranslationService`) — mỗi đoạn gọi `generate()` riêng lẻ tự bật/tắt Foreground Service ĐỘC LẬP (xem cơ chế ở mục 2.3 và `MnnBridge.kt`: `if (pipelineActive) updateStage else start`, rồi `if (!pipelineActive) stop` trong `finally`) — với tài liệu 100+ đoạn là 100+ lần bật/tắt liên tục, tạo khe hở giữa các đoạn có thể bị Android trừ tiến trình nếu tắt màn hình đúng lúc đó. **Đã sửa**: bọc cả vòng lặp nhiều đoạn bằng `LocalLlamaProvider.beginPipeline()`/`updatePipelineStage()`/`endPipeline()` (chỉ áp dụng khi `provider is LocalLlamaProvider` — cloud API không cần) — giữ 1 thông báo Foreground Service LIÊN TỤC suốt cả quá trình thay vì chớp tắt từng đoạn.
    - **Huỷ giữa chừng**: `resumeFromProgress` (mục 55) đã đảm bảo tiếp tục đúng chỗ dừng khi CHẠY LẠI, nhưng trước đây không có cách chủ động dừng SẠCH — chỉ có `PopScope` chặn back (mục 56). **Đã thêm**: nút "Huỷ" trong hộp thoại tiến trình, đặt cờ hợp tác (`isCancelled` callback) được `processDocument()` kiểm tra GIỮA MỖI đoạn (không ngắt dở đoạn đang chạy — không an toàn để huỷ nửa chừng 1 lệnh `generate()` đang gọi, chỉ có thể không bắt đầu đoạn kế tiếp).
    - **Xuất kết quả từng phần**: kiểm tra lại code — **đã hoạt động từ trước, không cần sửa**: `exportResult()` xử lý đoạn chưa có `resultText` bằng placeholder `[Chưa xử lý đoạn N]` thay vì chặn lại, nút "Xuất kết quả" trong UI luôn bật sẵn không phụ thuộc trạng thái xử lý.
    - **Việc cần làm ở phiên sau**: build/test thật cả 3 điểm đã sửa — đặc biệt xác nhận Foreground Service giữ được 1 thông báo liên tục (không chớp tắt) khi theo dõi qua thanh thông báo Android trong lúc xử lý tài liệu nhiều đoạn.

62. **[CRASH THẬT MỚI, KHÁC HẲN QNN, CHƯA CÓ CÁCH VÁ TRIỆT ĐỂ — 2026-08-01] SIGSEGV xảy ra ngay TRONG LÚC `nativeGenerate()` (không phải `nativeLoadModel()`) trên backend OpenCL (GPU) — xác nhận qua log thật kèm backtrace đầy đủ lần đầu tiên có symbol tên hàm rõ ràng của MNN.** Log cho thấy: model 1.5B (nhỏ hơn hẳn 7B, để loại trừ khả năng do model quá lớn) nạp OpenCL thành công, generate lần 1 (chat "alo", prompt ngắn) chạy xong không lỗi, nhưng generate lần 2 — **đúng lúc `DocumentService.processDocument()` dịch 1 đoạn tài liệu dài** (system prompt dịch thuật + đoạn văn gốc, tổng 3871 ký tự, dài hơn hẳn lần 1) — crash SIGSEGV tại địa chỉ `0x7031a8e000`. Backtrace (lần đầu có tên hàm rõ, không còn toàn "khong ro thieu symbol table" như các lần trước) cho thấy chuỗi gọi: `Java_..._nativeGenerate` → `Llm::response()` → `Llm::generate()` → `Llm::forwardVec()` → `Llm::forwardRaw()` → `MNN::Session::run()` → `MNN::ThreadPool::enqueue()` — tức là crash xảy ra **trên 1 luồng WORKER do MNN tự tạo ra để tính toán song song** (thấy rõ ở đáy backtrace: `art::Thread::CreateCallback` → `pthread_create`), không phải trên luồng chính gọi JNI. **Ý nghĩa quan trọng**: cơ chế cách ly tiến trình con (`fork()` + timeout, mục 53) CHỈ bọc bước `nativeLoadModel()` với QNN — KHÔNG bọc `nativeGenerate()` — nên loại crash này (xảy ra giữa lúc sinh văn bản, trên GPU/OpenCL — con đường vừa được xác nhận là "đường chính, đã tối ưu" ở mục 52/54) **hoàn toàn không được bảo vệ**, làm chết cả app ngay lập tức. **Nghi ngờ hàng đầu** (chưa xác nhận được, cần điều tra thêm nếu tái diễn): độ dài prompt lớn hơn hẳn (3871 ký tự so với 543 ký tự chạy được) có thể chạm vào 1 edge case về kích thước buffer/tensor trong `ThreadPool`/`Session::run()` của chính MNN — đây là lỗi NẰM TRONG chính thư viện MNN (`libMNN.so`), không phải trong code cầu nối (`libmnn_bridge.so`) của app, nên KHÔNG có cách vá trực tiếp từ phía app, chỉ có thể tránh/giảm thiểu.
    - **KHÔNG CÓ CÁCH cô lập crash loại này bằng kỹ thuật tương tự mục 53** (fork từng lần `generate()`) — vì phải fork() lại toàn bộ tiến trình cho MỖI LẦN sinh văn bản sẽ cực kỳ chậm (phải nạp lại model mỗi lần, mất hết lợi ích giữ model resident trong RAM), không khả thi cho việc dùng thực tế. Cách duy nhất triệt để là chuyển hẳn việc chạy MNN sang 1 **tiến trình Android riêng** (`android:process=":modelservice"` trong Manifest, giao tiếp qua AIDL/Binder) — 1 thay đổi kiến trúc lớn, CHƯA làm, cần cân nhắc kỹ ở phiên sau nếu loại crash này tái diễn thường xuyên.
    - **Đã làm ngay được (giảm thiệt hại, không phải sửa gốc)**: người dùng hỏi đúng trọng tâm "sao không có nút tiếp tục nhiệm vụ dang dở" — **thực ra ĐÃ CÓ SẴN** nhờ `resumeFromProgress` (mục 55/61: mỗi đoạn lưu `resultText` vào DB ngay khi xong, đoạn đang crash dở là đoạn DUY NHẤT mất, mọi đoạn trước đó vẫn giữ nguyên) — nhưng TRƯỚC ĐÂY không có gì hiển thị trên danh sách tài liệu để biết còn dở dang hay đã xong, dễ hiểu lầm phải bắt đầu lại từ đầu. **Đã sửa `document_screen.dart`**: `_load()` giờ đếm luôn số đoạn đã có `resultText` cho mỗi tài liệu (`_doneCounts`), danh sách hiện rõ nhãn "Dang dở: X/Y đoạn đã xong" hoặc dấu tick xanh nếu đã xong hết, và nút đổi nhãn động thành "Tiếp tục dịch (X/Y)"/"Tiếp tục tóm tắt (X/Y)" thay vì luôn ghi "Dịch toàn bộ"/"Tóm tắt" như chưa từng chạy. **CHƯA build/test thật.**

63. **[XÁC NHẬN CRASH MỤC 62 TÁI DIỄN — BẰNG CHỨNG THỨ 2, CÙNG PATTERN — 2026-08-01] Log lần 2 (model 7B lần này, không phải 1.5B) cho thấy CHÍNH XÁC cùng 1 kiểu crash: generate lần 1 (prompt 543 ký tự, chat "alo") chạy ổn, generate lần 2 (prompt 3832 ký tự, dịch tài liệu) crash SIGSEGV, backtrace đáy giống hệt mục 62 (`libMNN.so` các offset `0x3ce33c`/`0x3d0438`/`0x339c00` gần các offset lần trước, cùng nằm trong nhánh gọi từ `ThreadPool`/`libc pthread`).** Củng cố mạnh giả thuyết: **crash liên quan tới ĐỘ DÀI PROMPT** (luôn xảy ra ở lần generate có prompt dài ~3800+ ký tự, không phải do model 7B hay 1.5B — loại trừ hẳn khả năng do kích thước model) — rất có thể là 1 giới hạn/edge case cứng trong `MNN::ThreadPool`/`Session::run()` khi xử lý sequence length hoặc kích thước tensor vượt 1 ngưỡng nào đó trên backend OpenCL. **Quan sát phụ đáng chú ý (log lần 2)**: lần `loadModel` ĐẦU TIÊN trong phiên này thất bại hoàn toàn (`llmSlot->load() (OpenCL) TRA VE = FALSE` VÀ `llmSlot->load() (CPU) TRA VE = FALSE` — cả 2 backend cùng fail, không phải crash, chỉ trả về false) kèm cảnh báo `khong tim thay config.json — thu muc RONG` — rất giống hiện tượng đọc file trên storage ngoài (`/storage/emulated/0/Download/...`) chưa sẵn sàng ngay lúc app vừa khởi động (storage mount trễ hoặc quyền truy cập chưa cấp xong) — lần thử THỨ HAI (35s sau) mới đọc được `config.json` bình thường và load thành công. **Chưa đủ bằng chứng để kết luận chắc chắn, cần theo dõi thêm nếu tái diễn** — nếu lặp lại, có thể cần thêm bước "thử lại tự động sau vài giây" ở `ensureLoaded()` khi lần đầu thất bại ngay từ bước đọc `config.json`.
    - **Đã thêm màn hình MỚI theo yêu cầu người dùng: `document_chunks_screen.dart`** — thay vì chỉ chọn 1 khoảng liên tục (`RangeSlider`, mục 61), giờ có màn hình riêng cho từng tài liệu hiện DANH SÁCH TỪNG ĐOẠN cụ thể, mỗi đoạn có checkbox chọn RỜI RẠC (không bắt buộc liền kề), icon xanh/xám cho biết đã xong/chưa xong, xem trước 90 ký tự đầu + bấm vào xem toàn văn (gốc + kết quả) trong hộp thoại. Có nút chọn nhanh "Chọn tất cả"/"Chỉ chọn đoạn chưa xong"/"Bỏ chọn tất cả". Lý do trực tiếp: nếu xác định được đúng 1 đoạn cụ thể liên tục gây crash (mục 62/63), có thể BỎ QUA riêng đoạn đó, xử lý mọi đoạn khác trước, quay lại xử lý đoạn khó sau. **`processDocument()` thêm tham số `chunkIndices` (Set rời rạc, khác `startIndex`/`endIndex` liên tục)** — khi dùng chọn thủ công, LUÔN xử lý lại các đoạn được chọn (bỏ qua `resumeFromProgress`, vì chọn lại thủ công nghĩa là chủ động muốn làm lại). Mở màn hình này qua nút "Chọn từng đoạn" mới thêm trên mỗi thẻ tài liệu trong `document_screen.dart`. **CHƯA build/test thật.**

64. **[PHÁT HIỆN NGHIÊM TRỌNG HƠN HẲN MỤC 62/63 — CRASH LÀM HỎNG TRẠNG THÁI NỘI BỘ, LAN SANG MỌI ĐOẠN SAU — 2026-08-01] Đọc kỹ log thứ 3 (cùng pattern SIGSEGV lúc dịch tài liệu) phát hiện: đây KHÔNG chỉ là 1 crash đơn lẻ mất 1 đoạn — mà là 1 chuỗi hỏng hóc lan rộng, kết thúc bằng SIGABRT làm chết hẳn app.** Trình tự chính xác quan sát được:
    - Đoạn 1: `llm->response()` "chạy xong không crash" nhưng chỉ trả về **17 ký tự** cho 1 đoạn văn 800+ ký tự nguồn, mất 12.8 giây, `LlmContext` báo `status=4, gen_seq_len=3` (chỉ sinh đúng 3 token!) — kết quả này **VẪN ĐƯỢC LƯU vào DB và đánh dấu "đã xong"** (dấu tick xanh) dù rõ ràng là rác (người dùng xác nhận qua ảnh chụp: nội dung lưu là `"dan生态环境"` — lẫn cả chữ Hán, hoàn toàn không phải bản dịch tiếng Việt của đoạn văn gốc).
    - **NGAY SAU ĐÓ**: SIGSEGV tại địa chỉ `0x0` (null pointer) — signal handler bắt được, log lại, nhưng **process KHÔNG chết ngay** (khác với các lần trước) — điều này cho thấy signal xảy ra trên 1 luồng phụ (ThreadPool worker, giống mục 62) và vì lý do nào đó (cơ chế signal chain của ART, hoặc timing) không lập tức kết liễu tiến trình chính.
    - **11 đoạn tiếp theo**: mỗi đoạn `generate()` "chạy xong không crash" nhưng **hoàn thành trong ĐÚNG 0ms** (không phải suy luận thật), kết quả **RỖNG HOÀN TOÀN**, và **`LlmContext` báo CHÍNH XÁC `status=4, prompt_len=848, gen_seq_len=3` GIỐNG HỆT NHAU cho mọi đoạn** dù `prompt_len` thật in ra ngay phía trên mỗi lần đều KHÁC NHAU (3998, 3660, 3991, 3995, 3692, 4023, 3973, 3953, 3851, 3901, 4014 ký tự) — bằng chứng rõ ràng: đối tượng `Llm`/`Session` phía native đã **hỏng bộ nhớ (heap corruption)** ngay sau lần SIGSEGV đầu tiên, các lệnh gọi sau đó không còn thực hiện suy luận thật nữa, chỉ trả về ngay lập tức 1 trạng thái "xác chết" đã lưu sẵn từ trước lúc hỏng.
    - **Cuối cùng**: SIGABRT (signal 6) — backtrace cho thấy `abort()` → `art::Runtime::Abort` → `android::base::LogMessage` — đây là **chữ ký điển hình của bộ dò lỗi bộ nhớ của Android** (Scudo/hardened allocator) bắt được tham nhũng heap tích lũy từ trước và chủ động `abort()` để tránh hỏng nặng hơn — đây mới là nguyên nhân app **thật sự chết hẳn**, không phải SIGSEGV đầu tiên.
    - **Ý nghĩa quan trọng nhất**: các đoạn "đã xong" (dấu tick xanh) trong khoảng thời gian giữa lần SIGSEGV đầu và lúc app chết hẳn **ĐỀU LÀ RÁC**, không phải kết quả thật — nhưng UI trước đây (kể cả bản mới thêm dấu tick xanh ở mục 62) không có cách nào phân biệt được "xong thật" và "xong giả" — chỉ cần `resultText` không rỗng là hiện tick xanh, đúng như người dùng phát hiện qua ảnh chụp: "đoạn 1 đã xong, nhưng kết quả là cái gì vậy".
    - **Đã sửa `document_service.dart`**: thêm class `DocumentProcessingAnomalyException` — sau MỖI lần `generate()`, kiểm tra kết quả có "trông hợp lý" không (rỗng, HOẶC ngắn hơn 15% độ dài văn bản nguồn khi nguồn dài trên 50 ký tự) — nếu bất thường, **NÉM EXCEPTION NGAY, KHÔNG LƯU kết quả rác vào DB**, dừng hẳn vòng lặp xử lý nhiều đoạn tại đó thay vì chạy tiếp qua hàng chục đoạn khác cũng sẽ ra rác (vì trạng thái native đã hỏng). `document_screen.dart` và `document_chunks_screen.dart` đều đã cập nhật: gọi `_load()` ngay cả khi lỗi (để cập nhật đúng số đoạn ĐÃ THẬT SỰ xong trước khi gặp bất thường), hiện thông báo lỗi rõ ràng nêu đúng số đoạn gặp vấn đề, thời gian hiện lâu hơn (8 giây) để đọc kịp.
    - **CHƯA sửa được nguyên nhân gốc** (heap corruption bên trong `libMNN.so`) — đây vẫn là lỗi nằm trong chính thư viện MNN, ngoài khả năng vá từ phía app. Việc vừa làm chỉ NGĂN THIỆT HẠI LAN RỘNG (không lưu rác, dừng sớm) chứ không ngăn được crash gốc. **Nếu cần chặn triệt để, phương án duy nhất còn lại là chuyển MNN sang chạy ở 1 tiến trình Android riêng** (đã ghi ở mục 62) — chưa làm, cần cân nhắc mức độ ưu tiên ở phiên sau tuỳ tần suất tái diễn. **CHƯA build/test thật.**

65. **[LÀM RÕ KIẾN TRÚC + TỐI ƯU TỐC ĐỘ THẬT MỚI — 2026-08-01] Người dùng hỏi 2 việc: (a) tách MNN sang process riêng (mục 62) có giúp nhanh hơn không, (b) GGUF/llama.cpp có phải lựa chọn tốc độ tốt hơn không, công nghệ nào giảm thời gian chờ.**
    - **(a) Đã làm rõ, KHÔNG cần sửa code**: tách process CHỈ giúp cô lập crash (model lỗi không kéo chết cả app UI), **KHÔNG giúp nhanh hơn** — tốc độ do phần cứng GPU/CPU + thư viện MNN + cấu hình quyết định, không phụ thuộc process nào chạy nó. Thậm chí IPC/Binder giữa 2 process cộng thêm 1 chút overhead (dù nhỏ so với thời gian tính toán thật), nên tách process nếu làm có thể CHẬM HƠN chút ít, không nhanh hơn.
    - **(b) Tra cứu tài liệu chính thức `llama.cpp` (`docs/backend/OPENCL.md`)**: backend OpenCL cho Adreno chỉ liệt kê **đã kiểm chứng** trên Snapdragon 8 Gen 3/8 Elite (Adreno 750/830) — **KHÔNG có Adreno 660** (Snapdragon 888, máy test) trong danh sách. Vulkan trên Adreno được chính tài liệu cộng đồng ghi "có thể chậm nếu chưa vá driver". Kết luận: GGUF/llama.cpp **không chắc chắn nhanh hơn** trên đúng phần cứng này — cùng vùng chưa kiểm chứng như MNN, cần thử nghiệm thật (không phải sửa code ngay) mới biết, không phải giải pháp chắc ăn.
    - **Đã tìm và áp dụng công nghệ THẬT sự giúp giảm thời gian chờ**: tra cứu tài liệu chính thức `alibaba/MNN` (`transformers/README.md`) xác nhận tham số `reuse_kv` ("Whether to reuse the kv cache in multi-turn dialogues. Defaults to false") — đối chiếu thêm 1 issue GitHub thật của MNN dùng chính xác cấu hình này để xác nhận cú pháp đúng, tránh lặp lại sai lầm bịa tên tham số như mục 59. **Code cũ CHƯA hề dùng tham số này** — mỗi lượt chat phải tính lại KV-cache cho TOÀN BỘ system prompt + lịch sử từ đầu, dù phần lớn nội dung đó đã xử lý ở lượt trước.
    - **Đã sửa, luồng đầy đủ từ Dart xuống native**: thêm tham số `reuseKv` vào `AIProvider.generateStream()` (interface trừu tượng, mặc định `false`, 2 provider cloud nhận nhưng bỏ qua vì không có khái niệm tương đương) → `LocalLlamaProvider.generateStream()` truyền xuống qua `MethodChannel` (`'reuseKv': reuseKv`) → `MnnBridge.kt` đọc và đưa vào JSON config gửi cho `nativeGenerate()` (`put("reuse_kv", reuseKv)`) → không cần sửa gì ở tầng C++ vì `llm->set_config(configStr)` đã forward thẳng chuỗi JSON, MNN tự đọc key `reuse_kv`.
    - **Phạm vi bật CÓ CHỦ ĐÍCH, không bật tràn lan**: CHỈ bật `reuseKv: true` ở `chat_screen.dart` (hội thoại nhiều lượt thật sự, mỗi tin nhắn nối tiếp đúng nghĩa lượt trước). **Tắt (`false`, mặc định)** ở: `LocalLlamaProvider.generate()` — dùng cho từng đoạn tài liệu dịch/tóm tắt độc lập, tái dùng sai sẽ lẫn ngữ cảnh giữa các đoạn không liên quan; và "viết tiếp chương" (`chapter_editor_screen.dart`) — nội dung chương có thể bị người dùng sửa tự do giữa các lần gọi AI, phá vỡ giả định "tiền tố chung không đổi" mà `reuse_kv` cần để đúng.
    - **Lưu ý về phạm vi cải thiện**: `reuse_kv` CHỈ giúp lượt chat thứ 2 trở đi trong cùng phiên (không giúp lượt đầu tiên — chưa có gì để tái dùng). **CHƯA build/test thật.**

66. **[PHÁT HIỆN LỖ HỔNG THẬT TRONG `build.yml`, KHÔNG PHẢI TRONG CODE APP — 2026-08-02] Người dùng báo cáo: sau nhiều lần sửa, app bị hệ điều hành KILL khi đang chat chờ AI trả lời mà chuyển sang trình duyệt lướt web rồi quay lại — mất hẳn tiến trình, không phải chỉ mất kết nối.** Điều tra kỹ `build.yml` (không phải file Dart/Kotlin/C++ đã sửa nhiều lần trước đó) phát hiện 2 lỗ hổng thật, tồn tại TỪ TRƯỚC (không phải do các lần sửa gần đây gây ra — người dùng chỉ mới nhận ra/thử đúng kịch bản này lần đầu):
    - **Thiếu quyền `POST_NOTIFICATIONS` trong Manifest, dù `MainActivity.kt` ĐÃ CÓ SẴN code xin quyền này lúc chạy** (`ActivityCompat.requestPermissions`, thêm từ 1 phiên trước — comment cũ trong code còn ghi rõ). Thiếu khai báo `<uses-permission>` tương ứng trong Manifest khiến lệnh xin quyền runtime gần như vô tác dụng (Android không cho xin quyền ứng dụng chưa tự khai báo là mình cần). Thiếu quyền này, thông báo liên tục của Foreground Service có thể không hiển thị đúng cách — nhiều OEM (đặc biệt ASUS ZenUI, đúng máy test) dùng "có thông báo hiển thị hay không" làm 1 tiêu chí quyết định có bảo vệ tiến trình nền hay không.
    - **`foregroundServiceType="dataSync"` không đúng bản chất công việc** — tài liệu Android chính thức mô tả `dataSync` dành cho "upload/download dữ liệu... sẽ bị loại bỏ dần, nên cân nhắc thay thế", trong khi việc thực tế đang làm là **tính toán AI cục bộ**, không phải đồng bộ dữ liệu qua mạng. Loại đúng bản chất hơn là `specialUse` ("khi các loại khác không phù hợp với trường hợp sử dụng") — không bị giới hạn 6 giờ/24 giờ như `dataSync`/`mediaProcessing` trên Android 15+.
    - **Đã sửa `build.yml`**: thêm `<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>` khớp với code runtime đã có sẵn. Đổi `foregroundServiceType` từ `dataSync` sang `specialUse`, kèm bắt buộc thêm `<property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="local_on_device_ai_text_generation" />` bên trong thẻ `<service>` (tra cứu xác nhận qua nhiều nguồn độc lập — thiếu property này Android ném `SecurityException`/crash ngay khi gọi `startForeground()`), và thêm quyền tương ứng bắt buộc `<uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>` (khác hẳn quyền của `dataSync` — mỗi loại `foregroundServiceType` có quyền Manifest riêng, đây là điểm dễ quên nhất khi đổi loại).
    - **Đã tự kiểm tra**: `build.yml` sau khi sửa vẫn là YAML hợp lệ (parse bằng `pyyaml`), và đoạn code Python nhúng bên trong bước sửa Manifest vẫn biên dịch được (`compile()`) không lỗi cú pháp.
    - **CHƯA build/test thật** — đây là suy luận có căn cứ kỹ thuật vững (nhiều nguồn tài liệu Android độc lập xác nhận), nhưng KHÔNG chắc chắn 100% giải quyết dứt điểm triệu chứng "bị kill" — vẫn có khả năng liên quan tới trình quản lý pin đặc thù của ASUS ZenUI (cần người dùng tự thêm app vào danh sách loại trừ tối ưu hoá pin trong Cài đặt máy, việc này nằm ngoài khả năng sửa từ code). Việc cần làm ở phiên sau: build lại, lặp lại đúng kịch bản (chat chờ AI → chuyển trình duyệt → quay lại) xem còn bị kill không; nếu vẫn còn, hướng dẫn người dùng kiểm tra Cài đặt > Pin > tối ưu hoá pin cho từng ứng dụng, loại trừ LocalNovel.

67. **[PHÁT HIỆN QUAN TRỌNG NHẤT VỀ CRASH — RẤT CÓ THỂ LÀ LỜI GIẢI CHO TOÀN BỘ CHUỖI "HEAP CORRUPTION" BÍ ẨN Ở MỤC 62/63/64 — 2026-08-02] Đọc kỹ 1 log thật khác phát hiện bằng chứng trực tiếp: 2 LỆNH `generateStream` CHẠY ĐÈ LÊN NHAU TRÊN CÙNG 1 SLOT, không lệnh nào chờ lệnh kia xong.** Dòng thời gian chính xác trong log:
    - 04:24:48.374 (Dart): `generateStream` bắt đầu — chat, prompt 595 ký tự, slot 0.
    - Native: `nativeGenerate` bắt đầu, gọi `llm->response()`... — **KHÔNG có dòng "trả về xong" cho lệnh này** trước khi dòng tiếp theo xuất hiện.
    - 04:27:00.619 (Dart): `generateStream` bắt đầu LẦN 2 — nội dung khớp `RagService.buildConsistencyCheckPrompt()` (kiểm tra tính nhất quán chương, gọi từ `_checkConsistency()` trong `chapter_editor_screen.dart`), prompt 382 ký tự, **VẪN LÀ SLOT 0**.
    - Native: `nativeGenerate` bắt đầu LẦN 2, gọi `llm->response()` — **TRONG KHI LỆNH 1 VẪN ĐANG CHẠY DỞ**.
    - Ngay sau đó: **30 SIGSEGV liên tiếp**, địa chỉ lỗi khác nhau nhưng cùng 1 vùng bộ nhớ lân cận (`0x70c38...`) — đúng dấu hiệu 2 luồng cùng ghi/đọc chồng chéo lên cùng 1 vùng bộ nhớ chưa được bảo vệ.
    - **Nguyên nhân gốc xác nhận qua chính source code**: `nativeLoadModel()` đã có sẵn khoá chống gọi trùng (`g_loadingInProgress`, dùng `std::atomic::compare_exchange_strong`) — thêm từ rất sớm trong dự án. Nhưng **`nativeGenerate()` KHÔNG HỀ CÓ khoá tương tự** — bất kỳ số lượng lệnh `generate()` nào cũng có thể chạy đồng thời trên cùng 1 slot, không có gì ngăn cản. `Llm::response()` của MNN **không được thiết kế để gọi đồng thời từ nhiều luồng trên cùng 1 instance** (mutate chung KV-cache, buffer `ThreadPool`, tensor nội bộ) — khớp hoàn hảo với mọi triệu chứng "heap corruption" quan sát được trước đó (mục 62: SIGSEGV giữa `ThreadPool::enqueue`; mục 64: trạng thái hỏng lan sang các lệnh sau, kết thúc bằng SIGABRT).
    - **Kịch bản thực tế xảy ra**: người dùng đang chat (chờ AI trả lời) VÀ đồng thời (cùng lúc hoặc chuyển màn hình rất nhanh) bấm "Kiểm tra mâu thuẫn" ở màn hình soạn chương — cả 2 thao tác đều dùng slot 0 (model chính), không có gì ngăn chặn chạy song song.
    - **Đã sửa — 2 tầng phòng thủ**:
      1. **Tầng chính (Kotlin, `MnnBridge.kt`)**: thêm `Mutex` riêng cho từng slot (`generateMutexes`, dùng `kotlinx.coroutines.sync.Mutex`/`withLock`) — bọc quanh lệnh gọi `MnnNative.nativeGenerate()` thật. Lệnh generate() thứ 2 cho CÙNG slot giờ **CHỜ** (xếp hàng, không mất yêu cầu, không bị từ chối) cho tới khi lệnh trước xong hẳn mới chạy — slot 0 và slot 1 (nếu dùng model dịch riêng) vẫn chạy độc lập song song bình thường, đúng kiến trúc "2 slot" đã thiết kế.
      2. **Tầng dự phòng (C++, `mnn_bridge.cpp`)**: thêm `g_generatingInProgress[slot]` (tái dùng cấu trúc `LoadingGuard` RAII đã có sẵn cho `g_loadingInProgress`) — nếu vì lý do nào đó khoá Kotlin bị bỏ qua (lỗi tương lai, code path khác), lệnh generate thứ 2 bị **TỪ CHỐI NGAY LẬP TỨC** thay vì chạy song song và làm hỏng bộ nhớ — hàng phòng thủ thứ 2, trong điều kiện bình thường không bao giờ nên bị kích hoạt.
    - **Đã tự kiểm tra**: biên dịch cú pháp C++ sạch (`g++ -fsyntax-only` với header giả lập), kiểm tra ngoặc bằng stack-parser cho cả 2 file — không lỗi.
    - **CHƯA build/test thật.** Nếu đúng giả thuyết này, các crash "heap corruption" ở mục 62/63/64 (vốn nghi ngờ do độ dài prompt) rất có thể **không hề liên quan tới độ dài prompt** — mà do 2 tác vụ tình cờ chạy chồng chéo đúng lúc đó (document processing chạy nền + có tác vụ khác cũng gọi generate). Việc cần làm ở phiên sau: build lại, cố tình tái tạo kịch bản "vừa chat vừa bấm kiểm tra tính nhất quán chương cùng lúc" xem có còn crash không; nếu hết crash, xác nhận luôn giả thuyết gốc rễ cho mục 62/63/64 (không cần điều tra "độ dài prompt" hay "heap corruption trong MNN" nữa — vấn đề nằm ở app, không phải thư viện MNN).

68. **[LỖI DO CHÍNH MỤC 65 GÂY RA, ĐÃ TẮT LẠI — 2026-08-02] Người dùng báo cáo: câu chat THỨ 2 trong 1 phiên, model trả về chuỗi lặp vô nghĩa `"8888888"`.** Đây gần như chắc chắn là hậu quả trực tiếp của việc bật `reuseKv: true` cho chat ở mục 65 — dấu hiệu ("8888888", lặp 1 token liên tục) là triệu chứng kinh điển của lệch KV-cache/vị trí token trong các engine LLM, và đúng lúc xảy ra là lượt chat **THỨ 2** — lần ĐẦU TIÊN `reuse_kv` thực sự có gì đó từ lượt trước để "tái sử dụng" (lượt 1 luôn có cache rỗng nên không lộ lỗi). **Nguyên nhân kỹ thuật nghi ngờ nhiều nhất**: `local_provider.dart` luôn xây LẠI TOÀN BỘ prompt mỗi lượt (`'$systemPrompt\n\n$userPrompt'`), KHÔNG gửi kèm phần model đã TỰ SINH ra ở lượt trước — khi MNN cố tái sử dụng KV-cache của lượt trước (đã bao gồm cả phần tự sinh đó) mà prompt mới gửi vào lại không khớp đúng chuỗi tương ứng, model bị lệch ngữ cảnh, suy biến thành lặp token. **KHÔNG có tài liệu MNN nào xác nhận chính xác hợp đồng hành vi cần thiết** (cần gửi prompt kiểu gì — chỉ phần mới, hay toàn bộ, hay có API riêng để "tiếp tục" — để `reuse_kv` hoạt động đúng) — mục 65 đã bật tính năng này dựa trên tên tham số + mô tả ngắn mà chưa kiểm chứng đủ kỹ hợp đồng hành vi thật, đây là bài học nhắc lại: xác nhận được TÊN tham số đúng (tránh lặp lỗi mục 59) là điều kiện CẦN nhưng CHƯA ĐỦ — còn phải hiểu đúng ngữ nghĩa/hợp đồng sử dụng trước khi bật trên đường chính (production path).
    - **Đã sửa an toàn**: tắt lại `reuseKv: false` ở đúng 1 dòng gọi trong `chat_screen.dart` — **giữ nguyên toàn bộ hạ tầng** đã nối dây xuyên suốt (`AIProvider` → `MethodChannel` → `MnnBridge.kt` → JSON config), chỉ tắt nơi bật. Muốn bật lại sau khi xác minh đúng cách dùng, chỉ cần sửa đúng 1 dòng, không cần làm lại hạ tầng.
    - **Hệ quả**: lượt chat thứ 2 trở đi sẽ CHẬM HƠN LẠI như trước mục 65 (không còn tái sử dụng KV-cache) — đánh đổi tốc độ lấy đúng đắn, hợp lý cho tới khi có cách xác minh chắc chắn cách dùng đúng `reuse_kv` (ví dụ: tìm được ví dụ code chính thức của MNN dùng nó trong ngữ cảnh multi-turn thật, không chỉ tên tham số).
    - **CHƯA build/test thật** (bản thân việc tắt lại thì rủi ro thấp — chỉ là quay về hành vi mặc định `false` đã hoạt động ổn định trước đó — nhưng vẫn cần xác nhận qua build thật là hết hẳn hiện tượng "8888888").

69. **[TÍNH NĂNG LỚN MỚI, CHƯA build/test — 2026-08-02] Theo yêu cầu người dùng: tách hẳn giai đoạn LÊN KẾ HOẠCH (nhanh, không gọi AI) khỏi giai đoạn THỰC THI (chậm, AI chạy tuần tự theo hàng đợi) — trực tiếp giải quyết đúng nguyên nhân crash "2 lệnh generate chạy chồng chéo" đã tìm ra ở mục 5.67: nếu người dùng KHÔNG CÒN BỊ BẮT phải ngồi chờ AI viết XONG TỪNG CHƯƠNG/ĐOẠN MỘT mới được làm việc khác, sẽ giảm hẳn khả năng 2 tác vụ AI tình cờ trùng thời điểm.** Gồm 2 hệ thống song song, dùng chung tư duy "ghi chú trước, xử lý hàng loạt sau":
    - **Migration DB v3→v4** (`database_service.dart`): thêm cột `chapters.outline` (dàn ý/"chương mồi" — trước đây chỉ tồn tại tạm trong `outlineCtrl`, KHÔNG lưu DB, mất trắng nếu rời màn hình chưa bấm "Đắp thịt" — giờ `_save()` lưu bền, `initState()` nạp lại đúng); thêm bảng mới `pending_rewrites` (model `PendingRewrite` trong `story_models.dart`: `id, chapterId, novelId, originalText, note, status, resultText, createdAt`).
    - **Hệ thống A — Tạo chương hàng loạt từ outline**: `chapter_batch_service.dart` (MỚI) — nhận danh sách `Chapter` đã chọn (có `outline`), gọi `StyleService.fleshOutOutline()` (logic có sẵn, dùng lại nguyên) TUẦN TỰ từng chương, bọc `beginPipeline`/`endPipeline` (mẫu đã có ở `document_service.dart`, mục 61), có kiểm tra tính hợp lý kết quả trước khi lưu (ngưỡng độ dài, cùng tư duy `DocumentProcessingAnomalyException` ở mục 64 — dừng ngay nếu 1 chương ra kết quả bất thường, không chạy tiếp qua chương khác). `chapters_batch_generate_screen.dart` (MỚI) — màn hình chọn chương (checkbox, lọc nhanh "có outline"/"có outline + chưa viết"), thanh tiến trình %, nút Huỷ, `PopScope` chặn back — TÁI DÙNG gần như y hệt cấu trúc `document_chunks_screen.dart` (mục 63). Thêm nút mở màn hình này + badge trạng thái outline trên `chapters_screen.dart`.
    - **Hệ thống B — Ghi chú bôi đen, xử lý hàng loạt**: `_showRewriteMenu()` trong `chapter_editor_screen.dart` **THAY ĐỔI HOÀN TOÀN** — trước đây hiện 4 lựa chọn HARDCODE ("Sửa lỗi chính tả", "Viết sinh động hơn"...) và **GỌI AI NGAY LẬP TỨC** khi chọn (chính là 1 trong các đường có thể vô tình trùng thời điểm với tác vụ AI khác — nguyên nhân crash mục 5.67). Giờ: bôi đen → viết NHẬN XÉT/YÊU CẦU TỰ DO (không hardcode) → **LƯU thành `PendingRewrite` vào DB, KHÔNG GỌI AI** — có thể lặp lại ở nhiều chỗ. Khi sẵn sàng, bấm "Tạo lại tất cả" (`_applyAllPendingRewrites()`) xử lý TUẦN TỰ từng ghi chú.
      - **Định vị lại đoạn văn khi áp dụng**: dùng NGUYÊN VĂN `originalText` tìm trong nội dung HIỆN TẠI (không dùng offset số — nội dung có thể đã bị sửa ở chỗ khác giữa lúc ghi chú và lúc xử lý, đúng rủi ro đã lường trước khi thiết kế). Nếu không tìm thấy ĐÚNG 1 LẦN (đã bị sửa/xoá, hoặc trùng nhiều chỗ gây mơ hồ) → BỎ QUA ghi chú đó (`status = 'skipped_text_changed'`), không đoán mò áp dụng nhầm chỗ.
      - Hàm cũ `_applyRewrite()` (gọi AI ngay khi bôi đen) đã **XOÁ HẲN** (không còn nơi gọi tới) — biến `rewriting` gộp chung vào `applyingRewrites` mới, tránh biến chết.
      - UI mới trên AppBar `chapter_editor_screen.dart`: badge "N ghi chú" (mở xem/xoá từng ghi chú qua `_showPendingRewritesSheet`) + nút "Tạo lại tất cả".
    - **Lỗi tự phát hiện và sửa ngay trong lúc viết**: dùng `final context = await rag.buildContext(...)` bên trong `_applyAllPendingRewrites()` — biến cục bộ `context` (String) **CHE KHUẤT** `BuildContext context` kế thừa từ `State` (Dart cho phép shadowing, không báo lỗi ngay dòng đó) — nhưng dòng sau đó gọi `ScaffoldMessenger.of(context)` sẽ cố gọi `.of()` trên String, LỖI BIÊN DỊCH THẬT nếu không phát hiện. Đã đổi tên thành `storyBibleContext` trước khi đóng gói. **Bài học**: tên biến `context` cực kỳ dễ vô tình che khuất `BuildContext` trong bất kỳ hàm nào của `State` — luôn tránh đặt tên biến cục bộ trùng `context` trong file Flutter, dù ở phạm vi hẹp.
    - **Đã tự kiểm tra**: bracket-check nghiêm ngặt (stack-based) cho toàn bộ 6 file thay đổi (`chapter_editor_screen.dart`, `chapter_batch_service.dart`, `chapters_batch_generate_screen.dart`, `chapters_screen.dart`, `story_models.dart`, `database_service.dart`) — tất cả sạch.
    - **CHƯA build/test thật.** Việc cần làm ở phiên sau: build lại, thử viết vài outline chương (không gọi AI), dùng "Tạo chương hàng loạt" tạo 2-3 chương liên tiếp xem thanh tiến trình + huỷ hoạt động đúng; thử bôi đen nhiều chỗ trong 1 chương, viết ghi chú, bấm "Tạo lại tất cả", xác nhận định vị lại đúng đoạn (thử cả trường hợp sửa nội dung ở chỗ khác giữa lúc ghi chú và lúc xử lý, xem có bị bỏ qua đúng như thiết kế không thay vì áp dụng nhầm chỗ).

70. **[LỖ HỔNG THẬT DO CHÍNH MỤC 69 GÂY RA, PHÁT HIỆN QUA CÂU HỎI TRỰC TIẾP CỦA NGƯỜI DÙNG — 2026-08-02] Cả 2 hệ thống mới ở mục 69 (tạo chương hàng loạt + hàng đợi ghi chú bôi đen) đều ÂM THẦM BỎ QUA pipeline dịch thuật trung gian (`TranslationService`), dù luồng tương tác đơn lẻ tương ứng đã có từ trước.** Người dùng hỏi thẳng "2 hệ thống này có chạy theo quy trình dịch từ prompt->model sinh->dịch lại ngôn ngữ người dùng nếu bật hạ tầng dịch trung gian không" — kiểm tra code xác nhận: KHÔNG.
    - `ChapterBatchService.generateBatch()` dùng `StyleService.fleshOutOutline()` — hàm này **TỰ GHI RÕ TRONG COMMENT** là "gọi thẳng provider, không qua dịch thuật trung gian" (thiết kế cho 1 mục đích khác trước đó) — tạo chương hàng loạt vì vậy bỏ qua hoàn toàn cài đặt dịch thuật trung gian nếu người dùng đã bật.
    - `_applyAllPendingRewrites()` (mục 69, code MỚI VIẾT) gọi thẳng `provider.generate()` thay vì `_generateRespectingTranslation()` — khác với hàm cũ `_applyRewrite()` (đã xoá) vốn có dùng đúng `_generateRespectingTranslation()`. Đây là **lỗi hồi quy tôi tự gây ra** khi viết tính năng mới, không kiểm tra lại tính nhất quán với luồng cũ.
    - **Nhân tiện phát hiện thêm 1 lỗ hổng khác, có sẵn từ trước (không phải do mục 69 gây ra)**: `TranslationService.generateWithOptionalTranslation()` — hàm DÙNG CHUNG cho mọi nơi có route qua dịch thuật — trước giờ chỉ nhận `temperature`/`maxTokens`, **ÂM THẦM BỎ QUA `topP`/`topK`/`repetitionPenalty`** ở CẢ HAI nhánh (có dịch/không dịch) — nghĩa là các tham số này người dùng chỉnh trong Cài đặt KHÔNG có tác dụng thật với BẤT KỲ lệnh nào đi qua hàm này, kể cả trước khi có mục 69.
    - **Đã sửa tận gốc, 1 nơi sửa áp dụng cho mọi nơi gọi**: mở rộng `generateWithOptionalTranslation()` nhận đủ `topP`/`topK`/`repetitionPenalty`, truyền xuyên suốt CẢ HAI nhánh. `_generateRespectingTranslation()` trong `chapter_editor_screen.dart` rút gọn thành 1 lớp mỏng gọi thẳng hàm dùng chung (bỏ nhánh rẽ trùng lặp cũ). `ChapterBatchService` đổi sang tự build prompt qua `buildFleshOutPrompt()` (công khai, logic prompt giữ nguyên) rồi gọi `generateWithOptionalTranslation()` trực tiếp — nhất quán với luồng đơn lẻ. `_applyAllPendingRewrites()` đổi sang gọi `_generateRespectingTranslation()` thay vì `provider.generate()` trực tiếp, đồng thời nạp đúng `genCfg` từ Cài đặt thay vì hardcode `temperature: 0.8, maxTokens: 1500` như bản viết vội trước đó.
    - **Lỗi kỹ thuật thứ 2 tự phát hiện khi sửa**: `pipelineActive` (Boolean đơn giản, không đếm số lần lồng nhau) trong `MnnBridge.kt` **KHÔNG AN TOÀN** khi 2 lớp pipeline lồng nhau — `ChapterBatchService` bọc `beginPipeline()`/`endPipeline()` quanh CẢ vòng lặp nhiều chương, nhưng BÊN TRONG mỗi lượt, `generateWithOptionalTranslation()` (khi dịch thuật bật) CŨNG tự gọi `beginPipeline()`/`endPipeline()` riêng cho từng bước dịch — `endPipeline()` của lớp TRONG sẽ tắt Foreground Service NGAY sau 1 chương, dù vòng lặp NGOÀI còn nhiều chương chưa xử lý — tái tạo đúng kiểu lỗ hổng "chớp tắt thông báo giữa các bước" đã sửa ở mục 5.61 cho xử lý tài liệu, nhưng theo cách mới (lồng nhau, không phải tuần tự đơn giản). **Đã sửa**: đổi `pipelineActive` (Boolean) thành `pipelineDepth` (Int, đếm số lần lồng nhau, có khoá `synchronized` bảo vệ) trong `MnnBridge.kt` — chỉ THẬT SỰ bật Foreground Service khi độ sâu từ 0 lên 1 (lần bọc ngoài cùng), chỉ THẬT SỰ tắt khi độ sâu về lại 0 (lần kết thúc cuối cùng khớp với lần bắt đầu đầu tiên) — hỗ trợ đúng bất kỳ độ sâu lồng nhau nào (2 lớp như hiện tại, hoặc nhiều hơn trong tương lai) mà không cần Dart phải biết xử lý đặc biệt. `cancelGenerate` reset thẳng độ sâu về 0 (huỷ thủ công phải dừng toàn bộ, không chỉ giảm 1 lớp).
    - **Đã tự kiểm tra**: bracket-check nghiêm ngặt cho toàn bộ 4 file liên quan (`translation_service.dart`, `chapter_editor_screen.dart`, `chapter_batch_service.dart`, `MnnBridge.kt`) — sạch. Phát hiện và tự sửa thêm 1 lỗi ngoặc treo (dangling brackets) sót lại từ thao tác `str_replace` trước đó ở `chapter_editor_screen.dart` trong lúc rút gọn `_generateRespectingTranslation()` — nhờ thói quen kiểm tra ngay sau mỗi lần sửa mà bắt được trước khi đóng gói.
    - **Bài học quy trình**: khi thêm 1 luồng gọi AI MỚI (đặc biệt dạng hàng loạt/batch), phải RÀ LẠI xem có ĐANG ĐI ĐÚNG qua các lớp hạ tầng dùng chung đã có (dịch thuật trung gian, cấu hình sinh văn bản đầy đủ, quản lý Foreground Service) hay đã vô tình viết tắt/bỏ qua — nhất là khi có sẵn 1 hàm helper cũ (`StyleService.fleshOutOutline`) ghi rõ trong comment là "phiên bản rút gọn, bỏ qua X" — dễ bị tái sử dụng nhầm trong ngữ cảnh MỚI cần đầy đủ hơn ngữ cảnh nó được viết ra ban đầu.
    - **CHƯA build/test thật.**

71. **[RÀ SOÁT TOÀN HỆ THỐNG THEO YÊU CẦU TRỰC TIẾP CỦA NGƯỜI DÙNG — 2026-08-02] Người dùng KHÔNG chấp nhận câu trả lời "đã sửa" chung chung ở mục 70, hỏi thẳng: (a) đã sửa triệt để chưa hay chỉ vá 1-2 chỗ, (b) model dịch có áp dụng cài đặt không, có prompt văn phong dịch không, (c) Foreground Service có đủ tin cậy để CHẠY XUYÊN ĐÊM không ("sáng dậy thấy chết thì dẹp luôn dự án"). Rà soát bằng `grep` toàn bộ `lib/` tìm MỌI nơi gọi `provider.generate()`/`generateStream()` — phát hiện mục 70 CHỈ sửa 2/8 điểm thật.**
    - **(a) Danh sách đầy đủ sau khi rà soát toàn bộ, phân loại ĐÚNG/SAI theo bản chất kỹ thuật (không sửa tràn lan)**:
      - **THẬT SỰ THIẾU, ĐÃ SỬA thêm ở mục này**: `_checkConsistency()` (chapter_editor_screen.dart — trước đây không hề qua dịch thuật LẪN không dùng `genCfg` đầy đủ, chỉ có `maxTokens: 400` hardcode); `SummaryService.summarizeChapter()` (tóm tắt tự động sau khi lưu chương); `StyleService.analyzeStyleFromSample()` (phân tích văn phong từ mẫu import); `chat_screen.dart` nhánh CÓ dịch thuật (dù mục 70 đã sửa HẠ TẦNG `generateWithOptionalTranslation()` nhận đủ `topP`/`topK`/`repetitionPenalty`, nhưng CHÍNH nơi gọi đầu tiên phát hiện ra vấn đề — `chat_screen.dart` — lại QUÊN cập nhật truyền các tham số đó vào lệnh gọi thật — **đúng như người dùng lo ngại "có phải chỉ làm mã như lúc đầu"**, vá hạ tầng không tự động vá nơi gọi).
      - **CỐ Ý BỎ QUA, XÁC NHẬN ĐÚNG (không phải lỗi)**: `document_service.dart` (dịch/tóm tắt tài liệu) — văn bản gốc là NGOẠI NGỮ (Trung/Anh...) CHƯA dịch, khác hẳn các trường hợp trên (nội dung tiếng Việt của chính người dùng) — pipeline `generateWithOptionalTranslation` giả định đầu vào là TIẾNG VIỆT cần dịch sang ngôn ngữ trung gian; áp dụng nhầm ở đây sẽ dịch SAI HẲN (tưởng văn bản Trung là tiếng Việt). `benchmark_service.dart` — cố ý đo tốc độ THUẦN của model, áp dụng dịch thuật sẽ làm sai lệch phép đo.
    - **(b) Model dịch CÓ áp dụng cài đặt văn phong** (`loadTranslationStylePrompt()`, người dùng tự chỉnh trong Cài đặt, đã có từ trước — xác nhận qua code, không phải phỏng đoán) — nhưng **KHÔNG áp dụng** `topP`/`topK`/`repetitionPenalty` từ Cài đặt sinh văn bản chung (model dịch dùng `temperature: 0.3` cứng — **đây là THIẾT KẾ ĐÚNG, không phải lỗi**: dịch thuật cần chính xác/xác định, không nên dùng tham số "sáng tạo" của việc viết truyện). Hiện CHƯA có cài đặt `topP`/`topK`/`repetitionPenalty` RIÊNG cho model dịch — ghi nhận là thiếu SÓT NHỎ (không khẩn cấp), chưa làm ở phiên này.
    - **(c) Foreground Service cho chạy xuyên đêm — audit kỹ, tìm ra 1 lỗ hổng thật + xác nhận 1 điểm đã ổn**:
      - **XÁC NHẬN ỔN (tra cứu tài liệu Android chính thức)**: loại `specialUse` (đổi từ `dataSync` ở mục 66) KHÔNG bị giới hạn 6 tiếng như `dataSync`/`mediaProcessing` trên Android 15 — quyết định đổi loại ở mục 66 vô tình đã giải quyết đúng vấn đề này trước cả khi được hỏi.
      - **LỖ HỔNG THẬT, ĐÃ SỬA**: `GenerationService.kt` — WakeLock trước đây xin TRẦN CỨNG 8 TIẾNG (`acquire(8*60*60*1000L)`) — đây là giới hạn APP TỰ ĐẶT (không phải hệ điều hành), không đủ cho việc để máy chạy nhiều tiếng qua đêm. **Đã sửa**: đổi sang TỰ LÀM MỚI ĐỊNH KỲ — mỗi 30 phút gia hạn thêm 40 phút (luôn dư 10 phút) — hỗ trợ chạy dài KHÔNG GIỚI HẠN thời gian trong khi vẫn có lưới an toàn (nếu vòng lặp làm mới vì lý do gì đó dừng bất thường, WakeLock tự hết hạn sau tối đa 40 phút thay vì rò rỉ vĩnh viễn hút cạn pin).
      - **LỚP PHÒNG VỆ MỚI THÊM (không phải sửa lỗi có sẵn, mà bổ sung do bản chất yêu cầu độ tin cậy cao)**: thêm khả năng xin loại trừ khỏi tối ưu hoá pin của hãng máy (`isIgnoringBatteryOptimizations`/`requestIgnoreBatteryOptimizations`, qua Intent `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` — Android bắt buộc phải hỏi người dùng, không cho app tự tắt) — vì Foreground Service đúng chuẩn Android **không đảm bảo tuyệt đối** trên các máy có trình quản lý pin riêng của hãng (đặc biệt ASUS ZenUI, đúng máy test — mục 5.66) — hãng có thể tự ý kill app nền bất kể đúng chuẩn Android hay không, TRỪ KHI người dùng tự loại trừ thủ công. Thêm UI trong `local_optimization_screen.dart`: hiện rõ trạng thái (đã loại trừ/chưa), nút yêu cầu + nút kiểm tra lại.
    - **Tổng cộng đã sửa trong lượt này**: `summary_service.dart`, `style_service.dart`, `chapter_editor_screen.dart` (`_checkConsistency`), `chat_screen.dart`, `GenerationService.kt` (WakeLock renewal), `MnnBridge.kt` (2 handler pin mới), `build.yml` (quyền `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`), `local_provider.dart` (2 static method mới), `local_optimization_screen.dart` (UI trạng thái pin).
    - **Đã tự kiểm tra**: bracket-check nghiêm ngặt cho toàn bộ 8 file Dart/Kotlin thay đổi — sạch; `build.yml` xác nhận vẫn là YAML hợp lệ sau khi thêm quyền.
    - **Bài học quan trọng nhất phiên này**: khi hạ tầng dùng chung được SỬA (ví dụ mở rộng tham số 1 hàm), phải RÀ LẠI TỪNG NƠI GỌI để xác nhận thật sự dùng tham số mới — sửa xong khả năng của hàm KHÔNG tự động nghĩa là mọi nơi gọi đã dùng đúng khả năng đó; đây chính xác là điều người dùng nghi ngờ khi hỏi "hay chỉ là làm mã như lúc đầu" — và nghi ngờ đó đúng ở 1 nửa số điểm.
    - **CHƯA build/test thật.**

---

## 6. Danh sách yêu cầu người dùng — đã hoàn thành / chưa hoàn thành

### ✅ Đã hoàn thành và có trong source zip mới nhất

- [x] App viết truyện AI, đa truyện (multi-novel), Story Bible/RAG/timeline
- [x] Chat đa phiên, lưu bền vững, không mất khi đổi tab/model
- [x] Nhiều model local + nhiều API provider, không hardcode, đổi giữa chừng không mất bối cảnh
- [x] Không bộ lọc nội dung ở tầng app
- [x] Xuất chương (EPUB/DOCX/TXT), xuất chat (TXT/DOCX), xuất kết quả tài liệu
- [x] Đính kèm/dịch/tóm tắt tài liệu `.txt`/`.md` (Giai đoạn 1)
- [x] Văn phong + đắp thịt outline (không vi phạm bản quyền)
- [x] Tối ưu thiết bị: nhận diện chip, benchmark thật, RAG budget theo máy
- [x] Đổi engine AI local sang MNN-LLM + QNN, build qua GitHub Actions thành công (bao gồm tải QNN SDK, build native, biên dịch cầu nối JNI, và build Dart/Flutter)
- [x] **Provider "GPU ngoài" qua Google Colab (miễn phí)** — `OpenAICompatibleProvider` + notebook `LocalNovel_GPU_tu_xa_qua_Colab.ipynb` (build `llama-server` có CUDA + Cloudflare Tunnel), `BackgroundTaskManager` cho phép NHIỀU chương chạy THẬT SỰ song song khi provider là remote (giới hạn theo `maxParallelRemoteTasks`, xem `settings_screen.dart`) — mục này TRƯỚC ĐÂY ghi nhầm là "⬜ CHƯA code" gộp chung với lớp ẩn danh hoá (rà soát lại 2026-08-21, xem mục ⬜ bên dưới để biết phần THẬT SỰ chưa làm của kế hoạch 5 lớp mục 5.29 gốc).
- [x] Kiến trúc Platform Channel thay FFI (loại bỏ lỗi dlopen)
- [x] 2 slot model độc lập (multi-context) ở tầng native
- [x] Foreground Service + WakeLock chống bị Android kill khi chạy nền/qua đêm (wake lock trần 8 tiếng), gộp thành 1 pipeline cho luồng dịch tuần tự
- [x] Sửa UI model MNN (thư mục thay vì file `.gguf`), `FileBrowserScreen` hỗ trợ chọn thư mục VÀ chọn file (lọc theo đuôi file)
- [x] Tham số sinh văn bản — đã nối vào khung chat VÀ `chapter_editor_screen.dart`
- [x] Dịch thuật trung gian tuần tự — đã nối vào khung chat VÀ `chapter_editor_screen.dart`
- [x] In-line AI Rewrite (mục 4.9)
- [x] Notebook Colab convert model HuggingFace/ModelScope → định dạng MNN (`LocalNovel_Convert_Model_To_MNN.ipynb`, không nằm trong zip app — file riêng), đã convert thành công thật 1 model 7B, dùng được trên app
- [x] **QNN NPU XÁC NHẬN KÍCH HOẠT ĐƯỢC THẬT** trên Zenfone 8 (log debug thật: `loadModel TRẢ VỀ xong: {success: true, backend: qnn}`) — không còn là rủi ro treo nữa, xem mục 6 "Đã code nhưng CHƯA xác nhận" bên dưới đã bỏ mục này ra
- [x] Sửa lỗi nền tảng nghiêm trọng nhất từ trước tới giờ: `MainActivity.kt` thật bị copy sai đường dẫn package trong `build.yml` (mục 5.18) — mọi bản build từ #30-33 chưa từng thực sự chạy code native
- [x] Sửa nguyên nhân THẬT của crash native khi chat/đo tốc độ: R8/ProGuard đổi tên hàm JNI cần tới bằng tên chuỗi (mục 5.24) — đã thêm luật ProGuard `-keep`, kiểm tra/tự chèn `proguardFiles` vào `build.gradle`
- [x] Hạ tầng log chẩn đoán 3 tầng Dart/Kotlin/C++ ghi ra file xem được ngay trong app (mục 5.19-21), không cần ADB/máy tính
- [x] `backendPreference` (QNN tự động/ép GPU/ép CPU) cấu hình được từ UI, không cần build lại (mục 5.22)
- [x] Bọc toàn bộ `onMethodCall` trong try/catch — không còn nguy cơ 1 lỗi Kotlin bất kỳ làm crash cả app (mục 5.25)
- [x] Lỗi `@UiThread must be executed on the main thread` — đã sửa từ phiên trước (bọc `mainHandler.post{}`), nay mới được ghi lại vào tài liệu (mục 5.26)
- [x] Bug reload model mỗi lần chat (`currentProvider()` tạo instance mới mỗi lần gọi) — đã sửa bằng cache tĩnh trong `SettingsService` (mục 5.27)
- [x] **`llm->response()` sinh văn bản thật THÀNH CÔNG** (mục 5.28 → 5.40, đã đóng). Nguyên nhân cuối: backend QNN crash cứng (SIGSEGV) mọi lúc; OpenCL chạy được. App hiện dùng OpenCL khi ép buộc; cần đổi mặc định sang OpenCL (bỏ QNN khỏi đường thử đầu tiên) — xem việc cần làm ở mục 5.40. QNN để backlog tối ưu sau (mục 5.43).
- [ ] **`GenerationService` (Foreground Service/WakeLock) chưa từng khai báo trong Manifest — ĐANG SỬA, ưu tiên cao** (mục 5.42). Giải thích hiện tượng app "đóng băng" khi tắt màn hình lúc đang sinh văn bản, và số liệu `prefill_us` tăng bất thường qua các lần trong log. Đã thêm bước khai báo `<service>` + quyền vào `build.yml`, CHƯA build/test.
- [x] CI build ổn định trở lại sau lỗi `jni`/AGP 9 không tương thích (mục 5.30) — đã hạ AGP xuống 8.13.0 + Gradle 8.13 + Kotlin 2.1.20, build APK qua được nhiều lần liên tiếp.
- [x] **Xác nhận nguyên nhân gốc QNN không dùng được trên máy test — không phải lỗi code, mà do Hexagon v68 dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU (v73+)** (mục 5.52). Đã đổi mặc định sang GPU (OpenCL) đã tối ưu, QNN chuyển thành thử nghiệm bật thủ công (`backendPreference=3`), giữ nguyên cơ chế cách ly tiến trình con + timeout an toàn (mục 5.53) cho ai muốn thử trên máy chip mới hơn.
- [x] Tối ưu tốc độ GPU thật sự theo tài liệu MNN chính thức: `precision:low`, `memory:low`, `thread_num:68`, cache autotuning kernel (`tmp_path`) — mục 5.54.
- [x] Sửa bug FAB "Bách khoa" luôn mở sai form theo tab + sửa luôn bug màn hình trắng do chính phiên này gây ra khi vá lần 1 — mục 5.48/5.49.
- [x] Sửa 4 chỗ crash `setState() called after dispose()` trong `chapter_editor_screen.dart` khi thoát màn hình lúc AI đang chạy — mục 5.50.
- [x] Sửa bug hallucination Story Bible (model tự bịa nội dung khi Story Bible trống) — mục 5.51.
- [x] Thêm UI chỉnh prompt tóm tắt/dịch tài liệu + làm xử lý tài liệu tiếp tục được dở dang — mục 5.55.
- [x] Thêm `PopScope` chặn vuốt back Android 13+ giữa lúc AI đang chạy (chương/tài liệu) — mục 5.56, CHƯA build/test thật.
- [x] Tính năng mới: tìm kiếm web thủ công (bật/tắt theo phiên chat, không tự động) — mục 5.57, CHƯA build/test thật.
- [x] `build.yml` không còn để bước copy file QNN thất bại âm thầm — mục 5.58, CHƯA build/test thật.

### ⚠️ Đã code nhưng CHƯA xác nhận chạy đúng thật (rủi ro còn treo)

- [ ] `foregroundServiceType="dataSync"` có bị hệ thống từ chối lúc chạy không — vẫn chưa test riêng biệt, dù Foreground Service đã chạy được nhiều lần trong lúc debug crash (log cho thấy `GenerationService.start()` không hề ném lỗi) nên rủi ro này coi như đã giảm đáng kể, có thể hạ độ ưu tiên.
- [ ] **Bản sửa ProGuard/R8 (mục 5.24) — CHƯA build+test lần nào**. Đây là việc ưu tiên SỐ 1 tuyệt đối ngay phiên tiếp theo — nếu sửa đúng, tính năng chat/sinh văn bản với model local sẽ LẦN ĐẦU TIÊN hoạt động thật sự từ đầu dự án tới giờ.
- [ ] **TẤT CẢ 6 tính năng ở mục 4.10-4.15** (version snapshot, tìm kiếm, glossary/chống lặp từ, Story Bible nâng cao/auto-mention, EPUB bìa+mục lục, backup/restore) — vẫn CHƯA build/test lần nào kể từ khi viết (nhiều vòng build gần đây đều tập trung vá lỗi native/crash, chưa quay lại kiểm tra các tính năng Dart-only này).

### 🔧 Đã bắt đầu nhưng CHƯA hoàn thiện hết

*(không còn mục nào ở trạng thái này — 2 mục từng ở đây đã hoàn thành ở phiên trước)*

### ⬜ Yêu cầu đã nêu, CHƯA code

- [ ] Tóm tắt phân tầng đệ quy (tier 2: cụm chương, tier 3: bản đồ kịch bản toàn truyện) — cần cho truyện triệu chữ. **Cố tình chưa làm** — cần đọc `llm.hpp` thật trước để biết API quản lý KV cache đúng (mục 5.10), rủi ro kỹ thuật cao nhất trong các việc còn lại, không nên làm vội chung đợt với 6 tính năng khác.
- [ ] Scene bên trong Chapter + Corkboard kéo-thả — UI lớn, nhiều tương tác kéo-thả phức tạp, nên làm riêng 1 phiên để có không gian rà soát kỹ.
- [ ] TTS (đọc chương thành giọng nói) — cần thêm plugin native mới (chưa có trong `pubspec.yaml`), rủi ro build tương tự các lần đổi engine AI trước đây (mục 5.1-5.6) — cố tình hoãn, không thêm dependency mới khi chưa xác nhận build hiện tại ổn định.
- [ ] Đọc tài liệu PDF/DOCX/ảnh (Giai đoạn 2 của tính năng tài liệu) — cố tình hoãn từ trước, lý do tương tự TTS.
- [ ] Author's Note/Memory field tách riêng Story Bible, Canvas outline trực quan, tùy biến font/theme trình soạn thảo — chưa có yêu cầu cụ thể, độ ưu tiên thấp hơn các mục trên.
- [ ] **Lớp ẩn danh hoá thực thể trước khi gửi ra provider ngoài** (tên nhân vật/địa danh riêng → mã hoá tạm trước khi gửi HTTP ra GPU remote/API, giải mã lại khi nhận về) — phần kiến trúc 5 lớp thống nhất ở mục 5.29 gốc, TÁCH RIÊNG khỏi dòng "Provider GPU ngoài" (đã hoàn thành, xem mục ✅ phía trên) vì rà soát lại (2026-08-21, theo yêu cầu người dùng "kiểm tra tính năng nào có UI nhưng không hoạt động") xác nhận: **CHƯA có 1 dòng code nào** cho lớp ẩn danh hoá này trong toàn bộ `lib/` — không có hàm, không có UI, không có bảng ánh xạ tên thật↔mã hoá. Rủi ro thật đang tồn tại: dùng "GPU từ xa qua Colab"/API ngoài hiện gửi NGUYÊN VĂN tên riêng/nội dung truyện qua HTTP, không qua bước ẩn danh nào — nếu người dùng coi đây là yêu cầu bảo mật quan trọng (không phải chỉ optimization), cần ưu tiên làm sớm hơn vị trí hiện tại trong danh sách.

### 🆕 Mới hoàn thành phiên này (mục 4.10-4.15 phía trên) — CHƯA build/test thật

- [x] Version snapshot (undo AI viết đè) — mục 4.10
- [x] Tìm kiếm toàn văn UI — mục 4.11
- [x] Glossary (bảng thuật ngữ) + thống kê chống lặp từ — mục 4.12
- [x] Story Bible nâng cao: phân loại thẻ chi tiết + auto-mention — mục 4.13
- [x] EPUB có bìa + mục lục nhấp được thật — mục 4.14
- [x] Backup/restore toàn bộ dữ liệu — mục 4.15

---

## 7. Việc cần làm ngay khi bắt đầu phiên mới

**Cập nhật (2026-07-31 — trạng thái mới nhất, phiên dài, nhiều thay đổi lớn)**:

**Quyết định chiến lược quan trọng nhất phiên này**: đã điều tra và xác nhận
QNN/NPU không khả thi trên máy test (Snapdragon 888/Hexagon v68 dưới mức
Qualcomm chính thức hỗ trợ v73+ cho LLM — mục 5.52) — **không phải lỗi
code có thể vá tiếp**. Đã đổi chiến lược: **GPU (OpenCL) là đường chính**,
tối ưu hết mức theo tài liệu MNN chính thức (mục 5.54); QNN lùi thành lựa
chọn thử nghiệm bật thủ công (`backendPreference=3`), giữ nguyên cơ chế an
toàn (cách ly tiến trình con + timeout, mục 5.53) cho tương lai nếu đổi
máy chip mới hơn.

Ngoài ra phiên này sửa thêm nhiều bug UI/UX thật do người dùng phát hiện
qua ảnh chụp màn hình: bug FAB "Bách khoa" sai form theo tab (mục 5.48) —
**và chính bản vá lần 1 của bug đó lại gây ra 1 bug MỚI nghiêm trọng hơn
(màn hình trắng xoá cả tab Bách khoa, mục 5.49)** — bài học: mọi sửa lỗi
liên quan tới `context`/`InheritedWidget` phải được kiểm tra rất kỹ, ưu
tiên cho `State` tự sở hữu `Controller` riêng thay vì `.of(context)` khi
còn nghi ngờ. Sửa crash `setState() after dispose()` (mục 5.50), sửa
hallucination Story Bible trống (mục 5.51), thêm `PopScope` chặn back
Android 13+ (mục 5.56), thêm tính năng mới tìm kiếm web thủ công (mục
5.57).

**TRẠNG THÁI BUILD/TEST THẬT**: các mục 5.48 (bản đã sửa lỗi ở 5.49),
5.50, 5.51, 5.52, 5.53, 5.54 đã được người dùng xác nhận qua log/ảnh chụp
màn hình thật trong chính phiên hội thoại này (không phải suy đoán). Mục
5.56 (`PopScope`) từng có lỗi biên dịch thật (build APK #67 fail, xem mục
5.59) — **đã sửa tên tham số đúng, nhưng CHƯA build lại lần nào sau khi
sửa**. Mục 5.65 (`reuse_kv`) đã bật rồi PHẢI TẮT LẠI ngay do gây lỗi thật
("8888888", xem mục 5.68) — hạ tầng vẫn giữ, chỉ tắt nơi bật. Mục 5.67
(khoá Mutex chống generate() chạy chồng chéo) là phát hiện quan trọng
nhất phiên này, CHƯA build/test thật — ưu tiên xác nhận đầu tiên ở phiên
sau. Mục 5.69 (tạo chương hàng loạt + hàng đợi ghi chú) là tính năng lớn
MỚI, mục 5.70+5.71 (rà soát toàn hệ thống 2 lượt liên tiếp — dịch thuật
trung gian áp dụng đủ nơi chưa, `pipelineActive`→`pipelineDepth`, WakeLock
tự làm mới thay vì trần 8 tiếng, thêm loại trừ tối ưu hoá pin) — TẤT CẢ
CHƯA build/test thật lần nào, độ phức tạp cao (nhiều file mới + sửa hạ
tầng dùng chung nhiều lớp), cần test kỹ ở phiên sau hơn các mục khác —
**đặc biệt mục 5.71 (độ tin cậy chạy xuyên đêm) là yêu cầu cứng của
người dùng, cần xác nhận thật bằng cách để chạy 1 tác vụ dài qua đêm
thật sự, không chỉ tin vào suy luận kỹ thuật**. Các mục
**5.55, 5.56, 5.57, 5.58, 5.61, 5.66, 5.67, 5.68, 5.69, 5.70, 5.71 vẫn
CHƯA build/test thành công lần nào** — đây là việc ưu tiên ngay khi bắt
đầu phiên mới.

1. **Việc cần làm ĐẦU TIÊN**: build lại qua GitHub Actions với zip source
   MỚI NHẤT (đã gộp toàn bộ mục 5.48-5.58). Cài đè, thử LẦN LƯỢT từng
   tính năng:
   - Mở tab "Bách khoa", chuyển qua lại cả 4 tab, xác nhận nút "+" mở
     đúng form theo tab, KHÔNG còn màn hình trắng xoá (mục 5.48/5.49).
   - Chat/viết tiếp chương, đo tốc độ GPU có nhanh hơn rõ rệt không so
     với trước (mục 5.54) — cả bước mở model (không còn chờ 90s QNN vô
     ích) lẫn tốc độ sinh token (precision/memory tối ưu).
   - Story Bible còn trống, thử hỏi chat — xác nhận model KHÔNG còn tự
     bịa nội dung (mục 5.51).
   - Đang tạo chương/dịch/tóm tắt, thử vuốt back — xác nhận bị chặn đúng
     kỳ vọng, không mất tiến độ (mục 5.56, CHƯA test thật).
   - Bật nút tìm kiếm web trong chat, hỏi 1 câu cần thông tin mới — xác
     nhận có tìm được kết quả thật, không lỗi quyền `INTERNET`/mạng (mục
     5.57, CHƯA test thật — nếu lỗi quyền, cần thêm bước khai báo
     `INTERNET` permission vào `build.yml` tương tự cách đã làm cho
     Foreground Service ở mục 5.42).
   - Thử dịch/tóm tắt 1 tài liệu dài, xác nhận có hộp thoại chỉnh prompt
     trước khi chạy (mục 5.55).
2. **Nếu build.yml fail ở bước copy QNN** (mục 5.58, giờ dừng cứng thay
   vì im lặng): đọc log lỗi cụ thể — đường dẫn thư mục thật trong QNN SDK
   Community có thể khác giả định `aarch64-android/`/`hexagon-v68/unsigned/`,
   cần đối chiếu lại (chỉ ảnh hưởng nếu người dùng bật thử
   `backendPreference=3`, không ảnh hưởng đường chính GPU).
3. **`GenerationService` chưa khai báo Manifest (mục 5.42) — vẫn CHƯA
   build/test riêng biệt**, dù đã chạy nhiều lần trong lúc debug các lỗi
   khác không thấy báo lỗi cụ thể liên quan — rủi ro đã giảm nhưng chưa
   xác nhận dứt điểm bằng phép thử riêng (tắt màn hình giữa lúc sinh văn
   bản dài, xem đồng hồ có dừng không).
4. **TẤT CẢ 6 tính năng ở mục 4.10-4.15** (version snapshot, tìm kiếm,
   glossary, Story Bible nâng cao, EPUB, backup/restore) — vẫn CHƯA
   build/test lần nào kể từ khi viết, nhiều phiên gần đây tập trung vá
   lỗi native/crash/UX, chưa quay lại kiểm tra các tính năng Dart-only
   này.
5. Sau khi các mục trên ổn định: **tóm tắt phân tầng đệ quy** (giá trị
   cao nhất cho truyện dài, nhưng CHỈ sau khi đọc được `llm.hpp` thật kỹ
   hơn nếu cần quản lý KV cache, mục 5.10) → provider "GPU ngoài" + ẩn
   danh hoá thực thể (mục 5.47, đã hoãn có chủ đích) → Scene/Corkboard/
   TTS/đọc PDF-DOCX-ảnh (vẫn hoãn, xem lý do ở mục 6).
6. **Bài học quy trình quan trọng nhất phiên này**: (a) khi build "thành
   công", KHÔNG được coi là đã xác nhận tính năng hoạt động — phải tự tay
   MỞ APP, THỬ TỪNG TÍNH NĂNG THẬT; (b) khi 1 giả thuyết kỹ thuật nghe rất
   hợp lý (vd "chip đủ mạnh nên NPU phải chạy được") vẫn PHẢI đối chiếu với
   tài liệu/yêu cầu tối thiểu CHÍNH THỨC của nhà sản xuất trước khi tiếp
   tục đầu tư công sức vá lỗi — mục 5.52 tiết kiệm được rất nhiều vòng
   debug vô ích nếu được tra cứu sớm hơn; (c) mọi bản vá liên quan tới
   `BuildContext`/`InheritedWidget` (`.of(context)`) phải tự kiểm tra kỹ
   context nào đang thực sự được dùng nằm ở đâu trong cây widget — 1 bản
   vá tưởng đơn giản (mục 5.48) đã tự gây ra 1 bug nghiêm trọng hơn (mục
   5.49) ngay trong cùng 1 phiên vì bỏ qua bước này.

---

**Cập nhật (2026-08-21 — schema v12→v13: cài đặt "Tóm tắt cốt truyện" chuyển
sang riêng từng truyện + nguồn nén rẻ hơn từ Dòng thời gian/outline)**:

Theo 2 câu hỏi người dùng đặt ra ở cuối phiên trước ("cài đặt riêng từng
truyện hay chung cả app?" và đề xuất "đồng bộ theo hướng bible: xong 1
chương thì Timeline tạo sự kiện, từ đó cập nhật cốt truyện; hoặc dựa vào
outline/dàn ý của chương nếu có"):

1. **4 cài đặt của tính năng "Tự tóm tắt cốt truyện luỹ kế" chuyển từ
   SharedPreferences (chung TOÀN APP) thành cột riêng của bảng `novels`**
   (`plot_summary_enabled`, `plot_summary_interval`, và 2 cột MỚI
   `plot_summary_prefer_timeline`/`plot_summary_prefer_outline`) — lý do:
   chiến lược đồng bộ hợp lý cho 1 truyện (vd truyện chuyển cảnh nhanh cần
   giãn cách ngắn) không nhất thiết hợp cho truyện khác đang mở song song.
   `_migrateToV13` (database_service.dart) đọc lại 2 giá trị SharedPreferences
   CŨ đúng 1 lần lúc migrate DB, sao chép làm giá trị khởi tạo cho MỌI
   truyện đã có sẵn — không làm mất cài đặt người dùng cũ đang dùng. 2 cột
   mới không có tiền lệ cũ, mặc định BẬT (rủi ro thấp — chỉ tận dụng dữ
   liệu ĐÃ CÓ SẴN, không tự tạo gì mới). `GenerationSettingsScreen` giờ bắt
   buộc nhận `novelId` (đọc/ghi qua `DatabaseService`, không qua
   `SettingsService` nữa cho riêng 4 mục này — 5 tham số sinh văn bản khác
   ở trên vẫn CHUNG toàn app như cũ, đúng bản chất tài nguyên máy).
2. **`RagService._doUpdateCumulativeStorySummary` — thêm chuỗi ưu tiên
   nguồn RẺ HƠN thay vì luôn đọc lại nội dung/autoSummary đầy đủ mỗi
   chương**: (a) sự kiện Timeline của đúng chương đó nếu ĐÃ có sẵn (nhập
   tay hoặc "AI gợi ý") — mô tả cái ĐÃ xảy ra thật, đã lọc qua Bible, 0 chi
   phí AI thêm để lấy; (b) nếu Timeline rỗng, dùng `Chapter.outline` nếu có
   và người dùng đã bật — rẻ NHẤT (viết trước khi chương tồn tại) nhưng là
   KẾ HOẠCH, có thể lệch với văn bản thật đã "đắp thịt" nên luôn xếp SAU
   Timeline; (c) fallback cuối cùng: autoSummary/excerpt nội dung chương
   (hành vi cũ, không đổi). **Không tự động tạo Timeline event mới ở bước
   này** — nếu tự tạo sẽ lại tốn 1 lượt gọi AI, triệt tiêu chính mục đích
   "rẻ hơn"; muốn có Timeline, người dùng tự bấm "AI gợi ý" (mục 4.13 hoặc
   tab Dòng thời gian) hoặc tự nhập tay, độc lập với luồng viết chương.
3. **TRẠNG THÁI BUILD/TEST**: đổi thuần Dart + 1 cột SQLite mới (ADD COLUMN,
   không đụng cấu trúc bảng nào khác), rủi ro build thấp hơn các mục
   native/JNI ở các phiên trước — nhưng **CHƯA build/test thật lần nào**,
   đặc biệt cần xác nhận: (a) nâng cấp từ bản DB v12 → v13 không mất cài
   đặt tóm tắt cũ đang dùng; (b) tạo chương có sẵn Timeline/outline thật sự
   dùng đúng nguồn đó (xem qua log debug, không chỉ tin suy luận); (c) 2
   switch mới ẩn/hiện đúng trong `GenerationSettingsScreen` khi
   `plotSummaryEnabled` bật/tắt.
4. **CHƯA làm** (đã nêu nhưng ngoài phạm vi phiên này): tóm tắt phân tầng
   đệ quy thật (mục 2.5, "hierarchical merging" — Chang et al. 2023) vẫn là
   GAP hợp lệ cho truyện thật dài (nghìn chương); AI KHÔNG tự động tạo
   Timeline event ngay sau khi chương hoàn thành (có chủ đích, xem lý do
   "rẻ hơn" ở mục 2 trên) — nếu về sau người dùng muốn luồng này TỰ ĐỘNG
   (đánh đổi lại chi phí AI để đổi lấy Timeline luôn đầy đủ), cần 1 công
   tắc riêng, rõ ràng là BẬT SẼ TỐN THÊM, không gộp ngầm vào tính năng này.

---

**Cập nhật (2026-08-21, phiên 2 — rà soát "chưa nối dây"/"chỉ mã bề ngoài" +
huỷ giữa chừng khi stream + màn Tác vụ nền toàn app):**

Theo yêu cầu người dùng "kiểm tra tính năng nào có UI nhưng không hoạt
động, tính năng nào có UI nhưng chỉ là mã bề ngoài, tài liệu và code đồng
bộ chưa" — rà soát bằng cách đối chiếu MỌI hàm public ở tầng `services/`
với nơi thực sự gọi nó (không chỉ đọc lướt code), phát hiện + xử lý:

1. **`AIProvider.isReady()`** — khai báo ở interface, CẢ 3 provider implement,
   nhưng **0 nơi gọi trong toàn app**. Đã gọi tại ĐÚNG 1 điểm duy nhất —
   `SettingsService.currentProvider()` (nơi MỌI màn hình lấy provider đang
   active) — throw thông báo cụ thể (thiếu API key / thiếu đường dẫn model)
   thay vì để lỗi HTTP/native thô rơi ra tận màn hình.
2. **`BackgroundTaskManager.requestCancel()`/`clearFinished()`/`tasks`** — đã
   có sẵn, comment ghi rõ ý định dùng cho UI "Huỷ"/"Xoá lịch sử", nhưng
   KHÔNG CÓ màn hình nào gọi tới. Đã thêm `BackgroundTasksScreen` (màn "Tác
   vụ nền" — vào từ Cài đặt, có badge số lượng realtime) làm điểm truy cập
   DUY NHẤT, DÙNG CHUNG cho mọi loại nhiệm vụ nền (chat/tạo chương hàng
   loạt/tài liệu) — sống độc lập với màn hình đã tạo ra nhiệm vụ, đúng tinh
   thần thiết kế gốc của `BackgroundTaskManager`.
3. **Huỷ giữa chừng LÚC ĐANG STREAM** (theo câu hỏi người dùng: "phải đợi
   tạo xong toàn bộ rồi mới hủy?") — TRƯỚC bản vá này, đúng là gần như vậy:
   nút Huỷ (nếu có) chỉ chặn được việc THẢ THÊM chương mới vào hàng đợi,
   KHÔNG dừng được chương ĐANG stream dở (`isCancelled` chỉ được kiểm tra
   GIỮA 2 chương). Đã thêm tham số `isCancelled` vào
   `TranslationService.generateResumableWithOptionalTranslation()` — kiểm
   tra ngay sau MỖI đoạn chunk nhận được từ stream, huỷ được đúng
   giữa chừng 1 chương, không cần đợi nó viết xong. `ChapterBatchService`
   giờ gắn `onCancelRequested` cho TỪNG chương (mỗi chương = 1
   `BackgroundTask` độc lập) khi thả vào `BackgroundTaskManager` — nghĩa là
   từ màn "Tác vụ nền" (mục 2), có thể huỷ ĐÚNG 1 chương cụ thể đang chạy
   dở, kể cả sau khi đã rời màn "Tạo hàng loạt". Checkpoint được lưu tại
   ĐÚNG điểm dừng (không mất phần đã sinh), chương đó coi như "chưa xong",
   resume đúng chỗ gãy nếu tạo lại sau — KHÔNG bị tính là lỗi/bất thường
   (không chặn các chương khác đang chạy song song).
   **Giới hạn còn lại (không giấu)**: đây là huỷ CHỦ ĐỘNG qua cờ kiểm tra
   định kỳ (điểm dừng an toàn gần nhất), không phải abort cứng ngay lập
   tức — nếu HTTP đang chờ phản hồi 1 chunk lớn, độ trễ huỷ thực tế bằng
   đúng thời gian chờ chunk đó. Nhánh LOCAL tuần tự và luồng chat/tài liệu
   CHƯA được nối `onCancelRequested` tương tự (chỉ mới làm cho batch remote
   — đúng phạm vi câu hỏi gốc của người dùng).
4. **Dọn code chết phát sinh từ chính lượt vá trước** (v13): 4 hàm
   `load/savePlotSummaryEnabled/Interval` ở `SettingsService` — comment cũ
   nói "giữ vì migration cần", nhưng migration thực đọc thẳng
   SharedPreferences bằng chuỗi, không hề gọi 4 hàm đó → code chết thật sự.
   Đã xoá.
5. **Tài liệu vs code lệch pha** — mục 6 (checklist) trước đó gộp chung 1
   dòng "Provider GPU ngoài (Colab) + lớp ẩn danh hoá" là "⬜ CHƯA code" —
   SAI MỘT NỬA: provider GPU ngoài đã xong và đang dùng thật (notebook
   Colab + `OpenAICompatibleProvider` + chạy song song qua
   `BackgroundTaskManager`), nhưng **lớp ẩn danh hoá thực thể (kế hoạch 5
   lớp mục 5.29 gốc) thì đúng là CHƯA có 1 dòng code nào** — đã tách 2 mục
   này ra đúng trạng thái thật, giữ nguyên cảnh báo rủi ro bảo mật (gửi
   nguyên văn tên riêng/nội dung truyện ra GPU remote/API, không qua ẩn
   danh) cho tới khi làm.
6. **Xác nhận với người dùng (không phải bug, là thiết kế đã có sẵn)**:
   streaming + checkpoint + resume cho GPU remote (mục 5.93, phần "GHI CHÚ"
   ở đầu `_generateBatchParallel`) **đã hoạt động từ trước phiên này** —
   `generateResumableWithOptionalTranslation()` nhận từng đoạn NGAY khi
   model sinh ra, lưu định kỳ vào `Chapter.generationCheckpoint`, nên GPU
   remote sập giữa chừng không mất trắng — resume đúng chỗ gãy ở lần chạy
   tiếp theo. Đây là câu trả lời cho câu hỏi người dùng "GPU remote có hoạt
   động như model local, sinh tới đâu lưu tới đó không" — CÓ, đã làm.
7. **CHƯA làm, người dùng đã yêu cầu, để phiên sau (phạm vi lớn, cần làm
   riêng để dễ soát lỗi — đúng bài học đã rút ra ở mục 5.71)**:
   - Mở rộng phạm vi "cài đặt riêng từng truyện" ra XA HƠN 4 cài đặt tóm
     tắt cốt truyện (v13) — người dùng nêu rõ: **provider/model đang dùng,
     và 5 tham số sinh văn bản (temperature...) cũng nên riêng từng truyện**,
     không dùng chung 1 giá trị cho mọi truyện (khác hẳn giả định BAN ĐẦU
     của kiến trúc gốc mục 2.1 — "model không phải nội dung truyện nên
     dùng chung" — người dùng phản đối giả định này, cần sửa lại).
   - **Sao lưu/khôi phục THEO TỪNG TRUYỆN** (khác `BackupService` hiện tại
     — CHỈ xuất/nhập TOÀN BỘ app, mọi truyện gộp chung 1 file) — người dùng
     yêu cầu xuất được 1 file/truyện, bao gồm MỌI bảng liên quan tới đúng
     truyện đó (chương, Bách khoa, chat, tài liệu, version snapshot...).
     Rà soát nhân tiện phát hiện: `DatabaseService._backupTables` (dùng cho
     backup TOÀN APP hiện tại) đang THIẾU 2 bảng — `embeddings` (vector RAG)
     và `pending_rewrites` (hàng đợi gợi ý sửa đang chờ duyệt) — khôi phục
     từ backup hiện tại sẽ mất 2 loại dữ liệu này dù không có thông báo gì.
     Cần sửa chung khi làm mục sao lưu theo truyện.

---

**Cập nhật (2026-08-21, phiên 3 — provider/model/tham số sinh văn bản
chuyển thành cài đặt riêng từng truyện, schema v14):**

Theo phản đối trực tiếp của người dùng với giả định gốc mục 2.1 ("model
không phải nội dung truyện nên dùng chung") — lý do thật: 1 truyện có thể
đang dùng model local nhẹ để viết nhanh, 1 truyện khác đang dùng GPU remote
mạnh hơn, tham số sinh văn bản (temperature...) cũng có thể cần khác nhau
giữa 2 truyện.

1. `Novel` (story_models.dart) thêm 8 cột mới: `providerType`,
   `activeLocalModelId`, `activeApiProviderId`, `genTemperature`, `genTopP`,
   `genTopK`, `genRepetitionPenalty`, `genMaxNewTokens`. `_migrateToV14`
   sao chép giá trị SharedPreferences CŨ vào MỌI truyện đã có (cùng cách
   làm với v13). Bảng `local_models`/`api_providers` (danh sách THẬT các
   model/API key đã cấu hình) **vẫn dùng chung toàn app** — chỉ CON TRỎ
   "truyện này đang chọn cái nào" mới tách riêng; 2 truyện có thể cùng trỏ
   tới 1 model, hoặc mỗi truyện trỏ 1 cái khác nhau.
2. `SettingsService.currentProvider()` giờ **bắt buộc nhận `novelId`** —
   đã cập nhật đủ ~14 nơi gọi trong app (`chapter_editor_screen.dart` dùng
   `widget.chapter.novelId`, các màn khác dùng `widget.novelId`,
   `background_task_manager.dart` — không gắn với truyện cụ thể nào vì là
   1 singleton dùng chung cho MỌI truyện — tạm dùng `loadActiveNovelId()`
   làm căn cứ, có ghi rõ giới hạn thật ở ngay trong code).
3. `SettingsScreen`/`GenerationSettingsScreen`/`TranslationSettingsScreen`/
   `LocalOptimizationScreen` đều nhận `novelId`, xuyên suốt từ `RootScreen`.
4. **CHƯA làm — người dùng đã nói rõ "mọi dữ liệu sau khi vào truyện cụ
   thể đó là cài đặt riêng của truyện đó, chứ không chỉ những dữ liệu đó
   thôi"** — nghĩa là còn phải mở rộng tiếp sang: cấu hình local
   (threads/context/gpu layers/backend preference), RAG budget, TOÀN BỘ
   cài đặt dịch thuật trung gian, và số nhiệm vụ song song GPU remote.
   **Cố tình để lại phiên sau** — lưu ý thật cần cân nhắc khi làm: 1 số cài
   đặt trong nhóm này (threads/gpu layers/backend preference) về bản chất
   là cấu hình PHẦN CỨNG của máy, không phải nội dung truyện — chuyển
   chúng thành riêng-từng-truyện có nghĩa là ĐỔI TRUYỆN sẽ có thể kéo theo
   NẠP LẠI model với cấu hình khác (tốn thời gian hơn hẳn so với chỉ đổi
   con trỏ "đang chọn model nào" như đã làm ở mục 1-3 trên) — cần người
   dùng xác nhận đã hiểu đánh đổi này trước khi làm, không tự ý làm ngầm.
5. **Yêu cầu MỚI, CHƯA làm, đã ghi nhận cho phiên sau**:
   - Sao lưu/khôi phục: **2 lựa chọn** (toàn app HOẶC theo từng truyện),
     không phải chỉ 1 trong 2 — khác với kế hoạch phiên 2 (chỉ thêm chọn
     theo truyện).
   - **Đổi cơ chế hiển thị của MỌI loại sinh văn bản** (tạo chương, tóm
     tắt, dịch...) sang kiểu như chat hiện tại — chữ hiện DẦN ngay khi
     model sinh ra, không đợi xong cả đoạn mới hiện — áp dụng CẢ cho GPU
     remote. Đi kèm: thanh tiến trình (batch/mọi tác vụ có tiến độ) chuyển
     từ hiện GIỮA màn hình sang 1 GÓC màn hình, không còn chặn xem chữ
     đang sinh ra. Đây là thay đổi UI/luồng dữ liệu LỚN, đụng tới
     `chapter_editor_screen.dart` (đắp thịt/viết tiếp), `chapters_batch_generate_screen.dart`,
     `document_screen.dart`/`document_chunks_screen.dart`, và cách
     `TranslationService`/`ChapterBatchService` phát dữ liệu ra UI (hiện
     đang stream ở tầng service NHƯNG UI tầng trên đang đợi cả khối/hiện
     qua callback tiến trình dạng số %, không đẩy TỪNG CHỮ ra UI) — cần 1
     phiên riêng để làm cho đúng, không lẫn với các việc khác.

---

**Cập nhật (2026-08-21, phiên 4 — TOÀN BỘ cài đặt còn lại chuyển thành
riêng từng truyện, schema v15):**

Người dùng xác nhận: "Tất cả (kể cả threads/gpu layers/backend thuần phần
cứng)" — đã cảnh báo trước về đánh đổi (đổi truyện có thể kéo theo nạp lại
model), người dùng chấp nhận. Đã chuyển NỐT toàn bộ nhóm cài đặt còn lại từ
SharedPreferences sang cột riêng của `novels` (16 cột mới): cấu hình local
(`localThreads`/`localContextSize`/`localGpuLayers`/`backendPreference`),
`ragBudgetChars`, toàn bộ 7 cài đặt dịch thuật trung gian
(`translationEnabled`/`translationModelPath`/`translationTargetLanguage`/
`translationStylePrompt`/`translationPromptToTarget`/`translationPromptFromTarget`/
`translationKeepResidentMode`), `maxParallelRemoteTasks`, và 3 cài đặt xử
lý tài liệu (`docTranslatePrompt`/`docSummarizePrompt`/`docModelChoice`).
`_migrateToV15` sao chép giá trị SharedPreferences CŨ vào MỌI truyện đã có
(cùng cách làm v13/v14).

**Thay đổi cấu trúc quan trọng đi kèm** (không chỉ thêm cột, còn phải sửa
LOGIC vì hệ quả thật của việc hardware-setting giờ theo truyện):
- `LocalLlamaProvider` thêm field `novelId` (nullable — slot dịch thuật đôi
  khi được tạo mà chưa rõ truyện nào, rơi về `loadActiveNovelId()`) để tự
  đọc đúng `backendPreference` của truyện đang phục vụ khi `ensureLoaded()`.
- **Bug thật đã bắt được TRƯỚC KHI xảy ra** (rà soát kỹ trước khi coi là
  xong): cache provider local trong `SettingsService._buildProvider()` TRƯỚC
  ĐÂY khoá theo model path — nếu giữ nguyên, 2 truyện cùng chọn 1 model
  nhưng khác `backendPreference` sẽ ĐEM NHẦM backend của truyện này sang
  truyện kia (vì `ensureLoaded()` chỉ gọi lại `loadModel` native khi model
  CHƯA `_loaded`, không kiểm tra `backendPreference` có đổi hay không). Đã
  sửa: khoá cache theo cặp `(path, novelId)` — 2 truyện cùng model giờ nạp
  riêng (đúng chấp nhận đánh đổi ở trên), backend không còn lẫn.
- `TranslationService` thêm field bắt buộc `novelId` ở constructor — đã cập
  nhật toàn bộ ~11 nơi tạo `TranslationService(...)` trong app.
  `StyleService.analyzeStyleFromSample()`/`document_service.dart._generateChunk()`
  thêm tham số `novelId`/`required String novelId` tương ứng.
- `BackgroundTaskManager._currentConcurrencyCap()` giờ dùng
  `loadMaxParallelRemoteTasks(activeNovelId)` — cùng cơ chế suy ra "truyện
  đang mở" đã dùng cho `currentProvider()` ở phiên 3, GIỚI HẠN THẬT tương tự
  đã ghi ở đó vẫn áp dụng.

**Trạng thái**: cân bằng ngoặc toàn bộ project, quét sạch mọi lời gọi thiếu
`novelId` (không còn hàm nào trong `SettingsService` liên quan tới cài đặt
đọc/ghi SharedPreferences cho các nhóm đã chuyển). **CHƯA build/test thật.**

---

**Cập nhật (2026-08-21, phiên 5 — sao lưu theo từng truyện + hiện chữ dần
khi sinh văn bản + thanh tiến trình dời ra góc màn hình):**

Theo 2 yêu cầu người dùng: "sao lưu thì nên có 2 lựa chọn là sao lưu toàn
app hay sao lưu từng truyện" và "toàn bộ việc tạo chương, tóm tắt, dịch...
đều như chat là sinh ra chữ nào thì hiện chữ đó trên màn hình... thanh tiến
trình đó thay vì hiện giữa màn hình thì bây giờ hiện ở góc — áp dụng cả
cho GPU remote".

**1. Sao lưu theo từng truyện:**
- `DatabaseService.exportNovelData(novelId)`/`importNovelData(data)` mới —
  lọc đúng dữ liệu 1 truyện qua MỌI bảng liên quan, kể cả 3 bảng KHÔNG có
  cột `novel_id` trực tiếp (`document_chunks` lọc qua `document_id`,
  `chat_messages` lọc qua `session_id`, `embeddings` lọc qua `entity_id` +
  `entity_type`).
- Tiện thể rà soát lại phát hiện `_backupTables` (backup TOÀN APP) THIẾU 2
  bảng `pending_rewrites`/`embeddings` từ trước — đã bổ sung, backup toàn
  app từ giờ đầy đủ hơn (backup cũ vẫn khôi phục bình thường, chỉ đơn giản
  thiếu 2 loại dữ liệu đó).
- `BackupService`: `exportBackup()` (toàn app) và `exportNovelBackup(novelId, title)`
  (1 truyện) — file JSON có thêm `scope` ('app'/'novel') để bên đọc tự nhận
  diện, không đoán mò. `BackupRestoreScreen` giờ có 2 nút sao lưu riêng, hộp
  thoại xác nhận khôi phục tự đổi nội dung theo scope, CẢNH BÁO RÕ nếu
  truyện trong file backup ('novel') trùng id với truyện đã có trên máy —
  khôi phục sẽ GHI ĐÈ đúng truyện đó (không tạo id mới — theo đúng cách
  `importAllData`/`importNovelData` đã làm từ trước, giữ nhất quán 1 kiểu
  hành vi "ghi đè theo id" xuyên suốt app, không phát minh thêm 1 kiểu mới
  chỉ cho tính năng này).

**2. Hiện chữ dần khi sinh văn bản (giống chat) + progress dời ra góc:**
- `chapter_editor_screen.dart` ("Viết tiếp"/"Đắp thịt"): khi dịch thuật
  trung gian TẮT (mặc định), giờ bỏ qua `TranslationService` và stream
  trực tiếp từ provider — CÙNG NHÁNH NHANH `chat_screen.dart` đã dùng —
  chữ hiện thẳng vào ô nội dung chương ngay khi model sinh ra. Màn này
  TRƯỚC ĐÓ đã không dùng dialog chặn (chỉ có `aiStage` inline nhỏ), nên
  không cần dời gì, chỉ thêm phần hiện chữ dần.
- `chapters_batch_generate_screen.dart`: **bỏ hẳn** `AlertDialog`
  (`barrierDismissible: false`) từng chặn giữa màn hình — thân màn hình
  trong lúc chạy đổi sang hiện TRỰC TIẾP văn bản đang sinh của TỪNG chương
  (có thể NHIỀU chương cùng lúc nếu là GPU remote — mỗi chương 1 thẻ cuộn
  riêng), tiến trình TỔNG dời xuống 1 thẻ nhỏ ở góc dưới phải. `ChapterBatchService`
  thêm `currentText`/`currentChapterId` vào callback `onProgress` để UI biết
  ĐÚNG chương nào đang gửi chữ gì (quan trọng khi nhiều chương chạy song
  song — không thể chỉ có 1 giá trị "text hiện tại" dùng chung).
- `document_screen.dart`: cùng cách — bỏ `AlertDialog`, dời thẻ tiến trình
  ra góc dưới phải. **CHƯA làm hiện chữ dần cho tài liệu** (mỗi đơn vị xử
  lý là 1 đoạn ngắn, hoàn thành nhanh — ưu tiên thấp hơn phần dời thanh
  tiến trình, đã làm xong phần đó).
- **GIỚI HẠN THẬT đã có từ trước, không đổi** (đã ghi rõ ở
  `chat_screen.dart` gốc, nay lặp lại ở `chapter_editor_screen.dart`): khi
  dịch thuật trung gian BẬT, không stream được — dịch câu vào/model
  sinh/dịch câu ra là 3 lượt AI tuần tự, vẫn hiện theo giai đoạn (`aiStage`)
  như cũ. Nhánh LOCAL tuần tự của tạo chương hàng loạt (`_generateBatchSequential`)
  CHƯA có `currentText`/`currentPercent` — cố tình KHÔNG đổi (mục 5.67, lý
  do an toàn crash) — bất đối xứng với nhánh REMOTE giống hệt `currentPercent`
  đã có từ trước.

**Trạng thái**: cân bằng ngoặc toàn bộ project. **CHƯA build/test thật** —
đặc biệt cần xác nhận: (a) khôi phục 1 truyện từ backup không làm hỏng dữ
liệu của các truyện khác trên máy; (b) chữ hiện dần trong "Viết tiếp"/"Đắp
thịt" không bị giật/lag khi model sinh nhanh (nhiều lần setState liên tiếp);
(c) nhiều thẻ chương chạy song song trong "Tạo hàng loạt" hiện đúng, không
lẫn text của nhau.

---

**Cập nhật (2026-08-22, phiên 6 — sửa 2 "giới hạn thật" ghi sai ở phiên 5,
theo phản biện đúng của người dùng):**

Người dùng chỉ ra 2 điểm ở phiên 5 mà Claude tự nhận là "giới hạn thật"
thực ra là kết luận SAI/thiếu suy xét, không phải giới hạn kỹ thuật có
thật — cả 2 đã được sửa tận gốc:

1. **"Dịch thuật trung gian bật thì không stream được"** — SAI. Đường ống 3
   bước (dịch câu vào → model chính sinh → dịch câu ra) chỉ có bước GIỮA
   không hiện ra màn hình (chỉ là ngữ cảnh cho model), còn bước DỊCH NGƯỢC
   (bước 3) MỚI là văn bản người dùng thực sự nhìn thấy — và bước đó chạy
   trên `LocalLlamaProvider` (model dịch nhỏ), vốn dĩ đã hỗ trợ
   `generateStream()` y hệt model chính, không có lý do kỹ thuật nào để
   không stream được. Đã sửa: `TranslationService.translate()` thêm tham
   số `onChunk` tùy chọn (stream khi có, gọi `generate()` thường khi
   không); `generateWithOptionalTranslation()`/`generateResumableWithOptionalTranslation()`
   truyền `onChunk`/`onTranslatedChunk` xuống đúng bước dịch ngược. Nhánh
   TẮT dịch thuật cũng được nâng cấp tương tự (trước đó vẫn gọi
   `mainProvider.generate()` không streaming ngay cả khi tắt — bất nhất
   với cách `chapter_editor_screen.dart` đã tự bypass streaming trực tiếp).
   Kết quả: `chapter_editor_screen.dart`/`chat_screen.dart` giờ gọi THẲNG
   `generateWithOptionalTranslation(..., onChunk: ...)` cho CẢ 2 trường hợp
   bật/tắt dịch thuật — không cần nhánh rẽ/bypass riêng như trước, code gọn
   hơn HẲN so với phiên 5 (tự nó là bằng chứng "giới hạn" trước đó chỉ là
   thiếu nhìn kỹ, không phải rào cản thật).
2. **"Batch local không thêm live text vì lo crash 2 lệnh generate chạy
   chồng chéo (mục 5.67)"** — NHẬN ĐỊNH NHẦM LẪN 2 VIỆC KHÁC NHAU. Mục 5.67
   nói về việc ĐỔI CẤU TRÚC CHẠY (chạy song song thay vì tuần tự — tăng số
   lệnh generate() ĐANG CHẠY CÙNG LÚC), không liên quan gì tới việc thêm 1
   callback QUAN SÁT THỤ ĐỘNG (`onChunk`) lên 1 lệnh generate() VỐN DĨ đã
   chạy tuần tự (vòng `for` vẫn `await` xong chương này mới sang chương kế
   — không đổi). Đã sửa: `_generateBatchSequential` (nhánh LOCAL) giờ CŨNG
   có live text qua `onChunk`, xoá bất đối xứng vô lý với nhánh REMOTE.
   Phần checkpoint/resume khi crash (khác với live text — đây là việc LƯU
   TẠM xuống DB để phục hồi) VẪN chỉ ở nhánh REMOTE — đây MỚI là giới hạn
   thật (model LOCAL "sập" thường kéo theo crash cả tiến trình Dart đang
   giữ checkpoint, remote thì GPU chết nhưng app điện thoại vẫn sống) —
   không đổi, không liên quan gì tới việc vừa sửa.

**Bài học rút ra** (tự phê bình, ghi lại để không lặp lại): khi tự đánh giá
"limitation" trước khi người dùng hỏi lại, cần THỬ TÌM CÁCH GIẢI QUYẾT
TRƯỚC, không chỉ liệt kê lý do rồi dừng — cả 2 "giới hạn" ở phiên 5 đều
xuất phát từ việc dừng phân tích quá sớm, không truy tới tận gốc xem có
thật sự không giải quyết được không.

**Trạng thái**: cân bằng ngoặc toàn bộ project. **CHƯA build/test thật** —
đặc biệt cần xác nhận: (a) stream bước dịch ngược trong `translate()` hoạt
động đúng qua `LocalLlamaProvider.generateStream()` (chưa từng gọi
generateStream trên model dịch trước đây, chỉ gọi generate() thường); (b)
UI batch local hiện chữ dần mượt, không giật khi kèm cả `LocalLlamaProvider.updatePipelineStage()`
gọi song song trong cùng vòng lặp.

---

**Cập nhật (2026-08-22, phiên 7 — tài liệu cũng hiện chữ dần, cho NHẤT
QUÁN 100% với mọi màn sinh văn bản khác):**

Người dùng phản đối trực tiếp quyết định "ưu tiên thấp hơn" ở phiên 5 cho
xử lý tài liệu ("sao lì lợm dữ vậy, các màn hình AI tạo sinh văn bản đều
làm theo dạng chữ xuất hiện từng chữ 1 hết chứ") — đúng, "mỗi đoạn ngắn nên
ưu tiên thấp" không phải lý do kỹ thuật, chỉ là lựa chọn dừng sớm không cần
thiết. Đã sửa hết:

- `_generateChunk` (document_service.dart) thêm `onChunk` — hành động
  "Tóm tắt" đã qua `TranslationService.generateWithOptionalTranslation`
  (tự hỗ trợ `onChunk` từ phiên 6) nên chỉ cần truyền xuống; hành động
  "Dịch" (cố tình KHÔNG qua `TranslationService`, xem comment gốc đầu file
  — lý do NGÔN NGỮ, không liên quan gì tới streaming) đổi từ
  `provider.generate()` sang `provider.generateStream()` — cùng 1
  interface `AIProvider`, đổi đúng 1 chỗ.
- `onProgress` (cả `DocumentService`/UI) thêm `currentText`/`currentChunkId`
  — CÙNG QUY ƯỚC hệt `ChapterBatchService` (mục 5, phiên 5): text rỗng/null
  = đoạn đó vừa xong/lỗi, bỏ khỏi danh sách "đang chạy".
- `document_screen.dart`: thêm panel hiện chữ đang sinh của (các) đoạn
  đang chạy — CHÈN THÊM phía trên danh sách tài liệu (không thay thế hẳn,
  khác chapters_batch_generate_screen.dart — ở đây người dùng có thể vẫn
  cần thấy các tài liệu KHÁC trong lúc 1 tài liệu đang xử lý), cao tối đa
  35% màn hình, tự cuộn. Thẻ góc dưới phải giữ nguyên (đã làm ở phiên 5).
- Nhánh LOCAL tuần tự CŨNG có live text (không có lý do gì để bất đối xứng
  với remote — cùng bài học "quan sát thụ động ≠ đổi cấu trúc chạy" đã rút
  ra ở phiên 6 cho `ChapterBatchService`).

Tới đây, MỌI nơi trong app gọi model sinh văn bản Việt (chat, viết chương,
tạo hàng loạt, dịch/tóm tắt tài liệu) đều hiện chữ dần khi có thể về mặt kỹ
thuật — giới hạn CÒN LẠI DUY NHẤT là "kiểm tra tính nhất quán"/"tóm tắt
chương"/1 số tác vụ nội bộ ngắn khác gọi `generateWithOptionalTranslation`
KHÔNG truyền `onChunk` (không hiện lên UI dạng chữ chạy vì bản thân UI đó
chỉ hiện 1 dòng kết quả ngắn/không phải ô văn bản lớn — không phải giới
hạn kỹ thuật, mà là các UI đó chưa cần thiết kế lại dạng "khung lớn hiện
chữ chạy" cho 1 câu trả lời ngắn).

**Trạng thái**: cân bằng ngoặc toàn bộ project. **CHƯA build/test thật.**

---

**Cập nhật (2026-08-22, phiên 8 — lỗi build THẬT từ CI, xác nhận có lệch
pha thật giữa "đã sửa" và "đã sửa ĐỦ"):**

Người dùng hỏi thẳng "tài liệu kỹ thuật đã đồng bộ với code chưa hay có sự
lệch pha" — trong lúc đang tra soát để trả lời, người dùng dán log build
GitHub Actions THẤT BẠI THẬT:

```
lib/screens/document_chunks_screen.dart:149:21: Error: The argument type
'void Function(int, int)' can't be assigned to the parameter type
'void Function(int, int, {String? currentChunkId, String? currentText})?'.
```

**Nguyên nhân**: `document_chunks_screen.dart` — 1 màn hình RIÊNG (xử lý
từng đoạn được CHỌN RIÊNG RẼ của 1 tài liệu, khác `document_screen.dart` xử
lý theo PHẠM VI liên tục) — dùng chung `DocumentService.processDocument()`
nhưng bị BỎ SÓT hoàn toàn ở phiên 7 khi thêm `currentText`/`currentChunkId`
vào chữ ký `onProgress`. Phiên 7 chỉ rà soát "callback dùng chung" bằng
cách xem lại các file ĐÃ ĐỘNG TỚI gần nhất (`document_service.dart`,
`document_screen.dart`) — không `grep` lại TOÀN BỘ project theo ĐÚNG TÊN
HÀM `processDocument`/`onProgress` — nên bỏ sót đúng 1 file có cùng cách
dùng nhưng chưa từng được sửa ở các phiên trước (dùng dialog chặn CŨ,
chưa bao giờ được nâng cấp lên corner-progress như 2 màn kia).

**Đã sửa**: nâng `document_chunks_screen.dart` lên ĐÚNG cùng pattern đã áp
dụng cho `document_screen.dart` (bỏ `AlertDialog` chặn, thêm panel chữ chạy
dần + thẻ tiến trình góc dưới phải) — không chỉ vá cho qua lỗi build.

**Trả lời thẳng câu hỏi "đồng bộ chưa"**: KHÔNG — vừa có bằng chứng cụ thể
(lỗi build thật) rằng "đã rà soát" ở các phiên trước KHÔNG đồng nghĩa
"rà soát đủ". Đã kiểm lại toàn bộ 3 nơi gọi `DocumentService.processDocument()`/
`ChapterBatchService.generateBatch()` trong app bằng `grep -rn "onProgress: ("`
— xác nhận cả 3 (`chapters_batch_generate_screen.dart`,
`document_chunks_screen.dart`, `document_screen.dart`) giờ khớp đúng chữ ký
mới. Cân bằng ngoặc lại toàn bộ project.

**Bài học rút ra (lần 2 — nghiêm trọng hơn lần trước vì lần này là lỗi
build thật, không phải chỉ nhận định sai)**: đổi CHỮ KÝ của 1 hàm/callback
DÙNG CHUNG (không riêng của 1 màn hình) bắt buộc phải `grep` lại theo ĐÚNG
TÊN HÀM trên TOÀN BỘ `lib/`, không được giới hạn phạm vi rà soát theo "các
file vừa sửa trong phiên này" — 2 màn hình cùng gọi 1 hàm có thể được viết
ở 2 thời điểm khác nhau, sửa 1 màn không có nghĩa màn kia đã được cập nhật
theo.

---

**Cập nhật (2026-08-23, phiên 9 — TÌM RA NGUYÊN NHÂN GỐC "máy nóng, chờ
lâu, chat không sinh chữ": WakeLock có khoảng hở, thiết bị ngủ sâu giữa
chừng lúc đang sinh văn bản):**

Log lần 2 (đã có timestamp mới ở cả tầng C++/Kotlin, xem phiên 8) cho thấy
điều bất ngờ: KHÔNG có khoảng hở nào giữa lúc native báo xong và lúc
Kotlin/Dart nhận được (`onToken`/`nativeGenerate() TRA VE XONG` đều lệch
nhau <1ms) — giả thuyết "main thread bị nghẽn" ở phiên 8 SAI. Nguyên nhân
thật nằm ở CHỖ KHÁC: `THOI GIAN THAT (ms)=73487` (đo bằng `std::chrono::steady_clock`,
map tới `CLOCK_MONOTONIC` trên Android — **KHÔNG đếm thời gian lúc thiết bị
ngủ sâu**) lệch ~379 GIÂY so với thời gian tường thật giữa 2 mốc log (đo
bằng `system_clock`, CÓ đếm cả lúc ngủ sâu). Nghĩa là: **thiết bị đã ngủ
sâu ~379 giây NGAY GIỮA LÚC đang sinh văn bản**, dù `PARTIAL_WAKE_LOCK` +
`startForeground` đáng lẽ phải ngăn việc này.

**Nguyên nhân gốc tìm thấy trong code**: `GenerationService.start()`/`.stop()`
(gọi từ `beginPipeline`/`loadModel`/`generate` trong `MnnBridge.kt`) chỉ
`mainHandler.post{}` (ĐẨY việc vào hàng đợi main thread rồi TRẢ VỀ NGAY,
KHÔNG ĐỢI `onStartCommand()` của `GenerationService` thật sự chạy xong và
giữ được WakeLock). Có 1 KHOẢNG HỞ THẬT giữa lúc `nativeGenerate()`/
`nativeLoadModel()` BẮT ĐẦU chạy (trên coroutine, gần như ngay lập tức) và
lúc WakeLock của `GenerationService` THỰC SỰ được giữ (phụ thuộc main
thread Looper xử lý xong Intent đã post) — nếu màn hình vừa tắt/máy vừa
chuyển nền ĐÚNG vào khoảnh khắc đó, hệ điều hành có thể bắt đầu ngủ sâu
TRƯỚC KHI WakeLock kịp giữ, và một khi đã ngủ, chính việc xử lý Intent
đang chờ trên hàng đợi main thread cũng bị đóng băng theo — vòng luẩn quẩn
không tự thoát ra được cho tới "cửa sổ bảo trì" định kỳ tiếp theo của
Doze/App Standby.

**Đã sửa tận gốc**: thêm 1 `PowerManager.WakeLock` TRỰC TIẾP trong chính
`MnnBridge.kt` (`directWakeLock`), giữ NGAY TRONG cùng khối `synchronized`
dùng để tăng/giảm `pipelineDepth` (cho `beginPipeline`/`endPipeline`) hoặc
ngay tại điểm quyết định "lệnh độc lập" (cho `loadModel`/`generate` gọi
không qua pipeline) — ĐẢM BẢO KHÔNG CÓ khoảng hở nào giữa lúc quyết định
bắt đầu 1 phiên sinh và lúc WakeLock thực sự được giữ, không phụ thuộc vào
việc main thread xử lý Intent kịp hay không. `GenerationService` (thông
báo + WakeLock riêng, tự làm mới mỗi 30 phút) vẫn giữ nguyên làm lớp bảo vệ
THỨ 2 cho phiên chạy DÀI — WakeLock trực tiếp chỉ là lớp bảo vệ TỨC THỜI
cho đúng khoảng hở khởi động (giữ tối đa 40 phút/lần, không tự làm mới,
không cần vì đến lúc đó `GenerationService` đã chắc chắn chạy xong).

**Đã thêm** (để lần sau — nếu còn xảy ra — chẩn đoán được ngay trong 1 dòng
log): `nativeGenerate()` giờ đo CẢ `steady_clock` lẫn `system_clock` song
song quanh `llm->response()`, in luôn chênh lệch — nếu > 3 giây, tự in cảnh
báo rõ ràng "RẤT CÓ THỂ máy đã ngủ sâu giữa chừng" ngay trong log, không
cần tự trừ tay 2 timestamp ở 2 dòng khác nhau như trước.

**Phát hiện thêm (riêng, chưa sửa)**: kết quả dịch systemPrompt trong log
vẫn cho thấy dấu hiệu model dịch 1.8B ĐANG DỊCH NHẦM CHÍNH CÂU LỆNH thay vì
nội dung được giao (kết quả = bản tiếng Anh của chính prompt hướng dẫn, không
phải bản tiếng Anh của nội dung Story Bible cần dịch) — lỗi CHẤT LƯỢNG
riêng, không liên quan tốc độ/WakeLock, cần điều tra thêm ở phiên sau (có
thể do model quá nhỏ để tách biệt "hướng dẫn" khỏi "nội dung", hoặc cần
format prompt rõ ràng hơn — vd bọc nội dung cần dịch trong dấu ngoặc kép/
markdown code block để model phân biệt rõ hơn).

**QNN .so vẫn thiếu ở lần chạy build gần nhất** (log runtime lần 2 vẫn báo
UnsatisfiedLinkError cho cả 5 file) — vẫn đang chờ log đầy đủ của bước
"Đặt file .so vào đúng chỗ..." (có in cấu trúc thư mục thật của QNN SDK) để
xác định đúng đường dẫn cần sửa trong `build.yml`.

**Trạng thái**: cân bằng ngoặc cả Dart lẫn native (C++/Kotlin, đã kiểm tra
comment-aware, không chỉ đếm ký tự thô). **CHƯA build/test thật trên thiết
bị** — đặc biệt cần xác nhận: WakeLock trực tiếp mới thêm có thực sự ngăn
được ngủ sâu giữa chừng hay không (chỉ xác nhận được qua chạy lại thật, xem
log có còn dòng "CHENH LECH...ms" hay không).

---

**Cập nhật (2026-08-23, phiên 10 — thêm chẩn đoán chi tiết cho lỗi load()
FALSE của model 8B, không cần PC/adb):**

Người dùng đã tự tay đổi tên `llm_config.json` → `config.json` theo đúng
gợi ý của 1 bên phân tích khác — **KHÔNG hết lỗi**, `load()` vẫn trả FALSE
cho cả OpenCL lẫn CPU, và fail trong **~1 mili giây** (giữa lúc
`createLLM()` xong và `load() FALSE` chỉ cách nhau 1ms) — quá nhanh để là
lỗi đọc dở file weight 4GB, nhiều khả năng fail ngay ở bước kiểm tra đầu
(tên file tham chiếu bên trong config không khớp file thật, hoặc file bị
thiếu/hỏng) — nhưng KHÔNG có cách xác nhận chắc chắn nếu không thấy được
nội dung `config.json` ĐANG DÙNG đối chiếu với file THẬT trong thư mục.

Người dùng không có PC/adb để lấy `logcat` thật — đã thêm 2 hàm chẩn đoán
mới vào `mnn_bridge.cpp`, chạy TRƯỚC MỌI lần gọi `Llm::createLLM()` (không
chỉ khi nghi lỗi, vì lỗi không đoán trước được lúc nào xảy ra):

1. `logConfigDiagnostics()` — in TOÀN BỘ nội dung `config.json` ĐANG ĐƯỢC
   DÙNG (tối đa 3000 ký tự) thẳng vào `native_debug.txt` — người dùng xem
   được ngay trong app, không cần tự mở file quản lý riêng. Sau đó dò 3
   field quan trọng nhất (`llm_model`/`llm_weight`/`tokenizer_file`) bằng
   tìm chuỗi thô (KHÔNG parse JSON thật — chỉ để LOG, không ảnh hưởng logic
   nạp thật của MNN) — với MỖI field, kiểm tra file được khai báo có THẬT
   SỰ tồn tại trong thư mục hay không và kích thước thật là bao nhiêu, in
   rõ dòng cảnh báo `!!!` nếu không khớp — đây chính là bước "đối chiếu tự
   động" mà trước đó phải đoán qua ảnh chụp màn hình người dùng gửi.
2. `listDirWithSizes()` — liệt kê MỌI file trong thư mục model kèm kích
   thước byte thật — lộ ngay các trường hợp file tải dở/cắt cụt.

**Cân nhắc đã bỏ qua (ghi lại để không thử lại vô ích)**: có xem xét dùng
`__android_log_set_logger()` để bắt luôn log nội bộ CỦA CHÍNH MNN (macro
`MNN_ERROR`/`MNN_PRINT` ghi thẳng vào Android logcat qua `liblog`, không
qua `nativeLog()` của app) — hàm này chỉ có từ API 30 trong khi `minSdk=28`
của project, cần thêm lớp `dlsym` runtime-check phức tạp và có rủi ro ảnh
hưởng toàn bộ logging của tiến trình. Tạm KHÔNG làm — ưu tiên 2 hàm chẩn
đoán ở trên trước (an toàn, tương thích mọi API, khả năng cao đã đủ tìm ra
nguyên nhân dựa trên bằng chứng hiện có — ảnh chụp màn hình cho thấy
`llm.mnn` chỉ 2,30 MB trong khi có 1 file lạ `llm.mnn.json` 5,73 MB chưa
từng được nhắc tới trước đây, rất đáng ngờ).

**Trạng thái**: cân bằng ngoặc (đã kiểm tra comment/string-aware). **CHƯA
build/test thật** — cần người dùng build lại + thử load model 8B 1 lần nữa,
rồi gửi đoạn log mới (sẽ có thêm nhiều dòng `[CHAN DOAN]`) để xác định
chính xác nguyên nhân thay vì tiếp tục suy đoán.

---

**Cập nhật (2026-08-23, phiên 11 — TÌM RA LỖI NGHIÊM TRỌNG NHẤT TỪ ĐẦU TỚI
GIỜ: crash thật (SIGSEGV) do gửi chồng nhiều lệnh chat cùng lúc):**

Sau khi khôi phục đúng cặp `config.json`/`llm_config.json` (đúng như phiên
10 dự đoán — file `config.json.arch` là `llm_config.json` gốc bị đặt sai
tên khi làm theo gợi ý của 1 bên phân tích khác), model 8B **load thành
công** — nhưng log ngay sau đó lộ ra 1 lỗi HOÀN TOÀN KHÁC, nghiêm trọng
hơn nhiều: người dùng gõ "alo" 3 lần liên tiếp trong lúc model còn đang xử
lý câu đầu → native tự phát hiện **"TU CHOI vi phat hien lenh generate
KHAC dang chay dong thoi tren cung slot 0"** → ngay sau đó **crash SIGSEGV
thật** sâu trong `MNN::Session::run()` (stack trace đầy đủ trong log CI).

**Nguyên nhân gốc**: `chat_screen.dart._send()` có cờ chặn gửi trùng
(`sending`), nhưng cờ đó bị đặt **SAU** dòng `await db.upsertChatMessage(...)`
— tạo ra 1 khoảng hở race condition thật: bấm gửi 2-3 lần trong đúng vài
chục mili giây đó, MỌI lần bấm đều đọc `sending == false` (chưa kịp cập
nhật) và đều lọt qua, dẫn tới nhiều lệnh gọi model native chạy chồng lên
nhau — làm hỏng session/KV-cache nội bộ MNN và crash cứng cả tiến trình.
**Đây chính là lý do "tác vụ nền vẫn chạy dù đã vuốt xoá app khỏi recent
apps"** — app không "chạy dở bình thường", nó đã CRASH, nên luồng dọn dẹp
bình thường (tắt thông báo Foreground Service, thả WakeLock) không kịp
chạy, để lại thông báo + WakeLock kẹt lại (giải thích luôn hiện tượng máy
nóng/pin tụt đã báo cáo nhiều lần trước đó — CÓ THỂ chính là lỗi này, không
phải hoàn toàn do ngủ sâu như phiên 9 kết luận).

**Đã sửa**: đặt `sending = true` NGAY DÒNG ĐẦU của `_send()`, TRƯỚC MỌI
`await` — đóng kín khoảng hở hoàn toàn (đúng nguyên tắc đã áp dụng chuẩn ở
`chapter_editor_screen.dart._continueWithAI()`/`_fleshOutOutline()` từ đầu,
rà soát lại xác nhận 2 hàm đó KHÔNG dính lỗi này). Thêm lớp bảo vệ thứ 2:
vô hiệu hoá nút gửi + gửi qua bàn phím (`onSubmitted`) khi `sending == true`.

**Đã rà soát các màn hình khác có nguy cơ tương tự** (`document_screen.dart`,
`document_chunks_screen.dart`, `chapters_batch_generate_screen.dart`) —
mỗi màn đều có 1 `showDialog` (modal, chặn tương tác) đứng TRƯỚC lúc đặt cờ
bận, nên khoảng hở race hẹp hơn NHIỀU so với chat (khoảng hở ở chat là 1
lệnh ĐỌC/GHI DATABASE thật, không phải chỉ đợi 1 dialog đóng) — rủi ro thấp
hơn hẳn, chưa sửa ngay nhưng ghi nhận để theo dõi nếu còn crash tương tự.

**Trạng thái**: cân bằng ngoặc. **CHƯA build/test thật** — cần xác nhận
sau khi build lại, gõ gửi liên tiếp nhiều lần không còn crash, và (nếu vẫn
còn hiện tượng máy nóng/thông báo kẹt) mới cần quay lại nghi vấn ngủ sâu
(WakeLock) của phiên 9.

---

**Cập nhật (2026-08-23, phiên 12 — bản sửa phiên 11 CHƯA đủ, tìm ra nguyên
nhân crash THẬT SỰ chính xác: use-after-free khi nạp model mới đè lên
lệnh generate() "mồ côi" từ phiên trước):**

Người dùng làm rõ lại đúng trình tự 3 lần gõ "alo" — KHÔNG phải gõ liên
tiếp trong vài chục mili giây như phiên 11 suy đoán, mà là 3 LẦN THỬ RIÊNG
BIỆT cách nhau nhiều phút, ứng với 3 lần sửa file config khác nhau. Bản sửa
`sending = true` (chặn double-tap) ở phiên 11 tuy đúng và nên giữ, nhưng
**KHÔNG PHẢI nguyên nhân của crash đã thấy trong log**.

**Nguyên nhân THẬT (đọc lại chính xác trình tự log)**:
1. Lần thử ở `16:36:48` gọi `nativeGenerate()` trên slot=0 — log KHÔNG BAO
   GIỜ thấy dòng "TRA VE XONG" cho lệnh này trước khi phiên app kết thúc
   (người dùng rời màn hình/đóng app giữa chừng — khớp lời kể "bị chết
   chạy nền, hay do lỡ vuốt nhầm nút back"). Lệnh generate() này **KHÔNG
   HỀ BỊ HUỶ THẬT SỰ** — tiếp tục chạy "mồ côi" trong tiến trình native.
2. App khởi động lại (`16:58:11`), người dùng sửa xong config lần cuối,
   bấm nạp lại model 8B vào **CÙNG slot=0**. `nativeLoadModel()` gọi thẳng
   `llmSlot.reset(Llm::createLLM(path))` — **HUỶ NGAY object `Llm` cũ**,
   KHÔNG kiểm tra xem lệnh generate() mồ côi từ bước 1 có còn đang cầm con
   trỏ tới đúng object đó hay không.
3. Lệnh generate() mồ côi (vẫn đang chạy) tiếp tục dùng con trỏ `Llm*` giờ
   đã TRỎ TỚI VÙNG NHỚ ĐÃ GIẢI PHÓNG → **use-after-free** → SIGSEGV thật
   trong `MNN::Session::run()` — khớp CHÍNH XÁC stack trace trong log CI.

**Đã sửa tận gốc**: `nativeLoadModel()` giờ kiểm tra `g_generatingInProgress[slot]`
NGAY TRƯỚC khi huỷ object cũ — nếu slot đang có generate() chạy dở (kể cả
"mồ côi"), **TỪ CHỐI nạp model mới** (trả `JNI_FALSE`, không huỷ gì cả)
thay vì âm thầm huỷ và gây use-after-free. `local_provider.dart.generateStream()`
cũng được sửa: bọc `yield* controller.stream` trong `try/finally`, gọi
`cancelGenerate` native ngay khi consumer (màn hình chat) ngừng lắng nghe
GIỮA CHỪNG (rời màn hình, chưa nhận `done=true`).

**GIỚI HẠN THẬT — chưa giải quyết hoàn toàn (không giấu)**: `cancelGenerate`
phía Kotlin hiện chỉ gọi `currentJob?.cancel()` — đây là **huỷ hợp tác**
(cooperative cancellation) của Kotlin coroutine, KHÔNG có khả năng ngắt
NGANG 1 lời gọi JNI đồng bộ (blocking) đang chạy dở bên trong
`llm->response()` của MNN — vì MNN (dựa trên rà soát code trong repo này)
KHÔNG lộ ra cờ "dừng giữa chừng" nào để tầng Kotlin/C++ kiểm tra định kỳ.
Nghĩa là: lệnh generate() mồ côi VẪN SẼ tiếp tục chạy tới khi tự nhiên
xong (có thể vài phút), KHÔNG dừng ngay lập tức khi rời màn hình — nhưng
giờ đã AN TOÀN (không còn crash use-after-free nếu người dùng thử nạp
model khác trong lúc đó, chỉ đơn giản bị từ chối với thông báo rõ ràng).
Muốn dừng THẬT SỰ ngay lập tức, cách chắc chắn duy nhất hiện tại là
**đóng hẳn app (force-stop), không chỉ rời màn hình** — vì force-stop giết
cả tiến trình OS, không có cách nào để 1 luồng "mồ côi" sống sót qua đó.

**Trạng thái**: cân bằng ngoặc (Dart + C++/Kotlin, comment-aware). **CHƯA
build/test thật** — cần xác nhận: (a) không còn crash SIGSEGV nếu lặp lại
đúng kịch bản "rời màn hình giữa chừng rồi nạp model khác"; (b) thông báo
lỗi rõ ràng hiện ra thay vì crash trong tình huống đó.

---

**Cập nhật (2026-08-25, phiên 13 — sửa 3 vấn đề xác nhận thật từ log/ảnh
chụp: nút "X" chat vẫn không huỷ được, model lặp vô tận không có gì chặn,
`repetitionPenalty` mặc định quá thấp):**

1. **Nút "X" ở màn "Tác vụ nền" KHÔNG huỷ được chat local đang stream —
   XÁC NHẬN ĐÚNG LÀ BUG, chưa từng được sửa thật (dù có 1 phiên làm việc
   trước tự nhận "đã sửa xong" — kiểm tra lại mã nguồn thật cho thấy chưa
   hề áp dụng)**: `BackgroundTaskManager.submitAndWait()` (hàm `chat_screen.dart`
   dùng để nộp việc chat) gọi `submit()` bên dưới nhưng KHÔNG truyền
   `onCancelRequested` — mọi nhiệm vụ chat luôn có `onCancelRequested ==
   null`, nên `requestCancel()` (nút X gọi) không có gì để gọi. **Đã sửa
   tận gốc, xuyên suốt 3 lớp**:
   - `submitAndWait()` nhận thêm `onCancelRequested`, truyền xuống `submit()`.
   - `TranslationService.translate()`/`generateWithOptionalTranslation()`
     nhận thêm `isCancelled` (cùng khuôn mẫu đã có sẵn ở
     `generateResumableWithOptionalTranslation()` cho batch remote — chỉ
     là CHƯA từng nối cho chat/`generateWithOptionalTranslation()` như tài
     liệu phiên trước đã ghi nhận đúng là giới hạn thật) — kiểm tra ngay
     sau mỗi đoạn chunk nhận được, `break` sớm nếu đã bị huỷ.
   - `chat_screen.dart` thêm cờ `cancelRequested`, đặt lại `false` đầu mỗi
     lượt gửi, bật `true` trong `onCancelRequested`, truyền `isCancelled: ()
     => cancelRequested` vào `generateWithOptionalTranslation`.
   - Cơ chế huỷ THẬT SỰ dừng lệnh native: `break` khỏi `await for` khiến
     `LocalLlamaProvider.generateStream()` phát hiện consumer ngừng lắng
     nghe (nhánh `finally` đã có từ mục 5, phiên 12) → tự gọi
     `cancelGenerate` native — không cần thêm cơ chế huỷ mới ở tầng native.
   - **Giới hạn còn lại (không giấu)**: bước "sinh văn bản" ở GIỮA khi dịch
     thuật trung gian BẬT vẫn gọi `mainProvider.generate()` không
     streaming (đợi cả khối) — không có điểm dừng an toàn giữa chừng, huỷ
     lúc đó vẫn phải đợi bước đó xong rồi mới dừng ở bước dịch ngược. Đây
     là giới hạn có thật, không phải bug.

2. **Model lặp vô tận (log thật: model dịch trả `"8888888"`; ảnh chụp màn
   hình thật: Qwen 7B trả cả màn hình dấu `"(((((("`) — TRƯỚC ĐÂY KHÔNG
   CÓ GÌ PHÁT HIỆN/CHẶN**, model chạy tới hết `max_new_tokens` mới dừng
   (log thật: 1024 token trong 550 giây, máy nóng vô ích, pin tụt
   73%→18% trong 1 phiên). Đã thêm `_looksLikeRepetitionLoop()` trong
   `LocalLlamaProvider.generateStream()` (Dart, `local_provider.dart`) —
   đặt Ở ĐÚNG 1 nơi (listener `EventChannel`) để bảo vệ MỌI nơi gọi
   (chat/viết chương/dịch thuật) cùng lúc, không cần sửa riêng từng nơi:
   kiểm tra cửa sổ 200 ký tự cuối mỗi khi có token mới (từ ký tự thứ 60 trở
   đi), phát hiện (a) 1 ký tự chiếm > 85% cửa sổ, hoặc (b) 1 cụm 2-6 ký tự
   lặp khít cả cửa sổ — khớp đúng 2 dạng lỗi đã gặp thật. Phát hiện được
   thì dừng ngay: đóng stream + gọi `cancelGenerate` native + thêm 1 dòng
   cảnh báo rõ ràng vào cuối văn bản đã sinh (không mất phần hợp lệ đã có
   trước khi lặp bắt đầu).
3. **`repetitionPenalty` mặc định 1.05 — đúng như nghi vấn đã nêu ở lượt
   làm việc trước nhưng CHƯA áp dụng**: nâng mặc định lên 1.15
   (`settings_service.dart` + `generation_settings_screen.dart`, đồng bộ 2
   nơi). Đây là biện pháp GIẢM THIỂU, không phải sửa nguyên nhân gốc (vẫn
   chưa xác nhận chắc chắn gốc rễ là do tham số này hay yếu tố khác như
   nhiệt độ máy) — lớp phòng vệ ở mục 2 mới là lưới an toàn chắc chắn.

**Trạng thái**: cân bằng ngoặc (đã kiểm tra bằng đếm `{`/`}` toàn bộ 6 file
đã sửa). **CHƯA build/test thật trên thiết bị** — cần xác nhận qua build
CI + cài lại: (a) bấm "X" giữa lúc chat local đang stream thật sự dừng
sinh chữ thêm, không chỉ đổi trạng thái task; (b) cố tình dùng model/cấu
hình dễ lặp (nếu còn) để xác nhận dòng cảnh báo "Đã tự dừng" xuất hiện
thay vì chạy tới hết `max_new_tokens`; (c) `repetitionPenalty` mặc định
mới 1.15 không làm văn bản "cứng"/lặp cấu trúc câu quá mức ở model bình
thường (đánh đổi hợp lý, người dùng vẫn chỉnh lại được).

**CHƯA làm trong phiên này (ngoài phạm vi, cần log thật mới để làm tiếp)**:
`build.yml` copy QNN .so — cấu trúc hiện tại (5 file, có kiểm tra đủ/thiếu,
in cảnh báo rõ) trông đã đúng theo tài liệu MNN Chat tham khảo ở mục 46,
nhưng log runtime gần nhất (2026-08-23) vẫn báo thiếu cả 5 file — nhiều khả
năng do APK người dùng đang chạy được build TRƯỚC bản vá mục 46, hoặc
đường dẫn thật trong QNN SDK zip lệch với giả định `aarch64-android`/
`hexagon-v68/unsigned` đang dùng. Không sửa mù thêm lần nữa — cần đúng đoạn
log bước "Đặt file .so vào đúng chỗ..." của lần build MỚI NHẤT (có in cây
thư mục QNN SDK thật) mới xác định được chính xác cần đổi gì. Không nghiêm
trọng cấp bách vì QNN giờ chỉ là thử nghiệm tùy chọn (mục 1) — đường mặc
định GPU/OpenCL đã chạy tốt (log xác nhận `backend: opencl` thành công).

---

**Cập nhật (2026-08-25, phiên 14 — theo phản hồi log/mô tả mới nhất):**

1. **`LocalLlamaProvider.name` trước đây CỐ ĐỊNH "AI local (MNN + QNN)"
   bất kể model nào thật sự đang nạp** — đúng như người dùng phản ánh:
   không có cách nào nhìn vào khung chat để biết đang là Qwen hay
   OccultAI-Morpheus đang trả lời (đặc biệt dễ nhầm ngay sau khi vừa đổi
   model). Đã sửa: lấy tên thư mục model (basename của `modelPath`) làm
   tên hiển thị — ghi vào `providerLabel` của từng tin nhắn ngay lúc gửi
   (`chat_screen.dart` dòng `providerLabel: provider.name` đã có sẵn, chỉ
   cần sửa đúng 1 chỗ là `name` getter).
2. **Làm rõ hiểu lầm về "force stop"**: người dùng đúng — force stop giết
   hẳn tiến trình, dọn sạch RAM, không có luồng "mồ côi" nào sống sót qua
   được. Nhưng force stop KHÔNG thay đổi APK đã cài trên máy — lần mở lại
   sau force stop vẫn nạp lại ĐÚNG BỘ CODE CŨ đã build sẵn trong file APK
   (giống mở lại y hệt 1 quyển sách đã in — đóng sách lại không tự sửa
   được lỗi in ấn bên trong). Bug nút "X" không dừng được chat, bug lặp vô
   tận không bị chặn... là bug NẰM TRONG CODE — chỉ hết khi build lại
   APK từ mã nguồn đã sửa (`.zip` mới) rồi cài đè/cài lại, không phải khởi
   động lại app suông. Log mới nhất (2026-08-25 08:36) mà người dùng gửi
   cho thấy `repetition_penalty` gửi xuống native vẫn là `1.05` — CHƯA
   phải `1.15` mới sửa — xác nhận đúng: bản đang chạy là bản build TRƯỚC
   phiên 13 (hoặc do `novel.genRepetitionPenalty` đã lưu sẵn `1.05` cụ thể
   trong DB cho truyện đó từ trước, nên giá trị mặc định mới không ghi đè
   được — người dùng cần vào "Tham số sinh văn bản" chỉnh tay lại nếu đã
   từng lưu giá trị cũ cho truyện đang dùng).
3. **OccultAI-Morpheus-8B ra rác + nóng máy nhiều hơn hẳn Qwen dù cùng
   thời gian chờ**: log gửi kèm lần này chỉ có phiên nạp Qwen (thành công,
   chưa thấy đoạn sinh rác của OccultAI-Morpheus) nên chưa có bằng chứng
   log trực tiếp để kết luận nguyên nhân. Ghi nhận khả năng: (a) đúng lớp
   phòng vệ lặp vô tận thêm ở phiên 13 sẽ tự cắt sớm trường hợp này MỘT
   KHI đã build+cài bản mới — không sửa được "vì sao model đó lặp" (có thể
   do đặc thù bản lượng tử hoá/convert MNN của riêng file này bị lỗi, nằm
   ngoài phạm vi sửa được ở tầng app) nhưng sẽ ngăn được hậu quả (máy nóng
   vô ích, chờ vô ích); (b) nếu nghi ngờ file model bị hỏng khi convert,
   nên thử tải lại/convert lại file OccultAI-Morpheus-8B từ nguồn gốc để
   loại trừ khả năng lỗi nằm ở chính file .mnn.

---

**Cập nhật (2026-08-25, phiên 15 — xác nhận model-name fix hoạt động
đúng qua ảnh chụp thật; thêm cảnh báo trước khi thoát app lỡ tay):**

- **Xác nhận**: ảnh chụp màn hình gửi kèm cho thấy nhãn model đã đúng
  ("AI local — OccultAI-Morpheus-8B-v2-MNN-q4-chinh", "AI local —
  Orion-zhen-Qwen2.5-7B-Instruct-Uncensored-MNN-q4-chinh") — bản build
  người dùng đang chạy đã có bản vá phiên 14.
- **Bug/tình huống mới xác nhận thật qua log + mô tả người dùng**: vuốt
  gesture quay lại (back gesture) LỠ TAY ở màn gốc (`RootScreen` — không
  còn route nào để pop bên dưới, nên back ở đây luôn nghĩa là thoát app)
  trong lúc 1 lệnh generate() local đang chạy dở → lệnh đó thành "mồ côi"
  giống hệt kiểu lỗi đã ghi nhận ở mục 5/phiên 12, nhưng KHÔNG PHẢI do
  crash hay reload màn hình — mà do CHÍNH NGƯỜI DÙNG vô tình thoát app.
  Log xác nhận: `TU CHOI NAP MODEL MOI — slot 0 dang co 1 lenh generate()
  TU PHIEN TRUOC van con chay do (mo coi)` — lặp lại ở CẢ 2 lần thử nạp
  model khác nhau sau đó (OccultAI lẫn Qwen) — slot 0 bị khoá cứng, không
  nạp được BẤT KỲ model nào (không riêng model cũ) tới khi lệnh mồ côi tự
  chạy xong.
- **Đã thêm (theo đúng yêu cầu người dùng)**: `RootScreen` (`main.dart`)
  bọc trong `PopScope` — CHỈ chặn khi thật sự có tác vụ đang `running`
  (không làm phiền khi không có gì chạy, hoặc chỉ có tác vụ mới `queued`
  chưa động tới native). Chặn thì hiện hộp thoại xác nhận rõ hậu quả
  ("model có thể bị khoá tới khi lệnh cũ tự xong"), có 2 lựa chọn "Ở lại"
  / "Thoát vẫn". Nếu người dùng vẫn chọn thoát: gọi `requestCancel()` cho
  mọi tác vụ đang chạy/xếp hàng trước (cố gắng tốt nhất — không đảm bảo
  native kịp nhận trước khi tiến trình đóng) rồi mới `SystemNavigator.pop()`.
- **Giới hạn còn lại, ghi rõ không giấu**: lớp phát hiện "lặp vô tận"
  thêm ở phiên 13 nằm ở TẦNG DART (`local_provider.dart`, lắng nghe
  EventChannel) — MỘT KHI app đã thật sự thoát (Dart isolate/Flutter
  engine bị Android dọn), lớp này KHÔNG còn chạy được nữa, chỉ còn code
  Kotlin/C++ (không tự phát hiện lặp) tiếp tục chạy tới hết
  `max_new_tokens` nếu lệnh generate() gốc đã kịp thoát ra ngoài phạm vi
  PopScope chặn được (vd: app bị hệ thống Android tự kill vì thiếu RAM,
  không phải do người dùng bấm back). Hộp thoại xác nhận ở trên giảm
  được phần lớn trường hợp (lỡ tay vuốt back) nhưng KHÔNG loại bỏ hoàn
  toàn rủi ro mồ côi — muốn triệt để cần thêm 1 lớp phát hiện lặp vô tận
  Ở TẦNG NATIVE (Kotlin/C++, độc lập với Dart) — chưa làm trong phiên
  này, để dành việc kế tiếp nếu người dùng còn gặp lại tình huống khoá
  slot dù đã có hộp thoại xác nhận.

---

**Cập nhật (2026-08-25, phiên 16 — làm tiếp phần chặn lặp ở tầng gốc
(native) + hiện đúng trạng thái "tác vụ mồ côi" ở màn "Tác vụ nền", theo
đúng 2 yêu cầu của người dùng):**

1. **Phát hiện gốc rễ thật của TOÀN BỘ chuỗi lỗi "generate() mồ côi" từ
   trước tới giờ**: `cancelGenerate` (Kotlin) trước đây CHỈ gọi
   `currentJob?.cancel()` — huỷ được Job coroutine BỌC NGOÀI, nhưng lời
   gọi JNI thật sự chạy lâu (`MnnNative.nativeGenerate` → `llm->response()`,
   đồng bộ/chặn) thì KHÔNG CÓ CÁCH NÀO được báo phải dừng — coroutine
   cancellation của Kotlin không tự "ngắt" được 1 lời gọi JNI đang chạy dở.
   Đây là lý do THẬT SỰ vì sao mọi lệnh generate() (dù bị huỷ chủ động hay
   app bị thoát) đều chạy tới hết `max_new_tokens`/EOS mới dừng — không
   phải lỗi thiếu sót ở từng chỗ gọi riêng lẻ như các phiên trước tưởng.
2. **Sửa tận gốc (mnn_bridge.cpp)**: thêm `g_cancelRequested[slot]`
   (atomic, song song `g_generatingInProgress` đã có) + hàm JNI
   `nativeRequestCancel(slot)`. `JniStreamingBuf::xsputn` — điểm DUY NHẤT
   mọi token sinh ra đều đi qua trước khi tới Java — kiểm tra cờ này ở
   MỖI lần ghi token; nếu bật thì ném `GenerationStoppedException` để
   unwind ra khỏi `llm->response()` ngay lập tức (dùng exception vì đây
   là cách DUY NHẤT "ngắt" 1 lời gọi thư viện đồng bộ không tự hỗ trợ API
   huỷ giữa chừng). `nativeGenerate()` đã có sẵn khối `catch` bao quanh —
   thêm 1 nhánh `catch (const GenerationStoppedException&)` riêng, log rõ
   ràng "dừng sớm chủ động" (không phải lỗi/crash).
3. **Thêm LUÔN lớp phát hiện lặp vô tận Ở TẦNG NÀY** (không chỉ dừng ở
   nhận cờ huỷ) — bản C++ của `_looksLikeRepetitionLoop()` (Dart, phiên
   13), CÙNG logic (1 ký tự >85% cửa sổ, hoặc cụm 2-6 ký tự lặp khít),
   chạy trong chính `JniStreamingBuf::xsputn`. Khác biệt quan trọng với
   bản Dart: bản NÀY tiếp tục hoạt động dù Flutter engine/Dart isolate đã
   bị đóng (app đã thoát) — vì nó chạy trong cùng tiến trình native với
   chính lệnh generate() đang chạy, không phụ thuộc Dart còn sống hay
   không. Đây chính là lỗ hổng người dùng phát hiện ra ở phiên 15 (thoát
   app giữa chừng → lớp Dart chết theo, model vẫn lặp mà không ai chặn).
4. **`cancelGenerate` (Kotlin) giờ gọi CẢ HAI**: `currentJob?.cancel()`
   (dọn coroutine bọc ngoài, giữ nguyên như cũ) + `MnnNative.nativeRequestCancel(slot)`
   (mới — có tác dụng thật với `llm->response()` đang chạy). Nút "X" ở
   "Tác vụ nền" giờ mới thật sự dừng được sinh chữ giữa chừng, kể cả khi
   không phải do lặp vô tận.
5. **Trả lời câu hỏi "sao tác vụ nền không báo có bất cứ cái gì hết"**:
   đúng như nghi ngờ — `BackgroundTaskManager` (Dart) chỉ là 1 `List`
   sống trong RAM của PHIÊN HIỆN TẠI; đóng app = mất hết, không có cách
   nào tự biết về 1 lệnh mồ côi còn sống sót từ phiên TRƯỚC dưới native.
   Thêm hàm JNI `nativeIsGenerating(slot)` (đọc `g_generatingInProgress`)
   + method channel `isSlotGenerating` (Kotlin) + `LocalLlamaProvider.isSlotGenerating()`
   (Dart) để tầng UI hỏi THẲNG native — nơi duy nhất còn giữ đúng sự thật.
   `background_tasks_screen.dart` giờ tự hỏi cả 2 slot lúc mở màn (+ nút
   làm mới thủ công), hiện `MaterialBanner` cảnh báo rõ ràng nếu native
   báo bận NHƯNG Dart-side không có tác vụ nào đang `running` (đúng dấu
   hiệu mồ côi) — kèm nút "Huỷ tác vụ mồ côi" gọi thẳng
   `LocalLlamaProvider.requestCancelSlot()` (không cần instance provider
   cũ, chỉ cần đúng số slot).
6. **Trạng thái**: cân bằng ngoặc `{`/`}` đã kiểm tra lại trên cả 5 file
   sửa (2 Dart, 2 Kotlin/1 đã sửa, 1 C++). **CHƯA build/test thật trên
   thiết bị** (không có Android NDK/Flutter SDK trong môi trường chuẩn bị
   bản vá này) — đặc biệt cần chú ý khi build lần đầu: `GenerationStoppedException`
   kế thừa `std::runtime_error`, dùng `throw`/`catch` bình thường của C++,
   không cần cấu hình NDK gì thêm, nhưng nên xác nhận `ANDROID_STL` trong
   `CMakeLists.txt`/`build.yml` đang dùng bản STL có hỗ trợ exception đầy
   đủ (thường là mặc định `c++_shared`, không cần đổi gì nếu build trước
   đó vẫn dùng exception ở chỗ khác trong cùng file, như try/catch quanh
   `llm->response()` đã có sẵn từ trước).

---

**Cập nhật (2026-08-25, phiên 17 — log gửi kèm XÁC NHẬN cơ chế huỷ native
phiên 16 hoạt động thật; sửa tiếp 3 vấn đề người dùng phát hiện qua trải
nghiệm thật: chữ "Thoát vẫn" khó hiểu, thoát xong vẫn khoá slot = vô
nghĩa, chữ đã sinh biến mất sau khi thoát+mở lại):**

- **Xác nhận bằng chính log người dùng gửi**: `nativeRequestCancel: da dat
  co huy cho slot 0` lúc 16:46:58, rồi `nativeGenerate: DA DUNG SOM CHU
  DONG — nguoi dung/he thong yeu cau huy (cancelGenerate) (da sinh duoc
  1071 ky tu truoc do)` chỉ 6 giây sau — cơ chế huỷ native thêm ở phiên 16
  **hoạt động đúng như thiết kế**, không phải lý thuyết suông.
- **Bug thật phát hiện ra (giải thích vì sao "thoát vẫn" bị người dùng
  đúng là thấy "vô nghĩa")**: `main.dart` (phiên 15) gọi `requestCancel()`
  (chỉ đặt 1 cờ, KHÔNG đợi) rồi `SystemNavigator.pop()` NGAY LẬP TỨC —
  trong khi việc huỷ THẬT (native nhận lệnh, `llm->response()` thoát ra,
  và QUAN TRỌNG NHẤT: khối `finally` trong `chat_screen.dart` — nơi có
  `await db.upsertChatMessage(reply)`, CHỈ được gọi ĐÚNG 1 LẦN duy nhất ở
  cuối `_send()`, không hề lưu tăng dần trong lúc đang stream — chạy
  xong) đều xảy ra BẤT ĐỒNG BỘ, mất vài giây. App bị đóng TRƯỚC khi các
  bước đó kịp hoàn tất → (a) slot vẫn bị khoá (lệnh cũ chưa kịp nhận tín
  hiệu huỷ), (b) phần chữ đã hiện trên màn hình lúc đang sinh **CHƯA BAO
  GIỜ được ghi xuống DB** nên mất sạch khi mở lại — đúng cả 2 hiện tượng
  người dùng mô tả, CÙNG 1 GỐC.
- **Đã sửa (`main.dart`)**: xác nhận "Vẫn thoát" xong (đổi tên nút cho tự
  nhiên hơn — trước là "Thoát vẫn", đọc ngược khó hiểu) → hiện 1 hộp
  thoại nhỏ không tắt được ("Đang dừng AI và lưu phần đã sinh...") → gọi
  huỷ TRỰC TIẾP xuống native cho CẢ 2 slot (`LocalLlamaProvider.requestCancelSlot()`,
  nhanh hơn đường cũ vì không cần đợi consumer Dart nhận được chunk tiếp
  theo mới kích hoạt) → **CHỜ THẬT** bằng cách poll `manager.runningCount`
  mỗi 300ms, tối đa 10 giây (chỉ về 0 sau khi khối `finally` có
  `upsertChatMessage` đã chạy xong) → mới đóng hộp thoại + thật sự thoát.
- **Giới hạn còn lại, không giấu**: cơ chế này chỉ hoạt động khi người
  dùng thoát qua ĐÚNG con đường có `PopScope` chặn (back-gesture ở màn
  gốc). Nếu người dùng force-stop app từ màn hình đa nhiệm/Cài đặt hệ
  thống Android (bỏ qua hoàn toàn Flutter, giết tiến trình ngay lập tức),
  không có cách nào chặn được từ phía app — phần chữ đang sinh dở VẪN sẽ
  mất, và slot vẫn có thể bị khoá tạm thời (dù giờ đã có phòng vệ ở
  Tác vụ nền — mục 5, phiên 16 — để tự huỷ tay được khi mở lại).
- **Trả lời câu hỏi "sinh chữ chậm hơn phiên bản trước"**: log cho thấy
  lệnh generate() ĐẦU TIÊN sau khi nạp model mất 232 giây chỉ để sinh 13
  token — bất thường, nhiều khả năng là do MNN OpenCL backend đang tự
  "tuning" kernel lần đầu (biên dịch/đo thời gian các kernel GPU, chỉ xảy
  ra 1 lần cho tới khi cache tuning — đã có thư mục riêng qua
  `nativeSetCacheDir` — ổn định lại), KHÔNG liên quan tới code mới thêm ở
  phiên 13/16 (các phép kiểm tra lặp vô tận chỉ là so sánh ký tự đơn giản
  trên cửa sổ 200 byte, tốn vài micro-giây mỗi token, không thể gây chậm
  tới mức giây/token). Để xác nhận chắc chắn, cần so sánh THỜI GIAN CHO
  TỪNG TOKEN ở lệnh generate() THỨ 2, THỨ 3 trở đi trong CÙNG 1 phiên
  (sau khi cache tuning đã "nóng") — nếu vẫn chậm bất thường ở đó thì mới
  đáng nghi code, còn chậm chỉ ở LẦN ĐẦU sau khi cài lại APK thì nhiều
  khả năng là chi phí tuning 1 lần, không phải bug.
- **Trả lời "nhắn alo mà không trả lời được"**: log cho thấy model
  (OccultAI-Morpheus-8B) đã trả lời THẬT (13 token, không lỗi, không
  crash) — chỉ là câu trả lời "Tôi không có câu trả lời cho câu hỏi của
  bạn." Đây nhiều khả năng là ĐẶC ĐIỂM của chính model này (fine-tune
  hướng tới nội dung/phong cách khác, không được huấn luyện để xử lý tốt
  lời chào xã giao ngắn không có ngữ cảnh Story Bible) — không phải lỗi
  app, app chỉ đang chuyển tiếp đúng nguyên văn model trả về.

---

**Cập nhật (2026-08-25, phiên 18 — hoàn tất 3 việc đã làm dở cuối phiên
17: lưu tăng dần khi đang stream (chat + viết chương), nút khôi phục ở
màn hình tổng, cỡ chữ toàn app):**

1. **"Phần chữ đang sinh dở vẫn mất" — sửa tận gốc bằng lưu tăng dần**:
   trước đây `reply`/chương CHỈ ghi xuống máy đúng 1 lần ở cuối `_send()`/
   sau khi sinh XONG HẲN — chưa từng chạm ổ đĩa trong lúc đang stream.
   Thêm checkpoint trong `onChunk` (cả `chat_screen.dart` lẫn
   `chapter_editor_screen.dart`, 2 chỗ gọi AI trong màn viết chương):
   lưu khi có ≥200 ký tự mới HOẶC ≥2 giây trôi qua kể từ lần lưu gần
   nhất — cân bằng "mất ít nhất có thể" và "không ghi SQLite liên tục".
   Fire-and-forget (không `await` trong callback đồng bộ của stream).
2. **Nút khôi phục ở màn hình tổng**: `BackupRestoreScreen.novelId` đổi
   từ bắt buộc sang nullable — mở được từ AppBar màn "Truyện của bạn"
   (`NovelListScreen`, `main.dart`) ngay cả khi 0 truyện nào tồn tại; ẩn
   mục "Sao lưu 1 truyện" khi không có `novelId`, giữ nguyên "Sao lưu
   toàn app" + "Khôi phục từ file" (2 việc này vốn không phụ thuộc 1
   truyện cụ thể).
3. **Cỡ chữ toàn app** (không phải pinch-zoom thật — xem lý do đầy đủ ở
   `text_scale_service.dart`: pinch-gesture trực tiếp trên các ô nhập
   liệu rủi ro xung đột với cử chỉ đã có sẵn ở đó, đặc biệt màn viết
   chương vốn đã phức tạp): `TextScaleService` (`ValueNotifier<double>`,
   lưu qua SharedPreferences) + áp dụng qua `MediaQuery.textScaler` ở
   `builder` của `MaterialApp` (nơi DUY NHẤT cần sửa để có tác dụng ở MỌI
   màn hình cùng lúc) + 1 thanh trượt trong hộp thoại mở từ icon mới ở
   AppBar màn "Truyện của bạn".

---

**Cập nhật (2026-08-25, phiên 19 — log mới phát hiện vấn đề THỨ 3, KHÁC
với lặp nội dung: model "trì trệ" (stall) — sinh cực chậm dù nội dung
CHƯA CHẮC đã lặp):**

- **Bằng chứng từ log**: lớp chặn lặp native (phiên 16) hoạt động ĐÚNG —
  bắt được và dừng sạch sẽ (`DA DUNG SOM CHU DONG — phat hien lap vo tan
  ... da sinh duoc 60 ky tu`), khoá được giải phóng bình thường (không
  còn "mồ côi" nữa). NHƯNG phải mất **482 giây** chỉ để tích luỹ đủ 60 ký
  tự đầu tiên rồi mới bắt được — so sánh: model khác (Huihui 1.8B) CÙNG
  máy, CÙNG phiên, sinh gần 200 token chỉ trong 66 giây. Đây là lỗi KHÁC
  hẳn "lặp nội dung" — bản thân tốc độ SINH RA từng ký tự đã trì trệ bất
  thường, không phải nội dung ra rồi mới lặp.
- **Đã thêm lớp phòng vệ THỨ 3** (song song 2 lớp: cờ huỷ chủ động + phát
  hiện lặp nội dung, cả 2 thêm ở phiên 16): kiểm tra THỜI GIAN THẬT trong
  `JniStreamingBuf::xsputn` — quá 90 giây kể từ lúc bắt đầu generate() mà
  CHƯA tích được 80 ký tự thì coi là "trì trệ" (stall), dừng sớm luôn,
  không đợi tới khi đủ dữ liệu để phát hiện lặp (60 ký tự, nhưng trường
  hợp này 60 ký tự cũng mất tới 482 giây mới tới) hay đủ `max_new_tokens`.
  Thông báo cho người dùng khác hẳn 2 trường hợp kia — gợi ý "thử model
  khác, hoặc để máy nguội bớt rồi thử lại" thay vì nói chung chung.
- **Chưa biết nguyên nhân gốc của bản thân sự trì trệ này** (không giấu):
  có thể do (a) máy đang nóng sau khi chạy liên tiếp 2 model trong cùng
  phiên (Huihui rồi ngay lập tức OccultAI-Morpheus, không nghỉ), (b) đặc
  thù riêng của file OccultAI-Morpheus-8B (bản convert/lượng tử hoá có
  vấn đề, hoặc kiến trúc model này chạm phải 1 nhánh tính toán chậm bất
  thường trên backend OpenCL của máy này) — nghi ngờ (b) nhiều hơn vì đây
  không phải lần đầu model NÀY cụ thể có biểu hiện bất thường (đã ghi
  nhận "ra rác + nóng máy hơn hẳn" ở phiên 14). Lớp phòng vệ mới chỉ giới
  hạn THIỆT HẠI (không phải để hết 8+ phút chờ vô ích), không sửa được
  nguyên nhân gốc.

---

**Cập nhật (2026-08-25, phiên 20 — SỬA LẠI giả thuyết sai ở phiên 19,
theo đầu mối chính xác hơn từ người dùng):**

- **Rút lại giả thuyết "máy nóng"**: không đủ căn cứ, và đóng khung sai
  vấn đề (ngụ ý model "cảm nhận" được nhiệt độ). Người dùng chỉ ra đầu
  mối chính xác hơn nhiều: **chạy MỘT MÌNH thì bình thường, nhưng chạy
  NGAY SAU 1 model KHÁC (trong cùng phiên app) thì sinh rác — xảy ra với
  CẢ OccultAI-Morpheus LẪN Qwen 7B** (không phải đặc thù riêng 1 file
  model như nghi ngờ trước đó ở phiên 14/19). Đây là dấu hiệu kinh điển
  của trạng thái GPU/OpenCL sót lại giữa 2 lần nạp model trong CÙNG 1
  tiến trình — không phải máy nóng, không phải model cụ thể nào hỏng.
- **Tìm ra đúng chỗ nghi vấn (`mnn_bridge.cpp`, `nativeLoadModel`)**: dòng
  cũ `llmSlot.reset(Llm::createLLM(path));` có vấn đề THỨ TỰ tinh vi —
  C++ đánh giá `Llm::createLLM(path)` (khởi tạo model MỚI, cấp phát tài
  nguyên GPU/OpenCL) **TRƯỚC KHI** `reset()` huỷ model CŨ — nghĩa là
  trong lúc model mới khởi tạo, model cũ (nếu có) vẫn còn sống, tài
  nguyên GPU của nó chưa được giải phóng. Nếu backend OpenCL của MNN có
  bất kỳ trạng thái dùng chung (global/static, không tách riêng theo
  từng object `Llm` — rất phổ biến ở engine GPU vì lý do hiệu năng), model
  mới có thể vô tình "thừa hưởng" trạng thái/tài nguyên dở dang của model
  cũ — khớp đúng triệu chứng "tốt khi chạy 1 mình, hỏng khi chạy sau model
  khác".
- **Đã sửa**: tách thành 2 bước rõ ràng — huỷ HẲN model cũ trước
  (`llmSlot.reset();`, giải phóng sạch tài nguyên GPU), RỒI MỚI gọi
  `Llm::createLLM(path)` cho model mới. Đảm bảo không có 2 model cùng
  "sống" trên GPU cùng lúc dù chỉ trong khoảnh khắc ngắn.
- **Mức độ tin cậy, nói rõ không giấu**: đây là giả thuyết HỢP LÝ NHẤT
  dựa trên bằng chứng hiện có (khớp đúng mọi triệu chứng đã quan sát: tốt
  đơn lẻ / hỏng khi nối tiếp, xảy ra ở NHIỀU model khác nhau chứ không
  riêng 1 file) và là 1 thay đổi AN TOÀN, ĐÚNG THỰC HÀNH CHUẨN (dọn sạch
  tài nguyên GPU trước khi cấp phát tài nguyên GPU mới) dù có giải quyết
  triệt để hay không. KHÔNG có quyền truy cập vào mã nguồn nội bộ của
  MNN's OpenCL backend để xác nhận 100% đây chính xác là cơ chế rò rỉ
  trạng thái — nếu build mới vẫn còn hiện tượng này, bằng chứng đó sẽ thu
  hẹp lại: không phải do thứ tự huỷ/tạo object ở tầng app, mà có thể là
  vấn đề sâu hơn bên trong chính thư viện MNN (ngoài khả năng sửa được ở
  tầng code ứng dụng này).

---

**Cập nhật (2026-08-25, phiên 21 — thêm log chẩn đoán THẬT ở đúng tầng
nghi vấn, theo yêu cầu người dùng "sao không làm log bắt bug ở tầng
này" — trước đây phiên 20 chỉ SỬA theo giả thuyết, chưa có gì XÁC NHẬN
giả thuyết đó đúng/sai bằng số liệu thật):**

1. **`readVmRssKb()`** (mới, đọc `/proc/self/status` → `VmRSS`): bộ nhớ
   RAM thật tiến trình đang chiếm dụng. Trên hầu hết thiết bị Android,
   phần lớn buffer OpenCL/GPU cũng tính vào không gian địa chỉ chung của
   tiến trình, nên VmRSS tụt/tăng phản ánh khá tốt việc tài nguyên model
   có thật sự được giải phóng/cấp phát hay không (dù không hoàn hảo
   100% cho VRAM chuyên dụng riêng — nói rõ giới hạn của phép đo).
2. **`g_loadCountInProcess[slot]`** (mới, atomic int, KHÔNG reset khi đổi
   model, CHỈ reset khi tiến trình app bị kill/mở lại thật): đếm số lần
   đã nạp THÀNH CÔNG vào từng slot. Trả lời trực tiếp câu hỏi "lỗi có
   LUÔN xảy ra từ lần nạp thứ 2 trở đi trong slot đó không" bằng số liệu
   log thật, thay vì suy đoán từ trí nhớ.
3. **3 điểm log mới ở `nativeLoadModel`** (gắn nhãn `[CHAN DOAN DOI
   MODEL]` để dễ lọc): VmRSS TRƯỚC khi huỷ model cũ → VmRSS SAU khi huỷ
   (kèm số kB đã giảm — nếu số này gần 0/âm dù model cũ rõ ràng có dữ
   liệu, đó là bằng chứng cụ thể tài nguyên CHƯA được giải phóng thật) →
   VmRSS SAU khi tạo model mới (kèm số kB đã tăng).
4. **2 điểm log mới ở `JniStreamingBuf::xsputn`** (gắn nhãn `[CHAN DOAN
   TRI TRE]` / `[CHAN DOAN LAP VO TAN]`), ngay tại chỗ ném exception dừng
   sớm: ghi lại ĐÚNG lần nạp thứ mấy (từ `g_loadCountInProcess`) đã gây
   ra hiện tượng — nếu qua nhiều lần lỗi lặp lại, con số này LUÔN ≥ 2
   (không bao giờ là lần nạp ĐẦU TIÊN sau khi mở app), đó là bằng chứng
   củng cố mạnh cho giả thuyết "trạng thái sót lại giữa các lần nạp"
   (phiên 20) thay vì đặc thù riêng 1 file model hay máy nóng.
5. **Mục tiêu của phiên này KHÔNG PHẢI sửa thêm gì** — chỉ THU THẬP BẰNG
   CHỨNG. Lần tới nếu hiện tượng còn xảy ra, gửi kèm đúng đoạn log có 5
   nhãn `[CHAN DOAN ...]` ở trên sẽ cho biết chính xác: (a) fix thứ tự
   huỷ/tạo ở phiên 20 có thật sự giải phóng được bộ nhớ hay không (nhìn
   vào số kB giảm ở bước huỷ), và (b) lỗi có tương quan chặt với "không
   phải lần nạp đầu tiên" hay không — từ đó mới biết nên đào sâu tiếp
   theo hướng nào (vd: nếu VmRSS giảm bình thường mà vẫn lỗi → không phải
   RAM/GPU chưa giải phóng, mà có thể là trạng thái nội bộ khác của MNN
   như cache tuning OpenCL dùng chung file/thư mục giữa các model).

---

**Cập nhật (2026-08-25/26, phiên 22 — SỬA LỖI BUILD THẬT, xác nhận qua
log CI GitHub Actions người dùng gửi — Build APK #101 THẤT BẠI):**

- **Lỗi**: `lib/main.dart:267: Error: The method '_showTextScaleDialog'
  isn't defined for the type '_NovelListScreenState'`. Nguyên nhân: ở
  phiên 18, khi thêm hàm `_showTextScaleDialog()`, câu lệnh tìm-thay-thế
  đã khớp NHẦM vào đoạn `@override\n  Widget build(BuildContext context) {\n
  if (loading) {` — đoạn code này tồn tại Y HỆT ở CẢ 2 class
  (`_NovelGateScreenState` VÀ `_NovelListScreenState`, cả 2 đều có biến
  `loading` + kiểm tra tương tự) — công cụ sửa file chọn nhầm lần khớp
  ĐẦU TIÊN (`_NovelGateScreenState`), trong khi nút bấm gọi hàm này lại
  nằm ở `_NovelListScreenState` — 2 class hoàn toàn khác nhau nên biên
  dịch báo "method không tồn tại". Đây là lỗi tôi gây ra do không xác
  minh kỹ đích đến của thay-thế khi có nhiều đoạn code trùng cấu trúc
  trong cùng 1 file — bài học: khi 1 file có nhiều class với cấu trúc
  tương tự nhau (ở đây là nhiều màn hình `Stateful` đều có pattern
  `loading`/`build()`), luôn kiểm tra lại SỐ DÒNG THẬT SỰ của đoạn vừa
  sửa nằm trong class nào, không chỉ tin vào việc thay-thế "chạy thành
  công không báo lỗi".
- **Đã sửa**: cắt `_showTextScaleDialog()` khỏi `_NovelGateScreenState`
  (dòng ~72-165), chuyển đúng xuống `_NovelListScreenState` (dòng ~127+,
  ngay trước `build()` của chính nó, đúng nơi nút bấm ở AppBar gọi tới).
  Đã xác minh lại bằng `grep` số dòng: hàm định nghĩa và nơi gọi giờ cùng
  nằm giữa 2 mốc `class _NovelListScreenState` và `class RootScreen`.
- **Bài học quy trình (ghi để tránh lặp lại)**: từ phiên này trở đi, sau
  MỌI lần thêm method mới vào 1 file có nhiều class, chạy thêm bước xác
  minh: `grep -n "^class \|tên_method_mới"` rồi tự kiểm tra bằng mắt số
  dòng của method nằm giữa đúng cặp `class X {` / `class Y {` (class kế
  tiếp) mong muốn — không chỉ dựa vào việc lệnh sửa file không báo lỗi
  (một cú str_replace "thành công" không đồng nghĩa nó sửa ĐÚNG VỊ TRÍ
  nếu chuỗi khớp không đủ duy nhất trong ngữ cảnh nhiều class giống nhau).

---

**Cập nhật (2026-08-26, phiên 23 — BẰNG CHỨNG SỐ LIỆU THẬT đầu tiên từ
log VmRSS (phiên 21) — phát hiện quan trọng: fix thứ tự huỷ/tạo (phiên
20) KHÔNG giải quyết được rò rỉ bộ nhớ; + gỡ 2 hardcode bị người dùng
phát hiện đúng):**

## A. Phân tích log VmRSS — rò rỉ bộ nhớ THẬT SỰ tồn tại

- **Lần nạp thứ 1** (OccultAI-Morpheus-8B, slot trống hoàn toàn — tiến
  trình vừa mở): VmRSS trước huỷ = 221.100 kB, sau huỷ = 221.100 kB
  (giảm 0 — ĐÚNG, vì chưa có gì để huỷ). Nhưng generate() bị **TRÌ TRỆ**
  — chỉ 2 ký tự sau 90+ giây — **ngay ở lần nạp ĐẦU TIÊN**, phủ định 1
  phần giả thuyết "chỉ hỏng từ lần nạp thứ 2" (phiên 20/21): bản thân
  model này có vẻ có vấn đề NỘI TẠI (khớp lại với nghi ngờ ban đầu ở
  phiên 14), không chỉ do trạng thái sót lại.
- **Lần nạp thứ 2** (Qwen 2.5 1.5B, slot đã có OccultAI-Morpheus trước
  đó): VmRSS trước huỷ = **4.422.776 kB** (~4.4GB, khớp kích thước thật
  của OccultAI-Morpheus-8B q4 + embeddings). Sau khi gọi `llmSlot.reset()`
  (huỷ tường minh, fix phiên 20) → VmRSS = **2.799.740 kB** (~2.8GB) —
  **CHỈ giảm 1.623.036 kB (~1.6GB)**, còn kẹt lại **~2.58GB** so với mức
  nền lúc chưa nạp gì (221MB ở lần 1). Model Qwen 1.5B mới chỉ nặng
  ~800MB trên đĩa — không thể giải thích 2.58GB còn sót lại là "bình
  thường". → **BẰNG CHỨNG CỤ THỂ, ĐO ĐƯỢC: fix thứ tự huỷ-trước-tạo-sau ở
  phiên 20 KHÔNG giải quyết được rò rỉ bộ nhớ.** `llmSlot.reset()`
  (destructor của `Llm`) không giải phóng hết tài nguyên GPU/OpenCL đã
  cấp cho model cũ — đây gần như chắc chắn là hành vi BÊN TRONG thư viện
  MNN (hoặc chính GPU driver OpenCL của thiết bị giữ lại cache/pool), nằm
  ngoài khả năng sửa bằng cách sắp xếp lại lệnh C++ ở tầng wrapper này.
  Ngay sau đó, Qwen 1.5B (load thứ 2) → **LẶP VÔ TẬN** ("((((((") — khớp
  đúng giả thuyết "model B thừa hưởng trạng thái dở dang của model A".
- **Kết luận cập nhật (thay thế hoàn toàn phiên 19/20)**: có khả năng
  ĐANG TỒN TẠI CẢ 2 vấn đề riêng biệt, không loại trừ nhau: (1)
  OccultAI-Morpheus-8B tự nó có vấn đề nội tại (trì trệ ngay cả khi nạp
  đầu tiên, sạch sẽ), VÀ (2) rò rỉ tài nguyên GPU thật sự giữa các lần
  nạp trong cùng tiến trình (đo được bằng VmRSS, ~2.58GB kẹt lại) khiến
  model NẠP SAU (bất kể model gì) dễ bị hỏng theo. Đây là giới hạn THẬT
  của tầng code ứng dụng — sửa triệt để cần sửa/thay thế cách MNN quản lý
  bộ nhớ OpenCL nội bộ, ngoài phạm vi file wrapper `mnn_bridge.cpp` này.
- **Khuyến nghị thực tế cho người dùng** (trong lúc chưa có fix triệt
  để): nếu cần đổi model để dùng nghiêm túc (không chỉ thử nhanh), tốt
  nhất **thoát hẳn app (không chỉ chuyển màn hình) rồi mở lại** trước khi
  nạp model mới — đảm bảo tiến trình mới tinh, VmRSS về đúng mức nền,
  không kế thừa rò rỉ từ model trước.

## B. Gỡ 2 hardcode bị người dùng phát hiện đúng

1. **Prompt "biên tập viên viết truyện" ép cứng vào MỌI tin nhắn chat**
   (`chat_screen.dart` gọi `rag.buildSystemPrompt()` với `userInstruction`
   cố định) — đúng như người dùng nhận ra, kể cả gõ "alo" cũng bị ép
   khung "Bạn là trợ lý viết tiểu thuyết dài kỳ... Trả lời như một biên
   tập viên...". Đã thêm cờ `useNovelPersona` (lưu riêng theo từng
   truyện qua SharedPreferences), icon bật/tắt ngay trên AppBar màn chat
   — TẮT thì bỏ hẳn khung persona, chat tự do như trợ lý AI thường.
2. **Nút chỉnh cỡ chữ "biến mất" khi đã vào trong 1 truyện** — do trước
   đây gắn CỨNG vào 1 mình `NovelListScreen` (màn trước khi vào truyện),
   không có đường quay lại từ trong chat/chương. Tách hộp thoại ra hàm
   dùng chung `showTextScaleDialog()` (`text_scale_service.dart`), gọi
   được từ bất kỳ đâu — đã gắn thêm vào `chat_screen.dart`; các màn khác
   (chương, Bách khoa...) gắn thêm tương tự khi cần, không phải chép lại
   code.

---

**Cập nhật (2026-08-26, phiên 24 — TRA CỨU THẬT theo yêu cầu người dùng
"sao không tra cứu cách MNN/cộng đồng giải quyết vấn đề" — tìm được đầu
mối chính thức từ chính MNN, không còn đoán mù:**

## Kết quả tra cứu

Tìm kiếm changelog chính thức của thư viện MNN (alibaba/MNN, GitHub
Releases) cho thấy **bản 3.4.1** có đúng 1 mục thay đổi khớp gần như
nguyên văn với triệu chứng đã đo được ở phiên 23:

> **"LLM 资源管理优化: LLM 实例内置独立 Executor 并在所有公开方法中使用
> ExecutorScope，确保正确的资源作用域和及时释放，尤其是在 Python 绑定场
> 景中"**
> (dịch: "Tối ưu quản lý tài nguyên LLM: mỗi instance `Llm` giờ tự tạo
> `Executor` RIÊNG và dùng `ExecutorScope` ở MỌI public method, đảm bảo
> phạm vi tài nguyên đúng và giải phóng KỊP THỜI, đặc biệt trong các kịch
> bản dùng qua Python binding.")

Đây gần như chắc chắn xác nhận: `Llm` (lớp C++ app này đang bọc qua
`llm.hpp`) từng có (và theo release note, ĐÃ ĐƯỢC SỬA ở bản 3.4.1) đúng
kiểu lỗi "Executor dùng chung giữa các instance, không giải phóng đúng
lúc" — khớp triệu chứng đo được: model B thừa hưởng trạng thái/tài
nguyên còn sót của model A.

Cũng tìm thấy 1 dòng khác trong nhật ký phát hành app MNN Chat chính
thức, càng củng cố đây LÀ vấn đề CÓ THẬT mà chính đội MNN cũng từng vá:
**"Reuse the loaded runtime session when starting API service for the
same model to avoid extra reloads that could freeze or crash API
startup."** và **"Avoid deadlocks caused by partially initialized mmap
weights during model loading."** — cho thấy việc tái sử dụng
runtime/session giữa các lần nạp model là 1 mảng đã biết có nhiều vấn đề
tinh vi trong chính dự án gốc, không phải điều gì "lạ" hay đặc thù riêng
của app này.

## Vấn đề khi áp dụng vào project này

`build.yml` clone MNN bằng `git clone --depth 1` từ nhánh `master` —
LUÔN lấy đúng commit MỚI NHẤT tại THỜI ĐIỂM CHẠY BUILD, nhiều khả năng
đã SAU bản 3.4.1 (tức đã có fix). Nhưng vì `--depth 1` không giữ lại
tag/version rõ ràng trong log, KHÔNG CÓ CÁCH NÀO xác nhận trước đây build
nào đã dùng đúng commit gì — không thể kết luận "đã có fix mà vẫn còn
lỗi" hay "chưa từng có fix" chỉ từ log ứng dụng.

**Đã thêm bước CI mới** (`build.yml`, ngay sau bước clone MNN): in ra
`git rev-parse HEAD` + ngày commit + thử tìm `MNN_VERSION` trong
`include/MNN/MNNDefine.h` — để MỌI LẦN BUILD SAU đều có bằng chứng rõ
ràng đang dùng đúng commit MNN nào, đối chiếu được với ngày phát hành
3.4.1 khi cần điều tra tiếp (nếu vẫn còn rò rỉ dù build SAU ngày 3.4.1
phát hành, nghĩa là fix đó KHÔNG bao trùm hết trường hợp của app này —
rất có thể do buffer pool riêng của backend OpenCL, khác với `Executor`
chung được nhắc trong changelog).

## Giới hạn tra cứu, nói rõ không giấu

- Không truy cập được trực tiếp nội dung file mã nguồn `llm.hpp`/`llm.cpp`
  thật của MNN qua công cụ tìm kiếm hiện có (kết quả tìm kiếm chỉ trả về
  tóm tắt README/DeepWiki, không phải nội dung file thật) — nên KHÔNG thể
  khẳng định chắc chắn 100% class `Llm` có method public nào để chủ động
  gọi giải phóng/GC bộ nhớ giữa các lần nạp (nếu có, sẽ là cách sửa sạch
  hơn nhiều so với chỉ trông chờ destructor). Không đoán mù tên hàm/API
  cụ thể để tránh viết code gọi nhầm hàm không tồn tại, gây lỗi build.
- Không loại trừ khả năng phần rò rỉ còn lại (nếu build MỚI vẫn còn) nằm
  ở tầng THẤP HƠN `Executor` — cụ thể là bộ nhớ GPU do chính driver OpenCL
  của thiết bị (Adreno/Mali) tự giữ lại làm cache nội bộ, không phải do
  MNN — đây là hành vi driver thường thấy (giữ lại vùng nhớ đã cấp phát
  để tái sử dụng nhanh hơn ở lần sau), nằm hoàn toàn ngoài khả năng kiểm
  soát của cả MNN lẫn app này.

## Việc tiếp theo cần làm (khi có log build mới kèm commit hash)

1. Đối chiếu ngày commit MNN đã build với ngày phát hành 3.4.1 (khoảng
   tháng 3/2026 theo changelog) — nếu build SAU mốc đó mà vẫn rò rỉ, tức
   fix 3.4.1 không đủ, cần tìm hướng khác (nghi ngờ buffer pool OpenCL
   backend, không phải Executor chung).
2. Nếu build TRƯỚC mốc đó (không nên xảy ra với `--depth 1` từ `master`,
   nhưng vẫn nên xác nhận) — thử ép CMake pin về 1 tag cụ thể ≥ 3.4.1
   thay vì luôn lấy `master` mới nhất (đánh đổi: mất đi các fix MỚI HƠN
   nhưng đổi lại có 1 baseline ổn định, dễ so sánh/tái lập lỗi hơn).

## C. Cache autotuning OpenCL dùng chung giữa các model (2026-08-26)

Người dùng chỉ ra mâu thuẫn: ảnh chụp 23/8 cho thấy model 8B (OccultAI-
Morpheus) từng sinh văn bản đầy đủ, bình thường (chỉ "chậm hơn 7B"),
trong khi log đo được ngày 25-26/8 (mục A ở trên, và phiên 19/23) cho
thấy CHÍNH model đó đứng hình gần hoàn toàn (2-21 ký tự / 90-97 giây)
ngay ở LẦN NẠP ĐẦU TIÊN — tức không thể giải thích bằng giả thuyết "trạng
thái sót lại giữa 2 lần nạp" (mục A/B), vì lần nạp đầu tiên không có gì
để sót lại.

Kiểm tra code phát hiện: `MnnBridge.kt` gọi `nativeSetCacheDir(appContext
.cacheDir.absolutePath)` ĐÚNG 1 LẦN DUY NHẤT cho toàn bộ vòng đời app
(cờ `logDirSent`), và giá trị này được dùng thẳng làm `tmp_path` cho
MỌI model — tức cache autotuning kernel OpenCL của MNN (dò workgroup
size tối ưu, vốn có thể mất khá lâu ở lần dò đầu) bị DÙNG CHUNG giữa
tất cả model đã từng test, tích luỹ qua nhiều ngày. Nếu cache key nội
bộ của MNN không phân biệt đủ rõ giữa các kiến trúc khác nhau (8B vs
1.5B vs 7B — vocab/hidden-dim khác hẳn nhau), 1 lần load có thể vô tình
tái sử dụng entry autotuning của model khác, khiến MNN âm thầm chạy
sai/chậm workgroup config mà không crash — khớp với mọi log quan sát
được (luôn "khong crash", chỉ chậm bất thường). Timeline cũng khớp:
23/8 (cache còn sạch, ít model từng test) → 8B chạy ổn; 25-26/8 (sau
nhiều phiên test nhiều model) → 8B đứng hình.

**CHƯA CÓ BẰNG CHỨNG CHẮC CHẮN 100%** đây là nguyên nhân duy nhất — có
thể cộng hưởng với rò rỉ VmRSS thật ở mục A. Nhưng đây là thay đổi rẻ,
an toàn, tách bạch được nguyên nhân bằng log khách quan (không dựa cảm
quan người dùng) — đã sửa `mnn_bridge.cpp`:
- Thêm `sanitizeModelFolderName()` — lấy tên thư mục model, làm sạch
  ký tự không hợp lệ cho tên thư mục.
- Thêm `ensureDirExists()` — tạo thư mục kiểu "mkdir -p", log rõ nếu
  thất bại thay vì âm thầm rơi về cache dùng chung.
- `buildOptimizedOpenCLConfig()` giờ nhận thêm `rawModelPath`, dùng
  `tmp_path = "<cacheDir>/opencl_tuning/<tên_model_đã_làm_sạch>/"` thay
  vì `<cacheDir>` dùng chung cho mọi model như trước.
- Có log `buildOptimizedOpenCLConfig: tmp_path RIENG cho model nay = ...`
  ở mỗi lần load, để lần sau đối chiếu trực tiếp trong `native_debug.txt`
  xem đúng thư mục riêng có được dùng hay không — không cần đoán.

**Việc cần làm tiếp theo (khi có log build mới)**: so log elapsed/ký tự
của model 8B khi nạp đầu tiên (tiến trình sạch, cache thư mục riêng vừa
tạo lần đầu nên vẫn "lạnh") với con số cũ (~21 ký tự/97s). Nếu vẫn y hệt
mức cũ → loại trừ giả thuyết cache chéo, quay lại tập trung vào mục A/B
(rò rỉ VmRSS) hoặc bản thân model/GPU driver. Nếu cải thiện rõ rệt (đo
bằng số, không phải cảm quan) → xác nhận đúng nguyên nhân, giữ nguyên
fix này lâu dài.

## D. Kết quả đo thật của mục C, và 1 lỗi MỚI nghiêm trọng hơn phát hiện ra (2026-08-27)

Log build có fix mục C xác nhận: `buildOptimizedOpenCLConfig: tmp_path
RIENG cho model nay = ".../opencl_tuning/OccultAI-Morpheus-8B-v2-MNN-q4-chinh"
(tao thu muc THANH CONG)` — fix chạy đúng thiết kế. Nhưng kết quả đo:

- Lần nạp thứ 1 trong phiên: prompt dài (Story Bible + persona, 718 ký
  tự) — không tách được prefill/decode từ log, không dùng để so sánh.
- Lần nạp thứ 3 (cùng máy, cache autotuning đã "ấm" từ các lần trước —
  bằng chứng: `load()` chỉ mất **0,176 giây**, quá nhanh so với lần nạp
  đầu tiên từng thấy ~12 giây): prompt ngắn `"alo"` (5 ký tự) — vẫn đứng
  hình y hệt, chỉ sinh **7 ký tự trong 212 giây**.

→ **KẾT LUẬN CHÍNH THỨC: giả thuyết mục C (cache autotuning OpenCL dùng
chung/nhiễu) BỊ LOẠI HẲN.** Cache ấm, load nhanh, nhưng decode vẫn thảm
hại như cũ — bottleneck nằm ở chính bước sinh token, không phải ở bước
dò/nạp kernel. Giữ nguyên code mục C (không hại gì, và tách cache theo
model vẫn là vệ sinh tốt), nhưng KHÔNG coi đây là nguyên nhân của vụ
đứng hình nữa. Giả thuyết còn sống, mạnh nhất hiện tại: bảng embedding/
lm_head chưa lượng tử hoá (`embeddings_bf16.bin`, 1,05GB bf16, model
Qwen không có file này) — cần đọc/tính lại toàn bộ ~1GB đó ở MỖI token
sinh ra trên GPU di động, đúng kiểu nghẽn băng thông bộ nhớ. Hướng sửa
thật (nếu đúng): export lại model với `--embed_bit 4`, không phải sửa
code app.

### Lỗi MỚI, nghiêm trọng hơn: lệnh generate() thứ 2 treo VÔ THỜI HẠN, không hề được watchdog bắt

Ngay sau khi lệnh generate() thứ 1 (prompt "alo") bị watchdog 90s cắt
**sạch sẽ** (exception ném ra, bắt được, log đầy đủ, hàm trả về bình
thường — "khong crash"), người dùng gửi tin thứ 2 ngay lập tức (cùng
model, không đổi). Log cho thấy lệnh generate() thứ 2 này BẮT ĐẦU đầy đủ
(qua hết các bước init, set_config thành công) rồi gọi `llm->response()`
— và **KHÔNG BAO GIỜ QUAY LẠI**: không có dòng log nào tiếp theo (không
`[CHAN DOAN TRI TRE]`, không `onToken`, không gì cả) trong hơn **12
PHÚT**, cho tới khi người dùng thử nạp model khác và bị native từ chối
đúng như thiết kế mục 5.67 (tránh use-after-free) — đây là cách DUY NHẤT
lỗi này bị phát hiện, hoàn toàn gián tiếp.

**Nguyên nhân gốc (giả thuyết mạnh, chưa xác minh 100% vì không có mã
nguồn nội bộ MNN)**: cơ chế huỷ hiện tại của app là ném C++ exception
(`GenerationStoppedException`) từ TRONG `xsputn` — callback được MNN gọi
giữa chừng lúc `llm->response()` đang chạy. Đây KHÔNG phải cách huỷ
"sạch" đối với nội bộ MNN: exception này unwind ra khỏi `response()`
giữa chừng, rất có thể để lại KV-cache hoặc hàng đợi lệnh OpenCL dở
dang, không nhất quán. Lệnh generate() SAU trên CHÍNH object `Llm*` đó
(chưa được nạp lại) kế thừa đúng trạng thái hỏng này → treo vô thời hạn
khi cố dùng lại.

**Lỗ hổng thiết kế bị lộ ra thêm**: toàn bộ 3 lớp phòng vệ (watchdog trì
trệ, huỷ chủ động, phát hiện lặp) đều nằm BÊN TRONG `xsputn` — tức chỉ
được kiểm tra mỗi khi model THỰC SỰ ghi ra ít nhất 1 ký tự. Nếu
`llm->response()` treo hoàn toàn ngay từ đầu (0 ký tự, như log này), 3
lớp phòng vệ đó KHÔNG BAO GIỜ được gọi tới — không có bất kỳ bảo vệ nào
theo đúng nghĩa "thời gian thật, độc lập với việc đã sinh được chữ hay
chưa".

**Đã sửa** (`mnn_bridge.cpp`, an toàn/phòng thủ, KHÔNG cần biết chính
xác cơ chế MNN bên trong để vẫn có tác dụng):
- Cờ `g_slotNeedsFullReload[slot]` — set `true` ngay trong CẢ 2 nhánh
  catch bao quanh `llm->response()` (GenerationStoppedException lẫn
  exception khác) — vì bất kỳ lần nào bị ngắt giữa chừng đều đáng ngờ
  với nội bộ MNN, không chỉ riêng trường hợp trì trệ.
- `nativeGenerate()` kiểm tra cờ này NGAY ĐẦU HÀM (trước khi chạm tới
  `llm->response()`) — nếu slot đang bị đánh dấu, TỪ CHỐI NGAY LẬP TỨC
  với thông báo rõ ràng cho người dùng ("cần nạp lại model"), thay vì
  để lệnh đó tự treo rồi 12 phút sau mới phát hiện gián tiếp qua đường
  nạp model khác.
- `nativeLoadModel()` xoá cờ này sau khi tạo + nạp xong 1 object `Llm`
  hoàn toàn mới (không còn lý do nghi ngờ trạng thái cũ).
- Thông báo từ chối nạp model (khi slot còn lệnh generate mồ côi) giờ
  tính và in kèm **đã treo bao nhiêu giây** (dựa `g_generateStartTime`),
  thay vì chỉ nói chung chung — để lần sau không cần tự trừ 2 mốc log.

**Giới hạn thật của fix này, nói rõ không giấu**: đây CHỈ chặn được kịch
bản "lệnh thứ 2 sau lệnh thứ 1 vừa bị dừng-sạch" — vì lúc đó cờ
`g_generatingInProgress` đã kịp reset về false, lệnh thứ 2 mới có cơ hội
chạy tới và bị chặn bởi cờ MỚI này. Fix KHÔNG (và không thể, ở tầng app)
giải quyết trường hợp `llm->response()` tự nó treo vô thời hạn ngay từ
lệnh ĐẦU TIÊN (không có lệnh nào trước đó để đánh dấu) — trường hợp đó
vẫn phải đợi người dùng tự phát hiện qua việc thử nạp model khác, vẫn
không có watchdog thời gian thật độc lập với `xsputn`. Muốn giải quyết
triệt để cần 1 cơ chế giám sát ở luồng RIÊNG (không phụ thuộc callback
của MNN) có khả năng buộc kết thúc lệnh treo — rủi ro cao hơn nhiều
(huỷ cứng 1 luồng đang kẹt trong driver GPU có thể crash cả tiến trình),
CHƯA làm, cần bàn kỹ trước khi động vào.

## E. Nghi vấn máy ngủ sâu giữa chừng lúc "trì trệ" — CHƯA XÁC NHẬN, đã thêm log để xác nhận (2026-08-27)

Người dùng test lại nhiều lần liên tiếp cùng máy, phát hiện: **model
8B không hề nóng/giật lag khi bị watchdog CẮT SỚM (2-7 ký tự) — chỉ
nóng/giật lag khi sinh THÀNH CÔNG hoặc sinh RÁC (nhiều ký tự, chạy lâu)**.
Đây là bằng chứng vật lý quan trọng: nếu GPU thực sự phải tính toán liên
tục suốt cả quá trình "trì trệ" (như giả thuyết `embeddings_bf16.bin`
ngụ ý), máy phải nóng lên tương ứng — không nóng nghĩa là GPU **không hề
bận** trong phần lớn khoảng thời gian đó, tức đang bị KẸT/CHỜ, không
phải đang tính chậm.

Đối chiếu với 1 phát hiện CŨ đã có sẵn trong code, TỪ TRƯỚC cả phiên
debug này (xem `MnnBridge.kt`, khai báo `directWakeLock`): người dùng
từng phát hiện `std::chrono::steady_clock` (map tới `CLOCK_MONOTONIC`)
KHÔNG đếm thời gian máy ngủ sâu (suspend), trong khi timestamp log
(giờ tường, `system_clock`) VẪN đếm — chênh lệch giữa 2 mốc này (~379s
lúc đó) chính là thời gian máy đã ngủ sâu giữa chừng lúc đang sinh văn
bản. Đã sửa 1 phần (giữ `directWakeLock` đồng bộ, không qua post/Intent,
đóng khoảng hở lúc BẮT ĐẦU lệnh) — nhưng phép đo song song (steady vs
wall) **chỉ tồn tại ở nhánh THÀNH CÔNG** của `llm->response()` (log
`THOI GIAN THAT` / `THOI GIAN TUONG`), KHÔNG tồn tại ở nhánh bị watchdog
cắt — nghĩa là suốt từ đầu buổi debug này tới giờ, **mọi lần "trì trệ"
quan sát được chưa từng được đo bằng wall_clock**, không biết chắc có
đúng do ngủ sâu hay không, dù giả thuyết này khớp rất chặt với việc
không nóng máy.

**Đã sửa** (`mnn_bridge.cpp`, chỉ thêm log, không đổi hành vi): nhánh
watchdog trì trệ (trong `xsputn`) giờ đo thêm `wallStartTime_`
(`system_clock`) song song với `startTime_` (`steady_clock`, đã có sẵn),
in ra CẢ 2 mốc + chênh lệch ngay trong dòng log `[CHAN DOAN TRI TRE]` —
nếu lần "trì trệ" tiếp theo cho thấy STEADY chỉ ~90s (đúng bằng ngưỡng
watchdog) nhưng WALL lệch xa hẳn (như 1967s/119s đã thấy) → XÁC NHẬN
CHẮC CHẮN nguyên nhân là ngủ sâu giữa chừng, không cần đoán nữa. Nếu cả
2 mốc gần bằng nhau (steady ≈ wall) mà vẫn trì trệ hàng trăm/nghìn giây
→ loại hẳn giả thuyết ngủ sâu, quay lại các giả thuyết compute-bound cũ
(`embeddings_bf16.bin`...).

**Việc cần làm tiếp theo**: build lại, lặp lại đúng kịch bản gây trì
trệ (đặc biệt prompt Bible dài — nơi hiện tượng nóng máy rõ nhất), gửi
log — tìm đúng dòng `[CHAN DOAN TRI TRE] ... STEADY (ms)=... WALL
(ms)=...` để đọc kết quả trực tiếp, không cần tự trừ 2 mốc log khác
dòng nữa.

## F. XÁC NHẬN CHẮC CHẮN — máy ngủ sâu giữa chừng, và tìm ra nguyên nhân gốc tại sao WakeLock không có tác dụng (2026-08-27)

Log build có fix mục E trả về kết quả: `STEADY (ms)=137495, WALL
(ms)=1376108, CHENH LECH 1238613ms`. **Xác nhận chắc chắn, không còn là
giả thuyết**: máy đã ngủ sâu **~20,6 phút** giữa chừng lúc đang sinh văn
bản (bước "trì trệ" THẬT chỉ mất ~137,5 giây thời gian máy thức — vẫn
chậm, nhưng không phải hàng nghìn giây). Điều này giải thích được TOÀN
BỘ độ dao động khó hiểu đã thấy suốt buổi debug (1076s/1967s/119s/56s...
cho cùng 1 shape) — không phải do model/cache/GPU, mà do máy ngủ hay
không ngủ, ngủ bao lâu, mỗi lần test khác nhau hoàn toàn ngẫu nhiên.

Người dùng phản ánh đúng: **"mất luôn tính năng chạy ngầm"**. Xác nhận:
đây KHÔNG phải do các fix mục C/D vừa thêm (2 fix đó chỉ đụng tới
`mnn_bridge.cpp`, không hề đụng gì tới `MnnBridge.kt`/WakeLock) — đây là
1 lỗi CÓ SẴN từ trước, chỉ là giờ mới có số liệu để nhìn thấy rõ.

**Nguyên nhân gốc tìm được** (đọc kỹ `MnnBridge.kt`): `generate()` và
`loadModel()` chỉ gọi `acquireDirectWakeLock()` khi `pipelineDepth == 0`
— logic này TIN TƯỞNG rằng nếu `pipelineDepth > 0`, đã có 1 lệnh
`beginPipeline()` NGOÀI đang giữ sẵn WakeLock hộ. Nhưng `pipelineDepth`
chỉ được reset về 0 thủ công qua `cancelGenerate`, hoặc giảm dần qua
`endPipeline()` — và `endPipeline()` phía Dart (`chat_screen.dart`, khối
`finally`) CHỈ chạy được nếu lệnh native trước đó THẬT SỰ trả về (dù
thành công hay lỗi). Nếu 1 lệnh `generate()` bị TREO HOÀN TOÀN (đúng
kịch bản đã xác nhận thật ở mục D — lệnh #2 treo 12 phút không 1 dòng
log), phía Dart cũng bị `await` kẹt theo, khối `finally { endPipeline()
}` KHÔNG BAO GIỜ CHẠY được — `pipelineDepth` bị **rò rỉ, kẹt ở giá trị
dương VĨNH VIỄN** trong suốt phần đời còn lại của tiến trình. Từ đó trở
đi, MỌI lệnh `generate()`/`loadModel()` sau đó đều đi vào nhánh
`pipelineDepth > 0`, **bỏ qua hoàn toàn** `acquireDirectWakeLock()` — dù
không hề có WakeLock thật nào đang được giữ (cái WakeLock từ lệnh rò rỉ
gốc, nếu từng được giữ, cũng đã hết hạn từ lâu, tối đa 40 phút) — máy
được tự do ngủ sâu bất cứ lúc nào màn hình tắt.

Đúng log tối nay: `pipelineDepth=2` **ngay từ lần load MODEL ĐẦU TIÊN**
trong tiến trình (native side confirm "lan nap thu 1") — chứng tỏ có
ít nhất 2 lệnh rò rỉ từ TRƯỚC ĐÓ trong cùng phiên test kéo dài cả buổi
tối, chưa từng được dọn.

**Đã sửa** (`MnnBridge.kt`, cả `loadModel` lẫn `generate`): bỏ điều
kiện `pipelineDepth == 0` khỏi việc gọi `acquireDirectWakeLock()` — giờ
LUÔN gọi vô điều kiện, mỗi lần, bất kể `pipelineDepth`. An toàn tuyệt
đối vì đây là WakeLock KHÔNG đếm tham chiếu
(`setReferenceCounted(false)`) — gọi `acquire()` nhiều lần chỉ làm mới
hạn 40 phút, không cần `release()` thêm tương ứng, không có rủi ro giữ
WakeLock "thừa" mãi mãi. Logic bật/tắt Foreground Service (thông báo)
qua `pipelineDepth` giữ nguyên không đổi — chỉ tách riêng phần WakeLock
ra khỏi sự tin tưởng vào bộ đếm đó.

**Giới hạn thật, không giấu**: fix này chỉ đảm bảo WakeLock LUÔN được
giữ tươi cho MỌI lệnh — không sửa được gốc rễ việc `pipelineDepth` vẫn
có thể rò rỉ (vẫn cần dọn qua `cancelGenerate` hoặc khởi động lại app),
cũng không sửa được việc lệnh `generate()` có thể treo (mục D, vẫn còn
giới hạn thật đã ghi ở đó). Đây là 1 lớp phòng vệ ĐỘC LẬP, đúng đối
tượng gây ra triệu chứng cụ thể "mất chạy ngầm" — không phải sửa hết
mọi vấn đề còn lại trong hệ thống.

**XÁC NHẬN fix có tác dụng thật bằng số liệu (2026-08-28)**: log build
mới cho thấy `STEADY (ms)=140018, WALL (ms)=180173, CHENH LECH 40155ms`
— khoảng ngủ sâu giữa chừng giảm từ ~1.238.613ms (~20,6 phút, TRƯỚC fix)
xuống còn ~40.155ms (~40 giây, SAU fix) — giảm hơn 30 lần. Fix WakeLock
xác nhận có tác dụng thật.

Nhưng kết quả BÊN NGOÀI (bị watchdog cắt, lệnh sau bị từ chối) KHÔNG đổi
— vì đây luôn là 2 lớp vấn đề TÁCH BIỆT: máy ngủ sâu (đã sửa) khác hẳn
với việc bản thân tính toán chậm ngay cả lúc máy THỨC THẬT (140s máy
thức chỉ sinh được 2 ký tự — chưa sửa, không nằm trong phạm vi fix
WakeLock). Với cache-tuning đã loại (mục C/D) và ngủ sâu giờ chỉ còn dư
không đáng kể (~40s so với 140s steady), giả thuyết đứng vững nhất hiện
tại quay lại `embeddings_bf16.bin` (bảng embedding ~1GB chưa lượng tử
hoá, phải đọc lại mỗi bước) — đây là đặc điểm CỦA CHÍNH FILE MODEL, hướng
sửa thật (nếu đúng) là export lại model, không còn nằm trong phạm vi sửa
được ở `mnn_bridge.cpp`/`MnnBridge.kt` nữa.

## G. Convert lại model với `embed_bit=4` — KẾT QUẢ: LOẠI HẲN giả thuyết `embeddings_bf16.bin` (2026-08-28)

Đã convert lại đúng model 8B bằng notebook cập nhật (`--embed_bit 4`) —
output xác nhận đúng: `embeddings_int4.bin` (297MB, nén từ 1,05GB bf16
xuống int4), `config.json` tự trỏ đúng file mới. Convert chạy đúng thiết
kế, không có gì sai ở bước này.

So sánh STEADY (cùng điều kiện: Bible bật, prompt 724 ký tự, "xin chào",
lần nạp đầu tiên trong tiến trình):
- Model CŨ (bf16 embedding): STEADY=140.018ms, 2 ký tự.
- Model MỚI (int4 embedding): STEADY=138.750ms, 2 ký tự.

**Gần như giống hệt nhau (chênh <1%)** — đúng tiêu chí đã đặt ra trước khi
test ("nếu STEADY gần như không đổi → loại hẳn giả thuyết này"). **KẾT
LUẬN DỨT ĐIỂM: `embeddings_bf16.bin` KHÔNG phải nguyên nhân gây chậm.**
Không tiếp tục điều tra hướng này nữa. Khả năng cao nhất còn lại: bản
thân kiến trúc/kích thước 8B đơn giản quá nặng cho GPU của máy đang test
ở tầng tính toán cốt lõi — không phải lỗi có thể sửa bằng code app hay
convert lại model.

## H. Người dùng CHẤP NHẬN model chậm — chỉ gỡ lớp "trì trệ" (2026-08-28, đã sửa lại đúng phạm vi)

Người dùng xác nhận: chấp nhận model 8B chậm, không cần sửa tiếp phần tốc
độ, và muốn app **không tự cắt CHỈ VÌ CHẬM**. Yêu cầu ban đầu CHỈ nói tới
lớp "trì trệ" — lượt đầu tôi hiểu sai phạm vi, đã lỡ xoá luôn cả lớp "lặp
vô tận" (dù người dùng không yêu cầu); người dùng chỉnh lại ngay ("chặn
khi chậm khác chặn khi sinh rác/lặp từ"), đã phục hồi đúng lại.

**Trạng thái ĐÚNG hiện tại của `mnn_bridge.cpp` (`JniStreamingBuf::xsputn`)**:
1. Lớp "trì trệ" (mục 19, elapsed > 90s && chars < 80) — **ĐÃ XOÁ HẲN**,
   kể cả phần đo STEADY/WALL đi kèm (mục E/F) và 2 member
   `startTime_`/`wallStartTime_` không còn dùng. **Hệ quả cần biết**: mất
   luôn công cụ đo chênh lệch máy-ngủ-sâu (STEADY vs WALL) — muốn đo lại
   độ tin cậy của fix WakeLock (mục F) phải thêm lại đoạn đo đó RIÊNG,
   tách khỏi mọi hành vi tự cắt (chưa làm, chờ người dùng xác nhận có cần
   không).
2. Lớp "lặp vô tận" (`looksLikeRepetitionLoop()`, kiểm tra 1 ký tự chiếm
   >85% cửa sổ hoặc cụm 2-6 ký tự lặp khít) — **VẪN CÒN NGUYÊN**, hoạt
   động bình thường như trước giờ. KHÔNG bị đụng tới.
3. Lớp huỷ do người dùng chủ động bấm (`cancelGenerate`) — không đổi.

**Lưu ý quan trọng, tránh nhầm lẫn ở tầng khác**: `local_provider.dart`
(Dart) có 1 bộ phát hiện lặp vô tận RIÊNG, ĐỘC LẬP với bản native ở trên
(khác cơ chế: bản Dart tự gọi `cancelGenerate()` khi phát hiện, bản native
tự ném exception) — bộ này **chưa từng bị đụng tới trong suốt quá trình
trên**, vẫn hoạt động đầy đủ, không nằm trong phạm vi mục H này.

**Giới hạn thật còn lại của việc sinh chữ**: `max_new_tokens` (1024, do
MNN tự dừng), việc người dùng tự bấm huỷ, và lớp phát hiện lặp vô tận (cả
2 tầng, Dart lẫn native) — KHÔNG còn giới hạn THỜI GIAN nào (đây là phần
duy nhất đã bỏ). Cơ chế `g_slotNeedsFullReload` (mục D) áp dụng cho MỌI
lần bị ngắt giữa chừng (kể cả do lặp vô tận hoặc do người dùng huỷ), giữ
nguyên không đổi.

**Sửa thêm cùng ngày**: phép đo STEADY vs WALL (mục E/F) trước đây khai
báo TRONG khối `try` bao quanh `llm->response()`, nên chỉ đo được ở nhánh
THÀNH CÔNG. Đã chuyển `tSteadyStart`/`tWallStart` ra NGOÀI `try` và thêm
đúng phép đo đó vào CẢ 2 khối `catch` (huỷ/lặp vô tận, và lỗi khác) — giờ
đo được ở MỌI cách 1 lệnh `generate()` kết thúc, không riêng lúc thành
công nữa. Đây là công cụ DUY NHẤT còn lại để xác nhận fix WakeLock (mục
F) có thật sự ổn định hay không (câu hỏi "chạy ngầm đã khôi phục chưa"
vẫn đang bỏ ngỏ — mục F chỉ có 1 lần đo thành công, 1 lần đo sau đó
(362.715ms) chưa rõ có đúng bản có fix hay không).

Cũng dọn 1 nhánh code đã chết: `userMsg` trong catch `GenerationStoppedException`
từng có nhánh `else if (reason.find("tri tre"))` cho lớp trì trệ — nhánh
đó không còn chỗ nào ném exception với lý do đó nữa (đã bỏ ở trên), xoá
để tránh hiểu nhầm sau này là lớp trì trệ vẫn còn tồn tại đâu đó.

## I. Tra cứu kiến trúc model + 2 lỗi UX bắt người dùng làm thủ công (2026-08-29)

**Tra cứu kiến trúc**: xác nhận OccultAI/Morpheus-8B fine-tune từ
`nvidia/Llama-3.1-Nemotron-8B-UltraLong-1M-Instruct` — kiến trúc **Llama
3.1**, không phải Qwen. Giả thuyết "MNN tối ưu Qwen hơn do cùng hãng
Alibaba" **CHƯA kiểm chứng được** — không tìm thấy bằng chứng trực tiếp
nào (mọi kết quả tìm kiếm về hiệu năng Qwen-vs-kiến-trúc-khác đều là của
llama.cpp, không phải MNN). Muốn kiểm chứng thật cần 1 model Llama-kiến-
trúc cỡ nhỏ (~1.5-3B) test trên máy, so với Qwen 1.5B đã có sẵn — chưa có
dữ liệu đó.

### I.1 — Tự động nạp lại model, không bắt người dùng đổi qua lại thủ công

Trước đây: khi 1 lệnh `generate()` bị ngắt giữa chừng (huỷ/lặp vô tận),
native đánh dấu `g_slotNeedsFullReload[slot]=true` (mục D) — nhưng
`ensureLoaded()` phía Dart chỉ so `_loadedPath == modelPath` rồi bỏ qua
hẳn bước gọi `loadModel()` native, KHÔNG hề biết cờ này tồn tại. Kết quả
(xác nhận qua ảnh chụp thật): người dùng gửi lại tin nhắn bao nhiêu lần
cũng nhận đúng 1 thông báo "Cần nạp lại model..." lặp lại y hệt, không tự
hết — phải tự tay đổi sang model khác rồi đổi lại, hoặc khởi động lại
app, mới hết.

**Đã sửa, 3 tầng**:
- `mnn_bridge.cpp`: thêm JNI export `nativeNeedsFullReload(slot)` — đọc
  thẳng `g_slotNeedsFullReload[slot]`.
- `MnnNative.kt` + `MnnBridge.kt`: khai báo `external fun` tương ứng +
  case `"needsFullReload"` trong method channel (theo đúng khuôn mẫu
  `isLoaded`/`isSlotGenerating` đã có sẵn).
- `local_provider.dart`, `ensureLoaded()`: TRƯỚC khi quyết định bỏ qua
  bước `loadModel()` (do path khớp), hỏi thẳng native qua
  `needsFullReload` — nếu đang cần nạp lại, KHÔNG return sớm, chạy tiếp
  xuống gọi `loadModel()` thật (dù cùng `modelPath`) — native sẽ tạo
  `Llm` object mới, tự xoá cờ (đã có sẵn logic này từ mục D). Người dùng
  không cần biết/làm gì thêm — lần chat tiếp theo tự động nạp lại, chỉ
  chậm hơn đúng 1 lần bằng thời gian load model bình thường.

### I.2 — Tự dọn cache autotuning OpenCL, không để phình vô hạn

Kể từ khi tách cache theo từng model (mục C), thư mục
`<cacheDir>/opencl_tuning/` tích luỹ 1 thư mục con cho MỖI model từng
dùng qua, không có cơ chế dọn — xác nhận qua ảnh chụp Cài đặt Android:
"Bộ nhớ đệm" của app phình tới 1,66GB sau 1 buổi debug dùng nhiều bản
model 8B khác nhau (bf16 embedding, int4 embedding, Qwen...). Rà lại toàn
bộ codebase xác nhận không có chỗ nào khác trong app ghi vào `cacheDir`
ngoài đúng thư mục này — nhiều khả năng đây là nguồn chính, dù không loại
trừ hoàn toàn khả năng framework/thư viện khác ghi thêm gì đó nhỏ vào đó
mà code app không thấy được.

**Đã sửa** (`mnn_bridge.cpp`, hàm mới `pruneOpenCLTuningCacheIfNeeded()`,
gọi từ `buildOptimizedOpenCLConfig()` mỗi lần nạp model): tính tổng dung
lượng toàn bộ `opencl_tuning/`, nếu vượt hạn mức **500MB** thì tự xoá bớt
các thư mục con CŨ NHẤT (theo thời gian sửa đổi lần cuối, `mtime`) cho
tới khi dưới hạn mức — KHÔNG BAO GIỜ xoá thư mục của model đang chuẩn bị
dùng ngay trong lệnh nạp đó. Log rõ từng thư mục bị xoá + dung lượng, để
tra được sau này nếu cần.

**Đánh đổi cần biết**: model nào bị dọn cache sẽ phải tune lại từ đầu ở
lần dùng TIẾP THEO (chậm hơn 1 lần, như lần nạp đầu tiên của 1 model
mới) — đây là đánh đổi hợp lý giữa dung lượng và tốc độ, hạn mức 500MB
là số chọn tạm hợp lý (đủ vài model), có thể chỉnh nếu cần qua đúng 1
hằng số `kOpenCLTuningCacheCapBytes`.

## J. Không có API "nhẹ" để né nạp lại — đã tra cứu kỹ, và đã thêm log đo tách riêng từng bước (2026-08-29)

Người dùng hỏi thẳng: model đã nằm trong RAM (mmap), sao mỗi lần
`g_slotNeedsFullReload` kích hoạt vẫn phải "nạp lại" — có cách nào nhẹ
hơn không. Đã tra tài liệu chính thức MNN (mục "ChatMessage đa lượt"):
cách CHÍNH THỨC để tiếp tục hội thoại là gọi `response()` lại trên
**CÙNG 1 object**, không hề nạp lại gì — đúng như luồng chat bình thường
app đã làm. **Không tìm thấy** `reset()`/`clearHistory()` hay bất kỳ API
nào khác để dọn nhẹ trạng thái mà GIỮ NGUYÊN object/context OpenCL.

Lý do phải huỷ+dựng lại toàn bộ (`llmSlot.reset()` + `Llm::createLLM()`)
không phải vì trọng số (weights) cần đọc lại (chúng vẫn nằm nguyên trong
RAM nhờ `use_mmap`) — mà vì **context OpenCL** (hàng đợi lệnh GPU, kernel
đã biên dịch/tune) có thể ở trạng thái không nhất quán sau 1 lần bị ngắt
bất thường (mục D) — và MNN không có tài liệu nào xác nhận trạng thái đó
sẽ ra sao, nên huỷ+dựng lại là cách DUY NHẤT hiện biết chắc an toàn.

Số liệu cũ (từ nhiều log khác nhau) MÂU THUẪN nhau về thời gian `load()`
thật sự mất bao lâu khi "nạp lại" (0,176s tới ~12s, kể cả khi cache
autotuning đã ấm) — không đủ để trả lời "nhanh hơn bao nhiêu" nếu bỏ bớt
bước nào đó. **Đã thêm log đo tách riêng** (không đổi hành vi, chỉ thêm
chỉ số) cho từng bước:
- `mnn_bridge.cpp`, `nativeLoadModel()`: đo riêng `reset()`, `createLLM()`,
  `load()` (nhánh OpenCL mặc định) — in kèm số mili-giây ngay trong đúng
  dòng log đã có (không thêm dòng log mới, chỉ nối thêm vào cuối).
- `MnnBridge.kt`, `setupQnnEnvironmentOnce()`: đo cả 2 nhánh (bỏ qua vì
  đã chạy trong tiến trình này / chạy đầy đủ lần đầu) — để tách hẳn khỏi
  phần native, biết chắc có phải thủ phạm hay không (nghi vấn: nếu Android
  đã giết tiến trình app giữa các lần test dài — rất có thể xảy ra suốt
  buổi test kéo dài với nhiều khoảng tắt màn hình — biến static
  `qnnEnvSetupDone` sẽ reset về false, khiến 4-5 lần `System.load()` thất
  bại phải chạy lại mỗi lần, cộng thêm thời gian không liên quan gì tới
  `load()` model thật).

**Việc cần làm tiếp theo**: khi `g_slotNeedsFullReload` kích hoạt lần
sau, đọc đúng 3-4 con số mới trong log (`reset() mat ...ms`, `createLLM()
mat ...ms`, `load() mat ...ms`, và dòng `setupQnnEnvironmentOnce` cho
biết BỎ QUA hay CHẠY ĐẦY ĐỦ) — mới biết chính xác nên nhắm bỏ bớt bước
nào, thay vì đoán.

## L. Sửa TẬN GỐC — đổi mô hình sở hữu object sang shared_ptr, bỏ hẳn "TỪ CHỐI nạp model" (2026-08-30)

Log thật xác nhận đúng ca xấu nhất: lệnh generate() TREO THẬT SỰ (0 ký
tự, KHÔNG hề ném exception) khi đổi từ model 1.8B sang 8B — `g_slotNeedsFullReload`
chưa từng bật (vì không có exception), nên fix tự nạp lại (mục I.1) không
áp dụng được. 6,5 phút sau, người dùng thử đổi lại đúng model đó, native
từ chối với thông báo đã treo ~320 giây. Người dùng phản bác đúng: đề
xuất "đợi 180s rồi chỉ LOG cảnh báo" của phiên trước là vá víu, né tránh
gốc rễ thay vì giải quyết — yêu cầu sửa TẬN GỐC: nạp lại NGAY LẬP TỨC, dù
lệnh cũ có treo hay không, KHÔNG ĐƯỢC crash.

**Gốc rễ thật**: mọi lần "từ chối nạp model" (mục D và các mục sau) đều
xuất phát từ 1 nguyên nhân duy nhất — `g_slots` dùng `unique_ptr` (1 chủ
sở hữu). Huỷ object trong khi 1 luồng khác (lệnh generate mồ côi) vẫn có
thể đang cầm con trỏ tới nó → use-after-free thật → crash SIGSEGV (đã
từng xác nhận qua log CI, xem comment gốc trong code) — nên buộc phải TỪ
CHỐI thay vì mạo hiểm huỷ. Đây LÀ đánh đổi đúng đắn lúc đó, nhưng là giải
pháp NÔNG — xử lý triệu chứng (chặn crash bằng cách chặn luôn hành động),
không xử lý được nguyên nhân (đối tượng vẫn không thể huỷ an toàn khi
đang được dùng).

**Giải pháp gốc**: đổi `g_slots` từ `unique_ptr<Llm>` sang `shared_ptr<Llm>`.
Cơ chế đếm tham chiếu (reference counting) của `shared_ptr` giải quyết
ĐÚNG bài toán này theo cách kinh điển trong C++: mỗi lệnh `nativeGenerate()`
giờ tự giữ 1 BẢN SAO shared_ptr riêng (`slotShared()`, sống suốt cả hàm)
— khi `nativeLoadModel()` "thay thế" con trỏ trong `g_slots[slot]` bằng
object mới, object CŨ **không hề bị huỷ ngay** nếu vẫn còn ai đó (lệnh
mồ côi) giữ tham chiếu — chỉ thực sự giải phóng khi KHÔNG CÒN AI giữ nữa
(lệnh mồ côi tự trả về, dù trễ bao lâu, dù không bao giờ — trường hợp
"không bao giờ" thì object đó rò rỉ vĩnh viễn, nhưng đây CHÍNH XÁC là số
phận của nó ngay cả ở thiết kế CŨ khi treo mãi mãi — không tệ hơn).

**Đã sửa** (`mnn_bridge.cpp`):
- `g_slots`: `unique_ptr<Llm>` → `shared_ptr<Llm>`.
- Thêm `slotShared(slot)` — trả bản sao shared_ptr (khác `slotOrNull()`
  cũ, vẫn giữ nguyên cho 2 chỗ chỉ cần kiểm tra nhanh, không cần giữ sống
  lâu).
- `nativeGenerate()`: đổi sang giữ `llmKeepAlive` (shared_ptr) sống suốt
  hàm, thay vì mượn raw pointer tạm thời.
- **BỎ HẲN** khối "TỪ CHỐI NẠP MODEL MỚI" trong `nativeLoadModel()` — giờ
  LUÔN tiến hành nạp model mới ngay, chỉ còn ghi log thông tin nếu phát
  hiện có lệnh mồ côi (không còn ảnh hưởng gì tới việc nạp có thành công
  hay không).
- Thêm `g_slotEpoch[slot]` (tăng dần mỗi lần nạp model mới thành công) +
  sửa `LoadingGuard` nhận biết epoch: chỉ xoá cờ `g_generatingInProgress`
  nếu epoch lúc bắt đầu vẫn khớp epoch hiện tại — tránh trường hợp lệnh
  mồ côi (chạy rất trễ, cuối cùng cũng trả về) vô tình xoá NHẦM cờ đang
  thuộc về 1 lệnh MỚI hoàn toàn (chạy trên object mới sau khi đã nạp lại
  — nếu không có epoch, đây sẽ là 1 race condition thật, cho phép 2 lệnh
  generate() chạy chồng lên nhau trên cùng 1 object mới).
- Nạp model mới thành công giờ chủ động đặt lại `g_generatingInProgress[slot]
  = false` (object mới tinh, chưa có gì chạy trên nó) — không còn phụ
  thuộc vào việc lệnh cũ có bao giờ tự dọn cờ hay không.

**Đã sửa thêm** (`local_provider.dart`, `ensureLoaded()`): trước đây chỉ
hỏi `needsFullReload` (chỉ bật khi dừng SẠCH, có exception) — giờ hỏi
THÊM `isSlotGenerating` nếu `needsFullReload` là false. Logic: nếu Dart
CHUẨN BỊ bắt đầu 1 lượt chat MỚI mà native báo "đang generating", điều đó
CHỈ có thể là 1 lệnh mồ côi từ phiên trước (Dart chưa hề tự gửi lệnh nào
của lượt hiện tại) — coi như cần nạp lại y hệt `needsFullReload`. An toàn
để nạp lại ngay cả khi đang "generating" thật, nhờ đúng cơ chế shared_ptr
ở trên. Kết hợp 2 điều kiện này phủ được CẢ 2 trường hợp: dừng sạch (có
exception) VÀ treo thật (không exception) — không còn khoảng trống nào
giữa 2 cơ chế cũ (mục I.1) như trước.

**Rủi ro còn sót lại, nói rõ không giấu**: fix này giải quyết TRIỆT ĐỂ
rủi ro use-after-free ở tầng C++ (đối tượng, con trỏ) — đây là loại lỗi
hiểu rõ cơ chế, giải quyết dứt điểm bằng shared_ptr là đúng chuẩn. NHƯNG
**không loại trừ hoàn toàn** 1 rủi ro khác đã ghi nhận từ mục A/B: nếu
backend OpenCL của MNN có trạng thái TOÀN CỤC/static (không gắn với vòng
đời từng object `Llm` — nghi vấn chưa xác minh được, vì không có mã nguồn
nội bộ MNN) — có 2 object `Llm` "sống" cùng lúc (1 cũ mồ côi, 1 mới) về
lý thuyết vẫn CÓ THỂ đụng độ ở tầng GPU/driver, dù không còn đụng độ ở
tầng con trỏ C++ nữa. Trên thực tế, nếu lệnh cũ THẬT SỰ đang treo (không
còn phát lệnh GPU nào mới, chỉ đứng yên chờ), khả năng đụng độ này thấp —
nhưng chưa có cách kiểm chứng chắc chắn 100% nếu không có mã nguồn MNN
hoặc thiết bị thật để test kỹ. Cần theo dõi log các lần nạp lại sau khi
có lệnh mồ côi để xác nhận không có crash/hành vi lạ nào mới xuất hiện.

## M. Bug THẬT do chính mục L gây ra — `loadingGuard` kẹt vĩnh viễn sau lần nạp thành công đầu tiên (2026-08-31)

Log thật xác nhận: sau đúng 1 lần nạp model 8B thành công, **MỌI lần nạp
sau đó — bất kỳ model nào, cách bao lâu — đều bị từ chối** với thông báo
MỚI "BI TU CHOI — da co 1 lenh nap model khac cho slot 0 dang chay chua
xong", dù lần nạp trước đã trả về xong hơn 1 phút trước đó.

**Nguyên nhân**: mục L thêm cơ chế epoch cho CẢ 2 guard (`loadingGuard`
lẫn `generatingGuard`) giống hệt nhau — nhưng `nativeLoadModel()` (hàm SỞ
HỮU `loadingGuard`) lại chính là nơi TĂNG epoch (sau khi nạp xong, để bảo
vệ `generatingGuard` — xem mục L). Tới lúc `loadingGuard` kết thúc (cuối
hàm `nativeLoadModel`), epoch ĐÃ bị chính hàm đó tăng lên rồi → điều kiện
"epoch còn khớp" của `loadingGuard` LUÔN LUÔN SAI → cờ `g_loadingInProgress`
không bao giờ được xoá — kẹt vĩnh viễn ở `true` sau lần nạp THÀNH CÔNG
ĐẦU TIÊN. Epoch chỉ có ý nghĩa bảo vệ đúng cho `g_generatingInProgress`
(sống trong `nativeGenerate()` — hàm KHÁC, không tự tăng epoch) — áp
dụng y hệt kiểu đó cho `g_loadingInProgress` (sống trong CHÍNH hàm tăng
epoch) là sai về logic.

**Đã sửa**: `LoadingGuard` giờ cho phép `epochs == nullptr` — nghĩa là
"luôn xoá cờ vô điều kiện lúc kết thúc, không kiểm tra epoch gì cả".
`loadingGuard` (bảo vệ `g_loadingInProgress`) dùng `nullptr`.
`generatingGuard` (bảo vệ `g_generatingInProgress`) vẫn dùng đúng
`g_slotEpoch` như mục L.

### Phát hiện thêm — cần người dùng quyết định hướng đi, chưa tự ý làm

Đối chiếu kỹ log gây ra bug trên: lệnh generate() ĐẦU TIÊN (bắt đầu
02:45:23) **không hề treo chết** — chạy chậm thật (378,8 giây) nhưng
CUỐI CÙNG THÀNH CÔNG lúc 02:51:42. Log cho thấy `nativeSetLogDir`/
`nativeSetCacheDir` xuất hiện LẦN 2 lúc 02:46:36 — dấu hiệu rõ Activity/
màn hình app bị Android TÁI TẠO (không phải cả tiến trình chết hẳn, nhờ
`GenerationService` giữ lệnh cũ sống) — khiến trạng thái "đang gửi" phía
Dart (`sending`, `chat_screen.dart`) bị mất, cho phép người dùng gửi tin
thứ 2 dù tin đầu vẫn đang xử lý thật.

Nghĩa là: cơ chế `isSlotGenerating` (mục L) nếu chạy đúng thiết kế ở kịch
bản NÀY sẽ **huỷ ngang 1 lệnh đang chạy chậm nhưng SẼ THÀNH CÔNG**, không
phải lệnh chết — mất kết quả đã tính gần 6,5 phút. Đây là 1 đánh đổi CHƯA
được hỏi ý người dùng trước khi làm ở mục L.

Còn 1 rủi ro MỚI, CHƯA giải quyết, CHƯA xác minh: nếu Activity cũ bị huỷ,
callback JNI (`onTokenMethod`, đối tượng `callback`) mà lệnh cũ đang giữ
CÓ THỂ đã gắn với Activity đã chết — nếu lệnh cũ (chạy chậm nhưng không
chết) cuối cùng gọi lại vào callback đó, CÓ THỂ crash (khác hẳn rủi ro
use-after-free đã giải quyết ở mục L — đây là rủi ro JNI reference, chưa
từng xét tới). Chưa có cách kiểm chứng nếu không có thiết bị thật/mã
nguồn MNN.

**Việc cần làm tiếp theo**: hỏi người dùng — có muốn `isSlotGenerating`
tự động nạp lại NGAY CẢ KHI lệnh cũ chỉ đang chậm (không chết), chấp nhận
mất kết quả lệnh đó, hay chỉ muốn nạp lại khi THẬT SỰ chết/mồ côi (cần 1
cách phân biệt "chậm" và "chết" mà hiện chưa có, vì đã bỏ mọi giới hạn
thời gian theo yêu cầu mục H)? Chưa tự ý chọn hướng nào — cần xác nhận
trước khi sửa thêm.

## N. XÁC ĐỊNH ĐÚNG NGUYÊN NHÂN GỐC của mục M — không phải Android tái tạo Activity, mà là bấm BACK giữa lúc đang sinh chữ, và `chat_screen.dart` THIẾU PopScope so với các màn hình khác (2026-08-31)

Người dùng xác nhận trực tiếp: nguyên nhân KHÔNG phải Android tự tái tạo
Activity (suy đoán sai ở mục M) — mà là **tự tay bấm nút back** giữa lúc
model đang sinh văn bản. Người dùng còn chỉ ra 1 tính năng tưởng đã có
("vuốt back hỏi có thoát không") biến mất — soát code xác nhận ĐÚNG, đây
là 1 lỗ hổng thật, không phải hiểu nhầm.

**Xác nhận qua code**: `chapter_editor_screen.dart`, `document_screen.dart`,
`main.dart` đều ĐÃ dùng `PopScope(canPop: !busy, onPopInvokedWithResult:
...)` để chặn back + hiện SnackBar xác nhận khi đang có AI chạy — đúng
tính năng người dùng nhớ. Nhưng `chat_screen.dart` — màn hình xảy ra lỗi
— **HOÀN TOÀN KHÔNG CÓ `PopScope`** (chỉ có 1 dòng COMMENT nhắc tới từ
"PopScope" khi giải thích 1 fix khác, không phải widget thật). Đây là 1
điểm KHÔNG ĐỒNG BỘ giữa các màn hình, không phải Android gây ra.

**Cơ chế lỗi thật**: bấm back huỷ WIDGET `chat_screen.dart`, nhưng vòng
lặp `await for` trong hàm `_send()` (hàm `async`, KHÔNG gắn với vòng đời
widget trong Dart) **vẫn tiếp tục chạy tới hết**, chỉ là các `if (mounted)
setState(...)` bên trong tự động no-op (không ai thấy kết quả nữa). Vì
vòng lặp không bao giờ break sớm, cơ chế dọn dẹp có sẵn ở
`local_provider.dart` (`finally` sau `yield* controller.stream` — gọi
`cancelGenerate()` native nếu consumer huỷ giữa chừng TRƯỚC khi nhận
`done=true`) **không bao giờ được kích hoạt** — lệnh cứ chạy tự nhiên
(model 8B chậm, có thể mất nhiều phút) cho tới khi THẬT SỰ xong, trong
lúc đó slot bị coi là "đang bận" — khớp đúng với log mục M (lệnh đầu vẫn
chạy thật, không hề chết, chỉ là không ai biết).

**Đã sửa** (`chat_screen.dart`, chỉ file này): bọc `Scaffold` bằng
`PopScope(canPop: !sending, onPopInvokedWithResult: ...)` — đúng khuôn
mẫu đã có ở `chapter_editor_screen.dart`/`document_screen.dart`. Khi đang
`sending`, back bị chặn, hiện SnackBar "AI đang sinh văn bản — đợi xong
hoặc huỷ trước khi thoát" kèm nút "Huỷ & thoát". Bấm nút đó đặt
`cancelRequested = true` — dùng ĐÚNG cơ chế huỷ CÓ SẴN của màn hình này
(biến đã tồn tại từ trước, được `isCancelled: () => cancelRequested`
kiểm tra trong vòng lặp `_send()`) — khiến vòng lặp tự break đúng cách,
kích hoạt cơ chế dọn dẹp/gọi `cancelGenerate()` native đã có sẵn ở
`local_provider.dart`, thay vì bỏ mặc lệnh chạy ngầm vô chủ như trước.

**Kết hợp với mục M**: fix này giải quyết TẬN GỐC nguyên nhân phổ biến
nhất khiến `isSlotGenerating` từng gặp phải "lệnh cũ đang chạy" — vì giờ
back sẽ CHỦ ĐỘNG huỷ đúng cách thay vì để lệnh chạy ngầm rồi mới phát
hiện ra sau. Câu hỏi bỏ ngỏ ở mục M (nạp lại ngay hay chờ xác nhận chết
hẳn) vẫn còn giá trị cho các trường hợp KHÁC (force-kill app thật sự, lỗi
mạng, crash từng phần...) — nhưng tình huống CỤ THỂ người dùng gặp phải
(bấm back) giờ đã có đường xử lý đúng, không cần dựa vào `isSlotGenerating`
nữa cho đúng kịch bản này.

## O. Trả lời 3 câu hỏi cùng lúc — "mất chạy nền", tài liệu có đồng bộ không, và cache vẫn 1,8GB (2026-08-31)

### O.1 — KHÔNG phải mất chạy nền — là đúng tính năng "xác nhận thoát" đã có từ trước, cộng thêm 1 giới hạn thật mới phát hiện

Log xác nhận: `nativeRequestCancel` bắn ra cho **CẢ 2 slot cùng lúc**,
lặp lại 2 lần trong vài phút. Rà code chỉ có ĐÚNG 1 chỗ gọi huỷ cả 2 slot
cùng lúc: `main.dart`, `RootScreen`'s `PopScope.onPopInvoked` — tính năng
"Thoát khi AI đang chạy?" đã được thêm TỪ TRƯỚC (theo đúng 1 phản hồi
người dùng khác, đã ghi lại đầy đủ lý do trong comment) — cử chỉ back ở
màn hình GỐC (không còn gì để pop) → hỏi xác nhận → nếu chọn "Vẫn thoát"
→ huỷ cả 2 slot + đợi tối đa 10s cho lưu xong → mới thật sự thoát app.

Đây **không phải lỗi mất chạy nền** — là đúng thiết kế xác nhận thoát khi
người dùng CHỦ ĐỘNG bấm back tại màn gốc. Khả năng cao: cử chỉ "chuyển
sang ứng dụng khác" (vuốt home/đa nhiệm) bị nhầm với cử chỉ "back" (thoát
app) — 2 cử chỉ này dễ giống nhau trên điều hướng kiểu vuốt (gesture
navigation) hiện đại, đặc biệt nếu vuốt gần cạnh màn hình.

**Phát hiện thật, giá trị hơn**: model 8B trong log này SINH RA 0 KÝ TỰ
suốt từ lúc bắt đầu tới lúc bị huỷ (không phải chỉ chậm) — `nativeRequestCancel`
CÓ đặt cờ `g_cancelRequested`, nhưng cờ đó **CHỈ được kiểm tra bên trong
`xsputn`** (chỗ MNN gọi vào MỖI KHI thật sự ghi ra được ít nhất 1 ký tự —
xem `JniStreamingBuf::xsputn`). Nếu model sinh ra ĐÚNG 0 ký tự, `xsputn`
không hề được gọi lần nào → cờ huỷ không bao giờ được kiểm tra → lệnh
huỷ, dù đã đặt cờ đúng, **KHÔNG BAO GIỜ thật sự có tác dụng** — khớp
chính xác với log: 95 giây sau (rồi 23 giây sau nữa) vẫn báo "lenh
generate() TU PHIEN TRUOC van con chay do (mo coi)" dù đã yêu cầu huỷ từ
trước đó rất lâu.

**Đây là giới hạn CÙNG BẢN CHẤT với giới hạn đã ghi ở mục D/H** (không có
watchdog thời gian thật độc lập với `xsputn`) — áp dụng luôn cho cả
trường hợp NGƯỜI DÙNG chủ động huỷ, không chỉ trường hợp tự động phát
hiện trì trệ đã bỏ. **CHƯA có cách sửa AN TOÀN** — muốn huỷ thật 1 lệnh
đang kẹt cứng trong tính toán GPU (0 ký tự, không có điểm nào để code
tự kiểm tra cờ) cần buộc dừng 1 luồng đang chạy dở trong driver GPU — rủi
ro crash cả tiến trình, y hệt rủi ro đã từ chối làm ở mục D.

### O.2 — Cache 2048MB không giảm — bug THẬT trong chính fix trước, đã sửa

Log xác nhận: `pruneOpenCLTuningCacheIfNeeded` CÓ chạy, CÓ phát hiện đúng
2048MB vượt hạn mức 500MB, in ra "bat dau don thu muc CU NHAT" — nhưng
**không hề có dòng "DA XOA" nào sau đó**. Nguyên nhân: mục I.2 (khi thêm
tính năng này) loại trừ thư mục model HIỆN TẠI khỏi việc xoá ("không xoá
cache đang chuẩn bị dùng ngay bây giờ") — nhưng log này cho thấy người
dùng chỉ dùng ĐÚNG 1 model (`OccultAI-Morpheus-8B-v2-MNN-q4-chinh`) suốt
cả phiên — nên thư mục ĐÓ luôn là "hiện tại", luôn bị loại trừ, KHÔNG BAO
GIỜ bị xoá dù tự phình to bao nhiêu qua nhiều lần nạp/nhiều hình dạng
prompt khác nhau.

**Đã sửa**: bỏ hẳn luật loại trừ model hiện tại. Mất cache tuning của
CHÍNH model đang dùng chỉ khiến lần nạp TIẾP THEO phải dò lại từ đầu (chi
phí y hệt 1 lần nạp lạnh bình thường, không phải lỗi đúng nghĩa) — đánh
đổi hợp lý để cache có giới hạn thật, kể cả khi chỉ dùng 1 model duy nhất
suốt phiên. **Đã sửa thêm** (an toàn quan trọng): đảo thứ tự gọi — dọn
TRƯỚC, đảm bảo thư mục tồn tại (`ensureDirExists`) SAU — vì giờ có thể tự
xoá cả thư mục model hiện tại, nếu vẫn `ensureDirExists` trước rồi mới
dọn (thứ tự CŨ), thư mục vừa tạo xong có thể bị xoá ngay sau đó, khiến
`tmp_path` trỏ vào chỗ không tồn tại lúc `llmSlot->load()` thật sự dùng
tới.

### O.3 — Tài liệu: đã cập nhật đồng bộ ngay trong lần sửa này

2 phát hiện ở mục O.1/O.2 (giới hạn huỷ khi 0 ký tự, bug loại trừ model
hiện tại khỏi việc dọn cache) đều là phát hiện MỚI, chưa từng ghi trong
tài liệu trước đây — đã ghi lại đầy đủ ngay tại mục này, cùng lúc với
việc sửa code, để không bị lệch pha. CHƯA thử bỏ `llmSlot.reset()`/`createLLM()` (rủi ro tái
hiện lỗi treo 12 phút đã sửa ở mục D) — cần số liệu thật trước, và cần
người dùng chủ động xác nhận muốn đánh đổi rủi ro đó hay không.

## K. Luồng "dịch → sinh → dịch" (dịch thuật trung gian) không hiện tiến trình ở bước sinh văn bản chính (2026-08-29)

Người dùng phản ánh: bật "Dịch thuật trung gian", ngồi nhìn không thấy
tiến trình đang ở đâu, "ức chế quá". Rà lại `translation_service.dart`
phát hiện: hạ tầng báo tiến trình (`onStage` callback) **đã có sẵn và đã
được nối đúng ở cả 3 màn hình gọi** (`chat_screen.dart`,
`chapter_editor_screen.dart` qua biến `aiStage`,
`chapter_batch_service.dart` qua thông báo Android) — KHÔNG phải thiếu hạ
tầng, mà thiếu đúng 1 chỗ dùng nó.

**Nguyên nhân cụ thể**: `generateWithOptionalTranslation()` (hàm CHÍNH,
dùng bởi 8+ nơi gọi khác nhau — chat, tạo chương đơn lẻ, tóm tắt, dàn ý,
Story Bible, RAG, style...) có 3 bước (dịch vào → sinh bằng model chính →
dịch ra), nhưng bước GIỮA (sinh văn bản — thường là bước LÂU NHẤT, đặc
biệt với model chậm như 8B đang dùng, và từ khi bỏ watchdog trì trệ ở mục
H thì KHÔNG CÒN GIỚI HẠN THỜI GIAN nào) lại gọi `mainProvider.generate()`
— chờ CẢ KHỐI, không streaming, `onStage` chỉ gọi ĐÚNG 1 LẦN lúc bắt đầu
bước rồi im bặt cho tới khi xong hẳn. Đối chiếu: hàm SONG SONG
`generateResumableWithOptionalTranslation()` (dùng riêng cho vòng lặp tạo
chương hàng loạt) đã làm ĐÚNG từ trước — dùng `generateStream()` cho đúng
bước này — chỉ hàm ĐẦU (dùng ở NHIỀU nơi hơn) bị thiếu.

**Đã sửa** (chỉ `translation_service.dart`, không đụng màn hình nào —
mọi nơi gọi tự động được lợi vì đều đã nối `onStage` sẵn): đổi bước sinh
văn bản chính sang `generateStream()`, gọi lại `onStage` MỖI KHI nhận
được đoạn mới, kèm số ký tự đã sinh (`'Đang sinh văn bản... (đã sinh N ký
tự)'`) — số này tăng dần realtime, không còn đứng yên. Cố tình KHÔNG đẩy
nội dung thô (chưa dịch) qua `onChunk` (giữ đúng hợp đồng cũ: `onChunk`
chỉ nhận text ĐÃ DỊCH sang tiếng Việt, tránh người dùng thấy chữ nước
ngoài lạ giữa chừng gây khó hiểu) — chỉ dùng `onStage` (vốn đã hiển thị
dạng "⏳ ..." ở UI) để báo tiến trình.

**Lợi ích phụ**: trước đây bước này KHÔNG có cách nào huỷ giữa chừng (đã
ghi nhận là giới hạn thật ở phần khai báo hàm) — giờ dùng `generateStream()`
nên tự động hưởng luôn cơ chế `isCancelled` đã có sẵn trong file, huỷ
được giữa chừng bước sinh văn bản chính, không chỉ 2 bước dịch như trước.

## P. Chuyển thời điểm dọn cache autotuning OpenCL — từ "mỗi lần nạp" sang "chỉ khi đổi model / chỉ khi thoát app thật" (2026-09-01)

Theo yêu cầu người dùng, sau khi tự phát hiện (trả lời câu hỏi "nạp lạnh
có làm sinh chữ chậm hơn không") 1 hệ quả thật của fix mục O.2: log O.2
cho thấy 1 model DUY NHẤT có thể tự tạo ra tới 2048MB cache qua nhiều
hình dạng prompt khác nhau trong 1 phiên — nghĩa là sau khi mục O.2 bỏ
luật loại trừ "model hiện tại" khỏi việc dọn, nếu người dùng chỉ dùng
đúng 1 model suốt phiên, cache của CHÍNH model đó có thể lại vượt 500MB
NGAY TRONG PHIÊN, và bị dọn sạch giữa chừng nhiều lần — mỗi lần dọn xong
lại phải dò lại từ đầu (thêm chi phí ở prefill/vài token đầu, xem lý giải
ở mục O.1 — CHƯA đo trực tiếp xác nhận cache lạnh có làm CHẬM DECODE ổn
định hay không, chỉ có cơ sở lý thuyết cho rằng chủ yếu ảnh hưởng
prefill/vài token đầu, không phải throughput ổn định về sau).

**Đã sửa**: việc dọn (`pruneOpenCLTuningCacheIfNeeded`) không còn chạy ở
mỗi lần gọi `buildOptimizedOpenCLConfig()` (tức mỗi lần nạp, kể cả nạp
LẠI đúng model cũ trong cùng slot — ví dụ luồng tự-nạp-lại-sau-huỷ ở mục
I.1) nữa. Thêm `g_lastLoadedModelSubdir[slot]` theo dõi model đã nạp
thành công LẦN GẦN NHẤT trong từng slot — chỉ dọn khi model SẮP nạp khác
với model đó (đổi model thật, hoặc slot lần đầu nạp); nạp lại đúng model
cũ bỏ qua bước dọn.

Thêm 1 điểm dọn MỚI, độc lập, chỉ chạy đúng 1 lần lúc app thoát THẬT:
`nativeCleanupCacheOnExit()` (JNI mới, không nhận slot, không loại trừ gì
— app sắp đóng nên không còn "model đang dùng" nào cần bảo vệ) — Kotlin
(`MnnBridge.kt`, method `"cleanupCacheOnExit"`) gọi ĐỒNG BỘ (cố ý, không
tách thread nền) để đảm bảo dọn xong thật trước khi trả kết quả về Dart;
Dart (`LocalLlamaProvider.cleanupCacheOnExit()`) `await` lệnh này; nơi
gọi: `main.dart`, ngay TRƯỚC `SystemNavigator.pop()`, SAU khi đã huỷ +
đợi lưu xong 2 slot — cùng logic "CHỜ THẬT, không bắn cờ rồi thoát ngay"
đã áp dụng cho chính đoạn code exit này trước đó (mục N).

**Cập nhật (2026-09-01, cùng ngày) — đã khép nốt giới hạn còn lại, theo
lựa chọn PHƯƠNG ÁN (a) của người dùng**: đoạn trên ghi lại đúng lúc mới
xong phần "chỉ dọn khi có tác vụ đang chạy" — khi đó nhánh thoát NHANH
lúc KHÔNG có gì đang chạy (`runningCount == 0`, trường hợp PHỔ BIẾN NHẤT)
vẫn bỏ qua, để hệ thống tự pop, chưa gọi `cleanupCacheOnExit()`. Người
dùng chọn (a) — chấp nhận đánh đổi thêm 1 nhịp chờ bất đồng bộ ở MỌI lần
back tại màn gốc để khép luôn nhánh này.

**Đã sửa**: `PopScope.canPop` đổi từ điều kiện (`runningCount == 0`) sang
CỐ ĐỊNH `false` — chặn MỌI lần back ở màn gốc, không còn nhánh nào để hệ
thống tự xử lý pop nữa. Bên trong `onPopInvoked`, tách rõ 2 nhánh:
- `runningCount == 0`: KHÔNG hiện hộp thoại xác nhận (không có gì đang
  chạy để phải hỏi) VÀ KHÔNG hiện hộp "Đang dừng AI..." (không có gì để
  dừng, hiện ra chỉ gây khó chịu vô ích) — chỉ `await cleanupCacheOnExit()`
  rồi `SystemNavigator.pop()` thẳng. Đây chính là nhịp chờ mới thêm vào
  MỌI lần thoát bình thường — nhanh (chỉ I/O file, không đụng GPU/model),
  nhưng không còn "tức thời tuyệt đối" như trước.
- `runningCount > 0`: giữ nguyên toàn bộ luồng cũ (hỏi xác nhận → huỷ 2
  slot → poll tối đa 10s → dọn cache → pop) — không đổi gì so với bản ghi
  ở trên.

Không còn giới hạn nào bỏ ngỏ ở luồng thoát app nữa — mọi đường thoát qua
back tại màn gốc (có hoặc không có tác vụ đang chạy) đều gọi
`cleanupCacheOnExit()` trước khi thoát thật. Đường CHƯA phủ (chưa được
yêu cầu, chưa tự làm): thoát bằng vuốt-khỏi-danh-sách-đa-nhiệm hoặc bị hệ
điều hành tự kill (không đi qua back-gesture, không có cách nào Flutter
chặn được đường này để chạy code dọn dẹp có `await`) — vẫn ngoài phạm vi
mục này, đúng như trao đổi ở bản trả lời trước (hướng (b), chưa chọn).

## Q. Thêm điểm dọn cache thứ 2 — lúc app KHỞI ĐỘNG — khép nốt đường vuốt-khỏi-đa-nhiệm/OS-kill (2026-09-01)

Theo yêu cầu người dùng (hỏi vì sao nhiều app khác "vuốt xong / bị OS
kill là xoá sạch cache" được, trong khi mục P nói Flutter không chặn
được 2 đường đó). Trả lời: các app đó không làm qua back-gesture —
2 cơ chế thật khác hẳn:
- **Vuốt-khỏi-đa-nhiệm** (người dùng chủ động xoá task): Android gọi
  `Service.onTaskRemoved()` trên Service app đang chạy (kể cả foreground
  service như `GenerationService` sẵn có trong app này) — cơ chế native
  Kotlin, không qua Flutter/Dart. App CHƯA dùng hook này (đã kiểm tra:
  `GenerationService.kt` chưa override `onTaskRemoved()`).
- **OS tự kill vì thiếu RAM**: kill cứng, KHÔNG có callback nào đảm bảo
  chạy trước khi tiến trình chết — kể cả `onTaskRemoved()` cũng không áp
  dụng (chỉ dành cho "người dùng xoá task", khác kill-vì-thiếu-RAM).
- **Cách đa số app THẬT SỰ làm cho cả 2 trường hợp trên**: dọn dẹp lúc
  MỞ APP LẠI (`onCreate`/startup), không phải lúc thoát — cache cũ vẫn
  nằm nguyên trên đĩa ngay sau khi bị kill kiểu nào cũng vậy, chỉ được
  dọn ở lần mở tiếp theo. Đây là cách DUY NHẤT đảm bảo chạy được dù thoát
  kiểu gì (back, vuốt, OS kill, force-stop) — không phụ thuộc bắt đúng
  thời điểm thoát.

**Đã chọn và làm**: thêm điểm dọn lúc khởi động (không làm
`onTaskRemoved()` — vẫn để ngỏ nếu sau này cần phủ thêm case "vuốt lúc
đang có tác vụ chạy").

**Đổi tên hàm native**: `nativeCleanupCacheOnExit` → `nativeEnforceOpenCLCacheCap`
— tên cũ gắn chết với 1 thời điểm gọi (lúc thoát), gây hiểu lầm khi dùng
lại ở thời điểm khác (lúc khởi động); tên mới trung lập theo ĐÚNG VIỆC
hàm làm (giữ cache dưới hạn mức), không gắn thời điểm cụ thể. Cập nhật
đồng bộ ở cả 2 nơi gọi (`MnnBridge.kt`: nhánh method-channel
`"cleanupCacheOnExit"` lúc thoát, VÀ điểm gọi mới lúc khởi động).

**Điểm gọi mới**: `MnnBridge.kt`, trong `onMethodCallInner`, ngay sau
`nativeSetCacheDir()` (khối `if (!logDirSent)` — chỉ chạy ĐÚNG 1 lần mỗi
tiến trình, đúng lúc Dart gọi lệnh native đầu tiên của phiên).

**Phát hiện + sửa 1 race condition thật trước khi chốt** (không phải suy
đoán — soát lại chủ động): bản đầu định chạy điểm khởi động này trên
thread nền (`Thread { }.start()`) để không làm chậm lệnh gọi Dart đầu
tiên. Vấn đề: `onMethodCallInner` chạy tuần tự trên platform thread (mặc
định của `MethodChannel`) — nếu Dart gọi `loadModel` gần như ngay sau khi
mở app (thường gặp), lệnh đó được xử lý TRÊN PLATFORM THREAD trong khi
thread dọn NỀN (thread riêng, khác hẳn) vẫn có thể đang xoá — 2 thread
THẬT chạm cùng thư mục `opencl_tuning/` cùng lúc, có thể xoá nhầm đúng
lúc `tmp_path` của model đang nạp đang được dùng (khác bug đã sửa ở mục
O.2 — đó là sai THỨ TỰ trong 1 thread, đây là THẬT SỰ 2 thread chạy song
song). **Đã sửa**: bỏ hẳn thread nền, gọi ĐỒNG BỘ ngay trên platform
thread — vì `onMethodCallInner` xử lý tuần tự, gọi đồng bộ ở đây đảm bảo
dọn xong hẳn TRƯỚC KHI platform thread có thể xử lý bất kỳ lệnh gọi tiếp
theo nào (kể cả `loadModel`), loại hẳn race. Đánh đổi: lệnh gọi native
đầu tiên của phiên (thường vô hại, không nhất thiết là lệnh người dùng
đang sốt ruột chờ) chậm thêm đúng bằng thời gian quét+xoá cache — 1 lần
duy nhất mỗi phiên.

**Đường vẫn chưa phủ** (chưa được yêu cầu, chưa tự làm): `onTaskRemoved()`
— case vuốt-khỏi-đa-nhiệm LÚC ĐANG CÓ tác vụ generate() thật sự chạy dở
(hiện tại rơi đúng vào tình huống "mồ côi" đã ghi ở mục N/O, không tự huỷ
được) vẫn chưa có cách xử lý riêng — điểm dọn cache lúc khởi động mới
thêm chỉ giải quyết phần CACHE, không giải quyết phần "lệnh generate() mồ
côi" cho case vuốt-khỏi-đa-nhiệm.

## R. Sửa lỗi BUILD CI thật do chính mục P gây ra — dùng `kMaxSlots` TRƯỚC khi nó được khai báo (2026-09-01)

Log build CI thật (`Build APK #113`, thất bại sau 8m35s):
```
error: use of undeclared identifier 'kMaxSlots'
```
tại đúng 3 dòng mới thêm ở mục P (`g_lastLoadedModelSubdir[kMaxSlots]`
và 2 chỗ so sánh `slot < kMaxSlots`).

**Nguyên nhân thật**: `kMaxSlots` vốn khai báo ở dòng ~639 (ngay trước
phần hạ tầng đa-slot: `g_slots`, `g_cancelRequested`...). Mục P chèn
`g_lastLoadedModelSubdir` + phần dùng `kMaxSlots` vào NGAY TRƯỚC hàm
`buildOptimizedOpenCLConfig()` (dòng ~400) — SỚM HƠN dòng 639 rất nhiều.
C++ đọc file từ trên xuống, một tên phải được khai báo TRƯỚC lần dùng
đầu tiên trong toàn file — lỗi build đúng như log báo, không phải lỗi
ngẫu nhiên/lỗi môi trường CI.

**Đã sửa**: chuyển NGUYÊN dòng `constexpr int kMaxSlots = 2;` lên đầu
file (ngay sau `g_logDirBufForSignal`, TRƯỚC MỌI chỗ dùng nó trong toàn
file), xoá khai báo trùng ở vị trí cũ (dòng ~639, chỉ giữ lại phần
comment gốc của mục lịch sử ở đó — vẫn đúng ngữ cảnh, không liên quan gì
tới `kMaxSlots`). Đặt ở phạm vi file (không nằm trong `namespace { }`
nào) — `constexpr` ở phạm vi file vốn đã có internal linkage mặc định
giống hệt lúc còn trong `namespace { }`, chuyển ra ngoài không đổi hành
vi liên kết, chỉ đổi chỗ nhìn thấy được sớm hơn trong file.

**Bài học ghi lại cho lần sau (tự phê bình)**: khi chèn code mới dùng 1
hằng số/hàm đã có sẵn trong file, phải kiểm tra VỊ TRÍ khai báo của nó
(không chỉ kiểm tra nó CÓ tồn tại) trước khi chèn — file C++ đọc tuần tự
từ trên xuống, "có tồn tại trong file" không đồng nghĩa "nhìn thấy được
tại điểm mình sắp chèn". Lần sửa mục P trước đó CHỈ verify bằng cách đếm
ngoặc cân bằng (`braces: 0`) — cách đó không bắt được lỗi loại này (lỗi
thứ tự khai báo, không phải lỗi cú pháp/ngoặc), nên lọt qua tới tận CI.

## S. Rà soát toàn hệ thống lần nữa — Story Bible KHÔNG rỗng, nối dây đầy đủ; tìm và vá 1 tính năng mồ côi thật (2026-09-01)

Theo yêu cầu người dùng: "kiểm tra tính năng nào chưa có UI, chưa nối
dây, UI nào chỉ là vỏ rỗng, đặc biệt Bible".

**Kết luận Story Bible**: KHÔNG rỗng. Truy trực tiếp theo đường tới
prompt sinh chữ (`RagService.buildContext()`/`buildSystemPrompt()`,
gọi thật từ `chapter_editor_screen.dart`) — xác nhận cả 8 loại đều có
đường vào prompt AI thật: Character, WorldRule, GlossaryTerm,
PlotThread, PlotBeat, TimelineEvent (qua `buildContext`), StyleProfile
(qua `describeEntryWithFacts`, đường riêng vì phụ thuộc lựa chọn của
người dùng mỗi lượt sinh, không phải "mọi entry trong phạm vi" như 6
loại kia). `WritingGoal` không cần vào prompt AI (đúng thiết kế — chỉ là
mục tiêu năng suất cá nhân), có bảng `daily_word_log` ghi thật mỗi lần
lưu chương (`recordWordSnapshot()`, gọi từ `chapter_editor_screen.dart`
+ `chapter_batch_service.dart` cả 2 nhánh local/remote).

**Phương pháp rà soát** (để lần sau dùng lại): quét cơ giới (regex) mọi
hàm public trong `lib/services/*.dart` + `lib/screens/*.dart`, đếm số
lần tên hàm xuất hiện dạng lời gọi (`tenHam(`) trong TOÀN BỘ repo — nếu
số lần xuất hiện KHÔNG NHIỀU HƠN số nơi ĐỊNH NGHĨA, khả nghi mồ côi. Ra
4 ứng viên, xác minh tay từng cái: 3 cái là báo động giả (`describeCharacter`/
`describeRule`/`gistOf` — hàm closure cục bộ, gọi qua tear-off
`.map(tenHam)` nên regex không bắt được dạng `tenHam(`), 1 cái là THẬT.
Bổ sung: quét riêng UI có `onPressed` rỗng hoặc thông báo kiểu "chưa hỗ
trợ/sắp ra mắt" — không tìm thấy trường hợp nào.

**Tìm được 1 tính năng mồ côi thật**: `SettingsService.renameNovel(Novel)`
— hàm đổi tên/tác giả truyện, code đầy đủ, chạy được, nhưng
`NovelListScreen` (`main.dart`) trước đây chỉ có nút xoá, KHÔNG có
đường nào gọi tới hàm này — `createNovel`/`deleteNovel` (2 hàm anh em
ngay cạnh trong cùng file) đều có nút gọi thật, riêng `renameNovel` thì
không.

**Đã sửa**: thêm `_renameNovel(Novel novel)` trong `NovelListScreen`
(dialog y hệt phong cách `_createNovel()` — 2 ô Tên truyện/Tác giả —
nhưng ĐIỀN SẴN giá trị hiện tại). Đổi `trailing` của mỗi thẻ truyện từ 1
`IconButton` xoá đơn lẻ sang `PopupMenuButton` (2 mục: "Đổi tên"/"Xóa")
— đúng khuôn mẫu `PopupMenuButton` đã dùng sẵn ở `chapters_screen.dart`
(menu xuất file) và 4 màn khác trong app, không phát minh pattern UI
mới; đồng thời né lỡ tay bấm nhầm xoá (trước đây nút xoá lộ thiên ngay
cạnh vùng chạm mở truyện).

## T. Sự cố "Tạo lại tất cả ghi chú" ghi đè chương bằng cảnh báo lỗi nội bộ + chuỗi ~35 lệnh generate() chồng chéo trên cùng 1 slot — 6 nguyên nhân gốc và toàn bộ bản vá (2026-09-05)

### Triệu chứng ban đầu
Người dùng báo: bấm sinh 1 chương, chờ rất lâu (đối chiếu debug log: hơn 1 tiếng, từ 18:30 tới 19:51) mà chương không ra được 1 chữ nào. Test ban đầu ở khung chat (2 lần, đều tự huỷ giữa chừng) tưởng như không liên quan, nhưng chính là mồi lửa.

### Phương pháp xác định nguyên nhân
Đọc trực tiếp source thật (không suy đoán từ tên biến/hàm) đối chiếu từng dòng debug log theo mốc thời gian: `local_provider.dart` (`ensureLoaded`/`generateStream`), `MnnBridge.kt` (mutex, cancelGenerate, currentJob), `mnn_bridge.cpp` (vòng đời `g_slots` shared_ptr, exception handling trong `nativeGenerate`), `chapter_editor_screen.dart` (`_applyAllPendingRewrites`, `_generateRespectingTranslation`), `background_task_manager.dart`, `chapter_batch_service.dart`, `document_service.dart` (2 nơi ĐÃ có validation đúng, dùng làm chuẩn so sánh). Ban đầu nghi ngờ Story Bible/dịch tài liệu — đã loại trừ bằng grep trực tiếp (`story_bible_screen.dart` không hề gọi AI).

### 6 nguyên nhân gốc, đã xác nhận bằng code (không phải suy đoán)

1. **`_applyAllPendingRewrites` (chapter_editor_screen.dart) chỉ kiểm tra `cleaned.isEmpty`** trước khi ghi kết quả AI đè lên đoạn văn gốc — một cảnh báo lỗi nội bộ dạng `⚠️ [...]` (KHÔNG rỗng, KHÔNG ném exception, xem điểm 3 bên dưới) lọt qua, bị ghi thẳng vào chương coi như văn bản thật, rồi vòng lặp **chạy tiếp** sang ghi chú kế tiếp — không giống `chapter_batch_service.dart`/`document_service.dart` đã có `looksCorrupted` (kiểm tra tỉ lệ độ dài) từ trước. Đây là hàm DUY NHẤT trong 3 nơi xử lý-hàng-loạt thiếu lớp bảo vệ này.
2. **`ensureLoaded()` (local_provider.dart) coi MỌI lúc `isSlotGenerating=true` là "chắc chắn mồ côi từ phiên trước"** (bản vá mục I.1, 2026-08-29) rồi nạp đè model NGAY — giả định sai khi 2 tính năng cùng phiên gọi chung slot gần như đồng thời (chính là điểm 5 bên dưới): nạp đè lúc đó biến 1 lệnh THẬT, đang chạy bình thường (chỉ chậm — model 8B đã xác nhận vốn chậm, mục H) thành mồ côi thật.
3. **`g_slots[slot]` dùng `shared_ptr`** (mục L, 2026-08-30, cố tình để nạp lại không crash lệnh cũ) khiến lệnh mồ côi ở điểm 2 **tiếp tục chạy ngầm đến hết**, vẫn giữ nguyên `generateMutexes[slot]` (Kotlin) suốt thời gian đó — mọi lệnh generate() MỚI phải xếp hàng thật phía sau.
4. **`currentJob` (MnnBridge.kt) là 1 biến `Job?` duy nhất**, bị ghi đè mỗi lần có lệnh "generate" mới — `cancelGenerate()` chỉ huỷ được lệnh MỚI NHẤT, không đụng được tới các lệnh cũ hơn đang xếp hàng ở Mutex hay đang chạy ngầm. Không có cách nào trong app dọn được backlog này.
5. **`chapter_editor_screen.dart` (Viết tiếp/Đắp thịt/Kiểm tra nhất quán/Tạo lại tất cả ghi chú) gọi thẳng `TranslationService`/provider, hoàn toàn KHÔNG qua `BackgroundTaskManager`** — trong khi đó là nơi DUY NHẤT áp cap đồng thời=1 cho local model (mục 4.6/K). `chat_screen.dart` có tôn trọng cap này; 4 tính năng kia thì không — rời màn soạn chương lúc đang sinh (Future không tự huỷ theo vòng đời widget) rồi mở lại bấm tiếp, hoặc chat song song lúc đang soạn chương, đều có thể tạo 2 lệnh generate() thật đồng thời trên slot 0.
6. **`deleteAllPendingRewritesForChapter` xoá TOÀN BỘ hàng đợi ghi chú sau mỗi lượt "Tạo lại tất cả"**, kể cả ghi chú CHƯA kịp xử lý — giả định cũ (mọi ghi chú luôn kết thúc ở trạng thái cuối) không còn đúng sau khi thêm khả năng dừng sớm ở điểm 1.

Chuỗi nhân quả: 2 lần huỷ test ở khung chat (18:52, 18:59) bật `g_slotNeedsFullReload` → điểm 2 kích hoạt nạp đè → nếu đúng lúc đó "Tạo lại tất cả ghi chú" (hoặc 1 tính năng khác trong `chapter_editor_screen.dart`) đang chạy, điểm 2+3+4 biến nó thành mồ côi + không huỷ được → điểm 1 khiến vòng lặp KHÔNG dừng lại mà chạy tiếp qua toàn bộ ~35 ghi chú, mỗi ghi chú lại đụng đúng điểm 2 → tự nhân bản thành hàng chục lệnh chồng chéo, một số ghi rác `⚠️ [...]` thẳng vào chương.

### Toàn bộ bản vá

| Điểm gốc | File | Nội dung sửa |
|---|---|---|
| 1 | `chapter_editor_screen.dart` | `_applyAllPendingRewrites`: thêm kiểm tra `kAiFailureMarker`/tỉ lệ độ dài (giống `looksCorrupted` ở 2 nơi kia) — phát hiện là **dừng hẳn vòng lặp ngay**, giữ nguyên `status='pending'` (không đổi 'done'/'failed') |
| 6 | `chapter_editor_screen.dart` | Theo dõi `processedIds` — chỉ xoá khỏi hàng đợi ghi chú ĐÃ THỰC SỰ xử lý xong; ghi chú bị dừng giữa chừng (và các ghi chú sau nó chưa kịp chạy) được giữ nguyên để thử lại sau |
| — | `ai_provider.dart` | Hằng số dùng chung `kAiFailureMarker = '⚠️ ['` — 1 định nghĩa duy nhất cho cả nơi ghi (điểm 1) lẫn nơi quét (mục 4.17) |
| — (khắc phục hậu quả dữ liệu cũ) | `data_integrity_service.dart` + `data_integrity_screen.dart` *(mới)* | Xem mục 4.17 — tự quét + tự khôi phục chương đã lỡ bị ghi rác, không bắt người dùng tự dò tay |
| 2 | `local_provider.dart` | `ensureLoaded()`: khi `isSlotGenerating=true`, hỏi thêm `slotStalledMs` (thời gian từ **token cuối cùng**, không phải tổng thời gian chạy) — chỉ nạp đè khi thật sự không tiến triển gì quá `_stalledThreshold = 3 phút`; nếu vẫn đang tiến triển, để Mutex Kotlin tự xếp hàng, KHÔNG nạp đè |
| 2 | `mnn_bridge.cpp` | Thêm `g_lastProgressMs[slot]` (cập nhật mỗi token trong `JniStreamingBuf::xsputn`, khởi tạo lúc bắt đầu generate) + hàm JNI `nativeSlotStalledMs` — đo GAP-từ-token-cuối, cố tình KHÔNG dùng elapsed-time-từ-lúc-bắt-đầu (đúng lỗi khiến lớp trì trệ cũ ở mục H bị xoá vì cắt nhầm lệnh chậm-nhưng-sống) |
| 2 | `MnnNative.kt` / `MnnBridge.kt` | Khai báo `nativeSlotStalledMs`, expose qua case `"slotStalledMs"` trong `onMethodCall` |
| 4 | `MnnBridge.kt` | `currentJob: Job?` (1 biến) → `jobsPerSlot: Array<CopyOnWriteArrayList<Job>>` (danh sách theo slot) — mỗi lệnh "generate" tự đăng ký vào đúng slot, tự gỡ khi xong (`invokeOnCompletion`); `cancelGenerate` giờ huỷ **toàn bộ** Job của slot (kể cả Job còn đang chờ Mutex, Kotlin `Mutex.withLock` huỷ được ngay cả khi đang chờ khoá) |
| 5 | `chapter_editor_screen.dart` | `_generateRespectingTranslation` (điểm hội tụ chung của cả 4 tính năng) giờ bọc qua `BackgroundTaskManager.instance.submitAndWait` — dùng CHUNG 1 hàng đợi/cap với chat + tạo chương hàng loạt + xử lý tài liệu; thêm ticker hiện "⏳ Đang chờ — phía trước còn N tác vụ..." khi bị xếp hàng, tái dùng khuôn mẫu đã có ở `chat_screen.dart` |

### Cố tình CHƯA làm — ghi lại để không quên
- **Chưa gắn `requestId` riêng cho từng lệnh generate ở event channel** (token/done hiện chỉ gắn `slot`, không gắn ID lệnh cụ thể — nếu tương lai có 2 lệnh THẬT cùng sống trên CÙNG 1 slot, ví dụ lỗi tương tự lặp lại ở slot 1/dịch thuật hoặc ở 1 tính năng mới chưa qua `BackgroundTaskManager`, vẫn còn nguy cơ cross-talk lý thuyết y hệt sự cố này). Điểm 5 đã vá che được đường THỰC TẾ duy nhất gây ra sự cố hôm nay, nhưng KHÔNG phải vá tận gốc lỗ hổng thiết kế event channel — nếu sau này thêm tính năng mới gọi AI, PHẢI đi qua `BackgroundTaskManager` hoặc `_generateRespectingTranslation` có sẵn, không tự gọi thẳng provider.
- **Chưa build/test thật** — môi trường sửa lỗi không có Flutter/Android SDK, chỉ xác minh được bằng cách đối chiếu số ngoặc `{}`/`()` với bản gốc (cân bằng) và khớp field/hàm DB với model đã có. Bắt buộc chạy `build.yml` (GitHub Actions) hoặc build máy thật trước khi phát hành.
- `DataIntegrityService` chỉ quét theo TỪNG TRUYỆN (gọi từ `ChaptersScreen` của truyện đang mở) — chưa có màn "quét tất cả truyện cùng lúc" nếu người dùng có nhiều truyện đều nghi bị ảnh hưởng.

## U. Gõ Outline tự kích hoạt bão lệnh tóm tắt AI → cross-talk event channel gây báo sai "đã xong" + ký tự rác; bổ sung sửa Nhân vật/Luật thế giới (2026-09-06)

### Triệu chứng
Người dùng báo: bấm "Triển khai thành chương" ở màn "Đắp thịt cốt truyện" — báo đã xong nhưng chưa tạo được gì, nội dung sinh ra là ký tự rác. Log debug mới cho thấy `ensureLoaded` KHÔNG còn nạp đè model bừa bãi nữa (bản vá mục T hoạt động đúng — liên tục log "van dang tien trien... KHONG nap lai"), nhưng vẫn có **~33 lệnh `generateStream()` với prompt tóm tắt GIỐNG HỆT nhau** bắn liên tiếp cách nhau 1-15 giây trong 3 phút, xếp hàng đè lên đúng lúc lệnh "Đắp thịt" thật cần chạy.

### Nguyên nhân gốc — 2 lỗi riêng biệt cộng hưởng
1. **`_onOutlineChanged()` (chapter_editor_screen.dart) — debounce 800ms trên MỌI thay đổi `outlineCtrl`** — khi người dùng gõ outline (đúng màn hình trong ảnh chụp người dùng gửi), mỗi lần dừng gõ ≥800ms tự gọi `_save(silent:true)` → `_updateSummaryAndIndexInBackground()` → `SummaryService().summarizeChapter()` gọi THẲNG provider, **hoàn toàn không qua `BackgroundTaskManager`**, và **không có gì chặn việc gọi CHỒNG lên chính nó**. Gõ 1 outline trong vài phút (nhịp gõ tự nhiên tạo ra nhiều khoảng dừng ≥800ms) → hàng chục lệnh tóm tắt y hệt nhau (nội dung chương chưa đổi, chỉ outline đổi) dồn vào slot 0.
2. **Event channel token/done chỉ gắn `slot`, KHÔNG gắn ID riêng theo lệnh** — đây chính là hạn chế đã ghi rõ ở mục T ("cố tình chưa làm"), nay bị khai thác thật: khi ≥2 `generateStream()` cùng sống trên slot 0 (33 lệnh tóm tắt + 1 lệnh Đắp thịt thật), MỌI listener Dart đang mở đều nhận được TOÀN BỘ token/done phát sinh từ BẤT KỲ lệnh nào trong số đó — 1 lệnh tóm tắt ngắn xong trước gửi `done=true` khiến màn "Đắp thịt" tưởng CHÍNH NÓ đã xong (trong khi chưa nhận token thật nào), và token của các lệnh xen kẽ nhau tạo ra ký tự rác khi vô tình lọt vào cùng 1 buffer.

### Bản vá
| Nguyên nhân | File | Nội dung sửa |
|---|---|---|
| 2 | `MnnBridge.kt` | Đọc `requestId` (Dart tự sinh, Kotlin không cần hiểu ý nghĩa) từ tham số lệnh "generate", ECHO nguyên vẹn vào mọi event `token`/`done` gửi cho Dart |
| 2 | `local_provider.dart` | `generateStream()` tự sinh `requestId` duy nhất mỗi lần gọi, gửi kèm lệnh `generate`; listener lọc thêm theo `requestId` (không chỉ `slot`) — bỏ qua an toàn nếu `requestId` là `null` (tránh biến 1 lỗi đọc tham số nhỏ thành "không nhận được token nào") |
| 1 | `chapter_editor_screen.dart` | `_updateSummaryAndIndexInBackground()`: thêm cờ `_summarizing` (chặn gọi chồng) + `_lastSummarizedContent` (bỏ qua nếu nội dung chương chưa đổi so với lần tóm tắt gần nhất); bọc qua `BackgroundTaskManager.submitAndWait` giống 4 nơi gọi AI khác trong màn này |

Với bản vá điểm 2, sự cố "báo sai đã xong"/"ký tự rác" được chặn TẬN GỐC cho MỌI trường hợp có ≥2 lệnh generate() cùng sống trên 1 slot — không chỉ riêng trường hợp gõ outline hôm nay (bản vá điểm 1 chỉ chặn ĐÚNG nguồn gây ra sự cố LẦN NÀY, không đảm bảo không có nguồn khác tương tự chưa bị phát hiện).

### Việc khác đã làm trong cùng phiên (theo yêu cầu người dùng, không liên quan sự cố trên)
- **Thiếu chức năng sửa Nhân vật/Luật thế giới**: `_addCharacter()`/`_addRule()` (story_bible_screen.dart) trước đây CHỈ tạo mới — bấm vào 1 mục đã có chỉ mở được `_manageFactsSheet` (quản lý dữ kiện rời), không sửa được tên/vai trò/mô tả/phân loại gốc, nhập sai phải xoá tạo lại (mất luôn facts đã gắn). Đổi thành `_addOrEditCharacter({Character? existing})`/`_addOrEditRule({WorldRule? existing})`, `trailing` đổi từ nút Xoá đơn thành `PopupMenuButton` "Sửa"/"Xóa" (đúng khuôn mẫu đã dùng ở `NovelListScreen`, mục S).
- **Sửa lỗi đánh số mục trong chính tài liệu này**: mục 4.16 vừa thêm ở bản vá mục T (2026-09-05) trùng số với 1 mục ĐÃ ĐƯỢC comment trong `database_service.dart` (`_backupTables`) tham chiếu tới từ trước ("mục 4.16/5.77 tài liệu kiến trúc") nhưng CHƯA TỪNG thực sự được viết — comment nói dối chính nó, giống lỗi `recordWordSnapshot()` đã ghi ở mục N. Đã đổi mục của bản vá mục T thành **4.17**, và viết bổ sung **4.16 THẬT** mô tả tính năng "quy trình viết tiểu thuyết" (Dàn ý/Tuyến truyện/Mục tiêu/Quyển) đã có code từ lâu nhưng chưa từng được tài liệu hoá.

### Đã kiểm tra, CHƯA tìm thấy lỗi (cần người dùng xác nhận thêm)
Người dùng nghi ngờ "sao lưu truyện không backup outline của chương". Đã rà: cột `outline TEXT` có trong schema `chapters` (cả bản tạo mới lẫn migration v3→v4), `Chapter.toMap()`/`fromMap()` xử lý đúng, `exportNovelData`/`exportAllData` dùng `d.query('chapters')` (lấy TOÀN BỘ cột, gồm `outline`), `upsertChapter()` ghi qua `c.toMap()` (đầy đủ), `importNovelData`/`importAllData` phục hồi qua `Chapter.fromMap()`. Không tìm thấy đường nào làm rơi `outline` trong code hiện tại — nếu người dùng phục hồi từ 1 file backup XUẤT TỪ TRƯỚC KHI có cột này (trước migration v3→v4), file đó vốn dĩ không hề chứa outline nên không có gì để phục hồi (không phải lỗi code hiện tại). Cần file backup thật hoặc bước tái hiện cụ thể hơn để kết luận chắc chắn.

## V. Máy vẫn ngủ sâu giữa lúc sinh chương (~15 phút) dù WakeLock đã đúng chuẩn — TÁI DIỄN mục F, không phải lỗi mới (2026-09-07)

### Số liệu
`STEADY (ms)=158162, WALL (ms)=1074660, CHENH LECH=916498ms` (~15,3 phút ngủ sâu giữa chừng). Khác mục F: đây là **lệnh generate() ĐẦU TIÊN trong tiến trình vừa khởi động** ("lan nap thu 1") — KHÔNG PHẢI do `pipelineDepth` rò rỉ từ lệnh treo trước đó (nguyên nhân đã sửa ở mục F không áp dụng được ở đây, vì không có lệnh nào chạy trước nó trong tiến trình này). Đã đọc lại `MnnBridge.kt`: `acquireDirectWakeLock()` vẫn được gọi ĐÚNG, VÔ ĐIỀU KIỆN, ĐỒNG BỘ trước `scope.launch` (khớp bản vá mục F) — về mặt code, WakeLock 40 phút (`directWakeLockGrantMs`) THỪA SỨC che phủ 17,9 phút wall-clock của lệnh này.

### Kết luận
Code phía app đã làm ĐÚNG những gì API Android cho phép làm (PARTIAL_WAKE_LOCK giữ đồng bộ + Foreground Service đúng chuẩn). WakeLock chuẩn Android **không phải lúc nào cũng được hãng máy tôn trọng** — đây chính là giới hạn đã ghi nhận từ trước (mục 5, dòng ~402: máy test ASUS ZenUI từng bị chính hãng tự kill app nền bất kể đúng chuẩn hay không), và ĐÃ có sẵn cơ chế xin loại trừ (`local_optimization_screen.dart` → "Tối ưu AI local" → "Loại trừ khỏi tối ưu hoá pin"). Không có thêm gì sửa được ở tầng `MnnBridge.kt`/`GenerationService.kt` cho trường hợp NÀY — nếu người dùng CHƯA bấm nút loại trừ đó, đây gần như chắc chắn là nguyên nhân. Nếu ĐÃ loại trừ mà vẫn xảy ra, nghi vấn chuyển sang lớp quản lý pin RIÊNG của hãng máy (nằm NGOÀI mọi API chuẩn Android, mỗi hãng 1 kiểu cài đặt khác nhau — Xiaomi/MIUI "Tự khởi động" + "Tiết kiệm pin thông minh", Oppo/vivo "Bảo vệ nền", Asus "Power Master"...), cần biết đúng hãng máy mới hướng dẫn được vị trí cài đặt chính xác.

## W. SỬA LẠI mục V — không phải máy ngủ, mà "Cốt truyện đã diễn ra"/tóm tắt chương bị nhiễm rác lan ra MỌI lần "Đắp thịt" (2026-09-07)

### Mục V đã sai — bằng chứng phản bác
Mục V (cùng ngày, trước đó vài giờ) kết luận nguyên nhân là máy ngủ sâu giữa lúc sinh — dựa trên 1 log duy nhất có `CHENH LECH=916498ms`. Người dùng bật battery-optimization-exemption (xác nhận xanh), thử lại: `STEADY=136315ms, WALL=136315ms, khong chenh lech dang ke` — **máy hoàn toàn KHÔNG ngủ** — nhưng **vẫn dừng đúng ở "sinh duoc 60 ky tu" y hệt lần trước**. Đổi hẳn nội dung outline sang 1 outline bình thường — **vẫn y hệt**. Kết luận: máy ngủ ở mục V chỉ là trùng hợp, KHÔNG phải nguyên nhân. Ghi nhận công khai để không ai đọc mục V rồi đi sai hướng.

### Nguyên nhân thật
`looksLikeRepetitionLoop()` (mnn_bridge.cpp) có ngưỡng sàn cứng `accumulated_.size() < 60 → return false` — không thể báo lặp trước 60 ký tự dù model lặp từ ký tự đầu. Cả 2 lần đều dừng ĐÚNG tại mốc sớm nhất có thể → model gần như lặp ngay từ đầu, KHÔNG phải lặp sau 1 đoạn dài. Việc đổi outline không đổi được kết quả → rác không nằm ở outline (phần userPrompt), mà ở phần **systemPrompt CỐ ĐỊNH**.

Rà `StyleService.buildFleshOutPrompt()` → gọi `RagService.buildContext()` → dòng đầu tiên, LUÔN nhúng (không phụ thuộc outline/currentText) là `Novel.plotProgressSummary` ("Cốt truyện đã diễn ra — tóm tắt luỹ kế"). Rà `RagService.updateCumulativeStorySummary()` (hàm duy nhất ghi vào field này) → phát hiện **ĐÚNG lỗ hổng đã vá ở mục T** (`_applyAllPendingRewrites`): chỉ kiểm tra `trimmed.isNotEmpty` trước khi `db.updateNovelProgressSummary(...)`, không kiểm tra `kAiFailureMarker`. Trong cơn bão lệnh tóm tắt do gõ outline gây ra (mục U, TRƯỚC KHI vá `_summarizing`/`requestId`), rất có thể 1 trong các lượt gọi `updateCumulativeStorySummary` (được gọi ở cuối `_updateSummaryAndIndexInBackground`, mỗi lần tóm tắt "thành công") đã nhận về đúng chuỗi cảnh báo `⚠️ [Cần nạp lại model...]` và ghi thẳng vào `plotProgressSummary` — từ đó, **MỌI lần "Đắp thịt"/"Viết tiếp" sau đó đều nhúng rác này vào đầu prompt**, bất kể outline gõ gì — khớp 100% với triệu chứng quan sát được.

`Chapter.autoSummary` (tóm tắt riêng từng chương, dùng làm nguồn ngữ cảnh dự phòng khi không có Timeline/outline ưu tiên hơn — xem `gistOf()`) có **cùng lỗ hổng y hệt** ở `_updateSummaryAndIndexInBackground` (`widget.chapter.autoSummary = summary;` không kiểm tra `kAiFailureMarker`).

**Phát hiện phụ**: comment trong `rag_service.dart` nhắc người dùng "xoá tay ở tab 'Cốt truyện' trong Bách khoa" để sửa field này — tab đó **không tồn tại** trong `story_bible_screen.dart` (8 tab thật: Nhân vật/Luật thế giới/Văn phong/Thuật ngữ/Dàn ý/Tuyến truyện/Mục tiêu/Dòng thời gian). Comment nói dối chính nó — cùng dạng lỗi đã ghi ở mục N và mục U (4.16 trùng số). Chưa xây tab thay thế (xem "chưa làm" bên dưới) — dùng tạm công cụ ở mục 4.17 (nay mở rộng, xem dưới).

### Bản vá
| File | Nội dung sửa |
|---|---|
| `rag_service.dart` (`_doUpdateCumulativeStorySummary`) | Thêm kiểm tra `kAiFailureMarker` + tỉ lệ độ dài trước khi `updateNovelProgressSummary` — phát hiện rác thì GIỮ NGUYÊN bản tóm tắt cũ, không ghi đè |
| `chapter_editor_screen.dart` (`_updateSummaryAndIndexInBackground`) | Thêm kiểm tra `kAiFailureMarker` trước khi gán `chapter.autoSummary` |
| `data_integrity_service.dart` + `data_integrity_screen.dart` (mục 4.17) | Mở rộng quét thêm `Novel.plotProgressSummary` và `Chapter.autoSummary` (không chỉ `Chapter.content` như trước) — 2 nguồn này KHÔNG có lịch sử phiên bản riêng nên cách sửa là XOÁ SẠCH (ép AI tự tóm tắt lại từ đầu), không phải khôi phục bản cũ; xoá `plotProgressSummary` BẮT BUỘC reset kèm `plotProgressSummaryChapter` về null, nếu không các chương trước số đã lưu sẽ bị bỏ sót vĩnh viễn (logic gộp chỉ nhìn về phía trước) |

### Việc cần làm ngay (người dùng)
Mở "Kiểm tra dữ liệu bị lỗi" (icon 🩺 ở danh sách chương) — bản vá này giờ QUÉT ĐƯỢC đúng chỗ nghi ngờ đang chặn toàn bộ tính năng "Đắp thịt" của truyện hiện tại. Nếu thấy mục "Cốt truyện đã diễn ra..." trong danh sách, xử lý mục đó TRƯỚC — nó ảnh hưởng mọi chương, không riêng 1 chương.

### Vẫn CHƯA làm (ghi lại, không quên)
- Chưa xây tab "Cốt truyện" cho phép xem/sửa tay `plotProgressSummary` — comment code đã hứa nhưng chưa hiện thực hoá; hiện chỉ có đường "xoá sạch" qua công cụ quét, không có đường "sửa 1 phần".
- Chưa xác nhận CHẮC CHẮN 100% rác thực sự đã lọt vào `plotProgressSummary` của đúng truyện người dùng đang gặp lỗi (suy luận từ code + trùng khớp triệu chứng, chưa xem được dữ liệu thật) — bước xác nhận cuối cùng là người dùng tự mở công cụ quét ở trên.

## X. Vá thiếu đúng luồng quan trọng nhất: "Tạo hàng loạt qua đêm" — 3 lỗ hổng y hệt mục W nhưng KHÔNG tự động được che bởi bản vá ở màn soạn 1 chương (2026-09-07)

### Vì sao đây là mục nghiêm trọng nhất trong toàn bộ chuỗi sự cố T/U/W
Mục đích chính của app (theo đúng khẳng định của người dùng) là chạy **"Tạo hàng loạt" nhiều chương liên tục, không giám sát (qua đêm)** — `chapter_batch_service.dart`. Bản vá mục W chỉ sửa 2 hàm dùng CHUNG (`RagService._doUpdateCumulativeStorySummary` — tự động che được MỌI nơi gọi, kể cả batch) và 1 hàm CHỈ DÙNG RIÊNG cho màn soạn 1 chương (`chapter_editor_screen.dart _updateSummaryAndIndexInBackground`) — **`chapter_batch_service.dart` có 1 bản SAO RIÊNG của logic tương tự, không tự động thừa hưởng bản vá ở màn soạn tay**. Rà lại phát hiện đúng 3 chỗ:

1. **`looksCorrupted` (2 nơi — nhánh sequential VÀ nhánh parallel/remote)**: chỉ so `resultTrimmed.length < outline.length * 0.5` — KHÔNG kiểm tra `kAiFailureMarker`. Nếu outline đủ dài, chuỗi cảnh báo lỗi nội bộ (~180 ký tự) không bị coi là "quá ngắn", **lọt qua trót lọt và bị ghi thẳng vào chương** trong lúc chạy qua đêm không ai giám sát — hậu quả nặng hơn hẳn so với soạn tay (không ai nhận ra ngay để dừng).
2. **`_finalizeChapterMemory` → `chapter.autoSummary = summary;`**: không kiểm tra gì cả trước khi ghi — bản sao riêng của đúng lỗi đã vá ở `chapter_editor_screen.dart`.

### Bản vá
Thêm `resultTrimmed.contains(kAiFailureMarker)` vào `looksCorrupted` ở CẢ 2 nhánh (sequential + parallel); thêm kiểm tra `kAiFailureMarker`/rỗng trước `chapter.autoSummary = summary` trong `_finalizeChapterMemory`. `rag.updateCumulativeStorySummary()` gọi từ đây ĐÃ được che sẵn nhờ vá ở tầng dùng chung (mục W) — không cần sửa thêm.

### Đã rà soát để không tái diễn kiểu "vá 1 nơi, quên nơi dùng chung logic khác"
Grep toàn bộ project mọi nơi thực sự ghi `chapter.autoSummary =` hoặc gọi `db.updateNovelProgressSummary(` — xác nhận ĐÚNG 3 nơi (rag_service.dart, chapter_batch_service.dart, chapter_editor_screen.dart), cả 3 đã có kiểm tra sau đợt vá này. Bài học ghi lại: **mỗi khi vá 1 lỗ hổng "ghi rác không kiểm tra", phải grep toàn project tìm MỌI nơi ghi cùng 1 field, không chỉ vá đúng nơi vừa phát hiện triệu chứng** — nơi phát hiện ra triệu chứng chưa chắc là nơi duy nhất có lỗ hổng.

## Y. Chuyển từ "bắt tự kiểm tra/dọn tay" sang TỰ ĐỘNG bỏ qua rác khi đọc — theo đúng phản hồi người dùng (2026-09-07)

### Vấn đề với hướng tiếp cận cũ (mục 4.17/T/W/X)
Toàn bộ hướng xử lý trước đó (`DataIntegrityService`) chỉ CHẶN GHI rác mới + cho phép người dùng CHỦ ĐỘNG mở 1 màn hình quét rồi bấm dọn rác cũ. Người dùng phản hồi thẳng: dù không còn phải tự mò tìm bằng mắt (đã cải thiện so với bản đầu), vẫn đang bị bắt tự làm 1 việc thủ công (mở màn hình, bấm nút) TRƯỚC KHI dùng tiếp được — với người chỉ muốn bấm "Đắp thịt"/chạy batch mà không cần biết gì về khái niệm "dữ liệu bị lỗi", đây vẫn là gánh nặng không công bằng đặt lên người dùng cho lỗi do app gây ra.

### Hướng sửa đúng: tự động bỏ qua rác NGAY LÚC ĐỌC, không chờ ai dọn
Thay vì chỉ chặn ghi (mục W/X) rồi yêu cầu dọn tay dữ liệu ĐÃ lỡ ghi trước đó, `RagService` giờ tự động COI RÁC NHƯ KHÔNG TỒN TẠI ở mọi nơi ĐỌC `autoSummary`/`plotProgressSummary` để dùng làm ngữ cảnh:
- Thêm `_safeSummaryOrExcerpt(Chapter c)` — dùng chung cho `indexChapter()`, "Chương liên quan (truy xuất ngữ nghĩa)", "Tóm tắt các chương gần nhất", và `gistOf()` trong `updateCumulativeStorySummary` — nếu `autoSummary` dính `kAiFailureMarker`, tự động fallback về trích đoạn nội dung thật (`_excerpt(c.content)`), y hệt như chưa từng có `autoSummary`.
- `buildContext()`: đọc `novel.plotProgressSummary` — nếu dính rác, tự động BỎ QUA HẲN mục "Cốt truyện đã diễn ra" (không nhúng gì), thay vì nhúng rác vào mọi prompt sinh chương như trước.
- `_doUpdateCumulativeStorySummary()`: bản tóm tắt cũ dùng làm nền cho lần tự cập nhật KẾ TIẾP cũng tự động bỏ qua nếu dính rác, tránh đưa rác vào chính prompt đang cố tạo ra bản tóm tắt MỚI sạch.

**Quan trọng — cố tình KHÔNG tự xoá trong DB ở các hàm ĐỌC này**: chỉ bỏ qua khi dùng, giữ nguyên dữ liệu gốc trong DB. Lý do: (1) hàm đọc không nên kiêm luôn việc ghi/xoá dữ liệu — tách biệt trách nhiệm rõ ràng; (2) nếu rác chỉ dính 1 đoạn nhỏ lẫn trong 1 bản tóm tắt dài phần lớn vẫn dùng được, tự động xoá SẠCH ngay lúc đọc (thay vì chỉ bỏ qua) sẽ làm mất luôn phần còn dùng được đó mỗi lần đọc — trong khi CHỈ BỎ QUA khi dùng làm ngữ cảnh không mất gì, và công cụ quét ở mục 4.17 vẫn còn nguyên cho ai MUỐN dọn sạch hẳn (dùng cho gọn dữ liệu về lâu dài, không còn là điều kiện bắt buộc phải làm trước khi dùng tiếp).

### Kết quả
Người dùng không cần mở màn hình nào, không cần bấm nút nào — lần "Đắp thịt"/"Tạo hàng loạt" TIẾP THEO sẽ tự động không còn nhúng "Cốt truyện đã diễn ra" bị nhiễm rác (nếu đúng đây là nguyên nhân của sự cố mục W) mà không cần bất kỳ thao tác thủ công nào trước đó.


## Z. "Không thể tạo chương truyện" — lệnh tóm tắt nền rơi vào lặp vô tận 40 phút, chiếm slot model LOCAL, chặn đứng "Đắp thịt"/"Viết tiếp" thật (2026-09-08)

### Triệu chứng
Người dùng báo: không tạo được chương. Đối chiếu debug log (`debug_log.txt` +
`native_debug.txt`, 2026-09-08): sau khi model nạp thành công (backend
OpenCL, đúng đường mặc định `backendPreference=0`, xem mục 2.2/5.53), có
đúng 2 lệnh `generateStream()`:
1. 11:02:38 — prompt "xin chào" (8 ký tự), sinh 7 token trong ~148s, có
   nghi vấn ngủ sâu ngắn (~59s, cùng cơ chế đo STEADY/WALL đã ghi ở mục
   E/F/V) — không phải nguyên nhân chính, chỉ là 1 khoảng trễ nhỏ.
2. 11:05:23 — prompt hệ thống khớp **NGUYÊN VĂN** với
   `SummaryService.summarizeChapter()`
   ("Bạn là biên tập viên tóm tắt tiểu thuyết. Chỉ trả lời bằng đoạn tóm
   tắt, không thêm lời dẫn hay tiêu đề.") — xác nhận chắc chắn đây là lệnh
   tóm tắt chương chạy NỀN (kích hoạt qua `_save()` →
   `_updateSummaryAndIndexInBackground()`, xem mục 4.16/`chapter_editor_screen.dart`),
   KHÔNG phải lệnh "Đắp thịt"/"Viết tiếp" người dùng bấm trực tiếp. Lệnh
   này treo tới 11:45:55 (~40,5 phút) mới bị chính tầng Dart
   (`local_provider.dart`) tự phát hiện "LẶP VÔ TẬN" sau 329 ký tự và gọi
   `cancelGenerate()`. **Tầng native (`mnn_bridge.cpp`) không hề bắt được
   trong suốt 40 phút đó** — không có dòng `[CHAN DOAN LAP VO TAN]` nào
   trong native log.

### Nguyên nhân gốc — 3 lỗ hổng cộng hưởng, đã xác nhận bằng code

1. **`looksLikeRepetitionLoop()` (`mnn_bridge.cpp`) so khớp lặp theo BYTE
   thô của UTF-8, không phải theo KÝ TỰ** — 2 mẫu lỗi gốc dùng để thiết kế
   thuật toán này ("((((("/"8888888") đều là ASCII 1-byte/ký tự, nhưng
   app viết tiếng Việt có dấu, đa số ký tự chiếm 2-3 byte/ký tự. Hệ quả:
   (a) model lặp đúng 1 ký tự tiếng Việt duy nhất → không byte nào trong
   2-3 byte cấu thành ký tự đó chiếm nổi 85% → điều kiện "1 ký tự áp đảo"
   không bao giờ khớp; (b) model lặp 1 cụm ngắn 2-6 KÝ TỰ tiếng Việt → quy
   ra byte dễ vượt quá trần "period ≤ 6 byte" → điều kiện "cụm lặp khít"
   cũng không khớp. Tầng native — vốn phải là lớp phản ứng NHANH NHẤT
   (chạy ngay trong `xsputn`, mỗi token, ném exception tức thời) — gần
   như vô hiệu với đúng loại lặp phổ biến nhất của app này.
2. **Chỉ còn tầng Dart (`local_provider.dart`) làm việc** — thuật toán
   phía Dart so khớp theo `String` (UTF-16), với ký tự tiếng Việt dựng
   sẵn (precomposed) thông thường thì 1 code unit = đúng 1 ký tự, nên
   KHÔNG dính lỗi byte-vs-ký-tự ở trên — nhưng phải đợi vòng
   JNI → Kotlin → EventChannel → Dart, cộng cửa sổ tích luỹ riêng (≥60 ký
   tự), cộng tốc độ sinh chữ vốn đã rất chậm trên máy test (mục F/G/H) —
   329 ký tự "rác" mất tới 40 phút thời gian thực mới tích luỹ đủ để kết
   luận.
3. **`TranslationService.generateWithOptionalTranslation()`, nhánh dịch
   thuật TẮT (mặc định) + không có `onChunk`** (đúng nhánh
   `SummaryService`/`RagService.updateCumulativeStorySummary` dùng) gọi
   thẳng `mainProvider.generate()` (đợi cả khối) — **hoàn toàn bỏ qua**
   tham số `isCancelled` dù hàm đã khai báo sẵn, vì `generate()` không có
   điểm dừng giữa chừng nào để kiểm tra. 2 nơi gọi nhánh này không có bất
   kỳ cách nào tự thoát sớm.

Chuỗi nhân quả: `_save()` (gõ outline/lưu chương) kích hoạt lệnh tóm tắt
nền → model suy biến thành lặp ở nhiệt độ thấp (`temperature: 0.3`,
`repetitionPenalty` mặc định dùng chung 1.05 — thấp so với mức cần để bù
cho nhiệt độ thấp) → lỗ hổng 1 khiến tầng native không cắt được ngay →
lỗ hổng 3 khiến lệnh này không có đường thoát sớm nào khác ngoài chờ lỗ
hổng 2 (tầng Dart, chậm) → suốt 40 phút đó, lệnh tóm tắt vẫn đang
"running" trong `BackgroundTaskManager` (cap=1 cho model LOCAL, mục
5.67 — cố tình giữ nguyên để tránh crash heap corruption 2 lệnh
`generate()` chồng lên nhau) → **bất kỳ lệnh "Đắp thịt"/"Viết tiếp" nào
người dùng bấm trong 40 phút đó chỉ xếp hàng chờ** (`aiStage` hiện "⏳
Đang chờ — phía trước còn 1 tác vụ AI khác...", xem
`_generateRespectingTranslation`), không hề chạm được tới native — đúng
triệu chứng "không thể tạo chương truyện" đã báo.

### Bản vá

| Lỗ hổng | File | Nội dung sửa |
|---|---|---|
| 1 | `mnn_bridge.cpp` (`JniStreamingBuf::looksLikeRepetitionLoop`) | Thêm `splitUtf8Units()` — tách chuỗi UTF-8 thành từng KÝ TỰ thật (gộp byte tiếp diễn) trước khi so khớp; áp dụng lại NGUYÊN 2 tiêu chí cũ (1 đơn vị >85%, cụm 2-6 đơn vị lặp khít) trên dãy ký tự thay vì dãy byte. Không đổi hành vi với 2 mẫu ASCII gốc ("((((("/"8888888" — mỗi ký tự vẫn đúng 1 byte = 1 đơn vị) |
| 3 | `translation_service.dart` (`generateWithOptionalTranslation`, nhánh dịch thuật tắt) | Bỏ nhánh gọi thẳng `mainProvider.generate()`; LUÔN đi qua `generateStream()` + kiểm tra `isCancelled` mỗi token (dùng `onChunk?.call(...)` null-safe) — hành vi KHÔNG đổi với nơi gọi chưa truyền `isCancelled` (mặc định null) |
| — | `summary_service.dart` (`summarizeChapter`) | Tăng `repetitionPenalty` riêng cho tác vụ này lên `1.2` (không đụng cài đặt người dùng); thêm `isCancelled: () => stopwatch.elapsed > Duration(minutes: 3)` |
| — (cùng lỗ hổng, chưa xác nhận có dính đúng sự cố hôm nay hay không — vá theo bài học mục X) | `rag_service.dart` (`_doUpdateCumulativeStorySummary`) | Thêm `isCancelled: () => stopwatch.elapsed > Duration(minutes: 4)` (trần rộng hơn vì `maxTokens: 900` so với 300) |

**Cố tình KHÔNG đụng tới**: mọi lệnh `generateStream()`/`generate()` mà
người dùng TRỰC TIẾP đang xem chạy (chat, "Đắp thịt"/"Viết tiếp"/"Kiểm
tra nhất quán"/"Tạo lại tất cả ghi chú", "Tạo chương hàng loạt qua đêm")
— các nơi này KHÔNG truyền `isCancelled` thời gian, giữ nguyên không giới
hạn thời gian đúng quyết định đã thống nhất ở mục H. Bản vá lỗ hổng 3 chỉ
mở khả năng dùng `isCancelled`, không tự áp đặt nó cho ai chưa chủ động
truyền vào.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật** (đúng thông lệ đã ghi ở mục T/mọi mục khác —
  môi trường sửa lỗi không có Flutter/Android SDK). Đã tự kiểm tra cân
  bằng ngoặc `{}/()/[]` cho cả 2 file Dart lẫn file C++ (có xử lý riêng
  raw string `R"(...)"`/comment khối của C++), nhưng đây KHÔNG thay thế
  được việc chạy `build.yml` (GitHub Actions) thật trước khi phát hành.
- Nhánh dịch thuật trung gian BẬT của `generateWithOptionalTranslation()`
  (khi người dùng bật tính năng mục 4.8) không nằm trong phạm vi bản vá
  lỗ hổng 3 — nhánh đó vốn đã dùng `generateStream()` + `isCancelled` từ
  trước (không dính lỗ hổng 3), nhưng 2 bước `translate()` (dịch
  prompt/dịch kết quả, dùng model dịch nhỏ ở slot 1) trong CÙNG hàm vẫn
  chưa có `isCancelled` — chưa xác nhận model dịch nhỏ có cùng rủi ro lặp
  vô tận hay không, chưa vá.
- Ngưỡng "3 phút"/"4 phút" cho `isCancelled` là số ước lượng hợp lý dựa
  trên `maxTokens` (300/900) và tốc độ chậm nhất đã đo (mục F/G/H), CHƯA
  đo thật trên máy — nếu model/máy chậm hơn mức đã biết, 1 lượt tóm tắt
  BÌNH THƯỜNG (không lặp) có thể bị cắt oan; cần người dùng xác nhận qua
  build thật, chỉnh `Duration` nếu cần.
- Bản vá lỗ hổng 1 (native) tăng khả năng bắt lặp cho VIỆT NGỮ nói chung
  (áp dụng cho MỌI lệnh generate, không riêng tóm tắt) — đây là lớp phòng
  vệ NHANH quan trọng nhất trong 3 lớp, vì nó giúp cả lệnh "Đắp thịt"
  người dùng đang trực tiếp xem cũng được cắt gần như tức thời nếu lặp,
  thay vì phải đợi tầng Dart chậm hơn — nhưng vẫn CHƯA đo lại bằng số
  liệu thật (cần lặp lại đúng kịch bản gây lặp, xem log có xuất hiện dòng
  `[CHAN DOAN LAP VO TAN]` ở tầng native hay không, và đo thời gian từ
  lúc bắt đầu lặp tới lúc bị cắt — kỳ vọng còn vài giây thay vì vài chục
  phút).
- **Không sửa nguyên nhân khiến model rơi vào lặp lúc đầu** — tăng
  `repetitionPenalty` lên 1.2 chỉ giảm khả năng xảy ra, không loại trừ
  hẳn; đổi model hoặc tinh chỉnh sampler sâu hơn (vd bật lại `n_gram`/
  `ngram_factor`/`penalty_window` — hiện chỉ đặt 1 LẦN qua `config.json`
  lúc nạp model, KHÔNG nằm trong 5 khoá JSON gửi lại mỗi lần `generate()`,
  xem mục 4.7) nằm ngoài phạm vi bản vá này.

### Phát hiện phụ — cảnh báo QNN trong native log, KHÔNG phải nguyên nhân sự cố trên
`native_debug.txt` cùng phiên cho thấy cả 4 file `.so` QNN thật
(`libQnnSystem`/`libQnnHtp`/`libQnnHtpPrepare`/`libQnnHtpV68Stub`) đều
`dlopen` thất bại ("not found"), và `libQnnHtpV68Skel.so` được xác nhận
KHÔNG tồn tại trong thư mục `lib/arm64` của APK — đúng như comment trong
chính native log yêu cầu kiểm tra lại bước copy ở `build.yml`. Đối chiếu
`build.yml` (`HEXAGON_ARCH=68`, đúng khớp Hexagon 780/v68 của máy test,
mục 1): bước "Đặt file .so vào đúng chỗ Android tự nhận" CÓ cố gắng `cp`
đủ 5 file QNN vào `jniLibs/arm64-v8a`, có in cảnh báo "THIẾU ..." (không
làm fail cả workflow) nếu `cp` lỗi — nghĩa là nếu file thật sự thiếu
trong APK đã cài, nhiều khả năng đúng các dòng "THIẾU ..." đã in ra trong
log GitHub Actions của lần build tạo ra APK này (cần người dùng tự mở lại
log build đó, bước "Đặt file .so vào đúng chỗ Android tự nhận", để xác
nhận file nào thiếu — chưa có log build đó ở đây để xác nhận chắc chắn
tại sao `cp` lỗi, ví dụ SDK QNN đổi cấu trúc thư mục giữa các phiên bản).
**Không liên quan tới sự cố "không thể tạo chương truyện"** — log xác
nhận `backendPreference=0` (đường mặc định) đã nạp thành công thẳng qua
OpenCL (`success: true, backend: opencl`), đúng thiết kế mục 2.2/5.53 (QNN
giờ chỉ là thử nghiệm CÓ THỂ BẬT THỦ CÔNG qua `backendPreference=3`,
không nằm trên đường mặc định) — dù build.yml có thiếu file QNN, người
dùng KHÔNG bị ảnh hưởng trừ khi chủ động bật thử nghiệm NPU đó.
