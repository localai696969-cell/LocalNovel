# LocalNovel — Project Architecture & Implementation Spec

Tài liệu này tổng hợp toàn bộ kiến trúc, công nghệ, lỗi đã gặp/đã tránh, và
backlog của dự án **LocalNovel** — app Flutter hỗ trợ viết tiểu thuyết dài kỳ
(1000+ chương) bằng AI, chạy trên Android, ưu tiên AI local tận dụng GPU/NPU.
Dùng tài liệu này làm ngữ cảnh đầu vào cho phiên làm việc mới.

---

## 1. Tổng quan dự án & Cấu hình phần cứng mục tiêu

- **Nền tảng**: Android, viết bằng Flutter/Dart
- **Máy test chính**: Asus Zenfone 8 — chip **Snapdragon 888** (tên mã Qualcomm nội bộ **SM8350**), Hexagon 780 NPU (thế hệ **V68**), Adreno 660 GPU, **16GB RAM**, chạy **Android 13**
- **Build**: hoàn toàn qua **GitHub Actions** (không có máy tính/Android Studio) — người dùng chỉ thao tác qua trình duyệt điện thoại: upload file zip mã nguồn lên GitHub, dán nội dung `build.yml`, bấm "Run workflow", tải APK về từ mục Artifacts, cài thủ công
- **Yêu cầu số 1, không thương lượng của người dùng (ĐÃ CẬP NHẬT — xem mục 5.53)**: model AI local bắt buộc phải chạy được **tối thiểu GPU**. Ban đầu ưu tiên tuyệt đối là NPU, nhưng đã điều tra và xác nhận (mục 5.53): công cụ CHÍNH THỨC trưởng thành nhất của Qualcomm cho LLM-trên-NPU (Genie/AI Hub Models) yêu cầu tối thiểu **Hexagon v73** — Snapdragon 888/Hexagon 780 của máy test là **v68**, thấp hơn 2 thế hệ. Quyết định đã thống nhất với người dùng: **chấp nhận GPU (OpenCL) làm đường chính, tối ưu hết mức**; QNN/NPU chuyển thành lựa chọn thử nghiệm CÓ THỂ BẬT THỦ CÔNG (`backendPreference=3`), không còn nằm trên đường mặc định. CPU-only vẫn bị coi là "vứt".
- **Repo cấu trúc**: 1 file zip (`local_novel.zip`) chứa toàn bộ `lib/` (Dart) + `android_native/` (Kotlin/C++ sẽ được ghép vào project Android lúc build) + `pubspec.yaml`; `build.yml` là workflow GitHub Actions dán trực tiếp trên web GitHub (không nằm trong zip).

---

## 2. Kiến trúc phần mềm

### 2.1. Interface AI chung — `AIProvider` (không phải `IInferenceProvider`)

File: `lib/services/ai_provider.dart`. Interface trừu tượng, 3 implementation:

- `LocalLlamaProvider` (`lib/services/providers/local_provider.dart`) — gọi vào tầng native MNN-LLM + QNN qua **Platform Channel** (KHÔNG dùng `dart:ffi`)
- `AnthropicProvider` (`lib/services/providers/anthropic_provider.dart`)
- `OpenAICompatibleProvider` (`lib/services/providers/openai_compatible_provider.dart`) — dùng cho OpenAI hoặc bất kỳ endpoint tương thích chuẩn OpenAI

Interface có: `generate()` (non-streaming), `generateStream()` (streaming), `isReady()`. Tham số sinh văn bản: `temperature`, `maxTokens`, `topP`, `topK`, `repetitionPenalty` — đều có default, người dùng chỉnh trong màn "Tham số sinh văn bản".

Model/provider **không hardcode** — người dùng tự thêm nhiều `LocalModelEntry` (nhiều model local) và nhiều `ApiProviderEntry` (nhiều provider API), chọn 1 cái đang active. Đổi model/provider giữa chừng **không mất bối cảnh** vì Story Bible/lịch sử chat lưu SQLite, tách biệt hoàn toàn khỏi provider đang dùng.

### 2.2. Kiến trúc native AI — MNN-LLM + QNN qua Platform Channel

**Lịch sử quan trọng cần biết**: dự án đã đổi engine AI local **4 lần** trước khi tới MNN:
`fllama` → `lib_llama_cpp` → `flutter_llama` → `llama_cpp_dart` (netdur) → **MNN-LLM (Alibaba) + QNN (Qualcomm)** (hiện tại).

Lý do đổi lần cuối: `llama_cpp_dart` do 1 cá nhân duy trì, API đổi liên tục, **chưa từng xác nhận chạy được GPU/NPU thật trên Android**. MNN-LLM được chọn vì:
- Có sản phẩm thật đã public ("MNN Chat" trên Google Play) chứng minh QNN NPU chạy thật trên Snapdragon 8-series
- Benchmark thật đo trên chính Zenfone 8 của người dùng (app MNN Chat gốc): **Prefill 129.8 t/s, Decode 16.7 t/s trên backend OpenCL (GPU)** — nhanh hơn ~15-16 lần so với CPU thuần (~1 tok/s) của các engine cũ
- Snapdragon 888/SM8350 nằm trong danh sách chip Qualcomm/Microsoft chính thức test QNN

**Kiến trúc native** (`android_native/`):
```
android_native/app/src/main/
  cpp/
    mnn_bridge.cpp       — JNI, gọi API công khai MNN (llm.hpp, class Llm)
    CMakeLists.txt       — biên dịch mnn_bridge.cpp, link với libMNN.so build ở bước trước
  kotlin/com/localnovel/
    MainActivity.kt      — đăng ký MethodChannel + EventChannel, xin quyền POST_NOTIFICATIONS
    mnnbridge/
      MnnNative.kt       — khai báo external fun JNI
      MnnBridge.kt       — xử lý MethodCallHandler + EventChannel.StreamHandler, điều phối GenerationService
      GenerationService.kt — Foreground Service + WakeLock
```

**2 SLOT MODEL ĐỘC LẬP** (multi-context thật, không giả): `slot 0` = model chính (viết truyện), `slot 1` = model dịch thuật trung gian. Mỗi slot có `Llm*` riêng trong `mnn_bridge.cpp` (mảng `g_slots[2]`), có thể cùng tồn tại trong RAM hoặc xả riêng từng cái — quyết định ở tầng Dart (`TranslationService`), không hardcode ở tầng native.

Cầu nối gọi native theo cơ chế **ĐÃ ĐỔI (mục 5.53) — mặc định đi thẳng GPU đã tối ưu, QNN chuyển thành thử nghiệm CÓ THỂ BẬT THỦ CÔNG**:
```
backendPreference=0/1 (mặc định) → OpenCL (GPU, đã tối ưu precision/memory/thread_num) → lỗi thì mới rơi xuống CPU
backendPreference=2 → ép CPU
backendPreference=3 (thử nghiệm, người dùng tự bật) → thử QNN trong tiến trình con cách ly + timeout 90s → lỗi/treo thì rơi xuống OpenCL → CPU
```
Lý do đổi: Hexagon v68 (Snapdragon 888) dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU (yêu cầu v73+, xem mục 5.53) — thử QNN mỗi lần mở model chỉ tốn thời gian chờ vô ích, không có cơ hội thành công thật trên máy này.

Dart gọi qua `MethodChannel('com.localnovel/mnn_method')` (lệnh 1 lần: loadModel/generate/unload/isLoaded/cancelGenerate) và `EventChannel('com.localnovel/mnn_stream')` (luồng token trả về, lọc theo `slot`).

### 2.3. Foreground Service — chạy nền không bị Android kill

Lý do: luồng dịch tuần tự (dịch → sinh văn → dịch ngược) có thể mất vài phút tới hàng giờ (chạy overnight), Android sẽ kill tiến trình nếu app xuống nền/tắt màn hình mà không có Foreground Service.

`GenerationService.kt`: Foreground Service + `PARTIAL_WAKE_LOCK` (trần an toàn 8 tiếng, đủ cho tác vụ qua đêm, tự nhả nếu quên gọi stop để tránh hao pin vô hạn nếu có lỗi). `foregroundServiceType="dataSync"` (suy luận hợp lý nhất, Android không có type "AI inference" riêng — nếu bị từ chối lúc chạy thì đổi sang `specialUse`, **CHƯA XÁC NHẬN 100%**). Bật/tắt tự động quanh mỗi lệnh `loadModel`/`generate` trong `MnnBridge.kt`.

**TỒN ĐỌNG CHƯA XONG**: mỗi lệnh generate hiện tự start/stop service riêng — với luồng dịch tuần tự nhiều bước (dịch → sinh → dịch ngược), nên gộp thành **1 lần start ở đầu pipeline, update nội dung thông báo giữa các bước qua `updateStage()`, chỉ stop ở cuối** — tránh khoảng hở ngắn giữa các bước. Chưa sửa.

### 2.4. Đa truyện (multi-novel)

Mọi bảng nội dung (`characters`, `world_rules`, `timeline_events`, `chapters`, `style_profiles`, `chat_sessions`, `chat_messages`, `imported_documents`) đều có cột `novel_id`. `local_models`/`api_providers` KHÔNG gắn theo novel (tài nguyên máy dùng chung). Máy nâng cấp từ bản cũ (1 truyện) tự động migrate dữ liệu vào 1 "Truyện của tôi" mặc định — không mất dữ liệu (`database_service.dart`, hàm `_migrateToMultiNovel`).

`main.dart`: `NovelGateScreen` (tự vào thẳng truyện active nếu đã chọn trước đó) → `NovelListScreen` (tạo/chọn/xóa truyện) → `RootScreen` (5 tab: Chương/Bách khoa/Trợ lý AI/Tài liệu/Cài đặt, dùng `IndexedStack` giữ trạng thái khi chuyển tab).

### 2.5. RAG (Retrieval-Augmented Generation) — 1 tầng, chưa phân tầng

`RagService` kết hợp 3 cơ chế: luật cứng (luôn nạp), khớp từ khóa (Character/WorldRule.keywords), truy xuất embedding ngữ nghĩa (cosine similarity, `EmbeddingService` — ưu tiên embedding thật nếu có, dự phòng vector "hashing" thuần Dart). Toàn bộ giới hạn trong `novelId`, có ngân sách ký tự (`contextBudgetChars`) theo hồ sơ thiết bị.

**GAP THẬT CHƯA LÀM**: chỉ có 1 tầng tóm tắt (mỗi chương → 3-5 câu, `summary_service.dart`). **CHƯA CÓ** tóm tắt phân tầng đệ quy (tier 2: nén cụm ~10 chương thành "tóm tắt cung"; tier 3: nén toàn bộ thành "bản đồ kịch bản" tổng thể) — cần thiết thật sự cho truyện triệu chữ, đã xác nhận là gap hợp lệ, chưa code.

---

## 3. Thư viện & Công nghệ đã chọn (Tech Stack)

| Lớp | Công nghệ | Ghi chú |
|---|---|---|
| UI/Framework | Flutter/Dart | An toàn dài hạn, Google chính thức |
| Lưu trữ | SQLite qua `sqflite` | Ổn định, có FTS4 cho tìm kiếm toàn văn chương |
| Gọi API cloud | HTTP thuần (không SDK riêng) | An toàn tuyệt đối, không phụ thuộc hãng nào ngừng hỗ trợ |
| AI local (engine) | **MNN-LLM** (Alibaba), build từ mã nguồn qua NDK/CMake trong CI, cờ `-DMNN_BUILD_LLM=true -DMNN_OPENCL=true -DMNN_QNN=true -DMNN_ARM82=true` | Core do Alibaba duy trì, không phải cá nhân |
| AI local (NPU) | **QNN SDK** (Qualcomm), bản "Community" tải công khai không cần đăng nhập: `https://softwarecenter.qualcomm.com/api/download/software/sdks/Qualcomm_AI_Runtime_Community/All/2.40.0.251030/v2.40.0.251030.zip` | Copy `include/QNN` + `lib` vào `MNN/source/backend/qnn/3rdParty/` trước khi build |
| Cầu nối Flutter↔Native | **Platform Channel** (MethodChannel/EventChannel) — KHÔNG dùng `dart:ffi` | Tránh lỗi dlopen .so đã ám cả dự án trước đây |
| Xuất file | Tự dựng EPUB/DOCX/TXT bằng `archive` package (không dùng thư viện xuất bản ngoài) | EPUB hiện đơn giản, chưa có bìa/mục lục thật |
| CI/CD | GitHub Actions, NDK mới nhất (tự dò bản mới nhất qua `sdkmanager --list`, KHÔNG ghim NDK 21 vì quá cũ) | Xem mục 5 — nhiều lỗi build đã xảy ra ở đây |

**Cân nhắc đã loại bỏ** (không dùng, đã so sánh kỹ trước khi quyết định MNN):
- ONNX Runtime GenAI + QNN EP: engine lõi rất chắc (Maven Central chính thức), nhưng gói GenAI cho Android "Java API pending" (chưa publish chính thức) — kém chín hơn MNN tại thời điểm quyết định.
- MediaPipe LLM Inference (Google), MNN gốc Tencent (nhầm lẫn — thực ra là NCNN của Tencent, chỉ mạnh thị giác máy tính, không có LLM binding Flutter): đều yêu cầu bỏ định dạng GGUF, không phải yêu cầu cứng của người dùng nhưng MNN vẫn thắng nhờ bằng chứng thật cụ thể hơn.

---

## 4. Logic các tính năng chính

### 4.1. Story Bible / Lorebook
`Character`, `WorldRule` (có `isHardRule`), `TimelineEvent` — mỗi entry có `keywords` kích hoạt kiểu lorebook NovelAI. Xem trước lorebook khi soạn chương (chip hiện nhân vật/luật đang được nạp).

### 4.2. Chương & xuất bản
CRUD chương, cảnh báo mâu thuẫn (`consistencyWarning`), tìm kiếm FTS toàn văn theo `novelId`. Xuất EPUB/DOCX/TXT (`export_service.dart`).

### 4.3. Chat đa phiên
Nhiều `ChatSession` mỗi truyện, lưu bền vững `ChatMessageRecord` (kèm `providerLabel` — biết tin nhắn nào do model nào trả lời). Xuất cuộc trò chuyện ra TXT/DOCX.

### 4.4. Tài liệu (dịch/tóm tắt cuốn chiếu)
`DocumentService` chia file `.txt`/`.md` thành chunk, xử lý tuần tự (dịch hoặc tóm tắt), ráp kết quả, xuất file. **Giai đoạn 2 (PDF/DOCX/ảnh) CHƯA làm** — chủ động hoãn để tránh rủi ro build.

### 4.5. Văn phong & đắp thịt outline
`StyleService` — mô tả văn phong bằng lời hoặc học từ mẫu văn CỦA CHÍNH người dùng (không lưu nguyên văn tác phẩm người khác, tránh vi phạm bản quyền). "Đắp thịt" outline sơ sài thành chương đầy đủ.

### 4.6. Tối ưu thiết bị
`DeviceProfileService` đọc `/proc/meminfo` + mã chipset thật, `BenchmarkService` đo tốc độ token/giây thực tế (có chặn số liệu vô lý — bài học từ lỗi cũ khi `fllama` từng trả kết quả giả). RAG budget tùy theo hồ sơ máy.

### 4.7. Tham số sinh văn bản
Màn `GenerationSettingsScreen`: `temperature`, `top_p`, `top_k`, `repetition_penalty`, `max_new_tokens` — lưu qua `SettingsService`, áp dụng lại mỗi lần gọi `generate()`/`generateStream()` qua JSON gửi xuống `set_config()` của MNN (tên khóa JSON xác nhận đúng theo tài liệu chính thức MNN: `temperature`, `top_p`, `top_k`, `repetition_penalty`, `max_new_tokens`).

**ĐÃ NỐI**: khung chat (`chat_screen.dart`) VÀ `chapter_editor_screen.dart` (Viết tiếp/Đắp thịt/In-line AI Rewrite đều đọc `SettingsService().loadGenerationConfig()`).

### 4.8. Dịch thuật trung gian
Vấn đề giải quyết: model viết truyện hay thường không train nhiều tiếng Việt, viết trực tiếp dễ ra câu ngô nghê/lặp từ vô nghĩa/ký tự lạ.

`TranslationService`: tùy chọn bật/tắt (mặc định TẮT). Khi bật: dịch câu hỏi/outline sang ngôn ngữ đích (mặc định tiếng Anh) bằng model dịch nhỏ ở **slot 1** → gọi model chính ở **slot 0** sinh văn bản → dịch kết quả về tiếng Việt bằng slot 1. **Luôn chạy tuần tự** (không song song), gộp cả 3 bước vào 1 phiên Foreground Service duy nhất (`beginPipeline`/`updateStage`/`endPipeline`). Quyết định giữ hay xả slot 1 giữa các bước: `SettingsService.loadTranslationKeepResidentMode()` — 'auto' (theo RAM máy, ngưỡng `ramKeepResidentThresholdMb = 6000`) / 'always' / 'never', cấu hình thủ công được ở màn "Tối ưu AI local".

**ĐÃ NỐI**: khung chat VÀ `chapter_editor_screen.dart`.

### 4.9. In-line AI Rewrite
Bôi đen đoạn văn trong `chapter_editor_screen.dart` (qua `TextField.contextMenuBuilder`, thêm mục vào menu bôi đen mặc định của Flutter) → menu lệnh nhanh: chữa lỗi chính tả, viết sinh động hơn, rút ngắn, đổi ngôi kể. Có bảo vệ nếu nội dung đổi trong lúc chờ AI (không ghi đè nhầm chỗ, fallback copy vào clipboard).

### 4.10. Version snapshot (undo AI viết đè) — MỚI
`ChapterVersion` (bảng `chapter_versions`) — chụp lại nội dung chương TRƯỚC mỗi lần "Viết tiếp"/"Đắp thịt"/"Viết lại bằng AI" có khả năng ghi đè. Tối đa `maxVersionsPerChapter = 20` bản mỗi chương, vượt quá tự xóa bản cũ nhất (tránh phình DB vô hạn qua hàng nghìn lần bấm AI). Màn `ChapterVersionsScreen` (mở qua menu "⋮" trong `chapter_editor_screen.dart`) xem/khôi phục — khôi phục cũng tự chụp lại trạng thái hiện tại trước, nên không bao giờ mất hoàn toàn dù khôi phục nhầm.

### 4.11. Tìm kiếm toàn văn UI — MỚI
Tầng DB (`chapters_fts`, FTS4) đã có sẵn từ trước qua `searchChapters()`, chỉ dùng ngầm cho RAG — trước đây KHÔNG có ô tìm kiếm cho người dùng tự tra cứu. `SearchScreen` (mở qua icon kính lúp trong `ChaptersScreen`) tìm ngay khi gõ (không debounce, FTS4 đủ nhanh), hiện đoạn trích quanh từ khóa khớp đầu tiên.

### 4.12. Glossary + chống lặp từ — MỚI
`GlossaryTerm` (bảng `glossary_terms`) — từ điển tra nhanh cho địa danh/thuật ngữ riêng của truyện, khác Story Bible ở chỗ KHÔNG tự động nạp vào prompt AI (không có `keywords` kích hoạt). Quản lý ở tab "Thuật ngữ" trong `StoryBibleScreen`.

`RepetitionAnalyzer` (`repetition_analyzer_service.dart`, thuần Dart không phụ thuộc Flutter) — thống kê từ/cụm bị lặp nhiều. Có xử lý riêng cho đặc thù tiếng Việt: đếm cả âm tiết đơn (unigram) LẪN cụm 2 âm tiết liền nhau (bigram), vì 1 "từ" tiếng Việt thường gồm nhiều âm tiết cách nhau bởi dấu cách — đếm âm tiết đơn riêng lẻ sẽ nhiễu do các âm tiết phổ biến (một, người...) lặp lại là bình thường. Có danh sách hư từ (`stopSyllables`) loại khỏi thống kê, và phát hiện riêng "lặp gần" (từ/cụm dồn vào rất ít đoạn văn — kiểu lặp gây khó chịu khi đọc nhất). Mở qua menu "⋮" → "Kiểm tra lặp từ" trong `chapter_editor_screen.dart`.

### 4.13. Story Bible nâng cao: phân loại thẻ + auto-mention — MỚI
`Character.category` (Nhân vật chính/phụ/Phản diện/Khác) và `WorldRule.category` (Luật lệ/Địa điểm/Vũ khí/Tổ chức/Vật phẩm/Khác) — trường phân loại RIÊNG, tách khỏi `role`/mô tả tự do, hiện dưới dạng chip trong danh sách. Nhân tiện sửa 1 bug có sẵn: `_addRule` trước đây LUÔN đặt `isHardRule: true` bất kể người dùng nhập gì ở ô từ khóa — giờ có `SwitchListTile` thật để chọn.

Auto-mention: gõ `@` trong nội dung chương → hiện hàng gợi ý tên nhân vật khớp (lọc theo phần đã gõ sau `@`), bấm để chèn. **Đơn giản hóa có chủ đích**: hàng gợi ý cố định ngay phía trên ô nội dung (không phải overlay bám theo đúng vị trí con trỏ) — tránh phải tính toán vị trí con trỏ bằng `TextPainter` (dễ sai lệch, không kiểm chứng được nếu không build/test thật nhiều vòng). Đánh đổi chấp nhận được: vẫn đúng chức năng, chỉ khác vị trí hiển thị.

### 4.14. EPUB bìa + mục lục thật — MỚI
Trước đây EPUB có mục lục qua `toc.ncx` (điều hướng bên trong app đọc sách) nhưng KHÔNG có ảnh bìa và không có trang mục lục hiện ngay trong nội dung sách. Giờ:
- Ảnh bìa tự sinh bằng `dart:ui` (`Canvas`/`ParagraphBuilder` vẽ gradient + tên truyện + tác giả) — không cần người dùng tự chuẩn bị ảnh (app cố tình không có `file_picker`, xem mục 5.2-tương-tự lý do lịch sử build).
- Thêm `nav.xhtml` (EPUB3 nav document, `properties="nav"`) — vừa là trang "Mục lục" THẬT nằm trong nội dung sách (trang đầu tiên sau bìa), vừa tương thích các reader hiện đại (Apple Books, KOReader...) ưu tiên `nav.xhtml` hơn `toc.ncx`. Giữ `toc.ncx` song song cho reader cũ — nâng `content.opf` lên `version="3.0"` nhưng vẫn khai `<spine toc="ncx">` để tương thích ngược.

### 4.15. Sao lưu & khôi phục toàn bộ dữ liệu — MỚI
`BackupService` xuất TOÀN BỘ dữ liệu (mọi truyện) thành JSON đóng gói trong `.zip`, chia sẻ qua `share_plus`. Khôi phục qua `FileBrowserScreen` (chọn file `.zip`/`.json`, tái dùng — không cần thêm `file_picker`).

**Quyết định thiết kế quan trọng**: xuất JSON (đi qua các hàm `query()` bình thường) thay vì copy thẳng file `.db` nhị phân — tránh phụ thuộc journal mode/WAL còn dở dang lúc copy, và khi khôi phục đi qua đúng các hàm `upsert*()` sẵn có (tự đồng bộ lại `chapters_fts`...) thay vì ghi đè thẳng file. **KHÔNG xuất API key** (nằm ở `flutter_secure_storage` riêng, tách biệt có chủ đích vì bảo mật) — người dùng cần nhập lại API key thủ công sau khi khôi phục trên máy mới, nhưng danh sách provider/model local (tên, base URL, model ID) vẫn khôi phục đầy đủ.

---

## 5. Lỗi đã gặp & bài học kỹ thuật quan trọng (tránh lặp lại)

Đây là phần quan trọng nhất để phiên sau không đi lại đúng đường cũ:

1. **Không đoán API — luôn đọc log/tài liệu thật trước khi viết code.** Toàn bộ chuỗi đổi engine AI (fllama → lib_llama_cpp → flutter_llama → llama_cpp_dart) đều do đoán sai tên hàm/tham số của package, gây hàng chục vòng build-lỗi-sửa. Nguyên tắc rút ra: trước khi viết cầu nối vào 1 thư viện mới, phải tra cứu (web search/đọc header thật qua bước build in log) — không suy luận từ tên hàm nghe hợp lý.

2. **`libllama.so not found` (đã giải quyết bằng cách đổi kiến trúc)**: nguyên nhân gốc là gói `llama_cpp_dart` không đóng gói sẵn thư viện native, phải tự tải AAR — rất mong manh. Giải pháp triệt để: đổi hẳn sang MNN + biên dịch native trực tiếp trong CI, dùng Platform Channel thay FFI (loại bỏ hoàn toàn kiểu lỗi dlopen).

3. **NDK 21 quá cũ, không hỗ trợ SVE2/KleidiAI**: lỗi `clang++: error: the clang compiler does not support '-march=...+sve2'`. Nguyên nhân: MNN dùng tối ưu ARM mới (KleidiAI/SME2) nhưng README của MNN khuyến nghị NDK 21 đã lỗi thời so với code thật. **Sửa**: luôn tự dò NDK mới nhất qua `sdkmanager --list`, không ghim version cứng.

4. **`QnnInterface.h file not found`**: `-DMNN_QNN=true` cần header/lib thật của Qualcomm QNN SDK, MNN không mang theo sẵn (SDK độc quyền). **Sửa**: tải QNN SDK bản Community công khai, copy vào `MNN/source/backend/qnn/3rdParty/`.

5. **Đường dẫn tương đối bị lệch khi `working-directory` đổi giữa các step GitHub Actions**: đặt `QNN_SDK_ROOT` bằng đường dẫn tương đối ở 1 step, dùng lại ở step khác có `working-directory` khác → sai đường dẫn dù CMake không báo lỗi cú pháp. **Bài học**: mọi biến môi trường dùng xuyên step PHẢI là đường dẫn tuyệt đối.

6. **`find_library` chỉ tìm đúng path cố định, không tìm thấy `libMNN.so`**: MNN đặt file `.so` không đúng chỗ đoán trước. **Sửa**: dùng `file(GLOB_RECURSE ...)` quét toàn bộ thư mục install thay vì đoán 1-2 path cố định.

7. **APK "release" build ra không cài được ("gói có vẻ không hợp lệ")**: bản release không có signing key (mã nguồn công khai không kèm khóa ký riêng). **Sửa**: dùng `assembleDebug` cho mục đích test (tự động ký bằng debug keystore).

8. **Android 14+ bắt buộc khai báo `foregroundServiceType`** — dùng `dataSync` (suy luận hợp lý nhất, **chưa xác nhận 100%** là lựa chọn đúng, có thể cần đổi `specialUse` nếu bị từ chối lúc chạy thật).

9. **Danh sách chip được phép dùng QNN trong app "MNN Chat" của Alibaba (`sQnnLibMap`) là hardcode riêng của họ, KHÔNG phải giới hạn kỹ thuật thật của QNN** — quyết định của dự án: không copy theo whitelist đó, luôn thử QNN trực tiếp trên mọi máy, bắt lỗi rồi rơi xuống GPU/CPU.

10. **Chưa xác minh, nghi ngờ là bịa**: tên hàm `MNN::Interpreter::releaseCache` (được đề xuất từ 1 tài liệu ngoài) — tra không ra bằng chứng, CHƯA đưa vào code. Nếu phiên sau cần quản lý KV cache giữa các đoạn xử lý (tóm tắt phân tầng, dịch tuần tự nhiều đoạn), phải đọc lại `llm.hpp` thật (đã từng in ra log CI 1 lần, hỏi người dùng có còn giữ log đó không) trước khi thêm lời gọi hàm nào.

11. **Snapdragon 888 (Zenfone 8) là chip 2021, không nằm trong danh sách máy Alibaba tự test ổn định** (README MNN cũ ghi rõ chỉ test kỹ trên OnePlus 13/Xiaomi 14 Ultra — chip 2025) — rủi ro ổn định runtime tổng quát (không riêng QNN) chưa loại trừ hoàn toàn, cần theo dõi khi test thật.

12. **`AnthropicProvider`/`OpenAICompatibleProvider` thiếu tham số so với interface `AIProvider`**: lỗi build lần đầu thật (Build APK #30) — `generate()`/`generateStream()` của 2 provider cloud này thiếu `topP`/`topK`/`repetitionPenalty` (chỉ có ở bản khai báo interface và ở `LocalLlamaProvider`), Dart bắt lỗi ngay ở bước biên dịch (`kernel_snapshot_program failed`), không phải lỗi runtime. **Đã sửa**: thêm đủ 3 tham số vào cả 2 provider — Anthropic Messages API nhận thẳng `top_p`/`top_k`, OpenAI-compatible nhận `top_p` + xấp xỉ `repetitionPenalty` bằng `frequency_penalty` (map thô `repetitionPenalty - 1.0`), `top_k` gửi kèm cho các endpoint tương thích mở rộng (llama.cpp server, vLLM, Ollama) dù không phải chuẩn OpenAI chính thức. Bài học: khi thêm tham số mới vào 1 interface dùng chung nhiều implementation, phải rà lại TẤT CẢ implementation, không chỉ implementation đang cần dùng ngay lúc đó.

13. **Cảnh báo (chưa phải lỗi) — Kotlin Gradle Plugin (KGP) legacy ở `device_info_plus`/`share_plus`**: log build in cảnh báo các bản Flutter tương lai sẽ FAIL nếu plugin còn áp dụng KGP kiểu cũ thay vì "Built-in Kotlin". Build #30 vẫn qua được bước này (chỉ warning), nhưng cần theo dõi: nếu 1 phiên bản Flutter sau này thật sự chặn cứng, phải nâng version 2 package này trong `pubspec.yaml` lên bản đã hỗ trợ Built-in Kotlin (tra changelog thật trước khi đổi version, không đoán).

14. **`translation_settings_screen.dart` hứa hẹn 1 mục ở màn "Tối ưu AI local" nhưng chưa từng code**: text giới thiệu ghi "xem 'Tối ưu AI local' để biết máy có nên giữ cả 2 model trong RAM hay không", nhưng màn đó chưa từng có phần này (phát hiện qua ảnh chụp màn hình thật của người dùng). **Đã sửa**: thêm mục "Dịch thuật trung gian — giữ model trong RAM" vào `local_optimization_screen.dart` (hiện RAM máy phát hiện được, ngưỡng tự động, và `SegmentedButton` cho 3 chế độ Tự động/Luôn giữ/Luôn xả — lưu qua `SettingsService.saveTranslationKeepResidentMode`, `TranslationService._shouldKeepResident()` đọc lại đúng lựa chọn này thay vì luôn tự đoán theo RAM). Thêm nút điều hướng thẳng từ màn dịch thuật sang màn tối ưu. Bài học: khi 1 màn hình VIẾT text nhắc tới 1 màn khác, phải THẬT SỰ đi kiểm tra màn kia có đúng như mô tả không, không được giả định.

15. **`TextField.labelText` bị cắt "..." khi field trống/chưa focus và label dài**: label chỉ hiển thị đủ nhiều dòng khi đã "float" lên trên (field có nội dung hoặc đang được focus) — khi field trống và chưa chạm vào, label render inline trong khung 1 dòng nên bị ellipsis. **Đã sửa** ở field "Thư mục model dịch thuật": rút ngắn `labelText`, chuyển phần giải thích dài xuống `helperText` (luôn hiển thị, tự xuống dòng qua `helperMaxLines`). Cần rà lại các `TextField` khác trong app có `labelText` dài tương tự nếu người dùng báo gặp lại vấn đề này ở màn hình khác.

16. **`dart:ui` (`Canvas`/`ParagraphBuilder`) dùng được trong 1 service thuần, không cần widget**: để sinh ảnh bìa EPUB (mục 4.14) không cần `file_picker` hay ảnh có sẵn — vẽ trực tiếp bằng `dart:ui` ngay trong `export_service.dart` (không phải file `.dart` UI/widget). Hoạt động được vì Flutter engine đã khởi tạo sẵn khi hàm này được gọi (luôn gọi sau khi app đã chạy, từ 1 hành động người dùng bấm nút xuất bản) — **CHƯA build/test thật để xác nhận không có vấn đề threading/timing nào** (lý thuyết đúng theo tài liệu Flutter, nhưng đây là lần đầu dự án dùng `dart:ui` trực tiếp ngoài widget tree).

17. **Khi thêm cột mới vào bảng đã tồn tại qua nhiều đời migration, luôn dùng `PRAGMA table_info` kiểm tra tồn tại trước khi `ALTER TABLE ADD COLUMN`** (mẫu `addColumnIfMissing` đã có sẵn từ migration v1→v2, tái dùng y hệt cho v2→v3 ở mục 4.10/4.13) — an toàn nếu 1 máy nào đó lỡ chạy migration 2 lần (vd do lỗi mất kết nối DB giữa chừng), không bị lỗi "duplicate column".

18. **[NGHIÊM TRỌNG NHẤT TỪ TRƯỚC TỚI NAY] `flutter create --org com.localnovel --project-name local_novel` sinh ra package THẬT là `com.localnovel.local_novel` (org + tên project ghép lại), KHÔNG PHẢI chỉ `com.localnovel`** — nhưng bước "Ghép code native (Kotlin + JNI) vào project Android" trong `build.yml` từ trước tới giờ luôn copy `MainActivity.kt` (file THẬT, có đăng ký `MethodChannel`) vào `scaffold/android/app/src/main/kotlin/com/localnovel/MainActivity.kt` — SAI đường dẫn, thiếu `/local_novel`. Hậu quả: file thật nằm ở nhầm chỗ (class thừa, không ai gọi tới), còn `AndroidManifest.xml` (đúng theo package thật `com.localnovel.local_novel`) vẫn khai báo dùng bản `MainActivity` MẶC ĐỊNH RỖNG do chính `flutter create` tự sinh — bản này build/cài/chạy giao diện đều bình thường (không lỗi biên dịch, không crash lúc mở app) nhưng KHÔNG ĐĂNG KÝ `MethodChannel` NÀO CẢ. Kết quả: **mọi tính năng dùng model local (chat, đo tốc độ...) đều lỗi `MissingPluginException` ngay từ Build APK #30 tới #33** — nghĩa là **chưa từng có bản build nào trước đó thực sự chạm tới code native/JNI/MNN cả**, toàn bộ những gì tưởng đã "xác nhận" trước đó (QNN, Foreground Service...) đều CHƯA từng được kiểm chứng thật.
    **Đã sửa** (từ Build APK #34): bước "Ghép code native" giờ **tự dò** đường dẫn + package thật bằng cách tìm file `MainActivity.kt`/`.java` mặc định mà `flutter create` vừa sinh ra (`find scaffold/android/app/src/main -name 'MainActivity.kt' -o -name 'MainActivity.java'`), đọc dòng `package ...` bên trong để biết package thật, xóa bản mặc định, copy file thật vào ĐÚNG chỗ + tự sửa dòng `package` cho khớp — không hardcode đường dẫn nữa.
    **Bài học lớn nhất**: khi 1 quy trình build có bước "sinh khung tự động rồi ghép code riêng vào", PHẢI xác minh runtime thật xem code ghép vào có đúng là code ĐANG CHẠY hay không (vd bằng cách cho code tự in ra 1 dấu hiệu nhận biết), không được tin ngầm định chỉ vì build "thành công" và app "mở lên bình thường" — 2 thứ này hoàn toàn không đảm bảo code native thật sự được dùng.

19. **Hạ tầng ghi log chẩn đoán 3 tầng (Dart/Kotlin/C++) khi chưa có ADB/logcat thật**: xây dựng `DebugLogService` (Dart, ghi trước/sau mỗi lệnh gọi `invokeMethod` rủi ro) + `kLog()` (Kotlin, ghi trước/sau mỗi bước trong `onMethodCall`) + `nativeLog()` (C++, ghi từng dòng trong `nativeGenerate`/`nativeLoadModel`) — TẤT CẢ ghi vào CÙNG 1 file, flush đĩa ngay lập tức (không đợi buffer), để nếu app crash cứng (SIGSEGV, native, không throw exception Kotlin/C++ bắt được), dòng log CUỐI CÙNG còn sống sót trên đĩa cho biết chính xác code dừng ở đâu. Đây là kỹ thuật chẩn đoán thay thế tạm cho logcat/tombstone thật khi người dùng không có máy tính + ADB. Xem trực tiếp trong app qua Cài đặt → "Log debug" (`DebugLogScreen`), không cần vào Files.

20. **Ghi file vào `/storage/emulated/0/Download/` cần quyền `MANAGE_EXTERNAL_STORAGE` ĐƯỢC CẤP THẬT (qua Cài đặt hệ thống), không tự có chỉ vì khai báo trong `AndroidManifest.xml`** — lần đầu thử ghi log debug vào `Download`, cả Kotlin lẫn C++ đều ghi thất bại ÂM THẦM (lỗi bị code tự bắt rồi bỏ qua, không báo gì) vì quyền này chưa từng được người dùng bật tay. **Đã sửa**: chuyển hẳn sang ghi vào thư mục RIÊNG của app (`appContext.filesDir` phía Kotlin, truyền xuống C++ qua hàm `nativeSetLogDir()` gọi 1 lần lúc khởi động) — thư mục này luôn ghi được, không cần xin quyền gì cả.

21. **`getApplicationDocumentsDirectory()` (Dart, gói `path_provider`) KHÔNG trùng thư mục với `context.filesDir` (Kotlin) trên Android** — dù nghe tên tưởng tương đương. Đã tra cứu xác nhận: `getApplicationDocumentsDirectory()` map sang 1 thư mục riêng (`.../app_flutter`), còn `getApplicationSupportDirectory()` mới đúng là map sang `getFilesDir()`. Khi cần Dart đọc lại đúng file mà tầng Kotlin/C++ vừa ghi vào `filesDir`, PHẢI dùng `getApplicationSupportDirectory()`, không phải `getApplicationDocumentsDirectory()` — nếu không sẽ không bao giờ đọc được file dù nó ghi ra thành công.

22. **`backendPreference` (QNN tự động / ép GPU / ép CPU) giờ đọc từ Cài đặt (`SettingsService.loadBackendPreference()`), không còn hardcode `0` trong `MnnBridge.kt` nữa** — cho phép người dùng tự đổi qua lại giữa 3 chế độ ngay trong app để khoanh vùng lỗi native theo backend, KHÔNG cần build lại APK mỗi lần thử. Bài học: khi đang debug 1 vấn đề mà giả thuyết hàng đầu là "lỗi backend X", nên ưu tiên làm tham số đó CẤU HÌNH ĐƯỢC từ UI trước khi thử sửa cứng trong code — tiết kiệm rất nhiều vòng build (mỗi vòng build native mất 15-20+ phút).

23. **[Đã LOẠI TRỪ, không phải nguyên nhân]** Từng nghi ngờ tham số `max_new_tokens = 0` truyền cứng cho `llm->response(...)` gây crash native (SIGSEGV) — sửa thành `-1` nhưng **crash vẫn xảy ra y hệt**, xác nhận qua log debug thật. Giả thuyết này đã bị loại bỏ hoàn toàn. Bài học: 1 giả thuyết nghe hợp lý về mặt kỹ thuật (khớp với "tài liệu chính thức không ai truyền 0") vẫn PHẢI được xác nhận bằng thực nghiệm thật trước khi coi là đã sửa xong — không dừng lại ở "nghe có vẻ đúng".

24. **[NGUYÊN NHÂN THẬT của crash native, đã xác nhận bằng log thật] R8/ProGuard đổi tên class/hàm Kotlin trong bản `--release`, làm JNI `GetMethodID("onToken", "(Ljava/lang/String;Z)V")` trả về `NULL`** — log debug xác nhận tên lớp thật lúc chạy của callback bị đổi thành `a0.a` (dấu hiệu R8 đổi tên kinh điển). Vì `GetMethodID` trả `NULL` không phải throw C++ exception (mà là "pending exception" phía JVM), nếu code cũ không kiểm tra `NULL` trước khi gọi tiếp `CallVoidMethod` sẽ crash cứng ngay (SIGSEGV/undefined behavior) — đúng khớp mọi triệu chứng quan sát được (crash y hệt ở mọi backend QNN/GPU/CPU, vì đây là lỗi ở TẦNG GỌI JNI, không liên quan gì tới backend suy luận).
    **Phát hiện quan trọng khác**: theo tài liệu chính thức Flutter, các bản gần đây **KHÔNG tắt được** code shrinking (R8) cho bản release nữa (cờ `--no-shrink` hết tác dụng, "Code shrinking is always enabled in release builds") — thử set `minifyEnabled false` trong `build.gradle` qua `sed` KHÔNG có tác dụng (đã xác nhận qua thực nghiệm, không phải chỉ tra tài liệu suông).
    **Cách sửa ĐÚNG** (khuyến nghị chính thức cho JNI + R8): thêm luật ProGuard `-keep class com.localnovel.** { *; }` (rộng, giữ nguyên cả package thay vì chỉ đúng `TokenCallback`, phòng hờ chỗ khác cũng dùng JNI tương tự) vào `proguard-rules.pro`, VÀ kiểm tra/tự chèn dòng `proguardFiles ...` vào khối `buildTypes { release { ... } }` của `build.gradle`/`build.gradle.kts` nếu còn thiếu (khung `flutter create` mặc định KHÔNG chắc đã có sẵn dòng này) — làm bằng Python (không dùng `sed` mù quáng) để xác nhận chắc chắn đã thêm đúng chỗ, in lại nội dung sau khi sửa để đối chiếu.
    **Bài học viết script build**: heredoc bash (`<< 'EOF' ... EOF`) LỒNG bên trong khối `run: |` của YAML rất dễ vỡ — YAML literal block scalar yêu cầu MỌI dòng (kể cả dòng kết thúc heredoc) phải thụt lề nhất quán, nhưng bash heredoc lại yêu cầu dòng kết thúc phải sát lề trái (trừ khi dùng `<<-` với TAB, không phải space) — 2 yêu cầu xung đột nhau. Cách né an toàn: dùng `python3 -c "..."` với code Python truyền qua 1 chuỗi (có thể nhiều dòng trong chuỗi double-quote của bash, bash hỗ trợ xuống dòng thật trong chuỗi), tránh hẳn heredoc lồng nhau. Luôn kiểm tra lại bằng `python3 -c "import yaml; yaml.safe_load(open('build.yml'))"` sau khi sửa `build.yml` bằng tay/script, và mô phỏng chạy thử đoạn script trích ra trong môi trường giả lập trước khi gửi cho người dùng chạy thật trên GitHub Actions (tiết kiệm được 1 vòng build/test mất 15-20 phút mỗi lần sai).

25. **Toàn bộ `onMethodCall` của `MnnBridge.kt` trước đây KHÔNG có try/catch bao ngoài cùng** — nghĩa là bất kỳ exception Kotlin nào ném ra TRỰC TIẾP trong hàm này (không phải trong coroutine, nên `finally`/`catch` của coroutine không với tới được) sẽ làm crash toàn bộ app ngay lập tức, không kịp gọi `result.error(...)` để báo cho Dart biết. Đã thêm 1 lớp try/catch bao ngoài cùng (`onMethodCall` gọi `onMethodCallInner` bên trong try/catch, bắt `Throwable`, log + trả lỗi qua `result.error(...)` thay vì để crash) — áp dụng cho MỌI lỗi Kotlin tương lai ở tầng này, không chỉ lỗi đã biết. Bài học: `MethodChannel.MethodCallHandler.onMethodCall` không tự động được Flutter engine bọc try/catch — bất kỳ handler nào có logic đủ phức tạp (gọi Android API có thể ném exception như Foreground Service, file I/O...) đều nên tự bọc try/catch ngay từ đầu, không đợi tới khi crash thật mới thêm.

26. **[GHI LẠI MUỘN — lỗi này đã xảy ra và ĐÃ ĐƯỢC SỬA ở phiên trước, nhưng chưa từng được chép vào tài liệu này] Lỗi `RuntimeException: Methods marked with @UiThread must be executed on the main thread`** — sau khi mục 24 (ProGuard) được sửa, `llm->response()` chạy trọn vẹn lần đầu tiên (không còn crash native), nhưng `eventSink?.success(...)` (gửi token về Flutter qua `EventChannel`) và `result.success(...)`/`result.error(...)` (trả kết quả `MethodChannel`) đang bị gọi từ luồng nền `Dispatchers.Default` (dùng để nạp/sinh model nặng, tránh treo UI) — trong khi Flutter bắt buộc 2 lệnh này phải chạy trên luồng chính (UI thread). **Cách sửa đã áp dụng**: bọc toàn bộ 7 chỗ gọi `eventSink?.success/error` và `result.success/error` nằm bên trong `scope.launch { ... }` (luồng nền) bằng `mainHandler.post { ... }` (đẩy đúng lệnh gọi lại Flutter về luồng chính), còn phần tính toán nặng (nạp/sinh model) vẫn giữ nguyên ở luồng nền, không đổi. **Xác nhận qua code hiện tại**: `MnnBridge.kt` đã có đủ các chỗ bọc này. **Xác nhận qua log thật** (`debug_log.txt` ngày 2026-07-26): không còn xuất hiện lỗi `@UiThread` nữa — lỗi này coi như đã đóng, chỉ là tài liệu quên cập nhật, nay bổ sung lại cho đủ lịch sử.

27. **[BUG MỚI PHÁT HIỆN VÀ ĐÃ SỬA — 2026-07-27] `SettingsService.currentProvider()` dựng 1 `LocalLlamaProvider()` MỚI mỗi lần được gọi**, thay vì tái sử dụng instance cũ. Vì cờ `_loaded` (đánh dấu model đã nạp hay chưa) nằm trên instance, không phải static/toàn cục, mỗi lần `chat_screen.dart`/`chapter_editor_screen.dart` gọi `SettingsService().currentProvider()` (tức là mỗi lần gửi tin nhắn/bấm AI) đều tạo instance mới với `_loaded=false` → luôn gọi lại `loadModel` native dù model không đổi. Xác nhận qua `debug_log.txt`: cả 3 lần chat cách nhau 5-10 giây đều có dòng `ensureLoaded... CHUẨN BỊ gọi loadModel native`. Không gây crash (MNN dùng mmap nên "nạp lại" vẫn nhanh vì trang nhớ đã có sẵn trong cache của hệ điều hành từ lần trước), nhưng tốn thời gian dựng lại không cần thiết mỗi lần chat. **Đã sửa**: thêm cache tĩnh (`_cachedLocalProvider`/`_cachedLocalModelPath`) trong `SettingsService`, chỉ tạo `LocalLlamaProvider` mới khi `modelPath` thật sự đổi (người dùng đổi model trong Cài đặt).

28. **[ĐANG DEBUG — CHƯA CÓ KẾT LUẬN CUỐI, đây là việc ưu tiên số 1 hiện tại] `llm->response()` chạy xong không crash, nhưng luôn trả về chuỗi RỖNG (`do dai ket qua=0`)** ở cả 3 lần thử trong `debug_log.txt` (kể cả lần `max_new_tokens=1024`, prompt 494 ký tự). Quan sát quan trọng nhất: khoảng thời gian giữa lúc Kotlin gọi `nativeGenerate` và lúc nó trả về chỉ ~1ms theo dấu thời gian tầng Kotlin — trong khi theo benchmark thật của chính máy này (mục 3, bảng tech stack: decode ~16.7 token/giây trên OpenCL), dù chỉ sinh đúng 1 token cũng không thể xong trong 1ms. Kết luận tạm thời: `response()` gần như chắc chắn KHÔNG chạy forward-pass thật nào — dừng ngay ở điều kiện dừng (EOS) từ token đầu tiên, không phải do máy chậm hay lỗi backend. Nghi ngờ hàng đầu: model `Orion-zhen-Qwen2.5-7B-Instruct-Uncensored-MNN-q4-chinh` (convert qua `LocalNovel_Convert_Model_To_MNN.ipynb`, dùng đúng `llmexport.py` chính thức của MNN — không phải script tự chế, nên ít khả năng lỗi quy trình convert) có `tokenizer_config.json`/`generation_config.json`/EOS token id lệch chuẩn so với bản Qwen2.5 gốc do đây là bản fine-tune "Uncensored" của bên thứ ba. **Đã thêm vào `mnn_bridge.cpp`** (chưa build/test): (a) đo thời gian thật bằng `std::chrono` quanh `llm->response()` để xác nhận chắc chắn giả thuyết "không chạy forward-pass thật" thay vì suy đoán qua log Kotlin; (b) log 120 ký tự đầu + 120 ký tự cuối của prompt thật (thay `\n` bằng `|`) để kiểm tra định dạng prompt gửi xuống native có đúng như kỳ vọng không; (c) log cảnh báo rõ khi kết quả rỗng, gợi ý hướng nghi ngờ. **Việc cần làm tiếp**: build lại với bản sửa này, đọc log mới để xác nhận/loại trừ giả thuyết; nếu xác nhận đúng, thử convert + test lại bằng 1 model Qwen2.5 gốc (không phải bản uncensored) để cô lập xem lỗi nằm ở bản convert cụ thể này hay ở tầng code.

30. **[CẬP NHẬT QUAN TRỌNG — tiếp tục mục 28, dựa trên bằng chứng thật, KHÔNG còn nghi ngờ model nữa] Đã cô lập được: lỗi KHÔNG nằm ở model, mà ở code cầu nối.** Trình tự bằng chứng, theo đúng thời gian thật xảy ra:
    - **CI (build #45-47)**: gặp lỗi build hoàn toàn khác, không liên quan tới MNN — `Could not find method kotlin()` khi biên dịch package Dart `jni` (bị kéo vào gián tiếp qua 1 plugin khác). Truy ra tận gốc: package `jni` (bản `1.0.1`, đã xác nhận qua log là bản mới nhất hiện có, không có bản nào mới hơn để nâng cấp) chỉ tự áp dụng plugin Kotlin khi `AGP major version < 9`; scaffold Flutter (bản `3.44.7`, đã pin) mặc định sinh ra AGP `9.0.1` → điều kiện đó sai → khối `kotlin { compilerOptions {...} }` trong chính `build.gradle` của `jni` không tìm thấy extension tương ứng → lỗi. **Đã sửa**: hạ AGP xuống `8.13.0` (đúng version Google xác nhận đi kèm Gradle `8.13` — "AGP 8.13 now requires Gradle 8.13"), hạ Gradle wrapper xuống `8.13`, hạ Kotlin xuống `2.1.20` (phần này chỉ có bằng chứng gián tiếp, chưa xác nhận 100% là cặp version tối ưu nhất, nhưng đã build qua được nên coi như đạt yêu cầu tối thiểu). Build APK từ đó đã qua được ổn định.
    - **Test cô lập model (2026-07-28)**: convert thêm 1 bản `Qwen/Qwen2.5-1.5B-Instruct` CHÍNH THỨC (không phải fine-tune "Uncensored"), qua đúng `LocalNovel_Convert_Model_To_MNN.ipynb`, dùng đúng `llmexport.py` chính thức của MNN. Kết quả: **lỗi giống hệt bản Uncensored** — `llm->response()` vẫn trả rỗng, `THOI GIAN THAT (ms)=0` ở cả 2 model, cả 2 prompt khác nhau hoàn toàn (chat có Story Bible lẫn benchmark cố định). → **Loại bỏ hoàn toàn giả thuyết "lỗi do tokenizer/EOS của bản Uncensored"** đã đặt ra ở mục 28 — không phải lỗi model, mà là lỗi hệ thống ở tầng code, ảnh hưởng như nhau bất kể model nào.
    - **Đọc `llm.hpp` THẬT** (lấy trực tiếp từ log CI, bước "In cấu trúc thư mục install thật" vốn đã in sẵn từ trước, chỉ là chưa ai đọc tới — đúng việc đã ghi nợ ở mục 5.10): xác nhận chữ ký `response(const std::string&, std::ostream*, const char*, int max_new_tokens=-1)` khớp chính xác 100% với cách `mnn_bridge.cpp` đang gọi — không phải lỗi tham số. Nhưng phát hiện 2 điều quan trọng chưa từng khai thác:
      - `set_config()` trả về `bool` (thành công/thất bại) — code cũ **bỏ qua hoàn toàn** giá trị này, không hề biết JSON cấu hình có thực sự được MNN chấp nhận hay không.
      - `class Llm` có `getContext()` trả về `const LlmContext*` — struct này MNN tự ghi lại `status` (enum `LlmStatus`: `NORMAL_FINISHED`/`MAX_TOKENS_FINISHED`/`INTERNAL_ERROR`/`TIMEOUT`...), `prompt_len`, `gen_seq_len`, `prefill_us`/`decode_us` thật — đây là nguồn duy nhất cho biết **chính xác** lý do MNN dừng sinh văn bản, thay vì phải suy đoán qua thời gian chạy như trước giờ.
    - **Đã thêm vào `mnn_bridge.cpp`** (chưa build/test): log giá trị `bool` thật của `set_config()`, và log toàn bộ `LlmContext` (status/prompt_len/gen_seq_len/prefill_us/decode_us) ngay sau mỗi lần `response()`. **Việc cần làm ngay ở phiên tiếp theo**: build lại, đọc đúng dòng log `LlmContext THAT — status=...` — con số đó sẽ cho biết chính xác hướng sửa (nếu `status=INTERNAL_ERROR`, tìm lỗi nội bộ MNN; nếu `prompt_len=0`, lỗi nằm ở bước tokenize/encode prompt, có thể liên quan tới `initRuntime()`/`load()` chưa hoàn tất đúng cách dù trả về `success:true`).

31. **[BUG MỚI PHÁT HIỆN VÀ ĐÃ SỬA — 2026-07-28] Cắt chuỗi preview prompt trong log (mục 5.28) làm hỏng cả file `native_debug.txt`.** `preview.substr(0, 120)`/`substr(size-120)` cắt theo byte, không theo ký tự — tiếng Việt có dấu dùng UTF-8 nhiều byte/ký tự, nếu điểm cắt rơi giữa 1 ký tự nhiều byte sẽ tạo chuỗi byte không hợp lệ. App đọc file log bằng UTF-8 (`File.readAsString()`) gặp đoạn hỏng đó ném `FileSystemException: Failed to decode data using encoding 'utf-8'`, hỏng toàn bộ file log (không đọc được cả các dòng quan trọng phía sau, kể cả `LlmContext` mới thêm ở mục 5.30) — không phải chỉ 1 dòng bị lỗi. **Đã sửa**: thêm 2 hàm `utf8SafeHead`/`utf8SafeTail`, lùi/tiến điểm cắt tới đúng ranh giới ký tự (bỏ qua continuation byte dạng `10xxxxxx`) trước khi cắt, đảm bảo không bao giờ cắt giữa 1 ký tự UTF-8 nhiều byte nữa.

33. **[NGHI NGỜ NGUYÊN NHÂN GỐC MẠNH NHẤT TỪ TRƯỚC TỚI NAY — 2026-07-28, tiếp tục mục 30] Ép backend OpenCL để loại trừ QNN — lỗi vẫn giống hệt, loại bỏ luôn nghi ngờ backend.** `status` vẫn `NOT_LOADED (-1)`, mọi trường `LlmContext` vẫn 0, dù đã ép chạy OpenCL thay vì QNN. Vì `NOT_LOADED` chính là giá trị khởi tạo MẶC ĐỊNH của `LlmContext` lúc vừa tạo, chưa từng bị đụng tới — kết luận: `response()` thoát ra ngay từ đầu, trước cả bước mã hoá prompt, không phụ thuộc backend nào. Truy ngược lên tận `createLLM()`: header thật (`llm.hpp`) đặt tên tham số là `config_path` — đường dẫn tới 1 FILE cấu hình, nhưng `local_provider.dart`/`mnn_bridge.cpp` từ đầu dự án luôn truyền thẳng đường dẫn THƯ MỤC model (`modelPath`) vào thẳng `createLLM()`, không phải file. Đối chiếu với `LocalNovel_Convert_Model_To_MNN.ipynb`: file cấu hình thật do notebook sinh ra tên là `llm_config.json` (xác nhận qua chính bước kiểm tra file bắt buộc của notebook, mục "Bước 6"). Nếu `createLLM` cố đọc 1 thư mục như thể là file JSON, tuỳ thư viện có thể không ném exception C++ nhưng cấu hình sẽ rỗng/mặc định hoàn toàn — khớp chính xác với MỌI triệu chứng quan sát được xuyên suốt từ mục 28 tới giờ (không crash, `LlmContext` chưa từng được đụng tới, giống hệt nhau ở mọi model/mọi backend). **Đã sửa**: `nativeLoadModel` giờ tự động dò đúng file cấu hình thật bên trong thư mục được truyền vào — ưu tiên `llm_config.json` (đúng tên notebook dùng), dự phòng `config.json` (quy ước MNN cũ hơn), chỉ dùng nguyên `path` gốc nếu bản thân nó đã là 1 file `.json` rồi (không đoán mù, có log cảnh báo rõ nếu không tìm thấy file nào). **CHƯA build/test** — đây là việc ưu tiên số 1 tuyệt đối cho phiên tiếp theo, nhiều khả năng là nguyên nhân gốc thật sự của toàn bộ chuỗi debug từ mục 28.

35. **[SỬA LẠI LẦN 2, DỰA TRÊN TÀI LIỆU CHÍNH THỨC MNN — 2026-07-29, tiếp tục mục 33] Ưu tiên sai thứ tự giữa `config.json` và `llm_config.json`.** Sau khi mục 33 sửa xong đường dẫn (dò đúng file bên trong thư mục thay vì dùng thẳng thư mục), `load()` vẫn trả về `false` ở cả 3 backend (QNN/OpenCL/CPU — xác nhận qua log thật, không phải giả thuyết). Tra cứu tài liệu chính thức `alibaba/MNN/transformers/README.md`: **`config.json` mới là file truyền thẳng vào `createLLM()`/`llm_demo` (mọi ví dụ dòng lệnh chính thức đều dùng `model_dir/config.json`)**; `llm_config.json` chỉ là file được chính `config.json` tự tham chiếu tới bên trong qua field `llm_config` (mặc định trỏ ngược lại `config.json` nếu field đó không có) — không phải điểm vào trực tiếp. Bản sửa ở mục 33 ưu tiên nhầm `llm_config.json` trước — sai thứ tự so với quy ước thật của MNN, dù cả 2 file đều tồn tại thật trong thư mục model (xác nhận qua ảnh chụp file explorer của người dùng: `config.json` 502B, `llm_config.json` 0,90kB). **Đã sửa**: đảo lại thứ tự — ưu tiên `config.json` trước, chỉ dùng `llm_config.json` làm dự phòng nếu không có `config.json`. **CHƯA build/test** — việc cần làm ngay phiên sau.

37. **[ĐANG NGHI NGỜ, ĐÃ ÁP DỤNG KHUYẾN NGHỊ CHÍNH THỨC MNN — 2026-07-29, tiếp tục mục 35] App crash ngay lập tức (không kịp ghi thêm log) ở lần đầu tiên `createLLM()` đọc đúng `config.json` thật, tham chiếu đầy đủ tới file weight thật.** Đây là lần đầu tiên xuyên suốt chuỗi debug mà code thực sự cố nạp dữ liệu nặng vào RAM (trước đó luôn đọc nhầm file, nên `load()` trả `false` gần như tức thì, không kịp chạm tới bước nạp weight thật). Máy test 16GB RAM (bổ sung vào mục 1, trước đây tài liệu chỉ ghi tên chip, thiếu RAM) — về lý thuyết đủ cho model 7B q4 (~4,85GB weight+embedding), nhưng RAM khả dụng thực tế tại thời điểm nạp có thể thấp hơn nhiều do hệ thống/app nền. Tra lại tài liệu chính thức MNN (đã đọc ở mục 35): có tuỳ chọn cấu hình `use_mmap` — "mặc định `false`, khuyến nghị bật `true` cho thiết bị di động" để tránh đúng kiểu OOM cấp phát 1 khối RAM liên tục lớn này. Code từ đầu dự án CHƯA từng bật tuỳ chọn này. **Đã sửa**: thêm `"use_mmap": true` vào JSON cấu hình gửi cho `set_config()` ở cả 3 backend (QNN/OpenCL/CPU), cả nhánh tự động lẫn ép buộc. **CHƯA build/test, CHƯA xác nhận đây có đúng là nguyên nhân hay không** — cần thử thêm cả model 1.5B nhỏ hơn (đã convert sẵn) để so sánh trước khi kết luận chắc chắn.

39. **[ĐANG DEBUG, ĐÃ THÊM CÔNG CỤ CHẨN ĐOÁN MỚI — 2026-07-29, tiếp tục mục 37] Xác nhận qua CI (`✅ CO use_mmap`, `✅ CO chot chan chong lenh`) rằng bản build ĐÚNG là mới nhất — loại bỏ hẳn nghi ngờ "test nhầm bản cũ".** Nhưng crash vẫn xảy ra y hệt ở CẢ model 7B lẫn 1.5B, đúng cùng 1 điểm (ngay sau log đường dẫn config, trước cả khi log "CHUAN BI goi Llm::createLLM()" — chỉ là 1 câu in chữ, không tính toán gì — kịp chạy). Vì model 1.5B không thể OOM trên máy 16GB, giả thuyết hết RAM (mục 37) gần như bị loại. Nghi ngờ mới: crash cứng thật (SIGSEGV hoặc bị hệ thống kill) xảy ra ngay trong `Llm::createLLM()` của thư viện MNN đã build sẵn — try/catch C++ không bắt được loại crash này. Thử dùng tính năng "Báo cáo lỗi" (bug report) của Android để lấy logcat thật nhưng không hoạt động trên máy người dùng (bấm không phản hồi). **Đã thêm**: bộ bắt tín hiệu crash (`signal handler`) tự viết trong `mnn_bridge.cpp` — bắt `SIGSEGV`/`SIGABRT`/`SIGBUS`/`SIGILL`/`SIGFPE`, tự ghi vào `native_debug.txt` bằng syscall thô (`open`/`write`/`close`, KHÔNG dùng `std::string`/cấp phát bộ nhớ động vì không an toàn trong ngữ cảnh signal handler thật) trước khi trả lại hành vi mặc định của hệ điều hành. Cài đặt 1 lần trong `nativeSetLogDir` (gọi sớm nhất lúc app khởi động).

40. **[CỘT MỐC LỚN NHẤT DỰ ÁN — 2026-07-30] LẦN ĐẦU TIÊN model local sinh ra văn bản thật thành công, kết thúc chuỗi debug từ mục 28.** Xác nhận qua log thật: `LlmContext status=1 (NORMAL_FINISHED)`, sinh ra 264 ký tự, `prompt_len=128`, `gen_seq_len=58`. Nguyên nhân cuối cùng: bộ bắt crash (mục 39) xác nhận **backend QNN crash cứng (`SIGSEGV`) mọi lúc, mọi model** ngay trong `llmSlot->load()`; **backend OpenCL (ép buộc, `backendPreference=1`) chạy được, không crash**. Kết luận: lỗi tích hợp QNN trên bản build này là thật, không liên quan gì tới toàn bộ chuỗi nguyên nhân đã sửa trước đó (đường dẫn config mục 33/35, quyền file, `use_mmap` mục 37...) — tất cả đều ĐÚNG và CẦN THIẾT, chỉ là QNN tự nó bị lỗi ở bước cuối cùng. **Việc cần làm tiếp**: đổi mặc định app dùng OpenCL thay vì thử QNN trước (tránh crash mỗi lần mở app), ghi nhận việc sửa QNN là backlog tối ưu sau, không phải chặn đường chính nữa. **Hiệu năng lần đầu rất chậm** (`decode_us=313505345` ~313 giây cho 58 token, `prefill_us=46756357` ~47 giây cho 128 token) — nghi ngờ hiện tượng "khởi động nguội" của OpenCL (GPU driver biên dịch kernel/shader lần đầu chạy), cần xác nhận qua lần sinh thứ 2 trong cùng phiên (không tải lại model) có nhanh hơn hẳn không. **Đã sửa thêm**: màu chữ phản hồi AI trong `chat_screen.dart` không tương phản với nền (chữ sáng mặc định theo theme tối đè lên nền `grey.shade100` sáng, gần như không đọc được) — đã chỉ định rõ `Colors.black87` cho khung AI và `onPrimaryContainer` cho khung người dùng.

42. **[PHÁT HIỆN QUAN TRỌNG — 2026-07-30] `GenerationService` (Foreground Service + WakeLock) chưa từng khai báo trong `AndroidManifest.xml`, khiến nó không có tác dụng thật từ đầu dự án.** Người dùng quan sát: khi tắt màn hình lúc đang sinh văn bản, đồng hồ đếm giây dừng hẳn, chạy tiếp khi bật màn hình lại — đúng hành vi Android đóng băng tiến trình khi không chạy đúng Foreground Service. Kiểm tra lại: `GenerationService.kt` viết đúng (start/stop/WakeLock `PARTIAL_WAKE_LOCK`), gọi đúng từ `MnnBridge.kt`, nhưng **`build.yml` chưa từng thêm bước khai báo `<service>` trong Manifest**, cũng thiếu quyền `FOREGROUND_SERVICE`/`WAKE_LOCK`. Với `compileSdk 35` (Android 15), thiếu `android:foregroundServiceType` trên khai báo `<service>` khiến `startForegroundService()` ném lỗi ngay khi gọi — rất có thể bị nuốt bởi try/catch bọc quanh (`MnnBridge.kt` dòng 44), khiến app tiếp tục chạy nhưng KHÔNG có Foreground Service/WakeLock thật, dễ bị hệ thống đóng băng khi màn hình tắt. Đây cũng giải thích số liệu `prefill_us` tăng bất thường (46,8s → 68,9s → 708,4s) qua các lần sinh trong log — nhiều khả năng không phải GPU chậm dần, mà là thời gian đóng băng khi màn hình tắt bị tính lẫn vào đồng hồ đo (`chrono` đo theo giờ tường, không phân biệt được lúc tiến trình bị đóng băng). **Đã sửa**: thêm bước vào `build.yml` khai báo `<service android:name="com.localnovel.mnnbridge.GenerationService" android:foregroundServiceType="dataSync" .../>` + 3 quyền còn thiếu. **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, thử sinh văn bản dài, tắt màn hình giữa chừng, xác nhận đồng hồ vẫn chạy tiếp (không đóng băng) và thời gian đo được ổn định qua nhiều lần, không tăng bất thường nữa.

43. **[BACKLOG, CHƯA ĐỦ BẰNG CHỨNG ĐỂ SỬA NGAY — 2026-07-30] Yêu cầu ép chạy QNN (NPU) thay vì OpenCL (GPU) để tăng tốc — theo kinh nghiệm người dùng, NPU thường nhanh hơn GPU tới 10 lần (dẫn chứng từ Stable Diffusion 1.5).** Về nguyên tắc, đúng — NPU thường nhanh và tiết kiệm điện hơn GPU nhiều cho suy luận LLM. Nhưng hiện tại **QNN đang crash cứng thật (`SIGSEGV`, xác nhận qua bộ bắt crash mục 39)** ngay trong `llmSlot->load()`, không phải vấn đề tốc độ — cần sửa được lỗi crash đó trước khi bàn tới việc "ép dùng". Chưa đủ bằng chứng để xác định chính xác nguyên nhân crash (cần bản backtrace symbolized thật, ví dụ qua `ndk-stack`/`addr2line` đối chiếu file `.so` debug, hiện chưa có công cụ này trong quy trình) — có thể do phiên bản QNN SDK 2.40.0 Community không khớp hoàn toàn driver Hexagon 780 thật trên Snapdragon 888, hoặc lỗi cấu hình graph riêng cho model 7B q4. Không nên tiếp tục đầu tư thời gian vào việc này trước khi mục 42 (Foreground Service) được xác nhận sửa xong, vì đó là vấn đề ảnh hưởng rộng hơn (mọi backend), còn QNN chỉ ảnh hưởng riêng tốc độ.

44. **[SỬA XONG — 2026-07-30] Chat không hiện chữ dần, phải đợi sinh xong hết mới thấy — người dùng phát hiện đúng.** Tầng Dart (`local_provider.dart`, `chat_screen.dart`) đã viết đúng cơ chế hiển thị từng chữ (`await for (chunk in stream) setState(() => reply.text += chunk)`), nhưng tầng C++ (`mnn_bridge.cpp`) trước đây gọi `llm->response(promptStr, &fullOutput, ...)` với `fullOutput` là 1 `std::ostringstream` THƯỜNG — chỉ gom chữ vào bộ nhớ, không đẩy ra JNI cho tới khi `response()` hoàn toàn kết thúc, rồi mới gọi `CallVoidMethod` đúng 1 lần duy nhất với toàn bộ văn bản. Trong khi đó, MNN nội bộ THẬT SỰ ghi (`operator<<`) vào đúng `ostream` được truyền vào ngay mỗi khi sinh xong 1 đoạn — chỉ là code chưa "nghe" được thời điểm đó. **Đã sửa**: viết lớp `JniStreamingBuf` kế thừa `std::streambuf`, chặn đúng điểm MNN ghi chữ vào (`xsputn`/`overflow`), gọi `CallVoidMethod` (JNI_FALSE, "chưa xong") ngay lập tức mỗi lần MNN ghi 1 đoạn, thay vì gom hết. Sau khi `response()` trả về, chỉ gửi thêm 1 tín hiệu rỗng kèm JNI_TRUE để báo "xong" (không gửi lại toàn bộ văn bản, vì Dart đã có sẵn cơ chế bỏ qua token rỗng, chỉ dùng cờ `done` để đóng stream — không cần sửa gì ở tầng Dart). **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, xác nhận chữ hiện dần từng đoạn khi chat, không còn đợi sinh xong hết mới thấy.

46. **[THAM KHẢO MNN CHAT CHÍNH THỨC — 2026-07-30, tiếp tục mục 43] Tìm được 2 khác biệt quan trọng giữa cách app này và MNN Chat (app chính thức Alibaba) xử lý QNN.** Đọc mã nguồn thật `apps/Android/MnnLlmChat/.../qnn/QnnModule.kt`: (1) MNN Chat nạp TƯỜNG MINH từng thư viện QNN bằng `System.load()` với đường dẫn tuyệt đối, đúng thứ tự, TRƯỚC khi gọi `Llm.createLLM()` — tài liệu ghi rõ "QNN libraries phải được nạp trước khi gọi createLLM để đăng ký backend đúng cách"; app này trước giờ chỉ đặt file `.so` vào `jniLibs/` và để Android tự nạp theo cơ chế JNI thông thường, không đảm bảo đúng thời điểm. (2) MNN Chat thiết lập 2 biến môi trường `ADSP_LIBRARY_PATH` và `LD_LIBRARY_PATH` trỏ đúng thư mục chứa file `.so`, để runtime RPC của Hexagon DSP tìm thấy thư viện skeleton/stub khi giao tiếp với NPU thật — app này **chưa từng thiết lập 2 biến này**. Ngoài ra phát hiện **thiếu hẳn 1 file `libQnnSystem.so`** ("thư viện giao diện quản lý backend QNN") trong danh sách 5 thành phần bắt buộc mà MNN Chat liệt kê — `build.yml` trước giờ chỉ copy 4/5 file. Xác nhận Snapdragon 888 (SM8350) đúng là Hexagon V68 theo bảng chính thức, khớp với `HEXAGON_ARCH="68"` đã dùng — không phải nguyên nhân. **Đã sửa**: thêm bước copy `libQnnSystem.so` vào `build.yml`; thêm hàm `setupQnnEnvironmentOnce()` trong `MnnBridge.kt` — thiết lập 2 biến môi trường qua `Os.setenv()` + nạp tường minh 5 thư viện QNN bằng `System.load()` đường dẫn tuyệt đối theo đúng thứ tự MNN Chat dùng, gọi đúng 1 lần trước khi thử QNN lần đầu. **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, đổi backend về "Tự động (QNN trước)", thử chat, xem QNN có còn crash không; nếu vẫn crash, đọc thêm `si_addr`/backtrace (mục 39 nâng cấp) để biết chính xác vị trí lỗi còn lại.

47. **[BACKLOG — đã bàn kỹ, CHỦ ĐỘNG HOÃN lại sau khi xong mục 28/33/35/37/39/40/42/44] Provider "GPU ngoài" (mượn/thuê GPU người khác, vd qua Colab) + lớp ẩn danh hoá thực thể.** Bối cảnh: người dùng muốn thêm 1 `AIProvider` mới gọi tới model chạy trên GPU không thuộc sở hữu mình (Colab free hoặc GPU thuê), với yêu cầu bảo mật cao nhất có thể đạt được thật (không phải ảo tưởng "tuyệt đối"). Đã thống nhất kiến trúc phòng thủ theo lớp, KHÔNG làm tới khi mục 28 xong (ưu tiên có model local chạy ổn định trước, giảm phụ thuộc GPU ngoài):
    - **Lớp 1 (ưu tiên cao nhất khi quay lại, rẻ nhất)**: ẩn danh hoá thực thể — thay tên nhân vật/địa danh/thuật ngữ riêng (đọc từ `Character`/`WorldRule`/`GlossaryTerm` có sẵn trong Story Bible) bằng placeholder trước khi gửi, map ngược khi nhận về. Chạy hoàn toàn ở Dart, không tốn hiệu năng GPU.
    - **Lớp 2**: không định danh người gửi (token phiên ngẫu nhiên, tài khoản Google phụ tách biệt khỏi tài khoản chính khi dùng Colab).
    - **Lớp 3**: rải yêu cầu qua nhiều provider/phiên khác nhau theo thời gian (kiến trúc `ApiProviderEntry` đã hỗ trợ sẵn nhiều provider) — không để 1 nơi tích luỹ toàn bộ 1 tác phẩm.
    - **Lớp 4**: không giữ Colab runtime chạy 24/7, không log phía server tự viết.
    - **Lớp 5**: TLS/HTTPS qua Cloudflare Tunnel hoặc ngrok (đã có sẵn theo yêu cầu ban đầu).
    - **Giới hạn đã thống nhất, KHÔNG được quên khi làm**: không lớp nào ở trên ngăn được chủ hạ tầng vật lý (Google/chủ GPU thuê) đọc plaintext nếu họ có quyền hypervisor — mức bảo vệ thật duy nhất cho việc đó là GPU Confidential Computing (NVIDIA H100/H200 CC, có ở 1 số gói GPU thuê riêng trả phí như Azure NCC H100 v5, KHÔNG có ở Colab miễn phí), chấp nhận ~5-15% chậm hơn. UI thêm provider "GPU ngoài" phải hiển thị rõ giới hạn này, không được quảng cáo là "an toàn tuyệt đối".
    - Việc cần code khi quay lại: module ẩn danh hoá 2 chiều (Dart) + `TrustedRemoteGpuProvider` (kế thừa `OpenAICompatibleProvider`) + khối cảnh báo rõ trong UI màn thêm provider.

48. **[SỬA XONG — 2026-07-31, tiếp tục mục 43] Bug nút "+" ở `story_bible_screen.dart` luôn mở "Nhân vật mới" bất kể đang ở tab nào (Nhân vật/Luật thế giới/Văn phong/Thuật ngữ) — xác nhận qua 3 ảnh chụp màn hình giống hệt nhau.** Nguyên nhân: `Builder(builder: (context) { final tabIndex = DefaultTabController.of(context).index; ... })` — `Builder` không tự động lắng nghe `TabController`; đọc `.index` bên trong nó chỉ lấy đúng giá trị tại lần build ĐẦU TIÊN của toàn màn hình, vuốt/chạm đổi tab sau đó KHÔNG kích hoạt build lại FAB (vì `TabController.index` đổi qua `notifyListeners()`, không qua cơ chế InheritedWidget rebuild thông thường). **Đã sửa (lần 1, có bug — xem mục 49)**: đổi `Builder` thành `AnimatedBuilder(animation: DefaultTabController.of(context), builder: ...)`.

49. **[BUG DO CHÍNH PHIÊN NÀY GÂY RA, ĐÃ SỬA TRIỆT ĐỂ CÙNG NGÀY — 2026-07-31] Bản sửa mục 48 làm toàn bộ tab "Bách khoa" hiện MÀN HÌNH TRẮNG XOÁ** (xác nhận qua ảnh chụp màn hình thật của người dùng — chỉ còn thanh điều hướng dưới, không còn AppBar/TabBar/nội dung/FAB nào). **Nguyên nhân**: `DefaultTabController.of(context)` đặt ở vị trí tham số `animation:` của `AnimatedBuilder` được tính TOÁN NGAY LẬP TỨC bằng `context` CỦA CHÍNH `build()` hàm này — context đó nằm ở vị trí TRÊN `DefaultTabController` trong cây widget thật sự dựng ra (vì `DefaultTabController` chính là widget được TRẢ VỀ bởi lời gọi `build()` này), không phải context nằm DƯỚI nó — nên `.of(context)` luôn thất bại ngay khi build, ném lỗi khiến build() không trả về được gì, và ở bản release Flutter ẩn traceback lỗi, chỉ hiện màn hình trắng/xám trơn thay vì "red screen of death" như bản debug. Đây chính xác là lý do bản gốc dùng `Builder` (không phải quên làm reactive) — `Builder` tạo ra 1 context MỚI, đúng vị trí bên dưới `DefaultTabController` một khi đã mount. **Đã sửa triệt để**: bỏ hẳn `DefaultTabController` khỏi cây widget, cho `_StoryBibleScreenState` (đã có sẵn `SingleTickerProviderStateMixin`) tự sở hữu 1 `TabController` riêng (`late final TabController _tabController`, khởi tạo ở `initState()`, `dispose()` đúng cách), gán trực tiếp vào `TabBar(controller: _tabController)`/`TabBarView(controller: _tabController)`, và FAB dùng thẳng `AnimatedBuilder(animation: _tabController, builder: (context, _) { final tabIndex = _tabController.index; ... })` — không còn `.of(context)` ở đâu trong màn hình này nữa, loại bỏ hẳn cả nhóm lỗi định phạm vi context (context scoping) liên quan tới `InheritedWidget`. **Bài học lớn**: khi 1 sửa lỗi cần đọc giá trị từ `XxxController.of(context)` bên trong 1 vị trí không phải `build(BuildContext context)` trực tiếp (ví dụ tham số của 1 widget con), phải kiểm tra kỹ CONTEXT NÀO đang được dùng có thực sự nằm DƯỚI ancestor widget cần tìm trong cây ĐàDỰNG hay không — nếu nghi ngờ, cách an toàn nhất luôn là cho `State` tự sở hữu `Controller` riêng thay vì phụ thuộc `Default*Controller.of(context)`.

50. **[SỬA XONG — 2026-07-31] `setState()` không kiểm tra `mounted` sau khi `await` AI sinh văn bản dài (30 giây tới vài phút) trong `chapter_editor_screen.dart` — lặp lại y hệt ở 4 hàm: `_continueWithAI`, `_fleshOutOutline`, `_checkConsistency`, `_applyRewrite`.** Người dùng báo "tạo chương thì cũng dễ bị văng" — đúng nguyên nhân: nếu thoát màn hình (back/chuyển tab) trong lúc đang chờ AI, khi tác vụ hoàn tất và gọi `setState()` trên 1 `State` đã bị huỷ (`dispose()`), Flutter ném `setState() called after dispose()`, crash. **Đã sửa**: thêm `if (!mounted) return;`/`if (mounted) {...}` bao quanh MỌI `setState()` xảy ra sau 1 điểm `await` trong cả 4 hàm trên, bao gồm cả nhánh `finally` (dùng để tắt cờ `generating`/`fleshingOut`/`checking`/`rewriting`).

51. **[SỬA XONG — 2026-07-31] `rag_service.dart` — model tự bịa ra nội dung Story Bible giả khi Story Bible thực tế đang TRỐNG.** Người dùng báo hiện tượng model trả lời như đã có sẵn 1 bộ Story Bible chi tiết (thế giới ma thuật, nhân vật chính...) dù mới gõ "alo", nghi ngờ spyware/bộ lọc ẩn — **xác nhận không phải**, là hallucination thuần tuý do lỗi prompt: `buildContext()` trả về chuỗi RỖNG khi chưa có luật thế giới/nhân vật/chương nào, nhưng `buildSystemPrompt()` vẫn viết cứng "Dưới đây là dữ liệu Story Bible... [để trống]... tham chiếu đúng Story Bible" — ra lệnh model tham chiếu 1 thứ không tồn tại, model 7B (đặc biệt bản "uncensored") chọn cách tự dựng nội dung cho hợp lý thay vì báo "không có dữ liệu". **Đã sửa**: khi context rỗng, đổi hẳn nội dung — nói thẳng "Story Bible hiện đang trống, TUYỆT ĐỐI KHÔNG được tự bịa", áp dụng cho cả `buildSystemPrompt()` (chat) và `buildConsistencyCheckPrompt()` (kiểm tra mâu thuẫn chương).

52. **[XÁC NHẬN QUAN TRỌNG NHẤT VỀ QNN, KẾT THÚC ĐIỀU TRA TỪ MỤC 43/46 — 2026-07-31] QNN crash SIGSEGV không phải lỗi packaging/config có thể vá bằng code — máy test nằm DƯỚI mức phần cứng tối thiểu mà chính Qualcomm công bố cho LLM-trên-NPU.** Tra cứu tài liệu chính thức Qualcomm AI Hub Models/Genie (công cụ LLM-trên-NPU trưởng thành nhất, do chính Qualcomm phát triển): yêu cầu tối thiểu **Hexagon architecture v73**. Snapdragon 888 dùng Hexagon 780 = **v68** (xác nhận qua Wikipedia + bảng ánh xạ kiến trúc Qualcomm) — thấp hơn 2 thế hệ (v73 ứng với Snapdragon 8 Gen 2 trở lên). RAM 16GB của máy dư thừa theo yêu cầu Qualcomm nêu cho model 7B — cái thiếu KHÔNG phải RAM, mà là thế hệ NPU. Giải thích hợp lý cho toàn bộ chuỗi crash: LLM có KV-cache đổi hình dạng đồ thị (shape) liên tục qua từng token, đòi hỏi QNN compiler (vốn biên dịch đồ thị TĨNH offline) phải tách thành hàng chục đồ thị con cố định — hỗ trợ attention/RoPE trên HTP mới được bổ sung ở các thế hệ Hexagon gần đây hơn hẳn hỗ trợ tích chập (convolution — thứ NPU đời cũ như v68 đã làm tốt từ lâu, giải thích vì sao NPU chạy Stable Diffusion 1.5 — đồ thị tĩnh, không đổi hình dạng — chạy tốt trên cùng máy này). Model dùng trong app (kể cả tự convert bằng `LocalNovel_Convert_Model_To_MNN.ipynb`) cũng CHƯA từng qua bước biên dịch riêng cho QNN (`generate_llm_qnn.py` + build cờ `-DMNN_QNN_CONVERT_MODE=ON`, cần QNN SDK trên máy tính) — càng củng cố kết luận trên. **Quyết định đã thống nhất với người dùng**: chấp nhận GPU (OpenCL) làm đường chính, tối ưu hết mức (mục 5.54); QNN chuyển hẳn thành lựa chọn thử nghiệm CÓ THỂ BẬT THỦ CÔNG, không xoá code (`backendPreference=3`), dành cho trường hợp đổi sang máy chip mới hơn (Snapdragon 8 Gen 2+) sau này.

53. **[NÂNG CẤP CƠ CHẾ AN TOÀN CHO QNN — 2026-07-31, thay thế mục 39 khi backendPreference=3 được bật] `sigsetjmp`/`siglongjmp` chỉ bắt được crash TỨC THỜI (SIGSEGV ngay lập tức), KHÔNG bắt được TREO VÔ HẠN.** Ảnh chụp màn hình thật cho thấy có lần "Đang chạy... 6545s" (~109 phút)/"1925s" (~32 phút) KHÔNG hề crash, chỉ đứng im không ra chữ — rất có thể QNN đang chờ phản hồi từ Hexagon DSP qua FastRPC mà không bao giờ trả lời, không phải signal nào cả. **Đã thay** cơ chế bắt crash bằng cách ly tiến trình con (`fork()` + `pipe()` + `poll()` với timeout 90 giây): tiến trình con thử `Llm::createLLM()` + `load()` backend QNN thuần C++ (không đụng JNI/JVM sau `fork()` — an toàn); tiến trình cha chờ kết quả có giới hạn thời gian bằng `poll()`, nếu tiến trình con CRASH (bắt qua `waitpid`) hoặc TREO quá 90s (chủ động `SIGKILL`), tiến trình cha (app thật) không hề bị ảnh hưởng, rơi xuống OpenCL ngay. Nếu probe báo thành công, tiến trình cha tự load lại QNN thật (không dùng chung bộ nhớ giữa 2 tiến trình được). Cơ chế này giờ chỉ chạy khi `backendPreference=3` (xem mục 52).

54. **[SỬA XONG — 2026-07-31, theo quyết định mục 52] Tối ưu tốc độ GPU thật sự theo đúng khuyến nghị chính thức MNN — trước đây thiếu hoàn toàn.** Config OpenCL cũ chỉ có `backend_type` + `use_mmap`, thiếu 3 tham số tài liệu MNN khuyến nghị rõ ràng để tăng tốc: `"precision": "low"` (ưu tiên fp16, nhanh hơn trên GPU di động Adreno), `"memory": "low"` (bật lượng tử hoá runtime, giảm băng thông bộ nhớ — nút thắt cổ chai lớn nhất khi chạy LLM trên GPU di động, không phải tốc độ tính toán thuần), `"thread_num": 68` (giá trị cụ thể tài liệu MNN chỉ định riêng cho suy luận OpenCL). Thêm `"tmp_path"` trỏ vào cache dir riêng của app (JNI mới `nativeSetCacheDir`, dùng `context.cacheDir` bên Kotlin) — MNN OpenCL tự lưu cache kết quả autotuning kernel vào đây, các lần load SAU tái sử dụng cache thay vì dò lại từ đầu mỗi lần mở model. Cập nhật UI `local_optimization_screen.dart`: nhãn "Tự động (QNN trước)" → "Tự động (GPU tối ưu)", thêm lựa chọn thứ 4 "Thử QNN (thử nghiệm)" ứng với `backendPreference=3`.

55. **[SỬA XONG — 2026-07-31] Xử lý tài liệu (dịch/tóm tắt) thiếu 2 việc: không có UI chỉnh prompt, và không thể tiếp tục dở dang nếu văng giữa chừng.** `DocumentService.processDocument()` đã có sẵn tham số `customInstruction` từ đầu nhưng CHƯA từng có UI nào truyền vào — người dùng phát hiện đúng. **Đã sửa**: thêm hộp thoại chỉnh prompt trước khi chạy (`_askCustomPrompt`) trong `document_screen.dart`, hiện sẵn prompt mặc định để người dùng biết đang dùng gì. Đồng thời `processDocument()` trước đây LUÔN xử lý lại từ đoạn đầu tiên kể cả đoạn đã có kết quả — với tài liệu dài (dễ dính lỗi native khi `generate()`, phần này KHÔNG được cách ly như bước `loadModel` ở mục 53), văng giữa chừng mất hết tiến độ. **Đã sửa**: thêm `resumeFromProgress` (mặc định `true`) — bỏ qua đoạn đã có `resultText`, chỉ xử lý tiếp đoạn còn thiếu.

56. **[SỬA XONG — 2026-07-31] Android 13+ "vuốt back dự đoán" (predictive back gesture) có thể thoát màn hình ngay giữa lúc AI đang chạy (tạo chương/dịch/tóm tắt), làm mất kết quả đang chờ dù mounted-guard (mục 50) đã tránh được crash.** Chưa xác định được cơ chế kỹ thuật chính xác 100% vì không có máy thật để dựng lại (nghi ngờ liên quan tới cách Flutter/Android 13+ xử lý cử chỉ back mới nếu app chưa khai báo rõ ràng qua `PopScope`), nhưng đây là hành vi Flutter khuyến nghị xử lý rõ ràng bằng `PopScope` (thay thế `WillPopScope` cũ) khi có tác vụ quan trọng đang chạy — dự án dùng Dart SDK `>=3.3.0` nên `PopScope` có sẵn. **Đã thêm**: `PopScope(canPop: !busy, onPopInvokedWithPop: ...)` bọc `Scaffold` trong cả `chapter_editor_screen.dart` (biến `busy` gộp sẵn 4 cờ `generating/fleshingOut/checking/rewriting`) và `document_screen.dart` (cờ mới `_processingDoc`) — chặn back trong lúc đang chạy, hiện rõ SnackBar giải thích + nút "Huỷ & thoát" để người dùng chủ động quyết định thay vì bị thoát âm thầm. **CHƯA build/test thật trên máy** — việc cần làm ở phiên sau: xác nhận vuốt back trong lúc đang chạy AI bị chặn đúng như mong đợi, không còn mất tiến độ.

57. **[TÍNH NĂNG MỚI, CHƯA build/test — 2026-07-31] Tìm kiếm web — bật/tắt THỦ CÔNG theo yêu cầu rõ ràng của người dùng ("không nhất thiết lúc nào cũng tìm kiếm mạng, khi nào cần thì mới bật").** Thêm `lib/services/web_search_service.dart` — gọi endpoint HTML rút gọn của DuckDuckGo (`html.duckduckgo.com/html/`, KHÔNG cần đăng ký API key), parse bằng package `html` (mới thêm vào `pubspec.yaml`) qua CSS selector cố định (`.result__body`, `.result__title`, `.result__snippet`) — có rủi ro DuckDuckGo đổi cấu trúc trang làm hỏng việc trích xuất, khi đó trả về danh sách rỗng và báo rõ cho người dùng thay vì crash/im lặng. Thêm nút bật/tắt (icon địa cầu) trong `chat_screen.dart` cạnh nút đính kèm tài liệu — mặc định TẮT, chỉ áp dụng cho phiên chat hiện tại (không lưu lại), khi bật hiện rõ giai đoạn "🔍 Đang tìm kiếm web..." trước khi tiếp tục sinh văn bản như bình thường. **Cân nhắc bảo mật/quyền hạn CHƯA xác nhận**: `AndroidManifest.xml` không nằm trong repo (được `flutter create` tự sinh trong `build.yml`), nên KHÔNG xác nhận được chắc chắn quyền `INTERNET` đã có sẵn hay chưa — suy luận hợp lý là CÓ (vì `AnthropicProvider`/`OpenAICompatibleProvider` đã dùng `http` package gọi mạng từ trước), nhưng cần xác nhận thật khi build/test lần đầu tính năng này. **Việc cần làm ở phiên sau**: build lại, bật thử tìm kiếm web trong chat, xác nhận có kết quả trả về thật (không lỗi mạng/quyền), và tinh chỉnh CSS selector nếu DuckDuckGo đã đổi cấu trúc HTML.

58. **[ĐÃ SỬA, CHƯA build/test — 2026-07-31] `build.yml` từng để các bước `cp` file QNN thất bại ÂM THẦM (`|| echo "THIẾU..."` không dừng build), có thể tạo ra APK "build thành công" nhưng thiếu hẳn file QNN mà không ai biết cho tới khi cài lên máy thật.** Dù QNN giờ không còn trên đường mặc định (mục 52), vẫn cần đúng cho `backendPreference=3` (thử nghiệm) hoạt động nếu người dùng chọn dùng. **Đã sửa**: mọi lệnh `cp` file QNN giờ DỪNG BUILD NGAY nếu thất bại (`|| { echo ...; exit 1; }`), và thêm bước xác minh CUỐI CÙNG ngay trên chính file APK (`unzip` thật, kiểm tra `lib/arm64-v8a/` có đủ 5 file QNN + `libmnn_bridge.so` không) trước khi upload artifact — không còn tin tưởng mù quáng vào "copy vào jniLibs xong là chắc chắn có trong APK".

59. **[SỬA XONG, ĐÃ XÁC NHẬN QUA LOG BUILD THẬT — 2026-07-31] Lỗi biên dịch Dart ở mục 56 (`PopScope`): dùng sai tên tham số `onPopInvokedWithPop` (không tồn tại — tự bịa nhầm tên).** Log build APK #67 báo lỗi rõ ràng ở cả 2 file `chapter_editor_screen.dart:642` và `document_screen.dart:234`: `Error: No named parameter with the name 'onPopInvokedWithPop'`. Tra cứu API `PopScope` thật của Flutter (bản pin trong CI là `stable-3.44.7`): tham số đúng là **`onPopInvokedWithResult`**, nhận `(bool didPop, Object? result)` — không phải `(bool didPop)` như đã viết nhầm. Lịch sử API: `onPopInvoked` (cũ, `(bool didPop)`) → deprecated từ Flutter 3.22 → thay bằng `onPopInvokedWithResult` (thêm tham số `result` kiểu generic). **Đã sửa** cả 2 chỗ dùng `onPopInvokedWithResult: (didPop, result) { ... }`. **Bài học**: khi dùng API Flutter có lịch sử đổi tên tham số qua nhiều phiên bản (như `PopScope`), phải tra cứu ĐÚNG PHIÊN BẢN Flutter đang pin trong `build.yml` (ở đây là `stable-3.44.7`) thay vì suy đoán tên tham số từ trí nhớ — nhất là khi có nhiều tên gần giống nhau dễ nhầm (`onPopInvoked`/`onPopInvokedWithResult`/tên bịa `onPopInvokedWithPop`).

61. **[SỬA XONG, CHƯA build/test — 2026-07-31] Cải tiến xử lý tài liệu dài (dịch/tóm tắt), theo 4 câu hỏi kiến trúc người dùng đặt ra — 3/4 điểm có lỗ hổng thật, đã sửa:**
    - **Thanh tiến trình**: trước chỉ có spinner tròn + chữ "d/t đoạn", giờ có `LinearProgressIndicator` hiện % thật.
    - **Chọn phạm vi đoạn**: trước LUÔN xử lý toàn bộ tài liệu, giờ có `RangeSlider` trong hộp thoại cấu hình (`_askProcessConfig`) cho chọn "từ đoạn __ đến đoạn __" — `processDocument()` nhận thêm `startIndex`/`endIndex` (0-based, dùng `sublist` trên danh sách đã `ORDER BY idx ASC` từ DB).
    - **Chạy nền khi tắt màn hình — LỖ HỔNG THẬT đã tìm ra và sửa**: `processDocument()` trước đây KHÔNG gọi `beginPipeline()`/`endPipeline()` (đã có sẵn từ trước, dùng cho `TranslationService`) — mỗi đoạn gọi `generate()` riêng lẻ tự bật/tắt Foreground Service ĐỘC LẬP (xem cơ chế ở mục 2.3 và `MnnBridge.kt`: `if (pipelineActive) updateStage else start`, rồi `if (!pipelineActive) stop` trong `finally`) — với tài liệu 100+ đoạn là 100+ lần bật/tắt liên tục, tạo khe hở giữa các đoạn có thể bị Android trừ tiến trình nếu tắt màn hình đúng lúc đó. **Đã sửa**: bọc cả vòng lặp nhiều đoạn bằng `LocalLlamaProvider.beginPipeline()`/`updatePipelineStage()`/`endPipeline()` (chỉ áp dụng khi `provider is LocalLlamaProvider` — cloud API không cần) — giữ 1 thông báo Foreground Service LIÊN TỤC suốt cả quá trình thay vì chớp tắt từng đoạn.
    - **Huỷ giữa chừng**: `resumeFromProgress` (mục 55) đã đảm bảo tiếp tục đúng chỗ dừng khi CHẠY LẠI, nhưng trước đây không có cách chủ động dừng SẠCH — chỉ có `PopScope` chặn back (mục 56). **Đã thêm**: nút "Huỷ" trong hộp thoại tiến trình, đặt cờ hợp tác (`isCancelled` callback) được `processDocument()` kiểm tra GIỮA MỖI đoạn (không ngắt dở đoạn đang chạy — không an toàn để huỷ nửa chừng 1 lệnh `generate()` đang gọi, chỉ có thể không bắt đầu đoạn kế tiếp).
    - **Xuất kết quả từng phần**: kiểm tra lại code — **đã hoạt động từ trước, không cần sửa**: `exportResult()` xử lý đoạn chưa có `resultText` bằng placeholder `[Chưa xử lý đoạn N]` thay vì chặn lại, nút "Xuất kết quả" trong UI luôn bật sẵn không phụ thuộc trạng thái xử lý.
    - **Việc cần làm ở phiên sau**: build/test thật cả 3 điểm đã sửa — đặc biệt xác nhận Foreground Service giữ được 1 thông báo liên tục (không chớp tắt) khi theo dõi qua thanh thông báo Android trong lúc xử lý tài liệu nhiều đoạn.

62. **[CRASH THẬT MỚI, KHÁC HẲN QNN, CHƯA CÓ CÁCH VÁ TRIỆT ĐỂ — 2026-08-01] SIGSEGV xảy ra ngay TRONG LÚC `nativeGenerate()` (không phải `nativeLoadModel()`) trên backend OpenCL (GPU) — xác nhận qua log thật kèm backtrace đầy đủ lần đầu tiên có symbol tên hàm rõ ràng của MNN.** Log cho thấy: model 1.5B (nhỏ hơn hẳn 7B, để loại trừ khả năng do model quá lớn) nạp OpenCL thành công, generate lần 1 (chat "alo", prompt ngắn) chạy xong không lỗi, nhưng generate lần 2 — **đúng lúc `DocumentService.processDocument()` dịch 1 đoạn tài liệu dài** (system prompt dịch thuật + đoạn văn gốc, tổng 3871 ký tự, dài hơn hẳn lần 1) — crash SIGSEGV tại địa chỉ `0x7031a8e000`. Backtrace (lần đầu có tên hàm rõ, không còn toàn "khong ro thieu symbol table" như các lần trước) cho thấy chuỗi gọi: `Java_..._nativeGenerate` → `Llm::response()` → `Llm::generate()` → `Llm::forwardVec()` → `Llm::forwardRaw()` → `MNN::Session::run()` → `MNN::ThreadPool::enqueue()` — tức là crash xảy ra **trên 1 luồng WORKER do MNN tự tạo ra để tính toán song song** (thấy rõ ở đáy backtrace: `art::Thread::CreateCallback` → `pthread_create`), không phải trên luồng chính gọi JNI. **Ý nghĩa quan trọng**: cơ chế cách ly tiến trình con (`fork()` + timeout, mục 53) CHỈ bọc bước `nativeLoadModel()` với QNN — KHÔNG bọc `nativeGenerate()` — nên loại crash này (xảy ra giữa lúc sinh văn bản, trên GPU/OpenCL — con đường vừa được xác nhận là "đường chính, đã tối ưu" ở mục 52/54) **hoàn toàn không được bảo vệ**, làm chết cả app ngay lập tức. **Nghi ngờ hàng đầu** (chưa xác nhận được, cần điều tra thêm nếu tái diễn): độ dài prompt lớn hơn hẳn (3871 ký tự so với 543 ký tự chạy được) có thể chạm vào 1 edge case về kích thước buffer/tensor trong `ThreadPool`/`Session::run()` của chính MNN — đây là lỗi NẰM TRONG chính thư viện MNN (`libMNN.so`), không phải trong code cầu nối (`libmnn_bridge.so`) của app, nên KHÔNG có cách vá trực tiếp từ phía app, chỉ có thể tránh/giảm thiểu.
    - **KHÔNG CÓ CÁCH cô lập crash loại này bằng kỹ thuật tương tự mục 53** (fork từng lần `generate()`) — vì phải fork() lại toàn bộ tiến trình cho MỖI LẦN sinh văn bản sẽ cực kỳ chậm (phải nạp lại model mỗi lần, mất hết lợi ích giữ model resident trong RAM), không khả thi cho việc dùng thực tế. Cách duy nhất triệt để là chuyển hẳn việc chạy MNN sang 1 **tiến trình Android riêng** (`android:process=":modelservice"` trong Manifest, giao tiếp qua AIDL/Binder) — 1 thay đổi kiến trúc lớn, CHƯA làm, cần cân nhắc kỹ ở phiên sau nếu loại crash này tái diễn thường xuyên.
    - **Đã làm ngay được (giảm thiệt hại, không phải sửa gốc)**: người dùng hỏi đúng trọng tâm "sao không có nút tiếp tục nhiệm vụ dang dở" — **thực ra ĐÃ CÓ SẴN** nhờ `resumeFromProgress` (mục 55/61: mỗi đoạn lưu `resultText` vào DB ngay khi xong, đoạn đang crash dở là đoạn DUY NHẤT mất, mọi đoạn trước đó vẫn giữ nguyên) — nhưng TRƯỚC ĐÂY không có gì hiển thị trên danh sách tài liệu để biết còn dở dang hay đã xong, dễ hiểu lầm phải bắt đầu lại từ đầu. **Đã sửa `document_screen.dart`**: `_load()` giờ đếm luôn số đoạn đã có `resultText` cho mỗi tài liệu (`_doneCounts`), danh sách hiện rõ nhãn "Dang dở: X/Y đoạn đã xong" hoặc dấu tick xanh nếu đã xong hết, và nút đổi nhãn động thành "Tiếp tục dịch (X/Y)"/"Tiếp tục tóm tắt (X/Y)" thay vì luôn ghi "Dịch toàn bộ"/"Tóm tắt" như chưa từng chạy. **CHƯA build/test thật.**

---

## 6. Danh sách yêu cầu người dùng — đã hoàn thành / chưa hoàn thành

### ✅ Đã hoàn thành và có trong source zip mới nhất

- [x] App viết truyện AI, đa truyện (multi-novel), Story Bible/RAG/timeline
- [x] Chat đa phiên, lưu bền vững, không mất khi đổi tab/model
- [x] Nhiều model local + nhiều API provider, không hardcode, đổi giữa chừng không mất bối cảnh
- [x] Không bộ lọc nội dung ở tầng app
- [x] Xuất chương (EPUB/DOCX/TXT), xuất chat (TXT/DOCX), xuất kết quả tài liệu
- [x] Đính kèm/dịch/tóm tắt tài liệu `.txt`/`.md` (Giai đoạn 1)
- [x] Văn phong + đắp thịt outline (không vi phạm bản quyền)
- [x] Tối ưu thiết bị: nhận diện chip, benchmark thật, RAG budget theo máy
- [x] Đổi engine AI local sang MNN-LLM + QNN, build qua GitHub Actions thành công (bao gồm tải QNN SDK, build native, biên dịch cầu nối JNI, và build Dart/Flutter)
- [x] Kiến trúc Platform Channel thay FFI (loại bỏ lỗi dlopen)
- [x] 2 slot model độc lập (multi-context) ở tầng native
- [x] Foreground Service + WakeLock chống bị Android kill khi chạy nền/qua đêm (wake lock trần 8 tiếng), gộp thành 1 pipeline cho luồng dịch tuần tự
- [x] Sửa UI model MNN (thư mục thay vì file `.gguf`), `FileBrowserScreen` hỗ trợ chọn thư mục VÀ chọn file (lọc theo đuôi file)
- [x] Tham số sinh văn bản — đã nối vào khung chat VÀ `chapter_editor_screen.dart`
- [x] Dịch thuật trung gian tuần tự — đã nối vào khung chat VÀ `chapter_editor_screen.dart`
- [x] In-line AI Rewrite (mục 4.9)
- [x] Notebook Colab convert model HuggingFace/ModelScope → định dạng MNN (`LocalNovel_Convert_Model_To_MNN.ipynb`, không nằm trong zip app — file riêng), đã convert thành công thật 1 model 7B, dùng được trên app
- [x] **QNN NPU XÁC NHẬN KÍCH HOẠT ĐƯỢC THẬT** trên Zenfone 8 (log debug thật: `loadModel TRẢ VỀ xong: {success: true, backend: qnn}`) — không còn là rủi ro treo nữa, xem mục 6 "Đã code nhưng CHƯA xác nhận" bên dưới đã bỏ mục này ra
- [x] Sửa lỗi nền tảng nghiêm trọng nhất từ trước tới giờ: `MainActivity.kt` thật bị copy sai đường dẫn package trong `build.yml` (mục 5.18) — mọi bản build từ #30-33 chưa từng thực sự chạy code native
- [x] Sửa nguyên nhân THẬT của crash native khi chat/đo tốc độ: R8/ProGuard đổi tên hàm JNI cần tới bằng tên chuỗi (mục 5.24) — đã thêm luật ProGuard `-keep`, kiểm tra/tự chèn `proguardFiles` vào `build.gradle`
- [x] Hạ tầng log chẩn đoán 3 tầng Dart/Kotlin/C++ ghi ra file xem được ngay trong app (mục 5.19-21), không cần ADB/máy tính
- [x] `backendPreference` (QNN tự động/ép GPU/ép CPU) cấu hình được từ UI, không cần build lại (mục 5.22)
- [x] Bọc toàn bộ `onMethodCall` trong try/catch — không còn nguy cơ 1 lỗi Kotlin bất kỳ làm crash cả app (mục 5.25)
- [x] Lỗi `@UiThread must be executed on the main thread` — đã sửa từ phiên trước (bọc `mainHandler.post{}`), nay mới được ghi lại vào tài liệu (mục 5.26)
- [x] Bug reload model mỗi lần chat (`currentProvider()` tạo instance mới mỗi lần gọi) — đã sửa bằng cache tĩnh trong `SettingsService` (mục 5.27)
- [x] **`llm->response()` sinh văn bản thật THÀNH CÔNG** (mục 5.28 → 5.40, đã đóng). Nguyên nhân cuối: backend QNN crash cứng (SIGSEGV) mọi lúc; OpenCL chạy được. App hiện dùng OpenCL khi ép buộc; cần đổi mặc định sang OpenCL (bỏ QNN khỏi đường thử đầu tiên) — xem việc cần làm ở mục 5.40. QNN để backlog tối ưu sau (mục 5.43).
- [ ] **`GenerationService` (Foreground Service/WakeLock) chưa từng khai báo trong Manifest — ĐANG SỬA, ưu tiên cao** (mục 5.42). Giải thích hiện tượng app "đóng băng" khi tắt màn hình lúc đang sinh văn bản, và số liệu `prefill_us` tăng bất thường qua các lần trong log. Đã thêm bước khai báo `<service>` + quyền vào `build.yml`, CHƯA build/test.
- [x] CI build ổn định trở lại sau lỗi `jni`/AGP 9 không tương thích (mục 5.30) — đã hạ AGP xuống 8.13.0 + Gradle 8.13 + Kotlin 2.1.20, build APK qua được nhiều lần liên tiếp.
- [x] **Xác nhận nguyên nhân gốc QNN không dùng được trên máy test — không phải lỗi code, mà do Hexagon v68 dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU (v73+)** (mục 5.52). Đã đổi mặc định sang GPU (OpenCL) đã tối ưu, QNN chuyển thành thử nghiệm bật thủ công (`backendPreference=3`), giữ nguyên cơ chế cách ly tiến trình con + timeout an toàn (mục 5.53) cho ai muốn thử trên máy chip mới hơn.
- [x] Tối ưu tốc độ GPU thật sự theo tài liệu MNN chính thức: `precision:low`, `memory:low`, `thread_num:68`, cache autotuning kernel (`tmp_path`) — mục 5.54.
- [x] Sửa bug FAB "Bách khoa" luôn mở sai form theo tab + sửa luôn bug màn hình trắng do chính phiên này gây ra khi vá lần 1 — mục 5.48/5.49.
- [x] Sửa 4 chỗ crash `setState() called after dispose()` trong `chapter_editor_screen.dart` khi thoát màn hình lúc AI đang chạy — mục 5.50.
- [x] Sửa bug hallucination Story Bible (model tự bịa nội dung khi Story Bible trống) — mục 5.51.
- [x] Thêm UI chỉnh prompt tóm tắt/dịch tài liệu + làm xử lý tài liệu tiếp tục được dở dang — mục 5.55.
- [x] Thêm `PopScope` chặn vuốt back Android 13+ giữa lúc AI đang chạy (chương/tài liệu) — mục 5.56, CHƯA build/test thật.
- [x] Tính năng mới: tìm kiếm web thủ công (bật/tắt theo phiên chat, không tự động) — mục 5.57, CHƯA build/test thật.
- [x] `build.yml` không còn để bước copy file QNN thất bại âm thầm — mục 5.58, CHƯA build/test thật.

### ⚠️ Đã code nhưng CHƯA xác nhận chạy đúng thật (rủi ro còn treo)

- [ ] `foregroundServiceType="dataSync"` có bị hệ thống từ chối lúc chạy không — vẫn chưa test riêng biệt, dù Foreground Service đã chạy được nhiều lần trong lúc debug crash (log cho thấy `GenerationService.start()` không hề ném lỗi) nên rủi ro này coi như đã giảm đáng kể, có thể hạ độ ưu tiên.
- [ ] **Bản sửa ProGuard/R8 (mục 5.24) — CHƯA build+test lần nào**. Đây là việc ưu tiên SỐ 1 tuyệt đối ngay phiên tiếp theo — nếu sửa đúng, tính năng chat/sinh văn bản với model local sẽ LẦN ĐẦU TIÊN hoạt động thật sự từ đầu dự án tới giờ.
- [ ] **TẤT CẢ 6 tính năng ở mục 4.10-4.15** (version snapshot, tìm kiếm, glossary/chống lặp từ, Story Bible nâng cao/auto-mention, EPUB bìa+mục lục, backup/restore) — vẫn CHƯA build/test lần nào kể từ khi viết (nhiều vòng build gần đây đều tập trung vá lỗi native/crash, chưa quay lại kiểm tra các tính năng Dart-only này).

### 🔧 Đã bắt đầu nhưng CHƯA hoàn thiện hết

*(không còn mục nào ở trạng thái này — 2 mục từng ở đây đã hoàn thành ở phiên trước)*

### ⬜ Yêu cầu đã nêu, CHƯA code

- [ ] Tóm tắt phân tầng đệ quy (tier 2: cụm chương, tier 3: bản đồ kịch bản toàn truyện) — cần cho truyện triệu chữ. **Cố tình chưa làm** — cần đọc `llm.hpp` thật trước để biết API quản lý KV cache đúng (mục 5.10), rủi ro kỹ thuật cao nhất trong các việc còn lại, không nên làm vội chung đợt với 6 tính năng khác.
- [ ] Scene bên trong Chapter + Corkboard kéo-thả — UI lớn, nhiều tương tác kéo-thả phức tạp, nên làm riêng 1 phiên để có không gian rà soát kỹ.
- [ ] TTS (đọc chương thành giọng nói) — cần thêm plugin native mới (chưa có trong `pubspec.yaml`), rủi ro build tương tự các lần đổi engine AI trước đây (mục 5.1-5.6) — cố tình hoãn, không thêm dependency mới khi chưa xác nhận build hiện tại ổn định.
- [ ] Đọc tài liệu PDF/DOCX/ảnh (Giai đoạn 2 của tính năng tài liệu) — cố tình hoãn từ trước, lý do tương tự TTS.
- [ ] Author's Note/Memory field tách riêng Story Bible, Canvas outline trực quan, tùy biến font/theme trình soạn thảo — chưa có yêu cầu cụ thể, độ ưu tiên thấp hơn các mục trên.
- [ ] Provider "GPU ngoài" (Colab/GPU thuê) + lớp ẩn danh hoá thực thể — xem chi tiết kiến trúc 5 lớp đã thống nhất ở mục 5.29. **Chủ động hoãn tới sau khi mục 5.28 (bug response rỗng) xong** — ưu tiên có model local chạy ổn định trước khi thêm phụ thuộc GPU ngoài.

### 🆕 Mới hoàn thành phiên này (mục 4.10-4.15 phía trên) — CHƯA build/test thật

- [x] Version snapshot (undo AI viết đè) — mục 4.10
- [x] Tìm kiếm toàn văn UI — mục 4.11
- [x] Glossary (bảng thuật ngữ) + thống kê chống lặp từ — mục 4.12
- [x] Story Bible nâng cao: phân loại thẻ chi tiết + auto-mention — mục 4.13
- [x] EPUB có bìa + mục lục nhấp được thật — mục 4.14
- [x] Backup/restore toàn bộ dữ liệu — mục 4.15

---

## 7. Việc cần làm ngay khi bắt đầu phiên mới

**Cập nhật (2026-07-31 — trạng thái mới nhất, phiên dài, nhiều thay đổi lớn)**:

**Quyết định chiến lược quan trọng nhất phiên này**: đã điều tra và xác nhận
QNN/NPU không khả thi trên máy test (Snapdragon 888/Hexagon v68 dưới mức
Qualcomm chính thức hỗ trợ v73+ cho LLM — mục 5.52) — **không phải lỗi
code có thể vá tiếp**. Đã đổi chiến lược: **GPU (OpenCL) là đường chính**,
tối ưu hết mức theo tài liệu MNN chính thức (mục 5.54); QNN lùi thành lựa
chọn thử nghiệm bật thủ công (`backendPreference=3`), giữ nguyên cơ chế an
toàn (cách ly tiến trình con + timeout, mục 5.53) cho tương lai nếu đổi
máy chip mới hơn.

Ngoài ra phiên này sửa thêm nhiều bug UI/UX thật do người dùng phát hiện
qua ảnh chụp màn hình: bug FAB "Bách khoa" sai form theo tab (mục 5.48) —
**và chính bản vá lần 1 của bug đó lại gây ra 1 bug MỚI nghiêm trọng hơn
(màn hình trắng xoá cả tab Bách khoa, mục 5.49)** — bài học: mọi sửa lỗi
liên quan tới `context`/`InheritedWidget` phải được kiểm tra rất kỹ, ưu
tiên cho `State` tự sở hữu `Controller` riêng thay vì `.of(context)` khi
còn nghi ngờ. Sửa crash `setState() after dispose()` (mục 5.50), sửa
hallucination Story Bible trống (mục 5.51), thêm `PopScope` chặn back
Android 13+ (mục 5.56), thêm tính năng mới tìm kiếm web thủ công (mục
5.57).

**TRẠNG THÁI BUILD/TEST THẬT**: các mục 5.48 (bản đã sửa lỗi ở 5.49),
5.50, 5.51, 5.52, 5.53, 5.54 đã được người dùng xác nhận qua log/ảnh chụp
màn hình thật trong chính phiên hội thoại này (không phải suy đoán). Mục
5.56 (`PopScope`) từng có lỗi biên dịch thật (build APK #67 fail, xem mục
5.59) — **đã sửa tên tham số đúng, nhưng CHƯA build lại lần nào sau khi
sửa**. Các mục **5.55, 5.56, 5.57, 5.58, 5.61 vẫn CHƯA build/test thành
công lần nào**. **Mục 5.62 (crash SIGSEGV THẬT trong lúc `nativeGenerate()`
trên OpenCL, khác hẳn QNN)** vừa phát hiện qua log 2026-08-01 — cải thiện
UI tiến độ/tiếp tục đã làm nhưng CHƯA build/test, còn NGUYÊN NHÂN GỐC crash
này (khả năng liên quan tới prompt dài trong `MNN::ThreadPool`/`Session::run()`)
**CHƯA có cách vá triệt để** — nếu tái diễn khi build lại, cần thu thập
thêm log để xác định pattern (có phải luôn liên quan tới prompt dài? luôn
xảy ra ở đoạn thứ mấy? có tái lập được không?).

1. **Việc cần làm ĐẦU TIÊN**: build lại qua GitHub Actions với zip source
   MỚI NHẤT (đã gộp toàn bộ mục 5.48-5.58). Cài đè, thử LẦN LƯỢT từng
   tính năng:
   - Mở tab "Bách khoa", chuyển qua lại cả 4 tab, xác nhận nút "+" mở
     đúng form theo tab, KHÔNG còn màn hình trắng xoá (mục 5.48/5.49).
   - Chat/viết tiếp chương, đo tốc độ GPU có nhanh hơn rõ rệt không so
     với trước (mục 5.54) — cả bước mở model (không còn chờ 90s QNN vô
     ích) lẫn tốc độ sinh token (precision/memory tối ưu).
   - Story Bible còn trống, thử hỏi chat — xác nhận model KHÔNG còn tự
     bịa nội dung (mục 5.51).
   - Đang tạo chương/dịch/tóm tắt, thử vuốt back — xác nhận bị chặn đúng
     kỳ vọng, không mất tiến độ (mục 5.56, CHƯA test thật).
   - Bật nút tìm kiếm web trong chat, hỏi 1 câu cần thông tin mới — xác
     nhận có tìm được kết quả thật, không lỗi quyền `INTERNET`/mạng (mục
     5.57, CHƯA test thật — nếu lỗi quyền, cần thêm bước khai báo
     `INTERNET` permission vào `build.yml` tương tự cách đã làm cho
     Foreground Service ở mục 5.42).
   - Thử dịch/tóm tắt 1 tài liệu dài, xác nhận có hộp thoại chỉnh prompt
     trước khi chạy (mục 5.55).
2. **Nếu build.yml fail ở bước copy QNN** (mục 5.58, giờ dừng cứng thay
   vì im lặng): đọc log lỗi cụ thể — đường dẫn thư mục thật trong QNN SDK
   Community có thể khác giả định `aarch64-android/`/`hexagon-v68/unsigned/`,
   cần đối chiếu lại (chỉ ảnh hưởng nếu người dùng bật thử
   `backendPreference=3`, không ảnh hưởng đường chính GPU).
3. **`GenerationService` chưa khai báo Manifest (mục 5.42) — vẫn CHƯA
   build/test riêng biệt**, dù đã chạy nhiều lần trong lúc debug các lỗi
   khác không thấy báo lỗi cụ thể liên quan — rủi ro đã giảm nhưng chưa
   xác nhận dứt điểm bằng phép thử riêng (tắt màn hình giữa lúc sinh văn
   bản dài, xem đồng hồ có dừng không).
4. **TẤT CẢ 6 tính năng ở mục 4.10-4.15** (version snapshot, tìm kiếm,
   glossary, Story Bible nâng cao, EPUB, backup/restore) — vẫn CHƯA
   build/test lần nào kể từ khi viết, nhiều phiên gần đây tập trung vá
   lỗi native/crash/UX, chưa quay lại kiểm tra các tính năng Dart-only
   này.
5. Sau khi các mục trên ổn định: **tóm tắt phân tầng đệ quy** (giá trị
   cao nhất cho truyện dài, nhưng CHỈ sau khi đọc được `llm.hpp` thật kỹ
   hơn nếu cần quản lý KV cache, mục 5.10) → provider "GPU ngoài" + ẩn
   danh hoá thực thể (mục 5.47, đã hoãn có chủ đích) → Scene/Corkboard/
   TTS/đọc PDF-DOCX-ảnh (vẫn hoãn, xem lý do ở mục 6).
6. **Bài học quy trình quan trọng nhất phiên này**: (a) khi build "thành
   công", KHÔNG được coi là đã xác nhận tính năng hoạt động — phải tự tay
   MỞ APP, THỬ TỪNG TÍNH NĂNG THẬT; (b) khi 1 giả thuyết kỹ thuật nghe rất
   hợp lý (vd "chip đủ mạnh nên NPU phải chạy được") vẫn PHẢI đối chiếu với
   tài liệu/yêu cầu tối thiểu CHÍNH THỨC của nhà sản xuất trước khi tiếp
   tục đầu tư công sức vá lỗi — mục 5.52 tiết kiệm được rất nhiều vòng
   debug vô ích nếu được tra cứu sớm hơn; (c) mọi bản vá liên quan tới
   `BuildContext`/`InheritedWidget` (`.of(context)`) phải tự kiểm tra kỹ
   context nào đang thực sự được dùng nằm ở đâu trong cây widget — 1 bản
   vá tưởng đơn giản (mục 5.48) đã tự gây ra 1 bug nghiêm trọng hơn (mục
   5.49) ngay trong cùng 1 phiên vì bỏ qua bước này.
