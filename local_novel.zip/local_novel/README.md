# LocalNovel

App Flutter hỗ trợ viết tiểu thuyết dài kỳ (1000+ chương) bằng AI, chạy
trên Android. Hỗ trợ cả AI chạy local trên máy (không cần mạng, không
lộ dữ liệu) lẫn API cloud (Anthropic/OpenAI-compatible tùy chọn), người
dùng tự chọn và đổi qua lại bất kỳ lúc nào.

## Trạng thái hiện tại (quan trọng, đọc trước khi build)

**Engine AI local đang trong giai đoạn chuyển đổi.** Toàn bộ code Dart
trong repo này vẫn dùng `llama_cpp_dart` (gói của `netdur`, gọi qua FFI,
không qua server/Termux). Tuy nhiên gói này do 1 cá nhân duy trì, từng
đổi API breaking nhiều lần, và **chưa xác nhận chạy được GPU/NPU thật
trên Android** — đây là lý do dự án đang thử nghiệm chuyển engine sang
**MNN-LLM (Alibaba) + QNN (Qualcomm NPU)**, vì tổ hợp này:

- Có sản phẩm thật đã public ("MNN Chat" trên Google Play) chứng minh
  chạy LLM + QNN NPU thật trên Snapdragon 8-series
- Có benchmark thật đánh bại llama.cpp trên Android (nhanh hơn 8.6x lúc
  đọc prompt, 2.3x lúc sinh chữ, đo trên CPU thuần, chưa tính NPU)
- Snapdragon 888 (Zenfone 8) nằm trong danh sách chip Hexagon được hỗ
  trợ (thế hệ V68)

Việc chuyển đổi đang ở bước đầu: xác nhận build native của MNN chạy
được trên GitHub Actions (xem file workflow riêng, không phải
`build.yml` chính). Sau khi xác nhận, sẽ viết cầu nối Kotlin (Platform
Channel, không phải FFI) để thay `lib/services/providers/local_provider.dart`.
**Cho tới khi hoàn tất, `local_provider.dart` hiện tại vẫn là bản đang
chạy**, không đảm bảo GPU/NPU hoạt động.

## Kiến trúc

```
lib/
  main.dart                     - Cổng vào: chọn/tạo truyện, điều hướng chính
  models/story_models.dart      - Toàn bộ model dữ liệu (Novel, Character, Chapter...)
  services/
    database_service.dart       - SQLite, đa truyện (mọi bảng có novel_id)
    settings_service.dart       - Provider AI đang chọn, model/API đang active, truyện đang active
    rag_service.dart            - Chọn lọc đúng phần Story Bible liên quan để đưa vào prompt
    embedding_service.dart      - Vector hóa văn bản cho truy xuất ngữ nghĩa
    style_service.dart          - Phân tích văn phong, "đắp thịt" outline
    summary_service.dart        - Tự tóm tắt chương sau khi lưu
    document_service.dart       - Dịch/tóm tắt tài liệu theo kiểu cuốn chiếu
    export_service.dart         - Xuất EPUB/DOCX/TXT cho chương VÀ cho cuộc trò chuyện chat
    device_profile_service.dart - Nhận diện chip, gợi ý cấu hình chạy model
    benchmark_service.dart      - Đo tốc độ sinh token thực tế, chặn số liệu vô lý
    providers/                  - AIProvider (local, Anthropic, OpenAI-compatible)
  screens/                      - Các màn hình UI tương ứng
```

## Tính năng theo từng truyện (đa truyện — mới thêm)

M��i truyện có Story Bible (nhân vật/luật/timeline), danh sách chương,
nhiều cửa sổ chat, và tài liệu đính kèm HOÀN TOÀN riêng biệt. Model AI
local/API provider dùng CHUNG cho mọi truyện (không phải tài nguyên nội
dung). Vào **Cài đặt → Đổi truyện** để chuyển hoặc tạo truyện mới.

M�y đã cài bản cũ (chỉ 1 truyện) khi cập nhật app sẽ tự động được gom
dữ liệu sẵn có vào 1 truyện mặc định "Truyện của tôi" — không mất dữ
liệu.

## Xuất bản

- **Chương**: EPUB / DOCX / TXT (nút xuất trong màn "Chương")
- **Cuộc trò chuyện chat**: TXT / DOCX (nút xuất trong AppBar màn "Trợ lý AI")
- **Kết quả dịch/tóm tắt tài liệu**: nút "Xuất kết quả" trong màn "Tài liệu"

Toàn bộ export tự dựng cấu trúc file, chạy offline hoàn toàn, không
dùng dịch vụ ngoài.

## Không có bộ lọc nội dung ở tầng app

App không tự thêm bất kỳ lớp kiểm duyệt/lọc từ khóa nào. Nếu dùng API
của một hãng, chính sách nội dung của hãng đó vẫn áp dụng phía máy chủ
của họ — đây là giới hạn nằm ngoài phạm vi app.

## Build APK (qua GitHub Actions, không cần máy tính)

Xem `.github/workflows/build.yml` trong repo GitHub — quy trình: upload
`local_novel.zip` (chính file này) → `flutter create` sinh khung Android
→ ghép code Dart vào → `flutter build apk --release`. Chi tiết từng
bước đã trao đổi trực tiếp qua lịch sử làm việc, không lặp lại ở đây.

## Giới hạn đã biết

- File model `.gguf` (1.5-5GB) không đóng gói sẵn trong APK — người
  dùng tự tải về máy một lần, sau đó dùng offline hoàn toàn
- Tài liệu đính kèm hiện chỉ hỗ trợ `.txt`/`.md` — PDF/DOCX/ảnh dự kiến
  làm sau khi nền tảng AI local ổn định
- RAG dùng vector "hashing" thuần Dart làm phương án dự phòng khi không
  có embedding model thật — đủ dùng, không tối ưu bằng embedding model
  chuyên dụng
