# Trường Thiên — app viết truyện dài kỳ có AI (1 APK duy nhất)

## Kiến trúc — quan trọng, đọc trước

Model AI local chạy **nhúng thẳng trong cùng tiến trình app** qua FFI (Dart gọi
thẳng hàm C++ của llama.cpp, được gói `fllama` biên dịch sẵn thành thư viện native
đóng gói trong APK). KHÔNG có server riêng, KHÔNG cần Termux, KHÔNG cần mở port.

Vì cùng tiến trình, mọi tham số suy luận (số luồng, context size, GPU layers) đổi
được **ngay lập tức** trong màn hình Tối ưu AI local — không có bước "khởi động lại
server" nào cả, khác hẳn bản thiết kế server-based ban đầu.

Điều app **không** đóng gói sẵn: file trọng số model (.gguf, thường 1.5-5GB tùy kích
thước model). Đây là giới hạn thực tế, không phải thiết kế: Play Store giới hạn kích
thước APK, và bó cứng một model cụ thể vào app sẽ mất luôn khả năng đổi model theo
máy. Người dùng tự tải file .gguf (trình duyệt, từ Hugging Face...) rồi chọn trong
Cài đặt bằng file picker — một lần, sau đó dùng offline hoàn toàn.

## Cấu trúc project
```
lib/
  models/
    story_models.dart          Nhân vật, luật thế giới, timeline, chương, văn phong
    device_profile.dart        Hồ sơ hiệu năng theo chipset (không hardcode 1 máy)
  services/
    database_service.dart      SQLite local: Story Bible, chương, FTS, embeddings
    ai_provider.dart            Interface chung cho mọi provider AI
    embedding_service.dart      Vector hashing offline cho RAG (fllama chưa có API embedding cấp cao)
    rag_service.dart            Lõi RAG: luật cứng + khớp từ khóa + truy xuất ngữ nghĩa
    style_service.dart          Phân tích văn phong từ mẫu văn + đắp thịt outline
    summary_service.dart        Tự tóm tắt chương sau khi lưu
    export_service.dart         Xuất EPUB / DOCX / TXT
    device_profile_service.dart Nhận diện chipset/RAM máy đang chạy
    benchmark_service.dart      Đo tốc độ sinh token thực tế
    settings_service.dart       Lưu provider + API key + tham số suy luận local
    providers/
      local_provider.dart       fllama - chạy model NHÚNG THẲNG qua FFI, không server
      anthropic_provider.dart   Gọi Anthropic API
      openai_compatible_provider.dart  OpenAI hoặc endpoint tương thích khác
  screens/
    chapters_screen.dart        Danh sách chương + xuất bản
    chapter_editor_screen.dart  Soạn chương, viết tiếp AI, đắp thịt outline, xem trước lorebook
    story_bible_screen.dart     Nhân vật / Luật thế giới / Văn phong
    chat_screen.dart            Trợ lý AI
    settings_screen.dart        Chọn provider + chọn file model (.gguf)
    local_optimization_screen.dart  Nhận diện máy, chỉnh & áp dụng tham số ngay lập tức, đo tốc độ
  main.dart
```

## Build APK
```
flutter pub get
flutter build apk --release
```
File APK: `build/app/outputs/flutter-apk/app-release.apk`

`flutter pub get` sẽ tự tải thư viện native của `fllama` — không cần tự build NDK/CMake
thủ công như cách làm llama.cpp truyền thống.

## Dùng AI local trên máy (Zenfone 8 hoặc bất kỳ máy Android nào)

1. Cài app từ APK đã build
2. Tải một file .gguf bằng trình duyệt (ví dụ từ Hugging Face — tìm model có sẵn
   bản GGUF, khuyến nghị Qwen2.5 3-4B hoặc Gemma 2-4B, mức quantize Q4_K_M cho máy
   tầm Snapdragon 888)
3. Vào **Cài đặt → AI local → Chọn file .gguf trên máy**, trỏ tới file vừa tải
4. Vào **Cài đặt → Tối ưu AI local cho máy này** — app tự nhận diện chipset (nhận
   đúng Snapdragon 888/8 Gen 1/2/3 qua mã `hardware` của Android, máy khác thì ước
   lượng theo RAM), điền sẵn số luồng/context/GPU layers khuyến nghị
5. Bấm **Áp dụng ngay** — có hiệu lực từ lần sinh văn bản tiếp theo, không cần khởi
   động lại app
6. Bấm **Đo tốc độ ngay** để xác nhận, chỉnh tay thêm nếu cần

## Giấy phép cần biết

`fllama` dùng giấy phép kép: miễn phí cho phần lớn trường hợp sử dụng, cần liên hệ
mua giấy phép thương mại nếu app đã ra mắt và tạo doanh thu lớn với fllama là thành
phần lõi. Xem chi tiết tại trang GitHub của package trước khi phát hành thương mại.

## Giới hạn còn lại

- RagService dùng vector "hashing" (bag-of-words offline) cho local, vì fllama hiện
  chưa expose API embedding cấp cao như llama-server độc lập từng có — vẫn hoạt động
  tốt cho khớp từ vựng, không sâu bằng embedding model thật
- Chưa test build APK thật trong môi trường này (không có Android SDK/mạng) — build
  trên máy có Flutter SDK cài đặt
- API chính xác của `fllama` (tên hàm, tham số) có thể lệch nhẹ so với phiên bản mới
  nhất trên pub.dev — kiểm tra lại `OpenAiRequest`/`fllamaChat` đúng version đã cài
  nếu gặp lỗi biên dịch

## Đổi model giữa chừng không mất bối cảnh (mới)

Hai lớp dữ liệu tách biệt hoàn toàn khỏi việc đang chọn model/provider nào:

- **Story Bible + chương** (nhân vật, luật, timeline, embedding) — luôn nằm trong
  SQLite, `RagService` đọc lại từ đây cho MỌI provider, không có khái niệm "gắn với
  model cụ thể"
- **Lịch sử chat** — trước đây chỉ lưu trong RAM (mất khi chuyển tab/đổi provider),
  giờ lưu bền vững vào bảng `chat_messages`. Đổi model ở Cài đặt xong quay lại khung
  chat, hội thoại vẫn còn nguyên, tin nhắn AI cũ hiển thị rõ do model nào trả lời
  (nhãn nhỏ dưới mỗi tin nhắn) để dễ so sánh chất lượng giữa các model
- `main.dart` chuyển sang `IndexedStack` thay vì tạo lại widget mỗi lần đổi tab —
  tránh mất trạng thái tạm (ô đang gõ dở...) ngoài ý muốn

Nút xóa lịch sử chat (icon thùng rác) chỉ xóa hội thoại, không đụng tới Story Bible
hay chương — hai việc hoàn toàn tách biệt theo đúng thiết kế.
