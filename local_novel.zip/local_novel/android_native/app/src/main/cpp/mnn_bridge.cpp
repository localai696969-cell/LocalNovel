// Cầu nối JNI giữa Kotlin (Android) và MNN-LLM engine.
//
// QUAN TRỌNG: file này gọi vào API CÔNG KHAI CHÍNH THỨC của MNN
// (transformers/llm/engine/include/llm/llm.hpp) — đây là header MNN
// thiết kế sẵn để bên thứ ba tích hợp, KHÔNG phải chép lại code nội bộ
// app "MNN Chat" của Alibaba.
//
// HỖ TRỢ 2 SLOT MODEL ĐỘC LẬP (multi-context thật sự, không giả):
//   slot 0 = model chính (viết truyện)
//   slot 1 = model dịch thuật trung gian (nhỏ, tùy chọn)
// Mỗi slot có Llm riêng, tồn tại độc lập trong RAM. Việc "giữ cả 2 slot
// cùng lúc" hay "xả slot không dùng để tiết kiệm RAM" là QUYẾT ĐỊNH của
// tầng Kotlin/Dart (tùy cấu hình máy), tầng native này chỉ cung cấp khả
// năng — không tự ý xả bất cứ slot nào nếu không được yêu cầu.
#include <jni.h>
#include <string>
#include <memory>
#include <sstream>
#include <fstream>
#include <android/log.h>
#include "llm/llm.hpp"

#define LOG_TAG "MnnBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Ghi trực tiếp ra file (KHÔNG qua logcat) — vì máy người dùng chưa có
// cách lấy logcat thật (cần máy tính + ADB). Flush + close ngay lập tức
// sau mỗi dòng để dữ liệu chắc chắn nằm trên đĩa thật, sống sót được qua
// crash native (SIGSEGV giết cả tiến trình ngay lập tức, không cho kịp
// đóng file bình thường — nhưng vì đã flush+close ngay từ trước đó, dữ
// liệu đã ghi rồi vẫn còn nguyên). Ghi ra đúng thư mục Download (app đã có
// quyền MANAGE_EXTERNAL_STORAGE, đã ghi được model vào đây nên chắc chắn
// ghi được log vào đây).
static void nativeLog(const std::string& msg) {
  std::ofstream f("/storage/emulated/0/Download/localnovel_native_debug.txt", std::ios::app);
  if (f.is_open()) {
    f << msg << "\n";
    f.flush();
    f.close();
  }
}

using namespace MNN::Transformer;

namespace {
constexpr int kMaxSlots = 2; // 0 = model chính, 1 = model dịch thuật
std::unique_ptr<Llm> g_slots[kMaxSlots];
// Ghi lại backend THẬT đã nạp thành công cho mỗi slot — trước đây
// nativeActiveBackend() luôn trả cứng "unknown", giờ trả đúng giá trị đã
// dùng (qnn/opencl/cpu), lấy từ chính nơi nativeLoadModel() xác nhận thành
// công, không đoán qua API nào khác.
std::string g_activeBackend[kMaxSlots] = {"unknown", "unknown"};

Llm* slotOrNull(int slot) {
  if (slot < 0 || slot >= kMaxSlots) return nullptr;
  return g_slots[slot].get();
}
}

extern "C" {

// Nạp model vào đúng slot chỉ định — slot kia (nếu đang có model) KHÔNG
// bị đụng tới, cho phép cả model chính và model dịch cùng tồn tại trong
// RAM nếu máy đủ khỏe (gọi loadModel cho cả 2 slot mà không unload slot
// nào ở giữa). Trả về true nếu nạp thành công.
// backendPreference: 0 = tự thử QNN trước (rơi về GPU/CPU nếu QNN không
// khởi tạo được), 1 = ép OpenCL (GPU), 2 = ép CPU. KHÔNG hardcode danh
// sách máy được phép dùng QNN — luôn thử trước, bắt lỗi rồi rơi xuống.
JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeLoadModel(
    JNIEnv* env, jobject /* this */, jint slot, jstring configPath, jint backendPreference) {
  if (slot < 0 || slot >= kMaxSlots) {
    LOGE("Slot khong hop le: %d", slot);
    return JNI_FALSE;
  }
  const char* pathChars = env->GetStringUTFChars(configPath, nullptr);
  std::string path(pathChars);
  env->ReleaseStringUTFChars(configPath, pathChars);

  auto& llmSlot = g_slots[slot];
  try {
    llmSlot.reset(Llm::createLLM(path));
    if (!llmSlot) {
      LOGE("createLLM tra ve null cho path: %s (slot %d)", path.c_str(), slot);
      return JNI_FALSE;
    }

    if (backendPreference == 0) {
      try {
        llmSlot->set_config(R"({"backend_type": "qnn"})");
        llmSlot->load();
        LOGI("Slot %d: nap model thanh cong voi backend QNN: %s", slot, path.c_str());
        g_activeBackend[slot] = "qnn";
        return JNI_TRUE;
      } catch (const std::exception& qnnErr) {
        LOGI("Slot %d: QNN khoi tao khong thanh cong (%s), roi ve OpenCL GPU", slot, qnnErr.what());
      }
      try {
        llmSlot->set_config(R"({"backend_type": "opencl"})");
        llmSlot->load();
        LOGI("Slot %d: nap model thanh cong voi backend OpenCL (GPU): %s", slot, path.c_str());
        g_activeBackend[slot] = "opencl";
        return JNI_TRUE;
      } catch (const std::exception& glErr) {
        LOGI("Slot %d: OpenCL khong thanh cong (%s), roi ve CPU", slot, glErr.what());
      }
      llmSlot->set_config(R"({"backend_type": "cpu"})");
      llmSlot->load();
      LOGI("Slot %d: nap model thanh cong voi backend CPU: %s", slot, path.c_str());
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    } else if (backendPreference == 1) {
      llmSlot->set_config(R"({"backend_type": "opencl"})");
      llmSlot->load();
      g_activeBackend[slot] = "opencl";
      return JNI_TRUE;
    } else {
      llmSlot->set_config(R"({"backend_type": "cpu"})");
      llmSlot->load();
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    }
  } catch (const std::exception& e) {
    LOGE("Loi nap model slot %d: %s", slot, e.what());
    llmSlot.reset();
    return JNI_FALSE;
  }
}

// Sinh văn bản từ đúng slot chỉ định, gọi callback Kotlin cho mỗi lần có
// kết quả (hiện tại MNN trả nguyên khối, không phải từng token rời).
// generationConfigJson: JSON temperature/top_p/top_k/repetition_penalty/
// max_new_tokens — áp dụng lại trước mỗi lần sinh, không cần nạp lại model.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeGenerate(
    JNIEnv* env, jobject /* this */, jint slot, jstring prompt, jstring generationConfigJson, jobject callback) {
  nativeLog("nativeGenerate: BAT DAU, slot=" + std::to_string(slot));
  Llm* llm = slotOrNull(slot);
  if (!llm) {
    LOGE("nativeGenerate goi khi slot %d chua nap model", slot);
    nativeLog("nativeGenerate: LOI slot chua nap model, dung lai");
    return;
  }
  nativeLog("nativeGenerate: da lay duoc Llm* cho slot, dang doc prompt string...");
  const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
  std::string promptStr(promptChars);
  env->ReleaseStringUTFChars(prompt, promptChars);
  nativeLog("nativeGenerate: da doc prompt xong, do dai=" + std::to_string(promptStr.size()));

  const char* configChars = env->GetStringUTFChars(generationConfigJson, nullptr);
  std::string configStr(configChars);
  env->ReleaseStringUTFChars(generationConfigJson, configChars);
  nativeLog("nativeGenerate: da doc config xong: " + configStr);

  jclass callbackClass = env->GetObjectClass(callback);
  jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;Z)V");
  if (onTokenMethod == nullptr) {
    // GetMethodID that bai KHONG nem C++ exception — no la loi Java
    // (pending exception trong JNIEnv). Neu tiep tuc goi CallVoidMethod
    // voi methodID rong se undefined behavior / crash ngay. Kiem tra + xoa
    // pending exception + dung lai o day thay vi crash mo ho.
    nativeLog("nativeGenerate: LOI NGHIEM TRONG — GetMethodID tra ve NULL cho onToken, khong tim thay dung chu ky ham. Dung lai truoc khi crash.");
    LOGE("Slot %d: GetMethodID cho onToken tra ve NULL", slot);
    if (env->ExceptionCheck()) {
      env->ExceptionClear();
    }
    return;
  }
  nativeLog("nativeGenerate: da lay duoc onTokenMethod (khong null), chuan bi set_config...");

  try {
    llm->set_config(configStr);
    nativeLog("nativeGenerate: set_config xong, khong loi");
  } catch (const std::exception& e) {
    LOGE("Slot %d: khong ap dung duoc cau hinh sinh van ban (dung mac dinh): %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: set_config NEM LOI (van tiep tuc voi mac dinh): ") + e.what());
  }

  std::ostringstream fullOutput;
  try {
    // QUAN TRỌNG: KHÔNG truyền 0 cho max_new_tokens (tham số cuối) — từng
    // gây crash native (SIGSEGV, không phải exception C++ nên try/catch
    // không bắt được) ở CẢ 3 backend (QNN/OpenCL/CPU) như nhau, xác nhận
    // qua log debug thật trên máy — cho thấy lỗi nằm ở chính điểm gọi này,
    // không phải riêng backend nào. Tài liệu MNN chính thức chỉ gọi
    // response(prompt) dùng giá trị mặc định, không ai truyền 0. Dùng -1
    // để không ép giới hạn ở đây — max_new_tokens thật đã được set qua
    // set_config(configStr) ngay phía trên rồi (kênh chính thức, đúng theo
    // tài liệu MNN — xem generationConfigJson gửi từ Kotlin).
    // CẬP NHẬT: đã thử -1, vẫn crash y hệt — giả thuyết max_new_tokens=0
    // đã bị loại. Giữ nguyên -1 (không tệ hơn so với 0), thêm log chi tiết
    // xung quanh để tìm đúng dòng crash thật.
    nativeLog("nativeGenerate: CHUAN BI goi llm->response() — day la nghi pham chinh neu khong thay dong log sau day");
    llm->response(promptStr, &fullOutput, nullptr, -1);
    nativeLog("nativeGenerate: llm->response() TRA VE XONG, khong crash — do dai ket qua=" + std::to_string(fullOutput.str().size()));

    jstring jToken = env->NewStringUTF(fullOutput.str().c_str());
    nativeLog("nativeGenerate: da tao jstring ket qua, chuan bi goi CallVoidMethod...");
    env->CallVoidMethod(callback, onTokenMethod, jToken, JNI_TRUE);
    nativeLog("nativeGenerate: CallVoidMethod xong, khong crash");
    env->DeleteLocalRef(jToken);
  } catch (const std::exception& e) {
    LOGE("Slot %d: loi sinh van ban: %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: response() NEM std::exception (C++ bat duoc): ") + e.what());
    jstring jError = env->NewStringUTF((std::string("[Loi] ") + e.what()).c_str());
    env->CallVoidMethod(callback, onTokenMethod, jError, JNI_TRUE);
    env->DeleteLocalRef(jError);
  }
  nativeLog("nativeGenerate: KET THUC HAM, khong crash");
}

// Xả đúng 1 slot — KHÔNG đụng tới slot còn lại. Gọi khi máy yếu, cần
// giải phóng RAM ngay sau khi dùng xong 1 model (ví dụ xả model dịch
// sau khi dịch xong, trước khi nạp model chính).
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeUnload(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return;
  g_slots[slot].reset();
  g_activeBackend[slot] = "unknown";
}

JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeIsLoaded(JNIEnv* env, jobject /* this */, jint slot) {
  return slotOrNull(slot) != nullptr ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeActiveBackend(JNIEnv* env, jobject /* this */, jint slot) {
  // Trả về backend THẬT đã nạp thành công (ghi lại trong nativeLoadModel),
  // không còn hardcode "unknown" như trước.
  if (slot < 0 || slot >= kMaxSlots) return env->NewStringUTF("slot_khong_hop_le");
  std::string backend = slotOrNull(slot) ? g_activeBackend[slot] : "chua_nap_model";
  return env->NewStringUTF(backend.c_str());
}

} // extern "C"
