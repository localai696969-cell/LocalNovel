// Cầu nối JNI giữa Kotlin (Android) và MNN-LLM engine.
//
// QUAN TRỌNG: file này gọi vào API CÔNG KHAI CHÍNH THỨC của MNN
// (transformers/llm/engine/include/llm/llm.hpp) — đây là header MNN
// thiết kế sẵn để bên thứ ba tích hợp, KHÔNG phải chép lại code nội bộ
// app "MNN Chat" của Alibaba (code đó gắn chặt với UI/database riêng
// của họ, không phải API ổn định để tái sử dụng).
//
// Tên hàm/tham số dưới đây dựa trên mô tả tài liệu công khai + cách
// dùng phổ biến của MNN-LLM (đúng khớp llm_demo.cpp mẫu chính thức:
// tạo Llm qua createLLM(config_path), gọi load(), rồi response(prompt,
// callback)). CHƯA build thử trên máy thật — bước build CI sẽ in ra
// nguyên văn llm.hpp thật ngay trước khi biên dịch file này, nên nếu
// tên hàm/tham số sai, log sẽ chỉ thẳng đúng chỗ cần sửa, không cần
// đoán lại từ đầu.
#include <jni.h>
#include <string>
#include <memory>
#include <sstream>
#include <android/log.h>
#include "llm/llm.hpp"

#define LOG_TAG "MnnBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using namespace MNN::Transformer;

namespace {
// Giữ đúng 1 phiên làm việc (session) tại một thời điểm — app chỉ chat
// với 1 model active cùng lúc, khớp thiết kế hiện tại của LocalNovel.
std::unique_ptr<Llm> g_llm;
}

extern "C" {

// Nạp model từ đường dẫn thư mục MNN export (chứa llm_config.json,
// llm.mnn, llm.mnn.weight...). Trả về true nếu nạp thành công.
// backendPreference: 0 = tự thử QNN trước (rơi về GPU/CPU nếu QNN
// không khởi tạo được trên máy này), 1 = ép dùng OpenCL (GPU thuần,
// bỏ qua QNN), 2 = ép CPU thuần (chỉ dùng khi cần chẩn đoán lỗi).
// KHÔNG hardcode danh sách máy được phép dùng QNN — luôn thử trước,
// bắt lỗi và rơi về backend thấp hơn nếu khởi tạo thất bại.
JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeLoadModel(
    JNIEnv* env, jobject /* this */, jstring configPath, jint backendPreference) {
  const char* pathChars = env->GetStringUTFChars(configPath, nullptr);
  std::string path(pathChars);
  env->ReleaseStringUTFChars(configPath, pathChars);

  try {
    g_llm.reset(Llm::createLLM(path));
    if (!g_llm) {
      LOGE("createLLM tra ve null cho path: %s", path.c_str());
      return JNI_FALSE;
    }

    if (backendPreference == 0) {
      // Thử QNN trước — không kiểm tra whitelist chip, chỉ thử và bắt lỗi.
      try {
        g_llm->set_config(R"({"backend_type": "qnn"})");
        g_llm->load();
        LOGI("Nap model thanh cong voi backend QNN: %s", path.c_str());
        return JNI_TRUE;
      } catch (const std::exception& qnnErr) {
        LOGI("QNN khoi tao khong thanh cong (%s), roi ve OpenCL GPU", qnnErr.what());
      }
      try {
        g_llm->set_config(R"({"backend_type": "opencl"})");
        g_llm->load();
        LOGI("Nap model thanh cong voi backend OpenCL (GPU): %s", path.c_str());
        return JNI_TRUE;
      } catch (const std::exception& glErr) {
        LOGI("OpenCL khong thanh cong (%s), roi ve CPU", glErr.what());
      }
      g_llm->set_config(R"({"backend_type": "cpu"})");
      g_llm->load();
      LOGI("Nap model thanh cong voi backend CPU (cham nhat, nhung luon chay duoc): %s", path.c_str());
      return JNI_TRUE;
    } else if (backendPreference == 1) {
      g_llm->set_config(R"({"backend_type": "opencl"})");
    } else {
      g_llm->set_config(R"({"backend_type": "cpu"})");
    }
    g_llm->load();
    return JNI_TRUE;
  } catch (const std::exception& e) {
    LOGE("Loi nap model: %s", e.what());
    g_llm.reset();
    return JNI_FALSE;
  }
}

// Sinh văn bản, gọi callback Kotlin cho mỗi token mới sinh ra (streaming).
// callback: đối tượng Kotlin có method `onToken(String token, boolean done)`.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeGenerate(
    JNIEnv* env, jobject /* this */, jstring prompt, jobject callback) {
  if (!g_llm) {
    LOGE("nativeGenerate goi khi chua nap model");
    return;
  }
  const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
  std::string promptStr(promptChars);
  env->ReleaseStringUTFChars(prompt, promptChars);

  jclass callbackClass = env->GetObjectClass(callback);
  jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;Z)V");

  std::ostringstream fullOutput;
  try {
    g_llm->response(promptStr, &fullOutput, nullptr, 0);
    jstring jToken = env->NewStringUTF(fullOutput.str().c_str());
    env->CallVoidMethod(callback, onTokenMethod, jToken, JNI_TRUE);
    env->DeleteLocalRef(jToken);
  } catch (const std::exception& e) {
    LOGE("Loi sinh van ban: %s", e.what());
    jstring jError = env->NewStringUTF((std::string("[Loi] ") + e.what()).c_str());
    env->CallVoidMethod(callback, onTokenMethod, jError, JNI_TRUE);
    env->DeleteLocalRef(jError);
  }
}

JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeUnload(JNIEnv* env, jobject /* this */) {
  g_llm.reset();
}

JNIEXPORT jstring JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeActiveBackend(JNIEnv* env, jobject /* this */) {
  // Trả về tên backend thật đang chạy (để hiển thị cho người dùng biết
  // đang chạy CPU/GPU/NPU thật, không phải đoán) — cần xác nhận đúng
  // cách lấy thông tin này từ Llm sau khi build CI in ra llm.hpp thật.
  std::string backend = g_llm ? "unknown" : "chua_nap_model";
  return env->NewStringUTF(backend.c_str());
}

} // extern "C"
