// Cầu nối JNI giữa Kotlin (Android) và MNN-LLM engine.
//
// QUAN TRỌNG: file này gọi vào API CÔNG KHAI CHÍNH THỨC của MNN
// (transformers/llm/engine/include/llm/llm.hpp) — đây là header MNN
// thiết kế sẵn để bên thứ ba tích hợp, KHÔNG phải chép lại code nội bộ
// app "MNN Chat" của Alibaba.
//
// HỖ TRỢ 2 SLOT MODEL ĐỘC LẬP (multi-context thật sự, không giả):
//   slot 0 = model chính (viết truyện)
//   slot 1 = model dịch thuật trung gian (nhỏ, tùy chọn)
// Mỗi slot có Llm riêng, tồn tại độc lập trong RAM. Việc "giữ cả 2 slot
// cùng lúc" hay "xả slot không dùng để tiết kiệm RAM" là QUYẾT ĐỊNH của
// tầng Kotlin/Dart (tùy cấu hình máy), tầng native này chỉ cung cấp khả
// năng — không tự ý xả bất cứ slot nào nếu không được yêu cầu.
#include <jni.h>
#include <string>
#include <memory>
#include <sstream>
#include <fstream>
#include <chrono>
#include <algorithm>
#include <android/log.h>
#include "llm/llm.hpp"

#define LOG_TAG "MnnBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Ghi trực tiếp ra file (KHÔNG qua logcat) — vì máy người dùng chưa có
// cách lấy logcat thật (cần máy tính + ADB). Flush + close ngay lập tức
// sau mỗi dòng để dữ liệu chắc chắn nằm trên đĩa thật, sống sót được qua
// crash native (SIGSEGV giết cả tiến trình ngay lập tức, không cho kịp
// đóng file bình thường — nhưng vì đã flush+close ngay từ trước đó, dữ
// liệu đã ghi rồi vẫn còn nguyên).
//
// QUAN TRỌNG: ghi vào thư mục RIÊNG của app (Kotlin truyền xuống qua
// nativeSetLogDir(), gọi 1 lần lúc khởi động) — KHÔNG ghi thẳng vào
// /storage/emulated/0/Download/ như bản trước nữa, vì cần quyền
// MANAGE_EXTERNAL_STORAGE được CẤP THẬT qua Cài đặt hệ thống (không tự có
// chỉ vì khai báo trong Manifest) — rất có thể đây là lý do file log
// trước đó không hề được tạo ra. Thư mục riêng của app thì luôn ghi được,
// không cần xin quyền gì.
static std::string g_logDir = "";

static void nativeLog(const std::string& msg) {
  if (g_logDir.empty()) return; // Chưa nhận được đường dẫn từ Kotlin, bỏ qua thay vì đoán đường dẫn khác.
  std::ofstream f(g_logDir + "/native_debug.txt", std::ios::app);
  if (f.is_open()) {
    f << msg << "\n";
    f.flush();
    f.close();
  }
}

using namespace MNN::Transformer;

namespace {
constexpr int kMaxSlots = 2; // 0 = model chính, 1 = model dịch thuật
std::unique_ptr<Llm> g_slots[kMaxSlots];
// Ghi lại backend THẬT đã nạp thành công cho mỗi slot — trước đây
// nativeActiveBackend() luôn trả cứng "unknown", giờ trả đúng giá trị đã
// dùng (qnn/opencl/cpu), lấy từ chính nơi nativeLoadModel() xác nhận thành
// công, không đoán qua API nào khác.
std::string g_activeBackend[kMaxSlots] = {"unknown", "unknown"};

Llm* slotOrNull(int slot) {
  if (slot < 0 || slot >= kMaxSlots) return nullptr;
  return g_slots[slot].get();
}
}

extern "C" {

// Nhận đường dẫn thư mục ghi log (thư mục riêng của app, Kotlin truyền
// xuống qua appContext.filesDir) — gọi 1 lần lúc khởi động, TRƯỚC khi các
// hàm khác có thể ghi log được. Nếu không gọi hàm này, nativeLog() sẽ tự
// bỏ qua (không ghi được) thay vì đoán bừa 1 đường dẫn khác.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeSetLogDir(
    JNIEnv* env, jobject /* this */, jstring dir) {
  const char* dirChars = env->GetStringUTFChars(dir, nullptr);
  g_logDir = std::string(dirChars);
  env->ReleaseStringUTFChars(dir, dirChars);
  nativeLog("nativeSetLogDir: da nhan duong dan log: " + g_logDir);
}

// Nạp model vào đúng slot chỉ định — slot kia (nếu đang có model) KHÔNG
// bị đụng tới, cho phép cả model chính và model dịch cùng tồn tại trong
// RAM nếu máy đủ khỏe (gọi loadModel cho cả 2 slot mà không unload slot
// nào ở giữa). Trả về true nếu nạp thành công.
// backendPreference: 0 = tự thử QNN trước (rơi về GPU/CPU nếu QNN không
// khởi tạo được), 1 = ép OpenCL (GPU), 2 = ép CPU. KHÔNG hardcode danh
// sách máy được phép dùng QNN — luôn thử trước, bắt lỗi rồi rơi xuống.
JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeLoadModel(
    JNIEnv* env, jobject /* this */, jint slot, jstring configPath, jint backendPreference) {
  if (slot < 0 || slot >= kMaxSlots) {
    LOGE("Slot khong hop le: %d", slot);
    return JNI_FALSE;
  }
  const char* pathChars = env->GetStringUTFChars(configPath, nullptr);
  std::string path(pathChars);
  env->ReleaseStringUTFChars(configPath, pathChars);

  auto& llmSlot = g_slots[slot];
  try {
    llmSlot.reset(Llm::createLLM(path));
    if (!llmSlot) {
      LOGE("createLLM tra ve null cho path: %s (slot %d)", path.c_str(), slot);
      return JNI_FALSE;
    }

    if (backendPreference == 0) {
      try {
        llmSlot->set_config(R"({"backend_type": "qnn"})");
        llmSlot->load();
        LOGI("Slot %d: nap model thanh cong voi backend QNN: %s", slot, path.c_str());
        g_activeBackend[slot] = "qnn";
        return JNI_TRUE;
      } catch (const std::exception& qnnErr) {
        LOGI("Slot %d: QNN khoi tao khong thanh cong (%s), roi ve OpenCL GPU", slot, qnnErr.what());
      }
      try {
        llmSlot->set_config(R"({"backend_type": "opencl"})");
        llmSlot->load();
        LOGI("Slot %d: nap model thanh cong voi backend OpenCL (GPU): %s", slot, path.c_str());
        g_activeBackend[slot] = "opencl";
        return JNI_TRUE;
      } catch (const std::exception& glErr) {
        LOGI("Slot %d: OpenCL khong thanh cong (%s), roi ve CPU", slot, glErr.what());
      }
      llmSlot->set_config(R"({"backend_type": "cpu"})");
      llmSlot->load();
      LOGI("Slot %d: nap model thanh cong voi backend CPU: %s", slot, path.c_str());
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    } else if (backendPreference == 1) {
      llmSlot->set_config(R"({"backend_type": "opencl"})");
      llmSlot->load();
      g_activeBackend[slot] = "opencl";
      return JNI_TRUE;
    } else {
      llmSlot->set_config(R"({"backend_type": "cpu"})");
      llmSlot->load();
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    }
  } catch (const std::exception& e) {
    LOGE("Loi nap model slot %d: %s", slot, e.what());
    llmSlot.reset();
    return JNI_FALSE;
  }
}

// Sinh văn bản từ đúng slot chỉ định, gọi callback Kotlin cho mỗi lần có
// kết quả (hiện tại MNN trả nguyên khối, không phải từng token rời).
// generationConfigJson: JSON temperature/top_p/top_k/repetition_penalty/
// max_new_tokens — áp dụng lại trước mỗi lần sinh, không cần nạp lại model.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeGenerate(
    JNIEnv* env, jobject /* this */, jint slot, jstring prompt, jstring generationConfigJson, jobject callback) {
  nativeLog("nativeGenerate: BAT DAU, slot=" + std::to_string(slot));
  Llm* llm = slotOrNull(slot);
  if (!llm) {
    LOGE("nativeGenerate goi khi slot %d chua nap model", slot);
    nativeLog("nativeGenerate: LOI slot chua nap model, dung lai");
    return;
  }
  nativeLog("nativeGenerate: da lay duoc Llm* cho slot, dang doc prompt string...");
  const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
  std::string promptStr(promptChars);
  env->ReleaseStringUTFChars(prompt, promptChars);
  nativeLog("nativeGenerate: da doc prompt xong, do dai=" + std::to_string(promptStr.size()));
  // CHAN DOAN THEM (2026-07-27): in ra 120 ky tu dau + 120 ky tu cuoi cua
  // prompt that (thay \n bang | de khong vo dinh dang dong log) — de kiem
  // tra xem prompt gui xuong native co dung dinh dang mong doi khong (vd co
  // bi rong/cat cut/lech chat template khong), thay vi chi biet do dai.
  {
    std::string preview = promptStr;
    std::replace(preview.begin(), preview.end(), '\n', '|');
    std::string head = preview.substr(0, std::min<size_t>(120, preview.size()));
    std::string tail = preview.size() > 120
        ? preview.substr(preview.size() - std::min<size_t>(120, preview.size()))
        : std::string("(prompt ngan hon 120 ky tu, khong co tail rieng)");
    nativeLog("nativeGenerate: PROMPT DAU: [" + head + "]");
    nativeLog("nativeGenerate: PROMPT CUOI: [" + tail + "]");
  }

  const char* configChars = env->GetStringUTFChars(generationConfigJson, nullptr);
  std::string configStr(configChars);
  env->ReleaseStringUTFChars(generationConfigJson, configChars);
  nativeLog("nativeGenerate: da doc config xong: " + configStr);

  jclass callbackClass = env->GetObjectClass(callback);
  jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;Z)V");
  if (onTokenMethod == nullptr) {
    // GetMethodID that bai KHONG nem C++ exception — no la loi Java
    // (pending exception trong JNIEnv). Neu tiep tuc goi CallVoidMethod
    // voi methodID rong se undefined behavior / crash ngay. Kiem tra + xoa
    // pending exception + dung lai o day thay vi crash mo ho.
    if (env->ExceptionCheck()) {
      env->ExceptionClear();
    }
    // CHUAN DOAN: lay ten lop THAT cua callback luc runtime — dung
    // java/lang/Class (lop chuan JDK, KHONG bi R8/ProGuard doi ten dai
    // dien cho app) de biet chinh xac R8 co doi ten "onToken" hay khong,
    // thay vi doan mo.
    std::string realClassName = "(khong lay duoc)";
    jclass classClass = env->FindClass("java/lang/Class");
    if (classClass != nullptr) {
      jmethodID getNameMethod = env->GetMethodID(classClass, "getName", "()Ljava/lang/String;");
      if (getNameMethod != nullptr) {
        auto jName = (jstring)env->CallObjectMethod(callbackClass, getNameMethod);
        if (jName != nullptr) {
          const char* nameChars = env->GetStringUTFChars(jName, nullptr);
          realClassName = std::string(nameChars);
          env->ReleaseStringUTFChars(jName, nameChars);
          env->DeleteLocalRef(jName);
        }
      }
      env->DeleteLocalRef(classClass);
    }
    nativeLog("nativeGenerate: LOI NGHIEM TRONG — GetMethodID tra ve NULL cho onToken. Ten lop THAT cua callback luc runtime: " + realClassName + " — neu ten nay la ky tu la/ngan (vd 'a', 'b'...) thi xac nhan bi R8/ProGuard doi ten. Dung lai truoc khi crash.");
    LOGE("Slot %d: GetMethodID cho onToken tra ve NULL, class that: %s", slot, realClassName.c_str());
    return;
  }
  nativeLog("nativeGenerate: da lay duoc onTokenMethod (khong null), chuan bi set_config...");

  try {
    // CHAN DOAN THEM (2026-07-28): header that (llm.hpp) xac nhan
    // set_config() TRA VE bool (thanh cong/that bai), nhung code truoc day
    // BO QUA hoan toan gia tri nay — neu JSON sai ten khoa MNN can, ham co
    // the tra ve false ma khong nem exception, code van log "khong loi" nhu
    // khong co chuyen gi. Kiem tra + log ro rang ngay tai day.
    bool configOk = llm->set_config(configStr);
    nativeLog(std::string("nativeGenerate: set_config KET QUA THAT (bool tra ve) = ") + (configOk ? "true (thanh cong)" : "FALSE (that bai — MNN khong chap nhan JSON nay, co the sai ten khoa)"));
  } catch (const std::exception& e) {
    LOGE("Slot %d: khong ap dung duoc cau hinh sinh van ban (dung mac dinh): %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: set_config NEM LOI (van tiep tuc voi mac dinh): ") + e.what());
  }

  std::ostringstream fullOutput;
  try {
    // QUAN TRỌNG: KHÔNG truyền 0 cho max_new_tokens (tham số cuối) — từng
    // gây crash native (SIGSEGV, không phải exception C++ nên try/catch
    // không bắt được) ở CẢ 3 backend (QNN/OpenCL/CPU) như nhau, xác nhận
    // qua log debug thật trên máy — cho thấy lỗi nằm ở chính điểm gọi này,
    // không phải riêng backend nào. Tài liệu MNN chính thức chỉ gọi
    // response(prompt) dùng giá trị mặc định, không ai truyền 0. Dùng -1
    // để không ép giới hạn ở đây — max_new_tokens thật đã được set qua
    // set_config(configStr) ngay phía trên rồi (kênh chính thức, đúng theo
    // tài liệu MNN — xem generationConfigJson gửi từ Kotlin).
    // CẬP NHẬT: đã thử -1, vẫn crash y hệt — giả thuyết max_new_tokens=0
    // đã bị loại. Giữ nguyên -1 (không tệ hơn so với 0), thêm log chi tiết
    // xung quanh để tìm đúng dòng crash thật.
    nativeLog("nativeGenerate: CHUAN BI goi llm->response() — day la nghi pham chinh neu khong thay dong log sau day");
    // CHAN DOAN THEM (2026-07-27): do thoi gian THAT bang chrono, khong suy
    // doan qua timestamp cua tang Kotlin nua (tang do co do phan giai ms va
    // bi anh huong boi thoi gian dispatch coroutine). Neu so ms in ra o day
    // van gan 0 trong khi may that co the decode ~16-17 token/giay (theo
    // benchmark that trong tai lieu kien truc), thi xac nhan chac chan
    // response() KHONG chay forward-pass thuc su nao — dung lai o dieu kien
    // dung (EOS) ngay tu dau, khong phai do may cham.
    auto t_start = std::chrono::steady_clock::now();
    llm->response(promptStr, &fullOutput, nullptr, -1);
    auto t_end = std::chrono::steady_clock::now();
    long long elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(t_end - t_start).count();
    nativeLog("nativeGenerate: llm->response() TRA VE XONG, khong crash — do dai ket qua=" +
        std::to_string(fullOutput.str().size()) + ", THOI GIAN THAT (ms)=" + std::to_string(elapsedMs));
    // CHAN DOAN THEM (2026-07-28): doc thang LlmContext THAT tu header MNN
    // (llm.hpp, class Llm::getContext()) — day la noi MNN tu ghi lai CHINH
    // XAC ly do dung sinh van ban (enum LlmStatus), khong con phai doan qua
    // thoi gian chay nua. Neu status khong phai NORMAL_FINISHED (1) hay
    // MAX_TOKENS_FINISHED (2), day la bang chung truc tiep co loi noi bo.
    // prompt_len=0 nghia la tokenizer khong ma hoa duoc prompt thanh token
    // nao ca (loi tu dau, truoc ca luc sinh).
    {
      const auto* ctx = llm->getContext();
      if (ctx != nullptr) {
        nativeLog("nativeGenerate: LlmContext THAT — status=" + std::to_string(static_cast<int>(ctx->status)) +
            " (NOT_LOADED=-1,RUNNING=0,NORMAL_FINISHED=1,MAX_TOKENS_FINISHED=2,USER_CANCEL=3,INTERNAL_ERROR=4,TIMEOUT=5)" +
            ", prompt_len=" + std::to_string(ctx->prompt_len) +
            ", gen_seq_len=" + std::to_string(ctx->gen_seq_len) +
            ", all_seq_len=" + std::to_string(ctx->all_seq_len) +
            ", prefill_us=" + std::to_string(ctx->prefill_us) +
            ", decode_us=" + std::to_string(ctx->decode_us));
      } else {
        nativeLog("nativeGenerate: CANH BAO — getContext() tra ve null, khong doc duoc LlmContext that.");
      }
    }
    if (fullOutput.str().empty()) {
      nativeLog("nativeGenerate: CANH BAO — ket qua RONG. Neu THOI GIAN THAT o tren duoi ~50ms, gan\n"
                "        nhu chac chan model dung o dieu kien EOS/stop ngay token dau tien, KHONG\n"
                "        phai loi may cham hay backend — nghi ngo hang dau: tokenizer/EOS id/chat\n"
                "        template cua ban convert model nay (xem lai tokenizer_config.json va\n"
                "        generation_config.json cua model nguon truoc khi convert MNN).");
    }

    jstring jToken = env->NewStringUTF(fullOutput.str().c_str());
    nativeLog("nativeGenerate: da tao jstring ket qua, chuan bi goi CallVoidMethod...");
    env->CallVoidMethod(callback, onTokenMethod, jToken, JNI_TRUE);
    nativeLog("nativeGenerate: CallVoidMethod xong, khong crash");
    env->DeleteLocalRef(jToken);
  } catch (const std::exception& e) {
    LOGE("Slot %d: loi sinh van ban: %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: response() NEM std::exception (C++ bat duoc): ") + e.what());
    jstring jError = env->NewStringUTF((std::string("[Loi] ") + e.what()).c_str());
    env->CallVoidMethod(callback, onTokenMethod, jError, JNI_TRUE);
    env->DeleteLocalRef(jError);
  }
  nativeLog("nativeGenerate: KET THUC HAM, khong crash");
}

// Xả đúng 1 slot — KHÔNG đụng tới slot còn lại. Gọi khi máy yếu, cần
// giải phóng RAM ngay sau khi dùng xong 1 model (ví dụ xả model dịch
// sau khi dịch xong, trước khi nạp model chính).
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeUnload(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return;
  g_slots[slot].reset();
  g_activeBackend[slot] = "unknown";
}

JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeIsLoaded(JNIEnv* env, jobject /* this */, jint slot) {
  return slotOrNull(slot) != nullptr ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeActiveBackend(JNIEnv* env, jobject /* this */, jint slot) {
  // Trả về backend THẬT đã nạp thành công (ghi lại trong nativeLoadModel),
  // không còn hardcode "unknown" như trước.
  if (slot < 0 || slot >= kMaxSlots) return env->NewStringUTF("slot_khong_hop_le");
  std::string backend = slotOrNull(slot) ? g_activeBackend[slot] : "chua_nap_model";
  return env->NewStringUTF(backend.c_str());
}

} // extern "C"
