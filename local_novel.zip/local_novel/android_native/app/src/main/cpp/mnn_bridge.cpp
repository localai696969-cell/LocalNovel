// Cầu nối JNI giữa Kotlin (Android) và MNN-LLM engine.
//
// QUAN TRỌNG: file này gọi vào API CÔNG KHAI CHÍNH THỨC của MNN
// (transformers/llm/engine/include/llm/llm.hpp) — đây là header MNN
// thiết kế sẵn để bên thứ ba tích hợp, KHÔNG phải chép lại code nội bộ
// app "MNN Chat" của Alibaba.
//
// HỖ TRỢ 2 SLOT MODEL ĐỘC LẬP (multi-context thật sự, không giả):
//   slot 0 = model chính (viết truyện)
//   slot 1 = model dịch thuật trung gian (nhỏ, tùy chọn)
// Mỗi slot có Llm riêng, tồn tại độc lập trong RAM. Việc "giữ cả 2 slot
// cùng lúc" hay "xả slot không dùng để tiết kiệm RAM" là QUYẾT ĐỊNH của
// tầng Kotlin/Dart (tùy cấu hình máy), tầng native này chỉ cung cấp khả
// năng — không tự ý xả bất cứ slot nào nếu không được yêu cầu.
#include <jni.h>
#include <string>
#include <memory>
#include <sstream>
#include <fstream>
#include <chrono>
#include <algorithm>
#include <dirent.h>
#include <atomic>
#include <csignal>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <android/log.h>
#include "llm/llm.hpp"

#define LOG_TAG "MnnBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Ghi trực tiếp ra file (KHÔNG qua logcat) — vì máy người dùng chưa có
// cách lấy logcat thật (cần máy tính + ADB). Flush + close ngay lập tức
// sau mỗi dòng để dữ liệu chắc chắn nằm trên đĩa thật, sống sót được qua
// crash native (SIGSEGV giết cả tiến trình ngay lập tức, không cho kịp
// đóng file bình thường — nhưng vì đã flush+close ngay từ trước đó, dữ
// liệu đã ghi rồi vẫn còn nguyên).
//
// QUAN TRỌNG: ghi vào thư mục RIÊNG của app (Kotlin truyền xuống qua
// nativeSetLogDir(), gọi 1 lần lúc khởi động) — KHÔNG ghi thẳng vào
// /storage/emulated/0/Download/ như bản trước nữa, vì cần quyền
// MANAGE_EXTERNAL_STORAGE được CẤP THẬT qua Cài đặt hệ thống (không tự có
// chỉ vì khai báo trong Manifest) — rất có thể đây là lý do file log
// trước đó không hề được tạo ra. Thư mục riêng của app thì luôn ghi được,
// không cần xin quyền gì.
static std::string g_logDir = "";

// THEM (2026-07-29): bo bat crash (signal handler) tu viet — vi tinh nang
// "Bao cao loi" (bug report) cua Android khong hoat dong on dinh tren may
// nguoi dung (bam vao khong thay gi xay ra), can chu dong tu bat crash
// ngay trong app, khong phu thuoc cong cu he thong nua.
//
// QUAN TRONG VE AN TOAN: ben trong 1 signal handler that (chay ngay khi
// tien trinh sap chet vi SIGSEGV/SIGABRT...), KHONG duoc dung std::string,
// std::ofstream, hay bat ky thu gi co cap phat bo nho (malloc) — vi crash
// co the xay ra dung luc dang giu lock cap phat bo nho, goi malloc lai se
// treo vinh vien (deadlock) thay vi ghi duoc log. Vi vay ham nay CHI dung
// syscall tho (open/write/close) va bo dem tinh (static char buffer), an
// toan hon nhieu trong ngu canh signal handler.
static char g_logDirBufForSignal[512] = {0};

// NANG CAP (2026-07-30): signal() thuong chi cho biet SO HIEU tin hieu
// (SIGSEGV...), khong biet duoc DIA CHI bo nho gay loi hay NGAN XEP goi ham
// luc do — khong du de biet loi nam o dau BEN TRONG libMNN.so. Chuyen sang
// sigaction() voi co SA_SIGINFO: nhan them tham so `siginfo_t* info`, co
// truong `si_addr` = dia chi bo nho THAT gay ra SIGSEGV/SIGBUS. Dia chi nay
// rat co gia tri chan doan: gan 0x0 (vd duoi 0x1000) hau nhu chac chan la
// loi "null pointer" (goi ham qua 1 con tro rong) — mot dang loi rat pho
// bien va DE SUA neu biet dung; dia chi lon/bat thuong (vd gan
// 0xffffffff...) thuong la loi doc/ghi qua con tro da bi huy/sai kieu.
//
// Them ca 1 backtrace THO (dia chi cac ham dang goi long nhau) bang
// <unwind.h> cua chinh Android NDK (khong can them thu vien ngoai nao) —
// dia chi nay so voi dia chi nan (base address) cua libMNN.so co the doi
// chieu duoc sau nay bang addr2line/ndk-stack de biet dung ten ham that,
// neu can dieu tra sau hon.
#include <unwind.h>
#include <dlfcn.h>

namespace {
struct BacktraceState {
  void** current;
  void** end;
};

_Unwind_Reason_Code unwindCallback(struct _Unwind_Context* context, void* arg) {
  auto* state = static_cast<BacktraceState*>(arg);
  if (state->current == state->end) return _URC_END_OF_STACK;
  void* ip = reinterpret_cast<void*>(_Unwind_GetIP(context));
  if (ip != nullptr) {
    *state->current++ = ip;
  }
  return _URC_NO_REASON;
}
}

static void crashSignalHandler(int sig, siginfo_t* info, void* /*ucontext*/) {
  const char* sigName = "KHONG_RO";
  switch (sig) {
    case SIGSEGV: sigName = "SIGSEGV (truy cap bo nho khong hop le)"; break;
    case SIGABRT: sigName = "SIGABRT (chuong trinh tu goi abort, thuong do assert/exception khong bat duoc)"; break;
    case SIGBUS:  sigName = "SIGBUS (loi truy cap bo nho o muc phan cung/alignment)"; break;
    case SIGILL:  sigName = "SIGILL (lenh CPU khong hop le)"; break;
    case SIGFPE:  sigName = "SIGFPE (loi so hoc, vd chia cho 0)"; break;
    default: break;
  }
  if (g_logDirBufForSignal[0] != '\0') {
    char path[600];
    snprintf(path, sizeof(path), "%s/native_debug.txt", g_logDirBufForSignal);
    int fd = open(path, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd >= 0) {
      char msg[384];
      int n = snprintf(msg, sizeof(msg),
          "\n!!! CRASH THAT BAT DUOC (signal handler tu viet) — signal=%d: %s, dia_chi_loi(si_addr)=%p !!!\n",
          sig, sigName, info != nullptr ? info->si_addr : nullptr);
      if (n > 0) write(fd, msg, static_cast<size_t>(n));

      // Backtrace tho — toi da 32 tang goi ham, in ra dia chi tho (chua co
      // ten ham, can doi chieu addr2line/ndk-stack sau neu muon dich nguoc
      // ra ten ham/dong code that).
      void* addrs[32];
      BacktraceState state{addrs, addrs + 32};
      _Unwind_Backtrace(unwindCallback, &state);
      int depth = static_cast<int>(state.current - addrs);
      const char* header = "    Backtrace tho (dia chi, chua co ten ham):\n";
      write(fd, header, strlen(header));
      for (int i = 0; i < depth; ++i) {
        Dl_info dlInfo;
        char line[320];
        int lineLen;
        if (dladdr(addrs[i], &dlInfo) && dlInfo.dli_fname != nullptr) {
          // dli_sname (ten ham) co the null neu thu vien khong co symbol
          // table — van in duoc ten FILE .so + offset, du de doi chieu.
          uintptr_t offset = reinterpret_cast<uintptr_t>(addrs[i]) -
              reinterpret_cast<uintptr_t>(dlInfo.dli_fbase);
          lineLen = snprintf(line, sizeof(line), "      #%d %p  %s + 0x%lx  (ham: %s)\n",
              i, addrs[i], dlInfo.dli_fname, static_cast<unsigned long>(offset),
              dlInfo.dli_sname != nullptr ? dlInfo.dli_sname : "(khong ro, thieu symbol table)");
        } else {
          lineLen = snprintf(line, sizeof(line), "      #%d %p  (khong xac dinh duoc thu vien)\n", i, addrs[i]);
        }
        if (lineLen > 0) write(fd, line, static_cast<size_t>(lineLen));
      }
      close(fd);
    }
  }
  // Tra ve hanh vi mac dinh cua he dieu hanh (thuong la tao tombstone/crash
  // report chuan cua Android) sau khi da tu ghi log rieng cua minh xong.
  signal(sig, SIG_DFL);
  raise(sig);
}

static void installCrashSignalHandlerOnce() {
  static bool installed = false;
  if (installed) return;
  installed = true;
  struct sigaction sa;
  memset(&sa, 0, sizeof(sa));
  sa.sa_sigaction = crashSignalHandler;
  sa.sa_flags = SA_SIGINFO;
  sigaction(SIGSEGV, &sa, nullptr);
  sigaction(SIGABRT, &sa, nullptr);
  sigaction(SIGBUS, &sa, nullptr);
  sigaction(SIGILL, &sa, nullptr);
  sigaction(SIGFPE, &sa, nullptr);
}

static void nativeLog(const std::string& msg) {
  if (g_logDir.empty()) return; // Chưa nhận được đường dẫn từ Kotlin, bỏ qua thay vì đoán đường dẫn khác.
  std::ofstream f(g_logDir + "/native_debug.txt", std::ios::app);
  if (f.is_open()) {
    f << msg << "\n";
    f.flush();
    f.close();
  }
}

using namespace MNN::Transformer;

namespace {
// SUA LOI (2026-07-28): preview.substr(0, N) truoc day cat theo BYTE, khong
// phai theo KY TU — tieng Viet co dau dung UTF-8 nhieu byte cho 1 ky tu, neu
// diem cat roi giua 1 ky tu nhieu byte se tao ra chuoi byte KHONG HOP LE.
// Dart doc file log bang UTF-8 (File.readAsString() mac dinh) gap doan byte
// hong nay se nem FileSystemException, hong CA FILE LOG chu khong chi 1
// dong — day la nguyen nhan may lan truoc doc log bi loi "Failed to decode
// data using encoding 'utf-8'". Ham nay lui lai (khong tien toi) cho toi khi
// gap dung byte "dau" cua 1 ky tu UTF-8 (byte dau tien cua 1 ky tu KHONG co
// dang 10xxxxxx — continuation byte), dam bao khong bao gio cat giua chung.
std::string utf8SafeHead(const std::string& s, size_t maxBytes) {
  if (s.size() <= maxBytes) return s;
  size_t cut = maxBytes;
  while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80) {
    --cut; // dang la continuation byte, lui lai 1 byte
  }
  return s.substr(0, cut);
}
std::string utf8SafeTail(const std::string& s, size_t maxBytes) {
  if (s.size() <= maxBytes) return s;
  size_t start = s.size() - maxBytes;
  while (start < s.size() && (static_cast<unsigned char>(s[start]) & 0xC0) == 0x80) {
    ++start; // dang la continuation byte, tien toi 1 byte de bat dau dung tai dau 1 ky tu
  }
  return s.substr(start);
}
}

namespace {
// THEM (2026-07-30): SUA LOI "phai doi sinh xong het moi hien chu" — nguoi
// dung phat hien dung: cac app chat khac hien tung chu ngay khi sinh, con
// app nay doi het roi moi hien 1 lan. Nguyen nhan: `llm->response()` truoc
// day duoc goi voi 1 std::ostringstream THUONG — chi gom chu vao bo nho,
// khong day ra ngoai. Trong khi MNN, moi lan sinh xong 1 token, NO CO GHI
// (operator<<) vao dung doi tuong ostream duoc truyen vao ngay luc do — chi
// la code truoc gio khong "nghe" duoc thoi diem do de day qua JNI ngay.
//
// Lop nay ke thua std::streambuf, chan dung diem MNN ghi chu vao (ham
// xsputn/overflow) — moi lan MNN ghi 1 doan, goi JNI CallVoidMethod NGAY
// LAP TUC voi JNI_FALSE (bao "chua xong"), thay vi doi den cuoi cung moi
// gui 1 lan voi JNI_TRUE nhu truoc.
class JniStreamingBuf : public std::streambuf {
public:
  JniStreamingBuf(JNIEnv* env, jobject callback, jmethodID method)
      : env_(env), callback_(callback), method_(method) {}

  const std::string& accumulated() const { return accumulated_; }

protected:
  std::streamsize xsputn(const char* s, std::streamsize n) override {
    if (n > 0) {
      accumulated_.append(s, static_cast<size_t>(n));
      std::string chunk(s, static_cast<size_t>(n));
      jstring jChunk = env_->NewStringUTF(chunk.c_str());
      env_->CallVoidMethod(callback_, method_, jChunk, JNI_FALSE);
      env_->DeleteLocalRef(jChunk); // XOA ngay — goi lien tuc trong vong lap
                                    // sinh token, khong xoa se day tran bang
                                    // local reference cua JNI (mac dinh
                                    // ~512 O) sau vai tram token.
    }
    return n;
  }

  int overflow(int c) override {
    if (c != EOF) {
      char ch = static_cast<char>(c);
      xsputn(&ch, 1);
    }
    return c;
  }

private:
  JNIEnv* env_;
  jobject callback_;
  jmethodID method_;
  std::string accumulated_;
};
}

namespace {
// RAII don gian: tu dong tra loadingInProgress[slot] ve false khi ra khoi
// scope, bat ke ham nativeLoadModel thoat qua return nao (JNI_TRUE hay
// JNI_FALSE, hay qua exception) — tranh phai tu tay reset o tung cho return.
struct LoadingGuard {
  int slotIdx;
  std::atomic<bool>* flags;
  LoadingGuard(int s, std::atomic<bool>* f) : slotIdx(s), flags(f) {}
  ~LoadingGuard() { flags[slotIdx].store(false); }
};
}

namespace {
constexpr int kMaxSlots = 2; // 0 = model chính, 1 = model dịch thuật
std::unique_ptr<Llm> g_slots[kMaxSlots];
// CHAN DOAN + CHOT CHAN THEM (2026-07-29): phat hien qua log that — nguoi
// dung bam gui tin 3 lan lien tiep trong 20 giay trong khi lan nap model
// dau tien co the dang thuc su ban ron (nap weight ~vai GB + build do thi
// NPU that su lau, khac han truoc day khi doc nham file rong nen tra ve
// tuc thi). Neu 2-3 lenh nativeLoadModel cho CUNG 1 slot chay chong len
// nhau, co the gay tranh chap tai nguyen GPU/NPU that su treo may, chu
// khong phai bug moi. Chan hang cuoc goi thu 2 tro di cho cung 1 slot neu
// lenh truoc do van dang chay.
std::atomic<bool> g_loadingInProgress[kMaxSlots] = {false, false};
// Ghi lại backend THẬT đã nạp thành công cho mỗi slot — trước đây
// nativeActiveBackend() luôn trả cứng "unknown", giờ trả đúng giá trị đã
// dùng (qnn/opencl/cpu), lấy từ chính nơi nativeLoadModel() xác nhận thành
// công, không đoán qua API nào khác.
std::string g_activeBackend[kMaxSlots] = {"unknown", "unknown"};

Llm* slotOrNull(int slot) {
  if (slot < 0 || slot >= kMaxSlots) return nullptr;
  return g_slots[slot].get();
}
}

extern "C" {

// Nhận đường dẫn thư mục ghi log (thư mục riêng của app, Kotlin truyền
// xuống qua appContext.filesDir) — gọi 1 lần lúc khởi động, TRƯỚC khi các
// hàm khác có thể ghi log được. Nếu không gọi hàm này, nativeLog() sẽ tự
// bỏ qua (không ghi được) thay vì đoán bừa 1 đường dẫn khác.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeSetLogDir(
    JNIEnv* env, jobject /* this */, jstring dir) {
  const char* dirChars = env->GetStringUTFChars(dir, nullptr);
  g_logDir = std::string(dirChars);
  env->ReleaseStringUTFChars(dir, dirChars);
  // Sao chep sang buffer tinh (khong dung std::string) de signal handler
  // doc duoc an toan — xem giai thich chi tiet o khai bao crashSignalHandler.
  strncpy(g_logDirBufForSignal, g_logDir.c_str(), sizeof(g_logDirBufForSignal) - 1);
  installCrashSignalHandlerOnce();
  nativeLog("nativeSetLogDir: da nhan duong dan log: " + g_logDir + " (da cai bo bat crash tu viet)");
}

// Nạp model vào đúng slot chỉ định — slot kia (nếu đang có model) KHÔNG
// bị đụng tới, cho phép cả model chính và model dịch cùng tồn tại trong
// RAM nếu máy đủ khỏe (gọi loadModel cho cả 2 slot mà không unload slot
// nào ở giữa). Trả về true nếu nạp thành công.
// backendPreference: 0 = tự thử QNN trước (rơi về GPU/CPU nếu QNN không
// khởi tạo được), 1 = ép OpenCL (GPU), 2 = ép CPU. KHÔNG hardcode danh
// sách máy được phép dùng QNN — luôn thử trước, bắt lỗi rồi rơi xuống.
JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeLoadModel(
    JNIEnv* env, jobject /* this */, jint slot, jstring configPath, jint backendPreference) {
  if (slot < 0 || slot >= kMaxSlots) {
    LOGE("Slot khong hop le: %d", slot);
    return JNI_FALSE;
  }
  // CHOT CHAN (2026-07-29): tu choi lenh nap model thu 2 tro di neu lenh
  // truoc do cho CUNG slot nay van dang chay — xem giai thich chi tiet o
  // khai bao g_loadingInProgress phia tren.
  bool expected = false;
  if (!g_loadingInProgress[slot].compare_exchange_strong(expected, true)) {
    nativeLog("nativeLoadModel: BI TU CHOI — da co 1 lenh nap model khac cho slot " +
        std::to_string(slot) + " dang chay chua xong. Doi lenh truoc hoan tat, dung bam lien tuc.");
    LOGE("nativeLoadModel: slot %d dang co lenh nap khac chay, tu choi lenh nay de tranh tranh chap tai nguyen.", slot);
    return JNI_FALSE;
  }
  LoadingGuard loadingGuard(slot, g_loadingInProgress);

  const char* pathChars = env->GetStringUTFChars(configPath, nullptr);
  std::string rawPath(pathChars);
  env->ReleaseStringUTFChars(configPath, pathChars);

  // SUA LOI QUAN TRONG (2026-07-28): header that (llm.hpp) dat ten tham so
  // la "config_path" (duong dan toi 1 FILE cau hinh), nhung tang Dart/Kotlin
  // tu truoc gio truyen thang duong dan THU MUC model (vd
  // ".../Orion-zhen-...-chinh") vao thang createLLM() — khong phai file.
  // File cau hinh THAT do notebook convert sinh ra ten la "llm_config.json"
  // (xac nhan qua chinh buoc kiem tra file bat buoc trong
  // LocalNovel_Convert_Model_To_MNN.ipynb). Neu createLLM co gang doc 1 thu
  // muc nhu the la file JSON, co the khong nem loi C++ (tuy thu vien) nhung
  // cau hinh se rong/mac dinh hoan toan — khop chinh xac voi moi trieu
  // chung da thay (khong crash, LlmContext khong bao gio duoc dung toi,
  // giong het nhau o moi model/moi backend). Tu dong do tim dung file that
  // ben trong thu muc, uu tien "llm_config.json" (ten notebook nay dung),
  // roi toi "config.json" (quy uoc MNN cu hon, phong khi model tu nguon
  // khac), chi dung nguyen path goc neu chinh no da la 1 file .json roi.
  std::string path = rawPath;
  auto endsWithJson = [](const std::string& s) {
    return s.size() >= 5 && s.compare(s.size() - 5, 5, ".json") == 0;
  };
  auto fileExists = [](const std::string& p) {
    std::ifstream f(p);
    return f.good();
  };
  // SUA LAI LAN 2 (2026-07-29) — QUAN TRONG, DAO NGUOC THU TU UU TIEN:
  // tai lieu chinh thuc MNN (transformers/README.md) xac nhan RO RANG:
  // "config.json" MOI la file truyen thang vao createLLM()/llm_demo (moi
  // vi du dong lenh chinh thuc deu dung "model_dir/config.json"), con
  // "llm_config.json" chi la file duoc CHINH config.json TU THAM CHIEU toi
  // ben trong (qua field "llm_config"), khong phai diem vao truc tiep. Ban
  // sua truoc (muc 33) uu tien nham llm_config.json truoc — sai thu tu so
  // voi quy uoc that cua MNN. Sua lai: uu tien "config.json" truoc.
  auto candidate1 = rawPath + "/config.json";
  auto candidate2 = rawPath + "/llm_config.json";
  if (!endsWithJson(path)) {
    if (fileExists(candidate1)) {
      path = candidate1;
    } else if (fileExists(candidate2)) {
      path = candidate2;
    } else {
      // CHAN DOAN THEM (2026-07-29): thay vi chi bao "khong tim thay", liet
      // ke THAT toan bo file dang co trong thu muc do tren may — day la
      // bang chung truc tiep, khong con phai doan xem file that su ten gi/
      // co ton tai khong nua.
      std::string listing;
      DIR* dir = opendir(rawPath.c_str());
      if (dir != nullptr) {
        struct dirent* entry;
        int count = 0;
        while ((entry = readdir(dir)) != nullptr) {
          std::string name(entry->d_name);
          if (name == "." || name == "..") continue;
          listing += name + " | ";
          ++count;
        }
        closedir(dir);
        if (count == 0) {
          listing = "(thu muc TON TAI nhung RONG, khong co file nao ben trong)";
        }
      } else {
        listing = "(KHONG MO DUOC thu muc nay bang opendir — co the sai duong dan, hoac app khong co quyen doc thu muc nay)";
      }
      nativeLog("nativeLoadModel: CANH BAO — modelPath la thu muc (" + rawPath +
          ") nhung KHONG tim thay llm_config.json lan config.json ben trong. "
          "Van thu goi createLLM voi duong dan thu muc goc (nhieu kha nang se that bai/rong).");
      nativeLog("nativeLoadModel: DANH SACH FILE THAT co trong thu muc do: " + listing);
    }
  }
  nativeLog("nativeLoadModel: duong dan config THAT dung de goi createLLM: " + path);

  auto& llmSlot = g_slots[slot];
  try {
    // CHAN DOAN THEM (2026-07-29): tach rieng moc log TRUOC va SAU createLLM
    // — voi config.json THAT (tham chieu day du toi weight/tokenizer that,
    // khac voi lan truoc dung nham llm_config.json chay rong tuc thi), buoc
    // nay co the that su ton thoi gian (parse JSON long nhau, mo tokenizer,
    // kiem tra file weight ~4GB) — can biet ro dang ket o day hay o load().
    nativeLog("nativeLoadModel: CHUAN BI goi Llm::createLLM() — neu khong thay dong sau day, dang ket ngay trong createLLM (rat co the do parse JSON hoac mo file weight/tokenizer that lau)");
    llmSlot.reset(Llm::createLLM(path));
    nativeLog("nativeLoadModel: Llm::createLLM() TRA VE XONG (khong crash)");
    if (!llmSlot) {
      LOGE("createLLM tra ve null cho path: %s (slot %d)", path.c_str(), slot);
      return JNI_FALSE;
    }

    if (backendPreference == 0) {
      // SUA/THEM (2026-07-29): bat "use_mmap": true theo dung khuyen nghi
      // CHINH THUC cua MNN cho thiet bi di dong (transformers/README.md:
      // "use_mmap: ... Defaults to false. For mobile devices, it is
      // recommended to set this to true."). Truoc day chua bat — co the la
      // nguyen nhan crash/OOM ngay lap tuc khi nap model 7B that (~4.85GB
      // weight+embedding) du may co 16GB RAM tong, vi thieu mmap co the doi
      // hoi cap phat 1 khoi RAM lien tuc lon ngay lap tuc thay vi anh xa
      // linh hoat theo trang nho.
      try {
        nativeLog("nativeLoadModel: CHUAN BI goi llmSlot->load() that voi backend QNN — day co the la buoc lau nhat (nap weight ~vai GB + build do thi NPU lan dau)");
        llmSlot->set_config(R"({"backend_type": "qnn", "use_mmap": true})");
        // SUA LOI QUAN TRONG (2026-07-29): header that (llm.hpp) xac nhan
        // load() TRA VE bool — code truoc day BO QUA hoan toan gia tri nay,
        // cu log "nap thanh cong" va tra JNI_TRUE bat ke load() thuc su
        // thanh cong hay khong. Day rat co the la nguyen nhan LlmContext
        // luon o trang thai NOT_LOADED dai da qua, du duong dan config va
        // quyen doc file da dung: load() co the da tra ve false ma khong ai
        // biet, vi khong nem exception (nen khong roi vao nhanh catch).
        bool loadOk = llmSlot->load();
        nativeLog(std::string("nativeLoadModel: llmSlot->load() (QNN) TRA VE THAT (bool) = ") +
            (loadOk ? "true" : "FALSE"));
        if (!loadOk) {
          throw std::runtime_error("load() tra ve false voi backend QNN (khong nem exception, nhung khong thanh cong that)");
        }
        LOGI("Slot %d: nap model thanh cong voi backend QNN: %s", slot, path.c_str());
        g_activeBackend[slot] = "qnn";
        return JNI_TRUE;
      } catch (const std::exception& qnnErr) {
        LOGI("Slot %d: QNN khoi tao khong thanh cong (%s), roi ve OpenCL GPU", slot, qnnErr.what());
      }
      try {
        llmSlot->set_config(R"({"backend_type": "opencl", "use_mmap": true})");
        bool loadOk = llmSlot->load();
        nativeLog(std::string("nativeLoadModel: llmSlot->load() (OpenCL) TRA VE THAT (bool) = ") +
            (loadOk ? "true" : "FALSE"));
        if (!loadOk) {
          throw std::runtime_error("load() tra ve false voi backend OpenCL");
        }
        LOGI("Slot %d: nap model thanh cong voi backend OpenCL (GPU): %s", slot, path.c_str());
        g_activeBackend[slot] = "opencl";
        return JNI_TRUE;
      } catch (const std::exception& glErr) {
        LOGI("Slot %d: OpenCL khong thanh cong (%s), roi ve CPU", slot, glErr.what());
      }
      llmSlot->set_config(R"({"backend_type": "cpu", "use_mmap": true})");
      bool cpuLoadOk = llmSlot->load();
      nativeLog(std::string("nativeLoadModel: llmSlot->load() (CPU) TRA VE THAT (bool) = ") +
          (cpuLoadOk ? "true" : "FALSE"));
      if (!cpuLoadOk) {
        LOGE("Slot %d: load() that bai voi CA 3 backend (QNN/OpenCL/CPU) — kha nang cao llm_config.json hoac cac file weight/tokenizer ben trong thu muc model bi loi/khong hop le.", slot);
        return JNI_FALSE;
      }
      LOGI("Slot %d: nap model thanh cong voi backend CPU: %s", slot, path.c_str());
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    } else if (backendPreference == 1) {
      llmSlot->set_config(R"({"backend_type": "opencl", "use_mmap": true})");
      bool loadOk = llmSlot->load();
      nativeLog(std::string("nativeLoadModel: llmSlot->load() (OpenCL, ep buoc) TRA VE THAT (bool) = ") +
          (loadOk ? "true" : "FALSE"));
      if (!loadOk) return JNI_FALSE;
      g_activeBackend[slot] = "opencl";
      return JNI_TRUE;
    } else {
      llmSlot->set_config(R"({"backend_type": "cpu", "use_mmap": true})");
      bool loadOk = llmSlot->load();
      nativeLog(std::string("nativeLoadModel: llmSlot->load() (CPU, ep buoc) TRA VE THAT (bool) = ") +
          (loadOk ? "true" : "FALSE"));
      if (!loadOk) return JNI_FALSE;
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    }
  } catch (const std::exception& e) {
    LOGE("Loi nap model slot %d: %s", slot, e.what());
    llmSlot.reset();
    return JNI_FALSE;
  }
}

// Sinh văn bản từ đúng slot chỉ định, gọi callback Kotlin cho mỗi lần có
// kết quả (hiện tại MNN trả nguyên khối, không phải từng token rời).
// generationConfigJson: JSON temperature/top_p/top_k/repetition_penalty/
// max_new_tokens — áp dụng lại trước mỗi lần sinh, không cần nạp lại model.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeGenerate(
    JNIEnv* env, jobject /* this */, jint slot, jstring prompt, jstring generationConfigJson, jobject callback) {
  nativeLog("nativeGenerate: BAT DAU, slot=" + std::to_string(slot));
  Llm* llm = slotOrNull(slot);
  if (!llm) {
    LOGE("nativeGenerate goi khi slot %d chua nap model", slot);
    nativeLog("nativeGenerate: LOI slot chua nap model, dung lai");
    return;
  }
  nativeLog("nativeGenerate: da lay duoc Llm* cho slot, dang doc prompt string...");
  const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
  std::string promptStr(promptChars);
  env->ReleaseStringUTFChars(prompt, promptChars);
  nativeLog("nativeGenerate: da doc prompt xong, do dai=" + std::to_string(promptStr.size()));
  // CHAN DOAN THEM (2026-07-27): in ra 120 ky tu dau + 120 ky tu cuoi cua
  // prompt that (thay \n bang | de khong vo dinh dang dong log) — de kiem
  // tra xem prompt gui xuong native co dung dinh dang mong doi khong (vd co
  // bi rong/cat cut/lech chat template khong), thay vi chi biet do dai.
  {
    std::string preview = promptStr;
    std::replace(preview.begin(), preview.end(), '\n', '|');
    std::string head = utf8SafeHead(preview, 120);
    std::string tail = preview.size() > 120
        ? utf8SafeTail(preview, 120)
        : std::string("(prompt ngan hon 120 ky tu, khong co tail rieng)");
    nativeLog("nativeGenerate: PROMPT DAU: [" + head + "]");
    nativeLog("nativeGenerate: PROMPT CUOI: [" + tail + "]");
  }

  const char* configChars = env->GetStringUTFChars(generationConfigJson, nullptr);
  std::string configStr(configChars);
  env->ReleaseStringUTFChars(generationConfigJson, configChars);
  nativeLog("nativeGenerate: da doc config xong: " + configStr);

  jclass callbackClass = env->GetObjectClass(callback);
  jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;Z)V");
  if (onTokenMethod == nullptr) {
    // GetMethodID that bai KHONG nem C++ exception — no la loi Java
    // (pending exception trong JNIEnv). Neu tiep tuc goi CallVoidMethod
    // voi methodID rong se undefined behavior / crash ngay. Kiem tra + xoa
    // pending exception + dung lai o day thay vi crash mo ho.
    if (env->ExceptionCheck()) {
      env->ExceptionClear();
    }
    // CHUAN DOAN: lay ten lop THAT cua callback luc runtime — dung
    // java/lang/Class (lop chuan JDK, KHONG bi R8/ProGuard doi ten dai
    // dien cho app) de biet chinh xac R8 co doi ten "onToken" hay khong,
    // thay vi doan mo.
    std::string realClassName = "(khong lay duoc)";
    jclass classClass = env->FindClass("java/lang/Class");
    if (classClass != nullptr) {
      jmethodID getNameMethod = env->GetMethodID(classClass, "getName", "()Ljava/lang/String;");
      if (getNameMethod != nullptr) {
        auto jName = (jstring)env->CallObjectMethod(callbackClass, getNameMethod);
        if (jName != nullptr) {
          const char* nameChars = env->GetStringUTFChars(jName, nullptr);
          realClassName = std::string(nameChars);
          env->ReleaseStringUTFChars(jName, nameChars);
          env->DeleteLocalRef(jName);
        }
      }
      env->DeleteLocalRef(classClass);
    }
    nativeLog("nativeGenerate: LOI NGHIEM TRONG — GetMethodID tra ve NULL cho onToken. Ten lop THAT cua callback luc runtime: " + realClassName + " — neu ten nay la ky tu la/ngan (vd 'a', 'b'...) thi xac nhan bi R8/ProGuard doi ten. Dung lai truoc khi crash.");
    LOGE("Slot %d: GetMethodID cho onToken tra ve NULL, class that: %s", slot, realClassName.c_str());
    return;
  }
  nativeLog("nativeGenerate: da lay duoc onTokenMethod (khong null), chuan bi set_config...");

  try {
    // CHAN DOAN THEM (2026-07-28): header that (llm.hpp) xac nhan
    // set_config() TRA VE bool (thanh cong/that bai), nhung code truoc day
    // BO QUA hoan toan gia tri nay — neu JSON sai ten khoa MNN can, ham co
    // the tra ve false ma khong nem exception, code van log "khong loi" nhu
    // khong co chuyen gi. Kiem tra + log ro rang ngay tai day.
    bool configOk = llm->set_config(configStr);
    nativeLog(std::string("nativeGenerate: set_config KET QUA THAT (bool tra ve) = ") + (configOk ? "true (thanh cong)" : "FALSE (that bai — MNN khong chap nhan JSON nay, co the sai ten khoa)"));
  } catch (const std::exception& e) {
    LOGE("Slot %d: khong ap dung duoc cau hinh sinh van ban (dung mac dinh): %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: set_config NEM LOI (van tiep tuc voi mac dinh): ") + e.what());
  }

  // SUA (2026-07-30): thay std::ostringstream (chi gom, khong day ra ngoai)
  // bang JniStreamingBuf — moi lan MNN ghi 1 doan chu, day ngay qua JNI,
  // khong doi den khi sinh xong het moi hien.
  JniStreamingBuf streamBuf(env, callback, onTokenMethod);
  std::ostream streamingOut(&streamBuf);
  try {
    // QUAN TRỌNG: KHÔNG truyền 0 cho max_new_tokens (tham số cuối) — từng
    // gây crash native (SIGSEGV, không phải exception C++ nên try/catch
    // không bắt được) ở CẢ 3 backend (QNN/OpenCL/CPU) như nhau, xác nhận
    // qua log debug thật trên máy — cho thấy lỗi nằm ở chính điểm gọi này,
    // không phải riêng backend nào. Tài liệu MNN chính thức chỉ gọi
    // response(prompt) dùng giá trị mặc định, không ai truyền 0. Dùng -1
    // để không ép giới hạn ở đây — max_new_tokens thật đã được set qua
    // set_config(configStr) ngay phía trên rồi (kênh chính thức, đúng theo
    // tài liệu MNN — xem generationConfigJson gửi từ Kotlin).
    // CẬP NHẬT: đã thử -1, vẫn crash y hệt — giả thuyết max_new_tokens=0
    // đã bị loại. Giữ nguyên -1 (không tệ hơn so với 0), thêm log chi tiết
    // xung quanh để tìm đúng dòng crash thật.
    nativeLog("nativeGenerate: CHUAN BI goi llm->response() — day la nghi pham chinh neu khong thay dong log sau day");
    // CHAN DOAN THEM (2026-07-27): do thoi gian THAT bang chrono, khong suy
    // doan qua timestamp cua tang Kotlin nua (tang do co do phan giai ms va
    // bi anh huong boi thoi gian dispatch coroutine). Neu so ms in ra o day
    // van gan 0 trong khi may that co the decode ~16-17 token/giay (theo
    // benchmark that trong tai lieu kien truc), thi xac nhan chac chan
    // response() KHONG chay forward-pass thuc su nao — dung lai o dieu kien
    // dung (EOS) ngay tu dau, khong phai do may cham.
    auto t_start = std::chrono::steady_clock::now();
    llm->response(promptStr, &streamingOut, nullptr, -1);
    auto t_end = std::chrono::steady_clock::now();
    long long elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(t_end - t_start).count();
    nativeLog("nativeGenerate: llm->response() TRA VE XONG, khong crash — do dai ket qua=" +
        std::to_string(streamBuf.accumulated().size()) + ", THOI GIAN THAT (ms)=" + std::to_string(elapsedMs));
    // CHAN DOAN THEM (2026-07-28): doc thang LlmContext THAT tu header MNN
    // (llm.hpp, class Llm::getContext()) — day la noi MNN tu ghi lai CHINH
    // XAC ly do dung sinh van ban (enum LlmStatus), khong con phai doan qua
    // thoi gian chay nua. Neu status khong phai NORMAL_FINISHED (1) hay
    // MAX_TOKENS_FINISHED (2), day la bang chung truc tiep co loi noi bo.
    // prompt_len=0 nghia la tokenizer khong ma hoa duoc prompt thanh token
    // nao ca (loi tu dau, truoc ca luc sinh).
    {
      const auto* ctx = llm->getContext();
      if (ctx != nullptr) {
        nativeLog("nativeGenerate: LlmContext THAT — status=" + std::to_string(static_cast<int>(ctx->status)) +
            " (NOT_LOADED=-1,RUNNING=0,NORMAL_FINISHED=1,MAX_TOKENS_FINISHED=2,USER_CANCEL=3,INTERNAL_ERROR=4,TIMEOUT=5)" +
            ", prompt_len=" + std::to_string(ctx->prompt_len) +
            ", gen_seq_len=" + std::to_string(ctx->gen_seq_len) +
            ", all_seq_len=" + std::to_string(ctx->all_seq_len) +
            ", prefill_us=" + std::to_string(ctx->prefill_us) +
            ", decode_us=" + std::to_string(ctx->decode_us));
      } else {
        nativeLog("nativeGenerate: CANH BAO — getContext() tra ve null, khong doc duoc LlmContext that.");
      }
    }
    if (streamBuf.accumulated().empty()) {
      nativeLog("nativeGenerate: CANH BAO — ket qua RONG. Neu THOI GIAN THAT o tren duoi ~50ms, gan\n"
                "        nhu chac chan model dung o dieu kien EOS/stop ngay token dau tien, KHONG\n"
                "        phai loi may cham hay backend — nghi ngo hang dau: tokenizer/EOS id/chat\n"
                "        template cua ban convert model nay (xem lai tokenizer_config.json va\n"
                "        generation_config.json cua model nguon truoc khi convert MNN).");
    }

    // Toan bo van ban that da duoc day tung doan qua JniStreamingBuf ngay
    // trong luc sinh (khong con doi den cuoi nhu truoc) — o day CHI can gui
    // 1 tin hieu "da xong" (chuoi rong + JNI_TRUE), Dart da tu bo qua token
    // rong, chi dung co "done" de dong stream — khong gui lai toan bo van
    // ban nua de tranh nhan doi noi dung.
    jstring jDone = env->NewStringUTF("");
    nativeLog("nativeGenerate: da sinh xong, gui tin hieu DONE (khong gui lai toan bo van ban vi da stream tung doan roi)...");
    env->CallVoidMethod(callback, onTokenMethod, jDone, JNI_TRUE);
    nativeLog("nativeGenerate: CallVoidMethod (DONE) xong, khong crash");
    env->DeleteLocalRef(jDone);
  } catch (const std::exception& e) {
    LOGE("Slot %d: loi sinh van ban: %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: response() NEM std::exception (C++ bat duoc): ") + e.what());
    jstring jError = env->NewStringUTF((std::string("[Loi] ") + e.what()).c_str());
    env->CallVoidMethod(callback, onTokenMethod, jError, JNI_TRUE);
    env->DeleteLocalRef(jError);
  }
  nativeLog("nativeGenerate: KET THUC HAM, khong crash");
}

// Xả đúng 1 slot — KHÔNG đụng tới slot còn lại. Gọi khi máy yếu, cần
// giải phóng RAM ngay sau khi dùng xong 1 model (ví dụ xả model dịch
// sau khi dịch xong, trước khi nạp model chính).
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeUnload(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return;
  g_slots[slot].reset();
  g_activeBackend[slot] = "unknown";
}

JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeIsLoaded(JNIEnv* env, jobject /* this */, jint slot) {
  return slotOrNull(slot) != nullptr ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeActiveBackend(JNIEnv* env, jobject /* this */, jint slot) {
  // Trả về backend THẬT đã nạp thành công (ghi lại trong nativeLoadModel),
  // không còn hardcode "unknown" như trước.
  if (slot < 0 || slot >= kMaxSlots) return env->NewStringUTF("slot_khong_hop_le");
  std::string backend = slotOrNull(slot) ? g_activeBackend[slot] : "chua_nap_model";
  return env->NewStringUTF(backend.c_str());
}

} // extern "C"
