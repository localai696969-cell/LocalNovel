// Cầu nối JNI giữa Kotlin (Android) và MNN-LLM engine.
//
// QUAN TRỌNG: file này gọi vào API CÔNG KHAI CHÍNH THỨC của MNN
// (transformers/llm/engine/include/llm/llm.hpp) — đây là header MNN
// thiết kế sẵn để bên thứ ba tích hợp, KHÔNG phải chép lại code nội bộ
// app "MNN Chat" của Alibaba.
//
// HỖ TRỢ 2 SLOT MODEL ĐỘC LẬP (multi-context thật sự, không giả):
//   slot 0 = model chính (viết truyện)
//   slot 1 = model dịch thuật trung gian (nhỏ, tùy chọn)
// Mỗi slot có Llm riêng, tồn tại độc lập trong RAM.
#include <jni.h>
#include <string>
#include <memory>
#include <sstream>
#include <fstream>
#include <chrono>
#include <ctime>
#include <cstdio>
#include <algorithm>
#include <dirent.h>
#include <atomic>
#include <csignal>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <android/log.h>
#include <poll.h>
#include <sys/wait.h>
#include <signal.h>
#include "llm/llm.hpp"

#define LOG_TAG "MnnBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::string g_logDir = "";
static std::string g_cacheDir = "";

static char g_logDirBufForSignal[512] = {0};

#include <unwind.h>
#include <dlfcn.h>

namespace {
struct BacktraceState {
  void** current;
  void** end;
};

_Unwind_Reason_Code unwindCallback(struct _Unwind_Context* context, void* arg) {
  auto* state = static_cast<BacktraceState*>(arg);
  if (state->current == state->end) return _URC_END_OF_STACK;
  void* ip = reinterpret_cast<void*>(_Unwind_GetIP(context));
  if (ip != nullptr) {
    *state->current++ = ip;
  }
  return _URC_NO_REASON;
}
}

static void crashSignalHandler(int sig, siginfo_t* info, void* /*ucontext*/) {
  const char* sigName = "KHONG_RO";
  switch (sig) {
    case SIGSEGV: sigName = "SIGSEGV (truy cap bo nho khong hop le)"; break;
    case SIGABRT: sigName = "SIGABRT (chuong trinh tu goi abort)"; break;
    case SIGBUS:  sigName = "SIGBUS (loi truy cap bo nho o muc phan cung)"; break;
    case SIGILL:  sigName = "SIGILL (lenh CPU khong hop le)"; break;
    case SIGFPE:  sigName = "SIGFPE (loi so hoc)"; break;
    default: break;
  }
  if (g_logDirBufForSignal[0] != '\0') {
    char path[600];
    snprintf(path, sizeof(path), "%s/native_debug.txt", g_logDirBufForSignal);
    int fd = open(path, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd >= 0) {
      char msg[384];
      int n = snprintf(msg, sizeof(msg),
          "\n!!! CRASH THAT BAT DUOC (signal handler tu viet) — signal=%d: %s, dia_chi_loi(si_addr)=%p !!!\n",
          sig, sigName, info != nullptr ? info->si_addr : nullptr);
      if (n > 0) write(fd, msg, static_cast<size_t>(n));

      void* addrs[32];
      BacktraceState state{addrs, addrs + 32};
      _Unwind_Backtrace(unwindCallback, &state);
      int depth = static_cast<int>(state.current - addrs);
      const char* header = "    Backtrace tho (dia chi, chua co ten ham):\n";
      write(fd, header, strlen(header));
      for (int i = 0; i < depth; ++i) {
        Dl_info dlInfo;
        char line[320];
        int lineLen;
        if (dladdr(addrs[i], &dlInfo) && dlInfo.dli_fname != nullptr) {
          uintptr_t offset = reinterpret_cast<uintptr_t>(addrs[i]) -
              reinterpret_cast<uintptr_t>(dlInfo.dli_fbase);
          lineLen = snprintf(line, sizeof(line), "      #%d %p  %s + 0x%lx  (ham: %s)\n",
              i, addrs[i], dlInfo.dli_fname, static_cast<unsigned long>(offset),
              dlInfo.dli_sname != nullptr ? dlInfo.dli_sname : "(khong ro, thieu symbol table)");
        } else {
          lineLen = snprintf(line, sizeof(line), "      #%d %p  (khong xac dinh duoc thu vien)\n", i, addrs[i]);
        }
        if (lineLen > 0) write(fd, line, static_cast<size_t>(lineLen));
      }
      close(fd);
    }
  }
  signal(sig, SIG_DFL);
  raise(sig);
}

static void installCrashSignalHandlerOnce() {
  static bool installed = false;
  if (installed) return;
  installed = true;
  struct sigaction sa;
  memset(&sa, 0, sizeof(sa));
  sa.sa_sigaction = crashSignalHandler;
  sa.sa_flags = SA_SIGINFO;
  sigaction(SIGSEGV, &sa, nullptr);
  sigaction(SIGABRT, &sa, nullptr);
  sigaction(SIGBUS, &sa, nullptr);
  sigaction(SIGILL, &sa, nullptr);
  sigaction(SIGFPE, &sa, nullptr);
}

static void nativeLog(const std::string& msg) {
  if (g_logDir.empty()) return;
  std::ofstream f(g_logDir + "/native_debug.txt", std::ios::app);
  if (f.is_open()) {
    // ĐÃ THÊM (theo yêu cầu người dùng — điều tra "khung chat không sinh
    // chữ, đợi lâu": log gốc cho thấy khoảng cách ~193 giây KHÔNG GIẢI
    // THÍCH ĐƯỢC giữa lúc `llm->response()` báo xong (t_end đo bằng
    // std::chrono NGAY TRONG hàm) và lúc Kotlin log thấy `nativeGenerate()`
    // THẬT SỰ trả về — nhưng KHÔNG THỂ xác định chính xác đoạn nào trong
    // khoảng đó bị chậm, vì các dòng `nativeLog()` ở tầng C++ TRƯỚC ĐÂY
    // KHÔNG có mốc thời gian (chỉ tầng Kotlin có, qua `kLog()`) — thêm
    // timestamp ở đây để LẦN SAU xảy ra, so sánh được CHÍNH XÁC dòng nào
    // trong file .cpp cách dòng kế tiếp bao lâu, thay vì chỉ đoán.
    auto now = std::chrono::system_clock::now();
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count() % 1000;
    auto t = std::chrono::system_clock::to_time_t(now);
    struct tm tmBuf;
    localtime_r(&t, &tmBuf);
    char timeBuf[32];
    strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%dT%H:%M:%S", &tmBuf);
    char msBuf[8];
    snprintf(msBuf, sizeof(msBuf), ".%03lld", static_cast<long long>(ms));
    f << "[" << timeBuf << msBuf << "] " << msg << "\n";
    f.flush();
    f.close();
  }
}

using namespace MNN::Transformer;

// ĐÃ THÊM (tối ưu tốc độ GPU thật sự — theo đúng khuyến nghị chính thức
// của tài liệu MNN https://mnn-docs.readthedocs.io/en/latest/transformers/llm.html):
// trước đây config OpenCL chỉ có backend_type + use_mmap, THIẾU 3 tham số
// tài liệu MNN khuyến nghị rõ ràng để tăng tốc:
//   - "precision": "low"  → ưu tiên fp16 thay vì fp32, nhanh hơn đáng kể
//     trên GPU di động (Adreno hỗ trợ fp16 tốt), độ chính xác giảm không
//     đáng kể với model đã lượng tử hoá q4 sẵn.
//   - "memory": "low"     → bật lượng tử hoá runtime, giảm băng thông bộ
//     nhớ cần đọc mỗi bước sinh token — đây thường là NÚT THẮT CỔ CHAI
//     lớn nhất khi chạy LLM trên GPU di động, không phải tốc độ tính toán.
//   - "thread_num": 68    → giá trị CỤ THỂ tài liệu MNN khuyến nghị riêng
//     cho suy luận OpenCL (khác hẳn ý nghĩa "số luồng CPU" thông thường).
// Ngoài ra thêm "tmp_path" trỏ vào cache dir của app — MNN OpenCL tự
// động lưu cache kết quả autotuning kernel (dò lần đầu khá lâu) vào đây,
// các lần load SAU sẽ tái sử dụng cache thay vì dò lại từ đầu mỗi lần mở
// model, giảm đáng kể thời gian nạp model từ lần thứ 2 trở đi.
static std::string buildOptimizedOpenCLConfig() {
  std::string tmpPathPart = g_cacheDir.empty() ? "" : (R"(,"tmp_path":")" + g_cacheDir + R"(")");
  return R"({"backend_type": "opencl", "use_mmap": true, "precision": "low", "memory": "low", "thread_num": 68)" +
      tmpPathPart + "}";
}

// ===== FIX BUG 1 (BẢN 2 — ƯU TIÊN THẬT SỰ CHO NPU) =====
// Bản trước dùng sigsetjmp/siglongjmp — CHỈ bắt được SIGSEGV xảy ra TỨC
// THỜI. Nhưng bằng chứng thật từ ảnh chụp màn hình cho thấy có lần app
// "Đang chạy... 6545s" (~109 phút) và "1925s" (~32 phút) KHÔNG hề crash,
// chỉ đứng im không ra chữ nào — đây là HANG (treo thật, rất có thể do
// đang chờ phản hồi từ Hexagon DSP qua FastRPC mà không bao giờ trả lời),
// KHÔNG phải signal nào cả — sigsetjmp hoàn toàn bất lực với loại lỗi này.
//
// GIẢI PHÁP ĐÚNG: cách ly việc THỬ QNN vào 1 TIẾN TRÌNH CON (fork), có
// giới hạn thời gian chờ (timeout) bằng poll(). Đây là kỹ thuật duy nhất
// xử lý được CẢ HAI loại lỗi (crash tức thời VÀ treo vô hạn):
//   - Nếu tiến trình con CRASH (SIGSEGV) → cha nhận biết qua waitpid(),
//     không hề bị ảnh hưởng, tiến trình cha (app thật) sống nguyên vẹn.
//   - Nếu tiến trình con TREO (không bao giờ trả lời) → cha CHỦ ĐỘNG giới
//     hạn thời gian chờ bằng poll(timeoutMs), hết giờ thì SIGKILL tiến
//     trình con ngay, không phải đợi vô thời hạn như trước.
// Đây là "THỬ" (probe) — nếu tiến trình con báo THÀNH CÔNG trong thời
// hạn, tiến trình CHA (app thật) sẽ tự làm lại y hệt bước load() QNN đó
// (không dùng lại kết quả của con, vì bộ nhớ không dùng chung giữa 2
// tiến trình) — lúc này đã có bằng chứng khá chắc QNN không crash/treo.
//
// AN TOÀN post-fork: bên trong tiến trình con, TUYỆT ĐỐI không gọi bất kỳ
// hàm JNI/Java nào (undefined behavior trong tiến trình đa luồng vừa
// fork) — hàm dưới đây chỉ dùng MNN::Transformer::Llm (C++ thuần) +
// syscall thô (write/_exit), không đụng tới JNIEnv.
static bool probeQnnLoadInChildProcess(const std::string& path, int timeoutSeconds) {
  int pipefd[2];
  if (pipe(pipefd) != 0) {
    nativeLog("probeQnn: pipe() that bai, coi nhu QNN KHONG dung duoc (bo qua probe)");
    return false;
  }

  pid_t pid = fork();
  if (pid < 0) {
    nativeLog("probeQnn: fork() that bai, coi nhu QNN KHONG dung duoc (bo qua probe)");
    close(pipefd[0]);
    close(pipefd[1]);
    return false;
  }

  if (pid == 0) {
    // ===== TIẾN TRÌNH CON — CHỈ THỬ, KHÔNG DÙNG THẬT =====
    close(pipefd[0]);
    char resultByte = '0';
    try {
      std::unique_ptr<Llm> probeLlm(Llm::createLLM(path));
      if (probeLlm) {
        probeLlm->set_config(R"({"backend_type": "qnn", "use_mmap": true})");
        bool ok = probeLlm->load();
        resultByte = ok ? '1' : '0';
      }
    } catch (...) {
      resultByte = '0';
    }
    write(pipefd[1], &resultByte, 1);
    close(pipefd[1]);
    _exit(resultByte == '1' ? 0 : 1);
  }

  // ===== TIẾN TRÌNH CHA (app thật) =====
  close(pipefd[1]);
  struct pollfd pfd;
  pfd.fd = pipefd[0];
  pfd.events = POLLIN;
  int pollResult = poll(&pfd, 1, timeoutSeconds * 1000);

  bool qnnOk = false;
  if (pollResult > 0 && (pfd.revents & POLLIN)) {
    char resultByte = '0';
    ssize_t n = read(pipefd[0], &resultByte, 1);
    qnnOk = (n == 1 && resultByte == '1');
    nativeLog(std::string("probeQnn: tien trinh con QNN tra loi TRONG thoi han — ket qua: ") +
        (qnnOk ? "THANH CONG" : "THAT BAI (khong crash, nhung load() tra ve false)"));
  } else if (pollResult == 0) {
    nativeLog("probeQnn: HET THOI GIAN CHO (" + std::to_string(timeoutSeconds) +
        "s) — tien trinh con QNN dang TREO THAT SU (hang, khong phai crash). "
        "Day chinh la nguyen nhan cac lan cho 30-100 phut khong ra chu truoc day. "
        "Giet tien trinh con ngay, chuyen sang OpenCL.");
  } else {
    nativeLog("probeQnn: tien trinh con QNN CRASH/chet truoc khi kip bao ket qua "
        "(rat co the la SIGSEGV that su ben trong QNN/Hexagon driver) — chuyen sang OpenCL.");
  }

  close(pipefd[0]);
  // Don dep tien trinh con trong MOI truong hop — tranh zombie process va
  // tranh no tiep tuc chiem giu tai nguyen NPU/DSP ngam sau khi da bo qua.
  kill(pid, SIGKILL);
  int status = 0;
  waitpid(pid, &status, 0);
  return qnnOk;
}
// ===== END FIX BUG 1 (BẢN 2) =====

namespace {
std::string utf8SafeHead(const std::string& s, size_t maxBytes) {
  if (s.size() <= maxBytes) return s;
  size_t cut = maxBytes;
  while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80) {
    --cut;
  }
  return s.substr(0, cut);
}
std::string utf8SafeTail(const std::string& s, size_t maxBytes) {
  if (s.size() <= maxBytes) return s;
  size_t start = s.size() - maxBytes;
  while (start < s.size() && (static_cast<unsigned char>(s[start]) & 0xC0) == 0x80) {
    ++start;
  }
  return s.substr(start);
}
}

namespace {
class JniStreamingBuf : public std::streambuf {
public:
  JniStreamingBuf(JNIEnv* env, jobject callback, jmethodID method)
      : env_(env), callback_(callback), method_(method) {}

  const std::string& accumulated() const { return accumulated_; }

protected:
  std::streamsize xsputn(const char* s, std::streamsize n) override {
    if (n > 0) {
      accumulated_.append(s, static_cast<size_t>(n));
      std::string chunk(s, static_cast<size_t>(n));
      jstring jChunk = env_->NewStringUTF(chunk.c_str());
      env_->CallVoidMethod(callback_, method_, jChunk, JNI_FALSE);
      env_->DeleteLocalRef(jChunk);
    }
    return n;
  }

  int overflow(int c) override {
    if (c != EOF) {
      char ch = static_cast<char>(c);
      xsputn(&ch, 1);
    }
    return c;
  }

private:
  JNIEnv* env_;
  jobject callback_;
  jmethodID method_;
  std::string accumulated_;
};
}

namespace {
struct LoadingGuard {
  int slotIdx;
  std::atomic<bool>* flags;
  LoadingGuard(int s, std::atomic<bool>* f) : slotIdx(s), flags(f) {}
  ~LoadingGuard() { flags[slotIdx].store(false); }
};
}

namespace {
constexpr int kMaxSlots = 2;
std::unique_ptr<Llm> g_slots[kMaxSlots];
std::atomic<bool> g_loadingInProgress[kMaxSlots] = {false, false};
// ĐÃ THÊM (2026-08-02, chốt chặn dự phòng — hàng phòng thủ THỨ 2 sau khoá
// Mutex thật ở tầng Kotlin/MnnBridge.kt): nếu vì lý do nào đó (lỗi tương
// lai, code path khác bỏ qua khoá Kotlin) mà 2 lệnh nativeGenerate() vẫn
// lọt vào cùng lúc cho CÙNG 1 slot, cờ này đảm bảo lệnh SAU bị TỪ CHỐI
// ngay lập tức (không chờ, không chạy) thay vì chạy song song và làm hỏng
// bộ nhớ nội bộ của Llm — xem giải thích đầy đủ ở mục 5.67 (tài liệu kiến
// trúc) về nguyên nhân chuỗi crash "heap corruption" bí ẩn trước đó.
std::atomic<bool> g_generatingInProgress[kMaxSlots] = {false, false};
std::string g_activeBackend[kMaxSlots] = {"unknown", "unknown"};

Llm* slotOrNull(int slot) {
  if (slot < 0 || slot >= kMaxSlots) return nullptr;
  return g_slots[slot].get();
}
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeSetLogDir(
    JNIEnv* env, jobject /* this */, jstring dir) {
  const char* dirChars = env->GetStringUTFChars(dir, nullptr);
  g_logDir = std::string(dirChars);
  env->ReleaseStringUTFChars(dir, dirChars);
  strncpy(g_logDirBufForSignal, g_logDir.c_str(), sizeof(g_logDirBufForSignal) - 1);
  installCrashSignalHandlerOnce();
  nativeLog("nativeSetLogDir: da nhan duong dan log: " + g_logDir + " (da cai bo bat crash tu viet)");
}

// ĐÃ THÊM: cache dir riêng cho OpenCL kernel tuning cache (tmp_path) —
// dùng context.cacheDir bên Kotlin (khác thư mục log/files), vì đây là
// dữ liệu tạm có thể xoá an toàn bất cứ lúc nào (Android tự dọn khi cần
// thêm dung lượng), không nên lẫn với log debug cần giữ lại để chẩn đoán.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeSetCacheDir(
    JNIEnv* env, jobject /* this */, jstring dir) {
  const char* dirChars = env->GetStringUTFChars(dir, nullptr);
  g_cacheDir = std::string(dirChars);
  env->ReleaseStringUTFChars(dir, dirChars);
  nativeLog("nativeSetCacheDir: da nhan duong dan cache OpenCL tuning: " + g_cacheDir);
}

JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeLoadModel(
    JNIEnv* env, jobject /* this */, jint slot, jstring configPath, jint backendPreference) {
  if (slot < 0 || slot >= kMaxSlots) {
    LOGE("Slot khong hop le: %d", slot);
    return JNI_FALSE;
  }
  bool expected = false;
  if (!g_loadingInProgress[slot].compare_exchange_strong(expected, true)) {
    nativeLog("nativeLoadModel: BI TU CHOI — da co 1 lenh nap model khac cho slot " +
        std::to_string(slot) + " dang chay chua xong.");
    return JNI_FALSE;
  }
  LoadingGuard loadingGuard(slot, g_loadingInProgress);

  const char* pathChars = env->GetStringUTFChars(configPath, nullptr);
  std::string rawPath(pathChars);
  env->ReleaseStringUTFChars(configPath, pathChars);

  std::string path = rawPath;
  auto endsWithJson = [](const std::string& s) {
    return s.size() >= 5 && s.compare(s.size() - 5, 5, ".json") == 0;
  };
  auto fileExists = [](const std::string& p) {
    std::ifstream f(p);
    return f.good();
  };
  auto candidate1 = rawPath + "/config.json";
  auto candidate2 = rawPath + "/llm_config.json";
  if (!endsWithJson(path)) {
    if (fileExists(candidate1)) {
      path = candidate1;
    } else if (fileExists(candidate2)) {
      path = candidate2;
    } else {
      std::string listing;
      DIR* dir = opendir(rawPath.c_str());
      if (dir != nullptr) {
        struct dirent* entry;
        int count = 0;
        while ((entry = readdir(dir)) != nullptr) {
          std::string name(entry->d_name);
          if (name == "." || name == "..") continue;
          listing += name + " | ";
          ++count;
        }
        closedir(dir);
        if (count == 0) listing = "(thu muc RONG)";
      } else {
        listing = "(KHONG MO DUOC thu muc)";
      }
      nativeLog("nativeLoadModel: CANH BAO — khong tim thay config.json. File trong thu muc: " + listing);
    }
  }
  nativeLog("nativeLoadModel: duong dan config THAT dung de goi createLLM: " + path);

  auto& llmSlot = g_slots[slot];
  try {
    nativeLog("nativeLoadModel: CHUAN BI goi Llm::createLLM()");
    llmSlot.reset(Llm::createLLM(path));
    nativeLog("nativeLoadModel: Llm::createLLM() TRA VE XONG (khong crash)");
    if (!llmSlot) {
      LOGE("createLLM tra ve null cho path: %s (slot %d)", path.c_str(), slot);
      return JNI_FALSE;
    }

    if (backendPreference == 3) {
      // ĐÃ CHUYỂN (trước đây là backendPreference == 0, mặc định): thử
      // QNN trước rồi mới rơi xuống OpenCL. Sau khi xác nhận rõ ràng
      // Hexagon 780 (v68) trên máy này nằm DƯỚI mức Qualcomm chính thức
      // hỗ trợ LLM-trên-NPU (yêu cầu v73+ theo tài liệu Qualcomm AI Hub/
      // Genie), việc thử QNN mỗi lần mở model chỉ tốn thời gian chờ vô
      // ích (tới 90s/lần) mà không có cơ hội thành công thật. Đường này
      // giờ CHỈ chạy khi người dùng chủ động chọn (giá trị 3) — ví dụ
      // nếu sau này đổi sang máy chip mới hơn (Snapdragon 8 Gen 2+) và
      // muốn thử lại. Mặc định (0) giờ đi thẳng OpenCL tối ưu bên dưới.
      constexpr int kQnnProbeTimeoutSeconds = 90;
      nativeLog("nativeLoadModel: CHUAN BI probe QNN trong tien trinh con (gioi han " +
          std::to_string(kQnnProbeTimeoutSeconds) + "s) truoc khi thu that o tien trinh chinh");
      bool qnnProbeOk = probeQnnLoadInChildProcess(path, kQnnProbeTimeoutSeconds);

      bool qnnSucceeded = false;
      if (qnnProbeOk) {
        try {
          nativeLog("nativeLoadModel: probe QNN THANH CONG, CHUAN BI goi llmSlot->load() THAT o tien trinh chinh");
          llmSlot->set_config(R"({"backend_type": "qnn", "use_mmap": true})");
          bool loadOk = llmSlot->load();
          nativeLog(std::string("nativeLoadModel: llmSlot->load() (QNN, that) TRA VE = ") + (loadOk ? "true" : "FALSE"));
          if (loadOk) qnnSucceeded = true;
        } catch (const std::exception& qnnErr) {
          nativeLog(std::string("nativeLoadModel: QNN nem exception o LAN LOAD THAT (probe da qua nhung lan nay van loi): ") + qnnErr.what());
        }
      } else {
        nativeLog("nativeLoadModel: probe QNN THAT BAI/TREO/CRASH — bo qua hoan toan buoc load QNN that, chuyen fallback ngay");
      }

      if (qnnSucceeded) {
        LOGI("Slot %d: nap model thanh cong voi backend QNN: %s", slot, path.c_str());
        g_activeBackend[slot] = "qnn";
        return JNI_TRUE;
      }
      nativeLog("nativeLoadModel: QNN khong thanh cong, thu fallback OpenCL (GPU, da toi uu)");
    }

    if (backendPreference == 0 || backendPreference == 1 || backendPreference == 3) {
      // ĐÃ SỬA: dùng buildOptimizedOpenCLConfig() thay vì chuỗi cứng cũ
      // chỉ có backend_type + use_mmap — xem giải thích đầy đủ ở định
      // nghĩa hàm buildOptimizedOpenCLConfig() phía trên.
      try {
        llmSlot->set_config(buildOptimizedOpenCLConfig());
        bool loadOk = llmSlot->load();
        nativeLog(std::string("nativeLoadModel: llmSlot->load() (OpenCL, da toi uu) TRA VE = ") + (loadOk ? "true" : "FALSE"));
        if (loadOk) {
          LOGI("Slot %d: nap model thanh cong voi backend OpenCL (GPU, da toi uu): %s", slot, path.c_str());
          g_activeBackend[slot] = "opencl";
          return JNI_TRUE;
        }
      } catch (const std::exception& glErr) {
        nativeLog(std::string("nativeLoadModel: OpenCL nem exception: ") + glErr.what());
      }

      // Fallback CPU nếu cả OpenCL cũng thất bại (hiếm, nhưng vẫn cần)
      nativeLog("nativeLoadModel: OpenCL that bai, thu fallback CPU");
      try {
        llmSlot->set_config(R"({"backend_type": "cpu", "use_mmap": true, "precision": "low", "memory": "low"})");
        bool cpuLoadOk = llmSlot->load();
        nativeLog(std::string("nativeLoadModel: llmSlot->load() (CPU) TRA VE = ") + (cpuLoadOk ? "true" : "FALSE"));
        if (!cpuLoadOk) {
          LOGE("Slot %d: load() that bai voi CA OpenCL lan CPU", slot);
          return JNI_FALSE;
        }
        LOGI("Slot %d: nap model thanh cong voi backend CPU: %s", slot, path.c_str());
        g_activeBackend[slot] = "cpu";
        return JNI_TRUE;
      } catch (const std::exception& cpuErr) {
        nativeLog(std::string("nativeLoadModel: CPU nem exception: ") + cpuErr.what());
        return JNI_FALSE;
      }
    } else {
      llmSlot->set_config(R"({"backend_type": "cpu", "use_mmap": true, "precision": "low", "memory": "low"})");
      bool loadOk = llmSlot->load();
      nativeLog(std::string("nativeLoadModel: llmSlot->load() (CPU, ep buoc) TRA VE = ") + (loadOk ? "true" : "FALSE"));
      if (!loadOk) return JNI_FALSE;
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    }
  } catch (const std::exception& e) {
    LOGE("Loi nap model slot %d: %s", slot, e.what());
    llmSlot.reset();
    return JNI_FALSE;
  }
}

JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeGenerate(
    JNIEnv* env, jobject /* this */, jint slot, jstring prompt, jstring generationConfigJson, jobject callback) {
  nativeLog("nativeGenerate: BAT DAU, slot=" + std::to_string(slot));
  Llm* llm = slotOrNull(slot);
  if (!llm) {
    LOGE("nativeGenerate goi khi slot %d chua nap model", slot);
    nativeLog("nativeGenerate: LOI slot chua nap model, dung lai");
    return;
  }
  if (slot < 0 || slot >= kMaxSlots) {
    LOGE("nativeGenerate: slot khong hop le: %d", slot);
    return;
  }
  // ĐÃ THÊM: chốt chặn dự phòng — xem giải thích đầy đủ ở khai báo
  // g_generatingInProgress phía trên. Đây là hàng phòng thủ THỨ 2, hàng
  // THỨ 1 (chính, đúng nghĩa "chờ" chứ không "từ chối") là Mutex theo slot
  // ở MnnBridge.kt — trong điều kiện bình thường, guard này sẽ KHÔNG bao
  // giờ bị kích hoạt vì Kotlin đã xếp hàng đúng trước khi gọi tới đây.
  bool expectedGenerating = false;
  if (!g_generatingInProgress[slot].compare_exchange_strong(expectedGenerating, true)) {
    LOGE("nativeGenerate: TU CHOI — slot %d dang co 1 lenh generate khac chay dang do (khong nen xay ra neu khoa Kotlin hoat dong dung)", slot);
    nativeLog("nativeGenerate: TU CHOI vi phat hien lenh generate KHAC dang chay dong thoi tren cung slot " + std::to_string(slot) +
        " — day la loi bat thuong, khoa Mutex ben Kotlin le ra phai ngan truong hop nay tu truoc");
    return;
  }
  LoadingGuard generatingGuard(slot, g_generatingInProgress);
  nativeLog("nativeGenerate: da lay duoc Llm* cho slot, dang doc prompt string...");
  const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
  std::string promptStr(promptChars);
  env->ReleaseStringUTFChars(prompt, promptChars);
  nativeLog("nativeGenerate: da doc prompt xong, do dai=" + std::to_string(promptStr.size()));
  {
    std::string preview = promptStr;
    std::replace(preview.begin(), preview.end(), '\n', '|');
    std::string head = utf8SafeHead(preview, 120);
    std::string tail = preview.size() > 120
        ? utf8SafeTail(preview, 120)
        : std::string("(prompt ngan hon 120 ky tu)");
    nativeLog("nativeGenerate: PROMPT DAU: [" + head + "]");
    nativeLog("nativeGenerate: PROMPT CUOI: [" + tail + "]");
  }

  const char* configChars = env->GetStringUTFChars(generationConfigJson, nullptr);
  std::string configStr(configChars);
  env->ReleaseStringUTFChars(generationConfigJson, configChars);
  nativeLog("nativeGenerate: da doc config xong: " + configStr);

  jclass callbackClass = env->GetObjectClass(callback);
  jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;Z)V");
  if (onTokenMethod == nullptr) {
    if (env->ExceptionCheck()) {
      env->ExceptionClear();
    }
    std::string realClassName = "(khong lay duoc)";
    jclass classClass = env->FindClass("java/lang/Class");
    if (classClass != nullptr) {
      jmethodID getNameMethod = env->GetMethodID(classClass, "getName", "()Ljava/lang/String;");
      if (getNameMethod != nullptr) {
        auto jName = (jstring)env->CallObjectMethod(callbackClass, getNameMethod);
        if (jName != nullptr) {
          const char* nameChars = env->GetStringUTFChars(jName, nullptr);
          realClassName = std::string(nameChars);
          env->ReleaseStringUTFChars(jName, nameChars);
          env->DeleteLocalRef(jName);
        }
      }
      env->DeleteLocalRef(classClass);
    }
    nativeLog("nativeGenerate: LOI NGHIEM TRONG — GetMethodID tra ve NULL cho onToken. Ten lop that: " + realClassName);
    LOGE("Slot %d: GetMethodID cho onToken tra ve NULL, class that: %s", slot, realClassName.c_str());
    return;
  }
  nativeLog("nativeGenerate: da lay duoc onTokenMethod, chuan bi set_config...");

  try {
    bool configOk = llm->set_config(configStr);
    nativeLog(std::string("nativeGenerate: set_config KET QUA = ") + (configOk ? "true" : "FALSE"));
  } catch (const std::exception& e) {
    LOGE("Slot %d: khong ap dung duoc config sinh van ban: %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: set_config NEM LOI (van tiep tuc voi mac dinh): ") + e.what());
  }

  JniStreamingBuf streamBuf(env, callback, onTokenMethod);
  std::ostream streamingOut(&streamBuf);
  try {
    nativeLog("nativeGenerate: CHUAN BI goi llm->response()");
    auto t_start = std::chrono::steady_clock::now();
    llm->response(promptStr, &streamingOut, nullptr, -1);
    auto t_end = std::chrono::steady_clock::now();
    long long elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(t_end - t_start).count();
    nativeLog("nativeGenerate: llm->response() TRA VE XONG, do dai ket qua=" +
        std::to_string(streamBuf.accumulated().size()) + ", THOI GIAN THAT (ms)=" + std::to_string(elapsedMs));
    {
      const auto* ctx = llm->getContext();
      if (ctx != nullptr) {
        nativeLog("nativeGenerate: LlmContext — status=" + std::to_string(static_cast<int>(ctx->status)) +
            ", prompt_len=" + std::to_string(ctx->prompt_len) +
            ", gen_seq_len=" + std::to_string(ctx->gen_seq_len));
      }
    }
    if (streamBuf.accumulated().empty()) {
      nativeLog("nativeGenerate: CANH BAO — ket qua RONG. Kiem tra tokenizer/EOS id/chat template.");
    }

    jstring jDone = env->NewStringUTF("");
    nativeLog("nativeGenerate: gui tin hieu DONE...");
    env->CallVoidMethod(callback, onTokenMethod, jDone, JNI_TRUE);
    nativeLog("nativeGenerate: CallVoidMethod (DONE) xong");
    env->DeleteLocalRef(jDone);
  } catch (const std::exception& e) {
    LOGE("Slot %d: loi sinh van ban: %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: response() NEM exception: ") + e.what());
    jstring jError = env->NewStringUTF((std::string("[Loi] ") + e.what()).c_str());
    env->CallVoidMethod(callback, onTokenMethod, jError, JNI_TRUE);
    env->DeleteLocalRef(jError);
  }
  nativeLog("nativeGenerate: KET THUC HAM, khong crash");
}

JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeUnload(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return;
  g_slots[slot].reset();
  g_activeBackend[slot] = "unknown";
}

JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeIsLoaded(JNIEnv* env, jobject /* this */, jint slot) {
  return slotOrNull(slot) != nullptr ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeActiveBackend(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return env->NewStringUTF("slot_khong_hop_le");
  std::string backend = slotOrNull(slot) ? g_activeBackend[slot] : "chua_nap_model";
  return env->NewStringUTF(backend.c_str());
}

} // extern "C"
