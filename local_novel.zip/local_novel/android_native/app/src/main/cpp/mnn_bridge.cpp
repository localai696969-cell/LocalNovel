// Cầu nối JNI giữa Kotlin (Android) và MNN-LLM engine.
//
// QUAN TRỌNG: file này gọi vào API CÔNG KHAI CHÍNH THỨC của MNN
// (transformers/llm/engine/include/llm/llm.hpp) — đây là header MNN
// thiết kế sẵn để bên thứ ba tích hợp, KHÔNG phải chép lại code nội bộ
// app "MNN Chat" của Alibaba.
//
// HỖ TRỢ 2 SLOT MODEL ĐỘC LẬP (multi-context thật sự, không giả):
//   slot 0 = model chính (viết truyện)
//   slot 1 = model dịch thuật trung gian (nhỏ, tùy chọn)
// Mỗi slot có Llm riêng, tồn tại độc lập trong RAM.
#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <sstream>
#include <iterator>
#include <fstream>
#include <chrono>
#include <ctime>
#include <cstdio>
#include <algorithm>
#include <cctype>
#include <dirent.h>
#include <atomic>
#include <csignal>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <unordered_map>
#include <android/log.h>
#include <poll.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>
#include <cerrno>
#include "llm/llm.hpp"

#define LOG_TAG "MnnBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::string g_logDir = "";
static std::string g_cacheDir = "";

static char g_logDirBufForSignal[512] = {0};

// ĐÃ CHUYỂN LÊN ĐÂY (2026-09-01 — sửa lỗi build CI thật: "use of
// undeclared identifier 'kMaxSlots'"): hằng số này TRƯỚC ĐÂY khai báo ở
// dòng ~639 (ngay trước phần hạ tầng đa-slot) — khi thêm
// `g_lastLoadedModelSubdir[kMaxSlots]` (mục P) ở PHÍA TRÊN vị trí đó
// trong file, C++ đọc từ trên xuống nên chưa thấy `kMaxSlots` được khai
// báo ở đâu tại điểm dùng — lỗi build. Chuyển hằng số này lên NGAY ĐẦU
// file (trước MỌI chỗ dùng nó) — C++ không quan tâm đặt trong khối
// `namespace { }` nào, chỉ cần khai báo TRƯỚC lần dùng đầu tiên trong
// toàn file. `constexpr` ở phạm vi file vốn đã có internal linkage mặc
// định, y hệt lúc còn nằm trong `namespace { }` — chuyển ra ngoài không
// đổi hành vi liên kết, chỉ đổi chỗ nhìn thấy được sớm hơn.
constexpr int kMaxSlots = 2;

#include <unwind.h>
#include <dlfcn.h>

namespace {
struct BacktraceState {
  void** current;
  void** end;
};

_Unwind_Reason_Code unwindCallback(struct _Unwind_Context* context, void* arg) {
  auto* state = static_cast<BacktraceState*>(arg);
  if (state->current == state->end) return _URC_END_OF_STACK;
  void* ip = reinterpret_cast<void*>(_Unwind_GetIP(context));
  if (ip != nullptr) {
    *state->current++ = ip;
  }
  return _URC_NO_REASON;
}
}

static void crashSignalHandler(int sig, siginfo_t* info, void* /*ucontext*/) {
  const char* sigName = "KHONG_RO";
  switch (sig) {
    case SIGSEGV: sigName = "SIGSEGV (truy cap bo nho khong hop le)"; break;
    case SIGABRT: sigName = "SIGABRT (chuong trinh tu goi abort)"; break;
    case SIGBUS:  sigName = "SIGBUS (loi truy cap bo nho o muc phan cung)"; break;
    case SIGILL:  sigName = "SIGILL (lenh CPU khong hop le)"; break;
    case SIGFPE:  sigName = "SIGFPE (loi so hoc)"; break;
    default: break;
  }
  if (g_logDirBufForSignal[0] != '\0') {
    char path[600];
    snprintf(path, sizeof(path), "%s/native_debug.txt", g_logDirBufForSignal);
    int fd = open(path, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd >= 0) {
      char msg[384];
      int n = snprintf(msg, sizeof(msg),
          "\n!!! CRASH THAT BAT DUOC (signal handler tu viet) — signal=%d: %s, dia_chi_loi(si_addr)=%p !!!\n",
          sig, sigName, info != nullptr ? info->si_addr : nullptr);
      if (n > 0) write(fd, msg, static_cast<size_t>(n));

      void* addrs[32];
      BacktraceState state{addrs, addrs + 32};
      _Unwind_Backtrace(unwindCallback, &state);
      int depth = static_cast<int>(state.current - addrs);
      const char* header = "    Backtrace tho (dia chi, chua co ten ham):\n";
      write(fd, header, strlen(header));
      for (int i = 0; i < depth; ++i) {
        Dl_info dlInfo;
        char line[320];
        int lineLen;
        if (dladdr(addrs[i], &dlInfo) && dlInfo.dli_fname != nullptr) {
          uintptr_t offset = reinterpret_cast<uintptr_t>(addrs[i]) -
              reinterpret_cast<uintptr_t>(dlInfo.dli_fbase);
          lineLen = snprintf(line, sizeof(line), "      #%d %p  %s + 0x%lx  (ham: %s)\n",
              i, addrs[i], dlInfo.dli_fname, static_cast<unsigned long>(offset),
              dlInfo.dli_sname != nullptr ? dlInfo.dli_sname : "(khong ro, thieu symbol table)");
        } else {
          lineLen = snprintf(line, sizeof(line), "      #%d %p  (khong xac dinh duoc thu vien)\n", i, addrs[i]);
        }
        if (lineLen > 0) write(fd, line, static_cast<size_t>(lineLen));
      }
      close(fd);
    }
  }
  signal(sig, SIG_DFL);
  raise(sig);
}

static void installCrashSignalHandlerOnce() {
  static bool installed = false;
  if (installed) return;
  installed = true;
  struct sigaction sa;
  memset(&sa, 0, sizeof(sa));
  sa.sa_sigaction = crashSignalHandler;
  sa.sa_flags = SA_SIGINFO;
  sigaction(SIGSEGV, &sa, nullptr);
  sigaction(SIGABRT, &sa, nullptr);
  sigaction(SIGBUS, &sa, nullptr);
  sigaction(SIGILL, &sa, nullptr);
  sigaction(SIGFPE, &sa, nullptr);
}

// ĐÃ THÊM (theo yêu cầu người dùng: "sao không làm log bắt bug ở tầng
// này" — đúng, trước đây chỉ SỬA theo giả thuyết chứ chưa hề có log nào
// XÁC NHẬN được giả thuyết đó đúng hay sai). Đọc VmRSS (bộ nhớ RAM thật
// tiến trình đang chiếm dụng — Android dùng chung không gian địa chỉ cho
// cả CPU RAM lẫn phần lớn buffer GPU qua OpenCL trên hầu hết thiết bị di
// động, nên VmRSS tụt/tăng vẫn phản ánh khá tốt việc tài nguyên model có
// thật sự được giải phóng/cấp phát hay không, dù không hoàn hảo 100% cho
// riêng VRAM chuyên dụng). Dùng để LOG BẰNG CHỨNG THẬT ở 3 mốc quanh
// việc đổi model (trước huỷ model cũ / sau huỷ / sau tạo model mới) —
// nếu bộ nhớ KHÔNG tụt sau khi huỷ model cũ, đó là bằng chứng cụ thể cho
// thấy tài nguyên chưa thật sự được giải phóng như mong đợi.
static long readVmRssKb() {
  std::ifstream f("/proc/self/status");
  if (!f.is_open()) return -1;
  std::string line;
  while (std::getline(f, line)) {
    if (line.rfind("VmRSS:", 0) == 0) {
      long kb = -1;
      sscanf(line.c_str(), "VmRSS: %ld kB", &kb);
      return kb;
    }
  }
  return -1;
}

static void nativeLog(const std::string& msg) {
  if (g_logDir.empty()) return;
  std::ofstream f(g_logDir + "/native_debug.txt", std::ios::app);
  if (f.is_open()) {
    // ĐÃ THÊM (theo yêu cầu người dùng — điều tra "khung chat không sinh
    // chữ, đợi lâu": log gốc cho thấy khoảng cách ~193 giây KHÔNG GIẢI
    // THÍCH ĐƯỢC giữa lúc `llm->response()` báo xong (t_end đo bằng
    // std::chrono NGAY TRONG hàm) và lúc Kotlin log thấy `nativeGenerate()`
    // THẬT SỰ trả về — nhưng KHÔNG THỂ xác định chính xác đoạn nào trong
    // khoảng đó bị chậm, vì các dòng `nativeLog()` ở tầng C++ TRƯỚC ĐÂY
    // KHÔNG có mốc thời gian (chỉ tầng Kotlin có, qua `kLog()`) — thêm
    // timestamp ở đây để LẦN SAU xảy ra, so sánh được CHÍNH XÁC dòng nào
    // trong file .cpp cách dòng kế tiếp bao lâu, thay vì chỉ đoán.
    auto now = std::chrono::system_clock::now();
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count() % 1000;
    auto t = std::chrono::system_clock::to_time_t(now);
    struct tm tmBuf;
    localtime_r(&t, &tmBuf);
    char timeBuf[32];
    strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%dT%H:%M:%S", &tmBuf);
    char msBuf[8];
    snprintf(msBuf, sizeof(msBuf), ".%03lld", static_cast<long long>(ms));
    f << "[" << timeBuf << msBuf << "] " << msg << "\n";
    f.flush();
    f.close();
  }
}

using namespace MNN::Transformer;

// ĐÃ THÊM (theo yêu cầu người dùng — không có PC/adb để xem logcat thật,
// cần "bắt log chi tiết hơn" ngay trong file debug app đã có sẵn): 2 hàm
// dưới đây KHÔNG parse JSON đầy đủ (không thêm thư viện JSON mới chỉ để
// phục vụ debug) — chỉ dò TÌM CHUỖI thô đủ để LỘ RA những gì `config.json`
// thực sự khai báo, và ĐỐI CHIẾU với file thật đang nằm trong thư mục —
// việc parse JSON "thật" để NẠP MODEL vẫn do chính MNN (`Llm::createLLM`)
// đảm nhiệm như cũ, các hàm này chỉ QUAN SÁT, không thay đổi luồng nạp.

// Liệt kê MỌI file trong thư mục model KÈM KÍCH THƯỚC THẬT (byte) — để lộ
// ngay các trường hợp file bị cắt cụt/tải dở (size nhỏ bất thường) mà
// không cần người dùng tự mở app quản lý file so sánh tay.
static std::string listDirWithSizes(const std::string& dirPath) {
  std::string result;
  DIR* dir = opendir(dirPath.c_str());
  if (dir == nullptr) return "(KHONG MO DUOC thu muc: " + dirPath + ")";
  struct dirent* entry;
  int count = 0;
  while ((entry = readdir(dir)) != nullptr) {
    std::string name(entry->d_name);
    if (name == "." || name == "..") continue;
    struct stat st{};
    std::string fullPath = dirPath + "/" + name;
    long long size = (stat(fullPath.c_str(), &st) == 0) ? static_cast<long long>(st.st_size) : -1;
    result += "\n    - " + name + " (" + (size >= 0 ? std::to_string(size) + " byte" : "KHONG DOC DUOC KICH THUOC") + ")";
    ++count;
  }
  closedir(dir);
  if (count == 0) return "(thu muc RONG)";
  return result;
}

// Dò tìm giá trị chuỗi của 1 key dạng `"key": "value"` trong nội dung JSON
// THÔ (không parse thật) — đủ dùng cho mục đích LOG, không dùng để quyết
// định logic nạp model (MNN tự parse JSON thật theo cách riêng của nó).
static std::string extractJsonStringField(const std::string& jsonContent, const std::string& key) {
  std::string needle = "\"" + key + "\"";
  auto pos = jsonContent.find(needle);
  if (pos == std::string::npos) return "";
  pos = jsonContent.find(':', pos + needle.size());
  if (pos == std::string::npos) return "";
  auto quoteStart = jsonContent.find('"', pos + 1);
  if (quoteStart == std::string::npos) return "";
  auto quoteEnd = jsonContent.find('"', quoteStart + 1);
  if (quoteEnd == std::string::npos) return "";
  return jsonContent.substr(quoteStart + 1, quoteEnd - quoteStart - 1);
}

// Đọc nội dung file config.json THẬT SỰ ĐANG DÙNG, in TOÀN BỘ ra log (giới
// hạn 3000 ký tự đề phòng file bất thường lớn), rồi dò 3 field quan trọng
// nhất (`llm_model`/`llm_weight`/`tokenizer_file`) — với MỖI field tìm
// được, kiểm tra LUÔN file đó có thật sự tồn tại trong thư mục hay không
// và kích thước thật là bao nhiêu — đây chính là bước "đối chiếu" mà lần
// trước phải đoán mò qua ảnh chụp màn hình của người dùng.
static void logConfigDiagnostics(const std::string& configPath, const std::string& modelDir) {
  std::ifstream f(configPath);
  if (!f.is_open()) {
    nativeLog("nativeLoadModel: [CHAN DOAN] KHONG MO DUOC file config: " + configPath);
    return;
  }
  std::string content((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  f.close();

  nativeLog("nativeLoadModel: [CHAN DOAN] Kich thuoc config.json dang dung: " + std::to_string(content.size()) + " byte");
  nativeLog("nativeLoadModel: [CHAN DOAN] Noi dung config.json (toi da 3000 ky tu dau): " +
      content.substr(0, std::min<size_t>(content.size(), 3000)));

  for (const auto& key : {std::string("llm_model"), std::string("llm_weight"), std::string("tokenizer_file")}) {
    std::string declared = extractJsonStringField(content, key);
    if (declared.empty()) {
      nativeLog("nativeLoadModel: [CHAN DOAN] config.json KHONG KHAI BAO field \"" + key + "\"");
      continue;
    }
    std::string declaredPath = modelDir + "/" + declared;
    struct stat st{};
    if (stat(declaredPath.c_str(), &st) == 0) {
      nativeLog("nativeLoadModel: [CHAN DOAN] " + key + " = \"" + declared + "\" — FILE CO TON TAI, kich thuoc that = " +
          std::to_string(static_cast<long long>(st.st_size)) + " byte");
    } else {
      nativeLog("nativeLoadModel: [CHAN DOAN] !!! " + key + " = \"" + declared +
          "\" NHUNG FILE NAY KHONG TON TAI tai duong dan: " + declaredPath + " !!! ĐÂY RẤT CÓ THỂ LÀ NGUYÊN NHÂN load() FALSE.");
    }
  }
  nativeLog("nativeLoadModel: [CHAN DOAN] Toan bo file thuc te trong thu muc model: " + listDirWithSizes(modelDir));
}

// ĐÃ SỬA (2026-08-26 — nghi vấn nêu bởi người dùng, xác nhận qua code +
// ảnh chụp màn hình 23/8 cho thấy model 8B từng sinh văn bản bình thường,
// chỉ "chậm hơn 7B", KHÔNG hề đứng hình như log 25-26/8):
// TRƯỚC ĐÂY g_cacheDir (= appContext.cacheDir, set 1 LẦN DUY NHẤT lúc app
// khởi động — xem MnnBridge.kt) được dùng THẲNG làm "tmp_path" — tức MỌI
// model, bất kể kiến trúc/vocab/hidden-dim khác nhau thế nào, đều ghi
// chung 1 thư mục cache autotuning OpenCL, TÍCH LUỸ qua nhiều ngày/nhiều
// phiên test nhiều model khác nhau. Nếu cache key nội bộ của MNN không
// phân biệt đủ rõ giữa các kiến trúc khác nhau, 1 lần load có thể VÔ
// TÌNH tái sử dụng entry autotuning của 1 model KHÁC — MNN sẽ không
// crash (đúng như mọi log quan sát được), chỉ âm thầm chạy sai/chậm
// workgroup config. CHƯA CÓ BẰNG CHỨNG CHẮC CHẮN 100% đây là nguyên
// nhân duy nhất (còn có thể cộng hưởng với rò rỉ VmRSS giữa các lần nạp
// — xem mục 23), nhưng đây là thay đổi RẺ, AN TOÀN, có thể đo được ngay
// bằng log (không dựa cảm quan): tách hẳn 1 thư mục con RIÊNG cho từng
// model (theo đúng tên thư mục model, làm sạch ký tự không hợp lệ) dưới
// "<cacheDir>/opencl_tuning/<tên_model>/", để loại trừ hoàn toàn khả
// năng đụng cache chéo giữa các model — nếu sau khi build lại mà log đo
// được (elapsed/ký tự) của CHÍNH XÁC model 8B khi nạp đầu tiên vẫn y hệt
// mức cũ (~21 ký tự/97s), giả thuyết này bị loại, chuyển hẳn sang điều
// tra hướng khác (bản thân model/GPU driver).
static std::string sanitizeModelFolderName(const std::string& rawModelPath) {
  // Lấy đúng tên thư mục cuối cùng trong đường dẫn model (bỏ dấu / cuối nếu có)
  std::string p = rawModelPath;
  while (!p.empty() && p.back() == '/') p.pop_back();
  auto slashPos = p.find_last_of('/');
  std::string folderName = (slashPos == std::string::npos) ? p : p.substr(slashPos + 1);
  // Chỉ giữ [a-zA-Z0-9._-], thay mọi ký tự khác bằng '_' — an toàn để làm tên thư mục
  std::string safe;
  safe.reserve(folderName.size());
  for (char c : folderName) {
    if (std::isalnum(static_cast<unsigned char>(c)) || c == '.' || c == '_' || c == '-') {
      safe += c;
    } else {
      safe += '_';
    }
  }
  if (safe.empty()) safe = "unknown_model";
  return safe;
}

// Tạo thư mục đệ quy kiểu "mkdir -p" — bỏ qua nếu đã tồn tại (EEXIST),
// log rõ nếu tạo thất bại vì lý do khác (để không âm thầm rơi về cache
// dùng chung mà không ai biết).
static bool ensureDirExists(const std::string& dirPath) {
  if (dirPath.empty()) return false;
  std::string partial;
  size_t start = 0;
  bool ok = true;
  while (start <= dirPath.size()) {
    size_t pos = dirPath.find('/', start);
    if (pos == std::string::npos) pos = dirPath.size();
    partial = dirPath.substr(0, pos);
    if (!partial.empty()) {
      if (mkdir(partial.c_str(), 0700) != 0 && errno != EEXIST) {
        nativeLog("ensureDirExists: mkdir THAT BAI cho \"" + partial + "\" — errno=" + std::to_string(errno));
        ok = false;
      }
    }
    start = pos + 1;
  }
  return ok;
}

// ĐÃ THÊM (2026-08-29 — theo yêu cầu người dùng: "sao lại bắt người dùng
// tự giải quyết thủ công" khi thấy Cài đặt Android báo "Bộ nhớ đệm" của
// app phình lên tới 1,66GB): kể từ khi tách cache autotuning OpenCL riêng
// theo từng model (xem sanitizeModelFolderName/buildOptimizedOpenCLConfig
// phía dưới), thư mục "<cacheDir>/opencl_tuning/" TÍCH LUỸ 1 thư mục con
// cho MỖI model đã từng dùng qua, KHÔNG có cơ chế dọn — càng test nhiều
// model (đặc biệt trong 1 phiên debug dài, nhiều bản model 8B khác nhau
// như buổi tối nay) càng phình to. Giờ tự dọn: trước khi dùng cache cho
// model HIỆN TẠI, tính tổng dung lượng toàn bộ "opencl_tuning/", nếu vượt
// hạn mức thì xoá bớt các thư mục con CŨ NHẤT (theo thời gian sửa đổi lần
// cuối) cho tới khi dưới hạn mức — KHÔNG BAO GIỜ xoá thư mục của model
// đang chuẩn bị dùng ngay trong lệnh nạp này.
static constexpr long long kOpenCLTuningCacheCapBytes = 500LL * 1024 * 1024;  // 500MB — đủ chỗ cho vài model, không để phình vô hạn

static long long dirSizeRecursiveBytes(const std::string& path) {
  DIR* dir = opendir(path.c_str());
  if (dir == nullptr) return 0;
  long long total = 0;
  struct dirent* entry;
  while ((entry = readdir(dir)) != nullptr) {
    std::string name = entry->d_name;
    if (name == "." || name == "..") continue;
    std::string full = path + "/" + name;
    struct stat st{};
    if (lstat(full.c_str(), &st) != 0) continue;
    if (S_ISDIR(st.st_mode)) {
      total += dirSizeRecursiveBytes(full);
    } else {
      total += st.st_size;
    }
  }
  closedir(dir);
  return total;
}

// Xoá đệ quy 1 thư mục con — chỉ dùng cho việc dọn cache (thư mục do
// chính app tạo ra ở buildOptimizedOpenCLConfig(), KHÔNG phải dữ liệu
// người dùng), cố tình KHÔNG đụng gì tới thư mục model thật của người
// dùng (nằm ở /storage/emulated/0/Download/Models/, ngoài phạm vi hàm
// này hoàn toàn).
static bool removeDirRecursive(const std::string& path) {
  DIR* dir = opendir(path.c_str());
  if (dir == nullptr) return false;
  struct dirent* entry;
  bool ok = true;
  while ((entry = readdir(dir)) != nullptr) {
    std::string name = entry->d_name;
    if (name == "." || name == "..") continue;
    std::string full = path + "/" + name;
    struct stat st{};
    if (lstat(full.c_str(), &st) != 0) continue;
    if (S_ISDIR(st.st_mode)) {
      ok = removeDirRecursive(full) && ok;
    } else {
      if (remove(full.c_str()) != 0) ok = false;
    }
  }
  closedir(dir);
  if (rmdir(path.c_str()) != 0) ok = false;
  return ok;
}

// ĐÃ THÊM (2026-09-01 — theo yêu cầu người dùng, sau khi tự phát hiện hệ
// quả thật của fix mục O.2): trước đó `pruneOpenCLTuningCacheIfNeeded`
// chạy ở MỌI lần gọi `buildOptimizedOpenCLConfig()`, tức MỌI lần nạp —
// kể cả nạp LẠI ĐÚNG model đang dùng (ví dụ luồng tự-nạp-lại-sau-huỷ ở
// mục I.1). Log thật ở mục O.2 cho thấy 1 model DUY NHẤT có thể tự tạo
// ra tới 2048MB cache qua nhiều hình dạng prompt khác nhau trong 1 phiên
// — nghĩa là sau khi bỏ luật loại trừ "model hiện tại", chính model đang
// dùng có thể bị dọn sạch cache của NÓ ngay giữa phiên, nhiều lần, mỗi
// lần lại phải dò lại từ đầu (chi phí thêm ở prefill/vài token đầu, xem
// giải thích trong tài liệu kiến trúc mục O). Theo dõi
// `g_lastLoadedModelSubdir[slot]` để chỉ dọn khi THẬT SỰ đổi sang model
// khác (hoặc slot đó lần đầu nạp) — nạp lại đúng model cũ trong cùng slot
// (dù do người dùng chủ động hay do luồng tự phục hồi) không kích hoạt
// dọn nữa. Việc dọn "định kỳ" (không phụ thuộc đổi model) chuyển hẳn sang
// `nativeEnforceOpenCLCacheCap()`, gọi lúc thoát app thật VÀ lúc app
// khởi động (xem `main.dart` + `MnnBridge.kt`).
static std::string g_lastLoadedModelSubdir[kMaxSlots] = {"", ""};

static void pruneOpenCLTuningCacheIfNeeded(const std::string& tuningRootDir, const std::string& currentModelSubdirName) {
  DIR* dir = opendir(tuningRootDir.c_str());
  if (dir == nullptr) return;  // chưa có thư mục nào — không có gì để dọn

  struct Entry { std::string name; long long sizeBytes; time_t mtime; };
  std::vector<Entry> entries;
  struct dirent* de;
  long long totalBytes = 0;
  while ((de = readdir(dir)) != nullptr) {
    std::string name = de->d_name;
    if (name == "." || name == "..") continue;
    std::string full = tuningRootDir + "/" + name;
    struct stat st{};
    if (lstat(full.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) continue;
    long long sz = dirSizeRecursiveBytes(full);
    totalBytes += sz;
    entries.push_back({name, sz, st.st_mtime});
  }
  closedir(dir);

  if (totalBytes <= kOpenCLTuningCacheCapBytes) return;

  nativeLog("pruneOpenCLTuningCacheIfNeeded: tong dung luong cache opencl_tuning = " +
      std::to_string(totalBytes / (1024 * 1024)) + "MB, vuot han muc " +
      std::to_string(kOpenCLTuningCacheCapBytes / (1024 * 1024)) + "MB — bat dau don thu muc CU NHAT");

  // ĐÃ SỬA (2026-08-31 — bug THẬT xác nhận qua log: dùng đi dùng lại
  // ĐÚNG 1 model trong cả phiên (thư mục cache của nó tự phình to dần
  // qua nhiều lần nạp/nhiều hình dạng prompt khác nhau) — trước đây LUÔN
  // loại trừ thư mục model HIỆN TẠI khỏi việc xoá ("không xoá cache đang
  // chuẩn bị dùng ngay bây giờ") — nếu người dùng chỉ dùng 1 model duy
  // nhất, thư mục ĐÓ luôn là "hiện tại", nên KHÔNG BAO GIỜ bị xoá dù có
  // phình to bao nhiêu — log thật xác nhận: báo "vuot han muc" nhưng
  // không hề có dòng "DA XOA" nào sau đó, cache đứng yên ở 2048MB. Bỏ hẳn
  // luật loại trừ này — mất cache tuning của CHÍNH model đang dùng chỉ
  // khiến lần TIẾP THEO phải dò lại từ đầu (y hệt chi phí 1 lần nạp lạnh
  // bình thường, không phải lỗi đúng nghĩa) — đánh đổi hợp lý để cache
  // không phình vô hạn, kể cả khi chỉ dùng 1 model duy nhất suốt phiên.
  std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
    return a.mtime < b.mtime;
  });
  for (const auto& e : entries) {
    if (totalBytes <= kOpenCLTuningCacheCapBytes) break;
    std::string full = tuningRootDir + "/" + e.name;
    bool removed = removeDirRecursive(full);
    nativeLog("pruneOpenCLTuningCacheIfNeeded: " + std::string(removed ? "DA XOA" : "XOA THAT BAI") +
        " \"" + e.name + "\" (" + std::to_string(e.sizeBytes / (1024 * 1024)) + "MB)" +
        (e.name == currentModelSubdirName ? " [DAY LA MODEL HIEN TAI — lan nap SAU se phai tune lai tu dau]" : ""));
    if (removed) totalBytes -= e.sizeBytes;
  }
}


// trước đây config OpenCL chỉ có backend_type + use_mmap, THIẾU 3 tham số
// tài liệu MNN khuyến nghị rõ ràng để tăng tốc:
//   - "precision": "low"  → ưu tiên fp16 thay vì fp32, nhanh hơn đáng kể
//     trên GPU di động (Adreno hỗ trợ fp16 tốt), độ chính xác giảm không
//     đáng kể với model đã lượng tử hoá q4 sẵn.
//   - "memory": "low"     → bật lượng tử hoá runtime, giảm băng thông bộ
//     nhớ cần đọc mỗi bước sinh token — đây thường là NÚT THẮT CỔ CHAI
//     lớn nhất khi chạy LLM trên GPU di động, không phải tốc độ tính toán.
//   - "thread_num": 68    → giá trị CỤ THỂ tài liệu MNN khuyến nghị riêng
//     cho suy luận OpenCL (khác hẳn ý nghĩa "số luồng CPU" thông thường).
// Ngoài ra thêm "tmp_path" trỏ vào cache dir RIÊNG CHO TỪNG MODEL (xem
// sanitizeModelFolderName/ensureDirExists phía trên — ĐÃ SỬA 2026-08-26,
// trước đó dùng chung 1 thư mục cho mọi model). MNN OpenCL tự động lưu
// cache kết quả autotuning kernel (dò lần đầu khá lâu) vào đây, các lần
// load SAU của ĐÚNG model đó sẽ tái sử dụng cache thay vì dò lại từ đầu.
static std::string buildOptimizedOpenCLConfig(const std::string& rawModelPath, int slot) {
  std::string tmpPathPart;
  if (!g_cacheDir.empty()) {
    std::string modelSubdir = sanitizeModelFolderName(rawModelPath);
    std::string tuningRootDir = g_cacheDir + "/opencl_tuning";
    std::string fullTuningDir = tuningRootDir + "/" + modelSubdir;
    // ĐÃ SỬA (2026-09-01): CHỈ dọn khi lần nạp này THẬT SỰ đổi sang model
    // khác so với model TRƯỚC ĐÓ đã nạp thành công trong CHÍNH slot này
    // (xem giải thích đầy đủ ở khai báo g_lastLoadedModelSubdir phía
    // trên) — nạp lại đúng model cũ (cùng subdir) trong cùng slot bỏ qua
    // bước dọn, tránh tự xoá cache của chính mình giữa phiên. Việc dọn
    // "định kỳ, không phụ thuộc đổi model" đã chuyển sang
    // `nativeEnforceOpenCLCacheCap()` (gọi lúc thoát app thật VÀ lúc app
    // khởi động).
    bool isSwitchingModel = (slot >= 0 && slot < kMaxSlots) &&
        (g_lastLoadedModelSubdir[slot] != modelSubdir);
    if (isSwitchingModel) {
      nativeLog("buildOptimizedOpenCLConfig: slot " + std::to_string(slot) +
          " dang doi model (\"" + g_lastLoadedModelSubdir[slot] + "\" -> \"" + modelSubdir +
          "\") — kiem tra don cache dinh muc");
      // ĐÃ SỬA (2026-08-31, vẫn giữ nguyên lý do): đảo thứ tự — DỌN
      // TRƯỚC, đảm bảo thư mục tồn tại SAU. Bước dọn có thể xoá cả thư
      // mục của CHÍNH model sắp nạp (nếu nó tình cờ là thư mục cũ nhất) —
      // nếu `ensureDirExists` chạy TRƯỚC rồi mới dọn, thư mục vừa tạo có
      // thể bị xoá ngay sau đó, khiến `tmp_path` trỏ vào chỗ KHÔNG TỒN
      // TẠI lúc `llmSlot->load()` thật sự dùng tới.
      pruneOpenCLTuningCacheIfNeeded(tuningRootDir, modelSubdir);
    } else {
      nativeLog("buildOptimizedOpenCLConfig: slot " + std::to_string(slot) +
          " nap LAI dung model \"" + modelSubdir + "\" — bo qua buoc don cache (tranh tu xoa cache cua chinh minh giua phien)");
    }
    if (slot >= 0 && slot < kMaxSlots) g_lastLoadedModelSubdir[slot] = modelSubdir;
    bool dirOk = ensureDirExists(fullTuningDir);
    nativeLog("buildOptimizedOpenCLConfig: tmp_path RIENG cho model nay = \"" + fullTuningDir +
        "\" (tao thu muc " + (dirOk ? "THANH CONG" : "THAT BAI — se fallback ve khong co tmp_path") + ")");
    if (dirOk) {
      tmpPathPart = R"(,"tmp_path":")" + fullTuningDir + R"(")";
    }
  }
  return std::string(R"({"backend_type": "opencl", "use_mmap": true, "precision": "low", "memory": "low", "thread_num": 68, )") +
      // ĐÃ SỬA — mục AM, 2026-09-12 — sau khi mục AL đặt `mixed_samplers` ở
      // set_config LÚC GENERATE (sau load) khiến `llm->response()` treo
      // hẳn, không sinh được ký tự nào, không có log nào thêm — nghi vấn
      // đã tự ghi ở "Giới hạn thật" mục AL: gọi set_config LẦN THỨ HAI để
      // THÊM sampler mới vào pipeline đã dựng sẵn có thể không an toàn.
      // Chuyển sang đặt NGAY TẠI ĐÂY — set_config gọi TRƯỚC `load()`,
      // đúng thời điểm pipeline sampler được dựng LẦN ĐẦU (không phải sửa
      // 1 pipeline đã tồn tại) — đây là con đường AN TOÀN theo đúng cách
      // tài liệu MNN mô tả (cấu hình rồi mới load, không phải load rồi
      // mới đổi cấu trúc sampler). Đã bỏ `mixed_samplers` khỏi JSON phía
      // Kotlin (chỗ gọi lúc generate) — không giữ cả 2 nơi cùng lúc để
      // không nhân đôi rủi ro chưa hiểu hết.
      // ĐÃ SỬA (build that bai, GitHub Actions #129, 2026-09-12): C++
      // KHÔNG cho cộng thẳng 2 chuỗi ký tự thô (`const char[N] + const
      // char[M]` không có `operator+` — mảng phân rã thành con trỏ, cộng
      // 2 con trỏ vô nghĩa). Bản trước hoạt động vì literal đầu cộng
      // thẳng với `tmpPathPart` (đã là `std::string`) ngay sau đó — chèn
      // thêm 1 literal MỚI vào giữa khiến 2 literal đứng cạnh nhau bị
      // cộng TRƯỚC (phép + kết hợp trái). Bọc `std::string(...)` quanh
      // literal ĐẦU TIÊN — mọi phép + phía sau đều có 1 bên là
      // `std::string`, hợp lệ trở lại, không đổi nội dung chuỗi kết quả.
      R"("mixed_samplers": ["penalty", "topK", "tfs", "typical", "topP", "min_p", "temperature"], )" +
      // ĐÃ THÊM — mục AQ, 2026-09-13 — thay cho cách hardcode khuôn Llama 3
      // ở tầng Dart (mục AP, đã bỏ): bật `use_template` để MNN tự đọc
      // đúng `prompt_template` đã có SẴN trong `llm_config.json` của
      // TỪNG model (do `llmexport.py` tự trích từ chat_template gốc lúc
      // xuất model) và tự bọc đúng khuôn khi sinh — không cần app biết
      // trước model dùng khuôn Llama 3/ChatML/gì khác. Xem giải thích đầy
      // đủ ở `local_provider.dart` (nơi gọi `generate`, đã bỏ hardcode).
      R"("use_template": false)" +
      // ĐÃ SỬA (mục AU, 2026-09-14 — TEST ĐÚNG 1 BIẾN, theo góp ý đối
      // chiếu độc lập: mục AS tự nhận có giữ nguyên `use_template: true`
      // từ mục AQ, nhưng KHÔNG có bằng chứng Qwen 7B từng được test riêng
      // ở đúng lúc chỉ có mục AQ — lỗ hổng thật trong lập luận trước đó).
      // Tắt hẳn — quay về ĐÚNG trạng thái "trước mục AP", nơi Qwen 7B
      // CHẮC CHẮN hoạt động tốt (người dùng xác nhận trực tiếp). Đây là
      // biến DUY NHẤT còn khác giữa trạng thái đó và hiện tại (mục AC-AH/
      // AL-AM/AI-AJ đều đã có mặt từ trước mục AP, không đổi). Nếu tắt cờ
      // này mà model 8B/Hunyuan hết lặp — xác nhận đúng nghi vấn. Nếu vẫn
      // lặp — loại trừ hẳn use_template, cần hướng khác (thread_num,
      // precision/memory, hoặc bản thân model/lượng tử hoá).
      tmpPathPart + "}";
}

// ===== FIX BUG 1 (BẢN 2 — ƯU TIÊN THẬT SỰ CHO NPU) =====
// Bản trước dùng sigsetjmp/siglongjmp — CHỈ bắt được SIGSEGV xảy ra TỨC
// THỜI. Nhưng bằng chứng thật từ ảnh chụp màn hình cho thấy có lần app
// "Đang chạy... 6545s" (~109 phút) và "1925s" (~32 phút) KHÔNG hề crash,
// chỉ đứng im không ra chữ nào — đây là HANG (treo thật, rất có thể do
// đang chờ phản hồi từ Hexagon DSP qua FastRPC mà không bao giờ trả lời),
// KHÔNG phải signal nào cả — sigsetjmp hoàn toàn bất lực với loại lỗi này.
//
// GIẢI PHÁP ĐÚNG: cách ly việc THỬ QNN vào 1 TIẾN TRÌNH CON (fork), có
// giới hạn thời gian chờ (timeout) bằng poll(). Đây là kỹ thuật duy nhất
// xử lý được CẢ HAI loại lỗi (crash tức thời VÀ treo vô hạn):
//   - Nếu tiến trình con CRASH (SIGSEGV) → cha nhận biết qua waitpid(),
//     không hề bị ảnh hưởng, tiến trình cha (app thật) sống nguyên vẹn.
//   - Nếu tiến trình con TREO (không bao giờ trả lời) → cha CHỦ ĐỘNG giới
//     hạn thời gian chờ bằng poll(timeoutMs), hết giờ thì SIGKILL tiến
//     trình con ngay, không phải đợi vô thời hạn như trước.
// Đây là "THỬ" (probe) — nếu tiến trình con báo THÀNH CÔNG trong thời
// hạn, tiến trình CHA (app thật) sẽ tự làm lại y hệt bước load() QNN đó
// (không dùng lại kết quả của con, vì bộ nhớ không dùng chung giữa 2
// tiến trình) — lúc này đã có bằng chứng khá chắc QNN không crash/treo.
//
// AN TOÀN post-fork: bên trong tiến trình con, TUYỆT ĐỐI không gọi bất kỳ
// hàm JNI/Java nào (undefined behavior trong tiến trình đa luồng vừa
// fork) — hàm dưới đây chỉ dùng MNN::Transformer::Llm (C++ thuần) +
// syscall thô (write/_exit), không đụng tới JNIEnv.
static bool probeQnnLoadInChildProcess(const std::string& path, int timeoutSeconds) {
  int pipefd[2];
  if (pipe(pipefd) != 0) {
    nativeLog("probeQnn: pipe() that bai, coi nhu QNN KHONG dung duoc (bo qua probe)");
    return false;
  }

  pid_t pid = fork();
  if (pid < 0) {
    nativeLog("probeQnn: fork() that bai, coi nhu QNN KHONG dung duoc (bo qua probe)");
    close(pipefd[0]);
    close(pipefd[1]);
    return false;
  }

  if (pid == 0) {
    // ===== TIẾN TRÌNH CON — CHỈ THỬ, KHÔNG DÙNG THẬT =====
    close(pipefd[0]);
    char resultByte = '0';
    try {
      std::unique_ptr<Llm> probeLlm(Llm::createLLM(path));
      if (probeLlm) {
        probeLlm->set_config(R"({"backend_type": "qnn", "use_mmap": true})");
        bool ok = probeLlm->load();
        resultByte = ok ? '1' : '0';
      }
    } catch (...) {
      resultByte = '0';
    }
    write(pipefd[1], &resultByte, 1);
    close(pipefd[1]);
    _exit(resultByte == '1' ? 0 : 1);
  }

  // ===== TIẾN TRÌNH CHA (app thật) =====
  close(pipefd[1]);
  struct pollfd pfd;
  pfd.fd = pipefd[0];
  pfd.events = POLLIN;
  int pollResult = poll(&pfd, 1, timeoutSeconds * 1000);

  bool qnnOk = false;
  if (pollResult > 0 && (pfd.revents & POLLIN)) {
    char resultByte = '0';
    ssize_t n = read(pipefd[0], &resultByte, 1);
    qnnOk = (n == 1 && resultByte == '1');
    nativeLog(std::string("probeQnn: tien trinh con QNN tra loi TRONG thoi han — ket qua: ") +
        (qnnOk ? "THANH CONG" : "THAT BAI (khong crash, nhung load() tra ve false)"));
  } else if (pollResult == 0) {
    nativeLog("probeQnn: HET THOI GIAN CHO (" + std::to_string(timeoutSeconds) +
        "s) — tien trinh con QNN dang TREO THAT SU (hang, khong phai crash). "
        "Day chinh la nguyen nhan cac lan cho 30-100 phut khong ra chu truoc day. "
        "Giet tien trinh con ngay, chuyen sang OpenCL.");
  } else {
    nativeLog("probeQnn: tien trinh con QNN CRASH/chet truoc khi kip bao ket qua "
        "(rat co the la SIGSEGV that su ben trong QNN/Hexagon driver) — chuyen sang OpenCL.");
  }

  close(pipefd[0]);
  // Don dep tien trinh con trong MOI truong hop — tranh zombie process va
  // tranh no tiep tuc chiem giu tai nguyen NPU/DSP ngam sau khi da bo qua.
  kill(pid, SIGKILL);
  int status = 0;
  waitpid(pid, &status, 0);
  return qnnOk;
}
// ===== END FIX BUG 1 (BẢN 2) =====

namespace {
std::string utf8SafeHead(const std::string& s, size_t maxBytes) {
  if (s.size() <= maxBytes) return s;
  size_t cut = maxBytes;
  while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80) {
    --cut;
  }
  return s.substr(0, cut);
}
std::string utf8SafeTail(const std::string& s, size_t maxBytes) {
  if (s.size() <= maxBytes) return s;
  size_t start = s.size() - maxBytes;
  while (start < s.size() && (static_cast<unsigned char>(s[start]) & 0xC0) == 0x80) {
    ++start;
  }
  return s.substr(start);
}
}

namespace {
// ĐÃ SỬA (2026-08-30 — theo yêu cầu người dùng: "ngắt phiên trước giữa
// chừng thì lần sau chat phải nạp lại NGAY, không đợi, không crash"):
// TRƯỚC ĐÂY dùng unique_ptr (1 chủ sở hữu duy nhất) — buộc phải TỪ CHỐI
// nạp model mới nếu lệnh generate() cũ (dù đã "mồ côi"/treo thật) còn có
// thể đang cầm con trỏ tới object cũ, vì huỷ object đó ngay lúc này có
// thể gây use-after-free thật (crash) nếu lệnh cũ đột nhiên "tỉnh lại".
// Đổi sang shared_ptr: lệnh generate() nào đang chạy sẽ tự giữ 1 bản sao
// riêng (xem slotShared()) — khi nạp model mới THAY THẾ con trỏ trong
// g_slots[slot], object CŨ không hề bị huỷ ngay nếu vẫn còn ai đó (lệnh
// cũ) đang giữ tham chiếu — chỉ thực sự giải phóng khi KHÔNG CÒN AI giữ
// nữa (lệnh cũ tự trả về, dù trễ bao lâu, dù không bao giờ). Nhờ vậy nạp
// model mới AN TOÀN TUYỆT ĐỐI để làm NGAY LẬP TỨC, không cần chờ/từ chối
// gì cả — không đổi gì về việc TRỌNG SỐ có bị đọc lại hay không (vẫn
// dùng mmap như cũ), chỉ đổi cách quản lý vòng đời object C++.
std::shared_ptr<Llm> g_slots[kMaxSlots];
// Tăng dần mỗi lần nạp model mới thành công cho 1 slot — dùng để
// LoadingGuard (bên dưới) biết chắc mình có phải "chủ nhân hợp lệ hiện
// tại" của cờ g_generatingInProgress hay không lúc kết thúc, tránh trường
// hợp 1 lệnh generate() cũ (mồ côi, chạy rất trễ) vô tình xoá nhầm cờ
// đang thuộc về 1 lệnh MỚI hoàn toàn (chạy trên object mới sau khi đã
// nạp lại) — nếu không có epoch này, 2 lệnh generate() sẽ tưởng nhầm là
// đang "rảnh" trong khi thực ra có 1 lệnh mới đang chạy thật.
std::atomic<long long> g_slotEpoch[kMaxSlots] = {0, 0};
std::atomic<bool> g_loadingInProgress[kMaxSlots] = {false, false};
// ĐÃ THÊM (2026-08-02, chốt chặn dự phòng — hàng phòng thủ THỨ 2 sau khoá
// Mutex thật ở tầng Kotlin/MnnBridge.kt): nếu vì lý do nào đó (lỗi tương
// lai, code path khác bỏ qua khoá Kotlin) mà 2 lệnh nativeGenerate() vẫn
// lọt vào cùng lúc cho CÙNG 1 slot, cờ này đảm bảo lệnh SAU bị TỪ CHỐI
// ngay lập tức (không chờ, không chạy) thay vì chạy song song và làm hỏng
// bộ nhớ nội bộ của Llm — xem giải thích đầy đủ ở mục 5.67 (tài liệu kiến
// trúc) về nguyên nhân chuỗi crash "heap corruption" bí ẩn trước đó.
std::atomic<bool> g_generatingInProgress[kMaxSlots] = {false, false};
// ĐÃ THÊM (theo yêu cầu người dùng: "làm tiếp phần chặn lặp ở tầng gốc"):
// trước đây `cancelGenerate` (Kotlin) CHỈ huỷ được Job coroutine bọc
// ngoài — không có cách nào báo cho `llm->response()` (lời gọi JNI đồng
// bộ/chặn, đang chạy) rằng cần dừng, nên nó luôn chạy tới hết
// `max_new_tokens` hoặc tới khi EOS — đây MỚI LÀ gốc rễ thật của mọi lần
// "lệnh generate() mồ côi" xuất hiện trong log. Cờ này được kiểm tra
// NGAY TRONG `JniStreamingBuf::xsputn` (nơi DUY NHẤT mọi token sinh ra
// đều đi qua trước khi tới Java) — set `true` thì lần ghi token TIẾP
// THEO sẽ ném exception để thoát khỏi `llm->response()` ngay, không cần
// đợi library MNN tự hỗ trợ API huỷ giữa chừng (không có).
std::atomic<bool> g_cancelRequested[kMaxSlots] = {false, false};
// ĐÃ THÊM (log chẩn đoán, theo yêu cầu người dùng): đếm số lần ĐÃ NẠP
// THÀNH CÔNG vào từng slot kể từ khi tiến trình app khởi động (KHÔNG
// reset khi đổi model, CHỈ reset khi app bị kill/mở lại thật) — dùng để
// trả lời chính xác câu hỏi "lỗi có LUÔN xảy ra từ lần nạp thứ 2 trở đi
// trong slot đó không, hay ngẫu nhiên" bằng dữ liệu thật trong log, thay
// vì suy đoán từ trí nhớ người dùng.
std::atomic<int> g_loadCountInProcess[kMaxSlots] = {0, 0};
std::string g_activeBackend[kMaxSlots] = {"unknown", "unknown"};
// ĐÃ THÊM (2026-08-27 — bằng chứng thật từ log người dùng): lệnh
// generate() THỨ 2 gọi trên CÙNG 1 object Llm* vừa bị ép dừng bằng
// exception (throw từ trong xsputn) ở lệnh TRƯỚC ĐÓ đã bị TREO HOÀN
// TOÀN — không sinh nổi 1 ký tự, không crash, không có bất kỳ log nào
// cho tới khi bị phát hiện gián tiếp 12 PHÚT sau (lúc người dùng thử nạp
// model khác và bị từ chối vì "slot dang co lenh generate mo coi"). Lý
// do rất có thể: ném exception giữa chừng lúc response() đang chạy
// KHÔNG PHẢI cách huỷ "sạch" — rất có thể để lại trạng thái nội bộ của
// MNN (KV-cache dở dang, hàng đợi lệnh OpenCL dở dang) ở dạng không nhất
// quán, khiến lần gọi SAU trên CHÍNH object đó bị kẹt vô thời hạn. Cờ
// này đánh dấu 1 slot "KHÔNG CÒN AN TOÀN ĐỂ TÁI SỬ DỤNG" ngay sau khi bắt
// được bất kỳ exception nào giữa chừng response() — nativeGenerate() sẽ
// TỪ CHỐI NGAY LẬP TỨC (không đợi 12 phút mới phát hiện gián tiếp) nếu
// slot đang ở trạng thái này, buộc phải nạp lại model (dù là CÙNG model)
// trước khi generate() tiếp — nativeLoadModel() xoá cờ này sau khi tạo +
// load xong 1 object Llm hoàn toàn mới.
std::atomic<bool> g_slotNeedsFullReload[kMaxSlots] = {false, false};
// ĐÃ THÊM: mốc thời gian BẮT ĐẦU của lệnh generate() đang chạy trên từng
// slot — dùng để tính chính xác "đã treo bao lâu" khi từ chối nạp model
// mới vì slot còn lệnh mồ côi, thay vì chỉ nói chung chung "đang chạy dở".
std::chrono::steady_clock::time_point g_generateStartTime[kMaxSlots];
// ĐÃ THÊM (2026-09-05, sau sự cố "Tạo lại tất cả ghi chú" ngày 2026-09-03 —
// ensureLoaded() ở Dart coi MỌI lúc isSlotGenerating=true là "chắc chắn mồ
// côi" rồi nạp đè model NGAY, kể cả khi đó là 1 lệnh generate() THẬT đang
// chạy bình thường, chỉ là chậm — biến nó thành mồ côi thật, gây ra chuỗi
// ~35 lệnh generate() chồng chéo + ghi rác vào chương): mốc thời gian của
// lần TIẾN TRIỂN GẦN NHẤT (mỗi token sinh ra, xem JniStreamingBuf::xsputn)
// — KHÁC g_generateStartTime (mốc BẮT ĐẦU, không đổi trong suốt 1 lệnh).
// Dart dùng hiệu (thời điểm hiện tại − mốc này) để phân biệt "đang chạy
// thật, chỉ chậm" (hiệu nhỏ, model 8B này vốn đã được xác nhận chậm — xem
// ghi chú xoá lớp trì trệ theo elapsed-time phía trên) với "treo hẳn,
// không sinh nổi 1 ký tự trong nhiều phút liền" (hiệu rất lớn — CHỈ trường
// hợp này mới coi là mồ côi thật, an toàn để nạp đè). Cố tình KHÔNG dùng
// elapsed-time-từ-lúc-bắt-đầu (g_generateStartTime) cho việc này — đúng
// nguyên nhân khiến lớp trì trệ cũ (đã xoá) cắt nhầm lệnh CHẬM NHƯNG VẪN
// ĐANG CHẠY; đo theo TIẾN TRIỂN thì lệnh chậm-nhưng-sống vẫn liên tục cập
// nhật mốc này, không bao giờ bị coi là treo.
std::atomic<long long> g_lastProgressMs[kMaxSlots] = {0, 0};

long long nowSteadyMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::steady_clock::now().time_since_epoch()).count();
}

// Ném ra khi phát hiện cần dừng sớm (bị huỷ chủ động HOẶC tự phát hiện
// lặp vô tận) — nativeGenerate() đã có sẵn 1 khối catch(std::exception&)
// bao quanh lời gọi response(), exception này lọt vào đúng khối đó, in
// log rõ nguyên nhân rồi kết thúc bình thường (không crash).
struct GenerationStoppedException : public std::runtime_error {
  explicit GenerationStoppedException(const std::string& msg) : std::runtime_error(msg) {}
};

Llm* slotOrNull(int slot) {
  if (slot < 0 || slot >= kMaxSlots) return nullptr;
  return g_slots[slot].get();
}
// ĐÃ THÊM (2026-08-30): trả về 1 BẢN SAO shared_ptr (không phải raw
// pointer) — người gọi (nativeGenerate) giữ biến này SỐNG SUỐT cả hàm,
// đảm bảo object không bị huỷ dù g_slots[slot] có bị THAY THẾ bởi 1 lệnh
// nạp model khác chạy song song. Xem giải thích đầy đủ ở khai báo
// g_slots phía trên.
std::shared_ptr<Llm> slotShared(int slot) {
  if (slot < 0 || slot >= kMaxSlots) return nullptr;
  return g_slots[slot];
}
}

namespace {
class JniStreamingBuf : public std::streambuf {
public:
  JniStreamingBuf(JNIEnv* env, jobject callback, jmethodID method, int slot)
      : env_(env), callback_(callback), method_(method), slot_(slot) {}

  const std::string& accumulated() const { return accumulated_; }

protected:
  std::streamsize xsputn(const char* s, std::streamsize n) override {
    if (n > 0) {
      accumulated_.append(s, static_cast<size_t>(n));
      if (slot_ >= 0 && slot_ < kMaxSlots) {
        g_lastProgressMs[slot_].store(nowSteadyMs());
      }
      // ĐÃ BỎ (2026-08-28 — theo yêu cầu rõ ràng của người dùng): lớp
      // "trì trệ" (quá 90s mà chưa đủ 80 ký tự) đã XOÁ HẲN — người dùng
      // xác nhận CHẤP NHẬN model 8B này vốn nặng/chậm ở tầng tính toán
      // cốt lõi (đã kiểm chứng bằng số liệu thật — xem mục F/G tài liệu
      // kiến trúc: đổi embed_bit không cải thiện gì, STEADY gần như không
      // đổi) và không muốn bị cắt CHỈ VÌ CHẬM.
      // ĐÃ SỬA (2026-08-28, sau đó cùng ngày): yêu cầu ban đầu CHỈ nói bỏ
      // phần trì trệ — KHÔNG bao gồm phần lặp vô tận dưới đây. Lượt trước
      // tôi hiểu sai phạm vi, đã lỡ xoá luôn cả phần lặp vô tận — phục hồi
      // lại nguyên trạng theo đúng yêu cầu thật.
      if (slot_ >= 0 && slot_ < kMaxSlots && g_cancelRequested[slot_].load()) {
        throw GenerationStoppedException("nguoi dung/he thong yeu cau huy (cancelGenerate)");
      }
      if (looksLikeRepetitionLoop()) {
        nativeLog("nativeGenerate: [CHAN DOAN LAP VO TAN] xay ra o lan nap thu " +
            std::to_string(g_loadCountInProcess[slot_].load()) + " vao slot " + std::to_string(slot_) +
            " trong tien trinh nay (>=2 nghia la KHONG PHAI lan nap dau tien sau khi mo app)");
        throw GenerationStoppedException("phat hien lap vo tan (repetition loop) o tang native");
      }
      std::string chunk(s, static_cast<size_t>(n));
      jstring jChunk = env_->NewStringUTF(chunk.c_str());
      env_->CallVoidMethod(callback_, method_, jChunk, JNI_FALSE);
      env_->DeleteLocalRef(jChunk);
    }
    return n;
  }

  int overflow(int c) override {
    if (c != EOF) {
      char ch = static_cast<char>(c);
      xsputn(&ch, 1);
    }
    return c;
  }

private:
  // ĐÃ SỬA (mục Z tài liệu kiến trúc, 2026-09-08 — lỗi THẬT xác nhận qua
  // debug log: lệnh tóm tắt chương rơi vào lặp vô tận, tầng NATIVE này
  // không hề bắt được, phải đợi 40 phút tới khi tầng Dart tự phát hiện).
  //
  // BẢN CŨ so khớp theo BYTE thô của `std::string` (UTF-8) — comment cũ
  // tự nhận "2 mẫu lỗi thật đã gặp đều là ASCII thuần" nên "không mất độ
  // chính xác thực tế", nhưng đó là 2 mẫu lỗi gặp khi model lặp bằng
  // TIẾNG ANH/ký tự đặc biệt (dấu ngoặc, chữ số — mỗi ký tự ĐÚNG 1 byte).
  // App này viết tiểu thuyết TIẾNG VIỆT — phần lớn ký tự có dấu chiếm 2-3
  // byte UTF-8/ký tự (vd "à"=2 byte, "ề"=3 byte). Hệ quả 2 lỗ hổng THẬT:
  //  (a) Model lặp ĐÚNG 1 ký tự tiếng Việt duy nhất (tương đương "8888888"
  //      nhưng bằng tiếng Việt) — không byte nào trong 2-3 byte cấu thành
  //      1 ký tự đó chiếm nổi 85% (mỗi byte tự chia nhau phần trăm nhỏ) —
  //      điều kiện (a) KHÔNG BAO GIỜ true được với kiểu lặp này.
  //  (b) Model lặp 1 cụm ngắn 2-6 KÝ TỰ tiếng Việt — quy đổi ra BYTE dễ
  //      dàng vượt quá 6 (vd cụm 3 ký tự có dấu ~6-9 byte) — vượt hẳn
  //      trần period<=6 BYTE của điều kiện (b), không bao giờ khớp.
  // Tóm lại: thuật toán cũ gần như VÔ HIỆU với đúng loại lặp phổ biến
  // nhất của app này (lặp bằng tiếng Việt có dấu) — chỉ còn tầng Dart
  // (so khớp theo `String` của Dart, tức UTF-16 — với ký tự tiếng Việt
  // dựng sẵn/precomposed thông thường thì 1 code unit = đúng 1 ký tự,
  // nên KHÔNG dính lỗi này) làm được việc, nhưng tầng Dart luôn chậm hơn
  // hẳn (vòng JNI → Kotlin → EventChannel → Dart, cộng cửa sổ tích luỹ
  // riêng của nó) — đúng như log thật: 40 phút mới huỷ được, thay vì gần
  // như tức thời nếu tầng native (chạy ngay trong `xsputn`, mỗi token)
  // bắt được.
  //
  // BẢN SỬA: tách `compact` (đã bỏ khoảng trắng) thành từng "ký tự" UTF-8
  // thật (gộp đúng số byte tiếp diễn vào 1 đơn vị) TRƯỚC khi so khớp, rồi
  // áp DÙNG NGUYÊN 2 tiêu chí cũ (1 đơn vị chiếm >85%, HOẶC 1 cụm 2-6 ĐƠN
  // VỊ lặp khít) trên dãy ĐƠN VỊ đó thay vì trên dãy byte thô — khớp đúng
  // tinh thần "giữ cùng 1 logic với tầng Dart" mà comment gốc đã đặt ra,
  // chỉ là lần này thực sự đúng cho cả văn bản đa byte.
  static std::vector<std::string> splitUtf8Units(const std::string& s) {
    std::vector<std::string> out;
    out.reserve(s.size());
    size_t i = 0;
    while (i < s.size()) {
      unsigned char lead = static_cast<unsigned char>(s[i]);
      size_t len = 1;
      if ((lead & 0x80) == 0x00) len = 1;       // 0xxxxxxx — ASCII
      else if ((lead & 0xE0) == 0xC0) len = 2;  // 110xxxxx — 2 byte
      else if ((lead & 0xF0) == 0xE0) len = 3;  // 1110xxxx — 3 byte (đa số tiếng Việt có dấu)
      else if ((lead & 0xF8) == 0xF0) len = 4;  // 11110xxx — 4 byte (emoji...)
      // Byte lạ/lỗi giữa chuỗi (continuation byte đứng lẻ) — coi như 1
      // đơn vị độ dài 1 để không bao giờ đọc tràn ra ngoài chuỗi, tránh
      // biến 1 lỗi vô hại thành crash.
      len = std::min(len, s.size() - i);
      out.push_back(s.substr(i, len));
      i += len;
    }
    return out;
  }

  // ĐÃ THÊM — mục BU, xem giải thích đầy đủ tại nơi gọi trong
  // `looksLikeRepetitionLoop()`. Chạy trên TOÀN BỘ `accumulated_` (không
  // cần cửa sổ đuôi — lúc gọi được tới đây, `accumulated_` còn rất ngắn,
  // dưới hẳn 320 byte của tiêu chí (a)/(b)/(c) bên dưới).
  bool hasEarlyFlood() const {
    std::string compact;
    compact.reserve(accumulated_.size());
    for (char c : accumulated_) {
      if (!std::isspace(static_cast<unsigned char>(c))) compact.push_back(c);
    }
    const auto units = splitUtf8Units(compact);
    // Trần tối thiểu 24 đơn vị — thấp hơn hẳn ngưỡng 60 của tiêu chí (a)
    // gốc (cố ý — mục đích CHÍNH của lớp này là bắt SỚM), nhưng đủ để
    // không báo giả với vài ký tự lặp ngắn hoàn toàn bình thường.
    if (units.size() < 24) return false;
    std::unordered_map<std::string, int> counts;
    counts.reserve(units.size());
    for (const auto& u : units) counts[u]++;
    int maxCount = 0;
    for (const auto& kv : counts) maxCount = std::max(maxCount, kv.second);
    // 90% (không phải 85% như tiêu chí (a) gốc) — mẫu nhỏ hơn nên cần
    // khắt khe hơn để bù lại rủi ro trùng hợp cao hơn.
    return static_cast<double>(maxCount) / static_cast<double>(units.size()) > 0.90;
  }

  bool looksLikeRepetitionLoop() const {
    // ĐÃ SỬA — mục AI, 2026-09-11 — theo yêu cầu người dùng, sau khi 5+ lần
    // test liên tiếp — với `repetitionPenalty` ĐÃ XÁC NHẬN đúng 1.05 VÀ
    // 1.15 (loại trừ hẳn giả thuyết mục AC-AH) — đều bị cắt ở CÙNG 1 mốc:
    // "đã sinh được 60 ký tự". Đối chiếu mục Z tài liệu kiến trúc: bản vá
    // gốc (thêm `splitUtf8Units`, khiến bộ dò này lần đầu tiên nhận diện
    // ĐÚNG lặp tiếng Việt đa byte) đã tự nhận đây là RỦI RO CHƯA XÁC NHẬN
    // — "kỳ vọng còn vài giây... nhưng CHƯA đo lại bằng số liệu thật" cho
    // đúng luồng "Đắp thịt" người dùng trực tiếp bấm (khác tác vụ tóm tắt
    // nền là mục tiêu BAN ĐẦU của mục Z). Giờ có đủ dữ liệu thật: NGƯỠNG
    // 60 byte cũ (kế thừa nguyên từ thời chỉ so khớp ASCII, CHƯA từng đo
    // lại cho tiếng Việt) khớp NGAY vào lần kiểm tra ĐẦU TIÊN có thể xảy
    // ra — model chưa có cơ hội nào vượt qua 1 đoạn mở đầu có thể chỉ là
    // tạm thời trước khi bộ dò đã kết luận "không thể cứu". Không hạ thấp
    // ĐỘ NHẠY của chính 2 tiêu chí so khớp (vẫn y hệt mục Z, vẫn bắt được
    // lặp thật ở tốc độ tương đương) — chỉ nới NGƯỠNG TỐI THIỂU trước khi
    // bắt đầu xét, cho model đủ "đường băng" (~4-5 câu tiếng Việt) để tự
    // vượt qua đoạn mở đầu gập ghềnh nếu có thể, trước khi bị kết luận.
    // ĐÃ THÊM — mục BU, 2026-09-26 — LỖ HỔNG THẬT xác nhận qua log thật:
    // model lặp NGUYÊN 1 KÝ TỰ ("FFFFFFFF...", model kiến trúc Llama 3 —
    // KHÔNG PHẢI Qwen3, xem mục BT/BU) nhưng mỗi ký tự mất TỚI ~4,7 GIÂY
    // (342 giây cho đúng 73 ký tự) — tới lúc người dùng tự bấm Huỷ, tổng
    // `accumulated_` mới 73 byte, CHƯA BAO GIỜ chạm ngưỡng 320 byte bên
    // dưới, nên KHÔNG tiêu chí nào (a)/(b)/(c) được chạy dù kiểu lặp này
    // (1 ký tự chiếm áp đảo) đúng là thứ tiêu chí (a) sinh ra để bắt.
    // Ngưỡng 320 byte hợp lý cho tiêu chí (b)/(c) (cần đủ dữ liệu để phân
    // biệt chu kỳ THẬT với trùng hợp) — nhưng lại là điểm mù chết người khi
    // tốc độ sinh cực chậm. Thêm 1 lớp kiểm tra RIÊNG, chạy TRƯỚC ngưỡng
    // 320 byte, CHỈ cho đúng kiểu "1 đơn vị áp đảo" (an toàn để bắt sớm vì
    // văn bản thật, kể cả cười "ha ha ha" hay nhấn mạnh "khôngggg", gần
    // như không bao giờ đạt tỉ lệ 90%+ ngay cả với mẫu nhỏ) — dùng ngưỡng
    // CAO hơn tiêu chí (a) gốc (90% thay vì 85%) vì mẫu nhỏ hơn, rủi ro
    // trùng hợp cao hơn, cần khắt khe hơn để bù lại.
    if (hasEarlyFlood()) return true;

    if (accumulated_.size() < 320) return false;
    const size_t windowBytes = 200;
    std::string tail = accumulated_.size() > windowBytes
        ? accumulated_.substr(accumulated_.size() - windowBytes)
        : accumulated_;
    std::string compactBytes;
    compactBytes.reserve(tail.size());
    for (char c : tail) {
      if (!std::isspace(static_cast<unsigned char>(c))) compactBytes.push_back(c);
    }
    if (compactBytes.size() < 60) return false;
    const std::vector<std::string> compact = splitUtf8Units(compactBytes);
    // Trần theo SỐ KÝ TỰ (không phải byte) — 20 ký tự tiếng Việt có dấu
    // vẫn thừa đủ căn cứ (tương đương ngưỡng 60 byte cũ đã dùng cho ASCII
    // thuần), tránh đòi hỏi quá nhiều mới chịu kết luận trên văn bản đa byte.
    if (compact.size() < 20) return false;

    // (a) 1 ĐƠN VỊ (ký tự UTF-8 thật, không phải byte) chiếm áp đảo — vẫn
    // khớp đúng 2 mẫu ASCII cũ ("(((((", "8888888": mỗi ký tự đúng 1
    // byte = 1 đơn vị, không đổi hành vi), VÀ giờ khớp thêm cả lặp 1 ký
    // tự tiếng Việt có dấu duy nhất.
    std::unordered_map<std::string, int> counts;
    counts.reserve(compact.size());
    for (const auto& unit : compact) counts[unit]++;
    int maxCount = 0;
    for (const auto& kv : counts) maxCount = std::max(maxCount, kv.second);
    if (static_cast<double>(maxCount) / static_cast<double>(compact.size()) > 0.85) return true;

    // (b) 1 cụm ngắn (2 tới ~1/3 cửa sổ ĐƠN VỊ) lặp khít cả cửa sổ.
    // ĐÃ SỬA — mục BK, 2026-09-20 — LỖ HỔNG THẬT xác nhận qua log thật
    // (tầng Dart, cùng lỗ hổng — xem giải thích đầy đủ ở
    // `local_provider.dart`/`_looksLikeRepetitionLoop`): model lặp 1 CỤM
    // TỪ hoàn chỉnh ("Hãy cho tôi biết nhé!" ~60 lần) — trần cũ period<=6
    // ĐƠN VỊ chỉ đủ bắt lặp 1 KÝ TỰ hoặc cụm rất ngắn, không đủ cho 1 cụm
    // từ tiếng Việt thông thường (thường dài hơn 6 ký tự nhiều). Mở rộng
    // trần lên tới 1/3 kích thước cửa sổ (tối đa 60 đơn vị) — AN TOÀN với
    // văn bản thật vì phép kiểm vẫn yêu cầu TOÀN BỘ cửa sổ khớp đúng 1
    // cụm lặp lại đó, không phải chỉ 1 đoạn nhỏ trùng nhau — hoàn toàn
    // KHÔNG đụng tới sampler/set_config/mixed_samplers (đây là hàm thuần
    // so khớp chuỗi, tách biệt hẳn khỏi đúng phần từng gây treo máy ở mục
    // AL/AM).
    const size_t maxPeriod = std::min<size_t>(60, compact.size() / 3);
    for (size_t period = 2; period <= maxPeriod; ++period) {
      bool matches = true;
      for (size_t i = 0; i < compact.size() && matches; ++i) {
        if (compact[i] != compact[i % period]) matches = false;
      }
      if (matches) return true;
    }

    // (c) ĐÃ THÊM — mục BQ, 2026-09-23 — LỖ HỔNG THẬT xác nhận qua log +
    // ảnh chụp màn hình thật (prompt "xin chào", model trả lặp nguyên 1
    // CÂU DÀI ~200+ ký tự về việc đăng ký tài khoản "24pay.biz" — hoàn
    // toàn lạc đề, không liên quan gì tới prompt). Tiêu chí (a)/(b) phía
    // trên KHÔNG bắt được vì 2 lý do CÙNG LÚC:
    //   - (a) cần 1 ĐƠN VỊ chiếm >85% cửa sổ — câu văn bình thường đủ đa
    //     dạng ký tự, không đơn vị nào áp đảo.
    //   - (b) chỉ thử period TỐI ĐA 60 đơn vị — câu văn tiếng Việt bình
    //     thường (không phải 1 cụm từ ngắn kiểu "Hãy cho tôi biết nhé!"
    //     ở mục BK) dài hơn 60 ký tự RẤT NHIỀU, vượt hẳn trần này dù lặp
    //     NGUYÊN VẸN — bằng chứng thật: câu đầu tiên trong ảnh chụp dài
    //     hơn 200 ký tự, lặp Y HỆT 2 lần liên tiếp, không bộ dò nào ở
    //     trên phát hiện được, phải đợi người dùng tự bấm Huỷ sau 1557
    //     ký tự.
    // Cách khác hẳn (a)/(b) — không dùng cửa sổ cố định/period cố định
    // nữa, mà TÁCH CÂU (theo dấu . ! ? xuống dòng — an toàn với UTF-8 vì
    // 4 ký tự này luôn 1 byte ASCII, không bao giờ là byte nối tiếp của
    // 1 ký tự đa byte) trên TOÀN BỘ `accumulated_`, rồi so CÂU VỪA HOÀN
    // CHỈNH gần nhất với vài câu hoàn chỉnh TRƯỚC ĐÓ — bắt được lặp CẢ
    // CÂU bất kể câu đó dài bao nhiêu, không bị trần 60 giới hạn.
    if (hasSentenceLevelRepeat()) return true;
    return false;
  }

  // Tách theo 4 dấu kết câu ASCII (. ! ? và xuống dòng) — cố ý ĐƠN GIẢN
  // (không xử lý viết tắt kiểu "vd.", số thập phân "1.5"...) vì mục đích
  // ở đây là bắt LẶP THẬT (câu sau trùng y hệt câu trước), không phải
  // tách câu chuẩn ngôn ngữ học — tách sai 1 chỗ (vd cắt giữa domain
  // "24pay.biz" thành 2 mảnh) chỉ tạo thêm vài "câu" ngắn vô hại, bị lọc
  // bởi ngưỡng độ dài tối thiểu bên dưới, không gây báo giả.
  static std::vector<std::string> splitSentences(const std::string& text) {
    std::vector<std::string> out;
    size_t start = 0;
    for (size_t i = 0; i < text.size(); ++i) {
      char c = text[i];
      if (c == '.' || c == '!' || c == '?' || c == '\n') {
        out.push_back(text.substr(start, i - start + 1));
        start = i + 1;
      }
    }
    if (start < text.size()) out.push_back(text.substr(start));
    return out;
  }

  // Chuẩn hoá để so sánh: gộp mọi khoảng trắng liên tiếp thành 1 dấu
  // cách, hạ hoa/thường CHỈ với ASCII (an toàn — không gọi tolower() trên
  // byte >=0x80, tránh hành vi không xác định với byte nối tiếp UTF-8).
  static std::string normalizeForCompare(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    bool lastSpace = false;
    for (unsigned char c : s) {
      if (std::isspace(c)) {
        if (!lastSpace && !out.empty()) out.push_back(' ');
        lastSpace = true;
      } else {
        if (c >= 'A' && c <= 'Z') c = static_cast<unsigned char>(c - 'A' + 'a');
        out.push_back(static_cast<char>(c));
        lastSpace = false;
      }
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
  }

  bool hasSentenceLevelRepeat() const {
    const auto sentences = splitSentences(accumulated_);
    if (sentences.size() < 2) return false;
    // Câu CUỐI CÙNG trong danh sách có thể đang viết dở (hàm này chạy ở
    // MỌI token, không chỉ lúc vừa hết câu) — chỉ tính là "đã hoàn
    // chỉnh" nếu chính `accumulated_` đang kết thúc bằng 1 trong 4 dấu
    // kết câu, bỏ qua phần dở dang cuối nếu không.
    const char lastChar = accumulated_.empty() ? '\0' : accumulated_.back();
    const bool lastComplete = (lastChar == '.' || lastChar == '!' ||
        lastChar == '?' || lastChar == '\n');
    const size_t completeCount = lastComplete ? sentences.size() : sentences.size() - 1;
    if (completeCount < 2) return false;

    // ĐÃ SỬA — LỖ HỔNG THẬT tự phát hiện qua test (không phải đọc code
    // suông): 2 dấu kết câu đứng LIỀN NHAU (vd ".\n" — dấu chấm hết câu
    // rồi xuống dòng ngay sau) sinh ra 1 MẢNH RỖNG ở cuối danh sách
    // `sentences` — nếu lấy thẳng `sentences[completeCount-1]` làm "câu
    // hoàn chỉnh gần nhất" như bản đầu, sẽ vớ đúng mảnh RỖNG đó (không
    // phải câu thật ngay trước nó), luôn dưới ngưỡng 25 ký tự, khiến hàm
    // LUÔN trả về false — VÔ HIỆU HOÀN TOÀN, kể cả khi có lặp thật ngay
    // trước đó. Sửa bằng cách LỌC trước: chỉ giữ các câu ĐỦ DÀI (>=25 ký
    // tự sau chuẩn hoá) trong số các câu ĐÃ HOÀN CHỈNH, rồi mới so câu
    // cuối của danh sách ĐÃ LỌC với vài câu trước đó trong CHÍNH danh
    // sách đã lọc — không còn dính mảnh rỗng/quá ngắn xen giữa.
    std::vector<std::string> meaningful;
    meaningful.reserve(completeCount);
    for (size_t i = 0; i < completeCount; ++i) {
      std::string norm = normalizeForCompare(sentences[i]);
      if (norm.size() >= 25) meaningful.push_back(std::move(norm));
    }
    if (meaningful.size() < 2) return false;
    const std::string& lastSentence = meaningful.back();
    const size_t lookback = std::min<size_t>(8, meaningful.size() - 1);
    for (size_t k = 1; k <= lookback; ++k) {
      if (meaningful[meaningful.size() - 1 - k] == lastSentence) return true;
    }
    return false;
  }

  JNIEnv* env_;
  jobject callback_;
  jmethodID method_;
  int slot_;
  std::string accumulated_;
};
}

namespace {
// ĐÃ SỬA (2026-08-30): thêm epoch — xem giải thích đầy đủ ở khai báo
// g_slotEpoch. Chỉ xoá cờ g_generatingInProgress nếu epoch LÚC BẮT ĐẦU
// vẫn còn khớp epoch HIỆN TẠI — nếu khác (đã có 1 lần nạp model mới xảy
// ra ở GIỮA lúc lệnh này đang chạy), nghĩa là cờ hiện tại KHÔNG còn
// thuộc về lệnh này nữa (đã thuộc về 1 lệnh MỚI khác, chạy trên object
// mới) — không được đụng vào, để tránh xoá nhầm cờ của lệnh mới.
//
// ĐÃ SỬA THÊM (2026-08-31 — bug THẬT do chính lần sửa 2026-08-30 gây ra,
// xác nhận qua log thật: "BI TU CHOI — da co 1 lenh nap model khac cho
// slot 0 dang chay chua xong" xuất hiện dù lần nạp TRƯỚC đó đã trả về
// THÀNH CÔNG hơn 1 phút trước đó): `epochs` giờ CHO PHÉP là `nullptr` —
// nghĩa là "luôn xoá cờ vô điều kiện lúc kết thúc, không cần kiểm tra
// epoch gì cả" — dùng cho `g_loadingInProgress` (guard bảo vệ chính
// `nativeLoadModel()`). Lý do PHẢI tách riêng: chính `nativeLoadModel()`
// (hàm SỞ HỮU guard này) lại là nơi TĂNG epoch (sau khi nạp xong) — nếu
// dùng chung kiểu kiểm tra epoch như `g_generatingInProgress`, đến lúc
// guard này kết thúc (cuối hàm), epoch ĐÃ bị chính hàm đó tăng lên rồi
// → điều kiện "epoch còn khớp" LUÔN LUÔN SAI → cờ `g_loadingInProgress`
// không bao giờ được xoá nữa, KẸT VĨNH VIỄN ở `true` sau lần nạp THÀNH
// CÔNG ĐẦU TIÊN — đúng khớp lỗi thật vừa xảy ra. Epoch chỉ có ý nghĩa
// bảo vệ cho `g_generatingInProgress` (guard sống trong 1 hàm KHÁC —
// `nativeGenerate()` — không phải hàm tự tăng epoch), không áp dụng
// được cho chính hàm tăng epoch.
struct LoadingGuard {
  int slotIdx;
  std::atomic<bool>* flags;
  std::atomic<long long>* epochs;  // nullptr = luôn xoá vô điều kiện, không kiểm tra epoch
  long long epochAtStart;
  LoadingGuard(int s, std::atomic<bool>* f, std::atomic<long long>* e)
      : slotIdx(s), flags(f), epochs(e), epochAtStart(e ? e[s].load() : 0) {}
  ~LoadingGuard() {
    if (epochs == nullptr || epochs[slotIdx].load() == epochAtStart) {
      flags[slotIdx].store(false);
    }
  }
};
}


extern "C" {

JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeSetLogDir(
    JNIEnv* env, jobject /* this */, jstring dir) {
  const char* dirChars = env->GetStringUTFChars(dir, nullptr);
  g_logDir = std::string(dirChars);
  env->ReleaseStringUTFChars(dir, dirChars);
  strncpy(g_logDirBufForSignal, g_logDir.c_str(), sizeof(g_logDirBufForSignal) - 1);
  installCrashSignalHandlerOnce();
  nativeLog("nativeSetLogDir: da nhan duong dan log: " + g_logDir + " (da cai bo bat crash tu viet)");
}

// ĐÃ THÊM: cache dir riêng cho OpenCL kernel tuning cache (tmp_path) —
// dùng context.cacheDir bên Kotlin (khác thư mục log/files), vì đây là
// dữ liệu tạm có thể xoá an toàn bất cứ lúc nào (Android tự dọn khi cần
// thêm dung lượng), không nên lẫn với log debug cần giữ lại để chẩn đoán.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeSetCacheDir(
    JNIEnv* env, jobject /* this */, jstring dir) {
  const char* dirChars = env->GetStringUTFChars(dir, nullptr);
  g_cacheDir = std::string(dirChars);
  env->ReleaseStringUTFChars(dir, dirChars);
  nativeLog("nativeSetCacheDir: da nhan duong dan cache OpenCL tuning: " + g_cacheDir);
}

JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeLoadModel(
    JNIEnv* env, jobject /* this */, jint slot, jstring configPath, jint backendPreference) {
  if (slot < 0 || slot >= kMaxSlots) {
    LOGE("Slot khong hop le: %d", slot);
    return JNI_FALSE;
  }
  bool expected = false;
  if (!g_loadingInProgress[slot].compare_exchange_strong(expected, true)) {
    nativeLog("nativeLoadModel: BI TU CHOI — da co 1 lenh nap model khac cho slot " +
        std::to_string(slot) + " dang chay chua xong.");
    return JNI_FALSE;
  }
  LoadingGuard loadingGuard(slot, g_loadingInProgress, nullptr);

  const char* pathChars = env->GetStringUTFChars(configPath, nullptr);
  std::string rawPath(pathChars);
  env->ReleaseStringUTFChars(configPath, pathChars);

  std::string path = rawPath;
  auto endsWithJson = [](const std::string& s) {
    return s.size() >= 5 && s.compare(s.size() - 5, 5, ".json") == 0;
  };
  auto fileExists = [](const std::string& p) {
    std::ifstream f(p);
    return f.good();
  };
  auto candidate1 = rawPath + "/config.json";
  auto candidate2 = rawPath + "/llm_config.json";
  if (!endsWithJson(path)) {
    if (fileExists(candidate1)) {
      path = candidate1;
    } else if (fileExists(candidate2)) {
      path = candidate2;
    } else {
      std::string listing;
      DIR* dir = opendir(rawPath.c_str());
      if (dir != nullptr) {
        struct dirent* entry;
        int count = 0;
        while ((entry = readdir(dir)) != nullptr) {
          std::string name(entry->d_name);
          if (name == "." || name == "..") continue;
          listing += name + " | ";
          ++count;
        }
        closedir(dir);
        if (count == 0) listing = "(thu muc RONG)";
      } else {
        listing = "(KHONG MO DUOC thu muc)";
      }
      nativeLog("nativeLoadModel: CANH BAO — khong tim thay config.json. File trong thu muc: " + listing);
    }
  }
  nativeLog("nativeLoadModel: duong dan config THAT dung de goi createLLM: " + path);
  // ĐÃ THÊM: chẩn đoán ĐẦY ĐỦ trước khi thử nạp — xem giải thích ở
  // `logConfigDiagnostics()` phía trên. Chạy TRƯỚC MỌI lần gọi createLLM(),
  // không chỉ khi nghi ngờ lỗi — vì lần fail có thể xảy ra bất kỳ lúc nào,
  // không đoán trước được, nên luôn ghi lại để có sẵn trong log nếu cần.
  logConfigDiagnostics(path, rawPath);

  auto& llmSlot = g_slots[slot];
  // ĐÃ SỬA (2026-08-30 — theo yêu cầu người dùng: "lần sau chat phải nạp
  // lại NGAY, không đợi, không crash"): TRƯỚC ĐÂY dòng `llmSlot.reset(...)`
  // ngay dưới đây HUỶ THẲNG object `Llm` cũ — nếu 1 lệnh `nativeGenerate()`
  // từ phiên TRƯỚC (mồ côi, có thể treo thật) vẫn còn giữ con trỏ tới
  // ĐÚNG object đó, huỷ xong sẽ gây use-after-free thật (crash SIGSEGV,
  // từng xác nhận qua log CI) — nên trước đây phải TỪ CHỐI nạp model mới
  // hẳn trong trường hợp này, bắt người dùng đợi/tự xử lý thủ công.
  // GIỜ KHÔNG CÒN CẦN TỪ CHỐI NỮA: `g_slots` đã đổi sang `shared_ptr` (xem
  // khai báo phía trên) — lệnh generate() mồ côi đó (nếu có) đang giữ
  // RIÊNG 1 bản sao shared_ptr của chính nó (`slotShared()` trong
  // nativeGenerate) — dòng `llmSlot.reset(newLlm)` bên dưới chỉ THAY THẾ
  // con trỏ trong g_slots[slot], KHÔNG huỷ object cũ ngay nếu vẫn còn ai
  // giữ tham chiếu — an toàn tuyệt đối để nạp model mới NGAY LẬP TỨC, dù
  // lệnh cũ có đang treo thật hay không. Chỉ còn ghi log để biết (không
  // còn ảnh hưởng gì tới việc nạp model mới có thành công hay không).
  if (g_generatingInProgress[slot].load()) {
    auto stuckMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - g_generateStartTime[slot]).count();
    nativeLog("nativeLoadModel: slot " + std::to_string(slot) +
        " dang co 1 lenh generate() TU PHIEN TRUOC van con chay do (mo coi), DA TREO KHOANG " +
        std::to_string(stuckMs / 1000) + " GIAY — VAN TIEP TUC nap model moi ngay (an toan nho shared_ptr, "
        "khong con TU CHOI nhu truoc nua). Lenh mo coi do se tu ket thuc bat cu luc nao (hoac khong bao gio), "
        "khong con anh huong toi model MOI dang chuan bi nap.");
  }
  try {
    // ĐÃ SỬA (theo đầu mối chính xác người dùng chỉ ra: "chạy 1 mình thì
    // bình thường, nhưng chạy SAU 1 model khác thì sinh rác — kể cả Qwen
    // 7B" — đây là dấu hiệu KINH ĐIỂN của trạng thái sót lại giữa 2 lần
    // nạp model trong CÙNG 1 tiến trình, không phải do máy nóng như tôi
    // đoán nhầm trước đó): dòng `llmSlot.reset(Llm::createLLM(path))` CŨ
    // có 1 vấn đề thứ tự tinh vi — C++ ĐÁNH GIÁ `Llm::createLLM(path)`
    // (nạp + khởi tạo model MỚI, bao gồm cấp phát tài nguyên GPU/OpenCL)
    // TRƯỚC KHI `reset()` huỷ object CŨ — nghĩa là trong lúc model MỚI
    // đang khởi tạo, model CŨ (nếu có) VẪN CÒN SỐNG, tài nguyên GPU/OpenCL
    // của nó (buffer, command queue, cache tuning...) vẫn chưa được giải
    // phóng. Nếu backend OpenCL của MNN có BẤT KỲ trạng thái dùng chung
    // (global/static, không tách riêng theo từng object `Llm`) — điều rất
    // phổ biến ở các engine GPU vì hiệu năng — model MỚI có thể "thừa
    // hưởng" nhầm trạng thái/tài nguyên còn dở dang của model CŨ, sinh ra
    // đúng kiểu lỗi đã gặp (model tốt khi chạy MỘT MÌNH, hỏng khi chạy SAU
    // model khác). Sửa: huỷ HẲN model CŨ trước (giải phóng sạch tài nguyên
    // GPU), rồi MỚI khởi tạo model mới — đảm bảo không có 2 model cùng
    // "sống" trên GPU cùng lúc dù chỉ trong khoảnh khắc ngắn.
    //
    // ĐÃ THÊM (theo yêu cầu người dùng: "sao không làm log bắt bug ở tầng
    // này"): log VmRSS (bộ nhớ RAM thật) ở 3 mốc quanh việc đổi model +
    // số lần đã nạp vào slot này từ đầu tiến trình — để LẦN SAU NẾU CÒN
    // LẶP LẠI, có SỐ LIỆU THẬT đối chiếu thay vì chỉ có mô tả cảm tính.
    const int loadCountSoFar = g_loadCountInProcess[slot].load();
    const bool hadPreviousModelInThisSlot = static_cast<bool>(llmSlot);
    const long rssBeforeDestroy = readVmRssKb();
    nativeLog("nativeLoadModel: [CHAN DOAN DOI MODEL] lan nap thu " + std::to_string(loadCountSoFar + 1) +
        " vao slot " + std::to_string(slot) + " trong tien trinh nay; slot TRUOC DO " +
        (hadPreviousModelInThisSlot ? "DA CO model khac dang nap" : "TRONG (chua nap gi)") +
        "; VmRSS TRUOC KHI huy model cu = " + std::to_string(rssBeforeDestroy) + " kB");
    nativeLog("nativeLoadModel: huy HAN model CU (neu co) truoc — giai phong tai nguyen GPU/OpenCL sach se truoc khi nap model moi...");
    // ĐÃ THÊM (2026-08-29 — theo yêu cầu người dùng: cần biết CHÍNH XÁC
    // từng bước "nạp lại" mất bao lâu, không đoán mù nữa, trước khi quyết
    // định có đáng thử bỏ bớt bước nào không): đo riêng thời gian của
    // reset() / createLLM() / load() — 3 khoảng RÕ RÀNG, không gộp chung
    // như trước.
    auto tResetStart = std::chrono::steady_clock::now();
    llmSlot.reset();
    auto tResetEnd = std::chrono::steady_clock::now();
    const long rssAfterDestroy = readVmRssKb();
    nativeLog("nativeLoadModel: [CHAN DOAN DOI MODEL] VmRSS SAU KHI huy model cu = " + std::to_string(rssAfterDestroy) +
        " kB (giam " + std::to_string(rssBeforeDestroy - rssAfterDestroy) +
        " kB — neu con so nay GAN 0 hoac AM du model cu ro rang co du lieu, la BANG CHUNG tai nguyen CHUA duoc giai phong that su)" +
        " — reset() mat " + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(tResetEnd - tResetStart).count()) + "ms");
    nativeLog("nativeLoadModel: CHUAN BI goi Llm::createLLM()");
    auto tCreateStart = std::chrono::steady_clock::now();
    Llm* newLlm = Llm::createLLM(path);
    llmSlot.reset(newLlm);
    auto tCreateEnd = std::chrono::steady_clock::now();
    const long rssAfterCreate = readVmRssKb();
    g_loadCountInProcess[slot].fetch_add(1);
    // ĐÃ THÊM (2026-08-27): object Llm hoàn toàn mới vừa được tạo — không
    // còn lý do gì để tiếp tục coi slot này "không an toàn để dùng" từ
    // lần dừng-giữa-chừng trước đó (nếu có). Xem giải thích ở khai báo
    // g_slotNeedsFullReload.
    g_slotNeedsFullReload[slot].store(false);
    // ĐÃ THÊM (2026-08-30): object MỚI tinh — CHƯA có gì đang generate
    // trên nó cả, dù object CŨ (nếu có lệnh mồ côi) đang báo
    // g_generatingInProgress=true. Đặt lại false ở đây để phản ánh ĐÚNG
    // trạng thái của object HIỆN TẠI (mới), không phải object cũ đã bị
    // thay thế. Tăng epoch TRƯỚC khi đặt lại cờ — để LoadingGuard của
    // lệnh generate() cũ (mồ côi, nếu/khi nó cuối cùng cũng trả về) biết
    // mình đã "lỗi thời", không xoá nhầm cờ này nếu 1 lệnh MỚI đã bắt đầu
    // dùng nó trong lúc đó — xem giải thích đầy đủ ở LoadingGuard.
    g_slotEpoch[slot].fetch_add(1);
    g_generatingInProgress[slot].store(false);
    nativeLog("nativeLoadModel: [CHAN DOAN DOI MODEL] VmRSS SAU KHI tao model moi (truoc luc goi load()) = " +
        std::to_string(rssAfterCreate) + " kB (tang " + std::to_string(rssAfterCreate - rssAfterDestroy) + " kB)" +
        " — createLLM() mat " + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(tCreateEnd - tCreateStart).count()) + "ms");
    nativeLog("nativeLoadModel: Llm::createLLM() TRA VE XONG (khong crash)");
    if (!llmSlot) {
      LOGE("createLLM tra ve null cho path: %s (slot %d)", path.c_str(), slot);
      return JNI_FALSE;
    }

    if (backendPreference == 3) {
      // ĐÃ CHUYỂN (trước đây là backendPreference == 0, mặc định): thử
      // QNN trước rồi mới rơi xuống OpenCL. Sau khi xác nhận rõ ràng
      // Hexagon 780 (v68) trên máy này nằm DƯỚI mức Qualcomm chính thức
      // hỗ trợ LLM-trên-NPU (yêu cầu v73+ theo tài liệu Qualcomm AI Hub/
      // Genie), việc thử QNN mỗi lần mở model chỉ tốn thời gian chờ vô
      // ích (tới 90s/lần) mà không có cơ hội thành công thật. Đường này
      // giờ CHỈ chạy khi người dùng chủ động chọn (giá trị 3) — ví dụ
      // nếu sau này đổi sang máy chip mới hơn (Snapdragon 8 Gen 2+) và
      // muốn thử lại. Mặc định (0) giờ đi thẳng OpenCL tối ưu bên dưới.
      constexpr int kQnnProbeTimeoutSeconds = 90;
      nativeLog("nativeLoadModel: CHUAN BI probe QNN trong tien trinh con (gioi han " +
          std::to_string(kQnnProbeTimeoutSeconds) + "s) truoc khi thu that o tien trinh chinh");
      bool qnnProbeOk = probeQnnLoadInChildProcess(path, kQnnProbeTimeoutSeconds);

      bool qnnSucceeded = false;
      if (qnnProbeOk) {
        try {
          nativeLog("nativeLoadModel: probe QNN THANH CONG, CHUAN BI goi llmSlot->load() THAT o tien trinh chinh");
          llmSlot->set_config(R"({"backend_type": "qnn", "use_mmap": true, "mixed_samplers": ["penalty", "topK", "tfs", "typical", "topP", "min_p", "temperature"], "use_template": false})");
          bool loadOk = llmSlot->load();
          nativeLog(std::string("nativeLoadModel: llmSlot->load() (QNN, that) TRA VE = ") + (loadOk ? "true" : "FALSE"));
          if (loadOk) qnnSucceeded = true;
        } catch (const std::exception& qnnErr) {
          nativeLog(std::string("nativeLoadModel: QNN nem exception o LAN LOAD THAT (probe da qua nhung lan nay van loi): ") + qnnErr.what());
        }
      } else {
        nativeLog("nativeLoadModel: probe QNN THAT BAI/TREO/CRASH — bo qua hoan toan buoc load QNN that, chuyen fallback ngay");
      }

      if (qnnSucceeded) {
        LOGI("Slot %d: nap model thanh cong voi backend QNN: %s", slot, path.c_str());
        g_activeBackend[slot] = "qnn";
        return JNI_TRUE;
      }
      nativeLog("nativeLoadModel: QNN khong thanh cong, thu fallback OpenCL (GPU, da toi uu)");
    }

    if (backendPreference == 0 || backendPreference == 1 || backendPreference == 3) {
      // ĐÃ SỬA: dùng buildOptimizedOpenCLConfig() thay vì chuỗi cứng cũ
      // chỉ có backend_type + use_mmap — xem giải thích đầy đủ ở định
      // nghĩa hàm buildOptimizedOpenCLConfig() phía trên.
      try {
        // ĐÃ THÊM (mục AO, 2026-09-13 — sau khi mục AM/AN không rõ có thật
        // sự áp dụng "penalty" hay không: log trước giờ chỉ in "da toi uu"
        // chung chung, chưa từng in ĐÚNG nội dung JSON gửi vào set_config
        // lúc load — không có cách nào xác nhận `mixed_samplers` có mặt
        // thật hay không từ log cũ). Ghi thẳng chuỗi thật ra log TRƯỚC khi
        // gửi — lần chạy kế tiếp sẽ biết chắc, không cần suy đoán.
        const std::string openclCfg = buildOptimizedOpenCLConfig(rawPath, slot);
        nativeLog("nativeLoadModel: [CHAN DOAN mục AO] config OpenCL THAT gui vao set_config(): " + openclCfg);
        llmSlot->set_config(openclCfg);
        auto tLoadStart = std::chrono::steady_clock::now();
        bool loadOk = llmSlot->load();
        auto tLoadEnd = std::chrono::steady_clock::now();
        nativeLog(std::string("nativeLoadModel: llmSlot->load() (OpenCL, da toi uu) TRA VE = ") + (loadOk ? "true" : "FALSE") +
            " — load() mat " + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(tLoadEnd - tLoadStart).count()) + "ms");
        if (loadOk) {
          LOGI("Slot %d: nap model thanh cong voi backend OpenCL (GPU, da toi uu): %s", slot, path.c_str());
          g_activeBackend[slot] = "opencl";
          return JNI_TRUE;
        }
      } catch (const std::exception& glErr) {
        nativeLog(std::string("nativeLoadModel: OpenCL nem exception: ") + glErr.what());
      }

      // Fallback CPU nếu cả OpenCL cũng thất bại (hiếm, nhưng vẫn cần)
      nativeLog("nativeLoadModel: OpenCL that bai, thu fallback CPU");
      try {
        llmSlot->set_config(R"({"backend_type": "cpu", "use_mmap": true, "precision": "low", "memory": "low", "mixed_samplers": ["penalty", "topK", "tfs", "typical", "topP", "min_p", "temperature"], "use_template": false})");
        bool cpuLoadOk = llmSlot->load();
        nativeLog(std::string("nativeLoadModel: llmSlot->load() (CPU) TRA VE = ") + (cpuLoadOk ? "true" : "FALSE"));
        if (!cpuLoadOk) {
          LOGE("Slot %d: load() that bai voi CA OpenCL lan CPU", slot);
          return JNI_FALSE;
        }
        LOGI("Slot %d: nap model thanh cong voi backend CPU: %s", slot, path.c_str());
        g_activeBackend[slot] = "cpu";
        return JNI_TRUE;
      } catch (const std::exception& cpuErr) {
        nativeLog(std::string("nativeLoadModel: CPU nem exception: ") + cpuErr.what());
        return JNI_FALSE;
      }
    } else {
      llmSlot->set_config(R"({"backend_type": "cpu", "use_mmap": true, "precision": "low", "memory": "low", "mixed_samplers": ["penalty", "topK", "tfs", "typical", "topP", "min_p", "temperature"], "use_template": false})");
      bool loadOk = llmSlot->load();
      nativeLog(std::string("nativeLoadModel: llmSlot->load() (CPU, ep buoc) TRA VE = ") + (loadOk ? "true" : "FALSE"));
      if (!loadOk) return JNI_FALSE;
      g_activeBackend[slot] = "cpu";
      return JNI_TRUE;
    }
  } catch (const std::exception& e) {
    LOGE("Loi nap model slot %d: %s", slot, e.what());
    llmSlot.reset();
    return JNI_FALSE;
  }
}

JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeGenerate(
    JNIEnv* env, jobject /* this */, jint slot, jstring prompt, jstring generationConfigJson, jobject callback) {
  nativeLog("nativeGenerate: BAT DAU, slot=" + std::to_string(slot));
  // ĐÃ SỬA (2026-08-30): giữ 1 BẢN SAO shared_ptr sống suốt cả hàm này —
  // xem giải thích đầy đủ ở khai báo g_slots/slotShared() phía trên. Biến
  // `llmKeepAlive` không dùng trực tiếp bên dưới (dùng raw pointer `llm`
  // cho gọn, y hệt code cũ) nhưng SỰ TỒN TẠI của nó trong suốt hàm này là
  // điều quan trọng nhất — nó giữ object sống dù `g_slots[slot]` có bị 1
  // lệnh nạp model khác THAY THẾ giữa chừng lúc hàm này còn đang chạy.
  std::shared_ptr<Llm> llmKeepAlive = slotShared(slot);
  Llm* llm = llmKeepAlive.get();
  if (!llm) {
    LOGE("nativeGenerate goi khi slot %d chua nap model", slot);
    nativeLog("nativeGenerate: LOI slot chua nap model, dung lai");
    return;
  }
  if (slot < 0 || slot >= kMaxSlots) {
    LOGE("nativeGenerate: slot khong hop le: %d", slot);
    return;
  }
  // ĐÃ THÊM: chốt chặn dự phòng — xem giải thích đầy đủ ở khai báo
  // g_generatingInProgress phía trên. Đây là hàng phòng thủ THỨ 2, hàng
  // THỨ 1 (chính, đúng nghĩa "chờ" chứ không "từ chối") là Mutex theo slot
  // ở MnnBridge.kt — trong điều kiện bình thường, guard này sẽ KHÔNG bao
  // giờ bị kích hoạt vì Kotlin đã xếp hàng đúng trước khi gọi tới đây.
  bool expectedGenerating = false;
  if (!g_generatingInProgress[slot].compare_exchange_strong(expectedGenerating, true)) {
    LOGE("nativeGenerate: TU CHOI — slot %d dang co 1 lenh generate khac chay dang do (khong nen xay ra neu khoa Kotlin hoat dong dung)", slot);
    nativeLog("nativeGenerate: TU CHOI vi phat hien lenh generate KHAC dang chay dong thoi tren cung slot " + std::to_string(slot) +
        " — day la loi bat thuong, khoa Mutex ben Kotlin le ra phai ngan truong hop nay tu truoc");
    return;
  }
  // ĐÃ THÊM (2026-08-27): nếu lệnh generate() TRƯỚC ĐÓ trên slot này từng
  // bị ép dừng giữa chừng bằng exception (stall/lặp/huỷ), object Llm* có
  // thể đã ở trạng thái không nhất quán — xem giải thích đầy đủ ở khai
  // báo g_slotNeedsFullReload phía trên. TỪ CHỐI NGAY tại đây, không chờ
  // llm->response() tự treo rồi mới phát hiện gián tiếp qua đường nạp
  // model khác (như log thật cho thấy: mất tới 12 phút mới biết).
  if (g_slotNeedsFullReload[slot].load()) {
    g_generatingInProgress[slot].store(false);
    nativeLog("nativeGenerate: TU CHOI — slot " + std::to_string(slot) +
        " CAN NAP LAI MODEL truoc (lan generate() truoc do bi ep dung giua chung, object Llm co the khong con dung trang thai)");
    jclass cbClass = env->GetObjectClass(callback);
    jmethodID tokenMethod = env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;Z)V");
    if (tokenMethod != nullptr) {
      jstring jMsg = env->NewStringUTF(
          "\n\n⚠️ [Cần nạp lại model trước khi tiếp tục — lần sinh văn bản trước đã bị dừng giữa chừng, "
          "trạng thái nội bộ có thể không còn đúng. Hãy đổi sang model khác rồi đổi lại (hoặc khởi động lại app) "
          "trước khi chat tiếp.]");
      env->CallVoidMethod(callback, tokenMethod, jMsg, JNI_TRUE);
      env->DeleteLocalRef(jMsg);
    }
    return;
  }
  g_generateStartTime[slot] = std::chrono::steady_clock::now();
  g_lastProgressMs[slot].store(nowSteadyMs());
  LoadingGuard generatingGuard(slot, g_generatingInProgress, g_slotEpoch);
  // ĐÃ THÊM: reset cờ huỷ về false mỗi lần BẮT ĐẦU 1 lệnh generate() mới —
  // phòng trường hợp lệnh TRƯỚC đó bị huỷ (cờ còn true từ lần trước) mà
  // không được dọn sạch đúng cách.
  if (slot >= 0 && slot < kMaxSlots) g_cancelRequested[slot].store(false);
  nativeLog("nativeGenerate: da lay duoc Llm* cho slot, dang doc prompt string...");
  const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
  std::string promptStr(promptChars);
  env->ReleaseStringUTFChars(prompt, promptChars);
  nativeLog("nativeGenerate: da doc prompt xong, do dai=" + std::to_string(promptStr.size()));
  {
    std::string preview = promptStr;
    std::replace(preview.begin(), preview.end(), '\n', '|');
    std::string head = utf8SafeHead(preview, 120);
    std::string tail = preview.size() > 120
        ? utf8SafeTail(preview, 120)
        : std::string("(prompt ngan hon 120 ky tu)");
    nativeLog("nativeGenerate: PROMPT DAU: [" + head + "]");
    nativeLog("nativeGenerate: PROMPT CUOI: [" + tail + "]");
  }

  const char* configChars = env->GetStringUTFChars(generationConfigJson, nullptr);
  std::string configStr(configChars);
  env->ReleaseStringUTFChars(generationConfigJson, configChars);
  nativeLog("nativeGenerate: da doc config xong: " + configStr);

  jclass callbackClass = env->GetObjectClass(callback);
  jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;Z)V");
  if (onTokenMethod == nullptr) {
    if (env->ExceptionCheck()) {
      env->ExceptionClear();
    }
    std::string realClassName = "(khong lay duoc)";
    jclass classClass = env->FindClass("java/lang/Class");
    if (classClass != nullptr) {
      jmethodID getNameMethod = env->GetMethodID(classClass, "getName", "()Ljava/lang/String;");
      if (getNameMethod != nullptr) {
        auto jName = (jstring)env->CallObjectMethod(callbackClass, getNameMethod);
        if (jName != nullptr) {
          const char* nameChars = env->GetStringUTFChars(jName, nullptr);
          realClassName = std::string(nameChars);
          env->ReleaseStringUTFChars(jName, nameChars);
          env->DeleteLocalRef(jName);
        }
      }
      env->DeleteLocalRef(classClass);
    }
    nativeLog("nativeGenerate: LOI NGHIEM TRONG — GetMethodID tra ve NULL cho onToken. Ten lop that: " + realClassName);
    LOGE("Slot %d: GetMethodID cho onToken tra ve NULL, class that: %s", slot, realClassName.c_str());
    return;
  }
  nativeLog("nativeGenerate: da lay duoc onTokenMethod, chuan bi set_config...");

  try {
    bool configOk = llm->set_config(configStr);
    nativeLog(std::string("nativeGenerate: set_config KET QUA = ") + (configOk ? "true" : "FALSE"));
  } catch (const std::exception& e) {
    LOGE("Slot %d: khong ap dung duoc config sinh van ban: %s", slot, e.what());
    nativeLog(std::string("nativeGenerate: set_config NEM LOI (van tiep tuc voi mac dinh): ") + e.what());
  }

  JniStreamingBuf streamBuf(env, callback, onTokenMethod, slot);
  std::ostream streamingOut(&streamBuf);
  // ĐÃ SỬA (2026-08-28 — theo yêu cầu người dùng, sau khi bỏ lớp "trì trệ":
  // mốc thời gian này TRƯỚC ĐÂY khai báo TRONG khối try, nên chỉ đo được
  // khi response() TRẢ VỀ THÀNH CÔNG — không đo được khi bị ngắt giữa
  // chừng bởi lặp vô tận/huỷ. Chuyển ra NGOÀI try để đo được ở CẢ 2 khối
  // catch bên dưới nữa — muốn biết máy có ngủ sâu giữa chừng hay không thì
  // cần đo được ở MỌI cách lệnh generate() kết thúc, không riêng gì lúc
  // thành công.
  auto tSteadyStart = std::chrono::steady_clock::now();
  auto tWallStart = std::chrono::system_clock::now();
  try {
    nativeLog("nativeGenerate: CHUAN BI goi llm->response()");
    // ĐÃ SỬA (theo phát hiện thật từ log người dùng — chênh lệch ~379s giữa
    // "THOI GIAN THAT" (steady_clock, KHÔNG đếm lúc máy ngủ sâu) và mốc thời
    // gian tường trong log — xem giải thích đầy đủ ở MnnBridge.kt, khai báo
    // `directWakeLock`): đo THÊM bằng `system_clock` (giờ tường, CÓ đếm cả
    // lúc ngủ sâu) song song với `steady_clock` sẵn có — in cả 2 + chênh
    // lệch ra log, để lần sau (nếu còn xảy ra) thấy NGAY trong 1 dòng log
    // duy nhất thay vì phải tự trừ 2 timestamp ở 2 dòng log khác nhau.
    llm->response(promptStr, &streamingOut, nullptr, -1);
    auto tSteadyEnd = std::chrono::steady_clock::now();
    auto tWallEnd = std::chrono::system_clock::now();
    long long elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(tSteadyEnd - tSteadyStart).count();
    long long wallMs = std::chrono::duration_cast<std::chrono::milliseconds>(tWallEnd - tWallStart).count();
    long long suspendGapMs = wallMs - elapsedMs;
    nativeLog("nativeGenerate: llm->response() TRA VE XONG, do dai ket qua=" +
        std::to_string(streamBuf.accumulated().size()) + ", THOI GIAN THAT (ms)=" + std::to_string(elapsedMs) +
        ", THOI GIAN TUONG (ms)=" + std::to_string(wallMs) +
        (suspendGapMs > 3000
             ? (", !!! CHENH LECH " + std::to_string(suspendGapMs) +
                "ms — RẤT CÓ THỂ máy đã ngủ sâu giữa chừng (steady_clock không đếm lúc ngủ sâu, "
                "system_clock có đếm) !!!")
             : ""));
    {
      const auto* ctx = llm->getContext();
      if (ctx != nullptr) {
        nativeLog("nativeGenerate: LlmContext — status=" + std::to_string(static_cast<int>(ctx->status)) +
            ", prompt_len=" + std::to_string(ctx->prompt_len) +
            ", gen_seq_len=" + std::to_string(ctx->gen_seq_len));
      }
    }
    if (streamBuf.accumulated().empty()) {
      nativeLog("nativeGenerate: CANH BAO — ket qua RONG. Kiem tra tokenizer/EOS id/chat template.");
    }

    jstring jDone = env->NewStringUTF("");
    nativeLog("nativeGenerate: gui tin hieu DONE...");
    env->CallVoidMethod(callback, onTokenMethod, jDone, JNI_TRUE);
    nativeLog("nativeGenerate: CallVoidMethod (DONE) xong");
    env->DeleteLocalRef(jDone);
  } catch (const GenerationStoppedException& e) {
    // ĐÃ SỬA (thêm nhánh thứ 3 — trì trệ/stall — bên cạnh huỷ/lặp vô tận):
    // tách khỏi lỗi thật (exception khác) để log rõ ràng, không làm người
    // dùng tưởng nhầm là app bị lỗi/crash khi thực ra đây là hành vi ĐÚNG
    // NHƯ THIẾT KẾ.
    // ĐÃ THÊM (2026-08-27): đánh dấu slot cần nạp lại — xem giải thích ở
    // khai báo g_slotNeedsFullReload. Dừng bằng exception giữa chừng
    // response() không phải huỷ "sạch" đối với nội bộ MNN.
    g_slotNeedsFullReload[slot].store(true);
    // ĐÃ THÊM (2026-08-28): đo steady vs wall NGAY CẢ khi bị ngắt giữa
    // chừng (huỷ/lặp vô tận) — xem giải thích ở khai báo tSteadyStart phía
    // trên. Trước đây phép đo này CHỈ có ở nhánh thành công.
    {
      long long elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::steady_clock::now() - tSteadyStart).count();
      long long wallMs = std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::system_clock::now() - tWallStart).count();
      long long suspendGapMs = wallMs - elapsedMs;
      nativeLog(std::string("nativeGenerate: DA DUNG SOM CHU DONG — ") + e.what() +
          " (da sinh duoc " + std::to_string(streamBuf.accumulated().size()) + " ky tu truoc do)" +
          " — STEADY (ms)=" + std::to_string(elapsedMs) + ", WALL (ms)=" + std::to_string(wallMs) +
          (suspendGapMs > 3000
               ? (", !!! CHENH LECH " + std::to_string(suspendGapMs) +
                  "ms — RAT CO THE may da ngu sau GIUA CHUNG !!!")
               : ", khong chenh lech dang ke"));
    }
    // ĐÃ THÊM (mục AI, 2026-09-11 — theo yêu cầu người dùng, sau khi xác
    // nhận repetitionPenalty KHÔNG phải nguyên nhân "60 ký tự" tái diễn ở
    // MỌI lần test dù penalty đổi 1.05→1.15): dòng log TRÊN chỉ ghi SỐ
    // LƯỢNG ký tự, chưa từng ghi NỘI DUNG THẬT — không ai (kể cả người sửa
    // lỗi) từng thấy CHÍNH XÁC cái gì bị coi là "lặp". Ghi thẳng toàn bộ
    // `accumulated()` ra log — an toàn vì tại đây chỉ mới vài chục byte
    // (ngưỡng kiểm tra tối thiểu, xem `looksLikeRepetitionLoop`), không
    // phải hàng nghìn ký tự của cả chương. Dùng thẳng `e.what()` (không
    // phải biến `reason` — biến đó khai báo NGAY SAU đây, chưa tồn tại ở
    // đây) để tránh phụ thuộc thứ tự khai báo.
    // ĐÃ SỬA (mục AT, 2026-09-14 — theo phát hiện đúng của người dùng: tự
    // mắt thấy chữ F lặp trên màn hình lúc bấm Huỷ, nhưng log lại KHÔNG hề
    // có — vì điều kiện dưới đây trước đó CHỈ log khi lý do chứa "lap vo
    // tan" (bộ dò tự động phát hiện), bỏ sót hoàn toàn trường hợp NGƯỜI
    // DÙNG tự bấm Huỷ — dù đây mới chính là lúc CẦN thấy nội dung thật
    // nhất, vì người dùng đã tự mắt thấy có gì đó bất thường rồi mới bấm).
    // Bỏ hẳn điều kiện lọc theo lý do — ghi nội dung tích luỹ ở MỌI trường
    // hợp dừng sớm (tự động phát hiện lặp HAY người dùng tự huỷ), không
    // phân biệt nữa. An toàn vì đây luôn là dừng SỚM (tối đa vài trăm-vài
    // nghìn ký tự tới thời điểm dừng, không phải cả chương dài).
    nativeLog("nativeGenerate: [NOI DUNG LUC DUNG SOM] toan bo da tich luy: [" +
        streamBuf.accumulated() + "]");
    // ĐÃ THÊM — mục BB, 2026-09-17 (theo đúng phản hồi người dùng: không
    // được cứ đòi thêm bằng chứng rồi không tự làm gì) — "PROMPT DAU"/"PROMPT
    // CUOI" ở trên chỉ ghi 120 ký tự đầu/cuối, không đủ để tự kiểm tra xem
    // CHÍNH prompt (Story Bible/outline do buildContext dựng) có tự chứa
    // nội dung lặp/trùng lặp hay không — nghi vấn thật đang cân nhắc: có thể
    // đây mới là NGUYÊN NHÂN GỐC (model bắt chước cấu trúc lặp có sẵn trong
    // chính prompt), không phải lỗi ở bộ phạt sampler. Ghi THẲNG TOÀN BỘ
    // prompt ra log CHỈ ở đúng nhánh dừng sớm này (không phải mọi lần
    // generate() bình thường) — an toàn vì đây là sự kiện HIẾM, không phải
    // ghi hàng nghìn ký tự mỗi lần sinh chữ như log thường.
    {
      std::string promptForLog = promptStr;
      std::replace(promptForLog.begin(), promptForLog.end(), '\n', '|');
      nativeLog("nativeGenerate: [MUC BB - TOAN BO PROMPT DA GUI, de kiem tra co tu lap khong] [" +
          promptForLog + "]");
    }
    std::string reason = std::string(e.what());
    std::string userMsg;
    if (reason.find("huy") != std::string::npos) {
      userMsg = "theo yêu cầu huỷ.";
    } else {
      // ĐÃ BỎ (2026-08-28): từng có thêm 1 nhánh "else if reason chứa
      // 'tri tre'" ở đây cho lớp trì trệ — nhánh đó đã thành CHẾT (không
      // còn chỗ nào ném exception với lý do đó nữa, xem mục H) nên xoá,
      // tránh gây hiểu nhầm sau này là lớp trì trệ vẫn còn tồn tại đâu đó.
      userMsg = "phát hiện lặp vô tận ở tầng gốc (native) — bảo vệ này vẫn hoạt động ngay cả khi app đã bị đóng.";
    }
    jstring jStopped = env->NewStringUTF((std::string("\n\n⚠️ [Đã dừng: ") + userMsg + "]").c_str());
    env->CallVoidMethod(callback, onTokenMethod, jStopped, JNI_TRUE);
    env->DeleteLocalRef(jStopped);
  } catch (const std::exception& e) {
    // ĐÃ THÊM (2026-08-27): tương tự nhánh GenerationStoppedException — bất kỳ
    // exception nào ngắt response() giữa chừng đều đáng ngờ với nội bộ MNN.
    g_slotNeedsFullReload[slot].store(true);
    LOGE("Slot %d: loi sinh van ban: %s", slot, e.what());
    // ĐÃ THÊM (2026-08-28): đo steady vs wall — cùng lý do nhánh trên.
    {
      long long elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::steady_clock::now() - tSteadyStart).count();
      long long wallMs = std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::system_clock::now() - tWallStart).count();
      nativeLog(std::string("nativeGenerate: response() NEM exception: ") + e.what() +
          " — STEADY (ms)=" + std::to_string(elapsedMs) + ", WALL (ms)=" + std::to_string(wallMs));
    }
    jstring jError = env->NewStringUTF((std::string("[Loi] ") + e.what()).c_str());
    env->CallVoidMethod(callback, onTokenMethod, jError, JNI_TRUE);
    env->DeleteLocalRef(jError);
  }
  nativeLog("nativeGenerate: KET THUC HAM, khong crash");
}

JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeUnload(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return;
  g_slots[slot].reset();
  g_activeBackend[slot] = "unknown";
}

// ĐÃ THÊM (2026-09-01 — theo yêu cầu người dùng): dọn cache autotuning
// OpenCL định kỳ, KHÔNG loại trừ gì (truyền chuỗi rỗng cho
// currentModelSubdirName — không phân biệt model nào "đang dùng" ở tầng
// native này). ĐÃ ĐỔI TÊN (2026-09-01, cùng ngày) từ
// `nativeCleanupCacheOnExit` — ban đầu chỉ gọi lúc thoát app (xem
// `main.dart`, ngay trước `SystemNavigator.pop()`), sau đó THÊM 1 điểm
// gọi thứ 2 lúc app KHỞI ĐỘNG (xem `MnnBridge.kt`,
// `onMethodCallInner`) — tên cũ gắn với đúng 1 thời điểm gây hiểu lầm khi
// dùng ở thời điểm còn lại, đổi sang tên trung lập theo ĐÚNG VIỆC hàm này
// làm (giữ cache dưới hạn mức), không gắn với thời điểm gọi cụ thể nào.
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeEnforceOpenCLCacheCap(JNIEnv* env, jobject /* this */) {
  if (g_cacheDir.empty()) return;
  std::string tuningRootDir = g_cacheDir + "/opencl_tuning";
  nativeLog("nativeEnforceOpenCLCacheCap: kiem tra don cache opencl_tuning dinh muc");
  pruneOpenCLTuningCacheIfNeeded(tuningRootDir, "");
}

JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeIsLoaded(JNIEnv* env, jobject /* this */, jint slot) {
  return slotOrNull(slot) != nullptr ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeActiveBackend(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return env->NewStringUTF("slot_khong_hop_le");
  std::string backend = slotOrNull(slot) ? g_activeBackend[slot] : "chua_nap_model";
  return env->NewStringUTF(backend.c_str());
}

// ĐÃ THÊM (theo yêu cầu người dùng, phần 1: "làm tiếp phần chặn lặp ở
// tầng gốc"): set cờ huỷ NATIVE cho đúng slot — khác `cancelGenerate`
// (Kotlin) cũ chỉ huỷ Job coroutine bọc ngoài, cờ này được
// `JniStreamingBuf::xsputn` kiểm tra ở NGAY tầng C++, có tác dụng thật
// với `llm->response()` đang chạy (xem giải thích đầy đủ ở khai báo
// g_cancelRequested).
JNIEXPORT void JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeRequestCancel(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return;
  g_cancelRequested[slot].store(true);
  nativeLog("nativeRequestCancel: da dat co huy cho slot " + std::to_string(slot) +
      " — lan ghi token TIEP THEO (neu con) se dung generate() lai");
}

// ĐÃ THÊM (theo yêu cầu người dùng, phần 2: "sao tác vụ nền không báo có
// bất cứ cái gì" — đúng, `BackgroundTaskManager` ở Dart chỉ là 1 List
// trong RAM của phiên hiện tại, KHÔNG biết gì về 1 lệnh generate() mồ côi
// còn sống sót từ phiên TRƯỚC đã bị đóng — vì đối tượng Dart theo dõi nó
// đã mất theo phiên đó. Hàm này cho Dart tầng trên HỎI THẲNG native (nơi
// DUY NHẤT còn giữ sự thật) xem slot có đang thật sự bận không, để hiện
// đúng tình trạng thay vì im lặng khó hiểu.
JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeIsGenerating(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return JNI_FALSE;
  return g_generatingInProgress[slot].load() ? JNI_TRUE : JNI_FALSE;
}

// ĐÃ THÊM (2026-08-29 — theo yêu cầu người dùng, không bắt người dùng tự
// đổi model qua lại/khởi động lại app thủ công nữa): cho Dart hỏi thẳng
// cờ g_slotNeedsFullReload (xem giải thích đầy đủ ở khai báo cờ này phía
// trên) TRƯỚC khi quyết định có gọi loadModel() lại hay không.
JNIEXPORT jboolean JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeNeedsFullReload(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return JNI_FALSE;
  return g_slotNeedsFullReload[slot].load() ? JNI_TRUE : JNI_FALSE;
}

// ĐÃ THÊM (2026-09-05): xem giải thích đầy đủ ở khai báo g_lastProgressMs
// phía trên. Trả về -1 nếu slot HIỆN KHÔNG đang generate (câu hỏi không
// có ý nghĩa) — Dart chỉ gọi hàm này SAU KHI đã xác nhận isSlotGenerating
// = true, tránh đọc nhầm mốc của lệnh ĐÃ XONG từ trước.
JNIEXPORT jlong JNICALL
Java_com_localnovel_mnnbridge_MnnNative_nativeSlotStalledMs(JNIEnv* env, jobject /* this */, jint slot) {
  if (slot < 0 || slot >= kMaxSlots) return -1;
  if (!g_generatingInProgress[slot].load()) return -1;
  return nowSteadyMs() - g_lastProgressMs[slot].load();
}

} // extern "C"
