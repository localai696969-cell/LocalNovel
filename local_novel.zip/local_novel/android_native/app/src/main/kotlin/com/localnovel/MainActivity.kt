package com.localnovel

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.Manifest
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import com.localnovel.mnnbridge.MnnBridge

// Đây là điểm nối duy nhất giữa Flutter và tầng native MNN/QNN. Toàn bộ
// logic thật nằm ở MnnBridge — file này chỉ đăng ký 2 kênh giao tiếp
// chuẩn của Flutter (MethodChannel cho lệnh gọi 1 lần, EventChannel cho
// luồng token trả về liên tục khi sinh văn bản).
class MainActivity : FlutterActivity() {
    private val CHANNEL_METHOD = "com.localnovel/mnn_method"
    private val CHANNEL_EVENT = "com.localnovel/mnn_stream"

    // ĐÃ THÊM: theo yêu cầu người dùng ("cứ như các ứng dụng khác là có
    // nút gạt, ko phải bắt người dùng mất công cài đặt thủ công") — chọn
    // thư mục model qua Storage Access Framework (ACTION_OPEN_DOCUMENT_TREE)
    // thay vì bắt buộc quyền MANAGE_EXTERNAL_STORAGE (Cài đặt thủ công) cho
    // trường hợp thông thường (bộ nhớ trong chính máy). Đây là Activity
    // THẬT duy nhất trong app nên chỉ nó gọi được startActivityForResult()
    // — MnnBridge chỉ là 1 MethodCallHandler thường, không phải Activity,
    // nên được truyền vào 1 hàm callback để nhờ MainActivity mở hộ Intent.
    private val REQUEST_PICK_MODEL_FOLDER = 4201
    private var bridge: MnnBridge? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Android 13+ bắt buộc xin quyền hiển thị thông báo lúc chạy —
        // không có quyền này thì Foreground Service vẫn chạy được,
        // nhưng người dùng sẽ không thấy thông báo "AI đang xử lý".
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }

        val b = MnnBridge(applicationContext, launchFolderPicker = { intent ->
            startActivityForResult(intent, REQUEST_PICK_MODEL_FOLDER)
        })
        bridge = b
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_METHOD)
            .setMethodCallHandler(b)
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_EVENT)
            .setStreamHandler(b)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_MODEL_FOLDER) {
            // resultCode != RESULT_OK (vd RESULT_CANCELED khi bấm back/huỷ
            // trong picker) → coi như chưa chọn gì, uri = null, KHÔNG phải lỗi.
            val uri = if (resultCode == RESULT_OK) data?.data else null
            bridge?.onFolderPicked(uri)
        }
    }
}
