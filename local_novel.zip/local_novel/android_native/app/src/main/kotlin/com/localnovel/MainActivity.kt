package com.localnovel

import android.os.Build
import android.Manifest
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import com.localnovel.mnnbridge.MnnBridge

// Đây là điểm nối duy nhất giữa Flutter và tầng native MNN/QNN. Toàn bộ
// logic thật nằm ở MnnBridge — file này chỉ đăng ký 2 kênh giao tiếp
// chuẩn của Flutter (MethodChannel cho lệnh gọi 1 lần, EventChannel cho
// luồng token trả về liên tục khi sinh văn bản).
//
// ĐÃ THỬ RỒI BỎ (xem mục 5.75 tài liệu kiến trúc): từng thêm
// startActivityForResult/onActivityResult để chọn thư mục qua Storage
// Access Framework — xác nhận qua log thật là KHÔNG hoạt động đúng cho
// nhu cầu app này (duyệt/đổi model liên tục, không phải import 1 lần).
// Đã bỏ hẳn, quay về đúng 1 cơ chế: quyền MANAGE_EXTERNAL_STORAGE, không
// cần Activity Result nào cả — MainActivity vì vậy trở lại đơn giản như
// ban đầu.
class MainActivity : FlutterActivity() {
    private val CHANNEL_METHOD = "com.localnovel/mnn_method"
    private val CHANNEL_EVENT = "com.localnovel/mnn_stream"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Android 13+ bắt buộc xin quyền hiển thị thông báo lúc chạy —
        // không có quyền này thì Foreground Service vẫn chạy được,
        // nhưng người dùng sẽ không thấy thông báo "AI đang xử lý".
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }

        val b = MnnBridge(applicationContext)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_METHOD)
            .setMethodCallHandler(b)
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_EVENT)
            .setStreamHandler(b)
    }
}
