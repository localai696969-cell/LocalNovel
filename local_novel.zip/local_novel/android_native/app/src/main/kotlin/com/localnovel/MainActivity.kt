package com.localnovel

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import com.localnovel.mnnbridge.MnnBridge

// Đây là điểm nối duy nhất giữa Flutter và tầng native MNN/QNN. Toàn bộ
// logic thật nằm ở MnnBridge — file này chỉ đăng ký 2 kênh giao tiếp
// chuẩn của Flutter (MethodChannel cho lệnh gọi 1 lần, EventChannel cho
// luồng token trả về liên tục khi sinh văn bản).
class MainActivity : FlutterActivity() {
    private val CHANNEL_METHOD = "com.localnovel/mnn_method"
    private val CHANNEL_EVENT = "com.localnovel/mnn_stream"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val bridge = MnnBridge()
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_METHOD)
            .setMethodCallHandler(bridge)
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_EVENT)
            .setStreamHandler(bridge)
    }
}
