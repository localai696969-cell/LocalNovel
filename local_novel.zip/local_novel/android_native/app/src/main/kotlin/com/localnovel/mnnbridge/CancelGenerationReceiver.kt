package com.localnovel.mnnbridge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

// ĐÃ THÊM — mục AZ, 2026-09-16 — theo yêu cầu người dùng: cần cách huỷ
// generation MÀ KHÔNG PHẢI mở lại app trước (bấm thẳng nút trên chính
// notification hệ thống). Trước mục này, nút "Hủy" DUY NHẤT nằm trong UI
// Flutter — nếu Activity đã bị Android dọn hẳn trong lúc Foreground Service
// vẫn sống (đúng kiểu "vuốt tắt app ở recent, tác vụ nền báo trống nhưng
// máy vẫn tạo sinh" người dùng mô tả), người dùng buộc phải mở lại app rồi
// mới bấm Hủy được. Nút trên notification (xem
// GenerationService.buildNotification) gắn PendingIntent trỏ THẲNG vào đây.
//
// CỐ Ý gọi qua `MnnBridge.currentInstance?.performFullCancel(slot)` — dùng
// LẠI đúng 1 logic huỷ với MethodChannel "cancelGenerate" (huỷ Job đang
// chờ/đang chạy + đặt cờ huỷ native + reset pipelineDepth + thả WakeLock +
// dừng Foreground Service), không tạo đường huỷ riêng dễ lệch hành vi theo
// thời gian. Huỷ CẢ 2 slot (chính + dịch) vì nút trên notification không
// biết/không cần biết slot nào đang bận — người dùng bấm nút này với ý định
// "dừng hết những gì app đang làm ngay bây giờ", không phân biệt slot.
//
// Đăng ký TĨNH trong AndroidManifest (xem build.yml, cùng chỗ khai báo
// GenerationService) — không đăng ký động qua Context, vì receiver này phải
// nhận được broadcast dù lúc đó KHÔNG có Activity/FlutterEngine nào đang
// gắn (notification có thể bị bấm bất cứ lúc nào).
class CancelGenerationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_CANCEL_ALL) return
        val appContext = context.applicationContext
        // ĐÃ THÊM — mục BB, 2026-09-17 — theo đúng phản hồi người dùng: không
        // được bắt người dùng mở file log mới biết bấm nút có "ăn" hay
        // không. Toast này hiện ra NGAY LẬP TỨC (không phụ thuộc log, không
        // phụ thuộc việc còn instance MnnBridge hay không) — nếu bấm nút mà
        // KHÔNG thấy dòng chữ này hiện lên trên màn hình, nghĩa là broadcast
        // chưa tới được receiver này (lỗi ở bước đăng ký Manifest/hệ thống,
        // không phải ở phần logic huỷ bên dưới) — tách bạch rõ 2 khả năng
        // lỗi mà không cần mở file log nào cả.
        Toast.makeText(appContext, "LocalNovel: đã nhận yêu cầu Huỷ — đang dừng...", Toast.LENGTH_SHORT).show()
        val instance = MnnBridge.currentInstance
        kLog(appContext, "CancelGenerationReceiver: nhan duoc broadcast Huy tu notification — instance MnnBridge dang song = ${instance != null}")
        if (instance != null) {
            instance.performFullCancel(MnnNative.SLOT_MAIN)
            instance.performFullCancel(MnnNative.SLOT_TRANSLATION)
        } else {
            // KHÔNG còn instance MnnBridge nào sống (hiếm — vd plugin bị
            // detach nhưng Foreground Service vẫn còn) — vẫn bắn thẳng cờ
            // huỷ NATIVE, đây là phần QUAN TRỌNG NHẤT thực sự dừng được
            // generate() đang chạy; phần dọn WakeLock/Job/Service ở nhánh
            // này làm thủ công vì không có instance để gọi performFullCancel.
            MnnNative.nativeRequestCancel(MnnNative.SLOT_MAIN)
            MnnNative.nativeRequestCancel(MnnNative.SLOT_TRANSLATION)
            GenerationService.stop(appContext, Handler(Looper.getMainLooper()))
        }
    }

    companion object {
        const val ACTION_CANCEL_ALL = "com.localnovel.mnnbridge.ACTION_CANCEL_GENERATION"
    }
}
