package com.localnovel.mnnbridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

// Foreground Service — lý do cần: luồng dịch tuần tự (dịch → sinh văn →
// dịch ngược, có thể tốn vài phút vì phải nạp/xả model nhiều lần) sẽ bị
// Android tự kill giữa chừng nếu app xuống nền hoặc màn hình tắt, vì hệ
// thống coi tiến trình nền là ít ưu tiên, dễ bị dọn để giải phóng RAM.
// Foreground Service là cách CHÍNH THỨC Android cho phép: có thông báo
// hiển thị liên tục (bắt buộc, không thể ẩn) để người dùng luôn biết
// app đang làm việc, đổi lại tiến trình được ưu tiên giữ sống.
//
// Đi kèm WakeLock (PARTIAL_WAKE_LOCK) để giữ CPU/GPU không ngủ đông khi
// màn hình tắt — nếu không, dù tiến trình còn sống, CPU vẫn có thể bị
// hệ thống hạ xung nhịp mạnh khi màn hình tắt, làm việc sinh văn bản
// chậm hẳn hoặc treo.
class GenerationService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private val channelId = "localnovel_ai_generation"
    private val notificationId = 42

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val stage = intent?.getStringExtra("stage") ?: "Đang xử lý"
        startForeground(notificationId, buildNotification(stage))

        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalNovel::GenerationWakeLock")
            wakeLock?.setReferenceCounted(false)
        }
        wakeLock?.acquire(8 * 60 * 60 * 1000L /* trần an toàn 8 tiếng — đủ cho tác vụ chạy qua đêm, tự nhả nếu quên gọi stop() để tránh hao pin vô hạn nếu có lỗi */)

        return START_NOT_STICKY // không tự khởi động lại nếu bị hệ thống kill khi RAM quá cạn kiệt — tránh vòng lặp bất tận
    }

    override fun onDestroy() {
        if (wakeLock?.isHeld == true) wakeLock?.release()
        super.onDestroy()
    }

    // Gọi lại hàm này để đổi nội dung thông báo theo từng giai đoạn thật
    // (vd "Đang dịch câu hỏi..." → "Đang sinh văn bản..." → "Đang dịch kết quả...")
    // — giúp người dùng biết app còn sống và đang ở bước nào, không phải
    // màn hình đứng im gây tưởng treo máy.
    fun updateStage(stage: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notificationId, buildNotification(stage))
    }

    private fun buildNotification(stage: String): Notification {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AI đang xử lý",
                NotificationManager.IMPORTANCE_LOW, // không kêu/rung, chỉ hiển thị lặng lẽ
            )
            manager.createNotificationChannel(channel)
        }
        return Notification.Builder(this, channelId)
            .setContentTitle("LocalNovel — AI đang chạy")
            .setContentText(stage)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()
    }

    companion object {
        fun start(context: android.content.Context, stage: String) {
            val intent = Intent(context, GenerationService::class.java)
            intent.putExtra("stage", stage)
            context.startForegroundService(intent)
        }

        // Cập nhật nội dung thông báo + gia hạn wakelock cho 1 pipeline đang
        // chạy, KHÔNG tạo/dừng service. Dùng cùng cơ chế với start(): gọi lại
        // startForegroundService() khiến onStartCommand() chạy lại, thay nội
        // dung notification hiện có (không tạo notification mới) và re-acquire
        // wakelock (an toàn, vì setReferenceCounted(false) nên gọi acquire()
        // nhiều lần chỉ gia hạn thời điểm hết hạn chứ không chồng lock). Nhờ
        // vậy MnnBridge không cần giữ tham chiếu instance Service nào.
        fun updateStage(context: android.content.Context, stage: String) = start(context, stage)

        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, GenerationService::class.java))
        }
    }
}
