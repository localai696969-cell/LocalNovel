package com.localnovel.mnnbridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

// Foreground Service — lý do cần: luồng dịch tuần tự (dịch → sinh văn →
// dịch ngược, có thể tốn vài phút) sẽ bị Android tự kill giữa chừng
// nếu app xuống nền hoặc màn hình tắt.
//
// ===== FIX BUG 2: ForegroundServiceStartNotAllowedException =====
// Nguyên nhân gốc: Android 12+ (API 31+) cấm gọi startForegroundService()
// từ background — và coroutine Dispatchers.Default chạy KHÔNG phải trên
// UI thread, Android coi đó là "background". Thực tế lỗi xảy ra ngay cả
// khi app đang hiện lên màn hình, vì Android check mAllowStartForeground
// dựa trên "app state" process-level, không phải trạng thái Activity.
//
// Giải pháp đúng: KHÔNG gọi startForegroundService() từ coroutine nền.
// Thay vào đó dùng JobIntentService pattern — hay đơn giản hơn, dùng
// Handler(mainLooper) để đảm bảo mọi lệnh start/stop service đều được
// gọi trên MAIN THREAD (nơi Android coi là foreground-safe).
//
// Cụ thể: thêm parameter Handler vào companion object start()/stop(),
// và MnnBridge sẽ truyền mainHandler xuống. Tất cả lệnh start/update/stop
// đều được post lên main thread trước khi thực thi.
// ĐÃ SỬA (2026-08-02, theo yêu cầu rõ ràng của người dùng: "hệ thống này
// đặc biệt để treo máy, sáng dậy thấy nó chết thì dẹp luôn dự án"):
// trước đây WakeLock chỉ giữ tối đa 8 TIẾNG (`acquire(8*60*60*1000L)`) —
// không đủ cho việc để máy chạy tạo chương hàng loạt/xử lý tài liệu dài
// qua đêm (nhiều người để 10-12+ tiếng). Đây là giới hạn APP TỰ ĐẶT RA
// (không phải giới hạn hệ điều hành — đã xác nhận `specialUse` KHÔNG bị
// giới hạn 6 tiếng/24 tiếng như `dataSync`/`mediaProcessing` trên
// Android 15, xem mục 5.66 kiến trúc), nên sửa được hoàn toàn từ code.
//
// Giải pháp: TỰ LÀM MỚI WakeLock ĐỊNH KỲ (mỗi 30 phút, giữ trần 40 phút
// mỗi lần — luôn có 10 phút dư) thay vì 1 lần xin trần 8 tiếng cố định.
// An toàn hơn hẳn việc bỏ hẳn giới hạn (xin vô thời hạn): nếu vì lý do
// gì đó vòng lặp làm mới bị dừng bất thường (lỗi không lường trước),
// WakeLock vẫn tự hết hạn sau tối đa 40 phút thay vì rò rỉ mãi mãi, hút
// pin vô tận nếu service không bao giờ dừng đúng cách.
class GenerationService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private val channelId = "localnovel_ai_generation"
    private val notificationId = 42
    private val renewHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var renewalScheduled = false
    private val wakeLockRenewIntervalMs = 30 * 60 * 1000L // làm mới mỗi 30 phút
    private val wakeLockGrantMs = 40 * 60 * 1000L // mỗi lần giữ trần 40 phút (dư 10 phút)

    private val renewRunnable = object : Runnable {
        override fun run() {
            if (wakeLock?.isHeld == true) {
                wakeLock?.acquire(wakeLockGrantMs)
                renewHandler.postDelayed(this, wakeLockRenewIntervalMs)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val stage = intent?.getStringExtra("stage") ?: "Đang xử lý"
        startForeground(notificationId, buildNotification(stage))

        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "LocalNovel::GenerationWakeLock"
            )
            wakeLock?.setReferenceCounted(false)
        }
        wakeLock?.acquire(wakeLockGrantMs)

        // Chỉ lên lịch làm mới 1 LẦN DUY NHẤT — onStartCommand có thể được
        // gọi lại nhiều lần (mỗi lần start/updateStage), không lên lịch
        // trùng lặp nhiều vòng lặp làm mới song song.
        if (!renewalScheduled) {
            renewalScheduled = true
            renewHandler.postDelayed(renewRunnable, wakeLockRenewIntervalMs)
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        renewalScheduled = false
        renewHandler.removeCallbacks(renewRunnable)
        if (wakeLock?.isHeld == true) wakeLock?.release()
        super.onDestroy()
    }

    private fun buildNotification(stage: String): Notification {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AI đang xử lý",
                NotificationManager.IMPORTANCE_LOW,
            )
            manager.createNotificationChannel(channel)
        }
        return Notification.Builder(this, channelId)
            .setContentTitle("LocalNovel — AI đang chạy")
            .setContentText(stage)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()
    }

    companion object {
        // ===== FIX: nhận mainHandler từ MnnBridge, post lên main thread =====
        // Tất cả lệnh start/update/stop đều được dispatch về main thread
        // trước khi gọi startForegroundService() — đây là bắt buộc với
        // Android 12+ để tránh ForegroundServiceStartNotAllowedException.
        fun start(
            context: android.content.Context,
            stage: String,
            mainHandler: android.os.Handler,
        ) {
            mainHandler.post {
                val intent = Intent(context, GenerationService::class.java)
                intent.putExtra("stage", stage)
                context.startForegroundService(intent)
            }
        }

        // updateStage vẫn dùng startForegroundService để ghi đè notification
        // hiện có (không tạo service mới vì đã chạy rồi). Cũng cần main thread.
        fun updateStage(
            context: android.content.Context,
            stage: String,
            mainHandler: android.os.Handler,
        ) = start(context, stage, mainHandler)

        fun stop(
            context: android.content.Context,
            mainHandler: android.os.Handler,
        ) {
            mainHandler.post {
                context.stopService(Intent(context, GenerationService::class.java))
            }
        }
    }
}
