package com.localnovel.mnnbridge

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.system.Os
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Ghi log vào thư mục RIÊNG của app (appContext.filesDir) — không cần xin
// quyền gì cả (khác với /storage/emulated/0/Download/ đã thử trước đó,
// cần quyền MANAGE_EXTERNAL_STORAGE ĐƯỢC CẤP THẬT qua Cài đặt hệ thống,
// không tự có chỉ vì khai báo trong Manifest — rất có thể đây là lý do
// log không hề được tạo ra ở thư mục Download). Xem lại log qua chính
// app: Cài đặt → "Log debug" (đọc cùng thư mục này).
private fun logDir(context: Context): File = context.filesDir

private fun kLog(context: Context, msg: String) {
    try {
        val f = File(logDir(context), "native_debug.txt")
        val ts = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).format(Date())
        FileWriter(f, true).use { it.write("[$ts] [Kotlin] $msg\n") }
    } catch (_: Throwable) {
        // Không để lỗi ghi log làm hỏng luồng chính.
    }
}

// THEM (2026-07-30): doi chieu voi ma nguon that cua MNN Chat (app chinh
// thuc Alibaba, apps/Android/MnnLlmChat/.../qnn/QnnModule.kt) — phat hien
// 2 khac biet quan trong so voi cach app nay tung lam:
//   1. MNN Chat NAP TUONG MINH tung thu vien QNN bang System.load() voi
//      DUONG DAN TUYET DOI, theo DUNG THU TU, TRUOC KHI goi Llm.createLLM()
//      — khac voi viec chi dat file .so vao jniLibs/ va de Android tu nap
//      theo co che JNI thong thuong (khong dam bao dung thu tu/thoi diem).
//   2. MNN Chat THIET LAP 2 BIEN MOI TRUONG "ADSP_LIBRARY_PATH" va
//      "LD_LIBRARY_PATH" tro dung thu muc chua cac file .so do — de runtime
//      RPC cua Hexagon DSP tim thay dung thu vien skeleton/stub khi can
//      giao tiep voi phan cung NPU that. THIEU buoc nay rat co the la
//      nguyen nhan SIGSEGV khi QNN chay — code truoc gio chua tung lam.
// Chi can goi 1 lan cho ca vong doi app (dung co lock don gian tranh goi lap).
private var qnnEnvSetupDone = false
private fun setupQnnEnvironmentOnce(context: Context) {
    if (qnnEnvSetupDone) return
    qnnEnvSetupDone = true
    try {
        val libDir = context.applicationInfo.nativeLibraryDir
        kLog(context, "setupQnnEnvironmentOnce: thu muc thu vien native = $libDir")
        // Dat bien moi truong TRUOC khi nap thu vien — dung thu tu MNN Chat lam.
        Os.setenv("ADSP_LIBRARY_PATH", libDir, true)
        Os.setenv("LD_LIBRARY_PATH", libDir, true)
        kLog(context, "setupQnnEnvironmentOnce: da dat ADSP_LIBRARY_PATH va LD_LIBRARY_PATH = $libDir")
        // Nap tuong minh theo DUNG thu tu MNN Chat dung: System library truoc,
        // roi Htp core, roi cac thu vien theo kien truc Hexagon cu the (V68
        // cho Snapdragon 888/SM8350). Neu file nao thieu/nap loi, ghi log ro
        // rang va TIEP TUC (khong throw) — de luong fallback GPU/CPU cu (da
        // co san trong nativeLoadModel) van hoat dong binh thuong neu QNN
        // van khong nap duoc vi ly do khac.
        val libsInOrder = listOf(
            "libQnnSystem.so",
            "libQnnHtp.so",
            "libQnnHtpPrepare.so",
            "libQnnHtpV68Skel.so",
            "libQnnHtpV68Stub.so",
        )
        for (name in libsInOrder) {
            val fullPath = "$libDir/$name"
            try {
                System.load(fullPath)
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THANH CONG")
            } catch (e: Throwable) {
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THAT BAI: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    } catch (e: Throwable) {
        kLog(context, "setupQnnEnvironmentOnce: LOI TONG QUAT (khong chan luong chinh): ${e.javaClass.simpleName}: ${e.message}")
    }
}

// Lớp trung gian giữa Flutter (Dart, qua MethodChannel/EventChannel) và
// tầng native MnnNative (JNI/C++). Hỗ trợ 2 slot model độc lập (main +
// translation) — Dart truyền "slot" trong mỗi lệnh gọi để chỉ định làm
// việc với model nào, cho phép giữ cả 2 cùng lúc trong RAM (máy khỏe)
// hoặc xả từng cái theo tuần tự (máy yếu) mà không cần đổi code native.
//
// Bọc quanh Foreground Service (GenerationService) trong lúc nạp
// model/sinh văn bản — cần thiết vì luồng dịch tuần tự (dịch → sinh →
// dịch ngược) có thể mất vài phút, nếu không có Foreground Service,
// Android sẽ kill tiến trình khi app xuống nền hoặc tắt màn hình.
class MnnBridge(
    private val appContext: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
) : MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    private var eventSink: EventChannel.EventSink? = null
    private var currentJob: Job? = null

    // TỒN ĐỌNG mục 2.3 đã sửa: trước đây mỗi lệnh loadModel/generate tự
    // start/stop Foreground Service riêng, khiến luồng dịch tuần tự nhiều
    // bước (dịch → sinh → dịch ngược) có khoảng hở ngắn giữa các bước lúc
    // service bị dừng rồi khởi động lại. Giờ tầng Dart (TranslationService)
    // có thể gọi "beginPipeline" 1 lần ở đầu chuỗi nhiều bước, các lệnh
    // loadModel/generate ở giữa chỉ updateStage() (không start/stop), rồi
    // "endPipeline" ở cuối mới thật sự dừng service. Khi KHÔNG trong pipeline
    // (vd 1 lệnh generate đơn lẻ từ khung chat khi tắt dịch thuật), hành vi
    // cũ (tự start/stop từng lệnh) vẫn giữ nguyên.
    private var pipelineActive = false

    // GenerationService/nativeGenerate chạy trên luồng nền (Dispatchers.Default)
    // vì là việc nặng (nạp/sinh model) — nhưng Flutter BẮT BUỘC mọi lệnh gọi
    // vào EventChannel.EventSink / MethodChannel.Result phải chạy ở luồng
    // CHÍNH (UI thread), nếu không sẽ ném RuntimeException
    // "Methods marked with @UiThread must be executed on the main thread"
    // (đã xác nhận qua log debug thật — model sinh văn bản xong xuôi hoàn
    // toàn, không hề crash native nữa, nhưng kết quả không về được Dart vì
    // đúng lỗi luồng này). Dùng Handler gắn với Looper luồng chính để đẩy
    // đúng các lệnh gọi lại Flutter về luồng chính, không cần đổi cả
    // coroutine sang Dispatchers.Main (sẽ làm treo UI vì việc nạp/sinh model
    // vốn chạy lâu).
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        // BỌC TOÀN BỘ hàm này trong try/catch — trước đây KHÔNG có, nghĩa
        // là bất kỳ lỗi Kotlin nào ném ra trực tiếp trong onMethodCall
        // (không phải trong coroutine, nên finally/catch của coroutine
        // không với tới được) sẽ làm CRASH CẢ APP ngay lập tức, không kịp
        // hiện lỗi gì — đúng triệu chứng đã quan sát được qua log thật
        // (crash giữa lúc Dart gọi invokeMethod('generate') và trước khi
        // C++ kịp ghi dòng log đầu tiên, tức là chết ngay trong Kotlin).
        // Nghi phạm chính: GenerationService.start()/updateStage() gọi
        // TRỰC TIẾP (không try/catch) trong "loadModel"/"generate".
        try {
            onMethodCallInner(call, result)
        } catch (e: Throwable) {
            kLog(appContext, "onMethodCall: LOI NGHIEM TRONG bat duoc o tang ngoai cung (khong con crash ca app nua) — method=${call.method}, loi=${e.javaClass.simpleName}: ${e.message}")
            try {
                result.error("UNCAUGHT_KOTLIN_ERROR", "${e.javaClass.simpleName}: ${e.message}", null)
            } catch (_: Throwable) {
                // result có thể đã được trả lời trước đó rồi — bỏ qua.
            }
        }
    }

    private var logDirSent = false

    private fun onMethodCallInner(call: MethodCall, result: MethodChannel.Result) {
        // Báo cho tầng C++ biết ghi log vào đâu (thư mục riêng của app,
        // luôn ghi được, không cần xin quyền) — chỉ cần gửi 1 lần.
        if (!logDirSent) {
            MnnNative.nativeSetLogDir(appContext.filesDir.absolutePath)
            logDirSent = true
        }
        val slot = call.argument<Int>("slot") ?: MnnNative.SLOT_MAIN
        when (call.method) {
            "beginPipeline" -> {
                val stage = call.argument<String>("stage") ?: "Đang chuẩn bị..."
                pipelineActive = true
                GenerationService.start(appContext, stage)
                result.success(null)
            }
            "updateStage" -> {
                val stage = call.argument<String>("stage") ?: "Đang xử lý..."
                GenerationService.updateStage(appContext, stage)
                result.success(null)
            }
            "endPipeline" -> {
                pipelineActive = false
                GenerationService.stop(appContext)
                result.success(null)
            }
            "loadModel" -> {
                val configPath = call.argument<String>("configPath")
                // Đọc từ Dart thay vì hardcode — cho phép người dùng đổi
                // qua GPU/CPU trong "Tối ưu AI local" mà không cần build
                // lại app, hữu ích để khoanh vùng crash native của QNN.
                val backendPreference = call.argument<Int>("backendPreference") ?: 0
                if (configPath == null) {
                    result.error("BAD_ARGS", "Thiếu configPath", null)
                    return
                }
                kLog(appContext, "loadModel: CHUAN BI goi GenerationService (pipelineActive=$pipelineActive)")
                if (pipelineActive) {
                    GenerationService.updateStage(appContext, "Đang nạp model...")
                } else {
                    GenerationService.start(appContext, "Đang nạp model...")
                }
                kLog(appContext, "loadModel: GenerationService xong, khong crash. Chuan bi scope.launch...")
                if (backendPreference == 0) {
                    // Chi thiet lap khi co the se thu QNN (backendPreference=0
                    // tu dong thu QNN truoc) — khong can lam viec nay neu nguoi
                    // dung da chu dong ep GPU/CPU (backendPreference 1/2).
                    setupQnnEnvironmentOnce(appContext)
                }
                scope.launch {
                    try {
                        kLog(appContext, "loadModel: BEN TRONG coroutine, chuan bi goi MnnNative.nativeLoadModel...")
                        // backendPreference: 0 = luôn thử QNN trước, rơi về
                        // GPU/CPU nếu lỗi; 1 = ép GPU; 2 = ép CPU.
                        val ok = MnnNative.nativeLoadModel(slot, configPath, backendPreference)
                        val backend = if (ok) MnnNative.nativeActiveBackend(slot) else "loi"
                        mainHandler.post { result.success(mapOf("success" to ok, "backend" to backend)) }
                    } catch (e: Throwable) {
                        kLog(appContext, "loadModel: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post { result.error("LOAD_FAILED", e.message ?: "Lỗi nạp model không rõ nguyên nhân", null) }
                    } finally {
                        if (!pipelineActive) GenerationService.stop(appContext)
                    }
                }
            }
            "generate" -> {
                val prompt = call.argument<String>("prompt")
                val stageLabel = call.argument<String>("stageLabel") ?: "Đang sinh văn bản..."
                val temperature = call.argument<Double>("temperature") ?: 0.9
                val topP = call.argument<Double>("topP") ?: 0.9
                val topK = call.argument<Int>("topK") ?: 40
                val repetitionPenalty = call.argument<Double>("repetitionPenalty") ?: 1.05
                val maxNewTokens = call.argument<Int>("maxNewTokens") ?: 1024
                if (prompt == null) {
                    result.error("BAD_ARGS", "Thiếu prompt", null)
                    return
                }
                kLog(appContext, "generate: da doc xong tham so tu Dart, chuan bi tao JSON config...")
                // Tên khóa JSON khớp đúng tài liệu chính thức MNN (llm_config.json).
                val configJson = JSONObject().apply {
                    put("temperature", temperature)
                    put("top_p", topP)
                    put("top_k", topK)
                    put("repetition_penalty", repetitionPenalty)
                    put("max_new_tokens", maxNewTokens)
                }.toString()
                kLog(appContext, "generate: config JSON xong: $configJson. Chuan bi goi GenerationService (pipelineActive=$pipelineActive)...")

                if (pipelineActive) {
                    GenerationService.updateStage(appContext, stageLabel)
                } else {
                    GenerationService.start(appContext, stageLabel)
                }
                kLog(appContext, "generate: GenerationService xong, khong crash. Chuan bi scope.launch...")
                currentJob = scope.launch {
                    try {
                        kLog(appContext, "generate: BEN TRONG coroutine, chuan bi goi MnnNative.nativeGenerate...")
                        MnnNative.nativeGenerate(slot, prompt, configJson, object : MnnNative.TokenCallback {
                            override fun onToken(token: String, done: Boolean) {
                                // QUAN TRỌNG: onToken được gọi TRỰC TIẾP từ
                                // native (C++) trên CHÍNH luồng nền đang chạy
                                // nativeGenerate (Dispatchers.Default), KHÔNG
                                // phải luồng chính — eventSink.success() bắt
                                // buộc phải gọi ở luồng chính, nếu không
                                // Flutter ném RuntimeException
                                // "@UiThread must be executed on the main
                                // thread" (đã xác nhận qua log debug thật).
                                mainHandler.post {
                                    eventSink?.success(mapOf("token" to token, "done" to done, "slot" to slot))
                                }
                            }
                        })
                        kLog(appContext, "generate: MnnNative.nativeGenerate() TRA VE XONG (khong crash)")
                        mainHandler.post { result.success(null) }
                    } catch (e: Throwable) {
                        kLog(appContext, "generate: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post {
                            eventSink?.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                            result.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                        }
                    } finally {
                        if (!pipelineActive) GenerationService.stop(appContext)
                    }
                }
            }
            "cancelGenerate" -> {
                currentJob?.cancel()
                pipelineActive = false
                GenerationService.stop(appContext)
                result.success(null)
            }
            "unload" -> {
                scope.launch {
                    MnnNative.nativeUnload(slot)
                    mainHandler.post { result.success(null) }
                }
            }
            "isLoaded" -> {
                result.success(MnnNative.nativeIsLoaded(slot))
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }
}
