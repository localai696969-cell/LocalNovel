package com.localnovel.mnnbridge

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.system.Os
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun logDir(context: Context): File = context.filesDir

private fun kLog(context: Context, msg: String) {
    try {
        val f = File(logDir(context), "native_debug.txt")
        val ts = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).format(Date())
        FileWriter(f, true).use { it.write("[$ts] [Kotlin] $msg\n") }
    } catch (_: Throwable) {}
}

private var qnnEnvSetupDone = false
private fun setupQnnEnvironmentOnce(context: Context) {
    if (qnnEnvSetupDone) return
    qnnEnvSetupDone = true
    try {
        val libDir = context.applicationInfo.nativeLibraryDir
        kLog(context, "setupQnnEnvironmentOnce: thu muc thu vien native = $libDir")
        Os.setenv("ADSP_LIBRARY_PATH", libDir, true)
        Os.setenv("LD_LIBRARY_PATH", libDir, true)
        kLog(context, "setupQnnEnvironmentOnce: da dat ADSP_LIBRARY_PATH va LD_LIBRARY_PATH = $libDir")
        // SUA LOI KIEN TRUC (phat hien khi doi chieu ky lai): libQnnHtpV68Skel.so
        // KHONG PHAI thu vien ARM64 — day la binary bien dich CHO CHINH
        // HEXAGON DSP (kien truc CPU hoan toan khac ARM64), chi chay duoc
        // BEN TRONG chip DSP, khong bao gio chay tren tien trinh ARM64 cua
        // app. Goi System.load() cho file nay se LUON LUON that bai (dung
        // linker cua Android/ARM64 khong the nap 1 file ELF cho kien truc
        // Hexagon) — BAT KE file co ton tai dung cho hay khong, bat ke
        // build.yml co copy dung hay khong. Day la 1 phan ly do TRUOC GIO
        // ca 5 dong log deu bao "THAT BAI", khien khong phan biet duoc dau
        // la loi that (4 file ARM64 kia thieu that) va dau la hanh vi BINH
        // THUONG DUOC MONG DOI (Skel luon "that bai" theo kieu nay).
        //
        // Cach dung: KHONG System.load() file Skel — chi can no NAM DUNG
        // CHO trong thu muc native (jniLibs/arm64-v8a, da duoc dat dung
        // ADSP_LIBRARY_PATH tro toi o tren) de chinh Qualcomm FastRPC/ADSP
        // runtime (chay o tang thap hon, khong qua System.load) tu tim va
        // day no vao DSP that khi can — dung theo tai lieu MNN Chat that.
        val libsToSystemLoad = listOf(
            "libQnnSystem.so",
            "libQnnHtp.so",
            "libQnnHtpPrepare.so",
            "libQnnHtpV68Stub.so",
        )
        for (name in libsToSystemLoad) {
            val fullPath = "$libDir/$name"
            try {
                System.load(fullPath)
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THANH CONG")
            } catch (e: Throwable) {
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THAT BAI: ${e.javaClass.simpleName}: ${e.message} — NEU day la 1 trong 4 file ARM64 that (System/Htp/HtpPrepare/Stub), day LA loi that, can kiem tra lai build.yml co copy dung file khong")
            }
        }
        // Chi kiem tra SU TON TAI cua file Skel (khong System.load()) — de
        // biet chac no co that trong APK hay khong, phong khi build.yml
        // copy thieu (Skel la file BAT BUOC de FastRPC tim thay tren DSP,
        // du khong System.load() no o tang ARM).
        val skelFile = java.io.File(libDir, "libQnnHtpV68Skel.so")
        if (skelFile.exists()) {
            kLog(context, "setupQnnEnvironmentOnce: libQnnHtpV68Skel.so CO TON TAI dung cho (${skelFile.length()} bytes) — se duoc FastRPC/ADSP tim thay qua ADSP_LIBRARY_PATH, khong can System.load()")
        } else {
            kLog(context, "setupQnnEnvironmentOnce: CANH BAO — libQnnHtpV68Skel.so KHONG TON TAI trong $libDir. Neu file nay thieu, QNN se khong bao gio chay duoc tren DSP that du 4 file kia nap thanh cong. Kiem tra lai buoc copy trong build.yml.")
        }
    } catch (e: Throwable) {
        kLog(context, "setupQnnEnvironmentOnce: LOI TONG QUAT: ${e.javaClass.simpleName}: ${e.message}")
    }
}

class MnnBridge(
    private val appContext: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
) : MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    private var eventSink: EventChannel.EventSink? = null
    private var currentJob: Job? = null
    private var pipelineActive = false

    // ===== FIX BUG 2: mainHandler dùng để dispatch mọi lệnh service =====
    // Khai báo ở đây để dùng được trong cả onMethodCallInner VÀ truyền
    // xuống GenerationService — tránh tạo nhiều Handler object.
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            onMethodCallInner(call, result)
        } catch (e: Throwable) {
            kLog(appContext, "onMethodCall: LOI NGHIEM TRONG bat duoc o tang ngoai cung — method=${call.method}, loi=${e.javaClass.simpleName}: ${e.message}")
            try {
                result.error("UNCAUGHT_KOTLIN_ERROR", "${e.javaClass.simpleName}: ${e.message}", null)
            } catch (_: Throwable) {}
        }
    }

    private var logDirSent = false

    private fun onMethodCallInner(call: MethodCall, result: MethodChannel.Result) {
        if (!logDirSent) {
            MnnNative.nativeSetLogDir(appContext.filesDir.absolutePath)
            // ĐÃ THÊM: cache dir riêng cho OpenCL kernel tuning cache —
            // dùng cacheDir (Android tự dọn khi cần thêm dung lượng, an
            // toàn để làm dữ liệu tạm), khác files dir dùng cho log.
            MnnNative.nativeSetCacheDir(appContext.cacheDir.absolutePath)
            logDirSent = true
        }
        val slot = call.argument<Int>("slot") ?: MnnNative.SLOT_MAIN
        when (call.method) {
            "beginPipeline" -> {
                val stage = call.argument<String>("stage") ?: "Đang chuẩn bị..."
                pipelineActive = true
                // FIX: truyền mainHandler — gọi startForegroundService trên main thread
                GenerationService.start(appContext, stage, mainHandler)
                result.success(null)
            }
            "updateStage" -> {
                val stage = call.argument<String>("stage") ?: "Đang xử lý..."
                // FIX: truyền mainHandler
                GenerationService.updateStage(appContext, stage, mainHandler)
                result.success(null)
            }
            "endPipeline" -> {
                pipelineActive = false
                // FIX: truyền mainHandler
                GenerationService.stop(appContext, mainHandler)
                result.success(null)
            }
            "loadModel" -> {
                val configPath = call.argument<String>("configPath")
                val backendPreference = call.argument<Int>("backendPreference") ?: 0
                if (configPath == null) {
                    result.error("BAD_ARGS", "Thiếu configPath", null)
                    return
                }
                kLog(appContext, "loadModel: CHUAN BI goi GenerationService (pipelineActive=$pipelineActive)")
                if (pipelineActive) {
                    // FIX: truyền mainHandler
                    GenerationService.updateStage(appContext, "Đang nạp model...", mainHandler)
                } else {
                    // FIX: truyền mainHandler
                    GenerationService.start(appContext, "Đang nạp model...", mainHandler)
                }
                kLog(appContext, "loadModel: GenerationService scheduled (main thread), chuan bi scope.launch...")
                if (backendPreference == 0) {
                    setupQnnEnvironmentOnce(appContext)
                }
                scope.launch {
                    try {
                        kLog(appContext, "loadModel: BEN TRONG coroutine, chuan bi goi MnnNative.nativeLoadModel...")
                        val ok = MnnNative.nativeLoadModel(slot, configPath, backendPreference)
                        val backend = if (ok) MnnNative.nativeActiveBackend(slot) else "loi"
                        mainHandler.post { result.success(mapOf("success" to ok, "backend" to backend)) }
                    } catch (e: Throwable) {
                        kLog(appContext, "loadModel: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post { result.error("LOAD_FAILED", e.message ?: "Lỗi nạp model không rõ nguyên nhân", null) }
                    } finally {
                        // FIX: truyền mainHandler
                        if (!pipelineActive) GenerationService.stop(appContext, mainHandler)
                    }
                }
            }
            "generate" -> {
                val prompt = call.argument<String>("prompt")
                val stageLabel = call.argument<String>("stageLabel") ?: "Đang sinh văn bản..."
                val temperature = call.argument<Double>("temperature") ?: 0.9
                val topP = call.argument<Double>("topP") ?: 0.9
                val topK = call.argument<Int>("topK") ?: 40
                val repetitionPenalty = call.argument<Double>("repetitionPenalty") ?: 1.05
                val maxNewTokens = call.argument<Int>("maxNewTokens") ?: 1024
                // ĐÃ THÊM: reuse_kv — tham số CHÍNH THỨC của MNN (tài liệu
                // alibaba/MNN: "Whether to reuse the kv cache in multi-turn
                // dialogues. Defaults to false") — giảm thời gian chờ prefill
                // cho các lượt chat SAU lượt đầu trong cùng phiên, vì không
                // phải tính lại KV-cache cho phần system prompt + lịch sử đã
                // xử lý ở lượt trước. CHỈ bật true cho hội thoại thật sự
                // nhiều lượt (chat_screen.dart) — luôn false cho tác vụ 1
                // lần độc lập (dịch/tóm tắt từng đoạn tài liệu) để tránh lẫn
                // ngữ cảnh sai giữa các đoạn không liên quan.
                val reuseKv = call.argument<Boolean>("reuseKv") ?: false
                if (prompt == null) {
                    result.error("BAD_ARGS", "Thiếu prompt", null)
                    return
                }
                kLog(appContext, "generate: da doc xong tham so tu Dart, chuan bi tao JSON config...")
                val configJson = JSONObject().apply {
                    put("temperature", temperature)
                    put("top_p", topP)
                    put("top_k", topK)
                    put("repetition_penalty", repetitionPenalty)
                    put("max_new_tokens", maxNewTokens)
                    put("reuse_kv", reuseKv)
                }.toString()
                kLog(appContext, "generate: config JSON xong: $configJson. Chuan bi goi GenerationService (pipelineActive=$pipelineActive)...")

                if (pipelineActive) {
                    // FIX: truyền mainHandler
                    GenerationService.updateStage(appContext, stageLabel, mainHandler)
                } else {
                    // FIX: truyền mainHandler — ĐÂY LÀ ĐIỂM FIX CHÍNH CHO LỖI 2
                    // Trước đây gọi GenerationService.start() trực tiếp từ
                    // onMethodCallInner (chạy trên Binder thread của Flutter,
                    // KHÔNG phải main thread) → ForegroundServiceStartNotAllowedException.
                    // Giờ GenerationService.start() sẽ post lên main thread trước.
                    GenerationService.start(appContext, stageLabel, mainHandler)
                }
                kLog(appContext, "generate: GenerationService scheduled, chuan bi scope.launch...")
                currentJob = scope.launch {
                    try {
                        kLog(appContext, "generate: BEN TRONG coroutine, chuan bi goi MnnNative.nativeGenerate...")
                        MnnNative.nativeGenerate(slot, prompt, configJson, object : MnnNative.TokenCallback {
                            override fun onToken(token: String, done: Boolean) {
                                mainHandler.post {
                                    eventSink?.success(mapOf("token" to token, "done" to done, "slot" to slot))
                                }
                            }
                        })
                        kLog(appContext, "generate: MnnNative.nativeGenerate() TRA VE XONG (khong crash)")
                        mainHandler.post { result.success(null) }
                    } catch (e: Throwable) {
                        kLog(appContext, "generate: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post {
                            eventSink?.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                            result.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                        }
                    } finally {
                        // FIX: truyền mainHandler
                        if (!pipelineActive) GenerationService.stop(appContext, mainHandler)
                    }
                }
            }
            "cancelGenerate" -> {
                currentJob?.cancel()
                pipelineActive = false
                // FIX: truyền mainHandler
                GenerationService.stop(appContext, mainHandler)
                result.success(null)
            }
            "unload" -> {
                scope.launch {
                    MnnNative.nativeUnload(slot)
                    mainHandler.post { result.success(null) }
                }
            }
            "isLoaded" -> {
                result.success(MnnNative.nativeIsLoaded(slot))
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }
}
