package com.localnovel.mnnbridge

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.system.Os
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun logDir(context: Context): File = context.filesDir

private fun kLog(context: Context, msg: String) {
    try {
        val f = File(logDir(context), "native_debug.txt")
        val ts = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).format(Date())
        FileWriter(f, true).use { it.write("[$ts] [Kotlin] $msg\n") }
    } catch (_: Throwable) {}
}

private var qnnEnvSetupDone = false
private fun setupQnnEnvironmentOnce(context: Context) {
    if (qnnEnvSetupDone) return
    qnnEnvSetupDone = true
    try {
        val libDir = context.applicationInfo.nativeLibraryDir
        kLog(context, "setupQnnEnvironmentOnce: thu muc thu vien native = $libDir")
        Os.setenv("ADSP_LIBRARY_PATH", libDir, true)
        Os.setenv("LD_LIBRARY_PATH", libDir, true)
        kLog(context, "setupQnnEnvironmentOnce: da dat ADSP_LIBRARY_PATH va LD_LIBRARY_PATH = $libDir")
        // SUA LOI KIEN TRUC (phat hien khi doi chieu ky lai): libQnnHtpV68Skel.so
        // KHONG PHAI thu vien ARM64 — day la binary bien dich CHO CHINH
        // HEXAGON DSP (kien truc CPU hoan toan khac ARM64), chi chay duoc
        // BEN TRONG chip DSP, khong bao gio chay tren tien trinh ARM64 cua
        // app. Goi System.load() cho file nay se LUON LUON that bai (dung
        // linker cua Android/ARM64 khong the nap 1 file ELF cho kien truc
        // Hexagon) — BAT KE file co ton tai dung cho hay khong, bat ke
        // build.yml co copy dung hay khong. Day la 1 phan ly do TRUOC GIO
        // ca 5 dong log deu bao "THAT BAI", khien khong phan biet duoc dau
        // la loi that (4 file ARM64 kia thieu that) va dau la hanh vi BINH
        // THUONG DUOC MONG DOI (Skel luon "that bai" theo kieu nay).
        //
        // Cach dung: KHONG System.load() file Skel — chi can no NAM DUNG
        // CHO trong thu muc native (jniLibs/arm64-v8a, da duoc dat dung
        // ADSP_LIBRARY_PATH tro toi o tren) de chinh Qualcomm FastRPC/ADSP
        // runtime (chay o tang thap hon, khong qua System.load) tu tim va
        // day no vao DSP that khi can — dung theo tai lieu MNN Chat that.
        val libsToSystemLoad = listOf(
            "libQnnSystem.so",
            "libQnnHtp.so",
            "libQnnHtpPrepare.so",
            "libQnnHtpV68Stub.so",
        )
        for (name in libsToSystemLoad) {
            val fullPath = "$libDir/$name"
            try {
                System.load(fullPath)
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THANH CONG")
            } catch (e: Throwable) {
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THAT BAI: ${e.javaClass.simpleName}: ${e.message} — NEU day la 1 trong 4 file ARM64 that (System/Htp/HtpPrepare/Stub), day LA loi that, can kiem tra lai build.yml co copy dung file khong")
            }
        }
        // Chi kiem tra SU TON TAI cua file Skel (khong System.load()) — de
        // biet chac no co that trong APK hay khong, phong khi build.yml
        // copy thieu (Skel la file BAT BUOC de FastRPC tim thay tren DSP,
        // du khong System.load() no o tang ARM).
        val skelFile = java.io.File(libDir, "libQnnHtpV68Skel.so")
        if (skelFile.exists()) {
            kLog(context, "setupQnnEnvironmentOnce: libQnnHtpV68Skel.so CO TON TAI dung cho (${skelFile.length()} bytes) — se duoc FastRPC/ADSP tim thay qua ADSP_LIBRARY_PATH, khong can System.load()")
        } else {
            kLog(context, "setupQnnEnvironmentOnce: CANH BAO — libQnnHtpV68Skel.so KHONG TON TAI trong $libDir. Neu file nay thieu, QNN se khong bao gio chay duoc tren DSP that du 4 file kia nap thanh cong. Kiem tra lai buoc copy trong build.yml.")
        }
    } catch (e: Throwable) {
        kLog(context, "setupQnnEnvironmentOnce: LOI TONG QUAT: ${e.javaClass.simpleName}: ${e.message}")
    }
}

// ĐÃ THÊM: `launchFolderPicker` — theo yêu cầu người dùng ("cứ như các ứng
// dụng khác là có nút gạt, ko phải bắt người dùng mất công cài đặt thủ
// công"). MnnBridge tự nó không phải là Activity nên không thể tự gọi
// startActivityForResult() — MainActivity (chủ Activity thật) truyền vào
// 1 hàm callback để MnnBridge nhờ mở Intent hệ thống hộ. Mặc định null để
// không phá vỡ chỗ nào lỡ khởi tạo MnnBridge mà không cần tính năng này.
class MnnBridge(
    private val appContext: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
    private val launchFolderPicker: ((Intent) -> Unit)? = null,
) : MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    private var eventSink: EventChannel.EventSink? = null
    // Kết quả đang chờ của lệnh "pickModelFolder" — giữ lại vì
    // ACTION_OPEN_DOCUMENT_TREE là bất đồng bộ (trả về qua onActivityResult
    // của MainActivity, không phải ngay trong onMethodCall này).
    private var pendingFolderPickResult: MethodChannel.Result? = null
    private var currentJob: Job? = null
    // ĐÃ SỬA (2026-08-02, phát hiện qua thiết kế lồng nhau mới của
    // ChapterBatchService + generateWithOptionalTranslation): trước đây
    // `pipelineActive` là Boolean đơn giản — nếu 1 vòng lặp NGOÀI (vd tạo
    // hàng loạt nhiều chương) gọi beginPipeline() 1 lần bọc cả vòng lặp,
    // rồi BÊN TRONG mỗi lượt lại có 1 lệnh generate KHÁC (vd dịch thuật
    // trung gian) cũng tự gọi beginPipeline()/endPipeline() riêng — lệnh
    // endPipeline() của lượt BÊN TRONG sẽ tắt Foreground Service NGAY,
    // dù vòng lặp NGOÀI vẫn còn nhiều việc phải làm tiếp — tạo lại đúng
    // kiểu lỗ hổng "chớp tắt thông báo giữa các bước" đã sửa ở mục 5.61
    // cho xử lý tài liệu, nhưng giờ xảy ra với tạo chương hàng loạt có
    // dịch thuật trung gian. Đổi sang ĐẾM SỐ LẦN LỒNG NHAU (giống khoá
    // reentrant) — chỉ thực sự dừng Foreground Service khi bộ đếm về 0,
    // hỗ trợ đúng bất kỳ độ sâu lồng nhau nào mà không cần Dart phải biết
    ///xử lý đặc biệt cho từng trường hợp.
    private var pipelineDepth = 0
    private val pipelineDepthLock = Object()

    // ===== FIX BUG 2: mainHandler dùng để dispatch mọi lệnh service =====
    // Khai báo ở đây để dùng được trong cả onMethodCallInner VÀ truyền
    // xuống GenerationService — tránh tạo nhiều Handler object.
    private val mainHandler = Handler(Looper.getMainLooper())

    // ĐÃ THÊM (2026-08-02, phát hiện qua log thật — CHUỖI CRASH HEAP CORRUPTION
    // BÍ ẨN Ở MỤC 62-64 RẤT CÓ THỂ DO ĐÂY): `nativeLoadModel()` đã có sẵn khoá
    // chống gọi trùng (`g_loadingInProgress` phía C++), nhưng `nativeGenerate()`
    // KHÔNG HỀ CÓ khoá tương tự — log thật bắt được đúng lúc 2 lệnh generate
    // (chat + kiểm tra tính nhất quán chương) chạy ĐÈ LÊN NHAU trên CÙNG 1 slot
    // (slot 0), gây SIGSEGV liên tục 30 lần do 2 luồng cùng ghi/đọc chung 1 đối
    // tượng `Llm` native (KV-cache, buffer tính toán) không có cơ chế loại trừ
    // lẫn nhau (mutual exclusion). MNN's `Llm::response()` KHÔNG được thiết kế
    // để gọi đồng thời từ nhiều luồng trên CÙNG 1 instance.
    // Mỗi slot có 1 Mutex riêng — lệnh generate() cho CÙNG slot phải XẾP HÀNG
    // chờ lệnh trước xong (không bị từ chối, không mất yêu cầu, chỉ chờ), còn
    // slot 0 (model chính) và slot 1 (model dịch, nếu dùng) vẫn chạy độc lập
    // song song bình thường — đúng kiến trúc "2 slot" đã thiết kế từ đầu.
    private val generateMutexes = arrayOf(Mutex(), Mutex())

    private fun mutexForSlot(slot: Int): Mutex = generateMutexes.getOrElse(slot) { generateMutexes[0] }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            onMethodCallInner(call, result)
        } catch (e: Throwable) {
            kLog(appContext, "onMethodCall: LOI NGHIEM TRONG bat duoc o tang ngoai cung — method=${call.method}, loi=${e.javaClass.simpleName}: ${e.message}")
            try {
                result.error("UNCAUGHT_KOTLIN_ERROR", "${e.javaClass.simpleName}: ${e.message}", null)
            } catch (_: Throwable) {}
        }
    }

    private var logDirSent = false

    private fun onMethodCallInner(call: MethodCall, result: MethodChannel.Result) {
        if (!logDirSent) {
            MnnNative.nativeSetLogDir(appContext.filesDir.absolutePath)
            // ĐÃ THÊM: cache dir riêng cho OpenCL kernel tuning cache —
            // dùng cacheDir (Android tự dọn khi cần thêm dung lượng, an
            // toàn để làm dữ liệu tạm), khác files dir dùng cho log.
            MnnNative.nativeSetCacheDir(appContext.cacheDir.absolutePath)
            logDirSent = true
        }
        val slot = call.argument<Int>("slot") ?: MnnNative.SLOT_MAIN
        when (call.method) {
            "beginPipeline" -> {
                val stage = call.argument<String>("stage") ?: "Đang chuẩn bị..."
                // ĐÃ SỬA: chỉ THẬT SỰ gọi start() (bật thông báo mới) khi
                // đây là lần bọc NGOÀI CÙNG (độ sâu từ 0 lên 1) — nếu đã có
                // 1 pipeline khác đang chạy bọc bên ngoài (độ sâu > 0), chỉ
                // cập nhật nội dung thông báo, KHÔNG bật/tắt lại service.
                val isOutermost = synchronized(pipelineDepthLock) {
                    val was = pipelineDepth
                    pipelineDepth++
                    was == 0
                }
                if (isOutermost) {
                    // FIX: truyền mainHandler — gọi startForegroundService trên main thread
                    GenerationService.start(appContext, stage, mainHandler)
                } else {
                    GenerationService.updateStage(appContext, stage, mainHandler)
                }
                result.success(null)
            }
            "updateStage" -> {
                val stage = call.argument<String>("stage") ?: "Đang xử lý..."
                // FIX: truyền mainHandler
                GenerationService.updateStage(appContext, stage, mainHandler)
                result.success(null)
            }
            "endPipeline" -> {
                // ĐÃ SỬA: chỉ THẬT SỰ gọi stop() khi độ sâu về lại 0 (lần
                // endPipeline() cuối cùng khớp với lần beginPipeline() đầu
                // tiên) — nếu vẫn còn pipeline khác bọc bên ngoài đang chạy
                // dở (độ sâu > 0 sau khi giảm), KHÔNG tắt thông báo, để
                // vòng lặp bên ngoài tự tắt khi thật sự xong.
                val isOutermost = synchronized(pipelineDepthLock) {
                    if (pipelineDepth > 0) pipelineDepth--
                    pipelineDepth == 0
                }
                if (isOutermost) {
                    // FIX: truyền mainHandler
                    GenerationService.stop(appContext, mainHandler)
                }
                result.success(null)
            }
            "loadModel" -> {
                val configPath = call.argument<String>("configPath")
                val backendPreference = call.argument<Int>("backendPreference") ?: 0
                if (configPath == null) {
                    result.error("BAD_ARGS", "Thiếu configPath", null)
                    return
                }
                kLog(appContext, "loadModel: CHUAN BI goi GenerationService (pipelineDepth=$pipelineDepth)")
                if (pipelineDepth > 0) {
                    // FIX: truyền mainHandler
                    GenerationService.updateStage(appContext, "Đang nạp model...", mainHandler)
                } else {
                    // FIX: truyền mainHandler
                    GenerationService.start(appContext, "Đang nạp model...", mainHandler)
                }
                kLog(appContext, "loadModel: GenerationService scheduled (main thread), chuan bi scope.launch...")
                if (backendPreference == 0) {
                    setupQnnEnvironmentOnce(appContext)
                }
                scope.launch {
                    try {
                        kLog(appContext, "loadModel: BEN TRONG coroutine, chuan bi goi MnnNative.nativeLoadModel...")
                        val ok = MnnNative.nativeLoadModel(slot, configPath, backendPreference)
                        val backend = if (ok) MnnNative.nativeActiveBackend(slot) else "loi"
                        mainHandler.post { result.success(mapOf("success" to ok, "backend" to backend)) }
                    } catch (e: Throwable) {
                        kLog(appContext, "loadModel: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post { result.error("LOAD_FAILED", e.message ?: "Lỗi nạp model không rõ nguyên nhân", null) }
                    } finally {
                        // FIX: truyền mainHandler
                        if (pipelineDepth == 0) GenerationService.stop(appContext, mainHandler)
                    }
                }
            }
            "generate" -> {
                val prompt = call.argument<String>("prompt")
                val stageLabel = call.argument<String>("stageLabel") ?: "Đang sinh văn bản..."
                val temperature = call.argument<Double>("temperature") ?: 0.9
                val topP = call.argument<Double>("topP") ?: 0.9
                val topK = call.argument<Int>("topK") ?: 40
                val repetitionPenalty = call.argument<Double>("repetitionPenalty") ?: 1.05
                val maxNewTokens = call.argument<Int>("maxNewTokens") ?: 1024
                // ĐÃ THÊM: reuse_kv — tham số CHÍNH THỨC của MNN (tài liệu
                // alibaba/MNN: "Whether to reuse the kv cache in multi-turn
                // dialogues. Defaults to false") — giảm thời gian chờ prefill
                // cho các lượt chat SAU lượt đầu trong cùng phiên, vì không
                // phải tính lại KV-cache cho phần system prompt + lịch sử đã
                // xử lý ở lượt trước. CHỈ bật true cho hội thoại thật sự
                // nhiều lượt (chat_screen.dart) — luôn false cho tác vụ 1
                // lần độc lập (dịch/tóm tắt từng đoạn tài liệu) để tránh lẫn
                // ngữ cảnh sai giữa các đoạn không liên quan.
                val reuseKv = call.argument<Boolean>("reuseKv") ?: false
                if (prompt == null) {
                    result.error("BAD_ARGS", "Thiếu prompt", null)
                    return
                }
                kLog(appContext, "generate: da doc xong tham so tu Dart, chuan bi tao JSON config...")
                val configJson = JSONObject().apply {
                    put("temperature", temperature)
                    put("top_p", topP)
                    put("top_k", topK)
                    put("repetition_penalty", repetitionPenalty)
                    put("max_new_tokens", maxNewTokens)
                    put("reuse_kv", reuseKv)
                }.toString()
                kLog(appContext, "generate: config JSON xong: $configJson. Chuan bi goi GenerationService (pipelineDepth=$pipelineDepth)...")

                if (pipelineDepth > 0) {
                    // FIX: truyền mainHandler
                    GenerationService.updateStage(appContext, stageLabel, mainHandler)
                } else {
                    // FIX: truyền mainHandler — ĐÂY LÀ ĐIỂM FIX CHÍNH CHO LỖI 2
                    // Trước đây gọi GenerationService.start() trực tiếp từ
                    // onMethodCallInner (chạy trên Binder thread của Flutter,
                    // KHÔNG phải main thread) → ForegroundServiceStartNotAllowedException.
                    // Giờ GenerationService.start() sẽ post lên main thread trước.
                    GenerationService.start(appContext, stageLabel, mainHandler)
                }
                kLog(appContext, "generate: GenerationService scheduled, chuan bi scope.launch...")
                currentJob = scope.launch {
                    try {
                        kLog(appContext, "generate: BEN TRONG coroutine, chuan bi cho khoa (mutex) cho slot=$slot truoc khi goi nativeGenerate...")
                        // ĐÃ THÊM: khoá theo slot — nếu slot này đang có 1 lệnh
                        // generate() khác chạy dở (vd chat đang chờ, đồng thời
                        // kiểm tra tính nhất quán chương cũng gọi generate trên
                        // CÙNG slot), lệnh này sẽ CHỜ ở đây cho tới khi lệnh
                        // trước xong hẳn, KHÔNG chạy song song — tránh 2 luồng
                        // cùng đụng vào 1 đối tượng Llm native cùng lúc (nguyên
                        // nhân rất có thể của chuỗi crash "heap corruption" bí
                        // ẩn ở mục 62-64). Xem giải thích đầy đủ ở khai báo
                        // generateMutexes phía trên.
                        mutexForSlot(slot).withLock {
                            kLog(appContext, "generate: DA CO khoa cho slot=$slot, chuan bi goi MnnNative.nativeGenerate...")
                            MnnNative.nativeGenerate(slot, prompt, configJson, object : MnnNative.TokenCallback {
                                override fun onToken(token: String, done: Boolean) {
                                    mainHandler.post {
                                        eventSink?.success(mapOf("token" to token, "done" to done, "slot" to slot))
                                    }
                                }
                            })
                        }
                        kLog(appContext, "generate: MnnNative.nativeGenerate() TRA VE XONG (khong crash), da tha khoa")
                        mainHandler.post { result.success(null) }
                    } catch (e: Throwable) {
                        kLog(appContext, "generate: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post {
                            eventSink?.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                            result.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                        }
                    } finally {
                        // FIX: truyền mainHandler
                        if (pipelineDepth == 0) GenerationService.stop(appContext, mainHandler)
                    }
                }
            }
            "cancelGenerate" -> {
                currentJob?.cancel()
                // ĐÃ SỬA: huỷ thủ công phải RESET HẲN bộ đếm về 0 (không chỉ
                // giảm 1) — người dùng chủ động huỷ nghĩa là muốn dừng TOÀN
                // BỘ pipeline đang chạy, kể cả khi đang lồng nhiều lớp.
                synchronized(pipelineDepthLock) { pipelineDepth = 0 }
                // FIX: truyền mainHandler
                GenerationService.stop(appContext, mainHandler)
                result.success(null)
            }
            "unload" -> {
                scope.launch {
                    MnnNative.nativeUnload(slot)
                    mainHandler.post { result.success(null) }
                }
            }
            "isLoaded" -> {
                result.success(MnnNative.nativeIsLoaded(slot))
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "hệ thống này đặc biệt để
            // treo máy, sáng dậy thấy chết thì dẹp luôn dự án"): lớp phòng
            // vệ CUỐI CÙNG cho độ tin cậy chạy xuyên đêm — Foreground
            // Service + WakeLock tự làm mới (mục 5.71) bảo vệ được ở tầng
            // Android chuẩn, nhưng 1 số OEM (đặc biệt ASUS ZenUI, đúng máy
            // test — xem mục 5.66) có trình quản lý pin RIÊNG, tự ý kill
            // app nền bất kể Foreground Service đúng chuẩn hay không, trừ
            // khi người dùng TỰ TAY loại trừ app khỏi tối ưu hoá pin.
            // Android không cho phép app tự động tắt hẳn tối ưu hoá pin
            // cho chính mình — chỉ có thể MỞ HỘP THOẠI HỆ THỐNG để người
            // dùng tự xác nhận (yêu cầu bảo mật, không thể bỏ qua).
            // ĐÃ THÊM: chọn thư mục model qua Storage Access Framework — 1
            // lần chạm ("Cho phép truy cập"/"USE THIS FOLDER" trong picker hệ
            // thống), KHÔNG cần rời app sang Cài đặt máy như MANAGE_EXTERNAL_
            // STORAGE. Đây chính là kiểu "nút gạt" người dùng yêu cầu, giống
            // cách các app khác (file manager, app nhạc...) xin quyền 1 thư
            // mục cụ thể thay vì toàn bộ máy.
            //
            // GIỚI HẠN THẬT (không giấu): SAF trả về content:// URI, không
            // phải đường dẫn hệ thống file thật — nhưng engine MNN native
            // (nativeLoadModel) cần đường dẫn thật để mmap trực tiếp file
            // trọng số nhiều GB (không thể copy qua app trước, quá tốn dung
            // lượng/thời gian). Với bộ nhớ TRONG chính máy (không phải thẻ
            // nhớ ngoài/USB), Android LUÔN đặt tên node theo dạng cố định
            // "primary:<đường dẫn tương đối>" — suy ra lại được đường dẫn
            // thật (/storage/emulated/0/<đường dẫn tương đối>) mà không cần
            // quyền gì thêm. Với thẻ nhớ ngoài/USB, tên node đổi sang mã ổ
            // đĩa riêng của từng thiết bị — KHÔNG suy ra được đường dẫn thật
            // đáng tin cậy, lúc đó phải rơi về quyền "Truy cập mọi tệp" cũ
            // (đã có sẵn, xem "requestManageStoragePermission" bên dưới).
            "pickModelFolder" -> {
                if (launchFolderPicker == null) {
                    result.error("NO_PICKER", "Thiết bị không hỗ trợ chọn thư mục 1 chạm", null)
                    return
                }
                if (pendingFolderPickResult != null) {
                    result.error("BUSY", "Đang có 1 lượt chọn thư mục khác chưa xong, thử lại sau", null)
                    return
                }
                pendingFolderPickResult = result
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    intent.addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    )
                    launchFolderPicker.invoke(intent)
                } catch (e: Throwable) {
                    kLog(appContext, "pickModelFolder: LOI mo picker: ${e.javaClass.simpleName}: ${e.message}")
                    pendingFolderPickResult = null
                    result.error("PICKER_LAUNCH_FAILED", "${e.javaClass.simpleName}: ${e.message}", null)
                }
            }
            "isIgnoringBatteryOptimizations" -> {
                val pm = appContext.getSystemService(android.os.PowerManager::class.java)
                result.success(pm?.isIgnoringBatteryOptimizations(appContext.packageName) ?: false)
            }
            "requestIgnoreBatteryOptimizations" -> {
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = android.net.Uri.parse("package:${appContext.packageName}")
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    appContext.startActivity(intent)
                    result.success(true)
                } catch (e: Throwable) {
                    kLog(appContext, "requestIgnoreBatteryOptimizations: LOI: ${e.javaClass.simpleName}: ${e.message}")
                    result.success(false)
                }
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "mất công vào cài đặt cài
            // thủ công quá"): quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE,
            // đã khai báo ở build.yml) là quyền ĐẶC BIỆT — khác POST_NOTIFICATIONS
            // hay battery optimization, Android KHÔNG cho phép bật bằng 1 hộp
            // thoại Cho phép/Từ chối đơn giản, kể cả app hệ thống cũng không lách
            // được. Google buộc phải đi qua 1 màn Cài đặt để người dùng tự gạt —
            // đây là chủ đích thiết kế bảo mật, không phải thiếu sót của app.
            // Cái CÓ THỂ làm để đỡ mất công: dùng Intent
            // ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION để mở THẲNG đúng
            // trang gạt quyền của app này (Android 11+/API 30+), thay vì bắt
            // người dùng tự mò Cài đặt > Ứng dụng > LocalNovel > Quyền > Tệp.
            // Trên Android 9-10 (minSdk 28, quyền này chưa tồn tại) coi như
            // luôn có quyền — dùng API cũ (READ/WRITE_EXTERNAL_STORAGE thường).
            "hasManageStoragePermission" -> {
                val has = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    android.os.Environment.isExternalStorageManager()
                } else {
                    true // Android 9-10: không có khái niệm quyền này, coi như đủ
                }
                result.success(has)
            }
            "requestManageStoragePermission" -> {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        // Mở thẳng trang gạt quyền CỦA APP NÀY — chỉ 1 công tắc,
                        // không phải mò trong danh sách toàn bộ app trên máy.
                        val intent = android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
                        )
                        intent.data = android.net.Uri.parse("package:${appContext.packageName}")
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        appContext.startActivity(intent)
                    }
                    result.success(true)
                } catch (e: Throwable) {
                    kLog(appContext, "requestManageStoragePermission: LOI đường dẫn app-cụ-thể: ${e.javaClass.simpleName}: ${e.message}")
                    // Dự phòng: 1 số ROM tuỳ biến (đặc biệt ASUS ZenUI, xem mục
                    // 5.66 tài liệu kiến trúc) có thể không có đúng màn app-cụ-thể
                    // — lùi về màn danh sách chung, người dùng tự tìm LocalNovel
                    // trong danh sách (vẫn đỡ hơn phải tự mò từ Cài đặt gốc).
                    try {
                        val fallback = android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
                        )
                        fallback.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        appContext.startActivity(fallback)
                        result.success(true)
                    } catch (e2: Throwable) {
                        kLog(appContext, "requestManageStoragePermission: LOI du phong: ${e2.javaClass.simpleName}: ${e2.message}")
                        result.success(false)
                    }
                }
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    // Được MainActivity gọi từ onActivityResult() khi người dùng đã chọn
    // xong (hoặc bấm huỷ) trong picker hệ thống của ACTION_OPEN_DOCUMENT_TREE.
    // uri = null nghĩa là người dùng bấm huỷ/back — trả về null cho Dart,
    // KHÔNG coi là lỗi (chỉ là chưa chọn gì, y hệt hành vi các app khác).
    fun onFolderPicked(uri: Uri?) {
        val callback = pendingFolderPickResult
        pendingFolderPickResult = null
        if (callback == null) return // không có ai đang chờ (không nên xảy ra)
        if (uri == null) {
            callback.success(null)
            return
        }
        try {
            appContext.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        } catch (e: Throwable) {
            kLog(appContext, "onFolderPicked: LOI giu quyen lau dai: ${e.javaClass.simpleName}: ${e.message}")
            // Không chặn luồng — vẫn thử tiếp resolve path, quyền tạm thời
            // trong phiên này vẫn đủ để đọc model ngay bây giờ.
        }
        val realPath = resolveRealPathFromTreeUri(uri)
        if (realPath != null) {
            kLog(appContext, "onFolderPicked: resolve duoc duong dan that = $realPath")
            callback.success(realPath)
        } else {
            kLog(appContext, "onFolderPicked: KHONG resolve duoc duong dan that tu uri=$uri (co the la the nho ngoai/USB)")
            callback.error(
                "PATH_UNRESOLVED",
                "Không xác định được đường dẫn thật của thư mục đã chọn (thường do đây là thẻ nhớ ngoài/USB)",
                null,
            )
        }
    }

    // Suy ra đường dẫn hệ thống file THẬT từ content:// tree URI của SAF —
    // CHỈ đáng tin cậy cho bộ nhớ TRONG chính máy ("primary"). Dựa theo
    // quy ước tài liệu Android: docId của node gốc cây thư mục có dạng
    // "<storageId>:<đường dẫn tương đối>", storageId="primary" nghĩa là ổ
    // đĩa chính (map thẳng sang /storage/emulated/0). Thẻ nhớ ngoài/USB có
    // storageId là mã UUID/serial riêng của từng thiết bị — KHÔNG có quy
    // tắc suy ra thư mục gắn thật đáng tin cậy trên mọi máy/ROM, nên trả
    // về null, để Dart hiện hướng dẫn dùng quyền "Truy cập mọi tệp" dự
    // phòng (đã có sẵn) cho đúng trường hợp hiếm này.
    private fun resolveRealPathFromTreeUri(treeUri: Uri): String? {
        return try {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val parts = docId.split(":", limit = 2)
            if (parts.size != 2) return null
            val storageId = parts[0]
            val relativePath = parts[1]
            if (!storageId.equals("primary", ignoreCase = true)) return null
            val base = Environment.getExternalStorageDirectory().absolutePath
            if (relativePath.isEmpty()) base else "$base/$relativePath"
        } catch (e: Throwable) {
            kLog(appContext, "resolveRealPathFromTreeUri: LOI: ${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }
}
