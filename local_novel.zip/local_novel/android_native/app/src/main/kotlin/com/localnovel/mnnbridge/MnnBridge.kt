package com.localnovel.mnnbridge

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.system.Os
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun logDir(context: Context): File = context.filesDir

private fun kLog(context: Context, msg: String) {
    try {
        val f = File(logDir(context), "native_debug.txt")
        val ts = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).format(Date())
        FileWriter(f, true).use { it.write("[$ts] [Kotlin] $msg\n") }
    } catch (_: Throwable) {}
}

private var qnnEnvSetupDone = false
private fun setupQnnEnvironmentOnce(context: Context) {
    if (qnnEnvSetupDone) return
    qnnEnvSetupDone = true
    try {
        val libDir = context.applicationInfo.nativeLibraryDir
        kLog(context, "setupQnnEnvironmentOnce: thu muc thu vien native = $libDir")
        Os.setenv("ADSP_LIBRARY_PATH", libDir, true)
        Os.setenv("LD_LIBRARY_PATH", libDir, true)
        kLog(context, "setupQnnEnvironmentOnce: da dat ADSP_LIBRARY_PATH va LD_LIBRARY_PATH = $libDir")
        // SUA LOI KIEN TRUC (phat hien khi doi chieu ky lai): libQnnHtpV68Skel.so
        // KHONG PHAI thu vien ARM64 — day la binary bien dich CHO CHINH
        // HEXAGON DSP (kien truc CPU hoan toan khac ARM64), chi chay duoc
        // BEN TRONG chip DSP, khong bao gio chay tren tien trinh ARM64 cua
        // app. Goi System.load() cho file nay se LUON LUON that bai (dung
        // linker cua Android/ARM64 khong the nap 1 file ELF cho kien truc
        // Hexagon) — BAT KE file co ton tai dung cho hay khong, bat ke
        // build.yml co copy dung hay khong. Day la 1 phan ly do TRUOC GIO
        // ca 5 dong log deu bao "THAT BAI", khien khong phan biet duoc dau
        // la loi that (4 file ARM64 kia thieu that) va dau la hanh vi BINH
        // THUONG DUOC MONG DOI (Skel luon "that bai" theo kieu nay).
        //
        // Cach dung: KHONG System.load() file Skel — chi can no NAM DUNG
        // CHO trong thu muc native (jniLibs/arm64-v8a, da duoc dat dung
        // ADSP_LIBRARY_PATH tro toi o tren) de chinh Qualcomm FastRPC/ADSP
        // runtime (chay o tang thap hon, khong qua System.load) tu tim va
        // day no vao DSP that khi can — dung theo tai lieu MNN Chat that.
        val libsToSystemLoad = listOf(
            "libQnnSystem.so",
            "libQnnHtp.so",
            "libQnnHtpPrepare.so",
            "libQnnHtpV68Stub.so",
        )
        for (name in libsToSystemLoad) {
            val fullPath = "$libDir/$name"
            try {
                System.load(fullPath)
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THANH CONG")
            } catch (e: Throwable) {
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THAT BAI: ${e.javaClass.simpleName}: ${e.message} — NEU day la 1 trong 4 file ARM64 that (System/Htp/HtpPrepare/Stub), day LA loi that, can kiem tra lai build.yml co copy dung file khong")
            }
        }
        // Chi kiem tra SU TON TAI cua file Skel (khong System.load()) — de
        // biet chac no co that trong APK hay khong, phong khi build.yml
        // copy thieu (Skel la file BAT BUOC de FastRPC tim thay tren DSP,
        // du khong System.load() no o tang ARM).
        val skelFile = java.io.File(libDir, "libQnnHtpV68Skel.so")
        if (skelFile.exists()) {
            kLog(context, "setupQnnEnvironmentOnce: libQnnHtpV68Skel.so CO TON TAI dung cho (${skelFile.length()} bytes) — se duoc FastRPC/ADSP tim thay qua ADSP_LIBRARY_PATH, khong can System.load()")
        } else {
            kLog(context, "setupQnnEnvironmentOnce: CANH BAO — libQnnHtpV68Skel.so KHONG TON TAI trong $libDir. Neu file nay thieu, QNN se khong bao gio chay duoc tren DSP that du 4 file kia nap thanh cong. Kiem tra lai buoc copy trong build.yml.")
        }
    } catch (e: Throwable) {
        kLog(context, "setupQnnEnvironmentOnce: LOI TONG QUAT: ${e.javaClass.simpleName}: ${e.message}")
    }
}

// ĐÃ THỬ RỒI BỎ (xem mục 5.75 tài liệu kiến trúc): từng thêm chọn thư mục
// qua Storage Access Framework (ACTION_OPEN_DOCUMENT_TREE) — build lỗi
// thật trên máy xác nhận: dù suy được "đường dẫn thật" từ URI, code native
// (fopen/opendir) vẫn KHÔNG đọc được nội dung (thư mục rỗng) vì quyền SAF
// chỉ cấp qua content:// URI, không cấp quyền đọc file hệ thống thô. Đã bỏ
// hẳn hướng này — quay về ĐÚNG 1 cơ chế duy nhất mà file manager thật dùng:
// quyền MANAGE_EXTERNAL_STORAGE (xin 1 lần, dùng mãi mãi cho mọi thư mục).
class MnnBridge(
    private val appContext: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
) : MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    private var eventSink: EventChannel.EventSink? = null
    private var currentJob: Job? = null
    // ĐÃ SỬA (2026-08-02, phát hiện qua thiết kế lồng nhau mới của
    // ChapterBatchService + generateWithOptionalTranslation): trước đây
    // `pipelineActive` là Boolean đơn giản — nếu 1 vòng lặp NGOÀI (vd tạo
    // hàng loạt nhiều chương) gọi beginPipeline() 1 lần bọc cả vòng lặp,
    // rồi BÊN TRONG mỗi lượt lại có 1 lệnh generate KHÁC (vd dịch thuật
    // trung gian) cũng tự gọi beginPipeline()/endPipeline() riêng — lệnh
    // endPipeline() của lượt BÊN TRONG sẽ tắt Foreground Service NGAY,
    // dù vòng lặp NGOÀI vẫn còn nhiều việc phải làm tiếp — tạo lại đúng
    // kiểu lỗ hổng "chớp tắt thông báo giữa các bước" đã sửa ở mục 5.61
    // cho xử lý tài liệu, nhưng giờ xảy ra với tạo chương hàng loạt có
    // dịch thuật trung gian. Đổi sang ĐẾM SỐ LẦN LỒNG NHAU (giống khoá
    // reentrant) — chỉ thực sự dừng Foreground Service khi bộ đếm về 0,
    // hỗ trợ đúng bất kỳ độ sâu lồng nhau nào mà không cần Dart phải biết
    ///xử lý đặc biệt cho từng trường hợp.
    private var pipelineDepth = 0
    private val pipelineDepthLock = Object()

    // ===== FIX BUG 2: mainHandler dùng để dispatch mọi lệnh service =====
    // Khai báo ở đây để dùng được trong cả onMethodCallInner VÀ truyền
    // xuống GenerationService — tránh tạo nhiều Handler object.
    private val mainHandler = Handler(Looper.getMainLooper())

    // ĐÃ THÊM (theo log runtime thật — người dùng phát hiện: thời gian THẬT
    // đo bằng std::chrono BÊN TRONG llm->response() (73s) lệch RẤT XA so
    // với thời gian tường (log timestamp cho thấy cách nhau 452s) — chênh
    // lệch ~379s. Nguyên nhân: `std::chrono::steady_clock` (C++) map tới
    // CLOCK_MONOTONIC trên Android/Linux — clock này KHÔNG đếm thời gian
    // lúc thiết bị NGỦ SÂU (suspend), khác CLOCK_BOOTTIME. Log timestamp
    // (system_clock, giờ tường) VẪN đếm — nên chênh lệch = ĐÚNG BẰNG thời
    // gian máy đã ngủ sâu GIỮA CHỪNG lúc đang sinh văn bản. Nghĩa là
    // WakeLock KHÔNG thực sự ngăn được máy ngủ trong trường hợp này.
    //
    // TÌM RA NGUYÊN NHÂN GỐC: `GenerationService.start()`/`.stop()` (gọi từ
    // `beginPipeline`/`loadModel`/`generate` bên dưới) chỉ `mainHandler.post{}`
    // (ĐẨY việc vào hàng đợi main thread rồi TRẢ VỀ NGAY, KHÔNG đợi
    // `onStartCommand()` thật sự chạy xong và giữ được WakeLock) — có 1
    // KHOẢNG HỞ THẬT giữa lúc `nativeGenerate()`/`nativeLoadModel()` BẮT ĐẦU
    // chạy (trên coroutine, gần như ngay lập tức) và lúc WakeLock của
    // `GenerationService` THỰC SỰ được giữ (phụ thuộc main thread Looper xử
    // lý xong Intent đã post) — nếu màn hình vừa tắt/máy vừa chuyển nền ĐÚNG
    // vào khoảnh khắc đó, hệ điều hành có thể bắt đầu ngủ sâu TRƯỚC KHI
    // WakeLock kịp giữ, và 1 khi đã ngủ, CHÍNH quá trình xử lý Intent đang
    // chờ trên hàng đợi main thread cũng bị đóng băng theo — vòng luẩn quẩn
    // không tự thoát ra được cho tới lần "cửa sổ bảo trì" định kỳ tiếp theo
    // của Doze/App Standby (có thể cách nhau nhiều phút).
    //
    // SỬA TẬN GỐC: giữ 1 WakeLock TRỰC TIẾP, ĐỒNG BỘ (không qua post/Intent/
    // Service nào cả) NGAY TẠI ĐÂY, trong CÙNG 1 khối `synchronized` dùng để
    // tăng/giảm `pipelineDepth` — đảm bảo KHÔNG CÓ khoảng hở nào giữa lúc
    // quyết định "đây là lệnh NGOÀI CÙNG" và lúc WakeLock thực sự được giữ.
    // `GenerationService` (thông báo + WakeLock riêng, làm mới mỗi 30 phút)
    // VẪN GIỮ NGUYÊN — coi như lớp bảo vệ THỨ 2 cho phiên chạy DÀI (nhiều
    // giờ/qua đêm), còn WakeLock trực tiếp ở đây là lớp bảo vệ TỨC THỜI cho
    // đúng khoảng hở khởi động, không cần tự làm mới định kỳ (chỉ giữ tối đa
    // 40 phút/lần, đủ dư cho tới khi GenerationService kịp khởi động thật).
    private var directWakeLock: PowerManager.WakeLock? = null
    private val directWakeLockGrantMs = 40 * 60 * 1000L

    private fun acquireDirectWakeLock() {
        if (directWakeLock == null) {
            val pm = appContext.getSystemService(Context.POWER_SERVICE) as PowerManager
            directWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalNovel::MnnBridgeDirectWakeLock")
            directWakeLock?.setReferenceCounted(false)
        }
        directWakeLock?.acquire(directWakeLockGrantMs)
    }

    private fun releaseDirectWakeLockIfHeld() {
        if (directWakeLock?.isHeld == true) directWakeLock?.release()
    }

    // Bọc CẢ 2 việc (WakeLock trực tiếp + GenerationService.start) làm 1 —
    // gọi đúng những nơi TRƯỚC ĐÂY chỉ gọi `GenerationService.start()`, để
    // không nơi nào lỡ quên phần WakeLock trực tiếp.
    private fun startGenerationServiceSync(stage: String) {
        acquireDirectWakeLock()
        GenerationService.start(appContext, stage, mainHandler)
    }

    private fun stopGenerationServiceSync() {
        releaseDirectWakeLockIfHeld()
        GenerationService.stop(appContext, mainHandler)
    }

    // ĐÃ THÊM (2026-08-02, phát hiện qua log thật — CHUỖI CRASH HEAP CORRUPTION
    // BÍ ẨN Ở MỤC 62-64 RẤT CÓ THỂ DO ĐÂY): `nativeLoadModel()` đã có sẵn khoá
    // chống gọi trùng (`g_loadingInProgress` phía C++), nhưng `nativeGenerate()`
    // KHÔNG HỀ CÓ khoá tương tự — log thật bắt được đúng lúc 2 lệnh generate
    // (chat + kiểm tra tính nhất quán chương) chạy ĐÈ LÊN NHAU trên CÙNG 1 slot
    // (slot 0), gây SIGSEGV liên tục 30 lần do 2 luồng cùng ghi/đọc chung 1 đối
    // tượng `Llm` native (KV-cache, buffer tính toán) không có cơ chế loại trừ
    // lẫn nhau (mutual exclusion). MNN's `Llm::response()` KHÔNG được thiết kế
    // để gọi đồng thời từ nhiều luồng trên CÙNG 1 instance.
    // Mỗi slot có 1 Mutex riêng — lệnh generate() cho CÙNG slot phải XẾP HÀNG
    // chờ lệnh trước xong (không bị từ chối, không mất yêu cầu, chỉ chờ), còn
    // slot 0 (model chính) và slot 1 (model dịch, nếu dùng) vẫn chạy độc lập
    // song song bình thường — đúng kiến trúc "2 slot" đã thiết kế từ đầu.
    private val generateMutexes = arrayOf(Mutex(), Mutex())

    private fun mutexForSlot(slot: Int): Mutex = generateMutexes.getOrElse(slot) { generateMutexes[0] }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            onMethodCallInner(call, result)
        } catch (e: Throwable) {
            kLog(appContext, "onMethodCall: LOI NGHIEM TRONG bat duoc o tang ngoai cung — method=${call.method}, loi=${e.javaClass.simpleName}: ${e.message}")
            try {
                result.error("UNCAUGHT_KOTLIN_ERROR", "${e.javaClass.simpleName}: ${e.message}", null)
            } catch (_: Throwable) {}
        }
    }

    private var logDirSent = false

    private fun onMethodCallInner(call: MethodCall, result: MethodChannel.Result) {
        if (!logDirSent) {
            MnnNative.nativeSetLogDir(appContext.filesDir.absolutePath)
            // ĐÃ THÊM: cache dir riêng cho OpenCL kernel tuning cache —
            // dùng cacheDir (Android tự dọn khi cần thêm dung lượng, an
            // toàn để làm dữ liệu tạm), khác files dir dùng cho log.
            MnnNative.nativeSetCacheDir(appContext.cacheDir.absolutePath)
            logDirSent = true
        }
        val slot = call.argument<Int>("slot") ?: MnnNative.SLOT_MAIN
        when (call.method) {
            "beginPipeline" -> {
                val stage = call.argument<String>("stage") ?: "Đang chuẩn bị..."
                // ĐÃ SỬA: chỉ THẬT SỰ gọi start() (bật thông báo mới) khi
                // đây là lần bọc NGOÀI CÙNG (độ sâu từ 0 lên 1) — nếu đã có
                // 1 pipeline khác đang chạy bọc bên ngoài (độ sâu > 0), chỉ
                // cập nhật nội dung thông báo, KHÔNG bật/tắt lại service.
                // ĐÃ SỬA THÊM (xem giải thích đầy đủ ở khai báo `directWakeLock`
                // phía trên): giữ WakeLock trực tiếp NGAY TRONG khối
                // `synchronized` này — trước lúc trả `result.success()` về
                // Dart, tức là trước khi bất kỳ `nativeGenerate()`/
                // `nativeLoadModel()` nào có cơ hội bắt đầu chạy.
                val isOutermost = synchronized(pipelineDepthLock) {
                    val was = pipelineDepth
                    pipelineDepth++
                    if (was == 0) acquireDirectWakeLock()
                    was == 0
                }
                if (isOutermost) {
                    // FIX: truyền mainHandler — gọi startForegroundService trên main thread
                    GenerationService.start(appContext, stage, mainHandler)
                } else {
                    GenerationService.updateStage(appContext, stage, mainHandler)
                }
                result.success(null)
            }
            "updateStage" -> {
                val stage = call.argument<String>("stage") ?: "Đang xử lý..."
                // FIX: truyền mainHandler
                GenerationService.updateStage(appContext, stage, mainHandler)
                result.success(null)
            }
            "endPipeline" -> {
                // ĐÃ SỬA: chỉ THẬT SỰ gọi stop() khi độ sâu về lại 0 (lần
                // endPipeline() cuối cùng khớp với lần beginPipeline() đầu
                // tiên) — nếu vẫn còn pipeline khác bọc bên ngoài đang chạy
                // dở (độ sâu > 0 sau khi giảm), KHÔNG tắt thông báo, để
                // vòng lặp bên ngoài tự tắt khi thật sự xong.
                val isOutermost = synchronized(pipelineDepthLock) {
                    if (pipelineDepth > 0) pipelineDepth--
                    val nowZero = pipelineDepth == 0
                    if (nowZero) releaseDirectWakeLockIfHeld()
                    nowZero
                }
                if (isOutermost) {
                    // FIX: truyền mainHandler
                    GenerationService.stop(appContext, mainHandler)
                }
                result.success(null)
            }
            "loadModel" -> {
                val configPath = call.argument<String>("configPath")
                val backendPreference = call.argument<Int>("backendPreference") ?: 0
                if (configPath == null) {
                    result.error("BAD_ARGS", "Thiếu configPath", null)
                    return
                }
                kLog(appContext, "loadModel: CHUAN BI goi GenerationService (pipelineDepth=$pipelineDepth)")
                // ĐÃ SỬA (2026-08-27 — bằng chứng thật từ log: STEADY=137495ms
                // nhưng WALL=1376108ms, chênh ~1239 GIÂY = máy ngủ sâu GIỮA
                // CHỪNG lúc generate() đang chạy, dù đoạn code này TƯỞNG đã có
                // WakeLock bảo vệ): trước đây CHỈ gọi acquireDirectWakeLock()
                // khi pipelineDepth==0 (tin tưởng nếu >0 thì đã có 1 lệnh
                // beginPipeline() NGOÀI giữ sẵn WakeLock). Nhưng pipelineDepth
                // có thể bị "kẹt" ở giá trị >0 VĨNH VIỄN nếu 1 lệnh generate()
                // TRƯỚC ĐÓ bị treo (xem mục D/E trong tài liệu kiến trúc — log
                // thật xác nhận CÓ xảy ra) và never chạm tới finally/endPipeline
                // tương ứng phía Dart để giảm lại bộ đếm — mọi lệnh SAU ĐÓ
                // trong cùng tiến trình mãi mãi nghĩ "đã có người giữ WakeLock
                // rồi", trong khi WakeLock thật (nếu có) từ lâu đã hết hạn (tối
                // đa 40 phút) hoặc chưa từng được giữ. Giờ LUÔN gọi
                // acquireDirectWakeLock() bất kể pipelineDepth — an toàn tuyệt
                // đối vì đây là WakeLock KHÔNG đếm tham chiếu
                // (setReferenceCounted(false)): gọi acquire() nhiều lần chỉ LÀM
                // MỚI hạn 40 phút, không cần release() thêm tương ứng.
                acquireDirectWakeLock()
                if (pipelineDepth > 0) {
                    // FIX: truyền mainHandler
                    GenerationService.updateStage(appContext, "Đang nạp model...", mainHandler)
                } else {
                    // FIX: truyền mainHandler
                    GenerationService.start(appContext, "Đang nạp model...", mainHandler)
                }
                kLog(appContext, "loadModel: GenerationService scheduled (main thread), chuan bi scope.launch...")
                if (backendPreference == 0) {
                    setupQnnEnvironmentOnce(appContext)
                }
                scope.launch {
                    try {
                        kLog(appContext, "loadModel: BEN TRONG coroutine, chuan bi goi MnnNative.nativeLoadModel...")
                        val ok = MnnNative.nativeLoadModel(slot, configPath, backendPreference)
                        val backend = if (ok) MnnNative.nativeActiveBackend(slot) else "loi"
                        mainHandler.post { result.success(mapOf("success" to ok, "backend" to backend)) }
                    } catch (e: Throwable) {
                        kLog(appContext, "loadModel: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post { result.error("LOAD_FAILED", e.message ?: "Lỗi nạp model không rõ nguyên nhân", null) }
                    } finally {
                        // FIX: truyền mainHandler
                        if (pipelineDepth == 0) {
                            releaseDirectWakeLockIfHeld()
                            GenerationService.stop(appContext, mainHandler)
                        }
                    }
                }
            }
            "generate" -> {
                val prompt = call.argument<String>("prompt")
                val stageLabel = call.argument<String>("stageLabel") ?: "Đang sinh văn bản..."
                val temperature = call.argument<Double>("temperature") ?: 0.9
                val topP = call.argument<Double>("topP") ?: 0.9
                val topK = call.argument<Int>("topK") ?: 40
                val repetitionPenalty = call.argument<Double>("repetitionPenalty") ?: 1.05
                val maxNewTokens = call.argument<Int>("maxNewTokens") ?: 1024
                // ĐÃ THÊM: reuse_kv — tham số CHÍNH THỨC của MNN (tài liệu
                // alibaba/MNN: "Whether to reuse the kv cache in multi-turn
                // dialogues. Defaults to false") — giảm thời gian chờ prefill
                // cho các lượt chat SAU lượt đầu trong cùng phiên, vì không
                // phải tính lại KV-cache cho phần system prompt + lịch sử đã
                // xử lý ở lượt trước. CHỈ bật true cho hội thoại thật sự
                // nhiều lượt (chat_screen.dart) — luôn false cho tác vụ 1
                // lần độc lập (dịch/tóm tắt từng đoạn tài liệu) để tránh lẫn
                // ngữ cảnh sai giữa các đoạn không liên quan.
                val reuseKv = call.argument<Boolean>("reuseKv") ?: false
                if (prompt == null) {
                    result.error("BAD_ARGS", "Thiếu prompt", null)
                    return
                }
                kLog(appContext, "generate: da doc xong tham so tu Dart, chuan bi tao JSON config...")
                val configJson = JSONObject().apply {
                    put("temperature", temperature)
                    put("top_p", topP)
                    put("top_k", topK)
                    put("repetition_penalty", repetitionPenalty)
                    put("max_new_tokens", maxNewTokens)
                    put("reuse_kv", reuseKv)
                }.toString()
                kLog(appContext, "generate: config JSON xong: $configJson. Chuan bi goi GenerationService (pipelineDepth=$pipelineDepth)...")

                // ĐÃ SỬA (2026-08-27) — xem giải thích đầy đủ ở nhánh
                // "loadModel" phía trên, áp dụng y hệt cho generate(): không
                // còn tin tưởng pipelineDepth>0 để bỏ qua acquire — luôn gọi.
                acquireDirectWakeLock()
                if (pipelineDepth > 0) {
                    // FIX: truyền mainHandler
                    GenerationService.updateStage(appContext, stageLabel, mainHandler)
                } else {
                    // FIX: truyền mainHandler — ĐÂY LÀ ĐIỂM FIX CHÍNH CHO LỖI 2
                    // Trước đây gọi GenerationService.start() trực tiếp từ
                    // onMethodCallInner (chạy trên Binder thread của Flutter,
                    // KHÔNG phải main thread) → ForegroundServiceStartNotAllowedException.
                    // Giờ GenerationService.start() sẽ post lên main thread trước.
                    GenerationService.start(appContext, stageLabel, mainHandler)
                }
                kLog(appContext, "generate: GenerationService scheduled, chuan bi scope.launch...")
                currentJob = scope.launch {
                    try {
                        kLog(appContext, "generate: BEN TRONG coroutine, chuan bi cho khoa (mutex) cho slot=$slot truoc khi goi nativeGenerate...")
                        // ĐÃ THÊM: khoá theo slot — nếu slot này đang có 1 lệnh
                        // generate() khác chạy dở (vd chat đang chờ, đồng thời
                        // kiểm tra tính nhất quán chương cũng gọi generate trên
                        // CÙNG slot), lệnh này sẽ CHỜ ở đây cho tới khi lệnh
                        // trước xong hẳn, KHÔNG chạy song song — tránh 2 luồng
                        // cùng đụng vào 1 đối tượng Llm native cùng lúc (nguyên
                        // nhân rất có thể của chuỗi crash "heap corruption" bí
                        // ẩn ở mục 62-64). Xem giải thích đầy đủ ở khai báo
                        // generateMutexes phía trên.
                        mutexForSlot(slot).withLock {
                            kLog(appContext, "generate: DA CO khoa cho slot=$slot, chuan bi goi MnnNative.nativeGenerate...")
                            MnnNative.nativeGenerate(slot, prompt, configJson, object : MnnNative.TokenCallback {
                                override fun onToken(token: String, done: Boolean) {
                                    // ĐÃ THÊM (theo yêu cầu người dùng — điều tra "khung chat
                                    // không sinh chữ, đợi lâu"): log RIÊNG BIỆT 2 mốc — (1)
                                    // lúc JNI THẬT SỰ gọi vào onToken() (trên thread native/
                                    // coroutine đang giữ mutex), và (2) lúc Runnable được
                                    // `mainHandler.post` THẬT SỰ chạy (trên main thread). Nếu
                                    // khoảng cách giữa 2 mốc này LỚN, nghĩa là hàng đợi
                                    // (MessageQueue) của MAIN THREAD bị nghẽn/trễ — đúng nghi
                                    // vấn "mất khả năng chạy nền" (Android có thể hạ ưu tiên xử
                                    // lý MAIN THREAD khi app không hiển thị, dù WakeLock vẫn giữ
                                    // CPU thức và Foreground Service vẫn sống — 2 thứ đó bảo vệ
                                    // TIẾN TRÌNH không bị giết và CPU không ngủ, KHÔNG đảm bảo
                                    // main thread được lập lịch NGAY LẬP TỨC). CHỈ log khi
                                    // done=true (tín hiệu cuối) để tránh spam file log hàng trăm
                                    // dòng/giây khi đang stream từng token.
                                    if (done) {
                                        kLog(appContext, "onToken: JNI goi vao (done=true)")
                                    }
                                    mainHandler.post {
                                        if (done) {
                                            kLog(appContext, "onToken: mainHandler.post THAT SU chay (done=true)")
                                        }
                                        eventSink?.success(mapOf("token" to token, "done" to done, "slot" to slot))
                                    }
                                }
                            })
                        }
                        kLog(appContext, "generate: MnnNative.nativeGenerate() TRA VE XONG (khong crash), da tha khoa")
                        mainHandler.post { result.success(null) }
                    } catch (e: Throwable) {
                        kLog(appContext, "generate: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post {
                            eventSink?.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                            result.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                        }
                    } finally {
                        // FIX: truyền mainHandler
                        if (pipelineDepth == 0) {
                            releaseDirectWakeLockIfHeld()
                            GenerationService.stop(appContext, mainHandler)
                        }
                    }
                }
            }
            "cancelGenerate" -> {
                currentJob?.cancel()
                // ĐÃ THÊM (theo yêu cầu người dùng — "làm tiếp phần chặn lặp
                // ở tầng gốc"): trước đây chỉ huỷ được Job coroutine bọc
                // ngoài — nếu lệnh gọi native `llm->response()` ĐÃ ĐANG chạy
                // (trường hợp thường gặp nhất, vì đây là lời gọi JNI đồng bộ
                // dài), huỷ Job không có tác dụng gì với nó cả, nó vẫn chạy
                // tới hết `max_new_tokens`. Giờ gọi thêm cờ huỷ NATIVE — có
                // tác dụng thật, được `JniStreamingBuf` kiểm tra ở lần ghi
                // token tiếp theo (xem mnn_bridge.cpp).
                MnnNative.nativeRequestCancel(slot)
                // ĐÃ SỬA: huỷ thủ công phải RESET HẲN bộ đếm về 0 (không chỉ
                // giảm 1) — người dùng chủ động huỷ nghĩa là muốn dừng TOÀN
                // BỘ pipeline đang chạy, kể cả khi đang lồng nhiều lớp.
                // ĐÃ SỬA THÊM: reset kèm luôn thả WakeLock trực tiếp (nếu
                // đang giữ) — cùng lý do, huỷ thủ công phải dọn sạch MỌI tài
                // nguyên đã giữ cho pipeline, không chỉ bộ đếm.
                synchronized(pipelineDepthLock) {
                    pipelineDepth = 0
                    releaseDirectWakeLockIfHeld()
                }
                // FIX: truyền mainHandler
                GenerationService.stop(appContext, mainHandler)
                result.success(null)
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "sao tác vụ nền không báo có
            // bất cứ cái gì hết" khi 1 lệnh generate() mồ côi từ phiên TRƯỚC
            // vẫn đang chạy — đúng, `BackgroundTaskManager` phía Dart chỉ là
            // 1 List trong RAM của phiên HIỆN TẠI, không biết gì về phiên đã
            // đóng). Cho Dart hỏi thẳng native — nơi DUY NHẤT còn giữ đúng sự
            // thật slot có đang bận hay không.
            "isSlotGenerating" -> {
                result.success(MnnNative.nativeIsGenerating(slot))
            }
            "unload" -> {
                scope.launch {
                    MnnNative.nativeUnload(slot)
                    mainHandler.post { result.success(null) }
                }
            }
            "isLoaded" -> {
                result.success(MnnNative.nativeIsLoaded(slot))
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "hệ thống này đặc biệt để
            // treo máy, sáng dậy thấy chết thì dẹp luôn dự án"): lớp phòng
            // vệ CUỐI CÙNG cho độ tin cậy chạy xuyên đêm — Foreground
            // Service + WakeLock tự làm mới (mục 5.71) bảo vệ được ở tầng
            // Android chuẩn, nhưng 1 số OEM (đặc biệt ASUS ZenUI, đúng máy
            // test — xem mục 5.66) có trình quản lý pin RIÊNG, tự ý kill
            // app nền bất kể Foreground Service đúng chuẩn hay không, trừ
            // khi người dùng TỰ TAY loại trừ app khỏi tối ưu hoá pin.
            // Android không cho phép app tự động tắt hẳn tối ưu hoá pin
            // cho chính mình — chỉ có thể MỞ HỘP THOẠI HỆ THỐNG để người
            // dùng tự xác nhận (yêu cầu bảo mật, không thể bỏ qua).
            "isIgnoringBatteryOptimizations" -> {
                val pm = appContext.getSystemService(android.os.PowerManager::class.java)
                result.success(pm?.isIgnoringBatteryOptimizations(appContext.packageName) ?: false)
            }
            "requestIgnoreBatteryOptimizations" -> {
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = android.net.Uri.parse("package:${appContext.packageName}")
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    appContext.startActivity(intent)
                    result.success(true)
                } catch (e: Throwable) {
                    kLog(appContext, "requestIgnoreBatteryOptimizations: LOI: ${e.javaClass.simpleName}: ${e.message}")
                    result.success(false)
                }
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "mất công vào cài đặt cài
            // thủ công quá"): quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE,
            // đã khai báo ở build.yml) là quyền ĐẶC BIỆT — khác POST_NOTIFICATIONS
            // hay battery optimization, Android KHÔNG cho phép bật bằng 1 hộp
            // thoại Cho phép/Từ chối đơn giản, kể cả app hệ thống cũng không lách
            // được. Google buộc phải đi qua 1 màn Cài đặt để người dùng tự gạt —
            // đây là chủ đích thiết kế bảo mật, không phải thiếu sót của app.
            // Cái CÓ THỂ làm để đỡ mất công: dùng Intent
            // ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION để mở THẲNG đúng
            // trang gạt quyền của app này (Android 11+/API 30+), thay vì bắt
            // người dùng tự mò Cài đặt > Ứng dụng > LocalNovel > Quyền > Tệp.
            // Trên Android 9-10 (minSdk 28, quyền này chưa tồn tại) coi như
            // luôn có quyền — dùng API cũ (READ/WRITE_EXTERNAL_STORAGE thường).
            "hasManageStoragePermission" -> {
                val has = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    android.os.Environment.isExternalStorageManager()
                } else {
                    true // Android 9-10: không có khái niệm quyền này, coi như đủ
                }
                result.success(has)
            }
            "requestManageStoragePermission" -> {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        // Mở thẳng trang gạt quyền CỦA APP NÀY — chỉ 1 công tắc,
                        // không phải mò trong danh sách toàn bộ app trên máy.
                        val intent = android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
                        )
                        intent.data = android.net.Uri.parse("package:${appContext.packageName}")
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        appContext.startActivity(intent)
                    }
                    result.success(true)
                } catch (e: Throwable) {
                    kLog(appContext, "requestManageStoragePermission: LOI đường dẫn app-cụ-thể: ${e.javaClass.simpleName}: ${e.message}")
                    // Dự phòng: 1 số ROM tuỳ biến (đặc biệt ASUS ZenUI, xem mục
                    // 5.66 tài liệu kiến trúc) có thể không có đúng màn app-cụ-thể
                    // — lùi về màn danh sách chung, người dùng tự tìm LocalNovel
                    // trong danh sách (vẫn đỡ hơn phải tự mò từ Cài đặt gốc).
                    try {
                        val fallback = android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
                        )
                        fallback.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        appContext.startActivity(fallback)
                        result.success(true)
                    } catch (e2: Throwable) {
                        kLog(appContext, "requestManageStoragePermission: LOI du phong: ${e2.javaClass.simpleName}: ${e2.message}")
                        result.success(false)
                    }
                }
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }
}
