package com.localnovel.mnnbridge

import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job

// Lớp trung gian giữa Flutter (Dart, qua MethodChannel/EventChannel) và
// tầng native MnnNative (JNI/C++). Mọi lỗi từ tầng native được bắt lại
// và trả về Flutter dưới dạng lỗi có thông báo rõ ràng, không để app
// Android crash cứng — vì lỗi native (native crash) sẽ làm sập cả ứng
// dụng Flutter, khác với exception Dart bình thường có thể hiển thị
// cho người dùng và cho phép thử lại.
class MnnBridge(private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)) :
    MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    private var eventSink: EventChannel.EventSink? = null
    private var currentJob: Job? = null

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "loadModel" -> {
                val configPath = call.argument<String>("configPath")
                if (configPath == null) {
                    result.error("BAD_ARGS", "Thiếu configPath", null)
                    return
                }
                scope.launch {
                    try {
                        // backendPreference = 0: luôn thử QNN trước, không
                        // kiểm tra danh sách máy được phép — máy nào chạy
                        // được thì tận dụng, không thì tự rơi về GPU/CPU.
                        val ok = MnnNative.nativeLoadModel(configPath, 0)
                        val backend = if (ok) MnnNative.nativeActiveBackend() else "loi"
                        result.success(mapOf("success" to ok, "backend" to backend))
                    } catch (e: Throwable) {
                        result.error("LOAD_FAILED", e.message ?: "Lỗi nạp model không rõ nguyên nhân", null)
                    }
                }
            }
            "generate" -> {
                val prompt = call.argument<String>("prompt")
                if (prompt == null) {
                    result.error("BAD_ARGS", "Thiếu prompt", null)
                    return
                }
                currentJob = scope.launch {
                    try {
                        MnnNative.nativeGenerate(prompt, object : MnnNative.TokenCallback {
                            override fun onToken(token: String, done: Boolean) {
                                eventSink?.success(mapOf("token" to token, "done" to done))
                            }
                        })
                        result.success(null)
                    } catch (e: Throwable) {
                        eventSink?.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                        result.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                    }
                }
            }
            "cancelGenerate" -> {
                currentJob?.cancel()
                result.success(null)
            }
            "unload" -> {
                scope.launch {
                    MnnNative.nativeUnload()
                    result.success(null)
                }
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }
}
