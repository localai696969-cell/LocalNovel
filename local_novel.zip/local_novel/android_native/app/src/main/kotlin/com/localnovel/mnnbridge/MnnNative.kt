package com.localnovel.mnnbridge

// Lớp khai báo các hàm native (JNI) — tên gói/lớp ở đây PHẢI khớp chính
// xác với tên hàm JNI trong mnn_bridge.cpp (Java_com_localnovel_mnnbridge_MnnNative_...).
//
// slot 0 = model chính (viết truyện), slot 1 = model dịch thuật trung
// gian (tùy chọn, nhỏ). Cả 2 slot độc lập hoàn toàn — có thể cùng tồn
// tại trong RAM (máy khỏe) hoặc xả từng cái theo tuần tự (máy yếu),
// tùy MnnBridge quyết định, không hardcode ở đây.
object MnnNative {
    const val SLOT_MAIN = 0
    const val SLOT_TRANSLATION = 1

    init {
        System.loadLibrary("mnn_bridge")
    }

    external fun nativeLoadModel(slot: Int, configPath: String, backendPreference: Int): Boolean

    external fun nativeSetLogDir(dir: String)

    external fun nativeGenerate(slot: Int, prompt: String, generationConfigJson: String, callback: TokenCallback)

    external fun nativeUnload(slot: Int)

    external fun nativeIsLoaded(slot: Int): Boolean

    external fun nativeActiveBackend(slot: Int): String

    interface TokenCallback {
        fun onToken(token: String, done: Boolean)
    }
}
