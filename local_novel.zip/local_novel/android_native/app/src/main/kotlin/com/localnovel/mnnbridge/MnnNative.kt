package com.localnovel.mnnbridge

// Lớp khai báo các hàm native (JNI) — tên gói/lớp ở đây PHẢI khớp chính
// xác với tên hàm JNI trong mnn_bridge.cpp (Java_com_localnovel_mnnbridge_MnnNative_...).
//
// slot 0 = model chính (viết truyện), slot 1 = model dịch thuật trung
// gian (tùy chọn, nhỏ). Cả 2 slot độc lập hoàn toàn — có thể cùng tồn
// tại trong RAM (máy khỏe) hoặc xả từng cái theo tuần tự (máy yếu),
// tùy MnnBridge quyết định, không hardcode ở đây.
object MnnNative {
    const val SLOT_MAIN = 0
    const val SLOT_TRANSLATION = 1

    init {
        System.loadLibrary("mnn_bridge")
    }

    external fun nativeLoadModel(slot: Int, configPath: String, backendPreference: Int): Boolean

    external fun nativeSetLogDir(dir: String)

    // ĐÃ THÊM: đường dẫn cache riêng cho OpenCL kernel tuning (tmp_path)
    // — xem giải thích đầy đủ ở buildOptimizedOpenCLConfig() trong
    // mnn_bridge.cpp.
    external fun nativeSetCacheDir(dir: String)

    external fun nativeGenerate(slot: Int, prompt: String, generationConfigJson: String, callback: TokenCallback)

    external fun nativeUnload(slot: Int)

    external fun nativeIsLoaded(slot: Int): Boolean

    external fun nativeActiveBackend(slot: Int): String

    // ĐÃ THÊM (theo yêu cầu người dùng — làm cho "cancelGenerate" có tác
    // dụng THẬT với lệnh generate() đang chạy dưới native, không chỉ huỷ
    // Job coroutine bọc ngoài như trước): xem giải thích đầy đủ ở
    // mnn_bridge.cpp, khai báo g_cancelRequested.
    external fun nativeRequestCancel(slot: Int)

    // ĐÃ THÊM: cho phép tầng Dart hỏi thẳng native xem slot có đang thật
    // sự bận (kể cả bận vì 1 lệnh MỒ CÔI từ phiên trước) hay không — dùng
    // để hiện đúng tình trạng ở màn "Tác vụ nền" thay vì im lặng khó
    // hiểu khi Dart-side List các tác vụ đã mất theo phiên cũ.
    external fun nativeIsGenerating(slot: Int): Boolean

    interface TokenCallback {
        fun onToken(token: String, done: Boolean)
    }
}
