package com.localnovel.mnnbridge

// Lớp khai báo các hàm native (JNI) — tên gói/lớp ở đây PHẢI khớp chính
// xác với tên hàm JNI trong mnn_bridge.cpp (Java_com_localnovel_mnnbridge_MnnNative_...),
// vì JNI ánh xạ theo đúng tên gói+lớp+hàm dạng chuỗi, không phải theo
// interface như gọi hàm Kotlin bình thường. Đổi package/tên lớp này thì
// phải đổi cả tên hàm bên file .cpp.
object MnnNative {
    init {
        System.loadLibrary("mnn_bridge")
    }

    external fun nativeLoadModel(configPath: String, backendPreference: Int): Boolean

    external fun nativeGenerate(prompt: String, callback: TokenCallback)

    external fun nativeUnload()

    external fun nativeActiveBackend(): String

    interface TokenCallback {
        fun onToken(token: String, done: Boolean)
    }
}
