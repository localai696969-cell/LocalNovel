import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/story_models.dart';
import 'services/settings_service.dart';
import 'services/background_task_manager.dart';
import 'services/providers/local_provider.dart';
import 'services/text_scale_service.dart';
import 'screens/chapters_screen.dart';
import 'screens/story_bible_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/document_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/backup_restore_screen.dart';

void main() {
  runApp(const TruongThienApp());
}

class TruongThienApp extends StatelessWidget {
  const TruongThienApp({super.key});

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: nạp cỡ chữ đã lưu (nếu có) TRƯỚC KHI build cây widget đầu
    // tiên — gọi `loadOnce()` ở đây (không phải trong 1 `initState` riêng)
    // vì `TruongThienApp` là widget GỐC NHẤT, khớp đúng nơi cần đảm bảo
    // giá trị đã sẵn sàng trước khi bất kỳ màn hình con nào render.
    TextScaleService.instance.loadOnce();
    return ValueListenableBuilder<double>(
      valueListenable: TextScaleService.instance.scale,
      builder: (context, textScale, _) {
        return MaterialApp(
          title: 'LocalNovel',
          theme: ThemeData(colorSchemeSeed: const Color(0xFFA32D2D), useMaterial3: true),
          darkTheme: ThemeData(
            colorSchemeSeed: const Color(0xFFA32D2D),
            brightness: Brightness.dark,
            useMaterial3: true,
          ),
          // ĐÃ THÊM (theo yêu cầu người dùng: "tất cả các màn hình có tính
          // năng zoom không" — trước đây không hề có gì): `builder` là nơi
          // DUY NHẤT cần sửa để áp dụng cỡ chữ cho TOÀN BỘ MỌI MÀN HÌNH
          // cùng lúc — `MediaQuery` là widget tổ tiên chung của mọi route,
          // mọi `Text`/`TextField` trong app đều tự đọc `textScaler` từ
          // đây, không cần sửa riêng từng màn hình. Xem `TextScaleService`
          // để biết vì sao chọn cách này thay vì pinch-gesture thật.
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(textScale)),
              child: child!,
            );
          },
          // Cổng vào: tự động mở thẳng truyện đang active nếu đã có, nếu
          // chưa (lần đầu mở app, hoặc vừa xóa hết truyện) thì hiện danh
          // sách/màn tạo truyện trước.
          home: const NovelGateScreen(),
        );
      },
    );
  }
}

// Quyết định hiện gì đầu tiên: nếu đã có truyện active đã lưu từ lần
// trước, vào thẳng RootScreen của truyện đó — không bắt chọn lại mỗi
// lần mở app. Nếu chưa, hiện danh sách truyện.
class NovelGateScreen extends StatefulWidget {
  const NovelGateScreen({super.key});
  @override
  State<NovelGateScreen> createState() => _NovelGateScreenState();
}

class _NovelGateScreenState extends State<NovelGateScreen> {
  final settings = SettingsService();
  bool loading = true;
  Novel? activeNovel;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  Future<void> _resolve() async {
    final activeId = await settings.loadActiveNovelId();
    if (activeId != null) {
      final novel = await settings.db.novelById(activeId);
      if (novel != null) {
        if (!mounted) return;
        setState(() {
          activeNovel = novel;
          loading = false;
        });
        return;
      }
    }
    if (!mounted) return;
    setState(() => loading = false);
  }

  // ĐÃ SỬA (lỗi build thật, người dùng gửi log CI xác nhận): hộp thoại này
  // trước đây bị chèn NHẦM vào class `_NovelGateScreenState` (do câu lệnh
  // sửa file khớp trúng đoạn code giống hệt `if (loading) {...}` xuất hiện
  // ở CẢ 2 class) trong khi nút gọi nó lại nằm ở `_NovelListScreenState` —
  // 2 class khác nhau, nên biên dịch báo "method không tồn tại". Đã
  // chuyển đúng xuống `_NovelListScreenState` bên dưới.

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (activeNovel != null) {
      return RootScreen(novelId: activeNovel!.id, novelTitle: activeNovel!.title);
    }
    return const NovelListScreen();
  }
}

// Danh sách truyện — tạo mới, chọn 1 truyện để mở, xóa truyện (kèm toàn
// bộ dữ liệu riêng của nó: chương, nhân vật, luật, chat, tài liệu).
class NovelListScreen extends StatefulWidget {
  const NovelListScreen({super.key});
  @override
  State<NovelListScreen> createState() => _NovelListScreenState();
}

class _NovelListScreenState extends State<NovelListScreen> {
  final settings = SettingsService();
  List<Novel> novels = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await settings.allNovels();
    if (!mounted) return;
    setState(() {
      novels = all;
      loading = false;
    });
  }

  Future<void> _createNovel() async {
    final titleCtrl = TextEditingController();
    final authorCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Truyện mới'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên truyện')),
          TextField(controller: authorCtrl, decoration: const InputDecoration(labelText: 'Tác giả (tùy chọn)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Tạo')),
        ],
      ),
    );
    if (ok != true || titleCtrl.text.trim().isEmpty) return;
    final novel = await settings.createNovel(titleCtrl.text.trim(), author: authorCtrl.text.trim());
    await _openNovel(novel);
  }

  Future<void> _openNovel(Novel novel) async {
    await settings.setActiveNovel(novel.id);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => RootScreen(novelId: novel.id, novelTitle: novel.title)),
    );
  }

  Future<void> _deleteNovel(Novel novel) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa truyện này?'),
        content: Text(
          'Toàn bộ chương, nhân vật, luật thế giới, cuộc trò chuyện và tài liệu '
          'của "${novel.title}" sẽ bị xóa vĩnh viễn, không khôi phục được.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Xóa vĩnh viễn'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await settings.deleteNovel(novel.id);
      _load();
    }
  }

  // ĐÃ SỬA (chuyển ĐÚNG vào class này — `_NovelListScreenState` — trước
  // đây bị chèn nhầm vào `_NovelGateScreenState` do lỗi tìm-thay-thế khi
  // sửa file, gây lỗi build "method không tồn tại" đã xác nhận qua log
  // CI): hộp thoại chỉnh cỡ chữ toàn app — đặt ở màn "Truyện của bạn" vì
  // đây là màn LUÔN vào được (kể cả khi chưa có truyện nào), khác với các
  // cài đặt khác nằm trong Cài đặt CỦA 1 truyện cụ thể.
  void _showTextScaleDialog(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          return AlertDialog(
            title: const Text('Cỡ chữ'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Áp dụng cho MỌI màn hình trong app (không chỉ màn này) — kể cả chương, chat, '
                  'Bách khoa, Cài đặt...',
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
                const SizedBox(height: 16),
                ValueListenableBuilder<double>(
                  valueListenable: TextScaleService.instance.scale,
                  builder: (context, value, _) {
                    return Column(
                      children: [
                        Text('Aa', style: TextStyle(fontSize: 16 * value)),
                        Slider(
                          value: value,
                          min: TextScaleService.min,
                          max: TextScaleService.max,
                          divisions: 15,
                          label: '${(value * 100).round()}%',
                          onChanged: (v) => TextScaleService.instance.setScale(v),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => TextScaleService.instance.setScale(TextScaleService.defaultScale),
                child: const Text('Về mặc định'),
              ),
              FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Xong')),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Truyện của bạn'),
        // ĐÃ THÊM (theo yêu cầu người dùng: "cái tính năng sao lưu hồi
        // phục thì không có nút restore ở màn hình tổng trước khi vào dự
        // án truyện à" — đúng, trước đây `BackupRestoreScreen` bắt buộc
        // phải có `novelId`, chỉ mở được từ Cài đặt CỦA 1 TRUYỆN ĐÃ TỒN
        // TẠI — người mất sạch dữ liệu/cài máy mới thì không có truyện
        // nào để mở Cài đặt, nghịch lý đúng lúc cần khôi phục nhất lại
        // không vào được). `BackupRestoreScreen` giờ nhận `novelId` dạng
        // nullable — gọi ở đây với `null`, tự ẩn phần "sao lưu 1 truyện"
        // (không có truyện nào đang mở), giữ nguyên "sao lưu toàn app" +
        // "khôi phục từ file" hoạt động bình thường.
        actions: [
          IconButton(
            icon: const Icon(Icons.text_fields),
            tooltip: 'Cỡ chữ (áp dụng cho mọi màn hình)',
            onPressed: () => _showTextScaleDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.settings_backup_restore_outlined),
            tooltip: 'Sao lưu & khôi phục',
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const BackupRestoreScreen()));
              // Khôi phục xong có thể thêm truyện mới trên máy — tải lại
              // danh sách khi quay về màn này để thấy ngay, không cần thoát
              // app như ghi chú trong SnackBar (ghi chú đó vẫn đúng cho các
              // màn KHÁC đang mở, nhưng riêng danh sách truyện ở màn này thì
              // tự làm mới được).
              _load();
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createNovel,
        icon: const Icon(Icons.add),
        label: const Text('Truyện mới'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : novels.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.auto_stories_outlined, size: 48, color: Colors.grey),
                      const SizedBox(height: 12),
                      const Text(
                        'Chưa có truyện nào. Bấm "Truyện mới" để bắt đầu — '
                        'mỗi truyện có Story Bible, chương, chat và tài liệu hoàn toàn riêng.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ]),
                  ),
                )
              : ListView.builder(
                  itemCount: novels.length,
                  itemBuilder: (context, i) {
                    final n = novels[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.menu_book_outlined)),
                        title: Text(n.title),
                        subtitle: Text(n.author.isEmpty ? 'Chưa có tác giả' : n.author),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _deleteNovel(n),
                        ),
                        onTap: () => _openNovel(n),
                      ),
                    );
                  },
                ),
    );
  }
}

class RootScreen extends StatefulWidget {
  final String novelId;
  final String novelTitle;
  const RootScreen({super.key, required this.novelId, required this.novelTitle});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int index = 0;

  // ĐÃ THÊM: SỬA LỖI "tạo Quyển/Hồi ở tab Chương nhưng tab Bách khoa vẫn báo
  // chưa có quyển nào" (và các lỗi tương tự — vd chương mới không hiện bên
  // tab khác). Nguyên nhân gốc: `IndexedStack` bên dưới giữ CẢ 5 TAB SỐNG
  // CÙNG LÚC, đổi tab chỉ đổi WIDGET NÀO HIỂN THỊ chứ KHÔNG dispose/tạo lại
  // State — nên `_load()` gọi 1 lần trong `initState()` của từng tab không
  // bao giờ tự chạy lại khi dữ liệu bị đổi từ 1 tab khác. `GlobalKey` ở đây
  // cho phép gọi thẳng `refreshData()` (method public mới thêm) của đúng
  // State đang sống trong IndexedStack mỗi khi người dùng CHUYỂN SANG tab
  // Chương hoặc Bách khoa — đảm bảo dữ liệu luôn khớp DB mới nhất, không
  // cần dispose/tạo lại toàn bộ tab (vẫn giữ được vị trí cuộn, tab con...
  // đang mở trong từng màn).
  final _chaptersKey = GlobalKey<State<ChaptersScreen>>();
  final _bibleKey = GlobalKey<State<StoryBibleScreen>>();

  void _onDestinationSelected(int i) {
    setState(() => index = i);
    // dynamic vì State (_ChaptersScreenState/_StoryBibleScreenState) là
    // private trong file của nó — method `refreshData()` vẫn public nên
    // gọi được qua dynamic dispatch từ đây.
    if (i == 0) {
      final st = _chaptersKey.currentState;
      if (st != null) (st as dynamic).refreshData();
    }
    if (i == 1) {
      final st = _bibleKey.currentState;
      if (st != null) (st as dynamic).refreshData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      ChaptersScreen(key: _chaptersKey, novelId: widget.novelId, novelTitle: widget.novelTitle),
      StoryBibleScreen(key: _bibleKey, novelId: widget.novelId),
      ChatScreen(novelId: widget.novelId),
      DocumentScreen(novelId: widget.novelId),
      SettingsScreen(novelId: widget.novelId),
    ];
    // ĐÃ THÊM (theo phản hồi người dùng thật: vuốt gesture quay lại lỡ tay
    // ở màn gốc này = thoát hẳn app, trong khi 1 lệnh generate() local vẫn
    // đang chạy dở phía native — bấy giờ nó thành "mồ côi" (log thật:
    // "TU CHOI NAP MODEL MOI ... lenh generate() TU PHIEN TRUOC van con
    // chay do"), KHOÁ CỨNG slot model đó tới khi lệnh cũ tự chạy xong,
    // không nạp được model nào khác — kể cả mở lại app). `RootScreen` là
    // route GỐC (không còn gì để pop phía dưới), nên back-gesture ở đây
    // luôn có nghĩa là "thoát app" — đúng điểm cần chặn.
    //
    // CHỈ hỏi lại khi THẬT SỰ có tác vụ đang CHẠY (`runningCount > 0`) —
    // tác vụ mới xếp hàng (`queued`, chưa động tới native) thì thoát luôn
    // không sao, huỷ được sạch sẽ, không cần làm phiền người dùng.
    return PopScope(
      canPop: BackgroundTaskManager.instance.runningCount == 0,
      onPopInvoked: (didPop) async {
        if (didPop) return; // không có tác vụ đang chạy — đã thoát bình thường, không cần làm gì thêm
        final manager = BackgroundTaskManager.instance;
        final confirmed = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Thoát khi AI đang chạy?'),
            content: Text(
              'Đang có ${manager.runningCount} tác vụ AI chạy nền (chat, viết chương...). '
              'Chọn "Vẫn thoát" sẽ tự dừng các tác vụ này lại trước (đợi tối đa vài giây) rồi mới '
              'thoát hẳn — giữ được phần chữ đã sinh ra tới lúc đó. Nếu tắt app đột ngột thay vì '
              'dùng nút này, phần chữ đang sinh dở có thể bị MẤT (chưa kịp lưu) và model có thể bị '
              'khoá tạm thời (không nạp được model khác) cho tới khi lệnh cũ tự chạy xong.\n\n'
              'Bạn có chắc muốn thoát không?',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Ở lại')),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
                onPressed: () => Navigator.pop(ctx, true),
                // ĐÃ SỬA (theo phản hồi người dùng: "cái từ thoát vẫn là gì
                // nhỉ" — đúng, thứ tự từ cũ đọc lên hơi ngược/khó hiểu):
                // "Vẫn thoát" tự nhiên hơn "Thoát vẫn" trong tiếng Việt.
                child: const Text('Vẫn thoát'),
              ),
            ],
          ),
        );
        if (confirmed != true) return;

        // ĐÃ SỬA TẬN GỐC (theo phản hồi người dùng: "đã thoát rồi mà vẫn
        // còn chạy thì thoát trở nên vô nghĩa", VÀ "chữ đã nặn ra màn hình
        // sau khi thoát quay lại thì biến mất"): trước đây gọi
        // `requestCancel()` (chỉ đặt 1 cờ, KHÔNG đợi gì) rồi
        // `SystemNavigator.pop()` NGAY LẬP TỨC — trong khi việc huỷ thật
        // sự (native nhận được lệnh + `llm->response()` thoát ra +
        // `finally` của `chat_screen.dart` LƯU phần chữ đã sinh vào DB)
        // đều xảy ra BẤT ĐỒNG BỘ, cần vài giây — app thường bị đóng
        // TRƯỚC khi các bước đó kịp chạy xong, nên: (a) slot vẫn bị khoá
        // (lệnh cũ chưa kịp nhận tín hiệu huỷ), (b) phần chữ đã sinh mất
        // sạch (chưa kịp ghi DB). Giờ CHỜ THẬT: gọi huỷ trực tiếp xuống
        // native cho CẢ 2 slot (nhanh hơn, không cần đợi consumer Dart
        // nhận được chunk tiếp theo mới kích hoạt như đường cũ), rồi
        // POLL `manager.runningCount` (chỉ về 0 sau khi khối `finally`
        // trong `chat_screen.dart` — nơi có `db.upsertChatMessage(reply)`
        // — đã chạy xong) tối đa 10 giây trước khi thật sự thoát. Hiện 1
        // hộp thoại nhỏ không tắt được trong lúc chờ để người dùng biết
        // đang có việc xảy ra, không tưởng app bị treo.
        if (context.mounted) {
          showDialog<void>(
            context: context,
            barrierDismissible: false,
            builder: (_) => const AlertDialog(
              content: Row(
                children: [
                  SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)),
                  SizedBox(width: 16),
                  Expanded(child: Text('Đang dừng AI và lưu phần đã sinh...')),
                ],
              ),
            ),
          );
        }
        for (final t in manager.tasks) {
          if (t.status == TaskStatus.running || t.status == TaskStatus.queued) {
            manager.requestCancel(t.id);
          }
        }
        await LocalLlamaProvider.requestCancelSlot(0);
        await LocalLlamaProvider.requestCancelSlot(1);
        final deadline = DateTime.now().add(const Duration(seconds: 10));
        while (manager.runningCount > 0 && DateTime.now().isBefore(deadline)) {
          await Future<void>.delayed(const Duration(milliseconds: 300));
        }
        if (context.mounted) Navigator.of(context, rootNavigator: true).pop(); // đóng hộp "Đang dừng..."
        SystemNavigator.pop();
      },
      child: Scaffold(
        body: IndexedStack(index: index, children: screens),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: _onDestinationSelected,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Chương'),
            NavigationDestination(icon: Icon(Icons.auto_stories_outlined), label: 'Bách khoa'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Trợ lý AI'),
            NavigationDestination(icon: Icon(Icons.description_outlined), label: 'Tài liệu'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Cài đặt'),
          ],
        ),
      ),
    );
  }
}
