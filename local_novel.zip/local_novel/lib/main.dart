import 'package:flutter/material.dart';
import 'models/story_models.dart';
import 'services/settings_service.dart';
import 'screens/chapters_screen.dart';
import 'screens/story_bible_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/document_screen.dart';
import 'screens/settings_screen.dart';

void main() {
  runApp(const TruongThienApp());
}

class TruongThienApp extends StatelessWidget {
  const TruongThienApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LocalNovel',
      theme: ThemeData(colorSchemeSeed: const Color(0xFFA32D2D), useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: const Color(0xFFA32D2D),
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      // Cổng vào: tự động mở thẳng truyện đang active nếu đã có, nếu
      // chưa (lần đầu mở app, hoặc vừa xóa hết truyện) thì hiện danh
      // sách/màn tạo truyện trước.
      home: const NovelGateScreen(),
    );
  }
}

// Quyết định hiện gì đầu tiên: nếu đã có truyện active đã lưu từ lần
// trước, vào thẳng RootScreen của truyện đó — không bắt chọn lại mỗi
// lần mở app. Nếu chưa, hiện danh sách truyện.
class NovelGateScreen extends StatefulWidget {
  const NovelGateScreen({super.key});
  @override
  State<NovelGateScreen> createState() => _NovelGateScreenState();
}

class _NovelGateScreenState extends State<NovelGateScreen> {
  final settings = SettingsService();
  bool loading = true;
  Novel? activeNovel;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  Future<void> _resolve() async {
    final activeId = await settings.loadActiveNovelId();
    if (activeId != null) {
      final novel = await settings.db.novelById(activeId);
      if (novel != null) {
        if (!mounted) return;
        setState(() {
          activeNovel = novel;
          loading = false;
        });
        return;
      }
    }
    if (!mounted) return;
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (activeNovel != null) {
      return RootScreen(novelId: activeNovel!.id, novelTitle: activeNovel!.title);
    }
    return const NovelListScreen();
  }
}

// Danh sách truyện — tạo mới, chọn 1 truyện để mở, xóa truyện (kèm toàn
// bộ dữ liệu riêng của nó: chương, nhân vật, luật, chat, tài liệu).
class NovelListScreen extends StatefulWidget {
  const NovelListScreen({super.key});
  @override
  State<NovelListScreen> createState() => _NovelListScreenState();
}

class _NovelListScreenState extends State<NovelListScreen> {
  final settings = SettingsService();
  List<Novel> novels = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await settings.allNovels();
    if (!mounted) return;
    setState(() {
      novels = all;
      loading = false;
    });
  }

  Future<void> _createNovel() async {
    final titleCtrl = TextEditingController();
    final authorCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Truyện mới'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên truyện')),
          TextField(controller: authorCtrl, decoration: const InputDecoration(labelText: 'Tác giả (tùy chọn)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Tạo')),
        ],
      ),
    );
    if (ok != true || titleCtrl.text.trim().isEmpty) return;
    final novel = await settings.createNovel(titleCtrl.text.trim(), author: authorCtrl.text.trim());
    await _openNovel(novel);
  }

  Future<void> _openNovel(Novel novel) async {
    await settings.setActiveNovel(novel.id);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => RootScreen(novelId: novel.id, novelTitle: novel.title)),
    );
  }

  Future<void> _deleteNovel(Novel novel) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa truyện này?'),
        content: Text(
          'Toàn bộ chương, nhân vật, luật thế giới, cuộc trò chuyện và tài liệu '
          'của "${novel.title}" sẽ bị xóa vĩnh viễn, không khôi phục được.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Xóa vĩnh viễn'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await settings.deleteNovel(novel.id);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Truyện của bạn')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createNovel,
        icon: const Icon(Icons.add),
        label: const Text('Truyện mới'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : novels.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.auto_stories_outlined, size: 48, color: Colors.grey),
                      const SizedBox(height: 12),
                      const Text(
                        'Chưa có truyện nào. Bấm "Truyện mới" để bắt đầu — '
                        'mỗi truyện có Story Bible, chương, chat và tài liệu hoàn toàn riêng.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ]),
                  ),
                )
              : ListView.builder(
                  itemCount: novels.length,
                  itemBuilder: (context, i) {
                    final n = novels[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.menu_book_outlined)),
                        title: Text(n.title),
                        subtitle: Text(n.author.isEmpty ? 'Chưa có tác giả' : n.author),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _deleteNovel(n),
                        ),
                        onTap: () => _openNovel(n),
                      ),
                    );
                  },
                ),
    );
  }
}

class RootScreen extends StatefulWidget {
  final String novelId;
  final String novelTitle;
  const RootScreen({super.key, required this.novelId, required this.novelTitle});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int index = 0;

  // ĐÃ THÊM: SỬA LỖI "tạo Quyển/Hồi ở tab Chương nhưng tab Bách khoa vẫn báo
  // chưa có quyển nào" (và các lỗi tương tự — vd chương mới không hiện bên
  // tab khác). Nguyên nhân gốc: `IndexedStack` bên dưới giữ CẢ 5 TAB SỐNG
  // CÙNG LÚC, đổi tab chỉ đổi WIDGET NÀO HIỂN THỊ chứ KHÔNG dispose/tạo lại
  // State — nên `_load()` gọi 1 lần trong `initState()` của từng tab không
  // bao giờ tự chạy lại khi dữ liệu bị đổi từ 1 tab khác. `GlobalKey` ở đây
  // cho phép gọi thẳng `refreshData()` (method public mới thêm) của đúng
  // State đang sống trong IndexedStack mỗi khi người dùng CHUYỂN SANG tab
  // Chương hoặc Bách khoa — đảm bảo dữ liệu luôn khớp DB mới nhất, không
  // cần dispose/tạo lại toàn bộ tab (vẫn giữ được vị trí cuộn, tab con...
  // đang mở trong từng màn).
  final _chaptersKey = GlobalKey<State<ChaptersScreen>>();
  final _bibleKey = GlobalKey<State<StoryBibleScreen>>();

  void _onDestinationSelected(int i) {
    setState(() => index = i);
    // dynamic vì State (_ChaptersScreenState/_StoryBibleScreenState) là
    // private trong file của nó — method `refreshData()` vẫn public nên
    // gọi được qua dynamic dispatch từ đây.
    if (i == 0) {
      final st = _chaptersKey.currentState;
      if (st != null) (st as dynamic).refreshData();
    }
    if (i == 1) {
      final st = _bibleKey.currentState;
      if (st != null) (st as dynamic).refreshData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      ChaptersScreen(key: _chaptersKey, novelId: widget.novelId, novelTitle: widget.novelTitle),
      StoryBibleScreen(key: _bibleKey, novelId: widget.novelId),
      ChatScreen(novelId: widget.novelId),
      DocumentScreen(novelId: widget.novelId),
      const SettingsScreen(),
    ];
    return Scaffold(
      body: IndexedStack(index: index, children: screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: _onDestinationSelected,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Chương'),
          NavigationDestination(icon: Icon(Icons.auto_stories_outlined), label: 'Bách khoa'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Trợ lý AI'),
          NavigationDestination(icon: Icon(Icons.description_outlined), label: 'Tài liệu'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Cài đặt'),
        ],
      ),
    );
  }
}
