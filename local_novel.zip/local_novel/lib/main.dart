import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'models/story_models.dart';
import 'services/settings_service.dart';
import 'services/background_task_manager.dart';
import 'services/providers/local_provider.dart';
import 'services/text_scale_service.dart';
import 'services/debug_log_service.dart';
import 'services/database_service.dart';
import 'screens/chapters_screen.dart';
import 'screens/story_bible_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/document_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/backup_restore_screen.dart';

void main() {
  // ĐÃ THÊM (mục AD tài liệu kiến trúc, 2026-09-10): sau 2 lượt liền log
  // thật vẫn cho thấy `repetition_penalty:1.05` dù đã báo "đã sửa" (mục
  // AC) — không có cách nào phân biệt qua log CŨ xem đó là do code còn
  // sai hay do APK đang chạy CHƯA PHẢI bản build mới nhất (build.yml lỗi/
  // quên upload lại zip/cài nhầm APK cũ...). Ghi 1 dòng DUY NHẤT, DÒNG
  // ĐẦU TIÊN của debug_log.txt mỗi lần mở app, nêu rõ mã build đang chạy
  // — lần sau gửi log, nhìn đúng dòng này là biết ngay APK có đúng bản
  // mới hay không, không cần đoán/suy diễn qua nhiều bước gián tiếp nữa.
  // ĐÃ THÊM (mục AE, 2026-09-11): log ngày 2026-09-10 (build mucAD, ĐÃ CÓ
  // `_migrateToV16`) vẫn ra `repetition_penalty:1.05` — tức là `_migrateToV16`
  // (chỉ chạy 1 LẦN, bên trong `onUpgrade`, chỉ khi oldVersion<16) hoặc chưa
  // từng chạy tới trên máy đó, hoặc chạy nhưng bỏ sót đúng dòng bị kẹt (nghi
  // vấn lệch dấu phẩy động, so khớp tuyệt đối `=` quá chặt). Thêm
  // `_selfHealStuckRepetitionPenalty` (ngưỡng sai số, gọi lại được MỖI LẦN
  // mở app, không chỉ lúc nâng schema — xem database_service.dart) + log
  // trực tiếp giá trị repetitionPenalty thật sự nạp ra cho từng novelId
  // NGAY TẠI NGUỒN (settings_service.dart, thay vì chỉ suy luận gián tiếp
  // qua JSON native ở tầng Kotlin cách xa nơi quyết định giá trị).
  // ĐÃ THÊM (mục AF, 2026-09-11): log 09:53-09:54 cùng ngày (build mucAE)
  // cho thấy `_selfHealStuckRepetitionPenalty` chạy ĐÚNG (0 novel cần sửa
  // — DB đang đúng) nhưng 46 GIÂY SAU, cùng phiên, cùng novel lại đọc ra
  // 1.05 — tìm ra nguyên nhân thật: "Lost Update" ở `renameNovel()`/khôi
  // phục Data Integrity ghi đè cả hàng bằng 1 `Novel` object cũ (xem mục
  // AF tài liệu kiến trúc). Đã vá — không còn nơi nào ghi đè cả object.
  // ĐÃ THÊM (mục AG, 2026-09-11): log 11:44-11:45 cùng ngày (build mucAF)
  // lặp lại Y HỆT kịch bản mục AE dù đã vá `renameNovel`/Data Integrity —
  // rà tĩnh (đọc code) đã hết cách tìm thêm call site khả nghi mới. Thêm
  // log TRỰC TIẾP vào MỌI nơi có khả năng ghi cột `gen_repetition_penalty`
  // (đã rà lại LẦN NỮA cho chắc: upsertNovel/updateNovelSettings/
  // updateNovelGenerationConfig/importNovelData/importAllData) — không còn
  // suy luận, để log TỰ NÓI ra thủ phạm thật ở lần chạy kế tiếp. Nhân tiện
  // vá luôn 1 lỗi khác người dùng phát hiện, KHÔNG liên quan trực tiếp tới
  // repetitionPenalty (đã xác nhận qua code: chưa từng đụng tới trước mục
  // AG): nút "X" ở Tác vụ nền không huỷ được lệnh "Soạn chương" (Viết
  // tiếp/Đắp thịt/...) vì `_generateRespectingTranslation` chưa từng
  // truyền `onCancelRequested` — xem mục AG tài liệu kiến trúc.
  // ĐÃ THÊM (mục AH, 2026-09-11): log 17:02-17:08 cùng ngày (build mucAG,
  // đã có log ở MỌI nơi ghi cột) CHỈ ĐÍCH DANH thủ phạm thật, không còn
  // suy đoán: `[GHI gen_repetition_penalty] origin=importNovelData
  // novelId=... newValue=1.05` — khôi phục backup .zip cũ (từ TRƯỚC mục
  // AC) mang legacy value quay lại. Đã vá: tự chữa lành NGAY sau khi
  // import xong (cả theo-truyện lẫn toàn-app), không đợi tới lần mở app
  // kế tiếp — xem mục AH tài liệu kiến trúc.
  // ĐÃ THÊM (mục AI, 2026-09-11): sau khi mục AH xác nhận `repetitionPenalty`
  // đã chảy đúng 1.15 tới tận native — CHƯƠNG VẪN KHÔNG SINH ĐƯỢC, dừng ở
  // ĐÚNG 60 ký tự y hệt mọi lần trước (kể cả lúc còn 1.05). Rà lại mục Z
  // tài liệu kiến trúc: bản vá gốc (native lần đầu nhận diện đúng lặp
  // tiếng Việt đa byte) đã tự nhận là RỦI RO CHƯA XÁC NHẬN cho đúng luồng
  // "Đắp thịt" — giờ có đủ dữ liệu thật để xác nhận. Đã nới ngưỡng tối
  // thiểu trước khi bộ dò bắt đầu xét (60→320 byte, cho model "đường băng"
  // dài hơn) + ghi thẳng NỘI DUNG THẬT bị coi là lặp ra log (trước đây chỉ
  // ghi SỐ LƯỢNG ký tự) — xem mục AI tài liệu kiến trúc.
  // ĐÃ THÊM (mục AJ, 2026-09-12 — TỰ PHÊ BÌNH): log ngay sau mục AI cho
  // thấy vẫn cắt ở 60 ký tự — vì mục AI CHỈ sửa bộ dò native, bỏ sót bộ dò
  // THỨ HAI ở tầng Dart (`local_provider.dart`) mà chính mục Z đã ghi rõ
  // là tồn tại riêng — dù mục AI đọc và trích dẫn đúng đoạn đó. Đã áp
  // đúng cùng 1 thay đổi (60→320 + ghi nội dung thật) vào bộ dò Dart —
  // xem mục AJ tài liệu kiến trúc.
  // ĐÃ THÊM (mục AL, 2026-09-12 — NGUYÊN NHÂN GỐC THẬT SỰ, xác nhận qua
  // tài liệu chính thức MNN + người dùng trực tiếp xác nhận model lặp ký
  // tự đơn liên tục): `sampler_type: "mixed"` chỉ chạy đúng các sampler có
  // mặt trong `mixed_samplers` — mặc định KHÔNG có "penalty" trong đó.
  // `repetition_penalty` (1.0/1.05/1.15, mục AC-AJ) CHƯA TỪNG được áp
  // dụng thật khi sinh — khớp đúng lý do mục AI/AJ không giải quyết được
  // gì (nới ngưỡng bộ dò không thể sửa 1 model không có lớp chống lặp nào
  // đang chạy thật). Đã thêm "penalty" vào `mixed_samplers` gửi kèm mỗi
  // lần generate() — xem mục AL tài liệu kiến trúc.
  // ĐÃ THÊM (mục AM, 2026-09-12 — SỬA LỖI TREO do chính mục AL gây ra):
  // log gửi sau mục AL dừng hẳn ở "CHUAN BI goi llm->response()", không
  // có gì thêm — rất có thể `mixed_samplers` đặt qua `set_config()` LẦN
  // THỨ HAI (lúc generate, sau lúc load) làm treo hẳn pipeline sampler.
  // Đã chuyển `mixed_samplers` sang đặt lúc LOAD (set_config trước
  // `load()`, đúng lúc pipeline dựng lần đầu) ở cả 3 nhánh backend
  // (OpenCL/QNN/CPU), bỏ hẳn khỏi JSON phía Kotlin lúc generate — xem
  // mục AM tài liệu kiến trúc.
  // ĐÃ THÊM (mục AN, 2026-09-12 — SỬA LỖI BUILD do chính mục AM gây ra):
  // GitHub Actions #129 build THẤT BẠI — lỗi cú pháp C++ thật sự
  // (`invalid operands to binary expression`, KHÔNG PHẢI lỗi runtime):
  // cộng thẳng 2 chuỗi ký tự thô liền nhau trong `buildOptimizedOpenCLConfig()`
  // (C++ không có `operator+` cho `const char[N] + const char[M]`). Đã
  // bọc `std::string(...)` quanh literal đầu tiên để phép + hợp lệ trở
  // lại — không đổi nội dung JSON, chỉ sửa cú pháp.
  // ĐÃ THÊM (mục AO, 2026-09-13): log sau mục AN (build qua được) cho thấy
  // model sinh "#" rồi lặp "F" vô hạn ngay từ ký tự thứ 2 — ngưỡng mới
  // (mục AI/AJ, 320) chỉ trì hoãn phát hiện (315-347 ký tự thay vì 60),
  // KHÔNG ngăn được việc lặp bắt đầu. Chưa xác nhận được "penalty" trong
  // `mixed_samplers` (mục AM) có thật sự tới được config load OpenCL hay
  // không — log cũ không in ra nội dung JSON thật. Đã thêm log in thẳng
  // chuỗi JSON gửi vào set_config() lúc load — xem mục AO tài liệu kiến
  // trúc.
  // ĐÃ THÊM — mục AP, 2026-09-13 — NGUYÊN NHÂN GỐC THẬT SỰ CỦA TOÀN BỘ
  // CHUỖI "lặp ký tự đơn" từ đầu hội thoại: model (OccultAI/Morpheus-8B-v1)
  // yêu cầu đúng khuôn chat Llama 3, prompt cũ chỉ nối thô không có token
  // ranh giới — đã xác nhận qua thực nghiệm (dán đoạn dài vào CHÍNH màn
  // Chat cũng lặp "F" y hệt). Đã áp đúng khuôn Llama 3
  // (`<|start_header_id|>`/`<|eot_id|>`) khi ghép prompt gửi native — xem
  // mục AP tài liệu kiến trúc.
  // ĐÃ THÊM (mục AQ, 2026-09-13 — thay cách hardcode ở mục AP theo đúng
  // góp ý người dùng): bật `use_template: true` — để MNN tự đọc đúng
  // `prompt_template` có sẵn trong `llm_config.json` của TỪNG model (do
  // `llmexport.py` tự trích lúc xuất model) thay vì app tự đoán/hardcode
  // 1 khuôn cụ thể. Tổng quát cho MỌI model xuất chuẩn, không riêng model
  // đang dùng — xem mục AQ tài liệu kiến trúc.
  // ĐÃ THÊM (mục AR, 2026-09-13 — thay mục AQ, theo đúng phản biện người
  // dùng: "MNN Chat/công nghệ MNN chắc chắn đã tính đến chuyện này"):
  // chính app Android CHÍNH THỨC của đội MNN (MnnLlmChat) xác nhận có
  // tham số cấu hình RIÊNG "system prompt" — không phải nhét chung vào 1
  // chuỗi. Tách hẳn `systemPrompt` khỏi `prompt`, gửi qua khoá
  // `system_prompt` trong config — để MNN (đã dùng Jinja thật, tự áp
  // đúng chat_template gốc của từng model) tự dựng đúng cấu trúc
  // system/user, không cần app tự đoán khuôn hay gộp chuỗi thủ công nữa.
  // ĐÃ THÊM (mục AS, 2026-09-13 — REVERT mục AR, nguyên nhân hồi quy thật):
  // người dùng phát hiện model Qwen2.5-7B (khuôn HOÀN TOÀN KHÁC model 8B)
  // trước kia ổn với prompt dài, CÙNG NGÀY hôm nay cũng ra rác — chỉ tay
  // thẳng vào đúng 1 thay đổi CHUNG cho mọi model: mục AR (tách
  // system_prompt thành field riêng, rất có thể KHÔNG được MNN bản đang
  // build đọc, làm mất hẳn Story Bible/văn phong). Đã revert — gộp lại
  // systemPrompt+userPrompt thành 1 chuỗi như trước mục AP, giữ nguyên
  // use_template=true (mục AQ). Cũng sửa lại: model 8B THẬT SỰ là kiến
  // trúc Tencent Hunyuan (xác nhận qua chính llm_config.json trên máy),
  // không phải Llama 3 như mục AP từng tin nhầm từ 1 kết quả tìm kiếm
  // web không khớp — xem mục AS tài liệu kiến trúc.
  unawaited(DebugLogService.instance.log(
      'main(): mo app — MA_NGUON_BUILD=mucAS_2026-09-13 (gom: mục Z native repetition-loop UTF-8, '
      'mục AA/AB chặn ghi rác kAiFailureMarker, mục AC repetitionPenalty gốc 1.05->1.15, '
      'mục AE tu-chua-lanh repetitionPenalty moi lan mo app + log truc tiep tai nguon, '
      'mục AF vá Lost Update renameNovel/DataIntegrity ghi de ca hang, '
      'mục AG log MOI noi co the ghi gen_repetition_penalty + va nut Huy tac vu nen Soan chuong, '
      'mục AH tim ra THU PHAM THAT qua log (importNovelData/backup cu) + tu chua lanh ngay sau import, '
      'mục AI noi nguong toi thieu bo do lap NATIVE 60->320 byte + ghi noi dung that ra log, '
      'mục AJ ap dung NGUYEN VEN cung ban va do cho bo do lap tang DART bi bo sot o muc AI, '
      'mục AL them "penalty" vao mixed_samplers — NGUYEN NHAN GOC: repetition_penalty chua tung duoc ap dung that, '
      'mục AM SUA LOI TREO do mục AL — chuyen mixed_samplers sang set_config LUC LOAD thay vi luc generate, '
      'mục AN SUA LOI BUILD (C++ syntax) do chinh mục AM gay ra — build #129 that bai, '
      'mục AO ghi log config OpenCL THAT gui vao set_config luc load — chua xac nhan duoc penalty co toi noi hay khong, '
      'mục AP NGUYEN NHAN GOC THAT (SAI — xem mục AS): tuong la khuon Llama 3, thuc ra la Hunyuan, '
      'mục AQ thay hardcode Llama 3 (mục AP) bang use_template=true — MNN tu doc prompt_template dung cho TUNG model, '
      'mục AR thay mục AQ bang system_prompt rieng biet — dung tham so CHINH THUC cua MNN nhung gay hoi quy, '
      'mục AS REVERT mục AR (bang chung cheo model Qwen 7B) + sua nhan dien kien truc that la Hunyuan), '
      'DatabaseService.schemaVersion=${DatabaseService.schemaVersion}'));
  runApp(const TruongThienApp());
}

class TruongThienApp extends StatelessWidget {
  const TruongThienApp({super.key});

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: nạp cỡ chữ đã lưu (nếu có) TRƯỚC KHI build cây widget đầu
    // tiên — gọi `loadOnce()` ở đây (không phải trong 1 `initState` riêng)
    // vì `TruongThienApp` là widget GỐC NHẤT, khớp đúng nơi cần đảm bảo
    // giá trị đã sẵn sàng trước khi bất kỳ màn hình con nào render.
    TextScaleService.instance.loadOnce();
    return ValueListenableBuilder<double>(
      valueListenable: TextScaleService.instance.scale,
      builder: (context, textScale, _) {
        return MaterialApp(
          title: 'LocalNovel',
          theme: ThemeData(colorSchemeSeed: const Color(0xFFA32D2D), useMaterial3: true),
          darkTheme: ThemeData(
            colorSchemeSeed: const Color(0xFFA32D2D),
            brightness: Brightness.dark,
            useMaterial3: true,
          ),
          // ĐÃ THÊM (theo yêu cầu người dùng: "tất cả các màn hình có tính
          // năng zoom không" — trước đây không hề có gì): `builder` là nơi
          // DUY NHẤT cần sửa để áp dụng cỡ chữ cho TOÀN BỘ MỌI MÀN HÌNH
          // cùng lúc — `MediaQuery` là widget tổ tiên chung của mọi route,
          // mọi `Text`/`TextField` trong app đều tự đọc `textScaler` từ
          // đây, không cần sửa riêng từng màn hình. Xem `TextScaleService`
          // để biết vì sao chọn cách này thay vì pinch-gesture thật.
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(textScale)),
              child: child!,
            );
          },
          // Cổng vào: tự động mở thẳng truyện đang active nếu đã có, nếu
          // chưa (lần đầu mở app, hoặc vừa xóa hết truyện) thì hiện danh
          // sách/màn tạo truyện trước.
          home: const NovelGateScreen(),
        );
      },
    );
  }
}

// Quyết định hiện gì đầu tiên: nếu đã có truyện active đã lưu từ lần
// trước, vào thẳng RootScreen của truyện đó — không bắt chọn lại mỗi
// lần mở app. Nếu chưa, hiện danh sách truyện.
class NovelGateScreen extends StatefulWidget {
  const NovelGateScreen({super.key});
  @override
  State<NovelGateScreen> createState() => _NovelGateScreenState();
}

class _NovelGateScreenState extends State<NovelGateScreen> {
  final settings = SettingsService();
  bool loading = true;
  Novel? activeNovel;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  Future<void> _resolve() async {
    final activeId = await settings.loadActiveNovelId();
    if (activeId != null) {
      final novel = await settings.db.novelById(activeId);
      if (novel != null) {
        if (!mounted) return;
        setState(() {
          activeNovel = novel;
          loading = false;
        });
        return;
      }
    }
    if (!mounted) return;
    setState(() => loading = false);
  }

  // ĐÃ SỬA (lỗi build thật, người dùng gửi log CI xác nhận): hộp thoại này
  // trước đây bị chèn NHẦM vào class `_NovelGateScreenState` (do câu lệnh
  // sửa file khớp trúng đoạn code giống hệt `if (loading) {...}` xuất hiện
  // ở CẢ 2 class) trong khi nút gọi nó lại nằm ở `_NovelListScreenState` —
  // 2 class khác nhau, nên biên dịch báo "method không tồn tại". Đã
  // chuyển đúng xuống `_NovelListScreenState` bên dưới.

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (activeNovel != null) {
      return RootScreen(novelId: activeNovel!.id, novelTitle: activeNovel!.title);
    }
    return const NovelListScreen();
  }
}

// Danh sách truyện — tạo mới, chọn 1 truyện để mở, xóa truyện (kèm toàn
// bộ dữ liệu riêng của nó: chương, nhân vật, luật, chat, tài liệu).
class NovelListScreen extends StatefulWidget {
  const NovelListScreen({super.key});
  @override
  State<NovelListScreen> createState() => _NovelListScreenState();
}

class _NovelListScreenState extends State<NovelListScreen> {
  final settings = SettingsService();
  List<Novel> novels = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await settings.allNovels();
    if (!mounted) return;
    setState(() {
      novels = all;
      loading = false;
    });
  }

  Future<void> _createNovel() async {
    final titleCtrl = TextEditingController();
    final authorCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Truyện mới'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên truyện')),
          TextField(controller: authorCtrl, decoration: const InputDecoration(labelText: 'Tác giả (tùy chọn)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Tạo')),
        ],
      ),
    );
    if (ok != true || titleCtrl.text.trim().isEmpty) return;
    final novel = await settings.createNovel(titleCtrl.text.trim(), author: authorCtrl.text.trim());
    await _openNovel(novel);
  }

  Future<void> _openNovel(Novel novel) async {
    await settings.setActiveNovel(novel.id);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => RootScreen(novelId: novel.id, novelTitle: novel.title)),
    );
  }

  Future<void> _deleteNovel(Novel novel) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa truyện này?'),
        content: Text(
          'Toàn bộ chương, nhân vật, luật thế giới, cuộc trò chuyện và tài liệu '
          'của "${novel.title}" sẽ bị xóa vĩnh viễn, không khôi phục được.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Xóa vĩnh viễn'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await settings.deleteNovel(novel.id);
      _load();
    }
  }

  // ĐÃ THÊM (theo yêu cầu người dùng, sau khi rà soát toàn hệ thống phát
  // hiện `SettingsService.renameNovel()` đã viết đầy đủ, chạy được thật,
  // nhưng KHÔNG có bất kỳ nút/menu nào trong app gọi tới — tạo/xóa truyện
  // đều có nút, riêng đổi tên thì không): dialog y hệt phong cách
  // `_createNovel()` (2 ô Tên truyện/Tác giả) nhưng ĐIỀN SẴN giá trị hiện
  // tại thay vì để trống, rồi gọi thẳng `renameNovel()` có sẵn.
  Future<void> _renameNovel(Novel novel) async {
    final titleCtrl = TextEditingController(text: novel.title);
    final authorCtrl = TextEditingController(text: novel.author);
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Đổi tên truyện'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên truyện')),
          TextField(controller: authorCtrl, decoration: const InputDecoration(labelText: 'Tác giả (tùy chọn)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
        ],
      ),
    );
    if (ok != true || titleCtrl.text.trim().isEmpty) return;
    // ĐÃ SỬA (2026-09-11, cùng lần với settings_service.dart): KHÔNG còn
    // gán trực tiếp lên `novel` (object có thể đã cũ so với DB) rồi gửi cả
    // object đi nữa — truyền thẳng 2 chuỗi mới, để `renameNovel()` tự làm
    // UPDATE đúng 2 cột, không đụng tới bất kỳ cột nào khác của hàng này.
    await settings.renameNovel(novel.id, title: titleCtrl.text.trim(), author: authorCtrl.text.trim());
    _load();
  }

  // ĐÃ SỬA (dùng chung với các màn khác — xem `showTextScaleDialog()`
  // trong `text_scale_service.dart` — thay vì định nghĩa lại y hệt ở đây
  // + `chat_screen.dart`, tránh lệch nhau khi sửa sau này).

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Truyện của bạn'),
        // ĐÃ THÊM (theo yêu cầu người dùng: "cái tính năng sao lưu hồi
        // phục thì không có nút restore ở màn hình tổng trước khi vào dự
        // án truyện à" — đúng, trước đây `BackupRestoreScreen` bắt buộc
        // phải có `novelId`, chỉ mở được từ Cài đặt CỦA 1 TRUYỆN ĐÃ TỒN
        // TẠI — người mất sạch dữ liệu/cài máy mới thì không có truyện
        // nào để mở Cài đặt, nghịch lý đúng lúc cần khôi phục nhất lại
        // không vào được). `BackupRestoreScreen` giờ nhận `novelId` dạng
        // nullable — gọi ở đây với `null`, tự ẩn phần "sao lưu 1 truyện"
        // (không có truyện nào đang mở), giữ nguyên "sao lưu toàn app" +
        // "khôi phục từ file" hoạt động bình thường.
        actions: [
          IconButton(
            icon: const Icon(Icons.text_fields),
            tooltip: 'Cỡ chữ (áp dụng cho mọi màn hình)',
            onPressed: () => showTextScaleDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.settings_backup_restore_outlined),
            tooltip: 'Sao lưu & khôi phục',
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const BackupRestoreScreen()));
              // Khôi phục xong có thể thêm truyện mới trên máy — tải lại
              // danh sách khi quay về màn này để thấy ngay, không cần thoát
              // app như ghi chú trong SnackBar (ghi chú đó vẫn đúng cho các
              // màn KHÁC đang mở, nhưng riêng danh sách truyện ở màn này thì
              // tự làm mới được).
              _load();
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createNovel,
        icon: const Icon(Icons.add),
        label: const Text('Truyện mới'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : novels.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.auto_stories_outlined, size: 48, color: Colors.grey),
                      const SizedBox(height: 12),
                      const Text(
                        'Chưa có truyện nào. Bấm "Truyện mới" để bắt đầu — '
                        'mỗi truyện có Story Bible, chương, chat và tài liệu hoàn toàn riêng.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ]),
                  ),
                )
              : ListView.builder(
                  itemCount: novels.length,
                  itemBuilder: (context, i) {
                    final n = novels[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.menu_book_outlined)),
                        title: Text(n.title),
                        subtitle: Text(n.author.isEmpty ? 'Chưa có tác giả' : n.author),
                        // ĐÃ SỬA: trước đây chỉ có 1 nút xoá — đổi sang
                        // PopupMenuButton (đúng khuôn mẫu đã dùng ở
                        // `chapters_screen.dart` cho hành động xuất file)
                        // để có thêm chỗ cho "Đổi tên" mà không làm rối
                        // hàng, đồng thời né lỡ tay bấm nhầm xoá.
                        trailing: PopupMenuButton<String>(
                          icon: const Icon(Icons.more_vert),
                          onSelected: (v) {
                            if (v == 'rename') _renameNovel(n);
                            if (v == 'delete') _deleteNovel(n);
                          },
                          itemBuilder: (context) => const [
                            PopupMenuItem(value: 'rename', child: Text('Đổi tên')),
                            PopupMenuItem(value: 'delete', child: Text('Xóa')),
                          ],
                        ),
                        onTap: () => _openNovel(n),
                      ),
                    );
                  },
                ),
    );
  }
}

class RootScreen extends StatefulWidget {
  final String novelId;
  final String novelTitle;
  const RootScreen({super.key, required this.novelId, required this.novelTitle});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int index = 0;

  // ĐÃ THÊM: SỬA LỖI "tạo Quyển/Hồi ở tab Chương nhưng tab Bách khoa vẫn báo
  // chưa có quyển nào" (và các lỗi tương tự — vd chương mới không hiện bên
  // tab khác). Nguyên nhân gốc: `IndexedStack` bên dưới giữ CẢ 5 TAB SỐNG
  // CÙNG LÚC, đổi tab chỉ đổi WIDGET NÀO HIỂN THỊ chứ KHÔNG dispose/tạo lại
  // State — nên `_load()` gọi 1 lần trong `initState()` của từng tab không
  // bao giờ tự chạy lại khi dữ liệu bị đổi từ 1 tab khác. `GlobalKey` ở đây
  // cho phép gọi thẳng `refreshData()` (method public mới thêm) của đúng
  // State đang sống trong IndexedStack mỗi khi người dùng CHUYỂN SANG tab
  // Chương hoặc Bách khoa — đảm bảo dữ liệu luôn khớp DB mới nhất, không
  // cần dispose/tạo lại toàn bộ tab (vẫn giữ được vị trí cuộn, tab con...
  // đang mở trong từng màn).
  final _chaptersKey = GlobalKey<State<ChaptersScreen>>();
  final _bibleKey = GlobalKey<State<StoryBibleScreen>>();

  void _onDestinationSelected(int i) {
    setState(() => index = i);
    // dynamic vì State (_ChaptersScreenState/_StoryBibleScreenState) là
    // private trong file của nó — method `refreshData()` vẫn public nên
    // gọi được qua dynamic dispatch từ đây.
    if (i == 0) {
      final st = _chaptersKey.currentState;
      if (st != null) (st as dynamic).refreshData();
    }
    if (i == 1) {
      final st = _bibleKey.currentState;
      if (st != null) (st as dynamic).refreshData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      ChaptersScreen(key: _chaptersKey, novelId: widget.novelId, novelTitle: widget.novelTitle),
      StoryBibleScreen(key: _bibleKey, novelId: widget.novelId),
      ChatScreen(novelId: widget.novelId),
      DocumentScreen(novelId: widget.novelId),
      SettingsScreen(novelId: widget.novelId),
    ];
    // ĐÃ THÊM (theo phản hồi người dùng thật: vuốt gesture quay lại lỡ tay
    // ở màn gốc này = thoát hẳn app, trong khi 1 lệnh generate() local vẫn
    // đang chạy dở phía native — bấy giờ nó thành "mồ côi" (log thật:
    // "TU CHOI NAP MODEL MOI ... lenh generate() TU PHIEN TRUOC van con
    // chay do"), KHOÁ CỨNG slot model đó tới khi lệnh cũ tự chạy xong,
    // không nạp được model nào khác — kể cả mở lại app). `RootScreen` là
    // route GỐC (không còn gì để pop phía dưới), nên back-gesture ở đây
    // luôn có nghĩa là "thoát app" — đúng điểm cần chặn.
    //
    // ĐÃ SỬA (2026-09-01 — theo yêu cầu người dùng, chọn PHƯƠNG ÁN (a) đã
    // đề xuất): TRƯỚC ĐÂY `canPop` chỉ `false` khi `runningCount > 0` —
    // khi KHÔNG có gì đang chạy (trường hợp PHỔ BIẾN NHẤT lúc thoát app
    // bình thường), để hệ thống tự pop ngay, `cleanupCacheOnExit()`
    // KHÔNG có cơ hội chạy trên nhánh đó. Giờ CHẶN LUÔN mọi lần back ở
    // màn gốc (`canPop: false` cố định) để tự kiểm soát toàn bộ — đổi lại
    // MỌI lần thoát (kể cả lúc không có gì đang chạy) đều có thêm 1 nhịp
    // chờ bất đồng bộ ngắn (chỉ đủ để dọn cache, không hiện hộp thoại xác
    // nhận nếu không cần) trước khi thoát thật — đánh đổi người dùng đã
    // chủ động chọn.
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return; // an toàn dự phòng — với canPop:false, didPop luôn false, nhánh này lẽ ra không tới
        final manager = BackgroundTaskManager.instance;

        // ĐÃ SỬA (2026-09-01): tách hẳn 2 nhánh. Trước đây chỉ có nhánh
        // "có tác vụ đang chạy" (hỏi xác nhận) — giờ thêm nhánh KHÔNG có
        // gì đang chạy: bỏ qua hộp thoại xác nhận VÀ hộp thoại "Đang dừng
        // AI..." (không có gì để dừng, hỏi/hiện ra chỉ gây khó chịu vô
        // ích) — chỉ dọn cache rồi thoát thẳng.
        if (manager.runningCount == 0) {
          await LocalLlamaProvider.cleanupCacheOnExit();
          SystemNavigator.pop();
          return;
        }

        final confirmed = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Thoát khi AI đang chạy?'),
            content: Text(
              'Đang có ${manager.runningCount} tác vụ AI chạy nền (chat, viết chương...). '
              'Chọn "Vẫn thoát" sẽ tự dừng các tác vụ này lại trước (đợi tối đa vài giây) rồi mới '
              'thoát hẳn — giữ được phần chữ đã sinh ra tới lúc đó. Nếu tắt app đột ngột thay vì '
              'dùng nút này, phần chữ đang sinh dở có thể bị MẤT (chưa kịp lưu) và model có thể bị '
              'khoá tạm thời (không nạp được model khác) cho tới khi lệnh cũ tự chạy xong.\n\n'
              'Bạn có chắc muốn thoát không?',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Ở lại')),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
                onPressed: () => Navigator.pop(ctx, true),
                // ĐÃ SỬA (theo phản hồi người dùng: "cái từ thoát vẫn là gì
                // nhỉ" — đúng, thứ tự từ cũ đọc lên hơi ngược/khó hiểu):
                // "Vẫn thoát" tự nhiên hơn "Thoát vẫn" trong tiếng Việt.
                child: const Text('Vẫn thoát'),
              ),
            ],
          ),
        );
        if (confirmed != true) return;

        // ĐÃ SỬA TẬN GỐC (theo phản hồi người dùng: "đã thoát rồi mà vẫn
        // còn chạy thì thoát trở nên vô nghĩa", VÀ "chữ đã nặn ra màn hình
        // sau khi thoát quay lại thì biến mất"): trước đây gọi
        // `requestCancel()` (chỉ đặt 1 cờ, KHÔNG đợi gì) rồi
        // `SystemNavigator.pop()` NGAY LẬP TỨC — trong khi việc huỷ thật
        // sự (native nhận được lệnh + `llm->response()` thoát ra +
        // `finally` của `chat_screen.dart` LƯU phần chữ đã sinh vào DB)
        // đều xảy ra BẤT ĐỒNG BỘ, cần vài giây — app thường bị đóng
        // TRƯỚC khi các bước đó kịp chạy xong, nên: (a) slot vẫn bị khoá
        // (lệnh cũ chưa kịp nhận tín hiệu huỷ), (b) phần chữ đã sinh mất
        // sạch (chưa kịp ghi DB). Giờ CHỜ THẬT: gọi huỷ trực tiếp xuống
        // native cho CẢ 2 slot (nhanh hơn, không cần đợi consumer Dart
        // nhận được chunk tiếp theo mới kích hoạt như đường cũ), rồi
        // POLL `manager.runningCount` (chỉ về 0 sau khi khối `finally`
        // trong `chat_screen.dart` — nơi có `db.upsertChatMessage(reply)`
        // — đã chạy xong) tối đa 10 giây trước khi thật sự thoát. Hiện 1
        // hộp thoại nhỏ không tắt được trong lúc chờ để người dùng biết
        // đang có việc xảy ra, không tưởng app bị treo.
        if (context.mounted) {
          showDialog<void>(
            context: context,
            barrierDismissible: false,
            builder: (_) => const AlertDialog(
              content: Row(
                children: [
                  SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)),
                  SizedBox(width: 16),
                  Expanded(child: Text('Đang dừng AI và lưu phần đã sinh...')),
                ],
              ),
            ),
          );
        }
        for (final t in manager.tasks) {
          if (t.status == TaskStatus.running || t.status == TaskStatus.queued) {
            manager.requestCancel(t.id);
          }
        }
        await LocalLlamaProvider.requestCancelSlot(0);
        await LocalLlamaProvider.requestCancelSlot(1);
        final deadline = DateTime.now().add(const Duration(seconds: 10));
        while (manager.runningCount > 0 && DateTime.now().isBefore(deadline)) {
          await Future<void>.delayed(const Duration(milliseconds: 300));
        }
        // ĐÃ THÊM (2026-09-01 — theo yêu cầu người dùng): dọn cache
        // autotuning OpenCL đúng LÚC NÀY — app đã huỷ + lưu xong mọi tác
        // vụ đang chạy, chuẩn bị thoát THẬT. Đặt ĐÚNG tại đây (không phải
        // ở buildOptimizedOpenCLConfig() mỗi lần nạp như trước) để tránh
        // tự xoá cache của chính model đang dùng ngay giữa phiên — xem
        // giải thích đầy đủ ở mnn_bridge.cpp. `await` để đảm bảo dọn xong
        // thật trước khi tiến trình bị đóng ngay sau đó.
        await LocalLlamaProvider.cleanupCacheOnExit();
        if (context.mounted) Navigator.of(context, rootNavigator: true).pop(); // đóng hộp "Đang dừng..."
        SystemNavigator.pop();
      },
      child: Scaffold(
        body: IndexedStack(index: index, children: screens),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: _onDestinationSelected,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Chương'),
            NavigationDestination(icon: Icon(Icons.auto_stories_outlined), label: 'Bách khoa'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Trợ lý AI'),
            NavigationDestination(icon: Icon(Icons.description_outlined), label: 'Tài liệu'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Cài đặt'),
          ],
        ),
      ),
    );
  }
}
