// Hồ sơ cấu hình tối ưu cho một nhóm phần cứng. Không hardcode riêng
// Zenfone 8 — thiết kế theo "tier" (nhóm hiệu năng chipset) để dùng được
// cho bất kỳ máy Android nào sau này, kể cả máy chưa biết trước.
class DeviceProfile {
  final String tierName;
  final String chipsetLabel;
  final int recommendedThreads;
  final int recommendedContext; // -c cho llama-server
  final String recommendedQuant; // ví dụ Q4_K_M
  final bool gpuOffloadLikely; // có nên thử -ngl 99 không
  final int ragContextBudgetChars; // ngân sách RAG — máy yếu thì nạp ít hơn
  final String note;

  const DeviceProfile({
    required this.tierName,
    required this.chipsetLabel,
    required this.recommendedThreads,
    required this.recommendedContext,
    required this.recommendedQuant,
    required this.gpuOffloadLikely,
    required this.ragContextBudgetChars,
    required this.note,
  });
}

// Bảng tra theo "hardware/board codename" — trên phần lớn máy Android
// dùng chip Qualcomm, trường `hardware` của ro.build trùng với mã nội
// bộ của chipset (ví dụ Snapdragon 888 = "lahaina"). Đây là cách nhận
// diện không cần thư viện chuyên dụng, độ chính xác tốt với máy Qualcomm,
// hạn chế hơn với Mediatek/Exynos/Samsung tự chế — vẫn có phương án dự
// phòng theo RAM và cho người dùng tự chọn tay.
const Map<String, DeviceProfile> knownChipsetProfiles = {
  // Snapdragon 888 / 888+ — bao gồm Zenfone 8
  'lahaina': DeviceProfile(
    tierName: 'Flagship 2021 (Snapdragon 888)',
    chipsetLabel: 'Snapdragon 888 / 888+',
    recommendedThreads: 5,
    recommendedContext: 4096,
    recommendedQuant: 'Q4_K_M',
    gpuOffloadLikely: true,
    ragContextBudgetChars: 3500,
    note: 'Dùng 5 luồng để tránh kéo cả 4 nhân tiết kiệm điện (Cortex-A55) làm chậm đồng bộ. '
        'Thử -ngl 99 trước; nếu GPU offload lỗi hoặc không nhanh hơn, rơi về -ngl 0.',
  ),
  'lahainap': DeviceProfile(
    tierName: 'Flagship 2021 (Snapdragon 888+)',
    chipsetLabel: 'Snapdragon 888+',
    recommendedThreads: 5,
    recommendedContext: 4096,
    recommendedQuant: 'Q4_K_M',
    gpuOffloadLikely: true,
    ragContextBudgetChars: 3500,
    note: 'Tương tự Snapdragon 888, xung nhịp cao hơn nhẹ.',
  ),
  // Snapdragon 8 Gen 1
  'taro': DeviceProfile(
    tierName: 'Flagship 2022 (Snapdragon 8 Gen 1)',
    chipsetLabel: 'Snapdragon 8 Gen 1',
    recommendedThreads: 6,
    recommendedContext: 6144,
    recommendedQuant: 'Q4_K_M hoặc Q5_K_M',
    gpuOffloadLikely: true,
    ragContextBudgetChars: 4500,
    note: 'Băng thông RAM tốt hơn 888, có thể tăng context và cân nhắc quant cao hơn.',
  ),
  // Snapdragon 8 Gen 2
  'kalama': DeviceProfile(
    tierName: 'Flagship 2023 (Snapdragon 8 Gen 2)',
    chipsetLabel: 'Snapdragon 8 Gen 2',
    recommendedThreads: 6,
    recommendedContext: 8192,
    recommendedQuant: 'Q5_K_M',
    gpuOffloadLikely: true,
    ragContextBudgetChars: 5500,
    note: 'Đủ mạnh để chạy 7B ở tốc độ khả dụng, có thể thử model 7-8B thay vì chỉ 3-4B.',
  ),
  // Snapdragon 8 Gen 3
  'pineapple': DeviceProfile(
    tierName: 'Flagship 2024 (Snapdragon 8 Gen 3)',
    chipsetLabel: 'Snapdragon 8 Gen 3',
    recommendedThreads: 7,
    recommendedContext: 8192,
    recommendedQuant: 'Q5_K_M hoặc Q6_K',
    gpuOffloadLikely: true,
    ragContextBudgetChars: 6000,
    note: 'Có NPU Hexagon mạnh — nếu app/bản llama.cpp hỗ trợ QNN backend, thử bật để tăng tốc prefill.',
  ),
};

// Dùng khi không nhận diện được chipset cụ thể — phân theo RAM tổng,
// vẫn cho tốc độ chấp nhận được ở mọi máy Android tầm trung trở lên.
DeviceProfile fallbackProfileByRam(int totalRamMb) {
  if (totalRamMb >= 10000) {
    return const DeviceProfile(
      tierName: 'Chưa nhận diện chip — RAM cao (≥10GB)',
      chipsetLabel: 'Không xác định',
      recommendedThreads: 6,
      recommendedContext: 4096,
      recommendedQuant: 'Q4_K_M',
      gpuOffloadLikely: true,
      ragContextBudgetChars: 4000,
      note: 'Không nhận diện được chipset cụ thể, ước lượng theo RAM. Nên tự đo tốc độ để tinh chỉnh.',
    );
  } else if (totalRamMb >= 6000) {
    return const DeviceProfile(
      tierName: 'Chưa nhận diện chip — RAM trung bình (6-10GB)',
      chipsetLabel: 'Không xác định',
      recommendedThreads: 4,
      recommendedContext: 2048,
      recommendedQuant: 'Q4_K_M hoặc Q3_K_M',
      gpuOffloadLikely: false,
      ragContextBudgetChars: 2500,
      note: 'Máy tầm trung — ưu tiên model nhỏ (2-4B) thay vì cố chạy 7B.',
    );
  }
  return const DeviceProfile(
    tierName: 'Chưa nhận diện chip — RAM thấp (<6GB)',
    chipsetLabel: 'Không xác định',
    recommendedThreads: 3,
    recommendedContext: 1024,
    recommendedQuant: 'Q3_K_M hoặc IQ4_XS',
    gpuOffloadLikely: false,
    ragContextBudgetChars: 1500,
    note: 'RAM hạn chế — khuyến nghị model 1-2B, cân nhắc dùng API thay vì local nếu cần chất lượng cao.',
  );
}
