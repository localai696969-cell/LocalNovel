// Các model dữ liệu cốt lõi cho Story Bible.
// Mỗi entry đều có `keywords` — danh sách từ khóa kích hoạt, dùng cho
// cơ chế "lorebook" (giống NovelAI/NovelCrafter): khi từ khóa xuất hiện
// trong ngữ cảnh đang viết, entry này sẽ tự động được nạp vào prompt AI.
//
// Mọi thực thể gắn với nội dung truyện (Character, WorldRule, TimelineEvent,
// Chapter, StyleProfile, ChatSession, ImportedDocument) đều có `novelId` —
// app hỗ trợ nhiều truyện riêng biệt, mỗi truyện có Story Bible/chương/chat
// hoàn toàn tách biệt với truyện khác.

// Một "truyện" — đơn vị cao nhất, chứa toàn bộ Story Bible/chương/chat/tài
// liệu riêng của nó. Người dùng có thể tạo nhiều truyện và chuyển qua lại.
class Novel {
  final String id;
  String title;
  String author;
  String description;
  DateTime createdAt;
  DateTime updatedAt;
  // ĐÃ THÊM (theo yêu cầu người dùng — giải quyết "đồng bộ chương 1000 với
  // chương 1"): bản TÓM TẮT LUỸ KẾ cốt truyện đã diễn ra, AI TỰ CẬP NHẬT
  // sau mỗi chương hoàn thành (KHÔNG phải người dùng viết tay). Khác hẳn:
  // - `PlotBeat` (Dàn ý): người dùng TỰ VIẾT những gì CHƯA xảy ra (kế hoạch).
  // - `TimelineEvent`: người dùng TỰ NHẬP TAY từng mốc, không tự cập nhật.
  // - Cái này: AI tự nén những gì ĐÃ XẢY RA thành 1 bản tóm tắt GỌN, LUÔN
  //   được đưa vào ngữ cảnh AI BẤT KỂ chương đang viết cách xa bao nhiêu
  //   (khác "Chương liên quan" dựa vào embedding — có thể trượt nếu truyện
  //   quá dài/top-K quá hẹp). Xem RagService.updateCumulativeStorySummary().
  String? plotProgressSummary;
  // Số chương GẦN NHẤT đã được gộp vào `plotProgressSummary` — dùng để
  // biết cập nhật tiếp từ đâu, và để KHÔNG lùi lại nếu người dùng sửa 1
  // chương cũ đã gộp rồi (xem giải thích ở RagService).
  int? plotProgressSummaryChapter;

  // ĐÃ THÊM (theo yêu cầu người dùng: "các cài đặt là riêng cho từng
  // truyện hay chung cả app?") — 4 field dưới đây TRƯỚC ĐÂY nằm ở
  // SettingsService (SharedPreferences, DÙNG CHUNG toàn app). Chuyển
  // thành thuộc tính CỦA TỪNG TRUYỆN vì lý do thật: 2 truyện khác nhau có
  // thể cần chiến lược khác hẳn nhau (truyện dịch chuyển cảnh nhanh cần
  // giãn cách ngắn hơn truyện chậm rãi; truyện viết kỹ outline trước nên
  // ưu tiên nguồn rẻ từ outline, truyện viết tự do/ứng biến thì không).
  // Giá trị mặc định của 4 field này (true/1/true/true) khớp ĐÚNG hành vi
  // global cũ, để nâng cấp từ bản trước không đổi cảm nhận nếu người dùng
  // không tự tay chỉnh gì thêm — xem `_migrateToV13` (database_service.dart)
  // để biết cách giá trị SharedPreferences cũ được sao chép sang đây.
  bool plotSummaryEnabled;
  int plotSummaryInterval;
  // ĐÃ THÊM (theo đề xuất người dùng — "đồng bộ theo hướng bible": sau khi
  // xong 1 chương, sự kiện Timeline liên quan tới chương đó (nếu ĐÃ có sẵn
  // — do người dùng tự nhập tay hoặc bấm "AI gợi ý" ở tab Dòng thời gian)
  // được ưu tiên dùng làm NGUYÊN LIỆU nén tóm tắt, THAY VÌ đọc lại toàn bộ
  // nội dung/autoSummary chương. Rẻ hơn thật vì: (a) đây là dữ liệu ĐÃ có
  // sẵn từ trước, không tốn thêm lượt gọi AI nào trong hàm này; (b) là bản
  // đã được lọc/chắt qua Bible (nhân vật/luật thế giới liên quan), ngắn và
  // "sạch" hơn hẳn so với excerpt thô từ nội dung chương. GIỚI HẠN THẬT:
  // chỉ có tác dụng nếu Timeline CHƯA rỗng cho đúng số chương đó — không
  // tự động tạo Timeline event mới ở đây (nếu tự tạo, sẽ lại tốn 1 lượt
  // gọi AI, mất hết ý nghĩa "rẻ hơn"; muốn có, người dùng tự bấm "AI gợi
  // ý" ở tab Dòng thời gian, hoặc tự nhập tay).
  bool plotSummaryPreferTimeline;
  // ĐÃ THÊM (theo đề xuất người dùng — "dựa vào dàn ý/outline của chương
  // nếu có ban đầu, do chương hồi đều đi theo mạch outline"): nguồn RẺ
  // NHẤT có thể có — outline được viết SẴN trước khi chương tồn tại (0
  // chi phí AI để lấy được), dùng cho "Tạo chương hàng loạt" (luôn có
  // outline, đó là điều kiện bắt buộc để tạo). GIỚI HẠN THẬT (không giấu):
  // outline là KẾ HOẠCH, không phải bản ghi chính xác những gì THỰC SỰ đã
  // viết ra — model có thể "đắp thịt" lệch khỏi outline (thêm/bớt tình
  // tiết khi viết). Vì vậy khi CẢ HAI đều có cho cùng 1 chương, Timeline
  // (mục trên) được ưu tiên trước outline (Timeline mô tả cái ĐÃ xảy ra
  // thật, outline chỉ mô tả cái ĐỊNH xảy ra) — xem thứ tự ưu tiên đầy đủ ở
  // `RagService._doUpdateCumulativeStorySummary`.
  bool plotSummaryPreferOutline;

  // ĐÃ THÊM (v14 — theo yêu cầu người dùng: "cài đặt thì áp dụng cho quyển
  // truyện chứ không phải cho toàn app, vì mỗi truyện có khi dùng mỗi
  // model, mỗi quy trình khác nhau, tham số sinh văn bản cũng khác nhau,
  // không thể đánh đồng chung được"). Đây là PHẢN ĐỐI TRỰC TIẾP giả định
  // gốc ở mục 2.1 tài liệu kiến trúc ("model không phải nội dung truyện
  // nên dùng chung") — người dùng nêu rõ lý do thực tế: 1 truyện có thể
  // đang dùng model local nhẹ để viết nhanh, 1 truyện khác đang dùng GPU
  // remote mạnh hơn để viết kỹ — chuyển qua lại giữa 2 truyện không nên
  // kéo theo phải vào Cài đặt đổi lại từ đầu mỗi lần.
  //
  // `providerType` lưu TÊN enum `AIProviderType` (`localLlama`/`api`) dạng
  // chuỗi — NULL nghĩa là truyện này CHƯA từng chọn gì (trước khi có v14),
  // `SettingsService.loadProviderType()` sẽ tự trả về mặc định `localLlama`
  // giống hệt hành vi cũ nếu gặp giá trị NULL/lạ, không cần xử lý đặc biệt
  // ở đây. `activeLocalModelId`/`activeApiProviderId` tham chiếu tới ID
  // trong bảng `local_models`/`api_providers` — 2 bảng ĐÓ VẪN DÙNG CHUNG
  // toàn app (chính bản thân file model/API key nằm trên máy hoặc trong
  // flutter_secure_storage không có lý do gì phải tách riêng theo truyện,
  // chỉ CON TRỎ "đang chọn cái nào" mới cần tách) — xem giải thích đầy đủ
  // ở `DatabaseService._migrateToV14`.
  String? providerType;
  String? activeLocalModelId;
  String? activeApiProviderId;
  // 5 tham số sinh văn bản — TRƯỚC (v13 trở về trước) dùng CHUNG cho mọi
  // truyện qua SettingsService/SharedPreferences, giờ RIÊNG từng truyện vì
  // cùng lý do trên ("quy trình khác nhau, tham số sinh văn bản cũng khác
  // nhau"). Giá trị mặc định khớp ĐÚNG mặc định global cũ.
  double genTemperature;
  double genTopP;
  int genTopK;
  double genRepetitionPenalty;
  int genMaxNewTokens;

  // ĐÃ THÊM (v15 — theo yêu cầu người dùng: "tất cả [cài đặt còn lại],
  // kể cả threads/gpu layers/backend thuần phần cứng" cũng tách riêng
  // theo truyện). LƯU Ý THẬT đã cảnh báo trước khi làm: 3 field
  // `localThreads/localContextSize/localGpuLayers` + `backendPreference`
  // BẢN CHẤT là cấu hình PHẦN CỨNG của máy — tách riêng theo truyện nghĩa
  // là ĐỔI TRUYỆN có thể kéo theo NẠP LẠI model (nếu 2 truyện có cấu hình
  // khác nhau), người dùng đã xác nhận chấp nhận đánh đổi này.
  int? localThreads;
  int? localContextSize;
  int? localGpuLayers;
  int? backendPreference;
  int? ragBudgetChars;
  bool translationEnabled;
  String? translationModelPath;
  String translationTargetLanguage;
  String translationStylePrompt;
  String translationPromptToTarget;
  String translationPromptFromTarget;
  String translationKeepResidentMode;
  int maxParallelRemoteTasks;
  String docTranslatePrompt;
  String docSummarizePrompt;
  String docModelChoice;

  Novel({
    required this.id,
    required this.title,
    this.author = '',
    this.description = '',
    DateTime? createdAt,
    DateTime? updatedAt,
    this.plotProgressSummary,
    this.plotProgressSummaryChapter,
    this.plotSummaryEnabled = true,
    this.plotSummaryInterval = 1,
    this.plotSummaryPreferTimeline = true,
    this.plotSummaryPreferOutline = true,
    this.providerType,
    this.activeLocalModelId,
    this.activeApiProviderId,
    this.genTemperature = 0.8,
    this.genTopP = 0.9,
    this.genTopK = 40,
    this.genRepetitionPenalty = 1.15,
    this.genMaxNewTokens = 1024,
    this.localThreads,
    this.localContextSize,
    this.localGpuLayers,
    this.backendPreference,
    this.ragBudgetChars,
    this.translationEnabled = false,
    this.translationModelPath,
    this.translationTargetLanguage = 'tiếng Anh',
    this.translationStylePrompt =
        'Giữ đúng văn phong tiểu thuyết, tự nhiên, không dịch máy móc từng chữ.',
    this.translationPromptToTarget = 'Dịch đoạn văn bản tiếng Việt sau sang {targetLanguage}. '
        'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.',
    this.translationPromptFromTarget =
        'Dịch đoạn văn bản {targetLanguage} sau sang tiếng Việt tự nhiên, đúng văn phong tiểu thuyết. '
        'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.',
    this.translationKeepResidentMode = 'auto',
    this.maxParallelRemoteTasks = 2,
    this.docTranslatePrompt =
        'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.',
    this.docSummarizePrompt = 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.',
    this.docModelChoice = 'active',
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'author': author,
        'description': description,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'plot_progress_summary': plotProgressSummary,
        'plot_progress_summary_chapter': plotProgressSummaryChapter,
        'plot_summary_enabled': plotSummaryEnabled ? 1 : 0,
        'plot_summary_interval': plotSummaryInterval,
        'plot_summary_prefer_timeline': plotSummaryPreferTimeline ? 1 : 0,
        'plot_summary_prefer_outline': plotSummaryPreferOutline ? 1 : 0,
        'provider_type': providerType,
        'active_local_model_id': activeLocalModelId,
        'active_api_provider_id': activeApiProviderId,
        'gen_temperature': genTemperature,
        'gen_top_p': genTopP,
        'gen_top_k': genTopK,
        'gen_repetition_penalty': genRepetitionPenalty,
        'gen_max_new_tokens': genMaxNewTokens,
        'local_threads': localThreads,
        'local_context': localContextSize,
        'local_gpu_layers': localGpuLayers,
        'backend_preference': backendPreference,
        'rag_context_budget': ragBudgetChars,
        'translation_enabled': translationEnabled ? 1 : 0,
        'translation_model_path': translationModelPath,
        'translation_target_language': translationTargetLanguage,
        'translation_style_prompt': translationStylePrompt,
        'translation_prompt_to_target': translationPromptToTarget,
        'translation_prompt_from_target': translationPromptFromTarget,
        'translation_keep_resident_mode': translationKeepResidentMode,
        'max_parallel_remote_tasks': maxParallelRemoteTasks,
        'doc_translate_prompt': docTranslatePrompt,
        'doc_summarize_prompt': docSummarizePrompt,
        'doc_model_choice': docModelChoice,
      };

  factory Novel.fromMap(Map<String, dynamic> m) => Novel(
        id: m['id'],
        title: m['title'],
        author: m['author'] ?? '',
        description: m['description'] ?? '',
        createdAt: DateTime.parse(m['created_at']),
        updatedAt: DateTime.parse(m['updated_at']),
        plotProgressSummary: m['plot_progress_summary'],
        plotProgressSummaryChapter: m['plot_progress_summary_chapter'],
        // Cột NULL (bản ghi từ TRƯỚC migration v13, chưa kịp backfill vì lý
        // do bất kỳ) → mặc định đúng bằng hành vi global cũ, không đổi gì.
        plotSummaryEnabled: (m['plot_summary_enabled'] as int?) == null ? true : m['plot_summary_enabled'] == 1,
        plotSummaryInterval: (m['plot_summary_interval'] as int?) ?? 1,
        plotSummaryPreferTimeline:
            (m['plot_summary_prefer_timeline'] as int?) == null ? true : m['plot_summary_prefer_timeline'] == 1,
        plotSummaryPreferOutline:
            (m['plot_summary_prefer_outline'] as int?) == null ? true : m['plot_summary_prefer_outline'] == 1,
        providerType: m['provider_type'],
        activeLocalModelId: m['active_local_model_id'],
        activeApiProviderId: m['active_api_provider_id'],
        genTemperature: (m['gen_temperature'] as num?)?.toDouble() ?? 0.8,
        genTopP: (m['gen_top_p'] as num?)?.toDouble() ?? 0.9,
        genTopK: (m['gen_top_k'] as int?) ?? 40,
        // ĐÃ SỬA (mục AC tài liệu kiến trúc, 2026-09-10 — nguyên nhân THẬT
        // khiến bug lặp vô tận ở "Đắp thịt" tái diễn liên tục dù đã "nâng
        // mặc định lên 1.15" ở `settings_service.dart` từ phiên 13
        // 2026-08-23: dòng NÀY (và default constructor `Novel(...)` phía
        // trên) mới là nơi QUYẾT ĐỊNH THẬT — `novel?.genRepetitionPenalty`
        // ở `settings_service.dart` có kiểu `double?` chỉ null khi
        // `novel` chính nó null (không tồn tại), KHÔNG BAO GIỜ null vì lý
        // do cột DB null, do đúng dòng này đã tự quy đổi null → 1.05
        // TRƯỚC khi `settings_service.dart` kịp thấy — khiến `?? 1.15` ở
        // đó thành dead code, không bao giờ chạy tới được. Đồng bộ đúng
        // giá trị 1.15 tại NGUỒN THẬT này.
        genRepetitionPenalty: (m['gen_repetition_penalty'] as num?)?.toDouble() ?? 1.15,
        genMaxNewTokens: (m['gen_max_new_tokens'] as int?) ?? 1024,
        localThreads: m['local_threads'] as int?,
        localContextSize: m['local_context'] as int?,
        localGpuLayers: m['local_gpu_layers'] as int?,
        backendPreference: m['backend_preference'] as int?,
        ragBudgetChars: m['rag_context_budget'] as int?,
        translationEnabled: (m['translation_enabled'] as int?) == 1,
        translationModelPath: m['translation_model_path'],
        translationTargetLanguage: m['translation_target_language'] ?? 'tiếng Anh',
        translationStylePrompt: m['translation_style_prompt'] ??
            'Giữ đúng văn phong tiểu thuyết, tự nhiên, không dịch máy móc từng chữ.',
        translationPromptToTarget: m['translation_prompt_to_target'] ??
            'Dịch đoạn văn bản tiếng Việt sau sang {targetLanguage}. '
                'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.',
        translationPromptFromTarget: m['translation_prompt_from_target'] ??
            'Dịch đoạn văn bản {targetLanguage} sau sang tiếng Việt tự nhiên, đúng văn phong tiểu thuyết. '
                'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.',
        translationKeepResidentMode: m['translation_keep_resident_mode'] ?? 'auto',
        maxParallelRemoteTasks: (m['max_parallel_remote_tasks'] as int?) ?? 2,
        docTranslatePrompt: m['doc_translate_prompt'] ??
            'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.',
        docSummarizePrompt:
            m['doc_summarize_prompt'] ?? 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.',
        docModelChoice: m['doc_model_choice'] ?? 'active',
      );
}

// ĐÃ THÊM (theo yêu cầu người dùng: "dàn ý/tuyến truyện/luật thế giới...
// đều hardcode cho toàn truyện, không tuỳ chọn theo chương/hồi/quyển được
// ak") — "phạm vi hiệu lực" theo SỐ CHƯƠNG (KHÔNG hardcode theo quyển hay
// theo chương — số chương là đơn vị nhỏ nhất, chính xác nhất đã có sẵn
// trong app; muốn tính theo quyển chỉ cần điền đúng khoảng số chương của
// quyển đó, không ép buộc 1 kiểu cố định nào). Áp dụng cho Character,
// WorldRule, GlossaryTerm, StyleProfile, PlotThread — cả 5 đều thêm 2
// trường NULLABLE: effectiveFromChapter/effectiveToChapter. NULL (mặc
// định, hành vi CŨ) = luôn có hiệu lực xuyên suốt truyện, không đổi gì so
// với trước khi có tính năng này. Việc LỌC THẬT SỰ theo phạm vi này chỉ
// có ý nghĩa với Character/WorldRule (2 loại duy nhất RagService dùng để
// xây ngữ cảnh cho AI — xem rag_service.dart, hàm _isInScope) — GlossaryTerm/
// StyleProfile/PlotThread hiện KHÔNG được RagService tự động tham chiếu,
// nên phạm vi ở 3 loại đó chỉ có giá trị hiển thị/nhất quán dữ liệu, CHƯA
// ảnh hưởng hành vi AI (ghi rõ để không hiểu nhầm là đã lọc được toàn bộ).

class Character {
  final String id;
  final String novelId;
  String name;
  String role; // ví dụ: nhân vật chính, phản diện, phụ
  // Phân loại thẻ chi tiết (MỚI) — khác với `role` (mô tả tự do), category
  // là 1 trong tập giá trị cố định để lọc/nhóm trong UI Story Bible.
  // Giá trị hợp lệ: 'Nhân vật chính' | 'Nhân vật phụ' | 'Phản diện' | 'Khác'.
  String category;
  String description;
  String voiceStyle; // giọng nói / cách xưng hô đặc trưng
  List<String> keywords;
  // Phạm vi hiệu lực theo số chương — null = luôn có hiệu lực (mặc định).
  int? effectiveFromChapter;
  int? effectiveToChapter;
  // Phạm vi hiệu lực theo QUYỂN/HỒI (thay thế linh hoạt cho theo số
  // chương ở trên) — tham chiếu Volume.id, KHÔNG đóng băng khoảng số
  // chương tại thời điểm lưu: mỗi lần dùng, hệ thống tự dò lại danh
  // sách chương ĐANG thuộc quyển này để tính khoảng chương thật (xem
  // DatabaseService.volumeChapterRanges) — viết thêm chương vào quyển
  // sau này, phạm vi tự mở rộng theo, không cần sửa lại entry này.
  // Nếu ĐỒNG THỜI có cả 2 kiểu (theo chương VÀ theo quyển) — quyển được
  // ưu tiên dùng (xem RagService._resolveScope).
  String? effectiveFromVolumeId;
  String? effectiveToVolumeId;
  DateTime updatedAt;

  Character({
    required this.id,
    required this.novelId,
    required this.name,
    required this.role,
    required this.description,
    this.category = 'Khác',
    this.voiceStyle = '',
    List<String>? keywords,
    this.effectiveFromChapter,
    this.effectiveToChapter,
    this.effectiveFromVolumeId,
    this.effectiveToVolumeId,
    DateTime? updatedAt,
  })  : keywords = keywords ?? [name],
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'name': name,
        'role': role,
        'category': category,
        'description': description,
        'voice_style': voiceStyle,
        'keywords': keywords.join(','),
        'effective_from_chapter': effectiveFromChapter,
        'effective_to_chapter': effectiveToChapter,
        'effective_from_volume_id': effectiveFromVolumeId,
        'effective_to_volume_id': effectiveToVolumeId,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Character.fromMap(Map<String, dynamic> m) => Character(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        role: m['role'],
        category: (m['category'] as String?)?.isNotEmpty == true ? m['category'] : 'Khác',
        description: m['description'],
        voiceStyle: m['voice_style'] ?? '',
        keywords: (m['keywords'] as String).split(',').where((e) => e.isNotEmpty).toList(),
        effectiveFromChapter: m['effective_from_chapter'],
        effectiveToChapter: m['effective_to_chapter'],
        effectiveFromVolumeId: m['effective_from_volume_id'],
        effectiveToVolumeId: m['effective_to_volume_id'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

class WorldRule {
  final String id;
  final String novelId;
  String title;
  String content;
  bool isHardRule; // luật tuyệt đối, không bao giờ được vi phạm
  // Phân loại thẻ chi tiết (MỚI): 'Luật lệ' | 'Địa điểm' | 'Vũ khí' |
  // 'Tổ chức' | 'Vật phẩm' | 'Khác' — dùng để lọc/nhóm trong UI, không
  // ảnh hưởng cơ chế lorebook (vẫn dựa vào keywords như trước).
  String category;
  List<String> keywords;
  // Phạm vi hiệu lực theo số chương — null = luôn có hiệu lực (mặc định).
  // Hữu ích cho luật bị lật lại/bổ sung giữa truyện (vd twist ở 1 quyển
  // sau) — trước đây không có cách nào biểu diễn "luật này chỉ đúng từ
  // chương X trở đi".
  int? effectiveFromChapter;
  int? effectiveToChapter;
  // Phạm vi hiệu lực theo QUYỂN/HỒI (thay thế linh hoạt cho theo số
  // chương ở trên) — tham chiếu Volume.id, KHÔNG đóng băng khoảng số
  // chương tại thời điểm lưu: mỗi lần dùng, hệ thống tự dò lại danh
  // sách chương ĐANG thuộc quyển này để tính khoảng chương thật (xem
  // DatabaseService.volumeChapterRanges) — viết thêm chương vào quyển
  // sau này, phạm vi tự mở rộng theo, không cần sửa lại entry này.
  // Nếu ĐỒNG THỜI có cả 2 kiểu (theo chương VÀ theo quyển) — quyển được
  // ưu tiên dùng (xem RagService._resolveScope).
  String? effectiveFromVolumeId;
  String? effectiveToVolumeId;

  WorldRule({
    required this.id,
    required this.novelId,
    required this.title,
    required this.content,
    this.isHardRule = true,
    this.category = 'Luật lệ',
    List<String>? keywords,
    this.effectiveFromChapter,
    this.effectiveToChapter,
    this.effectiveFromVolumeId,
    this.effectiveToVolumeId,
  }) : keywords = keywords ?? [];

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'title': title,
        'content': content,
        'is_hard_rule': isHardRule ? 1 : 0,
        'category': category,
        'keywords': keywords.join(','),
        'effective_from_chapter': effectiveFromChapter,
        'effective_to_chapter': effectiveToChapter,
        'effective_from_volume_id': effectiveFromVolumeId,
        'effective_to_volume_id': effectiveToVolumeId,
      };

  factory WorldRule.fromMap(Map<String, dynamic> m) => WorldRule(
        id: m['id'],
        novelId: m['novel_id'],
        title: m['title'],
        content: m['content'],
        isHardRule: m['is_hard_rule'] == 1,
        category: (m['category'] as String?)?.isNotEmpty == true ? m['category'] : 'Luật lệ',
        keywords: (m['keywords'] as String).split(',').where((e) => e.isNotEmpty).toList(),
        effectiveFromChapter: m['effective_from_chapter'],
        effectiveToChapter: m['effective_to_chapter'],
        effectiveFromVolumeId: m['effective_from_volume_id'],
        effectiveToVolumeId: m['effective_to_volume_id'],
      );
}

class TimelineEvent {
  final String id;
  final String novelId;
  int chapterNumber;
  String summary; // tóm tắt sự kiện, dùng cho ngữ cảnh nén
  DateTime? inStoryDate; // thời gian trong truyện (nếu có lịch riêng)

  TimelineEvent({
    required this.id,
    required this.novelId,
    required this.chapterNumber,
    required this.summary,
    this.inStoryDate,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'chapter_number': chapterNumber,
        'summary': summary,
        'in_story_date': inStoryDate?.toIso8601String(),
      };

  factory TimelineEvent.fromMap(Map<String, dynamic> m) => TimelineEvent(
        id: m['id'],
        novelId: m['novel_id'],
        chapterNumber: m['chapter_number'],
        summary: m['summary'],
        inStoryDate: m['in_story_date'] != null ? DateTime.parse(m['in_story_date']) : null,
      );
}

// Một model .gguf đã "import" (lưu đường dẫn) — có thể có nhiều model,
// chỉ 1 model đang active để chat tại một thời điểm. Dùng chung cho MỌI
// truyện (không gắn theo novelId) vì đây là tài nguyên máy, không phải
// nội dung truyện.
class LocalModelEntry {
  final String id;
  String name;
  String path;

  LocalModelEntry({required this.id, required this.name, required this.path});

  Map<String, dynamic> toMap() => {'id': id, 'name': name, 'path': path};

  factory LocalModelEntry.fromMap(Map<String, dynamic> m) =>
      LocalModelEntry(id: m['id'], name: m['name'], path: m['path']);
}

// Một cấu hình API do người dùng tự thêm — không giới hạn số lượng,
// không hardcode chỉ Anthropic/OpenAI. type quyết định cách gọi API
// (anthropic dùng endpoint cố định; openai_compatible cho phép tự nhập
// base URL để dùng với bất kỳ dịch vụ tương thích chuẩn OpenAI nào).
// Cũng dùng chung cho mọi truyện, giống LocalModelEntry.
class ApiProviderEntry {
  final String id;
  String name;
  String type; // 'anthropic' | 'openai_compatible'
  String? baseUrl;
  String modelId;

  ApiProviderEntry({
    required this.id,
    required this.name,
    required this.type,
    this.baseUrl,
    required this.modelId,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type,
        'base_url': baseUrl,
        'model_id': modelId,
      };

  factory ApiProviderEntry.fromMap(Map<String, dynamic> m) => ApiProviderEntry(
        id: m['id'],
        name: m['name'],
        type: m['type'],
        baseUrl: m['base_url'],
        modelId: m['model_id'],
      );
}

class StyleProfile {
  final String id;
  final String novelId;
  String name;
  // Người dùng có thể mô tả văn phong bằng lời ("giọng cổ trang, câu dài,
  // nhiều ẩn dụ") hoặc dán mẫu văn CỦA CHÍNH HỌ để AI phân tích ra mô tả.
  // profileDescription luôn là mô tả bằng lời (kết quả phân tích hoặc
  // do người dùng tự viết) — không lưu nguyên văn tác phẩm của người khác.
  String profileDescription;
  // Phạm vi hiệu lực theo số chương — null = luôn có hiệu lực (mặc định).
  // LƯU Ý: hiện CHƯA có nơi nào tự động lọc theo phạm vi này (StyleProfile
  // được người dùng CHỌN THỦ CÔNG mỗi lần viết, không qua RagService) —
  // chỉ có giá trị hiển thị/nhất quán dữ liệu ở bước này.
  int? effectiveFromChapter;
  int? effectiveToChapter;
  // Phạm vi hiệu lực theo QUYỂN/HỒI (thay thế linh hoạt cho theo số
  // chương ở trên) — tham chiếu Volume.id, KHÔNG đóng băng khoảng số
  // chương tại thời điểm lưu: mỗi lần dùng, hệ thống tự dò lại danh
  // sách chương ĐANG thuộc quyển này để tính khoảng chương thật (xem
  // DatabaseService.volumeChapterRanges) — viết thêm chương vào quyển
  // sau này, phạm vi tự mở rộng theo, không cần sửa lại entry này.
  // Nếu ĐỒNG THỜI có cả 2 kiểu (theo chương VÀ theo quyển) — quyển được
  // ưu tiên dùng (xem RagService._resolveScope).
  String? effectiveFromVolumeId;
  String? effectiveToVolumeId;
  DateTime updatedAt;

  StyleProfile({
    required this.id,
    required this.novelId,
    required this.name,
    required this.profileDescription,
    this.effectiveFromChapter,
    this.effectiveToChapter,
    this.effectiveFromVolumeId,
    this.effectiveToVolumeId,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'name': name,
        'profile_description': profileDescription,
        'effective_from_chapter': effectiveFromChapter,
        'effective_to_chapter': effectiveToChapter,
        'effective_from_volume_id': effectiveFromVolumeId,
        'effective_to_volume_id': effectiveToVolumeId,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory StyleProfile.fromMap(Map<String, dynamic> m) => StyleProfile(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        profileDescription: m['profile_description'],
        effectiveFromChapter: m['effective_from_chapter'],
        effectiveToChapter: m['effective_to_chapter'],
        effectiveFromVolumeId: m['effective_from_volume_id'],
        effectiveToVolumeId: m['effective_to_volume_id'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// Tài liệu văn bản được "đính kèm" để dịch/tóm tắt/hỏi đáp — xử lý theo
// kiểu cuốn chiếu (chia nhỏ, xử lý từng phần, ráp lại) để không vượt
// giới hạn ngữ cảnh của model, dù văn bản gốc dài bao nhiêu. Gắn theo
// từng truyện vì thường dùng để tham khảo/dịch tư liệu cho đúng truyện đó.
class ImportedDocument {
  final String id;
  final String novelId;
  String name;
  String sourcePath;
  int chunkCount;
  DateTime createdAt;

  ImportedDocument({
    required this.id,
    required this.novelId,
    required this.name,
    required this.sourcePath,
    this.chunkCount = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'name': name,
        'source_path': sourcePath,
        'chunk_count': chunkCount,
        'created_at': createdAt.toIso8601String(),
      };

  factory ImportedDocument.fromMap(Map<String, dynamic> m) => ImportedDocument(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        sourcePath: m['source_path'],
        chunkCount: m['chunk_count'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

class DocumentChunk {
  final String id;
  final String documentId;
  final int index;
  final String originalText;
  String? resultText; // kết quả dịch/tóm tắt của riêng đoạn này

  DocumentChunk({
    required this.id,
    required this.documentId,
    required this.index,
    required this.originalText,
    this.resultText,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'document_id': documentId,
        'idx': index,
        'original_text': originalText,
        'result_text': resultText,
      };

  factory DocumentChunk.fromMap(Map<String, dynamic> m) => DocumentChunk(
        id: m['id'],
        documentId: m['document_id'],
        index: m['idx'],
        originalText: m['original_text'],
        resultText: m['result_text'],
      );
}

class ChatSession {
  final String id;
  final String novelId;
  String name;
  DateTime createdAt;

  ChatSession({required this.id, required this.novelId, required this.name, DateTime? createdAt})
      : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() =>
      {'id': id, 'novel_id': novelId, 'name': name, 'created_at': createdAt.toIso8601String()};

  factory ChatSession.fromMap(Map<String, dynamic> m) => ChatSession(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

class ChatMessageRecord {
  final String id;
  final String sessionId;
  final bool fromUser;
  String text;
  final String? providerLabel; // model nào đã trả lời — hiển thị khi đổi model giữa chừng
  final DateTime createdAt;

  ChatMessageRecord({
    required this.id,
    required this.sessionId,
    required this.fromUser,
    required this.text,
    this.providerLabel,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'session_id': sessionId,
        'from_user': fromUser ? 1 : 0,
        'text': text,
        'provider_label': providerLabel,
        'created_at': createdAt.toIso8601String(),
      };

  factory ChatMessageRecord.fromMap(Map<String, dynamic> m) => ChatMessageRecord(
        id: m['id'],
        sessionId: m['session_id'] ?? 'default',
        fromUser: m['from_user'] == 1,
        text: m['text'],
        providerLabel: m['provider_label'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

class Chapter {
  final String id;
  final String novelId;
  int number;
  String title;
  String content;
  // ĐÃ THÊM: "outline" (định hướng/dàn ý chương, "chương mồi") — trước đây
  // chỉ tồn tại tạm thời trong ô nhập của màn hình soạn chương
  // (outlineCtrl), KHÔNG lưu vào DB — rời màn hình mà chưa bấm "Đắp thịt"
  // là mất trắng. Giờ lưu bền vào chapter, cho phép người dùng viết dàn ý
  // nhiều chương TRƯỚC (không gọi AI), rồi chọn hàng loạt để tạo sau —
  // xem ChaptersBatchGenerateScreen.
  String? outline;
  String? autoSummary; // tóm tắt 3-5 câu, sinh tự động sau khi lưu chương
  bool consistencyChecked;
  String? consistencyWarning;
  // ĐÃ THÊM: chương thuộc (những) tuyến truyện/subplot nào — theo đúng
  // khuôn mẫu `Character.keywords` (comma-separated trong DB, List<String>
  // trong bộ nhớ). Cho phép 1 chương thúc đẩy NHIỀU tuyến cùng lúc (vd vừa
  // là tuyến chính vừa hé lộ 1 subplot). Rỗng = chưa gắn tuyến nào, không
  // bắt buộc dùng tính năng này.
  List<String> threadIds;
  // ĐÃ THÊM: chương thuộc "Quyển"/"Hồi" nào — null = chưa gom vào quyển
  // nào (mặc định, không bắt buộc dùng). Tham chiếu tới Volume.id.
  String? volumeId;
  // ĐÃ THÊM (v11, theo yêu cầu người dùng — resume khi GPU remote sập
  // giữa chừng): văn bản THÔ model đã sinh được tính tới lần checkpoint
  // gần nhất — KHÔNG phải nội dung chương thật (`content`). Nếu đang bật
  // dịch thuật trung gian, đây là văn bản CHƯA dịch (ngôn ngữ đích) —
  // giữ nguyên ngôn ngữ đó khi nối tiếp, chỉ dịch 1 LẦN DUY NHẤT sau khi
  // toàn bộ chương sinh xong, tránh dịch đi dịch lại nhiều lần tốn kém.
  // null/rỗng = không có phiên viết dở nào đang chờ tiếp tục.
  String? generationCheckpoint;
  DateTime updatedAt;

  Chapter({
    required this.id,
    required this.novelId,
    required this.number,
    required this.title,
    required this.content,
    this.outline,
    this.autoSummary,
    this.consistencyChecked = false,
    this.consistencyWarning,
    List<String>? threadIds,
    this.volumeId,
    this.generationCheckpoint,
    DateTime? updatedAt,
  })  : threadIds = threadIds ?? [],
        updatedAt = updatedAt ?? DateTime.now();

  int get wordCount => content.trim().isEmpty ? 0 : content.trim().split(RegExp(r'\s+')).length;

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'number': number,
        'title': title,
        'content': content,
        'outline': outline,
        'auto_summary': autoSummary,
        'consistency_checked': consistencyChecked ? 1 : 0,
        'consistency_warning': consistencyWarning,
        'thread_ids': threadIds.join(','),
        'volume_id': volumeId,
        'generation_checkpoint': generationCheckpoint,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Chapter.fromMap(Map<String, dynamic> m) => Chapter(
        id: m['id'],
        novelId: m['novel_id'],
        number: m['number'],
        title: m['title'],
        content: m['content'],
        outline: m['outline'],
        autoSummary: m['auto_summary'],
        consistencyChecked: m['consistency_checked'] == 1,
        consistencyWarning: m['consistency_warning'],
        threadIds: ((m['thread_ids'] as String?) ?? '').split(',').where((e) => e.isNotEmpty).toList(),
        volumeId: m['volume_id'],
        generationCheckpoint: m['generation_checkpoint'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// ĐÃ THÊM: 1 "ghi chú chờ xử lý" khi người dùng bôi đen 1 đoạn văn trong
// chương và viết nhận xét/yêu cầu chỉnh sửa TỰ DO (không phải chọn 1 trong
// các lựa chọn hardcode như trước) — KHÔNG gọi AI ngay lúc tạo ghi chú.
// Người dùng có thể bôi đen nhiều chỗ, viết nhiều ghi chú, rồi mới bấm
// "Tạo lại tất cả" để xử lý TUẦN TỰ theo hàng đợi (không đồng thời — đúng
// nguyên nhân crash đã tìm ra ở mục 5.67 kiến trúc).
//
// Lưu `originalText` (không phải vị trí số/offset) làm "mỏ neo" để định vị
// lại đoạn văn lúc áp dụng — vì offset có thể lệch nếu người dùng sửa nội
// dung ở chỗ khác của chương giữa lúc ghi chú và lúc thật sự tạo lại.
class PendingRewrite {
  final String id;
  final String chapterId;
  final String novelId;
  final String originalText;
  final String note; // nhận xét/yêu cầu tự do của người dùng
  String status; // 'pending' | 'done' | 'failed' | 'skipped_text_changed'
  String? resultText;
  final DateTime createdAt;

  PendingRewrite({
    required this.id,
    required this.chapterId,
    required this.novelId,
    required this.originalText,
    required this.note,
    this.status = 'pending',
    this.resultText,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'chapter_id': chapterId,
        'novel_id': novelId,
        'original_text': originalText,
        'note': note,
        'status': status,
        'result_text': resultText,
        'created_at': createdAt.toIso8601String(),
      };

  factory PendingRewrite.fromMap(Map<String, dynamic> m) => PendingRewrite(
        id: m['id'],
        chapterId: m['chapter_id'],
        novelId: m['novel_id'],
        originalText: m['original_text'],
        note: m['note'],
        status: m['status'] ?? 'pending',
        resultText: m['result_text'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

// Bản nháp cũ của 1 chương, chụp lại TRƯỚC khi nội dung bị ghi đè (AI viết
// tiếp/đắp thịt/rewrite, hoặc người dùng lưu tay) — cho phép khôi phục nếu
// kết quả AI không ưng ý. Không giới hạn cứng số lượng ở tầng model; tầng
// DatabaseService tự dọn bớt bản cũ nhất khi vượt quá `maxVersionsPerChapter`
// để tránh phình dung lượng vô hạn.
class ChapterVersion {
  final String id;
  final String chapterId;
  final String novelId;
  final String title;
  final String content;
  // Nhãn ngắn mô tả vì sao snapshot này được tạo, vd 'Trước khi Viết tiếp',
  // 'Trước khi Đắp thịt', 'Trước khi Viết lại bằng AI', 'Lưu thủ công'.
  final String label;
  final DateTime createdAt;

  ChapterVersion({
    required this.id,
    required this.chapterId,
    required this.novelId,
    required this.title,
    required this.content,
    required this.label,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  int get wordCount => content.trim().isEmpty ? 0 : content.trim().split(RegExp(r'\s+')).length;

  Map<String, dynamic> toMap() => {
        'id': id,
        'chapter_id': chapterId,
        'novel_id': novelId,
        'title': title,
        'content': content,
        'label': label,
        'created_at': createdAt.toIso8601String(),
      };

  factory ChapterVersion.fromMap(Map<String, dynamic> m) => ChapterVersion(
        id: m['id'],
        chapterId: m['chapter_id'],
        novelId: m['novel_id'],
        title: m['title'],
        content: m['content'],
        label: m['label'] ?? 'Lưu thủ công',
        createdAt: DateTime.parse(m['created_at']),
      );
}

// Thuật ngữ riêng của truyện (tên địa danh đặc biệt, thuật ngữ võ công/ma
// pháp, đơn vị đo lường tự chế...) — khác Character/WorldRule ở chỗ đây là
// một "từ điển tra nhanh" đơn giản, không tham gia cơ chế lorebook tự động
// nạp vào prompt (không có trường keywords/kích hoạt).
class GlossaryTerm {
  final String id;
  final String novelId;
  String term;
  String definition;
  String category; // 'Địa danh' | 'Thuật ngữ' | 'Vật phẩm' | 'Khác'
  // Phạm vi hiệu lực theo số chương — null = luôn có hiệu lực (mặc định).
  // LƯU Ý: hiện CHƯA có nơi nào tự động lọc theo phạm vi này (glossary
  // chưa được RagService tham chiếu) — chỉ có giá trị hiển thị/nhất quán
  // dữ liệu ở bước này, hữu ích cho trường hợp thuật ngữ đổi nghĩa/đổi
  // tên giữa truyện.
  int? effectiveFromChapter;
  int? effectiveToChapter;
  // Phạm vi hiệu lực theo QUYỂN/HỒI (thay thế linh hoạt cho theo số
  // chương ở trên) — tham chiếu Volume.id, KHÔNG đóng băng khoảng số
  // chương tại thời điểm lưu: mỗi lần dùng, hệ thống tự dò lại danh
  // sách chương ĐANG thuộc quyển này để tính khoảng chương thật (xem
  // DatabaseService.volumeChapterRanges) — viết thêm chương vào quyển
  // sau này, phạm vi tự mở rộng theo, không cần sửa lại entry này.
  // Nếu ĐỒNG THỜI có cả 2 kiểu (theo chương VÀ theo quyển) — quyển được
  // ưu tiên dùng (xem RagService._resolveScope).
  String? effectiveFromVolumeId;
  String? effectiveToVolumeId;
  DateTime updatedAt;

  GlossaryTerm({
    required this.id,
    required this.novelId,
    required this.term,
    required this.definition,
    this.category = 'Khác',
    this.effectiveFromChapter,
    this.effectiveToChapter,
    this.effectiveFromVolumeId,
    this.effectiveToVolumeId,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'term': term,
        'definition': definition,
        'category': category,
        'effective_from_chapter': effectiveFromChapter,
        'effective_to_chapter': effectiveToChapter,
        'effective_from_volume_id': effectiveFromVolumeId,
        'effective_to_volume_id': effectiveToVolumeId,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory GlossaryTerm.fromMap(Map<String, dynamic> m) => GlossaryTerm(
        id: m['id'],
        novelId: m['novel_id'],
        term: m['term'],
        definition: m['definition'],
        category: (m['category'] as String?)?.isNotEmpty == true ? m['category'] : 'Khác',
        effectiveFromChapter: m['effective_from_chapter'],
        effectiveToChapter: m['effective_to_chapter'],
        effectiveFromVolumeId: m['effective_from_volume_id'],
        effectiveToVolumeId: m['effective_to_volume_id'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// ĐÃ THÊM (theo yêu cầu người dùng: bổ sung tính năng dựa vào quy trình
// viết tiểu thuyết bình thường): 3 khái niệm mới hỗ trợ LẬP KẾ HOẠCH viết,
// tách biệt với nội dung chương thật (Chapter) — đúng tinh thần "viết dàn
// ý/kế hoạch trước, viết chương thật sau" mà nhiều tác giả dùng.

// Điểm nút cốt truyện (beat) — 1 mốc/sự kiện quan trọng trong cấu trúc
// truyện (vd "Mở đầu", "Điểm nút 1", "Cao trào", "Kết thúc" theo cấu trúc
// 3 hồi, hoặc tự đặt tên tùy ý — KHÔNG ép khuôn cứng 1 kiểu cấu trúc nào).
// Khác với Chapter.outline (dàn ý CHI TIẾT của 1 chương cụ thể) — PlotBeat
// là dàn ý Ở TẦM TOÀN TRUYỆN, có thể chưa gắn với chương nào, hoặc gắn
// với 1 số chương cụ thể qua linkedChapterNumber.
class PlotBeat {
  final String id;
  final String novelId;
  String title;
  String description;
  String beatType; // tự do, vd 'Mở đầu' | 'Điểm nút' | 'Cao trào' | 'Kết thúc' | tùy đặt
  int orderIndex; // thứ tự hiển thị, người dùng tự sắp xếp (kéo thả)
  int? linkedChapterNumber; // liên kết tới 1 chương cụ thể, null = chưa viết tới
  String status; // 'planned' (mới lên kế hoạch) | 'drafted' (đang viết) | 'done' (đã xong)
  // ĐÃ THÊM (v10): "Phạm vi hiệu lực" — cùng 4 field, cùng ý nghĩa như
  // Character/WorldRule/StyleProfile/GlossaryTerm/PlotThread (xem
  // RagService._resolveScope). Khác với `linkedChapterNumber` (ghim CHÍNH
  // XÁC 1 chương), 4 field này cho phép 1 điểm nút áp dụng cho CẢ 1
  // khoảng chương hoặc CẢ 1 Quyển/Hồi — dùng khi chưa chốt điểm nút rơi
  // đúng chương nào, chỉ biết nó thuộc quyển nào.
  int? effectiveFromChapter;
  int? effectiveToChapter;
  String? effectiveFromVolumeId;
  String? effectiveToVolumeId;
  DateTime updatedAt;

  PlotBeat({
    required this.id,
    required this.novelId,
    required this.title,
    this.description = '',
    this.beatType = 'Khác',
    this.orderIndex = 0,
    this.linkedChapterNumber,
    this.status = 'planned',
    this.effectiveFromChapter,
    this.effectiveToChapter,
    this.effectiveFromVolumeId,
    this.effectiveToVolumeId,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'title': title,
        'description': description,
        'beat_type': beatType,
        'order_index': orderIndex,
        'linked_chapter_number': linkedChapterNumber,
        'status': status,
        'effective_from_chapter': effectiveFromChapter,
        'effective_to_chapter': effectiveToChapter,
        'effective_from_volume_id': effectiveFromVolumeId,
        'effective_to_volume_id': effectiveToVolumeId,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory PlotBeat.fromMap(Map<String, dynamic> m) => PlotBeat(
        id: m['id'],
        novelId: m['novel_id'],
        title: m['title'],
        description: m['description'] ?? '',
        beatType: (m['beat_type'] as String?)?.isNotEmpty == true ? m['beat_type'] : 'Khác',
        orderIndex: m['order_index'] ?? 0,
        linkedChapterNumber: m['linked_chapter_number'],
        status: (m['status'] as String?)?.isNotEmpty == true ? m['status'] : 'planned',
        effectiveFromChapter: m['effective_from_chapter'],
        effectiveToChapter: m['effective_to_chapter'],
        effectiveFromVolumeId: m['effective_from_volume_id'],
        effectiveToVolumeId: m['effective_to_volume_id'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// Tuyến truyện/subplot — 1 mạch truyện riêng biệt chạy song song với
// tuyến chính (vd "Tuyến chính", "Tình cảm phụ", "Âm mưu phản diện B"...).
// Chapter.threadIds tham chiếu ngược lại id của lớp này (1 chương có thể
// thuộc nhiều tuyến) — cho phép lọc xem TOÀN BỘ chương thuộc 1 tuyến để
// theo dõi tuyến đó có bị bỏ quên/đứt đoạn quá lâu không.
class PlotThread {
  final String id;
  final String novelId;
  String name;
  String description;
  int colorValue; // ARGB int (Color.value) — chấm màu nhận diện nhanh trong UI
  String status; // 'active' (đang chạy) | 'paused' (tạm gác) | 'resolved' (đã khép lại)
  // Phạm vi hiệu lực theo số chương — null = luôn có hiệu lực (mặc định).
  // LƯU Ý: hiện CHƯA có nơi nào tự động lọc theo phạm vi này — chỉ có
  // giá trị hiển thị/nhất quán dữ liệu (vd biết tuyến này chỉ tồn tại từ
  // chương 10 tới chương 40).
  int? effectiveFromChapter;
  int? effectiveToChapter;
  // Phạm vi hiệu lực theo QUYỂN/HỒI (thay thế linh hoạt cho theo số
  // chương ở trên) — tham chiếu Volume.id, KHÔNG đóng băng khoảng số
  // chương tại thời điểm lưu: mỗi lần dùng, hệ thống tự dò lại danh
  // sách chương ĐANG thuộc quyển này để tính khoảng chương thật (xem
  // DatabaseService.volumeChapterRanges) — viết thêm chương vào quyển
  // sau này, phạm vi tự mở rộng theo, không cần sửa lại entry này.
  // Nếu ĐỒNG THỜI có cả 2 kiểu (theo chương VÀ theo quyển) — quyển được
  // ưu tiên dùng (xem RagService._resolveScope).
  String? effectiveFromVolumeId;
  String? effectiveToVolumeId;
  DateTime updatedAt;

  PlotThread({
    required this.id,
    required this.novelId,
    required this.name,
    this.description = '',
    this.colorValue = 0xFF6750A4,
    this.status = 'active',
    this.effectiveFromChapter,
    this.effectiveToChapter,
    this.effectiveFromVolumeId,
    this.effectiveToVolumeId,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'name': name,
        'description': description,
        'color_value': colorValue,
        'status': status,
        'effective_from_chapter': effectiveFromChapter,
        'effective_to_chapter': effectiveToChapter,
        'effective_from_volume_id': effectiveFromVolumeId,
        'effective_to_volume_id': effectiveToVolumeId,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory PlotThread.fromMap(Map<String, dynamic> m) => PlotThread(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        description: m['description'] ?? '',
        colorValue: m['color_value'] ?? 0xFF6750A4,
        status: (m['status'] as String?)?.isNotEmpty == true ? m['status'] : 'active',
        effectiveFromChapter: m['effective_from_chapter'],
        effectiveToChapter: m['effective_to_chapter'],
        effectiveFromVolumeId: m['effective_from_volume_id'],
        effectiveToVolumeId: m['effective_to_volume_id'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// Mục tiêu viết mỗi ngày cho 1 truyện — chỉ lưu con số mục tiêu, TIẾN ĐỘ
// THẬT (số chữ đã viết mỗi ngày) tính từ bảng daily_word_log riêng (xem
// DatabaseService.recordWordSnapshot/recentWordLog) — không lưu trùng lặp
// dữ liệu tiến độ ở đây.
class WritingGoal {
  final String novelId; // khóa chính luôn — mỗi truyện chỉ có 1 mục tiêu
  int dailyTargetWords;
  DateTime updatedAt;

  WritingGoal({
    required this.novelId,
    this.dailyTargetWords = 500,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'novel_id': novelId,
        'daily_target_words': dailyTargetWords,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory WritingGoal.fromMap(Map<String, dynamic> m) => WritingGoal(
        novelId: m['novel_id'],
        dailyTargetWords: m['daily_target_words'] ?? 500,
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// Quyển/Hồi — tầng nhóm nhiều chương lại (vd "Quyển 1: Khởi đầu" gồm
// chương 1-50), phổ biến trong tiểu thuyết mạng kiểu Việt/Trung. Chỉ là
// 1 nhãn gom nhóm hiển thị — KHÔNG thay đổi cách đánh số chương (Chapter.
// number vẫn liên tục xuyên suốt toàn truyện, không reset theo quyển,
// tránh phá vỡ mọi chỗ đang dựa vào number để sắp xếp/xuất EPUB).
class Volume {
  final String id;
  final String novelId;
  String title;
  String description;
  int orderIndex; // thứ tự hiển thị quyển (Quyển 1 trước Quyển 2...)
  DateTime updatedAt;

  Volume({
    required this.id,
    required this.novelId,
    required this.title,
    this.description = '',
    this.orderIndex = 0,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'title': title,
        'description': description,
        'order_index': orderIndex,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Volume.fromMap(Map<String, dynamic> m) => Volume(
        id: m['id'],
        novelId: m['novel_id'],
        title: m['title'],
        description: m['description'] ?? '',
        orderIndex: m['order_index'] ?? 0,
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// ĐÃ THÊM (theo yêu cầu người dùng: "nhân vật A tính cách 1 theo số
// chương, tính cách 2 theo hồi, tính cách 3 cho toàn truyện... tương tự
// đối với bible khác" — vd Luật thế giới lúc Hồi 1 thì như vậy, Hồi 2 lại
// thay đổi) — 1 bảng DÙNG CHUNG cho cả 5 loại Bible (Character/WorldRule/
// GlossaryTerm/StyleProfile/PlotThread), thay vì viết riêng 5 bảng giống
// hệt nhau. Mỗi "fact" là 1 CHI TIẾT CỤ THỂ có phạm vi hiệu lực RIÊNG,
// tách biệt khỏi mô tả/nội dung CHUNG của entry cha (field `description`/
// `content`/`definition`/`profileDescription` cũ — GIỮ NGUYÊN, coi là
// "luôn đúng/tổng quát", không đổi hành vi cũ). Ví dụ nhân vật "A" có
// description chung "Một hiệp sĩ", CỘNG THÊM các fact: "Tính tình hiền
// lành" (hiệu lực chương 1-50), "Tính tình lạnh lùng, tàn nhẫn" (hiệu lực
// chương 51-150) — AI sẽ chỉ thấy ĐÚNG fact khớp với chương đang viết,
// không thấy cả 2 cùng lúc gây mâu thuẫn.
//
// parentType: 'character' | 'world_rule' | 'glossary_term' | 'style_profile'
// | 'plot_thread' — parentId: id của entry cha tương ứng.
class BibleFact {
  final String id;
  final String novelId; // denormalize để truy vấn nhanh, không cần JOIN
  final String parentType;
  final String parentId;
  String factText;
  int orderIndex;
  // Phạm vi hiệu lực — CÙNG cơ chế với entry cha (theo số chương HOẶC
  // theo Quyển/Hồi, dò lại khoảng chương thật mỗi lần dùng nếu theo
  // quyển). NULL cả 4 = luôn đúng bất kể entry cha đang ở phạm vi nào.
  int? effectiveFromChapter;
  int? effectiveToChapter;
  String? effectiveFromVolumeId;
  String? effectiveToVolumeId;
  DateTime updatedAt;

  BibleFact({
    required this.id,
    required this.novelId,
    required this.parentType,
    required this.parentId,
    required this.factText,
    this.orderIndex = 0,
    this.effectiveFromChapter,
    this.effectiveToChapter,
    this.effectiveFromVolumeId,
    this.effectiveToVolumeId,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'parent_type': parentType,
        'parent_id': parentId,
        'fact_text': factText,
        'order_index': orderIndex,
        'effective_from_chapter': effectiveFromChapter,
        'effective_to_chapter': effectiveToChapter,
        'effective_from_volume_id': effectiveFromVolumeId,
        'effective_to_volume_id': effectiveToVolumeId,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory BibleFact.fromMap(Map<String, dynamic> m) => BibleFact(
        id: m['id'],
        novelId: m['novel_id'],
        parentType: m['parent_type'],
        parentId: m['parent_id'],
        factText: m['fact_text'],
        orderIndex: m['order_index'] ?? 0,
        effectiveFromChapter: m['effective_from_chapter'],
        effectiveToChapter: m['effective_to_chapter'],
        effectiveFromVolumeId: m['effective_from_volume_id'],
        effectiveToVolumeId: m['effective_to_volume_id'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}
