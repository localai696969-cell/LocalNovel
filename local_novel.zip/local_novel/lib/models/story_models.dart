// Các model dữ liệu cốt lõi cho Story Bible.
// Mỗi entry đều có `keywords` — danh sách từ khóa kích hoạt, dùng cho
// cơ chế "lorebook" (giống NovelAI/NovelCrafter): khi từ khóa xuất hiện
// trong ngữ cảnh đang viết, entry này sẽ tự động được nạp vào prompt AI.
//
// Mọi thực thể gắn với nội dung truyện (Character, WorldRule, TimelineEvent,
// Chapter, StyleProfile, ChatSession, ImportedDocument) đều có `novelId` —
// app hỗ trợ nhiều truyện riêng biệt, mỗi truyện có Story Bible/chương/chat
// hoàn toàn tách biệt với truyện khác.

// Một "truyện" — đơn vị cao nhất, chứa toàn bộ Story Bible/chương/chat/tài
// liệu riêng của nó. Người dùng có thể tạo nhiều truyện và chuyển qua lại.
class Novel {
  final String id;
  String title;
  String author;
  String description;
  DateTime createdAt;
  DateTime updatedAt;

  Novel({
    required this.id,
    required this.title,
    this.author = '',
    this.description = '',
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'author': author,
        'description': description,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Novel.fromMap(Map<String, dynamic> m) => Novel(
        id: m['id'],
        title: m['title'],
        author: m['author'] ?? '',
        description: m['description'] ?? '',
        createdAt: DateTime.parse(m['created_at']),
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

class Character {
  final String id;
  final String novelId;
  String name;
  String role; // ví dụ: nhân vật chính, phản diện, phụ
  String description;
  String voiceStyle; // giọng nói / cách xưng hô đặc trưng
  List<String> keywords;
  DateTime updatedAt;

  Character({
    required this.id,
    required this.novelId,
    required this.name,
    required this.role,
    required this.description,
    this.voiceStyle = '',
    List<String>? keywords,
    DateTime? updatedAt,
  })  : keywords = keywords ?? [name],
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'name': name,
        'role': role,
        'description': description,
        'voice_style': voiceStyle,
        'keywords': keywords.join(','),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Character.fromMap(Map<String, dynamic> m) => Character(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        role: m['role'],
        description: m['description'],
        voiceStyle: m['voice_style'] ?? '',
        keywords: (m['keywords'] as String).split(',').where((e) => e.isNotEmpty).toList(),
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

class WorldRule {
  final String id;
  final String novelId;
  String title;
  String content;
  bool isHardRule; // luật tuyệt đối, không bao giờ được vi phạm
  List<String> keywords;

  WorldRule({
    required this.id,
    required this.novelId,
    required this.title,
    required this.content,
    this.isHardRule = true,
    List<String>? keywords,
  }) : keywords = keywords ?? [];

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'title': title,
        'content': content,
        'is_hard_rule': isHardRule ? 1 : 0,
        'keywords': keywords.join(','),
      };

  factory WorldRule.fromMap(Map<String, dynamic> m) => WorldRule(
        id: m['id'],
        novelId: m['novel_id'],
        title: m['title'],
        content: m['content'],
        isHardRule: m['is_hard_rule'] == 1,
        keywords: (m['keywords'] as String).split(',').where((e) => e.isNotEmpty).toList(),
      );
}

class TimelineEvent {
  final String id;
  final String novelId;
  int chapterNumber;
  String summary; // tóm tắt sự kiện, dùng cho ngữ cảnh nén
  DateTime? inStoryDate; // thời gian trong truyện (nếu có lịch riêng)

  TimelineEvent({
    required this.id,
    required this.novelId,
    required this.chapterNumber,
    required this.summary,
    this.inStoryDate,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'chapter_number': chapterNumber,
        'summary': summary,
        'in_story_date': inStoryDate?.toIso8601String(),
      };

  factory TimelineEvent.fromMap(Map<String, dynamic> m) => TimelineEvent(
        id: m['id'],
        novelId: m['novel_id'],
        chapterNumber: m['chapter_number'],
        summary: m['summary'],
        inStoryDate: m['in_story_date'] != null ? DateTime.parse(m['in_story_date']) : null,
      );
}

// Một model .gguf đã "import" (lưu đường dẫn) — có thể có nhiều model,
// chỉ 1 model đang active để chat tại một thời điểm. Dùng chung cho MỌI
// truyện (không gắn theo novelId) vì đây là tài nguyên máy, không phải
// nội dung truyện.
class LocalModelEntry {
  final String id;
  String name;
  String path;

  LocalModelEntry({required this.id, required this.name, required this.path});

  Map<String, dynamic> toMap() => {'id': id, 'name': name, 'path': path};

  factory LocalModelEntry.fromMap(Map<String, dynamic> m) =>
      LocalModelEntry(id: m['id'], name: m['name'], path: m['path']);
}

// Một cấu hình API do người dùng tự thêm — không giới hạn số lượng,
// không hardcode chỉ Anthropic/OpenAI. type quyết định cách gọi API
// (anthropic dùng endpoint cố định; openai_compatible cho phép tự nhập
// base URL để dùng với bất kỳ dịch vụ tương thích chuẩn OpenAI nào).
// Cũng dùng chung cho mọi truyện, giống LocalModelEntry.
class ApiProviderEntry {
  final String id;
  String name;
  String type; // 'anthropic' | 'openai_compatible'
  String? baseUrl;
  String modelId;

  ApiProviderEntry({
    required this.id,
    required this.name,
    required this.type,
    this.baseUrl,
    required this.modelId,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type,
        'base_url': baseUrl,
        'model_id': modelId,
      };

  factory ApiProviderEntry.fromMap(Map<String, dynamic> m) => ApiProviderEntry(
        id: m['id'],
        name: m['name'],
        type: m['type'],
        baseUrl: m['base_url'],
        modelId: m['model_id'],
      );
}

class StyleProfile {
  final String id;
  final String novelId;
  String name;
  // Người dùng có thể mô tả văn phong bằng lời ("giọng cổ trang, câu dài,
  // nhiều ẩn dụ") hoặc dán mẫu văn CỦA CHÍNH HỌ để AI phân tích ra mô tả.
  // profileDescription luôn là mô tả bằng lời (kết quả phân tích hoặc
  // do người dùng tự viết) — không lưu nguyên văn tác phẩm của người khác.
  String profileDescription;
  DateTime updatedAt;

  StyleProfile({
    required this.id,
    required this.novelId,
    required this.name,
    required this.profileDescription,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'name': name,
        'profile_description': profileDescription,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory StyleProfile.fromMap(Map<String, dynamic> m) => StyleProfile(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        profileDescription: m['profile_description'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

// Tài liệu văn bản được "đính kèm" để dịch/tóm tắt/hỏi đáp — xử lý theo
// kiểu cuốn chiếu (chia nhỏ, xử lý từng phần, ráp lại) để không vượt
// giới hạn ngữ cảnh của model, dù văn bản gốc dài bao nhiêu. Gắn theo
// từng truyện vì thường dùng để tham khảo/dịch tư liệu cho đúng truyện đó.
class ImportedDocument {
  final String id;
  final String novelId;
  String name;
  String sourcePath;
  int chunkCount;
  DateTime createdAt;

  ImportedDocument({
    required this.id,
    required this.novelId,
    required this.name,
    required this.sourcePath,
    this.chunkCount = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'name': name,
        'source_path': sourcePath,
        'chunk_count': chunkCount,
        'created_at': createdAt.toIso8601String(),
      };

  factory ImportedDocument.fromMap(Map<String, dynamic> m) => ImportedDocument(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        sourcePath: m['source_path'],
        chunkCount: m['chunk_count'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

class DocumentChunk {
  final String id;
  final String documentId;
  final int index;
  final String originalText;
  String? resultText; // kết quả dịch/tóm tắt của riêng đoạn này

  DocumentChunk({
    required this.id,
    required this.documentId,
    required this.index,
    required this.originalText,
    this.resultText,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'document_id': documentId,
        'idx': index,
        'original_text': originalText,
        'result_text': resultText,
      };

  factory DocumentChunk.fromMap(Map<String, dynamic> m) => DocumentChunk(
        id: m['id'],
        documentId: m['document_id'],
        index: m['idx'],
        originalText: m['original_text'],
        resultText: m['result_text'],
      );
}

class ChatSession {
  final String id;
  final String novelId;
  String name;
  DateTime createdAt;

  ChatSession({required this.id, required this.novelId, required this.name, DateTime? createdAt})
      : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() =>
      {'id': id, 'novel_id': novelId, 'name': name, 'created_at': createdAt.toIso8601String()};

  factory ChatSession.fromMap(Map<String, dynamic> m) => ChatSession(
        id: m['id'],
        novelId: m['novel_id'],
        name: m['name'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

class ChatMessageRecord {
  final String id;
  final String sessionId;
  final bool fromUser;
  String text;
  final String? providerLabel; // model nào đã trả lời — hiển thị khi đổi model giữa chừng
  final DateTime createdAt;

  ChatMessageRecord({
    required this.id,
    required this.sessionId,
    required this.fromUser,
    required this.text,
    this.providerLabel,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'session_id': sessionId,
        'from_user': fromUser ? 1 : 0,
        'text': text,
        'provider_label': providerLabel,
        'created_at': createdAt.toIso8601String(),
      };

  factory ChatMessageRecord.fromMap(Map<String, dynamic> m) => ChatMessageRecord(
        id: m['id'],
        sessionId: m['session_id'] ?? 'default',
        fromUser: m['from_user'] == 1,
        text: m['text'],
        providerLabel: m['provider_label'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

class Chapter {
  final String id;
  final String novelId;
  int number;
  String title;
  String content;
  String? autoSummary; // tóm tắt 3-5 câu, sinh tự động sau khi lưu chương
  bool consistencyChecked;
  String? consistencyWarning;
  DateTime updatedAt;

  Chapter({
    required this.id,
    required this.novelId,
    required this.number,
    required this.title,
    required this.content,
    this.autoSummary,
    this.consistencyChecked = false,
    this.consistencyWarning,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  int get wordCount => content.trim().isEmpty ? 0 : content.trim().split(RegExp(r'\s+')).length;

  Map<String, dynamic> toMap() => {
        'id': id,
        'novel_id': novelId,
        'number': number,
        'title': title,
        'content': content,
        'auto_summary': autoSummary,
        'consistency_checked': consistencyChecked ? 1 : 0,
        'consistency_warning': consistencyWarning,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Chapter.fromMap(Map<String, dynamic> m) => Chapter(
        id: m['id'],
        novelId: m['novel_id'],
        number: m['number'],
        title: m['title'],
        content: m['content'],
        autoSummary: m['auto_summary'],
        consistencyChecked: m['consistency_checked'] == 1,
        consistencyWarning: m['consistency_warning'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}
