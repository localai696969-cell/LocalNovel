import 'package:flutter/material.dart';
import '../services/background_task_manager.dart';
import '../services/providers/local_provider.dart';

// ĐÃ THÊM (rà soát toàn hệ thống theo yêu cầu người dùng — "kiểm tra tính
// năng nào có UI nhưng không hoạt động, chỉ là mã bề ngoài"): phát hiện
// `BackgroundTaskManager.requestCancel()`/`clearFinished()`/`tasks` (getter
// liệt kê TOÀN BỘ nhiệm vụ nền — chat, tạo chương hàng loạt, xử lý tài
// liệu) đã có sẵn từ trước (comment ngay trong `background_task_manager.dart`
// còn ghi rõ "gọi thủ công từ UI (nút Huỷ/Xoá lịch sử)"), nhưng KHÔNG hề
// có màn hình nào trong `lib/screens/` từng gọi tới — 3 khả năng đó tồn
// tại nhưng hoàn toàn "câm", không ai với tới được từ UI.
//
// Màn hình này là điểm truy cập DUY NHẤT, DÙNG CHUNG cho MỌI loại nhiệm vụ
// nền (không riêng "tạo chương hàng loạt") — vào được từ Cài đặt, SỐNG
// ĐỘC LẬP với màn hình đã tạo ra nhiệm vụ (đúng đúng tinh thần thiết kế
// gốc của `BackgroundTaskManager`, xem comment đầu file đó): rời màn "Tạo
// hàng loạt" giữa chừng, nhiệm vụ vẫn chạy tiếp, và giờ vẫn có thể quay
// lại HUỶ từng nhiệm vụ cụ thể (mỗi CHƯƠNG trong 1 lô là 1 nhiệm vụ riêng,
// xem `ChapterBatchService._generateBatchParallel`) từ chính màn hình này,
// không cần quay lại đúng màn cũ nữa.
class BackgroundTasksScreen extends StatefulWidget {
  const BackgroundTasksScreen({super.key});
  @override
  State<BackgroundTasksScreen> createState() => _BackgroundTasksScreenState();
}

class _BackgroundTasksScreenState extends State<BackgroundTasksScreen> {
  final manager = BackgroundTaskManager.instance;
  // ĐÃ THÊM: kết quả hỏi native slot 0/1 có đang bận không — xem giải
  // thích đầy đủ ở `LocalLlamaProvider.isSlotGenerating()`. `null` = chưa
  // hỏi xong (đang load), `true`/`false` = kết quả.
  final Map<int, bool?> _slotGenerating = {0: null, 1: null};

  @override
  void initState() {
    super.initState();
    // BackgroundTaskManager là ChangeNotifier — lắng nghe trực tiếp để
    // danh sách tự cập nhật NGAY khi có nhiệm vụ mới/đổi trạng thái, không
    // cần bấm refresh tay hay poll định kỳ.
    manager.addListener(_onChanged);
    _refreshSlotGenerating();
  }

  Future<void> _refreshSlotGenerating() async {
    final busy0 = await LocalLlamaProvider.isSlotGenerating(0);
    final busy1 = await LocalLlamaProvider.isSlotGenerating(1);
    if (mounted) setState(() => _slotGenerating..[0] = busy0..[1] = busy1);
  }

  @override
  void dispose() {
    manager.removeListener(_onChanged);
    super.dispose();
  }

  void _onChanged() {
    if (mounted) setState(() {});
  }

  String _categoryLabel(String category) {
    switch (category) {
      case 'chat':
        return 'Trợ lý AI';
      case 'chapter_batch':
        return 'Tạo chương hàng loạt';
      case 'document':
        return 'Xử lý tài liệu';
      default:
        return category;
    }
  }

  IconData _statusIcon(TaskStatus s) {
    switch (s) {
      case TaskStatus.queued:
        return Icons.hourglass_empty;
      case TaskStatus.running:
        return Icons.autorenew;
      case TaskStatus.done:
        return Icons.check_circle;
      case TaskStatus.error:
        return Icons.error;
      case TaskStatus.cancelled:
        return Icons.cancel;
    }
  }

  Color? _statusColor(TaskStatus s, BuildContext context) {
    switch (s) {
      case TaskStatus.error:
        return Theme.of(context).colorScheme.error;
      case TaskStatus.done:
        return Colors.green;
      case TaskStatus.running:
        return Theme.of(context).colorScheme.primary;
      default:
        return null;
    }
  }

  String _statusLabel(TaskStatus s) {
    switch (s) {
      case TaskStatus.queued:
        return 'Đang chờ';
      case TaskStatus.running:
        return 'Đang chạy...';
      case TaskStatus.done:
        return 'Xong';
      case TaskStatus.error:
        return 'Lỗi';
      case TaskStatus.cancelled:
        return 'Đã huỷ';
    }
  }

  @override
  Widget build(BuildContext context) {
    final tasks = manager.tasks;
    // Mới nhất lên đầu — nhiệm vụ vừa thả vào thường là cái người dùng
    // quan tâm nhất ngay lúc mở màn này.
    final sorted = tasks.reversed.toList();
    final hasFinished = tasks.any((t) =>
        t.status == TaskStatus.done || t.status == TaskStatus.error || t.status == TaskStatus.cancelled);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tác vụ nền'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Hỏi lại native xem slot có đang bận không',
            onPressed: _refreshSlotGenerating,
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            tooltip: 'Xoá lịch sử (đã xong/lỗi/huỷ)',
            onPressed: hasFinished ? () => setState(() => manager.clearFinished()) : null,
          ),
        ],
      ),
      body: Column(
        children: [
          // ĐÃ THÊM: banner cảnh báo khi native báo slot đang bận NHƯNG
          // Dart-side không có tác vụ nào đang `running` — đúng dấu hiệu
          // của 1 lệnh generate() MỒ CÔI từ phiên trước (đóng app giữa
          // chừng), thứ mà trước đây người dùng KHÔNG hề thấy gì ở màn
          // này (List Dart trống trơn vì nó chỉ nhớ tác vụ của PHIÊN HIỆN
          // TẠI). Chỉ hiện khi thật sự đáng ngờ — không hiện nếu Dart vẫn
          // đang track đúng 1 tác vụ running bình thường (tránh báo trùng
          // 2 lần cho cùng 1 việc).
          for (final entry in _slotGenerating.entries)
            if (entry.value == true && manager.runningCount == 0)
              MaterialBanner(
                leading: const Icon(Icons.warning_amber_rounded, color: Colors.orange),
                content: Text(
                  entry.key == 0
                      ? 'Model chính (slot 0) đang bận sinh văn bản ở tầng gốc, nhưng KHÔNG có tác vụ nào '
                          'trong danh sách bên dưới — rất có thể đây là 1 lệnh còn sót lại từ phiên trước '
                          '(app bị đóng giữa chừng). Không nạp được model khác cho tới khi lệnh này tự '
                          'xong, hoặc bấm "Huỷ tác vụ mồ côi" bên dưới.'
                      : 'Model dịch thuật (slot 1) đang bận ở tầng gốc, không thấy tác vụ tương ứng trong '
                          'danh sách — có thể là 1 lệnh dịch còn sót lại từ phiên trước.',
                ),
                actions: [
                  TextButton(
                    onPressed: () async {
                      await LocalLlamaProvider.requestCancelSlot(entry.key);
                      await Future<void>.delayed(const Duration(seconds: 1));
                      await _refreshSlotGenerating();
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Đã gửi yêu cầu huỷ. Nếu model đang lặp vô tận, lớp phát hiện ở tầng gốc sẽ tự '
                              'dừng ở lần ghi token tiếp theo — có thể mất vài giây.',
                            ),
                          ),
                        );
                      }
                    },
                    child: const Text('Huỷ tác vụ mồ côi'),
                  ),
                ],
              ),
          Expanded(
            child: sorted.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Chưa có tác vụ nền nào. Các việc chạy lâu (chat AI, tạo chương hàng loạt, '
                        'xử lý tài liệu) sẽ hiện ở đây — bạn có thể rời màn hình khác mà không mất '
                        'tiến trình, và quay lại đây bất cứ lúc nào để xem/huỷ.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                  )
                : ListView.builder(
                    itemCount: sorted.length,
                    itemBuilder: (context, i) {
                      final t = sorted[i];
                      final canCancel = t.status == TaskStatus.queued || t.status == TaskStatus.running;
                      return ListTile(
                        leading: Icon(_statusIcon(t.status), color: _statusColor(t.status, context)),
                        title: Text(t.label, maxLines: 2, overflow: TextOverflow.ellipsis),
                        subtitle: Text(
                          t.status == TaskStatus.error && t.errorMessage != null
                              ? '${_categoryLabel(t.category)} · ${_statusLabel(t.status)}: ${t.errorMessage}'
                              : '${_categoryLabel(t.category)} · ${_statusLabel(t.status)}',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        trailing: canCancel
                            ? IconButton(
                                icon: const Icon(Icons.close),
                                tooltip: t.status == TaskStatus.queued
                                    ? 'Bỏ khỏi hàng đợi'
                                    // ĐÃ SỬA: giờ nút huỷ đã có tác dụng thật với
                                    // cả chat local (xem `background_task_manager.dart`
                                    // + `local_provider.dart` — cờ huỷ NATIVE mới
                                    // thêm), không còn chỉ đúng cho "Tạo chương
                                    // hàng loạt" (remote) như trước.
                                    : 'Yêu cầu huỷ',
                                onPressed: () => manager.requestCancel(t.id),
                              )
                            : null,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
