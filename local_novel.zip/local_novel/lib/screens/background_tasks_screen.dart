import 'package:flutter/material.dart';
import '../services/background_task_manager.dart';

// ĐÃ THÊM (rà soát toàn hệ thống theo yêu cầu người dùng — "kiểm tra tính
// năng nào có UI nhưng không hoạt động, chỉ là mã bề ngoài"): phát hiện
// `BackgroundTaskManager.requestCancel()`/`clearFinished()`/`tasks` (getter
// liệt kê TOÀN BỘ nhiệm vụ nền — chat, tạo chương hàng loạt, xử lý tài
// liệu) đã có sẵn từ trước (comment ngay trong `background_task_manager.dart`
// còn ghi rõ "gọi thủ công từ UI (nút Huỷ/Xoá lịch sử)"), nhưng KHÔNG hề
// có màn hình nào trong `lib/screens/` từng gọi tới — 3 khả năng đó tồn
// tại nhưng hoàn toàn "câm", không ai với tới được từ UI.
//
// Màn hình này là điểm truy cập DUY NHẤT, DÙNG CHUNG cho MỌI loại nhiệm vụ
// nền (không riêng "tạo chương hàng loạt") — vào được từ Cài đặt, SỐNG
// ĐỘC LẬP với màn hình đã tạo ra nhiệm vụ (đúng đúng tinh thần thiết kế
// gốc của `BackgroundTaskManager`, xem comment đầu file đó): rời màn "Tạo
// hàng loạt" giữa chừng, nhiệm vụ vẫn chạy tiếp, và giờ vẫn có thể quay
// lại HUỶ từng nhiệm vụ cụ thể (mỗi CHƯƠNG trong 1 lô là 1 nhiệm vụ riêng,
// xem `ChapterBatchService._generateBatchParallel`) từ chính màn hình này,
// không cần quay lại đúng màn cũ nữa.
class BackgroundTasksScreen extends StatefulWidget {
  const BackgroundTasksScreen({super.key});
  @override
  State<BackgroundTasksScreen> createState() => _BackgroundTasksScreenState();
}

class _BackgroundTasksScreenState extends State<BackgroundTasksScreen> {
  final manager = BackgroundTaskManager.instance;

  @override
  void initState() {
    super.initState();
    // BackgroundTaskManager là ChangeNotifier — lắng nghe trực tiếp để
    // danh sách tự cập nhật NGAY khi có nhiệm vụ mới/đổi trạng thái, không
    // cần bấm refresh tay hay poll định kỳ.
    manager.addListener(_onChanged);
  }

  @override
  void dispose() {
    manager.removeListener(_onChanged);
    super.dispose();
  }

  void _onChanged() {
    if (mounted) setState(() {});
  }

  String _categoryLabel(String category) {
    switch (category) {
      case 'chat':
        return 'Trợ lý AI';
      case 'chapter_batch':
        return 'Tạo chương hàng loạt';
      case 'document':
        return 'Xử lý tài liệu';
      default:
        return category;
    }
  }

  IconData _statusIcon(TaskStatus s) {
    switch (s) {
      case TaskStatus.queued:
        return Icons.hourglass_empty;
      case TaskStatus.running:
        return Icons.autorenew;
      case TaskStatus.done:
        return Icons.check_circle;
      case TaskStatus.error:
        return Icons.error;
      case TaskStatus.cancelled:
        return Icons.cancel;
    }
  }

  Color? _statusColor(TaskStatus s, BuildContext context) {
    switch (s) {
      case TaskStatus.error:
        return Theme.of(context).colorScheme.error;
      case TaskStatus.done:
        return Colors.green;
      case TaskStatus.running:
        return Theme.of(context).colorScheme.primary;
      default:
        return null;
    }
  }

  String _statusLabel(TaskStatus s) {
    switch (s) {
      case TaskStatus.queued:
        return 'Đang chờ';
      case TaskStatus.running:
        return 'Đang chạy...';
      case TaskStatus.done:
        return 'Xong';
      case TaskStatus.error:
        return 'Lỗi';
      case TaskStatus.cancelled:
        return 'Đã huỷ';
    }
  }

  @override
  Widget build(BuildContext context) {
    final tasks = manager.tasks;
    // Mới nhất lên đầu — nhiệm vụ vừa thả vào thường là cái người dùng
    // quan tâm nhất ngay lúc mở màn này.
    final sorted = tasks.reversed.toList();
    final hasFinished = tasks.any((t) =>
        t.status == TaskStatus.done || t.status == TaskStatus.error || t.status == TaskStatus.cancelled);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tác vụ nền'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            tooltip: 'Xoá lịch sử (đã xong/lỗi/huỷ)',
            onPressed: hasFinished ? () => setState(() => manager.clearFinished()) : null,
          ),
        ],
      ),
      body: sorted.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Chưa có tác vụ nền nào. Các việc chạy lâu (chat AI, tạo chương hàng loạt, '
                  'xử lý tài liệu) sẽ hiện ở đây — bạn có thể rời màn hình khác mà không mất '
                  'tiến trình, và quay lại đây bất cứ lúc nào để xem/huỷ.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            )
          : ListView.builder(
              itemCount: sorted.length,
              itemBuilder: (context, i) {
                final t = sorted[i];
                final canCancel = t.status == TaskStatus.queued || t.status == TaskStatus.running;
                return ListTile(
                  leading: Icon(_statusIcon(t.status), color: _statusColor(t.status, context)),
                  title: Text(t.label, maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                    t.status == TaskStatus.error && t.errorMessage != null
                        ? '${_categoryLabel(t.category)} · ${_statusLabel(t.status)}: ${t.errorMessage}'
                        : '${_categoryLabel(t.category)} · ${_statusLabel(t.status)}',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: canCancel
                      ? IconButton(
                          icon: const Icon(Icons.close),
                          tooltip: t.status == TaskStatus.queued
                              ? 'Bỏ khỏi hàng đợi'
                              // ĐÚNG THẬT: nhiệm vụ ĐANG CHẠY chỉ huỷ được nếu
                              // chính runner của nó có hỗ trợ tự kiểm tra cờ
                              // huỷ giữa chừng (`onCancelRequested`, xem
                              // `BackgroundTaskManager.requestCancel()`) — nếu
                              // runner không hỗ trợ, bấm nút này không có tác
                              // dụng gì (không có cách huỷ cứng 1 Future HTTP/
                              // native đang chạy dở an toàn trong Dart). Hiện
                              // tại "Tạo chương hàng loạt" (nhánh GPU remote) đã
                              // hỗ trợ huỷ giữa chừng thật sự; chat/tài liệu chưa.
                              : 'Yêu cầu huỷ (chỉ có tác dụng nếu tác vụ hỗ trợ tự kiểm tra huỷ giữa chừng)',
                          onPressed: () => manager.requestCancel(t.id),
                        )
                      : null,
                );
              },
            ),
    );
  }
}
