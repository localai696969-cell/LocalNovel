import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services/backup_service.dart';
import '../services/database_service.dart';
import 'file_browser_screen.dart';

// ĐÃ SỬA (theo yêu cầu người dùng: "sao lưu thì nên có 2 lựa chọn là sao
// lưu toàn app hay sao lưu từng truyện cho người dùng lựa chọn") — màn
// này giờ có 2 nút sao lưu riêng biệt, và hộp thoại xác nhận khôi phục tự
// đổi nội dung tùy theo loại file backup được chọn (đọc từ `manifest['scope']`,
// xem backup_service.dart). KHÔNG bao gồm API key (xem giải thích trong
// backup_service.dart) — cần nhập lại API key sau khi khôi phục trên máy
// mới, dù là khôi phục toàn app hay 1 truyện.
class BackupRestoreScreen extends StatefulWidget {
  // Truyện ĐANG MỞ — dùng cho nút "Sao lưu truyện này".
  final String novelId;
  const BackupRestoreScreen({super.key, required this.novelId});
  @override
  State<BackupRestoreScreen> createState() => _BackupRestoreScreenState();
}

class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
  final backupService = BackupService();
  final db = DatabaseService.instance;
  bool exportingApp = false;
  bool exportingNovel = false;
  bool restoring = false;
  String? novelTitle;

  @override
  void initState() {
    super.initState();
    _loadNovelTitle();
  }

  Future<void> _loadNovelTitle() async {
    final novel = await db.novelById(widget.novelId);
    if (mounted) setState(() => novelTitle = novel?.title ?? '(không rõ tên)');
  }

  Future<void> _exportApp() async {
    setState(() => exportingApp = true);
    try {
      final file = await backupService.exportBackup();
      await Share.shareXFiles([XFile(file.path)], text: 'Sao lưu toàn bộ dữ liệu LocalNovel');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi sao lưu: $e')));
    } finally {
      if (mounted) setState(() => exportingApp = false);
    }
  }

  Future<void> _exportNovel() async {
    setState(() => exportingNovel = true);
    try {
      final file = await backupService.exportNovelBackup(widget.novelId, novelTitle ?? widget.novelId);
      await Share.shareXFiles([XFile(file.path)], text: 'Sao lưu truyện "${novelTitle ?? ''}"');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi sao lưu: $e')));
    } finally {
      if (mounted) setState(() => exportingNovel = false);
    }
  }

  Future<void> _restore() async {
    final path = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const FileBrowserScreen(allowedExtensions: ['zip', 'json'])),
    );
    if (path == null) return;

    setState(() => restoring = true);
    try {
      final preview = await backupService.readBackupFile(File(path));
      if (!mounted) return;
      final isNovelScope = preview.scope == 'novel';
      // ĐÃ THÊM: kiểm tra TRƯỚC khi hỏi xác nhận xem truyện trong file backup
      // (scope 'novel') có TRÙNG id với 1 truyện đã có sẵn trên máy này hay
      // không — nếu có, người dùng cần biết rõ đây là GHI ĐÈ truyện đó, chứ
      // không phải "thêm 1 truyện mới" (khôi phục không tạo id mới, xem
      // giải thích ở DatabaseService.importNovelData).
      bool novelAlreadyExists = false;
      if (isNovelScope && preview.novelId != null) {
        final existing = await db.novelById(preview.novelId!);
        novelAlreadyExists = existing != null;
      }
      final content = isNovelScope
          ? 'File này là bản sao lưu CỦA 1 TRUYỆN: "${preview.novelTitle ?? '(không rõ tên)'}" '
              '(${preview.chapterCount} chương)'
              '${preview.exportedAt != null ? ', sao lưu lúc ${preview.exportedAt}' : ''}.\n\n'
              '${novelAlreadyExists ? 'Máy này ĐÃ CÓ 1 truyện trùng — khôi phục sẽ GHI ĐÈ toàn bộ dữ liệu của đúng truyện đó bằng nội dung trong file này (không đụng tới các truyện khác).' : 'Sẽ tạo truyện này trên máy, giữ nguyên toàn bộ chương/Bách khoa/chat/tài liệu đã sao lưu.'}'
          : 'File này có ${preview.novelCount} truyện, ${preview.chapterCount} chương'
              '${preview.exportedAt != null ? ', sao lưu lúc ${preview.exportedAt}' : ''}.\n\n'
              'Dữ liệu sẽ được GHI ĐÈ theo id (không xóa dữ liệu hiện có không trùng id, '
              'nhưng phần trùng id sẽ bị thay bằng bản trong file sao lưu này).';
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(isNovelScope ? 'Khôi phục 1 truyện?' : 'Khôi phục toàn bộ dữ liệu?'),
          content: Text(content),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Khôi phục')),
          ],
        ),
      );
      if (confirm == true) {
        await backupService.restoreFromPreview(preview);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Đã khôi phục xong — khởi động lại app để thấy đầy đủ thay đổi.'),
          ));
        }
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi khôi phục: $e')));
    } finally {
      if (mounted) setState(() => restoring = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sao lưu & khôi phục')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'KHÔNG bao gồm API key (vì lý do bảo mật) — cần nhập lại API key thủ công sau khi '
            'khôi phục trên máy mới. Danh sách provider/model vẫn được khôi phục đầy đủ.',
            style: TextStyle(color: Colors.orange, fontSize: 12),
          ),
          const SizedBox(height: 20),
          Text('Sao lưu toàn bộ app', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 4),
          const Text(
            'Mọi truyện — Story Bible, chương, lịch sử phiên bản, chat, tài liệu, thuật ngữ — '
            'ra 1 file .zip. Dùng khi đổi máy hoặc muốn 1 bản sao lưu đầy đủ duy nhất.',
            style: TextStyle(color: Colors.grey, fontSize: 13),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: exportingApp ? null : _exportApp,
            icon: exportingApp
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.upload_outlined),
            label: Text(exportingApp ? 'Đang sao lưu...' : 'Sao lưu toàn bộ app'),
          ),
          const SizedBox(height: 24),
          Text('Sao lưu 1 truyện', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 4),
          Text(
            'Chỉ đúng truyện đang mở: "${novelTitle ?? '...'}" — nhẹ hơn, dễ chia sẻ hoặc lưu '
            'riêng cho từng dự án viết, không kèm các truyện khác trên máy.',
            style: const TextStyle(color: Colors.grey, fontSize: 13),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: (exportingNovel || novelTitle == null) ? null : _exportNovel,
            icon: exportingNovel
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.upload_file_outlined),
            label: Text(exportingNovel ? 'Đang sao lưu...' : 'Sao lưu truyện này'),
          ),
          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 12),
          Text('Khôi phục', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 4),
          const Text(
            'Chọn 1 file backup (toàn app hoặc 1 truyện đều được — app tự nhận diện đúng loại).',
            style: TextStyle(color: Colors.grey, fontSize: 13),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: restoring ? null : _restore,
            icon: restoring
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.download_outlined),
            label: Text(restoring ? 'Đang khôi phục...' : 'Khôi phục từ file sao lưu'),
          ),
        ],
      ),
    );
  }
}
