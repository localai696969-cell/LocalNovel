import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services/backup_service.dart';
import 'file_browser_screen.dart';

// Sao lưu/khôi phục TOÀN BỘ dữ liệu app (mọi truyện) ra 1 file .zip — dùng
// khi đổi máy hoặc phòng mất dữ liệu. KHÔNG bao gồm API key (xem giải
// thích trong backup_service.dart) — cần nhập lại API key sau khi khôi
// phục trên máy mới.
class BackupRestoreScreen extends StatefulWidget {
  const BackupRestoreScreen({super.key});
  @override
  State<BackupRestoreScreen> createState() => _BackupRestoreScreenState();
}

class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
  final backupService = BackupService();
  bool exporting = false;
  bool restoring = false;

  Future<void> _export() async {
    setState(() => exporting = true);
    try {
      final file = await backupService.exportBackup();
      await Share.shareXFiles([XFile(file.path)], text: 'Sao lưu dữ liệu LocalNovel');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi sao lưu: $e')));
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  Future<void> _restore() async {
    final path = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const FileBrowserScreen(allowedExtensions: ['zip', 'json'])),
    );
    if (path == null) return;

    setState(() => restoring = true);
    try {
      final preview = await backupService.readBackupFile(File(path));
      if (!mounted) return;
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Khôi phục dữ liệu?'),
          content: Text(
            'File này có ${preview.novelCount} truyện, ${preview.chapterCount} chương'
            '${preview.exportedAt != null ? ', sao lưu lúc ${preview.exportedAt}' : ''}.\n\n'
            'Dữ liệu sẽ được GHI ĐÈ theo id (không xóa dữ liệu hiện có không trùng id, '
            'nhưng phần trùng id sẽ bị thay bằng bản trong file sao lưu này).',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Khôi phục')),
          ],
        ),
      );
      if (confirm == true) {
        await backupService.restoreFromPreview(preview);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Đã khôi phục xong — khởi động lại app để thấy đầy đủ thay đổi.'),
          ));
        }
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi khôi phục: $e')));
    } finally {
      if (mounted) setState(() => restoring = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sao lưu & khôi phục')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Sao lưu toàn bộ dữ liệu (mọi truyện: Story Bible, chương, lịch sử phiên bản, '
            'chat, tài liệu, thuật ngữ) ra 1 file .zip để giữ phòng khi mất máy, hoặc chuyển '
            'sang máy khác.',
            style: TextStyle(color: Colors.grey, fontSize: 13),
          ),
          const SizedBox(height: 4),
          const Text(
            'KHÔNG bao gồm API key (vì lý do bảo mật) — cần nhập lại API key thủ công sau khi '
            'khôi phục trên máy mới. Danh sách provider/model vẫn được khôi phục đầy đủ.',
            style: TextStyle(color: Colors.orange, fontSize: 12),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: exporting ? null : _export,
            icon: exporting
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.upload_outlined),
            label: Text(exporting ? 'Đang sao lưu...' : 'Sao lưu ngay'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: restoring ? null : _restore,
            icon: restoring
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.download_outlined),
            label: Text(restoring ? 'Đang khôi phục...' : 'Khôi phục từ file sao lưu'),
          ),
        ],
      ),
    );
  }
}
