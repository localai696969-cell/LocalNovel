import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/bible_extraction_service.dart';
import '../services/database_service.dart';

// ĐÃ THÊM — mục BJ, 2026-09-20 — màn hình XEM LẠI TRƯỚC KHI GHI, xem giải
// thích đầy đủ lý do (không tự động ghi thẳng) ở đầu file
// `bible_extraction_service.dart`. Dùng CHUNG cho cả 2 nguồn (chat và tài
// liệu) — không viết riêng 2 màn hình, vì logic xem lại/ghi vào DB giống
// hệt nhau bất kể nguồn trích xuất từ đâu.
class BibleExtractionReviewScreen extends StatefulWidget {
  final String novelId;
  final List<ExtractedBibleEntry> entries;
  // Hiển thị cho người dùng biết trích từ đâu (vd "từ đoạn chat vừa rồi",
  // "từ tài liệu Story_Bible.docx") — chỉ để hiển thị, không ảnh hưởng logic.
  final String sourceLabel;
  // ĐÃ THÊM: báo THẬT nếu có chunk nào bị bỏ sót lúc trích xuất (model lỗi
  // ở đúng chunk đó) — không im lặng giấu đi.
  final int totalChunks;
  final int failedChunkCount;

  const BibleExtractionReviewScreen({
    super.key,
    required this.novelId,
    required this.entries,
    required this.sourceLabel,
    this.totalChunks = 1,
    this.failedChunkCount = 0,
  });

  @override
  State<BibleExtractionReviewScreen> createState() => _BibleExtractionReviewScreenState();
}

class _BibleExtractionReviewScreenState extends State<BibleExtractionReviewScreen> {
  final db = DatabaseService.instance;
  bool _saving = false;

  String _typeLabel(String type) {
    switch (type) {
      case 'character':
        return 'Nhân vật';
      case 'world_rule':
        return 'Luật thế giới';
      case 'glossary':
        return 'Thuật ngữ';
      case 'plot_thread':
        return 'Tuyến truyện';
      default:
        return type;
    }
  }

  IconData _typeIcon(String type) {
    switch (type) {
      case 'character':
        return Icons.person_outline;
      case 'world_rule':
        return Icons.gavel_outlined;
      case 'glossary':
        return Icons.menu_book_outlined;
      case 'plot_thread':
        return Icons.timeline_outlined;
      default:
        return Icons.notes_outlined;
    }
  }

  Future<void> _save() async {
    final selected = widget.entries.where((e) => e.selected).toList();
    if (selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa chọn mục nào để lưu.')));
      return;
    }
    setState(() => _saving = true);
    try {
      for (final e in selected) {
        switch (e.type) {
          case 'character':
            await db.upsertCharacter(Character(
              id: generateBibleEntryId(),
              novelId: widget.novelId,
              name: e.title.isEmpty ? 'Nhân vật chưa đặt tên' : e.title,
              role: e.category.isEmpty ? 'Khác' : e.category,
              description: e.content,
            ));
            break;
          case 'world_rule':
            await db.upsertWorldRule(WorldRule(
              id: generateBibleEntryId(),
              novelId: widget.novelId,
              title: e.title.isEmpty ? 'Luật chưa đặt tên' : e.title,
              content: e.content,
              category: e.category.isEmpty ? 'Luật lệ' : e.category,
            ));
            break;
          case 'glossary':
            await db.upsertGlossaryTerm(GlossaryTerm(
              id: generateBibleEntryId(),
              novelId: widget.novelId,
              term: e.title.isEmpty ? 'Thuật ngữ chưa đặt tên' : e.title,
              definition: e.content,
              category: e.category.isEmpty ? 'Thuật ngữ' : e.category,
            ));
            break;
          case 'plot_thread':
            await db.upsertPlotThread(PlotThread(
              id: generateBibleEntryId(),
              novelId: widget.novelId,
              name: e.title.isEmpty ? 'Tuyến truyện chưa đặt tên' : e.title,
              description: e.content,
            ));
            break;
        }
      }
      if (!mounted) return;
      Navigator.of(context).pop(selected.length);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi khi lưu: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final selectedCount = widget.entries.where((e) => e.selected).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Xem lại trước khi thêm vào Bible'),
      ),
      body: widget.entries.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Không tìm thấy dữ kiện cụ thể nào để trích xuất từ nội dung này.\n\n'
                  'Có thể đoạn nội dung chỉ chứa nhận xét/tư vấn chung chung, không có tên nhân vật, luật lệ, thuật ngữ hay tuyến truyện cụ thể nào.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(
                    'Trích ${widget.sourceLabel} — bấm giữ vào từng mục để sửa trước khi lưu. Chỉ mục được chọn (dấu tích) mới được thêm vào Bible.',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                ),
                // ĐÃ THÊM: báo THẬT nếu có chunk bị bỏ sót — không im lặng.
                if (widget.failedChunkCount > 0)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(horizontal: 12),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.orange.shade100, borderRadius: BorderRadius.circular(8)),
                    child: Text(
                      '⚠️ ${widget.failedChunkCount}/${widget.totalChunks} đoạn bị lỗi lúc trích xuất (model báo lỗi hoặc trả sai định dạng) — nội dung ở các đoạn đó CHƯA được trích, có thể cần thử lại.',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                Expanded(
                  child: ListView.builder(
                    itemCount: widget.entries.length,
                    itemBuilder: (context, i) {
                      final e = widget.entries[i];
                      return GestureDetector(
                        onLongPress: () => _editEntry(e),
                        child: CheckboxListTile(
                          value: e.selected,
                          onChanged: (v) => setState(() => e.selected = v ?? false),
                          secondary: Icon(_typeIcon(e.type)),
                          title: Text(e.title.isEmpty ? '(chưa có tên)' : e.title),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${_typeLabel(e.type)}${e.category.isNotEmpty ? ' · ${e.category}' : ''}'),
                              Text(e.content),
                              // ĐÃ THÊM — theo đúng phản hồi người dùng: 2
                              // cảnh báo THẬT thay vì chỉ ghi vào mục giới hạn.
                              if (e.duplicateWarning != null)
                                Text('⚠️ ${e.duplicateWarning}', style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
                              if (!e.isGrounded)
                                const Text('❔ Không tìm thấy tên này trong văn bản gốc — có thể model diễn đạt lại, hoặc bịa, tự kiểm tra kỹ trước khi lưu',
                                    style: TextStyle(color: Colors.deepOrange, fontSize: 11)),
                            ],
                          ),
                          isThreeLine: true,
                        ),
                      );
                    },
                  ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: FilledButton.icon(
                      onPressed: _saving ? null : _save,
                      icon: _saving
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.check),
                      label: Text(_saving ? 'Đang lưu...' : 'Thêm $selectedCount mục vào Bible'),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _editEntry(ExtractedBibleEntry e) async {
    final titleCtrl = TextEditingController(text: e.title);
    final contentCtrl = TextEditingController(text: e.content);
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Sửa ${_typeLabel(e.type)}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên/tiêu đề')),
            TextField(controller: contentCtrl, decoration: const InputDecoration(labelText: 'Nội dung'), maxLines: 5),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Huỷ')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Lưu')),
        ],
      ),
    );
    if (result == true) {
      setState(() {
        e.title = titleCtrl.text;
        e.content = contentCtrl.text;
      });
    }
  }
}
