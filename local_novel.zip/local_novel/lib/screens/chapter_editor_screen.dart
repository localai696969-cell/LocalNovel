import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import '../services/settings_service.dart';
import '../services/summary_service.dart';
import '../services/style_service.dart';

class ChapterEditorScreen extends StatefulWidget {
  final Chapter chapter;
  const ChapterEditorScreen({super.key, required this.chapter});

  @override
  State<ChapterEditorScreen> createState() => _ChapterEditorScreenState();
}

class _ChapterEditorScreenState extends State<ChapterEditorScreen> {
  late TextEditingController titleCtrl;
  late TextEditingController contentCtrl;
  final outlineCtrl = TextEditingController();
  final db = DatabaseService.instance;
  bool checking = false;
  bool generating = false;
  bool fleshingOut = false;
  bool savingBackground = false;
  String? warning;
  List<String> activeEntries = [];
  List<StyleProfile> styles = [];
  StyleProfile? selectedStyle;

  @override
  void initState() {
    super.initState();
    titleCtrl = TextEditingController(text: widget.chapter.title);
    contentCtrl = TextEditingController(text: widget.chapter.content);
    warning = widget.chapter.consistencyWarning;
    contentCtrl.addListener(_refreshPreview);
    _loadStyles();
    _refreshPreview();
  }

  Future<void> _loadStyles() async {
    final s = await db.allStyleProfiles(widget.chapter.novelId);
    setState(() => styles = s);
  }

  Future<RagService> _rag() async => RagService(
        db,
        await SettingsService().currentEmbeddingService(),
        novelId: widget.chapter.novelId,
        contextBudgetChars: await SettingsService().loadRagBudget(),
      );

  // Xem trước lorebook: hiển thị ngay những entry Story Bible nào sẽ
  // được nạp vào AI cho đoạn văn hiện tại, để người viết yên tâm là
  // đúng nhân vật/luật đang được tham chiếu trước khi bấm sinh văn bản.
  DateTime _lastPreviewRequest = DateTime.now();
  Future<void> _refreshPreview() async {
    final requestTime = DateTime.now();
    _lastPreviewRequest = requestTime;
    await Future.delayed(const Duration(milliseconds: 500));
    if (_lastPreviewRequest != requestTime) return; // đã có thay đổi mới hơn, bỏ qua
    if (contentCtrl.text.trim().isEmpty) {
      setState(() => activeEntries = []);
      return;
    }
    final rag = await _rag();
    final entries = await rag.previewActiveEntries(contentCtrl.text);
    if (mounted) setState(() => activeEntries = entries);
  }

  Future<void> _save({bool silent = false}) async {
    widget.chapter.title = titleCtrl.text;
    widget.chapter.content = contentCtrl.text;
    widget.chapter.updatedAt = DateTime.now();
    await db.upsertChapter(widget.chapter);
    if (!silent && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu chương')));
    }
    _updateSummaryAndIndexInBackground();
  }

  // Chạy nền, không chặn UI: tóm tắt chương (lớp bộ nhớ nén cho các
  // chương xa) rồi cập nhật embedding để chương này tìm được qua truy
  // xuất ngữ nghĩa từ các chương sau này.
  Future<void> _updateSummaryAndIndexInBackground() async {
    if (widget.chapter.content.trim().isEmpty) return;
    setState(() => savingBackground = true);
    try {
      final provider = await SettingsService().currentProvider();
      final summary = await SummaryService().summarizeChapter(widget.chapter, provider);
      widget.chapter.autoSummary = summary;
      await db.upsertChapter(widget.chapter);
      final rag = await _rag();
      await rag.indexChapter(widget.chapter);
    } catch (_) {
      // lỗi nền (ví dụ mất mạng khi dùng API) không cần làm phiền người viết
    } finally {
      if (mounted) setState(() => savingBackground = false);
    }
  }

  Future<void> _continueWithAI() async {
    setState(() => generating = true);
    try {
      final provider = await SettingsService().currentProvider();
      final rag = await _rag();
      final systemPrompt = await rag.buildSystemPrompt(
        userInstruction: 'Viết tiếp đúng mạch văn, giữ giọng văn hiện có, không lặp lại nội dung cũ.'
            '${selectedStyle != null ? ' Văn phong: ${selectedStyle!.profileDescription}' : ''}',
        currentText: contentCtrl.text,
      );
      final result = await provider.generate(
        systemPrompt: systemPrompt,
        userPrompt: contentCtrl.text,
        maxTokens: 800,
      );
      setState(() => contentCtrl.text = '${contentCtrl.text}\n\n$result');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      setState(() => generating = false);
    }
  }

  // "Đắp thịt": nhận outline sơ sài người dùng gõ, sinh ra văn xuôi đầy
  // đủ theo văn phong đã chọn, có thoại và miêu tả — không chỉ liệt kê
  // lại outline.
  Future<void> _fleshOutOutline() async {
    if (outlineCtrl.text.trim().isEmpty) return;
    setState(() => fleshingOut = true);
    try {
      final provider = await SettingsService().currentProvider();
      final rag = await _rag();
      final result = await StyleService().fleshOutOutline(
        outline: outlineCtrl.text,
        style: selectedStyle,
        rag: rag,
        provider: provider,
      );
      setState(() {
        contentCtrl.text = contentCtrl.text.trim().isEmpty ? result : '${contentCtrl.text}\n\n$result';
        outlineCtrl.clear();
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      setState(() => fleshingOut = false);
    }
  }

  Future<void> _checkConsistency() async {
    setState(() => checking = true);
    try {
      widget.chapter.content = contentCtrl.text;
      final provider = await SettingsService().currentProvider();
      final rag = await _rag();
      final prompt = await rag.buildConsistencyCheckPrompt(widget.chapter);
      final result = await provider.generate(
        systemPrompt: 'Bạn là biên tập viên kiểm tra tính nhất quán của tiểu thuyết dài kỳ.',
        userPrompt: prompt,
        maxTokens: 400,
      );
      final ok = result.trim().toUpperCase().startsWith('OK');
      widget.chapter.consistencyChecked = true;
      widget.chapter.consistencyWarning = ok ? null : result.trim();
      await db.upsertChapter(widget.chapter);
      setState(() => warning = widget.chapter.consistencyWarning);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      setState(() => checking = false);
    }
  }

  Future<void> _showOutlineSheet() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: StatefulBuilder(builder: (context, setSheetState) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Đắp thịt cốt truyện', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 4),
              const Text(
                'Gõ vài gạch đầu dòng định hướng, AI sẽ triển khai thành văn xuôi đầy đủ.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: outlineCtrl,
                maxLines: 5,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: '- Thanh Vũ đối mặt Hắc Diễm Tôn tại cửa vực\n- Phát hiện Hắc Diễm Tôn mất một tay\n- Trận đấu kết thúc bằng một lời thề báo thù',
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<StyleProfile?>(
                value: selectedStyle,
                decoration: const InputDecoration(labelText: 'Văn phong', border: OutlineInputBorder()),
                items: [
                  const DropdownMenuItem(value: null, child: Text('Mặc định')),
                  ...styles.map((s) => DropdownMenuItem(value: s, child: Text(s.name))),
                ],
                onChanged: (v) => setSheetState(() => selectedStyle = v),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: fleshingOut
                    ? null
                    : () async {
                        Navigator.pop(context);
                        await _fleshOutOutline();
                      },
                icon: const Icon(Icons.auto_fix_high_outlined),
                label: const Text('Triển khai thành chương'),
              ),
            ],
          );
        }),
      ),
    );
  }

  @override
  void dispose() {
    contentCtrl.removeListener(_refreshPreview);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Soạn chương'),
        actions: [
          if (savingBackground)
            const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
            ),
          IconButton(onPressed: () => _save(), icon: const Icon(Icons.save_outlined)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tiêu đề chương')),
            const SizedBox(height: 8),
            if (warning != null)
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(8)),
                child: Text(warning!, style: TextStyle(color: Colors.orange.shade900, fontSize: 12)),
              ),
            if (activeEntries.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: activeEntries
                      .map((e) => Chip(
                            label: Text(e, style: const TextStyle(fontSize: 11)),
                            visualDensity: VisualDensity.compact,
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ))
                      .toList(),
                ),
              ),
            Expanded(
              child: TextField(
                controller: contentCtrl,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: const InputDecoration(
                  hintText: 'Nội dung chương...',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: checking ? null : _checkConsistency,
                  icon: checking
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.fact_check_outlined),
                  label: const Text('Kiểm tra'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: fleshingOut ? null : _showOutlineSheet,
                  icon: const Icon(Icons.auto_fix_high_outlined),
                  label: const Text('Đắp thịt'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.icon(
                  onPressed: generating ? null : _continueWithAI,
                  icon: generating
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome_outlined),
                  label: const Text('Viết tiếp'),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
