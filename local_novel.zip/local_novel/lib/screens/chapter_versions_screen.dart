import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';

// Lịch sử phiên bản (undo AI viết đè) — hiển thị các bản snapshot đã chụp
// TRƯỚC mỗi lần AI viết tiếp/đắp thịt/rewrite (xem _snapshotVersion trong
// chapter_editor_screen.dart). Chọn "Khôi phục" trả về ChapterVersion đã
// chọn qua Navigator.pop, màn soạn chương tự áp dụng lại.
class ChapterVersionsScreen extends StatefulWidget {
  final String chapterId;
  const ChapterVersionsScreen({super.key, required this.chapterId});

  @override
  State<ChapterVersionsScreen> createState() => _ChapterVersionsScreenState();
}

class _ChapterVersionsScreenState extends State<ChapterVersionsScreen> {
  final db = DatabaseService.instance;
  List<ChapterVersion> versions = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final v = await db.versionsForChapter(widget.chapterId);
    if (!mounted) return;
    setState(() {
      versions = v;
      loading = false;
    });
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Vừa xong';
    if (diff.inMinutes < 60) return '${diff.inMinutes} phút trước';
    if (diff.inHours < 24) return '${diff.inHours} giờ trước';
    if (diff.inDays < 30) return '${diff.inDays} ngày trước';
    return '${dt.day}/${dt.month}/${dt.year}';
  }

  Future<void> _preview(ChapterVersion v) async {
    final restore = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(v.title.isEmpty ? '(Không có tiêu đề)' : v.title),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Text(v.content.isEmpty ? '(Chương trống ở thời điểm này)' : v.content),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Đóng')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Khôi phục bản này')),
        ],
      ),
    );
    if (restore == true && mounted) {
      Navigator.pop(context, v);
    }
  }

  Future<void> _delete(ChapterVersion v) async {
    await db.deleteChapterVersion(v.id);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử phiên bản')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : versions.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chưa có phiên bản cũ nào. Mỗi khi AI viết tiếp/đắp thịt/viết lại một đoạn, '
                      'nội dung TRƯỚC ĐÓ sẽ tự động được lưu lại ở đây để có thể khôi phục nếu cần.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.separated(
                  itemCount: versions.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final v = versions[i];
                    return ListTile(
                      leading: const Icon(Icons.history_outlined),
                      title: Text(v.label),
                      subtitle: Text('${_timeAgo(v.createdAt)} · ${v.wordCount} chữ'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 18),
                        onPressed: () => _delete(v),
                      ),
                      onTap: () => _preview(v),
                    );
                  },
                ),
    );
  }
}
