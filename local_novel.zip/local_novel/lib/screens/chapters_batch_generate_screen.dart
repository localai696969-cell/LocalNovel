import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/chapter_batch_service.dart';
import '../services/database_service.dart';
import '../services/settings_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng): màn hình chọn NHIỀU chương đã có
// outline/dàn ý (viết trước, KHÔNG gọi AI) để AI viết hàng loạt, xử lý
// TUẦN TỰ theo hàng đợi — không đồng thời, tránh đúng nguyên nhân crash
// "2 lệnh generate chạy chồng chéo" (mục 5.67 kiến trúc).
class ChaptersBatchGenerateScreen extends StatefulWidget {
  final String novelId;
  const ChaptersBatchGenerateScreen({super.key, required this.novelId});

  @override
  State<ChaptersBatchGenerateScreen> createState() => _ChaptersBatchGenerateScreenState();
}

class _ChaptersBatchGenerateScreenState extends State<ChaptersBatchGenerateScreen> {
  final db = DatabaseService.instance;
  late final ChapterBatchService batchService = ChapterBatchService(db);
  List<Chapter> chapters = [];
  final Set<String> selected = {};
  bool loading = true;
  bool _processing = false;
  bool _cancelRequested = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await db.allChapters(widget.novelId);
    if (!mounted) return;
    setState(() {
      chapters = all;
      loading = false;
    });
  }

  bool _hasOutline(Chapter c) => (c.outline?.trim().isNotEmpty ?? false);
  bool _isEmpty(Chapter c) => c.content.trim().isEmpty;

  void _selectAllWithOutline() => setState(() {
        selected
          ..clear()
          ..addAll(chapters.where(_hasOutline).map((c) => c.id));
      });
  void _selectPendingOnly() => setState(() {
        selected
          ..clear()
          ..addAll(chapters.where((c) => _hasOutline(c) && _isEmpty(c)).map((c) => c.id));
      });
  void _selectNone() => setState(() => selected.clear());

  Future<void> _runBatch() async {
    final targets = chapters.where((c) => selected.contains(c.id)).toList();
    if (targets.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa chọn chương nào')));
      return;
    }
    final withoutOutline = targets.where((c) => !_hasOutline(c)).length;
    if (withoutOutline > 0) {
      final proceed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Có chương chưa có outline'),
          content: Text('$withoutOutline/${targets.length} chương đã chọn CHƯA có dàn ý — sẽ tự động bỏ qua khi tạo. Tiếp tục?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Tiếp tục')),
          ],
        ),
      );
      if (proceed != true || !mounted) return;
    }

    int done = 0;
    final total = targets.length;
    final progressNotifier = ValueNotifier<({double value, String label})>((value: 0, label: ''));
    _cancelRequested = false;
    setState(() => _processing = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Đang tạo chương hàng loạt...'),
        content: ValueListenableBuilder<({double value, String label})>(
          valueListenable: progressNotifier,
          builder: (context, v, _) => Column(mainAxisSize: MainAxisSize.min, children: [
            LinearProgressIndicator(value: total > 0 ? v.value : null),
            const SizedBox(height: 12),
            Text('Đã xong ${(v.value * total).round()}/$total chương'),
            if (v.label.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('Đang viết: ${v.label}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ],
          ]),
        ),
        actions: [
          TextButton(
            onPressed: () {
              _cancelRequested = true;
              Navigator.pop(dialogContext);
            },
            child: const Text('Huỷ'),
          ),
        ],
      ),
    );

    try {
      final provider = await SettingsService().currentProvider();
      await batchService.generateBatch(
        chapters: targets,
        provider: provider,
        novelId: widget.novelId,
        isCancelled: () => _cancelRequested,
        onProgress: (d, t, title) {
          done = d;
          progressNotifier.value = (value: t > 0 ? d / t : 0, label: title);
        },
      );
      if (mounted && !_cancelRequested) Navigator.pop(context);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(_cancelRequested
              ? 'Đã huỷ — hoàn thành $done/$total chương trong lượt chọn này.'
              : 'Đã tạo xong $done/$total chương.'),
        ));
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e'), duration: const Duration(seconds: 8)));
      }
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: chặn vuốt back (Android 13+ predictive back) trong lúc
    // đang tạo hàng loạt — cùng lý do như document_screen.dart.
    return PopScope(
      canPop: !_processing,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Đang tạo chương — đợi xong trước khi thoát để không mất tiến độ.'),
        ));
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Tạo chương hàng loạt'),
          actions: [
            PopupMenuButton<String>(
              tooltip: 'Chọn nhanh',
              onSelected: (v) {
                if (v == 'outline') _selectAllWithOutline();
                if (v == 'pending') _selectPendingOnly();
                if (v == 'none') _selectNone();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'outline', child: Text('Chọn tất cả có outline')),
                PopupMenuItem(value: 'pending', child: Text('Chỉ chọn: có outline + chưa viết')),
                PopupMenuItem(value: 'none', child: Text('Bỏ chọn tất cả')),
              ],
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : chapters.isEmpty
                ? const Center(child: Text('Chưa có chương nào.'))
                : ListView.builder(
                    itemCount: chapters.length,
                    itemBuilder: (context, i) {
                      final c = chapters[i];
                      final hasOutline = _hasOutline(c);
                      final isEmpty = _isEmpty(c);
                      return CheckboxListTile(
                        value: selected.contains(c.id),
                        onChanged: _processing
                            ? null
                            : (v) => setState(() {
                                  if (v == true) {
                                    selected.add(c.id);
                                  } else {
                                    selected.remove(c.id);
                                  }
                                }),
                        secondary: Icon(
                          !hasOutline
                              ? Icons.circle_outlined
                              : (isEmpty ? Icons.pending_outlined : Icons.check_circle),
                          color: hasOutline && isEmpty ? Colors.orange : (hasOutline ? Colors.green : Colors.grey),
                        ),
                        title: Text('Chương ${c.number}: ${c.title}'),
                        subtitle: Text(
                          !hasOutline
                              ? 'Chưa có outline'
                              : (isEmpty ? 'Có outline, chưa viết — sẵn sàng tạo' : 'Đã có nội dung (${c.wordCount} chữ)'),
                          style: TextStyle(
                            fontSize: 12,
                            color: hasOutline && isEmpty ? Colors.orange : Colors.grey,
                          ),
                        ),
                      );
                    },
                  ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: FilledButton.icon(
              onPressed: _processing ? null : _runBatch,
              icon: const Icon(Icons.auto_awesome),
              label: Text('Tạo ${selected.length} chương đã chọn'),
            ),
          ),
        ),
      ),
    );
  }
}
