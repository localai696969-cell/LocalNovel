import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/chapter_batch_service.dart';
import '../services/database_service.dart';
import '../services/settings_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng): màn hình chọn NHIỀU chương đã có
// outline/dàn ý (viết trước, KHÔNG gọi AI) để AI viết hàng loạt, xử lý
// TUẦN TỰ theo hàng đợi — không đồng thời, tránh đúng nguyên nhân crash
// "2 lệnh generate chạy chồng chéo" (mục 5.67 kiến trúc).
//
// ĐÃ SỬA HOÀN TOÀN (theo yêu cầu người dùng: "toàn bộ việc tạo chương...
// đều như chat là sinh ra chữ nào thì hiện chữ đó trên màn hình, kèm theo
// đó thì khi batch tiến trình... thanh tiến trình đó thay vì hiện giữa
// màn hình thì bây giờ hiện ở góc"): trước đây dùng `AlertDialog` CHẶN cả
// màn hình (barrierDismissible: false) để hiện % — giờ bỏ hẳn dialog đó.
// Trong lúc đang tạo, thân màn hình đổi sang hiện TRỰC TIẾP văn bản đang
// sinh ra của TỪNG chương (có thể NHIỀU chương cùng lúc nếu provider là
// GPU remote — xem `_InFlightChapter`), thanh tiến trình tổng dời xuống 1
// thẻ nhỏ ở GÓC DƯỚI PHẢI màn hình, không còn che nội dung đang xem.
class ChaptersBatchGenerateScreen extends StatefulWidget {
  final String novelId;
  const ChaptersBatchGenerateScreen({super.key, required this.novelId});

  @override
  State<ChaptersBatchGenerateScreen> createState() => _ChaptersBatchGenerateScreenState();
}

// Trạng thái sinh chữ của 1 chương đang "trong luồng" — hoạt động ở CẢ 2
// nhánh (local lẫn GPU remote, xem `ChapterBatchService._generateBatchSequential`/
// `_generateBatchParallel`) — riêng `percent` (%) chỉ nhánh REMOTE có (dựa
// trên checkpoint định kỳ, local không cần vì không có khái niệm "resume
// giữa chừng", xem giải thích ở chapter_batch_service.dart).
class _InFlightChapter {
  final String title;
  String text;
  int? percent;
  _InFlightChapter({required this.title, required this.text, this.percent});
}

class _ChaptersBatchGenerateScreenState extends State<ChaptersBatchGenerateScreen> {
  final db = DatabaseService.instance;
  late final ChapterBatchService batchService = ChapterBatchService(db);
  List<Chapter> chapters = [];
  final Set<String> selected = {};
  bool loading = true;
  bool _processing = false;
  bool _cancelRequested = false;

  // Tiến trình TỔNG (thẻ góc) — không còn cần ValueNotifier riêng vì cả
  // màn hình rebuild qua setState() bình thường (tần suất chunk không quá
  // dày, khác gì chat_screen.dart đang làm).
  int _done = 0;
  int _total = 0;
  final Map<String, _InFlightChapter> _inFlight = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await db.allChapters(widget.novelId);
    if (!mounted) return;
    setState(() {
      chapters = all;
      loading = false;
    });
  }

  bool _hasOutline(Chapter c) => (c.outline?.trim().isNotEmpty ?? false);
  bool _isEmpty(Chapter c) => c.content.trim().isEmpty;
  // ĐÃ THÊM: chương có checkpoint dở dang từ lần chạy trước bị lỗi giữa
  // chừng (vd GPU remote sập) — content vẫn rỗng (chưa xong hẳn) nhưng đã
  // có phần viết dở lưu tạm, lần chạy tới sẽ TỰ ĐỘNG resume từ đây thay vì
  // viết lại từ đầu (xem ChapterBatchService._generateBatchParallel).
  bool _hasCheckpoint(Chapter c) => (c.generationCheckpoint?.trim().isNotEmpty ?? false);

  void _selectAllWithOutline() => setState(() {
        selected
          ..clear()
          ..addAll(chapters.where(_hasOutline).map((c) => c.id));
      });
  void _selectPendingOnly() => setState(() {
        selected
          ..clear()
          ..addAll(chapters.where((c) => _hasOutline(c) && _isEmpty(c)).map((c) => c.id));
      });
  void _selectNone() => setState(() => selected.clear());

  Future<void> _runBatch() async {
    final targets = chapters.where((c) => selected.contains(c.id)).toList();
    if (targets.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa chọn chương nào')));
      return;
    }
    final withoutOutline = targets.where((c) => !_hasOutline(c)).length;
    if (withoutOutline > 0) {
      final proceed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Có chương chưa có outline'),
          content: Text('$withoutOutline/${targets.length} chương đã chọn CHƯA có dàn ý — sẽ tự động bỏ qua khi tạo. Tiếp tục?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Tiếp tục')),
          ],
        ),
      );
      if (proceed != true || !mounted) return;
    }

    final total = targets.length;
    _cancelRequested = false;
    setState(() {
      _processing = true;
      _done = 0;
      _total = total;
      _inFlight.clear();
    });

    try {
      final provider = await SettingsService().currentProvider(widget.novelId);
      await batchService.generateBatch(
        chapters: targets,
        provider: provider,
        novelId: widget.novelId,
        isCancelled: () => _cancelRequested,
        onProgress: (d, t, title, {currentPercent, currentText, currentChapterId}) {
          if (!mounted) return;
          setState(() {
            _done = d;
            _total = t;
            if (currentChapterId != null) {
              if (currentText != null) {
                // Đang chạy (hoặc vừa nhận thêm chunk) — cập nhật/tạo entry.
                final existing = _inFlight[currentChapterId];
                if (existing != null) {
                  existing.text = currentText;
                  existing.percent = currentPercent;
                } else {
                  _inFlight[currentChapterId] = _InFlightChapter(title: title, text: currentText, percent: currentPercent);
                }
              } else {
                // text == null: chương này vừa XONG/HUỶ/LỖI — bỏ khỏi danh
                // sách "đang chạy" (xem 3 điểm gọi ở chapter_batch_service.dart).
                _inFlight.remove(currentChapterId);
              }
            }
          });
        },
      );
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(_cancelRequested
              ? 'Đã huỷ — hoàn thành $_done/$total chương trong lượt chọn này.'
              : 'Đã tạo xong $_done/$total chương.'),
        ));
      }
    } catch (e) {
      await _load();
      if (mounted) {
        // ĐÃ THÊM: nếu lỗi resumable (checkpoint đã lưu — xem
        // ChapterBatchAnomalyException.resumable), gợi ý rõ ràng thay vì
        // chỉ hiện thông báo lỗi chung chung — người dùng cần biết CHẠY
        // LẠI (không cần sửa gì) là đủ để tiếp tục đúng chỗ gãy.
        final isResumable = e is ChapterBatchAnomalyException && e.resumable;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(isResumable ? '$e\n\nChỉ cần bấm "Tạo hàng loạt" lại — không cần sửa gì.' : 'Lỗi: $e'),
          duration: const Duration(seconds: 8),
        ));
      }
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  Widget _buildLiveGenerationView() {
    if (_inFlight.isEmpty) {
      // Nhánh LOCAL (không báo text theo chunk) hoặc đang giữa 2 chương —
      // vẫn cho xem danh sách chọn như bình thường, chỉ khoá tương tác.
      return _buildSelectionList();
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), // chừa chỗ cho thẻ góc
      children: _inFlight.values.map((c) {
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                const SizedBox(width: 8),
                Expanded(child: Text(c.title, style: const TextStyle(fontWeight: FontWeight.bold))),
                if (c.percent != null)
                  Text('${c.percent}%', style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ]),
              const SizedBox(height: 8),
              // ĐÃ THÊM: hiện chữ đang sinh ra TRỰC TIẾP, giống khung chat —
              // giới hạn chiều cao + cuộn riêng, tránh 1 chương dài đẩy các
              // chương khác ra khỏi màn hình.
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 160),
                child: SingleChildScrollView(
                  reverse: true, // luôn cuộn tới cuối — nơi chữ mới nhất
                  child: Text(c.text, style: const TextStyle(fontSize: 13)),
                ),
              ),
            ]),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSelectionList() {
    return chapters.isEmpty
        ? const Center(child: Text('Chưa có chương nào.'))
        : ListView.builder(
            itemCount: chapters.length,
            itemBuilder: (context, i) {
              final c = chapters[i];
              final hasOutline = _hasOutline(c);
              final isEmpty = _isEmpty(c);
              final hasCheckpoint = isEmpty && _hasCheckpoint(c);
              return CheckboxListTile(
                value: selected.contains(c.id),
                onChanged: _processing
                    ? null
                    : (v) => setState(() {
                          if (v == true) {
                            selected.add(c.id);
                          } else {
                            selected.remove(c.id);
                          }
                        }),
                secondary: Icon(
                  !hasOutline
                      ? Icons.circle_outlined
                      : hasCheckpoint
                          ? Icons.play_circle_outline
                          : (isEmpty ? Icons.pending_outlined : Icons.check_circle),
                  color: hasCheckpoint
                      ? Colors.blue
                      : (hasOutline && isEmpty ? Colors.orange : (hasOutline ? Colors.green : Colors.grey)),
                ),
                title: Text('Chương ${c.number}: ${c.title}'),
                subtitle: Text(
                  !hasOutline
                      ? 'Chưa có outline'
                      // ĐÃ THÊM: phân biệt rõ "chưa viết" với "đang
                      // viết dở, đã lưu tạm — chọn lại sẽ TIẾP TỤC
                      // đúng chỗ gãy" (xem _hasCheckpoint) — người
                      // dùng cần biết chọn lại KHÔNG viết lại từ đầu.
                      : hasCheckpoint
                          ? 'Đang dở ~${ChapterBatchService.estimatePercent(c.generationCheckpoint?.length ?? 0)}% — chọn lại sẽ tiếp tục, không viết lại từ đầu'
                          : (isEmpty ? 'Có outline, chưa viết — sẵn sàng tạo' : 'Đã có nội dung (${c.wordCount} chữ)'),
                  style: TextStyle(
                    fontSize: 12,
                    color: hasCheckpoint ? Colors.blue : (hasOutline && isEmpty ? Colors.orange : Colors.grey),
                  ),
                ),
              );
            },
          );
  }

  // ĐÃ THÊM: thẻ tiến trình TỔNG — nổi ở GÓC DƯỚI PHẢI thay cho AlertDialog
  // chặn giữa màn hình trước đây. Chỉ hiện khi đang xử lý.
  Widget _buildCornerProgressCard() {
    final value = _total > 0 ? _done / _total : 0.0;
    return Positioned(
      right: 12,
      bottom: 12,
      child: Material(
        elevation: 6,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 220,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text('Đã xong $_done/$_total chương', style: const TextStyle(fontSize: 12))),
              InkWell(
                onTap: () => setState(() => _cancelRequested = true),
                child: const Padding(
                  padding: EdgeInsets.all(2),
                  child: Icon(Icons.close, size: 16),
                ),
              ),
            ]),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(value: _total > 0 ? value : null, minHeight: 6),
            ),
            if (_inFlight.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('${_inFlight.length} chương đang chạy song song', style: const TextStyle(fontSize: 10, color: Colors.grey)),
            ],
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: chặn vuốt back (Android 13+ predictive back) trong lúc
    // đang tạo hàng loạt — cùng lý do như document_screen.dart.
    return PopScope(
      canPop: !_processing,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Đang tạo chương — đợi xong trước khi thoát để không mất tiến độ.'),
        ));
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Tạo chương hàng loạt'),
          actions: [
            PopupMenuButton<String>(
              tooltip: 'Chọn nhanh',
              onSelected: (v) {
                if (v == 'outline') _selectAllWithOutline();
                if (v == 'pending') _selectPendingOnly();
                if (v == 'none') _selectNone();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'outline', child: Text('Chọn tất cả có outline')),
                PopupMenuItem(value: 'pending', child: Text('Chỉ chọn: có outline + chưa viết')),
                PopupMenuItem(value: 'none', child: Text('Bỏ chọn tất cả')),
              ],
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : Stack(
                children: [
                  _processing ? _buildLiveGenerationView() : _buildSelectionList(),
                  if (_processing) _buildCornerProgressCard(),
                ],
              ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: FilledButton.icon(
              onPressed: _processing ? null : _runBatch,
              icon: const Icon(Icons.auto_awesome),
              label: Text('Tạo ${selected.length} chương đã chọn'),
            ),
          ),
        ),
      ),
    );
  }
}

