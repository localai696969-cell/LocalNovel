import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/export_service.dart';
import 'chapter_editor_screen.dart';
import 'chapters_batch_generate_screen.dart';
import 'search_screen.dart';

class ChaptersScreen extends StatefulWidget {
  final String novelId;
  final String novelTitle;
  const ChaptersScreen({super.key, required this.novelId, required this.novelTitle});
  @override
  State<ChaptersScreen> createState() => _ChaptersScreenState();
}

class _ChaptersScreenState extends State<ChaptersScreen> {
  final db = DatabaseService.instance;
  List<Chapter> chapters = [];
  // ĐÃ THÊM: tầng "Quyển/Hồi" nhóm nhiều chương — rỗng = không dùng tính
  // năng này, danh sách chương hiển thị y hệt như trước (không đổi gì).
  List<Volume> volumes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant ChaptersScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final list = await db.allChapters(widget.novelId);
    final v = await db.allVolumes(widget.novelId);
    if (!mounted) return;
    setState(() {
      chapters = list;
      volumes = v;
    });
  }

  Future<void> _newChapter() async {
    final nextNumber = chapters.isEmpty ? 1 : chapters.first.number + 1;
    final chapter = Chapter(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      number: nextNumber,
      title: 'Chương mới',
      content: '',
    );
    await db.upsertChapter(chapter);
    await _load();
    if (mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: chapter)))
          .then((_) => _load());
    }
  }

  // ---------- Quyển/Hồi ----------
  Future<void> _addOrEditVolume({Volume? existing}) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(existing == null ? 'Quyển/Hồi mới' : 'Sửa Quyển/Hồi'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên (vd: Quyển 1 - Khởi đầu)')),
          TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả (tùy chọn)'), maxLines: 3),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
        ],
      ),
    );
    if (ok != true) return;
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    await db.upsertVolume(Volume(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      title: title,
      description: descCtrl.text.trim(),
      orderIndex: existing?.orderIndex ?? volumes.length,
    ));
    _load();
  }

  Future<void> _deleteVolume(Volume v) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa Quyển/Hồi?'),
        content: Text('"${v.title}" sẽ bị xóa. Các chương đang thuộc quyển này KHÔNG bị xóa, chỉ gỡ khỏi quyển.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirm != true) return;
    await db.deleteVolume(v.id);
    _load();
  }

  // Màn quản lý Quyển/Hồi — mở từ menu AppBar, CRUD đầy đủ, kéo-thả sắp
  // xếp lại thứ tự quyển (không phải thứ tự chương — chương vẫn đánh số
  // liên tục xuyên suốt truyện như cũ).
  Future<void> _manageVolumes() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(builder: (sheetContext, setSheetState) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                const Text('Quản lý Quyển/Hồi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const Spacer(),
                TextButton.icon(
                  onPressed: () async {
                    await _addOrEditVolume();
                    setSheetState(() {});
                  },
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Thêm'),
                ),
              ]),
              const SizedBox(height: 8),
              if (volumes.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Text('Chưa có quyển/hồi nào. Bấm "Thêm" để tạo.', style: TextStyle(color: Colors.grey)),
                )
              else
                Flexible(
                  child: ReorderableListView(
                    shrinkWrap: true,
                    onReorder: (oldIndex, newIndex) async {
                      if (newIndex > oldIndex) newIndex -= 1;
                      final list = List<Volume>.from(volumes);
                      final item = list.removeAt(oldIndex);
                      list.insert(newIndex, item);
                      setState(() => volumes = list);
                      setSheetState(() {});
                      await db.reorderVolumes(list);
                    },
                    children: volumes
                        .map((v) => ListTile(
                              key: ValueKey(v.id),
                              leading: const Icon(Icons.menu_book_outlined),
                              title: Text(v.title),
                              subtitle: v.description.isEmpty ? null : Text(v.description, maxLines: 1, overflow: TextOverflow.ellipsis),
                              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(
                                  icon: const Icon(Icons.edit_outlined, size: 18),
                                  onPressed: () async {
                                    await _addOrEditVolume(existing: v);
                                    setSheetState(() {});
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 18),
                                  onPressed: () async {
                                    await _deleteVolume(v);
                                    setSheetState(() {});
                                  },
                                ),
                              ]),
                            ))
                        .toList(),
                  ),
                ),
            ]),
          ),
        );
      }),
    );
    _load();
  }

  // Gán 1 chương vào quyển nào — bottom sheet chọn nhanh, có tùy chọn
  // "Không thuộc quyển nào" để gỡ khỏi quyển hiện tại.
  Future<void> _assignChapterVolume(Chapter c) async {
    if (volumes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Chưa có quyển/hồi nào — bấm biểu tượng sách ở thanh trên để tạo trước.'),
      ));
      return;
    }
    final chosen = await showModalBottomSheet<String?>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            ListTile(
              leading: const Icon(Icons.remove_circle_outline),
              title: const Text('Không thuộc quyển nào'),
              selected: c.volumeId == null,
              onTap: () => Navigator.pop(context, ''),
            ),
            ...volumes.map((v) => ListTile(
                  leading: const Icon(Icons.menu_book_outlined),
                  title: Text(v.title),
                  selected: c.volumeId == v.id,
                  onTap: () => Navigator.pop(context, v.id),
                )),
          ],
        ),
      ),
    );
    if (chosen == null) return; // bấm ra ngoài, không đổi gì
    c.volumeId = chosen.isEmpty ? null : chosen;
    c.updatedAt = DateTime.now();
    await db.upsertChapter(c);
    _load();
  }

  Future<void> _export(String format) async {
    final all = await db.allChaptersAscending(widget.novelId);
    if (all.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa có chương nào để xuất')));
      return;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đang tạo file xuất bản...')));
    }
    try {
      final novel = await db.novelById(widget.novelId);
      final exporter = ExportService();
      final file = switch (format) {
        'epub' => await exporter.exportEpub(
            title: widget.novelTitle,
            author: (novel?.author.trim().isNotEmpty ?? false) ? novel!.author : 'Chưa rõ tác giả',
            chapters: all,
          ),
        'docx' => await exporter.exportDocx(title: widget.novelTitle, chapters: all),
        _ => await exporter.exportTxt(title: widget.novelTitle, chapters: all),
      };
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất bản: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chương (${chapters.length})'),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_book_outlined),
            tooltip: 'Quản lý Quyển/Hồi',
            onPressed: _manageVolumes,
          ),
          IconButton(
            icon: const Icon(Icons.playlist_add_check_outlined),
            tooltip: 'Tạo chương hàng loạt từ outline',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChaptersBatchGenerateScreen(novelId: widget.novelId)),
            ).then((_) => _load()),
          ),
          IconButton(
            icon: const Icon(Icons.search_outlined),
            tooltip: 'Tìm kiếm toàn văn',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => SearchScreen(novelId: widget.novelId)),
            ).then((_) => _load()),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share_outlined),
            onSelected: _export,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'epub', child: Text('Xuất EPUB')),
              PopupMenuItem(value: 'docx', child: Text('Xuất DOCX')),
              PopupMenuItem(value: 'txt', child: Text('Xuất TXT')),
            ],
          ),
        ],
      ),
      body: chapters.isEmpty
          ? const Center(child: Text('Chưa có chương nào. Bấm + để bắt đầu.'))
          // ĐÃ THÊM: khi truyện CÓ ít nhất 1 quyển/hồi, danh sách chương
          // hiển thị NHÓM theo quyển (thứ tự quyển đã sắp, chương ascending
          // trong từng nhóm — đúng thứ tự đọc) thay vì danh sách phẳng DESC
          // như trước. Truyện CHƯA dùng tính năng này (volumes rỗng) giữ
          // NGUYÊN 100% hành vi cũ, không đổi gì.
          : (volumes.isEmpty ? _buildFlatList() : _buildGroupedByVolume()),
      floatingActionButton: FloatingActionButton(onPressed: _newChapter, child: const Icon(Icons.add)),
    );
  }

  Widget _chapterTile(Chapter c) {
    return ListTile(
      title: Text('Chương ${c.number}: ${c.title}'),
      subtitle: Text(
        '${c.wordCount} chữ'
        '${c.consistencyWarning != null ? ' · có cảnh báo nhất quán' : ''}'
        // ĐÃ THÊM: hiện rõ chương nào có outline nhưng chưa
        // viết ("chương mồi" đang chờ) — để biết còn gì cần
        // xử lý qua "Tạo chương hàng loạt" mà không cần mở
        // từng chương ra xem.
        '${(c.outline?.trim().isNotEmpty ?? false) && c.content.trim().isEmpty ? ' · có outline, chưa viết' : ''}',
      ),
      leading: Icon(
        c.consistencyWarning != null
            ? Icons.warning_amber_rounded
            : (c.consistencyChecked ? Icons.check_circle_outline : Icons.circle_outlined),
        color: c.consistencyWarning != null ? Colors.orange : null,
      ),
      // ĐÃ THÊM: chạm giữ để gán/đổi quyển — chỉ có tác dụng khi truyện đã
      // có ít nhất 1 quyển (nếu chưa, hàm tự hiện gợi ý tạo quyển trước).
      onLongPress: () => _assignChapterVolume(c),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: c)),
      ).then((_) => _load()),
    );
  }

  Widget _buildFlatList() {
    return ListView.builder(
      itemCount: chapters.length,
      itemBuilder: (context, i) => _chapterTile(chapters[i]),
    );
  }

  Widget _buildGroupedByVolume() {
    final byVolume = <String?, List<Chapter>>{};
    for (final c in chapters) {
      byVolume.putIfAbsent(c.volumeId, () => []).add(c);
    }
    for (final list in byVolume.values) {
      list.sort((a, b) => a.number.compareTo(b.number));
    }
    final sections = <Widget>[];
    for (final v in volumes) {
      final inVolume = byVolume[v.id] ?? [];
      if (inVolume.isEmpty) continue; // quyển chưa có chương nào — ẩn khỏi danh sách, vẫn còn trong "Quản lý Quyển"
      sections.add(Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        child: Text(v.title, style: const TextStyle(fontWeight: FontWeight.bold)),
      ));
      sections.addAll(inVolume.map(_chapterTile));
    }
    final unassigned = (byVolume[null] ?? [])..sort((a, b) => a.number.compareTo(b.number));
    if (unassigned.isNotEmpty) {
      sections.add(Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        child: const Text('Chưa gom quyển', style: TextStyle(fontWeight: FontWeight.bold)),
      ));
      sections.addAll(unassigned.map(_chapterTile));
    }
    return ListView(children: sections);
  }
}
