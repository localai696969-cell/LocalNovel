import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/export_service.dart';
import 'chapter_editor_screen.dart';
import 'chapters_batch_generate_screen.dart';
import 'search_screen.dart';

class ChaptersScreen extends StatefulWidget {
  final String novelId;
  final String novelTitle;
  const ChaptersScreen({super.key, required this.novelId, required this.novelTitle});
  @override
  State<ChaptersScreen> createState() => _ChaptersScreenState();
}

class _ChaptersScreenState extends State<ChaptersScreen> {
  final db = DatabaseService.instance;
  List<Chapter> chapters = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant ChaptersScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final list = await db.allChapters(widget.novelId);
    if (!mounted) return;
    setState(() => chapters = list);
  }

  Future<void> _newChapter() async {
    final nextNumber = chapters.isEmpty ? 1 : chapters.first.number + 1;
    final chapter = Chapter(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      number: nextNumber,
      title: 'Chương mới',
      content: '',
    );
    await db.upsertChapter(chapter);
    await _load();
    if (mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: chapter)))
          .then((_) => _load());
    }
  }

  Future<void> _export(String format) async {
    final all = await db.allChaptersAscending(widget.novelId);
    if (all.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa có chương nào để xuất')));
      return;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đang tạo file xuất bản...')));
    }
    try {
      final novel = await db.novelById(widget.novelId);
      final exporter = ExportService();
      final file = switch (format) {
        'epub' => await exporter.exportEpub(
            title: widget.novelTitle,
            author: (novel?.author.trim().isNotEmpty ?? false) ? novel!.author : 'Chưa rõ tác giả',
            chapters: all,
          ),
        'docx' => await exporter.exportDocx(title: widget.novelTitle, chapters: all),
        _ => await exporter.exportTxt(title: widget.novelTitle, chapters: all),
      };
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất bản: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chương (${chapters.length})'),
        actions: [
          IconButton(
            icon: const Icon(Icons.playlist_add_check_outlined),
            tooltip: 'Tạo chương hàng loạt từ outline',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChaptersBatchGenerateScreen(novelId: widget.novelId)),
            ).then((_) => _load()),
          ),
          IconButton(
            icon: const Icon(Icons.search_outlined),
            tooltip: 'Tìm kiếm toàn văn',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => SearchScreen(novelId: widget.novelId)),
            ).then((_) => _load()),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share_outlined),
            onSelected: _export,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'epub', child: Text('Xuất EPUB')),
              PopupMenuItem(value: 'docx', child: Text('Xuất DOCX')),
              PopupMenuItem(value: 'txt', child: Text('Xuất TXT')),
            ],
          ),
        ],
      ),
      body: chapters.isEmpty
          ? const Center(child: Text('Chưa có chương nào. Bấm + để bắt đầu.'))
          : ListView.builder(
              itemCount: chapters.length,
              itemBuilder: (context, i) {
                final c = chapters[i];
                return ListTile(
                  title: Text('Chương ${c.number}: ${c.title}'),
                  subtitle: Text(
                    '${c.wordCount} chữ'
                    '${c.consistencyWarning != null ? ' · có cảnh báo nhất quán' : ''}'
                    // ĐÃ THÊM: hiện rõ chương nào có outline nhưng chưa
                    // viết ("chương mồi" đang chờ) — để biết còn gì cần
                    // xử lý qua "Tạo chương hàng loạt" mà không cần mở
                    // từng chương ra xem.
                    '${(c.outline?.trim().isNotEmpty ?? false) && c.content.trim().isEmpty ? ' · có outline, chưa viết' : ''}',
                  ),
                  leading: Icon(
                    c.consistencyWarning != null
                        ? Icons.warning_amber_rounded
                        : (c.consistencyChecked ? Icons.check_circle_outline : Icons.circle_outlined),
                    color: c.consistencyWarning != null ? Colors.orange : null,
                  ),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: c)),
                  ).then((_) => _load()),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(onPressed: _newChapter, child: const Icon(Icons.add)),
    );
  }
}
