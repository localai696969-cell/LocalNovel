import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/export_service.dart';
import 'chapter_editor_screen.dart';

class ChaptersScreen extends StatefulWidget {
  const ChaptersScreen({super.key});
  @override
  State<ChaptersScreen> createState() => _ChaptersScreenState();
}

class _ChaptersScreenState extends State<ChaptersScreen> {
  final db = DatabaseService.instance;
  List<Chapter> chapters = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await db.allChapters();
    setState(() => chapters = list);
  }

  Future<void> _newChapter() async {
    final nextNumber = chapters.isEmpty ? 1 : chapters.first.number + 1;
    final chapter = Chapter(id: const Uuid().v4(), number: nextNumber, title: 'Chương mới', content: '');
    await db.upsertChapter(chapter);
    await _load();
    if (mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: chapter)))
          .then((_) => _load());
    }
  }

  Future<void> _export(String format) async {
    final all = await db.allChaptersAscending();
    if (all.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa có chương nào để xuất')));
      return;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đang tạo file xuất bản...')));
    }
    try {
      final exporter = ExportService();
      final file = switch (format) {
        'epub' => await exporter.exportEpub(title: 'LocalNovel', author: 'Tác giả', chapters: all),
        'docx' => await exporter.exportDocx(title: 'LocalNovel', chapters: all),
        _ => await exporter.exportTxt(title: 'LocalNovel', chapters: all),
      };
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất bản: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chương (${chapters.length})'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share_outlined),
            onSelected: _export,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'epub', child: Text('Xuất EPUB')),
              PopupMenuItem(value: 'docx', child: Text('Xuất DOCX')),
              PopupMenuItem(value: 'txt', child: Text('Xuất TXT')),
            ],
          ),
        ],
      ),
      body: chapters.isEmpty
          ? const Center(child: Text('Chưa có chương nào. Bấm + để bắt đầu.'))
          : ListView.builder(
              itemCount: chapters.length,
              itemBuilder: (context, i) {
                final c = chapters[i];
                return ListTile(
                  title: Text('Chương ${c.number}: ${c.title}'),
                  subtitle: Text(
                    '${c.wordCount} chữ'
                    '${c.consistencyWarning != null ? ' · có cảnh báo nhất quán' : ''}',
                  ),
                  leading: Icon(
                    c.consistencyWarning != null
                        ? Icons.warning_amber_rounded
                        : (c.consistencyChecked ? Icons.check_circle_outline : Icons.circle_outlined),
                    color: c.consistencyWarning != null ? Colors.orange : null,
                  ),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: c)),
                  ).then((_) => _load()),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(onPressed: _newChapter, child: const Icon(Icons.add)),
    );
  }
}
