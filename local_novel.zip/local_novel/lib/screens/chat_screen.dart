import 'dart:async';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import '../services/settings_service.dart';
import '../services/document_service.dart';
import '../services/export_service.dart';
import '../services/translation_service.dart';
import '../services/web_search_service.dart';
import 'file_browser_screen.dart';

class ChatScreen extends StatefulWidget {
  final String novelId;
  const ChatScreen({super.key, required this.novelId});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final db = DatabaseService.instance;
  List<ChatSession> sessions = [];
  ChatSession? currentSession;
  List<ChatMessageRecord> messages = [];
  final inputCtrl = TextEditingController();
  bool sending = false;
  bool loading = true;
  List<ImportedDocument> documents = [];
  ImportedDocument? attachedDoc;
  int waitingSeconds = 0;
  // ĐÃ THÊM: bật/tắt tìm kiếm web THỦ CÔNG cho tin nhắn — mặc định TẮT,
  // không tự động chạy nền, không làm chậm những tin nhắn không cần tra
  // cứu. Chỉ áp dụng cho phiên chat hiện tại (không lưu lại), người dùng
  // tự bật lại mỗi khi cần — đúng như yêu cầu "khi nào cần thì mới bật".
  bool webSearchEnabled = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void didUpdateWidget(covariant ChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _init();
  }

  Future<void> _init() async {
    var all = await db.allChatSessions(widget.novelId);
    if (all.isEmpty) {
      final first = ChatSession(id: const Uuid().v4(), novelId: widget.novelId, name: 'Cuộc trò chuyện 1');
      await db.upsertChatSession(first);
      all = [first];
    }
    final docs = await db.allDocuments(widget.novelId);
    if (!mounted) return;
    setState(() {
      sessions = all;
      currentSession = all.first;
      documents = docs;
      attachedDoc = null;
    });
    await _loadMessages();
  }

  Future<void> _loadMessages() async {
    if (currentSession == null) return;
    final saved = await db.chatMessagesForSession(currentSession!.id);
    if (!mounted) return;
    setState(() {
      messages = saved;
      loading = false;
    });
  }

  Future<void> _newSession() async {
    final s = ChatSession(id: const Uuid().v4(), novelId: widget.novelId, name: 'Cuộc trò chuyện ${sessions.length + 1}');
    await db.upsertChatSession(s);
    final all = await db.allChatSessions(widget.novelId);
    setState(() {
      sessions = all;
      currentSession = s;
    });
    await _loadMessages();
  }

  Future<void> _switchSession(ChatSession s) async {
    setState(() => currentSession = s);
    await _loadMessages();
  }

  Future<void> _deleteSession(ChatSession s) async {
    await db.deleteChatSession(s.id);
    final all = await db.allChatSessions(widget.novelId);
    if (all.isEmpty) {
      await _init();
      return;
    }
    setState(() {
      sessions = all;
      if (currentSession?.id == s.id) currentSession = all.first;
    });
    await _loadMessages();
  }

  // Xuất toàn bộ cuộc trò chuyện hiện tại ra file — hữu ích khi muốn lưu
  // lại một đoạn tư vấn cốt truyện hoặc kết quả hỏi đáp tài liệu.
  Future<void> _exportSession(String format) async {
    if (currentSession == null || messages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cuộc trò chuyện đang rỗng, chưa có gì để xuất')));
      return;
    }
    try {
      final exporter = ExportService();
      final file = format == 'docx'
          ? await exporter.exportChatSessionDocx(sessionName: currentSession!.name, messages: messages)
          : await exporter.exportChatSessionTxt(sessionName: currentSession!.name, messages: messages);
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất file: $e')));
    }
  }

  Future<void> _showSessionList() async {
    final chosen = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.add),
            title: const Text('Cuộc trò chuyện mới'),
            onTap: () {
              Navigator.pop(context, '__new__');
            },
          ),
          const Divider(height: 1),
          ...sessions.map((s) => ListTile(
                leading: Icon(s.id == currentSession?.id ? Icons.chat_bubble : Icons.chat_bubble_outline),
                title: Text(s.name),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, size: 18),
                  onPressed: () {
                    Navigator.pop(context);
                    _deleteSession(s);
                  },
                ),
                onTap: () => Navigator.pop(context, s.id),
              )),
        ]),
      ),
    );
    if (chosen == '__new__') {
      await _newSession();
    } else if (chosen != null) {
      final s = sessions.firstWhere((x) => x.id == chosen);
      await _switchSession(s);
    }
  }

  Future<void> _send() async {
    final text = inputCtrl.text.trim();
    if (text.isEmpty || sending || currentSession == null) return;
    final sessionId = currentSession!.id;

    final userMsg = ChatMessageRecord(id: const Uuid().v4(), sessionId: sessionId, fromUser: true, text: text);
    await db.upsertChatMessage(userMsg);
    setState(() {
      messages.add(userMsg);
      inputCtrl.clear();
      sending = true;
    });

    final provider = await SettingsService().currentProvider();
    final reply = ChatMessageRecord(id: const Uuid().v4(), sessionId: sessionId, fromUser: false, text: '', providerLabel: provider.name);
    setState(() => messages.add(reply));

    // Model lớn (7-8B) trên điện thoại có thể chỉ đạt 1 token/giây hoặc
    // chậm hơn — không coi "chưa có chữ nào" là lỗi ngay, hiện đồng hồ
    // đếm để người dùng biết app đang chạy thật, không phải bị treo.
    final stopwatch = Stopwatch()..start();
    final ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => waitingSeconds = stopwatch.elapsed.inSeconds);
    });

    try {
      final rag = RagService(
        db,
        await SettingsService().currentEmbeddingService(),
        novelId: widget.novelId,
        contextBudgetChars: await SettingsService().loadRagBudget(),
      );
      var systemPrompt = await rag.buildSystemPrompt(
        userInstruction: 'Trả lời như một biên tập viên tư vấn viết truyện, tham chiếu đúng Story Bible.',
        currentText: text,
      );
      if (attachedDoc != null) {
        final docContext = await DocumentService(db).buildQaContext(attachedDoc!);
        systemPrompt = '$systemPrompt\n\n$docContext';
      }
      // ĐÃ THÊM: chỉ tìm web khi người dùng CHỦ ĐỘNG bật (webSearchEnabled)
      // — không tự động, không chạy ngầm cho tin nhắn không cần. Hiện rõ
      // giai đoạn "Đang tìm kiếm web..." để người dùng biết đang chờ gì,
      // giống cách hiện thị giai đoạn dịch thuật trung gian đã có.
      if (webSearchEnabled) {
        setState(() => reply.text = '🔍 Đang tìm kiếm web...');
        try {
          final results = await WebSearchService().search(text);
          final searchContext = WebSearchService().formatForPrompt(results, text);
          systemPrompt = '$systemPrompt\n\n$searchContext';
          setState(() => reply.text = '');
        } catch (e) {
          setState(() => reply.text = '⚠️ Tìm kiếm web lỗi ($e) — tiếp tục trả lời không có kết quả web...');
        }
      }
      final genCfg = await SettingsService().loadGenerationConfig();
      final translationOn = await TranslationService(SettingsService()).isEnabled;
      if (translationOn) {
        // Dịch thuật trung gian bật: không streaming từng chữ được (cần
        // dịch xong toàn bộ mới trả về), hiện tiến trình theo từng giai
        // đoạn qua stageLabel thay vì chữ chạy dần.
        final result = await TranslationService(SettingsService()).generateWithOptionalTranslation(
          mainProvider: provider,
          systemPrompt: systemPrompt,
          userPrompt: text,
          temperature: genCfg.temperature,
          maxTokens: genCfg.maxNewTokens,
          onStage: (stage) => setState(() => reply.text = '⏳ $stage'),
        );
        setState(() => reply.text = result);
      } else {
        final stream = provider.generateStream(
          systemPrompt: systemPrompt,
          userPrompt: text,
          temperature: genCfg.temperature,
          maxTokens: genCfg.maxNewTokens,
          topP: genCfg.topP,
          topK: genCfg.topK,
          repetitionPenalty: genCfg.repetitionPenalty,
          // ĐÃ THÊM: khung chat là hội thoại nhiều lượt thật sự (mỗi tin
          // nhắn nối tiếp lượt trước trong cùng phiên) — bật reuse_kv để
          // MNN không phải tính lại KV-cache cho phần system prompt +
          // lịch sử đã xử lý ở các lượt trước, giảm thời gian chờ từ lượt
          // thứ 2 trở đi. Xem giải thích đầy đủ ở ai_provider.dart.
          reuseKv: true,
        );
        await for (final chunk in stream) {
          setState(() => reply.text += chunk);
        }
      }
      if (reply.text.isEmpty) {
        reply.text = '(Model trả lời rỗng — thử lại hoặc kiểm tra model có phù hợp không)';
      }
    } catch (e) {
      setState(() => reply.text = 'Lỗi sau ${stopwatch.elapsed.inSeconds}s: $e');
    } finally {
      ticker.cancel();
      waitingSeconds = 0;
      await db.upsertChatMessage(reply);
      setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(currentSession?.name ?? 'Trợ lý AI'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share_outlined),
            tooltip: 'Xuất cuộc trò chuyện này',
            onSelected: _exportSession,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'txt', child: Text('Xuất TXT')),
              PopupMenuItem(value: 'docx', child: Text('Xuất DOCX')),
            ],
          ),
          IconButton(
            onPressed: () async {
              // ĐÃ SỬA: trước đây kẹp giấy trong khung CHAT chỉ hiện danh
              // sách tài liệu ĐÃ import từ trước (qua tab "Tài liệu"
              // riêng) — nếu chưa import gì, danh sách trống, trông như
              // "không dùng được". Giờ thêm lựa chọn "Nhập tài liệu mới"
              // ngay trong khung chat, dùng lại đúng FileBrowserScreen
              // (dart:io tự viết, không dùng file_picker) và
              // DocumentService đã có sẵn — không cần rời tab Chat.
              final chosen = await showModalBottomSheet<ImportedDocument?>(
                context: context,
                builder: (context) => SafeArea(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    ListTile(
                      leading: const Icon(Icons.link_off),
                      title: const Text('Không tham chiếu tài liệu nào'),
                      onTap: () => Navigator.pop(context, null),
                    ),
                    ListTile(
                      leading: const Icon(Icons.folder_open_outlined),
                      title: const Text('Nhập tài liệu mới (.txt, .md)...'),
                      onTap: () async {
                        Navigator.pop(context, null);
                        final pickedPath = await Navigator.push<String>(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const FileBrowserScreen(allowedExtensions: ['txt', 'md']),
                          ),
                        );
                        if (pickedPath == null || !mounted) return;
                        try {
                          final newDoc = await DocumentService(db).importFromPath(pickedPath, novelId: widget.novelId);
                          if (!mounted) return;
                          final refreshedDocs = await db.allDocuments(widget.novelId);
                          setState(() {
                            documents = refreshedDocs;
                            attachedDoc = newDoc;
                          });
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi nhập tài liệu: $e')));
                          }
                        }
                      },
                    ),
                    if (documents.isNotEmpty) const Divider(height: 1),
                    ...documents.map((d) => ListTile(
                          leading: const Icon(Icons.description_outlined),
                          title: Text(d.name),
                          onTap: () => Navigator.pop(context, d),
                        )),
                  ]),
                ),
              );
              setState(() => attachedDoc = chosen);
            },
            icon: Icon(attachedDoc != null ? Icons.attach_file : Icons.attach_file_outlined),
            tooltip: 'Tham chiếu tài liệu',
          ),
          IconButton(
            onPressed: () => setState(() => webSearchEnabled = !webSearchEnabled),
            icon: Icon(webSearchEnabled ? Icons.public : Icons.public_outlined,
                color: webSearchEnabled ? Theme.of(context).colorScheme.primary : null),
            tooltip: webSearchEnabled
                ? 'Tìm kiếm web: ĐANG BẬT (tắt để trả lời nhanh hơn, không cần tra cứu)'
                : 'Tìm kiếm web: đang tắt (bật khi cần tra cứu thông tin mới)',
          ),
          IconButton(onPressed: _showSessionList, icon: const Icon(Icons.forum_outlined), tooltip: 'Danh sách cuộc trò chuyện'),
          IconButton(onPressed: _newSession, icon: const Icon(Icons.add_comment_outlined), tooltip: 'Cuộc trò chuyện mới'),
        ],
        bottom: attachedDoc == null
            ? null
            : PreferredSize(
                preferredSize: const Size.fromHeight(32),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Chip(
                    label: Text('Đang tham chiếu: ${attachedDoc!.name}', style: const TextStyle(fontSize: 11)),
                    visualDensity: VisualDensity.compact,
                    onDeleted: () => setState(() => attachedDoc = null),
                  ),
                ),
              ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: messages.isEmpty
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                              'Hỏi trợ lý về truyện của bạn. Có thể tạo nhiều cuộc trò chuyện riêng '
                              '(icon dấu + trên) và đổi model AI bất kỳ lúc nào ở Cài đặt.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: messages.length,
                          itemBuilder: (context, i) {
                            final m = messages[i];
                            return Align(
                              alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                              child: Column(
                                crossAxisAlignment: m.fromUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.symmetric(vertical: 4),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                                    decoration: BoxDecoration(
                                      color: m.fromUser
                                          ? Theme.of(context).colorScheme.primaryContainer
                                          : Colors.grey.shade100,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Text(
                                      m.text.isEmpty
                                          ? (sending && i == messages.length - 1
                                              ? 'Đang chạy... ${waitingSeconds}s (model lớn có thể mất vài phút)'
                                              : '...')
                                          : m.text,
                                      // SUA (2026-07-30): truoc day khong chi
                                      // dinh mau chu, nen chu tu dong lay mau
                                      // mac dinh cua theme (sang mau vi app
                                      // dung theme toi) — chu sang tren nen
                                      // xam nhat (grey.shade100) gan nhu
                                      // khong doc duoc. Chi dinh ro mau
                                      // tuong phan cho tung loai khung chat.
                                      style: TextStyle(
                                        color: m.fromUser
                                            ? Theme.of(context).colorScheme.onPrimaryContainer
                                            : Colors.black87,
                                      ),
                                    ),
                                  ),
                                  if (!m.fromUser && m.providerLabel != null)
                                    Padding(
                                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                                      child: Text(
                                        m.providerLabel!,
                                        style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(children: [
                      Expanded(
                        child: TextField(
                          controller: inputCtrl,
                          decoration: const InputDecoration(hintText: 'Hỏi trợ lý về truyện của bạn...'),
                          onSubmitted: (_) => _send(),
                        ),
                      ),
                      IconButton(onPressed: _send, icon: const Icon(Icons.send)),
                    ]),
                  ),
                ),
              ],
            ),
    );
  }
}
