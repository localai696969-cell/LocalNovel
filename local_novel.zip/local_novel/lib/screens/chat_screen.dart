import 'dart:async';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import '../services/settings_service.dart';
import '../services/document_service.dart';
import '../services/export_service.dart';
import '../services/translation_service.dart';
import '../services/providers/local_provider.dart';
import '../services/web_search_service.dart';
import '../services/background_task_manager.dart';
import '../services/text_scale_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'file_browser_screen.dart';
import '../services/bible_extraction_service.dart';
import 'bible_extraction_review_screen.dart';

class ChatScreen extends StatefulWidget {
  final String novelId;
  const ChatScreen({super.key, required this.novelId});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final db = DatabaseService.instance;
  List<ChatSession> sessions = [];
  ChatSession? currentSession;
  List<ChatMessageRecord> messages = [];
  final inputCtrl = TextEditingController();
  bool sending = false;
  // ĐÃ THÊM: cờ huỷ giữa chừng thật — trước đây nút "X" ở màn "Tác vụ nền"
  // gọi `requestCancel()` nhưng KHÔNG có tác dụng gì với chat local đang
  // stream (xem `background_task_manager.dart submitAndWait`). Bật cờ này
  // trong `onCancelRequested`, kiểm tra định kỳ trong `isCancelled` truyền
  // xuống `generateWithOptionalTranslation`.
  bool cancelRequested = false;
  // ĐÃ THÊM: theo dõi checkpoint lưu tăng dần trong lúc chat đang stream —
  // xem giải thích đầy đủ ở `_maybeCheckpointReply()`.
  int _lastCheckpointedLength = 0;
  final Stopwatch _checkpointStopwatch = Stopwatch();
  // ĐÃ THÊM (theo phản hồi người dùng: "trong khung chat hình như có
  // hardcode prompt cố định, có thể bỏ được không" — đúng, MỌI tin nhắn
  // chat trước đây đều bị ép khung "Bạn là trợ lý viết tiểu thuyết dài
  // kỳ... Trả lời như một biên tập viên tư vấn viết truyện" (xem
  // `rag_service.dart buildSystemPrompt()`), dù chỉ gõ "alo"/"hello" xã
  // giao không liên quan gì tới viết truyện. Thêm cờ bật/tắt — TẮT thì bỏ
  // hẳn khung persona này, chat như trợ lý AI thông thường (vẫn giữ được
  // tài liệu đính kèm/tìm web nếu người dùng tự bật, chỉ bỏ riêng phần ép
  // "vai trò biên tập viên truyện + Story Bible"). Lưu theo TỪNG TRUYỆN
  // (khoá SharedPreferences có `widget.novelId`) — hợp lý vì có thể truyện
  // này người dùng luôn muốn bàn chuyện viết, truyện khác chỉ dùng chat
  // chơi/thử model, không nên dùng chung 1 cờ toàn app.
  bool useNovelPersona = true;
  bool loading = true;
  List<ImportedDocument> documents = [];
  ImportedDocument? attachedDoc;
  int waitingSeconds = 0;
  // ĐÃ THÊM: id của nhiệm vụ hiện tại trong BackgroundTaskManager (null =
  // chưa nộp/đã xong) — dùng để tra trạng thái queued/running mỗi giây
  // (tái dùng đúng `ticker` đã có sẵn cho đồng hồ đếm giây, không thêm
  // Timer mới) và hiện rõ "đang chờ tác vụ khác" thay vì im lặng như
  // trước — theo đúng yêu cầu người dùng.
  String? currentTaskId;
  // ĐÃ THÊM (theo yêu cầu người dùng: "phần chat khi tắt dịch thuật, có
  // lựa chọn bật khi chat với model không hiểu tiếng Việt không"): trước
  // đây `isEnabled` chỉ đọc đúng 1 cờ TOÀN CỤC (Cài đặt → Dịch thuật trung
  // gian) — muốn chat qua dịch thuật phải vào Cài đặt bật lên, ảnh hưởng
  // LUÔN cả Viết tiếp/Đắp thịt/Tạo hàng loạt, không có cách bật RIÊNG cho
  // 1 phiên chat đang thử 1 model không rành tiếng Việt.
  // null = theo đúng cài đặt chung (mặc định — không đổi hành vi cũ).
  // true = LUÔN bật dịch thuật cho phiên chat này, BẤT KỂ cài đặt chung.
  // false = LUÔN tắt, kể cả khi cài đặt chung đang bật.
  // Chỉ áp dụng cho phiên chat hiện tại, không lưu lại — cùng triết lý với
  // `webSearchEnabled` phía trên (bật/tắt theo nhu cầu từng lúc, không cần
  // vào Cài đặt đổi qua đổi lại).
  bool? sessionTranslationOverride;
  // ĐÃ THÊM: bật/tắt tìm kiếm web THỦ CÔNG cho tin nhắn — mặc định TẮT,
  // không tự động chạy nền, không làm chậm những tin nhắn không cần tra
  // cứu. Chỉ áp dụng cho phiên chat hiện tại (không lưu lại), người dùng
  // tự bật lại mỗi khi cần — đúng như yêu cầu "khi nào cần thì mới bật".
  bool webSearchEnabled = false;

  @override
  void initState() {
    super.initState();
    _init();
    _loadUseNovelPersona();
  }

  @override
  void didUpdateWidget(covariant ChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _init();
  }

  Future<void> _init() async {
    var all = await db.allChatSessions(widget.novelId);
    if (all.isEmpty) {
      final first = ChatSession(id: const Uuid().v4(), novelId: widget.novelId, name: 'Cuộc trò chuyện 1');
      await db.upsertChatSession(first);
      all = [first];
    }
    final docs = await db.allDocuments(widget.novelId);
    if (!mounted) return;
    setState(() {
      sessions = all;
      currentSession = all.first;
      documents = docs;
      attachedDoc = null;
    });
    await _loadMessages();
  }

  Future<void> _loadMessages() async {
    if (currentSession == null) return;
    final saved = await db.chatMessagesForSession(currentSession!.id);
    if (!mounted) return;
    setState(() {
      messages = saved;
      loading = false;
    });
  }

  String get _useNovelPersonaKey => 'chat_use_novel_persona_${widget.novelId}';

  Future<void> _loadUseNovelPersona() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getBool(_useNovelPersonaKey);
    if (saved != null && mounted) setState(() => useNovelPersona = saved);
  }

  Future<void> _toggleUseNovelPersona() async {
    final next = !useNovelPersona;
    setState(() => useNovelPersona = next);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_useNovelPersonaKey, next);
  }

  Future<void> _newSession() async {
    final s = ChatSession(id: const Uuid().v4(), novelId: widget.novelId, name: 'Cuộc trò chuyện ${sessions.length + 1}');
    await db.upsertChatSession(s);
    final all = await db.allChatSessions(widget.novelId);
    setState(() {
      sessions = all;
      currentSession = s;
    });
    await _loadMessages();
  }

  Future<void> _switchSession(ChatSession s) async {
    setState(() => currentSession = s);
    await _loadMessages();
  }

  Future<void> _deleteSession(ChatSession s) async {
    await db.deleteChatSession(s.id);
    final all = await db.allChatSessions(widget.novelId);
    if (all.isEmpty) {
      await _init();
      return;
    }
    setState(() {
      sessions = all;
      if (currentSession?.id == s.id) currentSession = all.first;
    });
    await _loadMessages();
  }

  // Xuất toàn bộ cuộc trò chuyện hiện tại ra file — hữu ích khi muốn lưu
  // lại một đoạn tư vấn cốt truyện hoặc kết quả hỏi đáp tài liệu.
  Future<void> _exportSession(String format) async {
    if (currentSession == null || messages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cuộc trò chuyện đang rỗng, chưa có gì để xuất')));
      return;
    }
    try {
      final exporter = ExportService();
      final file = format == 'docx'
          ? await exporter.exportChatSessionDocx(sessionName: currentSession!.name, messages: messages)
          : await exporter.exportChatSessionTxt(sessionName: currentSession!.name, messages: messages);
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất file: $e')));
    }
  }

  Future<void> _showSessionList() async {
    final chosen = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.add),
            title: const Text('Cuộc trò chuyện mới'),
            onTap: () {
              Navigator.pop(context, '__new__');
            },
          ),
          const Divider(height: 1),
          ...sessions.map((s) => ListTile(
                leading: Icon(s.id == currentSession?.id ? Icons.chat_bubble : Icons.chat_bubble_outline),
                title: Text(s.name),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, size: 18),
                  onPressed: () {
                    Navigator.pop(context);
                    _deleteSession(s);
                  },
                ),
                onTap: () => Navigator.pop(context, s.id),
              )),
        ]),
      ),
    );
    if (chosen == '__new__') {
      await _newSession();
    } else if (chosen != null) {
      final s = sessions.firstWhere((x) => x.id == chosen);
      await _switchSession(s);
    }
  }

  // ĐÃ THÊM — mục BJ, 2026-09-20: trích nội dung 1 tin nhắn trợ lý thành đề
  // xuất Story Bible. Lấy provider HIỆN TẠI tươi mới (không dùng lại biến
  // đã lưu từ lúc `_send()` chạy trước đó — người dùng có thể đã đổi
  // model/provider giữa chừng) — cùng cách `_send()` tự lấy provider mỗi
  // lần gọi.
  Future<void> _extractToBible(String messageText) async {
    final provider = await SettingsService().currentProvider(widget.novelId);
    if (!mounted) return;
    // Dùng dialog loading đơn giản — tác vụ trích xuất là 1 lệnh generate()
    // NGẮN (maxTokens=1024, temperature thấp), không cần qua
    // BackgroundTaskManager như tác vụ tạo chương dài — nhưng vẫn nên chặn
    // thao tác khác trong lúc chờ để tránh người dùng bấm nhiều lần.
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Row(children: [
          CircularProgressIndicator(),
          SizedBox(width: 16),
          Expanded(child: Text('Đang trích xuất dữ kiện...')),
        ]),
      ),
    );
    // ĐÃ SỬA — theo phản hồi người dùng ("giới hạn tại sao không khắc
    // phục"): đi qua `extractFromChunks` (dù chat chỉ có 1 đoạn duy nhất)
    // thay vì gọi thẳng `extractFromText` — để CÓ ĐƯỢC cảnh báo trùng lặp
    // với Bible đã có sẵn + cảnh báo grounding, không chỉ riêng tài liệu
    // dài mới cần 2 lớp cảnh báo này.
    BibleExtractionResult result;
    String? error;
    try {
      result = await BibleExtractionService().extractFromChunks([messageText], provider: provider, novelId: widget.novelId);
    } catch (e) {
      error = '$e';
      result = BibleExtractionResult(entries: [], totalChunks: 1, failedChunkCount: 1);
    }
    if (!mounted) return;
    Navigator.of(context).pop(); // đóng dialog loading
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không trích xuất được: $error')));
      return;
    }
    if (!mounted) return;
    final addedCount = await Navigator.of(context).push<int>(MaterialPageRoute(
      builder: (context) => BibleExtractionReviewScreen(
        novelId: widget.novelId,
        entries: result.entries,
        sourceLabel: 'từ đoạn chat vừa rồi',
        totalChunks: result.totalChunks,
        failedChunkCount: result.failedChunkCount,
      ),
    ));
    if (addedCount != null && addedCount > 0 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Đã thêm $addedCount mục vào Story Bible.')));
    }
  }

  Future<void> _send() async {
    final text = inputCtrl.text.trim();
    if (text.isEmpty || sending || currentSession == null) return;
    final sessionId = currentSession!.id;

    // ĐÃ SỬA (lỗi CRASH THẬT phát hiện từ log runtime — SIGSEGV sâu trong
    // MNN khi 2 lệnh generate() chạy chồng lên nhau trên CÙNG 1 slot model):
    // TRƯỚC ĐÂY `sending = true` chỉ được đặt SAU dòng `await db.upsertChatMessage(...)`
    // bên dưới — Dart chạy đơn luồng nhưng các lệnh `await` VẪN nhường lại
    // vòng lặp sự kiện, nên nếu người dùng bấm gửi 2-3 lần thật nhanh
    // (trong đúng khoảng hở vài chục mili giây đó), MỌI lần bấm đều đọc
    // thấy `sending == false` (chưa kịp cập nhật) và đều lọt qua điều kiện
    // chặn ở dòng trên — dẫn tới NHIỀU lệnh `currentProvider().generate*`
    // cùng gọi xuống model native đồng thời, gây corrupt session/KV-cache
    // và crash cứng cả app (không phải lỗi Dart bắt được, sập cả tiến
    // trình — xem log "SIGSEGV" + "TU CHOI vi phat hien lenh generate KHAC
    // dang chay dong thoi"). Đặt `sending = true` NGAY TẠI ĐÂY — trước bất
    // kỳ `await` nào — đóng kín khoảng hở race condition này hoàn toàn.
    setState(() {
      sending = true;
      cancelRequested = false;
    });

    final userMsg = ChatMessageRecord(id: const Uuid().v4(), sessionId: sessionId, fromUser: true, text: text);
    await db.upsertChatMessage(userMsg);
    setState(() {
      messages.add(userMsg);
      inputCtrl.clear();
    });

    final provider = await SettingsService().currentProvider(widget.novelId);
    final reply = ChatMessageRecord(id: const Uuid().v4(), sessionId: sessionId, fromUser: false, text: '', providerLabel: provider.name);
    setState(() => messages.add(reply));
    _lastCheckpointedLength = 0;
    _checkpointStopwatch
      ..reset()
      ..start();

    // Model lớn (7-8B) trên điện thoại có thể chỉ đạt 1 token/giây hoặc
    // chậm hơn — không coi "chưa có chữ nào" là lỗi ngay, hiện đồng hồ
    // đếm để người dùng biết app đang chạy thật, không phải bị treo.
    final stopwatch = Stopwatch()..start();
    // ĐÃ SỬA: ticker giờ CŨNG kiểm tra trạng thái nhiệm vụ trong
    // BackgroundTaskManager mỗi giây — nếu đang "queued" (xếp hàng chờ 1
    // tác vụ AI khác chạy trước, vd model local đang bận ở màn khác),
    // hiện rõ "⏳ Đang chờ tác vụ khác..." thay vì để người dùng tưởng bị
    // treo. Đúng yêu cầu người dùng: không im lặng chờ nữa.
    final ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        waitingSeconds = stopwatch.elapsed.inSeconds;
        if (currentTaskId != null && BackgroundTaskManager.instance.statusOf(currentTaskId!) == TaskStatus.queued) {
          final ahead = BackgroundTaskManager.instance.queuedAheadOf(currentTaskId!);
          reply.text = ahead > 0
              ? '⏳ Đang chờ — phía trước còn $ahead tác vụ AI khác đang chạy...'
              : '⏳ Đang chờ tác vụ AI khác chạy xong...';
        }
      });
    });

    try {
      final rag = RagService(
        db,
        await SettingsService().currentEmbeddingService(),
        novelId: widget.novelId,
        contextBudgetChars: await SettingsService().loadRagBudget(widget.novelId),
      );
      var systemPrompt = useNovelPersona
          ? await rag.buildSystemPrompt(
              userInstruction: 'Trả lời như một biên tập viên tư vấn viết truyện, tham chiếu đúng Story Bible.',
              currentText: text,
            )
          // ĐÃ THÊM: nhánh TẮT persona — bỏ hẳn khung "biên tập viên viết
          // truyện + Story Bible", chat như trợ lý AI thông thường. Không
          // gọi `rag.buildSystemPrompt()` ở nhánh này vì hàm đó LUÔN ép
          // khung persona cố định vào — không có tham số nào để tắt riêng
          // phần đó mà giữ lại RAG, nên đơn giản nhất là bỏ qua toàn bộ.
          : '';
      if (attachedDoc != null) {
        final docContext = await DocumentService(db).buildQaContext(attachedDoc!);
        systemPrompt = '$systemPrompt\n\n$docContext';
      }
      // ĐÃ THÊM: chỉ tìm web khi người dùng CHỦ ĐỘNG bật (webSearchEnabled)
      // — không tự động, không chạy ngầm cho tin nhắn không cần. Hiện rõ
      // giai đoạn "Đang tìm kiếm web..." để người dùng biết đang chờ gì,
      // giống cách hiện thị giai đoạn dịch thuật trung gian đã có.
      if (webSearchEnabled) {
        setState(() => reply.text = '🔍 Đang tìm kiếm web...');
        try {
          final results = await WebSearchService().search(text);
          final searchContext = WebSearchService().formatForPrompt(results, text);
          systemPrompt = '$systemPrompt\n\n$searchContext';
          setState(() => reply.text = '');
        } catch (e) {
          setState(() => reply.text = '⚠️ Tìm kiếm web lỗi ($e) — tiếp tục trả lời không có kết quả web...');
        }
      }
      final genCfg = await SettingsService().loadGenerationConfig(widget.novelId);
      final globalTranslationOn = await TranslationService(SettingsService(), novelId: widget.novelId).isEnabled;
      // ĐÃ SỬA: áp dụng override riêng cho phiên chat này nếu người dùng
      // đã bật/tắt qua nút trên AppBar (xem `sessionTranslationOverride`).
      final translationOn = sessionTranslationOverride ?? globalTranslationOn;

      // ĐÃ SỬA (theo yêu cầu người dùng: mọi nhiệm vụ AI đi qua chung 1
      // hàng đợi, không riêng tạo chương hàng loạt): phần sinh AI thật sự
      // (dịch thuật trung gian HOẶC streaming trực tiếp) giờ nộp qua
      // BackgroundTaskManager.submitAndWait() thay vì gọi thẳng — để:
      //   - Tôn trọng đúng giới hạn đồng thời theo provider (local = 1,
      //     tránh đúng crash mục 5.67; remote = theo cấu hình người dùng).
      //   - Hiện được trạng thái "đang chờ" thật (qua currentTaskId +
      //     ticker ở trên) thay vì im lặng chờ như trước.
      // beginPipeline/endPipeline VẪN giữ nguyên phạm vi bọc như cũ (toàn
      // bộ khối generate), chỉ chuyển vào bên trong closure `run` — chỉ
      // khác là giờ Foreground Service bắt đầu ĐÚNG LÚC nhiệm vụ THỰC SỰ
      // chạy (không phải lúc còn đang xếp hàng chờ).
      await BackgroundTaskManager.instance.submitAndWait<void>(
        label: 'Chat: ${text.length > 30 ? '${text.substring(0, 30)}...' : text}',
        category: 'chat',
        isLocalProvider: provider is LocalLlamaProvider,
        onSubmitted: (id) => currentTaskId = id,
        onCancelRequested: () => cancelRequested = true,
        run: () async {
          bool pipelineStarted = false;
          try {
            await LocalLlamaProvider.beginPipeline('💬 Chat đang xử lý...');
            pipelineStarted = true;
          } catch (_) {
            // Không làm cả chức năng chat bị kẹt nếu gọi pipeline thất bại
            // (ví dụ: chưa chọn model local, đang dùng API cloud).
          }
          try {
            // ĐÃ SỬA (theo phản hồi người dùng — bản trước tự cho rằng dịch
            // thuật bật thì "không streaming được" là SAI, xem giải thích
            // đầy đủ ở `TranslationService.translate()`): giờ gọi thẳng
            // `generateWithOptionalTranslation` với `onChunk` cho CẢ 2
            // trường hợp bật/tắt dịch thuật — hàm đó tự chọn đúng cách
            // stream ở từng trường hợp, không cần tự rẽ nhánh ở đây nữa.
            final result =
                await TranslationService(SettingsService(), novelId: widget.novelId).generateWithOptionalTranslation(
              mainProvider: provider,
              systemPrompt: systemPrompt,
              userPrompt: text,
              temperature: genCfg.temperature,
              maxTokens: genCfg.maxNewTokens,
              topP: genCfg.topP,
              topK: genCfg.topK,
              repetitionPenalty: genCfg.repetitionPenalty,
              onStage: (stage) {
                // Chỉ có ý nghĩa ở 2 giai đoạn DỊCH (không stream được) —
                // giai đoạn "Đang sinh văn bản..." đã có onChunk lo, gán đè
                // ở đây vô hại vì onChunk sẽ ghi đè ngay chunk đầu tiên.
                if (mounted && translationOn) setState(() => reply.text = '⏳ $stage');
              },
              onChunk: (textSoFar) {
                if (mounted) setState(() => reply.text = textSoFar);
                // ĐÃ THÊM (theo yêu cầu người dùng: "có cách nào làm cho nó
                // không mất được không" — trường hợp force-stop app THẲNG,
                // bỏ qua cả PopScope): trước đây `reply` CHỈ được ghi xuống
                // máy đúng 1 lần duy nhất ở `finally` cuối `_send()` — force
                // kill giữa chừng thì mất sạch, không có cách nào cứu được vì
                // dữ liệu chưa từng chạm tới ổ đĩa. Giờ tự lưu theo NGƯỠNG
                // (throttle) NGAY TRONG LÚC đang stream — không lưu MỖI
                // token (quá tốn, ghi SQLite hàng chục lần/giây không cần
                // thiết), chỉ lưu khi đã có thêm ĐỦ NHIỀU chữ mới (200 ký
                // tự) HOẶC đã đủ lâu (2 giây) kể từ lần lưu gần nhất — cân
                // bằng giữa "mất ít nhất có thể" và "không ghi ổ đĩa liên
                // tục". Kết quả: force-stop giữa chừng vẫn mất phần rất mới
                // (tối đa ~200 ký tự/2 giây cuối), nhưng không còn mất TOÀN
                // BỘ như trước.
                _maybeCheckpointReply(reply);
              },
              isCancelled: () => cancelRequested,
            );
            if (mounted) setState(() => reply.text = result);
            if (cancelRequested && reply.text.isNotEmpty) {
              reply.text = '${reply.text}\n\n⏹️ (Đã dừng theo yêu cầu người dùng)';
            }
            if (reply.text.isEmpty) {
              reply.text = cancelRequested
                  ? '⏹️ (Đã dừng theo yêu cầu người dùng trước khi có chữ nào)'
                  : '(Model trả lời rỗng — thử lại hoặc kiểm tra model có phù hợp không)';
            }
          } finally {
            if (pipelineStarted) {
              try {
                await LocalLlamaProvider.endPipeline();
              } catch (_) {}
            }
          }
        },
      );
    } catch (e) {
      // ĐÃ SỬA (liên quan câu hỏi người dùng về mất nội dung khi GPU remote
      // sập giữa chừng): trước đây `setState(() => reply.text = 'Lỗi...')`
      // GHI ĐÈ hoàn toàn phần chữ đã stream về được trước khi lỗi xảy ra
      // (vd server treo/đứt kết nối sau khi đã gửi được vài trăm từ) — mất
      // sạch phần đó dù thực tế đã nhận được. Giờ GIỮ LẠI `reply.text` hiện
      // có (nếu có), chỉ nối thêm thông báo lỗi vào cuối — người dùng vẫn
      // thấy được phần chat đã sinh dở dang thay vì mất trắng.
      final partial = reply.text.trim();
      final errorNote = 'Lỗi sau ${stopwatch.elapsed.inSeconds}s: $e';
      setState(() => reply.text = partial.isEmpty ? errorNote : '$partial\n\n⚠️ $errorNote');
    } finally {
      ticker.cancel();
      waitingSeconds = 0;
      currentTaskId = null;
      await db.upsertChatMessage(reply);
      setState(() => sending = false);
    }
  }

  // ĐÃ THÊM: lưu `reply` xuống DB nếu đã đủ ngưỡng (200 ký tự mới HOẶC 2
  // giây) kể từ lần lưu gần nhất — cố tình "fire and forget" (không
  // `await`), vì đây chạy TRONG callback đồng bộ `onChunk` của luồng
  // stream: nếu `await` ở đây sẽ làm chậm việc nhận token tiếp theo một
  // cách không cần thiết (ghi SQLite vài chục ms mỗi lần, không đáng phải
  // chặn UI/stream). Rủi ro duy nhất khi không `await`: nếu app bị kill
  // ĐÚNG NGAY GIỮA LÚC ghi (cực hiếm, cửa sổ chỉ vài ms) thì lần ghi đó
  // có thể không kịp hoàn tất — chấp nhận được, vì mục tiêu là "mất ít
  // nhất có thể", không phải "không bao giờ mất 1 ký tự nào" (điều đó cần
  // transaction đồng bộ mỗi token, không thực tế cho model sinh hàng trăm
  // token).
  void _maybeCheckpointReply(ChatMessageRecord reply) {
    final newChars = reply.text.length - _lastCheckpointedLength;
    final elapsed = _checkpointStopwatch.elapsed;
    if (newChars < 200 && elapsed < const Duration(seconds: 2)) return;
    _lastCheckpointedLength = reply.text.length;
    _checkpointStopwatch
      ..reset()
      ..start();
    unawaited(db.upsertChatMessage(reply));
  }

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM (2026-08-31 — theo phản hồi người dùng thật: bấm back giữa
    // lúc đang sinh văn bản khiến lệnh generate() native chạy tiếp NGẦM,
    // không ai biết, rồi lần chat SAU phải tự nạp lại model thủ công mới
    // dùng được — đúng chỗ bị bỏ sót so với các màn hình khác đã làm
    // đúng từ trước, xem `chapter_editor_screen.dart`/`document_screen.dart`,
    // cùng dùng PopScope chặn back lúc đang bận): trước đây `chat_screen.dart`
    // KHÔNG có PopScope nào cả — cử chỉ back (đặc biệt "vuốt back dự đoán"
    // Android 13+) thoát thẳng khỏi màn hình, HUỶ WIDGET, nhưng vòng lặp
    // `await for` trong `_send()` (hàm async, KHÔNG gắn với vòng đời
    // widget) vẫn tiếp tục chạy tới hết — không hề dừng, chỉ là không ai
    // nhìn thấy kết quả nữa. Vì vòng lặp đó KHÔNG BAO GIỜ break sớm, cơ
    // chế dọn dẹp có sẵn ở `local_provider.dart` (gọi `cancelGenerate()`
    // khi consumer huỷ giữa chừng) cũng không bao giờ được kích hoạt —
    // lệnh cứ chạy tự nhiên tới khi xong thật (có thể rất lâu với model
    // chậm), khiến slot bị coi là "đang bận" cho tới lúc đó.
    return PopScope(
      canPop: !sending,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('AI đang sinh văn bản — đợi xong hoặc huỷ trước khi thoát để không bị kẹt lần chat sau.'),
          action: SnackBarAction(
            label: 'Huỷ & thoát',
            onPressed: () {
              // Dùng ĐÚNG cơ chế huỷ có sẵn (giống hệt nút dừng đang có)
              // — đặt cancelRequested=true để vòng lặp `await for` trong
              // `_send()` tự break ở lần kiểm tra `isCancelled` tiếp
              // theo, kích hoạt đúng cơ chế dọn dẹp/gọi cancelGenerate()
              // native đã có sẵn — KHÔNG bỏ mặc lệnh chạy ngầm vô chủ
              // như trước.
              cancelRequested = true;
              Navigator.of(context).pop();
            },
          ),
        ));
      },
      child: Scaffold(
      appBar: AppBar(
        title: Text(currentSession?.name ?? 'Trợ lý AI'),
        actions: [
          // ĐÃ THÊM (theo phản hồi người dùng: "phần tăng kích cỡ chữ ở
          // màn hình khung chat sao không thấy" — trước đây chỉ có ở màn
          // "Truyện của bạn", không có đường quay lại đó từ trong 1
          // truyện đang mở mà không thoát cả truyện ra). Dùng chung đúng
          // 1 hàm `showTextScaleDialog()` — sửa cỡ chữ ở đây có tác dụng
          // NGAY LẬP TỨC cho MỌI màn hình khác trong app luôn, không chỉ
          // riêng màn chat này.
          IconButton(
            icon: const Icon(Icons.text_fields),
            tooltip: 'Cỡ chữ (áp dụng cho mọi màn hình)',
            onPressed: () => showTextScaleDialog(context),
          ),
          // ĐÃ THÊM: bật/tắt khung "biên tập viên viết truyện + Story
          // Bible" bị ép cứng vào mọi tin nhắn trước đây — xem giải thích
          // đầy đủ ở khai báo `useNovelPersona` phía trên.
          IconButton(
            icon: Icon(useNovelPersona ? Icons.auto_stories : Icons.auto_stories_outlined),
            tooltip: useNovelPersona
                ? 'Đang BẬT vai trò "biên tập viên viết truyện" cho mọi tin nhắn — bấm để tắt, chat tự do'
                : 'Đang TẮT vai trò cố định — chat tự do như trợ lý AI thường. Bấm để bật lại',
            onPressed: _toggleUseNovelPersona,
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share_outlined),
            tooltip: 'Xuất cuộc trò chuyện này',
            onSelected: _exportSession,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'txt', child: Text('Xuất TXT')),
              PopupMenuItem(value: 'docx', child: Text('Xuất DOCX')),
            ],
          ),
          IconButton(
            onPressed: () async {
              // ĐÃ SỬA: trước đây kẹp giấy trong khung CHAT chỉ hiện danh
              // sách tài liệu ĐÃ import từ trước (qua tab "Tài liệu"
              // riêng) — nếu chưa import gì, danh sách trống, trông như
              // "không dùng được". Giờ thêm lựa chọn "Nhập tài liệu mới"
              // ngay trong khung chat, dùng lại đúng FileBrowserScreen
              // (dart:io tự viết, không dùng file_picker) và
              // DocumentService đã có sẵn — không cần rời tab Chat.
              final chosen = await showModalBottomSheet<ImportedDocument?>(
                context: context,
                builder: (context) => SafeArea(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    ListTile(
                      leading: const Icon(Icons.link_off),
                      title: const Text('Không tham chiếu tài liệu nào'),
                      onTap: () => Navigator.pop(context, null),
                    ),
                    ListTile(
                      leading: const Icon(Icons.folder_open_outlined),
                      title: const Text('Nhập tài liệu mới (.txt, .md)...'),
                      onTap: () async {
                        Navigator.pop(context, null);
                        final pickedPath = await Navigator.push<String>(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const FileBrowserScreen(allowedExtensions: ['txt', 'md']),
                          ),
                        );
                        if (pickedPath == null || !mounted) return;
                        try {
                          final newDoc = await DocumentService(db).importFromPath(pickedPath, novelId: widget.novelId);
                          if (!mounted) return;
                          final refreshedDocs = await db.allDocuments(widget.novelId);
                          setState(() {
                            documents = refreshedDocs;
                            attachedDoc = newDoc;
                          });
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi nhập tài liệu: $e')));
                          }
                        }
                      },
                    ),
                    if (documents.isNotEmpty) const Divider(height: 1),
                    ...documents.map((d) => ListTile(
                          leading: const Icon(Icons.description_outlined),
                          title: Text(d.name),
                          onTap: () => Navigator.pop(context, d),
                        )),
                  ]),
                ),
              );
              setState(() => attachedDoc = chosen);
            },
            icon: Icon(attachedDoc != null ? Icons.attach_file : Icons.attach_file_outlined),
            tooltip: 'Tham chiếu tài liệu',
          ),
          IconButton(
            onPressed: () => setState(() => webSearchEnabled = !webSearchEnabled),
            icon: Icon(webSearchEnabled ? Icons.public : Icons.public_outlined,
                color: webSearchEnabled ? Theme.of(context).colorScheme.primary : null),
            tooltip: webSearchEnabled
                ? 'Tìm kiếm web: ĐANG BẬT (tắt để trả lời nhanh hơn, không cần tra cứu)'
                : 'Tìm kiếm web: đang tắt (bật khi cần tra cứu thông tin mới)',
          ),
          // ĐÃ THÊM (theo yêu cầu người dùng — "có lựa chọn bật khi chat
          // với model không hiểu tiếng Việt không"): bấm để xoay vòng qua 3
          // trạng thái CHỈ áp dụng cho phiên chat này, không đổi Cài đặt
          // chung: Theo cài đặt chung → Luôn bật → Luôn tắt → quay lại.
          IconButton(
            onPressed: () => setState(() {
              // null -> true -> false -> null -> ...
              sessionTranslationOverride =
                  sessionTranslationOverride == null ? true : (sessionTranslationOverride == true ? false : null);
            }),
            icon: Icon(
              Icons.translate,
              color: sessionTranslationOverride == true
                  ? Theme.of(context).colorScheme.primary
                  : (sessionTranslationOverride == false ? Theme.of(context).colorScheme.error : null),
            ),
            tooltip: sessionTranslationOverride == null
                ? 'Dịch thuật trung gian cho phiên chat này: theo Cài đặt chung (bấm để LUÔN bật riêng cho chat này)'
                : (sessionTranslationOverride == true
                    ? 'Dịch thuật trung gian: LUÔN BẬT cho phiên chat này (dùng khi model không rành tiếng Việt) — bấm để LUÔN TẮT'
                    : 'Dịch thuật trung gian: LUÔN TẮT cho phiên chat này, kể cả khi Cài đặt chung đang bật — bấm để quay về theo Cài đặt chung'),
          ),
          IconButton(onPressed: _showSessionList, icon: const Icon(Icons.forum_outlined), tooltip: 'Danh sách cuộc trò chuyện'),
          IconButton(onPressed: _newSession, icon: const Icon(Icons.add_comment_outlined), tooltip: 'Cuộc trò chuyện mới'),
        ],
        bottom: attachedDoc == null
            ? null
            : PreferredSize(
                preferredSize: const Size.fromHeight(32),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Chip(
                    label: Text('Đang tham chiếu: ${attachedDoc!.name}', style: const TextStyle(fontSize: 11)),
                    visualDensity: VisualDensity.compact,
                    onDeleted: () => setState(() => attachedDoc = null),
                  ),
                ),
              ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: messages.isEmpty
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                              'Hỏi trợ lý về truyện của bạn. Có thể tạo nhiều cuộc trò chuyện riêng '
                              '(icon dấu + trên) và đổi model AI bất kỳ lúc nào ở Cài đặt.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: messages.length,
                          itemBuilder: (context, i) {
                            final m = messages[i];
                            return Align(
                              alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                              child: Column(
                                crossAxisAlignment: m.fromUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.symmetric(vertical: 4),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                                    decoration: BoxDecoration(
                                      color: m.fromUser
                                          ? Theme.of(context).colorScheme.primaryContainer
                                          : Colors.grey.shade100,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Text(
                                      m.text.isEmpty
                                          ? (sending && i == messages.length - 1
                                              ? 'Đang chạy... ${waitingSeconds}s (model lớn có thể mất vài phút)'
                                              : '...')
                                          : m.text,
                                      // SUA (2026-07-30): truoc day khong chi
                                      // dinh mau chu, nen chu tu dong lay mau
                                      // mac dinh cua theme (sang mau vi app
                                      // dung theme toi) — chu sang tren nen
                                      // xam nhat (grey.shade100) gan nhu
                                      // khong doc duoc. Chi dinh ro mau
                                      // tuong phan cho tung loai khung chat.
                                      style: TextStyle(
                                        color: m.fromUser
                                            ? Theme.of(context).colorScheme.onPrimaryContainer
                                            : Colors.black87,
                                      ),
                                    ),
                                  ),
                                  if (!m.fromUser && m.providerLabel != null)
                                    Padding(
                                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                                      child: Text(
                                        m.providerLabel!,
                                        style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                                      ),
                                    ),
                                  // ĐÃ THÊM — mục BJ, 2026-09-20: nút trích nội
                                  // dung tư vấn này thành đề xuất Story Bible
                                  // (nhân vật/luật/thuật ngữ/tuyến truyện) — chỉ
                                  // hiện cho tin nhắn CỦA TRỢ LÝ, đã sinh xong
                                  // (không hiện lúc đang generate dở, `m.text`
                                  // rỗng hoặc đang "...").
                                  if (!m.fromUser && m.text.isNotEmpty && !(sending && i == messages.length - 1))
                                    Padding(
                                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                                      child: TextButton.icon(
                                        onPressed: () => _extractToBible(m.text),
                                        icon: const Icon(Icons.auto_stories_outlined, size: 16),
                                        label: const Text('Trích vào Bible', style: TextStyle(fontSize: 12)),
                                        style: TextButton.styleFrom(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                          minimumSize: Size.zero,
                                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(children: [
                      Expanded(
                        child: TextField(
                          controller: inputCtrl,
                          decoration: const InputDecoration(hintText: 'Hỏi trợ lý về truyện của bạn...'),
                          // ĐÃ THÊM: vô hiệu hoá gửi qua bàn phím khi đang chờ
                          // phản hồi — lớp bảo vệ THỨ 2 (lớp chính đã sửa ở
                          // `_send()` bằng cách đặt `sending = true` NGAY ĐẦU
                          // hàm, trước mọi `await`) — xem giải thích đầy đủ ở
                          // đó về lỗi crash SIGSEGV thật đã xảy ra do gửi
                          // chồng nhiều lệnh generate() cùng lúc.
                          onSubmitted: sending ? null : (_) => _send(),
                        ),
                      ),
                      IconButton(onPressed: sending ? null : _send, icon: const Icon(Icons.send)),
                    ]),
                  ),
                ),
              ],
            ),
    ),
    );
  }
}
