import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import '../services/settings_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final db = DatabaseService.instance;
  List<ChatSession> sessions = [];
  ChatSession? currentSession;
  List<ChatMessageRecord> messages = [];
  final inputCtrl = TextEditingController();
  bool sending = false;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    var all = await db.allChatSessions();
    if (all.isEmpty) {
      final first = ChatSession(id: const Uuid().v4(), name: 'Cuộc trò chuyện 1');
      await db.upsertChatSession(first);
      all = [first];
    }
    setState(() {
      sessions = all;
      currentSession = all.first;
    });
    await _loadMessages();
  }

  Future<void> _loadMessages() async {
    if (currentSession == null) return;
    final saved = await db.chatMessagesForSession(currentSession!.id);
    setState(() {
      messages = saved;
      loading = false;
    });
  }

  Future<void> _newSession() async {
    final s = ChatSession(id: const Uuid().v4(), name: 'Cuộc trò chuyện ${sessions.length + 1}');
    await db.upsertChatSession(s);
    final all = await db.allChatSessions();
    setState(() {
      sessions = all;
      currentSession = s;
    });
    await _loadMessages();
  }

  Future<void> _switchSession(ChatSession s) async {
    setState(() => currentSession = s);
    await _loadMessages();
  }

  Future<void> _deleteSession(ChatSession s) async {
    await db.deleteChatSession(s.id);
    final all = await db.allChatSessions();
    if (all.isEmpty) {
      await _init();
      return;
    }
    setState(() {
      sessions = all;
      if (currentSession?.id == s.id) currentSession = all.first;
    });
    await _loadMessages();
  }

  Future<void> _showSessionList() async {
    final chosen = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.add),
            title: const Text('Cuộc trò chuyện mới'),
            onTap: () {
              Navigator.pop(context, '__new__');
            },
          ),
          const Divider(height: 1),
          ...sessions.map((s) => ListTile(
                leading: Icon(s.id == currentSession?.id ? Icons.chat_bubble : Icons.chat_bubble_outline),
                title: Text(s.name),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, size: 18),
                  onPressed: () {
                    Navigator.pop(context);
                    _deleteSession(s);
                  },
                ),
                onTap: () => Navigator.pop(context, s.id),
              )),
        ]),
      ),
    );
    if (chosen == '__new__') {
      await _newSession();
    } else if (chosen != null) {
      final s = sessions.firstWhere((x) => x.id == chosen);
      await _switchSession(s);
    }
  }

  Future<void> _send() async {
    final text = inputCtrl.text.trim();
    if (text.isEmpty || sending || currentSession == null) return;
    final sessionId = currentSession!.id;

    final userMsg = ChatMessageRecord(id: const Uuid().v4(), sessionId: sessionId, fromUser: true, text: text);
    await db.upsertChatMessage(userMsg);
    setState(() {
      messages.add(userMsg);
      inputCtrl.clear();
      sending = true;
    });

    final provider = await SettingsService().currentProvider();
    final reply = ChatMessageRecord(id: const Uuid().v4(), sessionId: sessionId, fromUser: false, text: '', providerLabel: provider.name);
    setState(() => messages.add(reply));

    try {
      final rag = RagService(db, await SettingsService().currentEmbeddingService(),
          contextBudgetChars: await SettingsService().loadRagBudget());
      final systemPrompt = await rag.buildSystemPrompt(
        userInstruction: 'Trả lời như một biên tập viên tư vấn viết truyện, tham chiếu đúng Story Bible.',
        currentText: text,
      );
      final stream = provider.generateStream(systemPrompt: systemPrompt, userPrompt: text);
      await for (final chunk in stream) {
        setState(() => reply.text += chunk);
      }
    } catch (e) {
      setState(() => reply.text = 'Lỗi: $e');
    } finally {
      await db.upsertChatMessage(reply);
      setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(currentSession?.name ?? 'Trợ lý AI'),
        actions: [
          IconButton(onPressed: _showSessionList, icon: const Icon(Icons.forum_outlined), tooltip: 'Danh sách cuộc trò chuyện'),
          IconButton(onPressed: _newSession, icon: const Icon(Icons.add_comment_outlined), tooltip: 'Cuộc trò chuyện mới'),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: messages.isEmpty
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                              'Hỏi trợ lý về truyện của bạn. Có thể tạo nhiều cuộc trò chuyện riêng '
                              '(icon dấu + trên) và đổi model AI bất kỳ lúc nào ở Cài đặt.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: messages.length,
                          itemBuilder: (context, i) {
                            final m = messages[i];
                            return Align(
                              alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                              child: Column(
                                crossAxisAlignment: m.fromUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.symmetric(vertical: 4),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                                    decoration: BoxDecoration(
                                      color: m.fromUser
                                          ? Theme.of(context).colorScheme.primaryContainer
                                          : Colors.grey.shade100,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Text(m.text.isEmpty ? '...' : m.text),
                                  ),
                                  if (!m.fromUser && m.providerLabel != null)
                                    Padding(
                                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                                      child: Text(
                                        m.providerLabel!,
                                        style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(children: [
                      Expanded(
                        child: TextField(
                          controller: inputCtrl,
                          decoration: const InputDecoration(hintText: 'Hỏi trợ lý về truyện của bạn...'),
                          onSubmitted: (_) => _send(),
                        ),
                      ),
                      IconButton(onPressed: _send, icon: const Icon(Icons.send)),
                    ]),
                  ),
                ),
              ],
            ),
    );
  }
}
