import 'package:flutter/material.dart';
import '../services/data_integrity_service.dart';
import '../services/database_service.dart';

// ĐÃ THÊM (2026-09-05): thay cho việc bắt người dùng tự mở từng chương, tự
// tìm chữ "Cần nạp lại model" bằng mắt — màn này tự quét TOÀN BỘ chương
// của 1 truyện, chỉ ra đúng (những) chương bị dính, cho xem trước đoạn bị
// lỗi, và khôi phục chỉ bằng 1 lần bấm (tự chụp lại bản hiện tại trước khi
// ghi đè, nên bấm nhầm cũng không mất gì — xem DataIntegrityService).
class DataIntegrityScreen extends StatefulWidget {
  final String novelId;
  const DataIntegrityScreen({super.key, required this.novelId});

  @override
  State<DataIntegrityScreen> createState() => _DataIntegrityScreenState();
}

class _DataIntegrityScreenState extends State<DataIntegrityScreen> {
  final service = DataIntegrityService(DatabaseService.instance);
  late Future<List<CorruptionFinding>> _future;
  final Set<String> _restoredChapterIds = {};

  // ĐÃ SỬA (2026-09-07): trước đây dùng thẳng `chapter.id` làm key — giờ
  // có thêm 2 loại phát hiện KHÔNG gắn với đúng 1 Chapter theo cách đó
  // (novelPlotSummary gắn với Novel, và 1 Chapter có thể xuất hiện ở CẢ
  // chapterContent lẫn chapterAutoSummary cùng lúc — cần key phân biệt
  // được 2 dòng đó, không trùng nhau).
  String _findingKey(CorruptionFinding f) {
    switch (f.kind) {
      case CorruptionKind.novelPlotSummary:
        return 'novel:${f.novel!.id}';
      case CorruptionKind.chapterContent:
        return 'chapter_content:${f.chapter!.id}';
      case CorruptionKind.chapterAutoSummary:
        return 'chapter_summary:${f.chapter!.id}';
    }
  }

  String _actionLabel(CorruptionFinding f) {
    switch (f.kind) {
      case CorruptionKind.chapterContent:
        return 'Khôi phục về bản lúc ${_formatTime(f.cleanVersion!.createdAt)}';
      case CorruptionKind.novelPlotSummary:
        return 'Xoá, để AI tự tóm tắt lại từ đầu';
      case CorruptionKind.chapterAutoSummary:
        return 'Xoá, tự sinh lại ở lần lưu kế tiếp';
    }
  }

  @override
  void initState() {
    super.initState();
    _future = service.scanNovel(widget.novelId);
  }

  Future<void> _rescan() async {
    setState(() {
      _restoredChapterIds.clear();
      _future = service.scanNovel(widget.novelId);
    });
  }

  Future<void> _restore(CorruptionFinding f) async {
    try {
      await service.restore(f);
      if (!mounted) return;
      setState(() => _restoredChapterIds.add(_findingKey(f)));
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Đã xử lý "${f.title}"'
            '${f.kind == CorruptionKind.chapterContent ? ' — bản trước khi khôi phục vẫn được giữ trong Lịch sử phiên bản.' : '.'}'),
      ));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không xử lý được: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kiểm tra dữ liệu bị lỗi'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), tooltip: 'Quét lại', onPressed: _rescan),
        ],
      ),
      body: FutureBuilder<List<CorruptionFinding>>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final findings = snapshot.data!;
          if (findings.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  '✅ Không phát hiện chương/tóm tắt nào bị ghi đè bởi thông báo lỗi nội bộ.\n\n'
                  'App đã quét nội dung chương, tóm tắt riêng từng chương, VÀ "Cốt truyện đã diễn ra" '
                  '(tóm tắt luỹ kế cả truyện), tìm dấu hiệu văn bản lỗi (dạng "⚠️ [...]") '
                  'từng bị lưu nhầm như thể là kết quả AI thật.',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: findings.length,
            itemBuilder: (context, i) {
              final f = findings[i];
              final restored = _restoredChapterIds.contains(_findingKey(f));
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.warning_amber_rounded, color: Colors.orange),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(f.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${f.occurrences} chỗ nghi bị ghi đè'
                        '${f.kind == CorruptionKind.novelPlotSummary ? ' — ảnh hưởng MỌI chương sinh sau này, nên xử lý trước tiên' : ''}',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.orange.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(f.contextSnippet, style: const TextStyle(fontSize: 13)),
                      ),
                      const SizedBox(height: 10),
                      if (restored)
                        const Text('Đã xử lý ✓', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))
                      else if (!f.canAutoFix)
                        const Text(
                          'Không tìm được bản snapshot sạch để tự khôi phục — bạn cần sửa tay đoạn này.',
                          style: TextStyle(color: Colors.red),
                        )
                      else
                        Align(
                          alignment: Alignment.centerRight,
                          child: FilledButton.icon(
                            onPressed: () => _restore(f),
                            icon: Icon(f.kind == CorruptionKind.chapterContent ? Icons.restore : Icons.delete_sweep_outlined),
                            label: Text(_actionLabel(f)),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  String _formatTime(DateTime t) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(t.hour)}:${two(t.minute)} ${two(t.day)}/${two(t.month)}';
  }
}
