import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../services/debug_log_service.dart';

// Xem log debug đã ghi ra file — dùng khi app bị crash cứng (đóng đột ngột,
// không hiện lỗi gì) lúc dùng model local: dòng CUỐI CÙNG trong log cho biết
// app đang làm gì (gọi lệnh native nào) ngay trước khi chết, giúp khoanh
// vùng nguyên nhân mà không cần máy tính/logcat thật.
class DebugLogScreen extends StatefulWidget {
  const DebugLogScreen({super.key});
  @override
  State<DebugLogScreen> createState() => _DebugLogScreenState();
}

class _DebugLogScreenState extends State<DebugLogScreen> {
  String content = 'Đang tải...';
  String? path;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await DebugLogService.instance.readAll();
    final p = await DebugLogService.instance.filePath();
    if (!mounted) return;
    setState(() {
      content = c;
      path = p;
    });
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: content));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã sao chép toàn bộ log')));
    }
  }

  Future<void> _share() async {
    if (path == null) return;
    await Share.shareXFiles([XFile(path!)]);
  }

  Future<void> _clear() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa log?'),
        content: const Text('Xóa toàn bộ log debug hiện có, không khôi phục lại được.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirm == true) {
      await DebugLogService.instance.clear();
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Log debug'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(icon: const Icon(Icons.copy_outlined), onPressed: _copy),
          IconButton(icon: const Icon(Icons.share_outlined), onPressed: _share),
          IconButton(icon: const Icon(Icons.delete_outline), onPressed: _clear),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.orange.shade50,
            child: const Text(
              'Nếu app vừa bị đóng đột ngột lúc chat/đo tốc độ, dòng CUỐI CÙNG trong log này '
              'cho biết app đang làm gì ngay trước khi chết. Bấm nút chia sẻ để gửi log này ra ngoài.',
              style: TextStyle(fontSize: 12, color: Colors.black87),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: SelectableText(content, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
            ),
          ),
        ],
      ),
    );
  }
}
