import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/document_service.dart';
import '../services/settings_service.dart';

// ĐÃ THÊM (theo yêu cầu): màn hình riêng cho từng tài liệu, hiện danh
// sách TỪNG ĐOẠN đã được chia từ tài liệu gốc — cho chọn RỜI RẠC (không
// bắt buộc liên tục như thanh trượt phạm vi ở document_screen.dart) đoạn
// nào cần dịch/tóm tắt, hiện rõ đoạn nào đã xong (✅ xanh)/chưa xong (⚪).
// Hữu ích nhất khi 1 đoạn cụ thể liên tục gây crash (mục 5.62,
// 5.63) — có thể BỎ QUA đúng đoạn đó, xử lý mọi đoạn khác trước, rồi
// quay lại xử lý riêng đoạn khó sau (thử prompt ngắn hơn, tách nhỏ thêm...).
class DocumentChunksScreen extends StatefulWidget {
  final ImportedDocument doc;
  const DocumentChunksScreen({super.key, required this.doc});

  @override
  State<DocumentChunksScreen> createState() => _DocumentChunksScreenState();
}

class _DocumentChunksScreenState extends State<DocumentChunksScreen> {
  final db = DatabaseService.instance;
  late final DocumentService docService = DocumentService(db);
  List<DocumentChunk> chunks = [];
  final Set<int> selected = {};
  bool loading = true;
  bool _processingDoc = false;
  bool _cancelDocRequested = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await db.chunksForDocument(widget.doc.id);
    if (!mounted) return;
    setState(() {
      chunks = all;
      loading = false;
    });
  }

  void _selectAll() => setState(() => selected.addAll(chunks.map((c) => c.index)));
  void _selectNone() => setState(() => selected.clear());
  void _selectUnfinished() => setState(() {
        selected
          ..clear()
          ..addAll(chunks.where((c) => c.resultText == null || c.resultText!.isEmpty).map((c) => c.index));
      });

  Future<void> _showChunkDetail(DocumentChunk chunk) {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Đoạn ${chunk.index + 1}'),
        content: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Văn bản gốc:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(chunk.originalText),
            const SizedBox(height: 16),
            const Text('Kết quả:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(
              (chunk.resultText?.isNotEmpty ?? false) ? chunk.resultText! : '(chưa xử lý đoạn này)',
              style: TextStyle(color: (chunk.resultText?.isNotEmpty ?? false) ? null : Colors.grey),
            ),
          ]),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Đóng'))],
      ),
    );
  }

  Future<void> _runOnSelected(DocumentAction action) async {
    if (selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa chọn đoạn nào — bấm chọn ít nhất 1 đoạn trước.')));
      return;
    }
    final promptCtrl = TextEditingController(
      text: action == DocumentAction.translate
          ? 'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.'
          : 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.',
    );
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${action == DocumentAction.translate ? "Dịch" : "Tóm tắt"} ${selected.length} đoạn đã chọn'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
            'Các đoạn đã chọn sẽ LUÔN được xử lý lại (kể cả đoạn đã có kết quả từ trước) — chọn thủ công nghĩa là muốn làm lại đoạn đó.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          TextField(controller: promptCtrl, maxLines: 5, decoration: const InputDecoration(border: OutlineInputBorder())),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Bắt đầu')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    int done = 0;
    final total = selected.length;
    final progressNotifier = ValueNotifier<double>(0);
    _cancelDocRequested = false;
    setState(() => _processingDoc = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text(action == DocumentAction.translate ? 'Đang dịch...' : 'Đang tóm tắt...'),
        content: ValueListenableBuilder<double>(
          valueListenable: progressNotifier,
          builder: (context, value, _) => Column(mainAxisSize: MainAxisSize.min, children: [
            LinearProgressIndicator(value: total > 0 ? value : null),
            const SizedBox(height: 12),
            Text('Đã xong ${(value * total).round()}/$total đoạn (${(value * 100).round()}%)'),
          ]),
        ),
        actions: [
          TextButton(
            onPressed: () {
              _cancelDocRequested = true;
              Navigator.pop(dialogContext);
            },
            child: const Text('Huỷ'),
          ),
        ],
      ),
    );

    final selectedSnapshot = Set<int>.from(selected);
    try {
      final provider = await SettingsService().currentProvider();
      await docService.processDocument(
        doc: widget.doc,
        action: action,
        provider: provider,
        customInstruction: promptCtrl.text.trim().isEmpty ? null : promptCtrl.text.trim(),
        chunkIndices: selectedSnapshot,
        isCancelled: () => _cancelDocRequested,
        onProgress: (d, t) {
          done = d;
          progressNotifier.value = t > 0 ? d / t : 0;
        },
      );
      if (mounted && !_cancelDocRequested) Navigator.pop(context);
      await _load(); // làm mới trạng thái đã xong/chưa xong trên danh sách
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(_cancelDocRequested
              ? 'Đã huỷ — hoàn thành $done/$total đoạn trong lượt chọn này.'
              : 'Đã xử lý xong $done/$total đoạn đã chọn.'),
        ));
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      await _load(); // cập nhật lại đoạn nào đã xong trước khi gặp lỗi
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e'), duration: const Duration(seconds: 8)));
    } finally {
      if (mounted) setState(() => _processingDoc = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final doneCount = chunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length;
    // ĐÃ THÊM: chặn vuốt back (Android 13+ predictive back) trong lúc
    // đang xử lý đoạn đã chọn — cùng lý do như document_screen.dart.
    return PopScope(
      canPop: !_processingDoc,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Đang xử lý — đợi xong trước khi thoát để không mất tiến độ.'),
        ));
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.doc.name, overflow: TextOverflow.ellipsis),
          actions: [
            PopupMenuButton<String>(
              tooltip: 'Chọn nhanh',
              onSelected: (v) {
                if (v == 'all') _selectAll();
                if (v == 'none') _selectNone();
                if (v == 'unfinished') _selectUnfinished();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'all', child: Text('Chọn tất cả')),
                PopupMenuItem(value: 'unfinished', child: Text('Chỉ chọn đoạn chưa xong')),
                PopupMenuItem(value: 'none', child: Text('Bỏ chọn tất cả')),
              ],
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(28),
            child: Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                'Đã xong $doneCount/${chunks.length} đoạn — đã chọn ${selected.length}',
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ),
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : chunks.isEmpty
                ? const Center(child: Text('Tài liệu chưa có đoạn nào.'))
                : ListView.builder(
                    itemCount: chunks.length,
                    itemBuilder: (context, i) {
                      final chunk = chunks[i];
                      final done = chunk.resultText != null && chunk.resultText!.isNotEmpty;
                      final isSelected = selected.contains(chunk.index);
                      final preview = chunk.originalText.length > 90
                          ? '${chunk.originalText.substring(0, 90)}...'
                          : chunk.originalText;
                      return CheckboxListTile(
                        value: isSelected,
                        onChanged: _processingDoc
                            ? null
                            : (v) => setState(() {
                                  if (v == true) {
                                    selected.add(chunk.index);
                                  } else {
                                    selected.remove(chunk.index);
                                  }
                                }),
                        secondary: Icon(
                          done ? Icons.check_circle : Icons.radio_button_unchecked,
                          color: done ? Colors.green : Colors.grey,
                        ),
                        title: Text('Đoạn ${chunk.index + 1}', style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: GestureDetector(
                          onTap: () => _showChunkDetail(chunk),
                          child: Text(
                            preview,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        ),
                      );
                    },
                  ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _processingDoc ? null : () => _runOnSelected(DocumentAction.translate),
                  icon: const Icon(Icons.translate, size: 16),
                  label: Text('Dịch (${selected.length})'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _processingDoc ? null : () => _runOnSelected(DocumentAction.summarize),
                  icon: const Icon(Icons.summarize_outlined, size: 16),
                  label: Text('Tóm tắt (${selected.length})'),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
