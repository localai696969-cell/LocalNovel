import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/document_service.dart';
import '../services/settings_service.dart';
import '../services/providers/local_provider.dart';
import 'document_chunks_screen.dart';
import 'file_browser_screen.dart';

class DocumentScreen extends StatefulWidget {
  final String novelId;
  const DocumentScreen({super.key, required this.novelId});
  @override
  State<DocumentScreen> createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  final db = DatabaseService.instance;
  late final DocumentService docService = DocumentService(db);
  List<ImportedDocument> documents = [];
  bool loading = true;
  // ĐÃ THÊM: đếm số đoạn ĐÃ DỊCH (giá trị lớn nhất giữa số đoạn có bản
  // dịch và số đoạn có bản tóm tắt — 2 thao tác độc lập, dùng chung 1 cột
  // resultText nên không phân biệt được loại nào, nhưng đủ để biết tài
  // liệu có tiến độ dở dang hay chưa) — hiện lên danh sách để người dùng
  // BIẾT RÕ có nhiệm vụ dang dở trước khi bấm nút, không cần đoán mò.
  Map<String, int> _doneCounts = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant DocumentScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final all = await db.allDocuments(widget.novelId);
    // ĐÃ THÊM: tải kèm số đoạn đã có kết quả cho từng tài liệu, để hiện
    // tiến độ dở dang trên danh sách — không load hết nội dung đoạn, chỉ
    // đếm, nên không tốn nhiều bộ nhớ/thời gian dù tài liệu dài.
    final doneCounts = <String, int>{};
    for (final doc in all) {
      final chunks = await db.chunksForDocument(doc.id);
      doneCounts[doc.id] = chunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length;
    }
    if (!mounted) return;
    setState(() {
      documents = all;
      _doneCounts = doneCounts;
      loading = false;
    });
  }

  Future<void> _importDialog() async {
    final pathCtrl = TextEditingController();
    String? checkResult;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Đính kèm tài liệu (.txt, .md)'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Đường dẫn file',
                hintText: '/storage/emulated/0/Download/truyen.txt',
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await Navigator.push<String>(
                      context,
                      MaterialPageRoute(builder: (_) => const FileBrowserScreen(allowedExtensions: ['txt', 'md'])),
                    );
                    if (picked != null) {
                      pathCtrl.text = picked;
                      setDialogState(() => checkResult = null);
                    }
                  },
                  icon: const Icon(Icons.folder_open_outlined, size: 16),
                  label: const Text('Duyệt file'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final exists = File(pathCtrl.text.trim()).existsSync();
                    setDialogState(() => checkResult = exists ? '✓ File tồn tại' : '✗ Không tìm thấy file');
                  },
                  icon: const Icon(Icons.fact_check_outlined, size: 16),
                  label: const Text('Kiểm tra'),
                ),
              ),
            ]),
            if (checkResult != null)
              Text(checkResult!, style: TextStyle(color: checkResult!.startsWith('✓') ? Colors.green : Colors.red, fontSize: 12)),
            const SizedBox(height: 4),
            const Text(
              'Chỉ hỗ trợ file văn bản thuần (.txt, .md) ở bản này. PDF/DOCX/ảnh sẽ thêm sau.',
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Đính kèm')),
          ],
        );
      }),
    );
    if (ok == true && pathCtrl.text.trim().isNotEmpty) {
      try {
        await docService.importFromPath(pathCtrl.text.trim(), novelId: widget.novelId);
        _load();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    }
  }

  // Prompt mặc định — hiện ra sẵn trong ô chỉnh sửa để người dùng biết
  // Lấy prompt đã lưu (hoặc mặc định) cho từng loại thao tác.
  Future<String> _defaultPromptFor(DocumentAction action) async {
    final settings = SettingsService();
    return action == DocumentAction.translate
        ? await settings.loadDocTranslatePrompt()
        : await settings.loadDocSummarizePrompt();
  }

  // Hộp thoại cấu hình trước khi xử lý tài liệu — gồm 3 phần:
  //   1. Chọn model: "Model chính" (active trong Cài đặt) hoặc "Model dịch
  //      ngôn ngữ" (slot 1, model nhỏ cấu hình ở Dịch thuật trung gian).
  //      Chỉ 2 lựa chọn này — không có model sinh văn bản riêng ở đây vì
  //      model chính đã được quản lý tập trung trong tab Cài đặt.
  //   2. Prompt hướng dẫn — load từ Settings (lần trước đã gõ gì thì hiện
  //      lại), lưu lại sau khi xác nhận.
  //   3. Phạm vi đoạn cần xử lý.
  Future<({String prompt, int start, int end, String modelChoice})?> _askProcessConfig(
    DocumentAction action,
    ImportedDocument doc,
  ) async {
    final settings = SettingsService();
    final savedPrompt = await _defaultPromptFor(action);
    final savedModelChoice = await settings.loadDocModelChoice();
    final translationModelPath = await settings.loadTranslationModelPath();
    final hasTranslationModel = translationModelPath != null && translationModelPath.isNotEmpty;

    final ctrl = TextEditingController(text: savedPrompt);
    final maxIndex = (doc.chunkCount - 1).clamp(0, 1 << 30);
    RangeValues range = RangeValues(0, maxIndex.toDouble());
    // Nếu lần trước chọn model dịch nhưng giờ chưa cấu hình, reset về 'active'
    String modelChoice = (savedModelChoice == 'translation' && !hasTranslationModel)
        ? 'active'
        : savedModelChoice;

    return showDialog<({String prompt, int start, int end, String modelChoice})>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (dialogCtx, setDialogState) => AlertDialog(
          title: Text(action == DocumentAction.translate ? 'Cấu hình dịch thuật' : 'Cấu hình tóm tắt'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              // ── Chọn model ──────────────────────────────────────────
              const Text('Model xử lý', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 4),
              // Model chính = model active đang chọn trong tab Cài đặt
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('Model chính (đang chọn trong Cài đặt)'),
                subtitle: const Text('Dùng model đang active, giống chat và viết chương', style: TextStyle(fontSize: 11)),
                value: 'active',
                groupValue: modelChoice,
                onChanged: (v) => setDialogState(() => modelChoice = v!),
              ),
              // Model dịch ngôn ngữ = slot 1, cấu hình ở Dịch thuật trung gian
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(
                  hasTranslationModel
                      ? 'Model dịch ngôn ngữ (slot 1)'
                      : 'Model dịch ngôn ngữ — chưa cấu hình',
                  style: TextStyle(color: hasTranslationModel ? null : Colors.grey),
                ),
                subtitle: Text(
                  hasTranslationModel
                      ? 'Model nhỏ (0.3B–1.5B) cấu hình ở Dịch thuật trung gian — dịch nhanh hơn, ít tốn RAM'
                      : 'Vào Cài đặt → Dịch thuật trung gian → mục 1 để thêm model',
                  style: const TextStyle(fontSize: 11),
                ),
                value: 'translation',
                groupValue: modelChoice,
                onChanged: hasTranslationModel ? (v) => setDialogState(() => modelChoice = v!) : null,
              ),
              const Divider(height: 20),
              // ── Prompt ──────────────────────────────────────────────
              const Text('Prompt hướng dẫn', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 4),
              const Text(
                'AI nhận prompt này trước mỗi đoạn. Được lưu lại cho lần sau.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: ctrl,
                maxLines: 5,
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
              const SizedBox(height: 16),
              // ── Phạm vi đoạn ────────────────────────────────────────
              Text(
                'Phạm vi: đoạn ${range.start.round() + 1} → ${range.end.round() + 1} / ${doc.chunkCount}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              if (maxIndex > 0)
                RangeSlider(
                  values: range,
                  min: 0,
                  max: maxIndex.toDouble(),
                  divisions: maxIndex > 0 ? maxIndex : null,
                  labels: RangeLabels('${range.start.round() + 1}', '${range.end.round() + 1}'),
                  onChanged: (v) => setDialogState(() => range = v),
                )
              else
                const Text('Tài liệu chỉ có 1 đoạn.', style: TextStyle(fontSize: 12, color: Colors.grey)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogCtx), child: const Text('Hủy')),
            FilledButton(
              onPressed: () => Navigator.pop(dialogCtx, (
                prompt: ctrl.text.trim(),
                start: range.start.round(),
                end: range.end.round(),
                modelChoice: modelChoice,
              )),
              child: const Text('Bắt đầu'),
            ),
          ],
        ),
      ),
    );
  }

  // ĐÃ THÊM: cờ theo dõi ở cấp State (trước đây không có) — dùng để
  // PopScope chặn vuốt back (Android 13+ predictive back) trong lúc đang
  // dịch/tóm tắt tài liệu, tránh mất tiến độ giữa chừng do vuốt lỡ tay.
  bool _processingDoc = false;
  // ĐÃ THÊM: cờ huỷ hợp tác — người dùng bấm nút Huỷ trong hộp thoại tiến
  // trình sẽ bật cờ này, vòng lặp xử lý đoạn kiểm tra giữa mỗi đoạn (dừng
  // SẠCH giữa 2 đoạn, không ngắt dở đoạn đang chạy).
  bool _cancelDocRequested = false;

  // Tạo provider theo lựa chọn trong hộp thoại:
  //   'active'      → model đang active trong tab Cài đặt (currentProvider)
  //   'translation' → model dịch ngôn ngữ slot 1 (cấu hình ở Dịch thuật trung gian)
  Future<dynamic> _providerForChoice(String choice) async {
    if (choice == 'translation') {
      final path = await SettingsService().loadTranslationModelPath();
      if (path == null || path.isEmpty) {
        throw Exception('Model dịch ngôn ngữ chưa cấu hình — vào Cài đặt → Dịch thuật trung gian');
      }
      return LocalLlamaProvider(modelPath: path, slot: 1);
    }
    return SettingsService().currentProvider();
  }

  Future<void> _process(ImportedDocument doc, DocumentAction action) async {
    final config = await _askProcessConfig(action, doc);
    if (config == null || !mounted) return; // người dùng bấm Hủy

    // Lưu prompt và lựa chọn model để lần sau hiện sẵn
    final settings = SettingsService();
    if (config.prompt.isNotEmpty) {
      if (action == DocumentAction.translate) {
        await settings.saveDocTranslatePrompt(config.prompt);
      } else {
        await settings.saveDocSummarizePrompt(config.prompt);
      }
    }
    await settings.saveDocModelChoice(config.modelChoice);

    int done = 0;
    // ĐÃ SỬA: tổng số giờ tính theo PHẠM VI ĐÃ CHỌN, không phải luôn là
    // toàn bộ tài liệu.
    final total = config.end - config.start + 1;
    final progressNotifier = ValueNotifier<double>(0);
    _cancelDocRequested = false;
    setState(() => _processingDoc = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text(action == DocumentAction.translate ? 'Đang dịch...' : 'Đang tóm tắt...'),
        content: ValueListenableBuilder<double>(
          valueListenable: progressNotifier,
          builder: (context, value, _) => Column(mainAxisSize: MainAxisSize.min, children: [
            // ĐÃ THÊM: thanh tiến trình % thật thay vì chỉ có spinner tròn.
            LinearProgressIndicator(value: total > 0 ? value : null),
            const SizedBox(height: 12),
            Text('Đã xong ${(value * total).round()}/$total đoạn (${(value * 100).round()}%)'),
          ]),
        ),
        actions: [
          // ĐÃ THÊM: nút Huỷ rõ ràng — trước đây chỉ có thể chặn vuốt back
          // (PopScope) chứ không có cách chủ động dừng sạch giữa chừng.
          TextButton(
            onPressed: () {
              _cancelDocRequested = true;
              Navigator.pop(dialogContext);
            },
            child: const Text('Huỷ'),
          ),
        ],
      ),
    );

    try {
      final provider = await _providerForChoice(config.modelChoice);
      await docService.processDocument(
        doc: doc,
        action: action,
        provider: provider,
        customInstruction: config.prompt.isEmpty ? null : config.prompt,
        startIndex: config.start,
        endIndex: config.end,
        isCancelled: () => _cancelDocRequested,
        onProgress: (d, t) {
          done = d;
          progressNotifier.value = t > 0 ? d / t : 0;
        },
      );
      if (mounted && !_cancelDocRequested) Navigator.pop(context);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            _cancelDocRequested
                ? 'Đã huỷ — hoàn thành $done/$total đoạn trong phạm vi đã chọn, bấm chạy lại để tiếp tục đúng chỗ dừng.'
                : '${action == DocumentAction.translate ? "Đã dịch" : "Đã tóm tắt"} xong $done/$total đoạn trong phạm vi đã chọn — '
                    'bấm nút "Xuất kết quả" để lưu file, hoặc dùng khung chat để hỏi đáp về tài liệu này',
          ),
        ));
      }
      _load();
    } catch (e) {
      if (mounted) Navigator.pop(context);
      // ĐÃ THÊM: gọi _load() cả khi lỗi — nếu là DocumentProcessingAnomalyException
      // (mục 64), 1 số đoạn TRƯỚC đoạn bất thường có thể đã lưu thành công,
      // cần cập nhật lại số đếm "đã xong" trên danh sách để phản ánh đúng.
      _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e'), duration: const Duration(seconds: 8)));
    } finally {
      if (mounted) setState(() => _processingDoc = false);
    }
  }

  // Xuất kết quả (bản dịch HOẶC bản tóm tắt, tùy loại đã xử lý gần nhất)
  // ra file — trước đây chỉ tự động làm việc này cho "Dịch toàn bộ",
  // giờ dùng chung cho cả "Tóm tắt", vì cả hai đều là kết quả đáng lưu.
  Future<void> _exportResult(ImportedDocument doc) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final file = await docService.exportResult(doc, dir);
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất file: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: chặn vuốt back (Android 13+ predictive back) trong lúc
    // đang dịch/tóm tắt tài liệu — cùng lý do như chapter_editor_screen.dart.
    return PopScope(
      canPop: !_processingDoc,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Đang xử lý tài liệu — đợi xong trước khi thoát để không mất tiến độ.'),
        ));
      },
      child: Scaffold(
      appBar: AppBar(title: const Text('Tài liệu')),
      floatingActionButton: FloatingActionButton(onPressed: _importDialog, child: const Icon(Icons.add)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : documents.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Đính kèm file .txt/.md để dịch cuốn chiếu, tóm tắt, hoặc hỏi đáp về nội dung trong khung chat.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: documents.length,
                  itemBuilder: (context, i) {
                    final doc = documents[i];
                    final done = _doneCounts[doc.id] ?? 0;
                    // ĐÃ THÊM: có tiến độ dở dang (đã dịch/tóm tắt được
                    // 1 phần, chưa xong hết) → đổi nhãn nút thành "Tiếp
                    // tục" kèm số đoạn đã xong, thay vì luôn ghi "Dịch
                    // toàn bộ"/"Tóm tắt" như thể chưa từng chạy — trả lời
                    // đúng câu hỏi "sao không có nút tiếp tục nhiệm vụ
                    // dang dở": NÚT ĐÃ CÓ SẴN (processDocument() tự bỏ
                    // qua đoạn đã xong nhờ resumeFromProgress — mục 55),
                    // chỉ là trước đây không có gì hiện lên để biết còn
                    // dở dang hay không, dễ hiểu lầm là phải làm lại từ đầu.
                    final hasProgress = done > 0 && done < doc.chunkCount;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(doc.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                          Row(children: [
                            Text('${doc.chunkCount} đoạn', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                            if (hasProgress) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primaryContainer,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  'Dang dở: $done/${doc.chunkCount} đoạn đã xong',
                                  style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onPrimaryContainer),
                                ),
                              ),
                            ] else if (done >= doc.chunkCount && doc.chunkCount > 0) ...[
                              const SizedBox(width: 8),
                              const Icon(Icons.check_circle, size: 14, color: Colors.green),
                            ],
                          ]),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            // ĐÃ THÊM: mở màn hình chọn từng đoạn cụ thể — hữu
                            // ích nhất khi 1 đoạn cụ thể hay gây crash (mục
                            // 5.62), có thể bỏ qua đúng đoạn đó, xử lý các
                            // đoạn khác trước.
                            OutlinedButton.icon(
                              onPressed: () async {
                                await Navigator.push(context, MaterialPageRoute(builder: (_) => DocumentChunksScreen(doc: doc)));
                                _load(); // làm mới số đoạn đã xong sau khi quay lại
                              },
                              icon: const Icon(Icons.view_list_outlined, size: 16),
                              label: const Text('Chọn từng đoạn'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.translate),
                              icon: Icon(hasProgress ? Icons.play_arrow : Icons.translate, size: 16),
                              label: Text(hasProgress ? 'Tiếp tục dịch ($done/${doc.chunkCount})' : 'Dịch toàn bộ'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.summarize),
                              icon: Icon(hasProgress ? Icons.play_arrow : Icons.summarize_outlined, size: 16),
                              label: Text(hasProgress ? 'Tiếp tục tóm tắt ($done/${doc.chunkCount})' : 'Tóm tắt'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _exportResult(doc),
                              icon: const Icon(Icons.ios_share_outlined, size: 16),
                              label: const Text('Xuất kết quả'),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () async {
                                await db.deleteDocument(doc.id);
                                _load();
                              },
                            ),
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
      ),
    );
  }
}
