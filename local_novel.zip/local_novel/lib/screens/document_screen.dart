import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/document_service.dart';
import '../services/settings_service.dart';
import 'file_browser_screen.dart';

class DocumentScreen extends StatefulWidget {
  final String novelId;
  const DocumentScreen({super.key, required this.novelId});
  @override
  State<DocumentScreen> createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  final db = DatabaseService.instance;
  late final DocumentService docService = DocumentService(db);
  List<ImportedDocument> documents = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant DocumentScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final all = await db.allDocuments(widget.novelId);
    if (!mounted) return;
    setState(() {
      documents = all;
      loading = false;
    });
  }

  Future<void> _importDialog() async {
    final pathCtrl = TextEditingController();
    String? checkResult;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Đính kèm tài liệu (.txt, .md)'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Đường dẫn file',
                hintText: '/storage/emulated/0/Download/truyen.txt',
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await Navigator.push<String>(
                      context,
                      MaterialPageRoute(builder: (_) => const FileBrowserScreen(allowedExtensions: ['txt', 'md'])),
                    );
                    if (picked != null) {
                      pathCtrl.text = picked;
                      setDialogState(() => checkResult = null);
                    }
                  },
                  icon: const Icon(Icons.folder_open_outlined, size: 16),
                  label: const Text('Duyệt file'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final exists = File(pathCtrl.text.trim()).existsSync();
                    setDialogState(() => checkResult = exists ? '✓ File tồn tại' : '✗ Không tìm thấy file');
                  },
                  icon: const Icon(Icons.fact_check_outlined, size: 16),
                  label: const Text('Kiểm tra'),
                ),
              ),
            ]),
            if (checkResult != null)
              Text(checkResult!, style: TextStyle(color: checkResult!.startsWith('✓') ? Colors.green : Colors.red, fontSize: 12)),
            const SizedBox(height: 4),
            const Text(
              'Chỉ hỗ trợ file văn bản thuần (.txt, .md) ở bản này. PDF/DOCX/ảnh sẽ thêm sau.',
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Đính kèm')),
          ],
        );
      }),
    );
    if (ok == true && pathCtrl.text.trim().isNotEmpty) {
      try {
        await docService.importFromPath(pathCtrl.text.trim(), novelId: widget.novelId);
        _load();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    }
  }

  // Prompt mặc định — hiện ra sẵn trong ô chỉnh sửa để người dùng biết
  // đang dùng gì và có thể đổi trước khi chạy, thay vì cố định cứng
  // không cho tùy chỉnh như trước.
  String _defaultPromptFor(DocumentAction action) => action == DocumentAction.translate
      ? 'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.'
      : 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.';

  // ĐÃ THÊM: trước đây prompt tóm tắt/dịch bị CỐ ĐỊNH trong code, không
  // có ô nào cho người dùng chỉnh sửa văn phong/mức độ chi tiết mong
  // muốn — dù docService.processDocument() đã có sẵn tham số
  // customInstruction từ trước, chỉ là không có UI nào truyền vào.
  Future<String?> _askCustomPrompt(DocumentAction action) async {
    final ctrl = TextEditingController(text: _defaultPromptFor(action));
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(action == DocumentAction.translate ? 'Prompt dịch thuật' : 'Prompt tóm tắt'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
            'Chỉnh sửa hướng dẫn AI sẽ dùng cho MỖI đoạn văn bản (áp dụng cho toàn bộ tài liệu này).',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: ctrl,
            maxLines: 5,
            decoration: const InputDecoration(border: OutlineInputBorder()),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
          FilledButton(
            onPressed: () => Navigator.pop(context, ctrl.text.trim()),
            child: const Text('Dùng prompt này'),
          ),
        ],
      ),
    );
  }

  // ĐÃ THÊM: cờ theo dõi ở cấp State (trước đây không có) — dùng để
  // PopScope chặn vuốt back (Android 13+ predictive back) trong lúc đang
  // dịch/tóm tắt tài liệu, tránh mất tiến độ giữa chừng do vuốt lỡ tay.
  bool _processingDoc = false;

  Future<void> _process(ImportedDocument doc, DocumentAction action) async {
    final customPrompt = await _askCustomPrompt(action);
    if (customPrompt == null || !mounted) return; // người dùng bấm Hủy

    int done = 0;
    final total = doc.chunkCount;
    final progressNotifier = ValueNotifier<String>('Đang xử lý 0/$total đoạn...');
    setState(() => _processingDoc = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        content: ValueListenableBuilder<String>(
          valueListenable: progressNotifier,
          builder: (context, value, _) => Row(children: [
            const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
            const SizedBox(width: 16),
            Expanded(child: Text(value)),
          ]),
        ),
      ),
    );

    try {
      final provider = await SettingsService().currentProvider();
      await docService.processDocument(
        doc: doc,
        action: action,
        provider: provider,
        customInstruction: customPrompt.isEmpty ? null : customPrompt,
        onProgress: (d, t) {
          done = d;
          progressNotifier.value = 'Đang xử lý $d/$t đoạn...';
        },
      );
      if (mounted) Navigator.pop(context);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            '${action == DocumentAction.translate ? "Đã dịch" : "Đã tóm tắt"} xong $done đoạn — '
            'bấm nút "Xuất kết quả" để lưu file, hoặc dùng khung chat để hỏi đáp về tài liệu này',
          ),
        ));
      }
      _load();
    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) setState(() => _processingDoc = false);
    }
  }

  // Xuất kết quả (bản dịch HOẶC bản tóm tắt, tùy loại đã xử lý gần nhất)
  // ra file — trước đây chỉ tự động làm việc này cho "Dịch toàn bộ",
  // giờ dùng chung cho cả "Tóm tắt", vì cả hai đều là kết quả đáng lưu.
  Future<void> _exportResult(ImportedDocument doc) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final file = await docService.exportResult(doc, dir);
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất file: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: chặn vuốt back (Android 13+ predictive back) trong lúc
    // đang dịch/tóm tắt tài liệu — cùng lý do như chapter_editor_screen.dart.
    return PopScope(
      canPop: !_processingDoc,
      onPopInvokedWithPop: (didPop) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Đang xử lý tài liệu — đợi xong trước khi thoát để không mất tiến độ.'),
        ));
      },
      child: Scaffold(
      appBar: AppBar(title: const Text('Tài liệu')),
      floatingActionButton: FloatingActionButton(onPressed: _importDialog, child: const Icon(Icons.add)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : documents.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Đính kèm file .txt/.md để dịch cuốn chiếu, tóm tắt, hoặc hỏi đáp về nội dung trong khung chat.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: documents.length,
                  itemBuilder: (context, i) {
                    final doc = documents[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(doc.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                          Text('${doc.chunkCount} đoạn', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.translate),
                              icon: const Icon(Icons.translate, size: 16),
                              label: const Text('Dịch toàn bộ'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.summarize),
                              icon: const Icon(Icons.summarize_outlined, size: 16),
                              label: const Text('Tóm tắt'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _exportResult(doc),
                              icon: const Icon(Icons.ios_share_outlined, size: 16),
                              label: const Text('Xuất kết quả'),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () async {
                                await db.deleteDocument(doc.id);
                                _load();
                              },
                            ),
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
      ),
    );
  }
}
