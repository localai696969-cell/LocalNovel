import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/document_service.dart';
import '../services/settings_service.dart';

class DocumentScreen extends StatefulWidget {
  const DocumentScreen({super.key});
  @override
  State<DocumentScreen> createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  final db = DatabaseService.instance;
  late final DocumentService docService = DocumentService(db);
  List<ImportedDocument> documents = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await db.allDocuments();
    setState(() {
      documents = all;
      loading = false;
    });
  }

  Future<void> _importDialog() async {
    final pathCtrl = TextEditingController();
    String? checkResult;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Đính kèm tài liệu (.txt, .md)'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Đường dẫn file',
                hintText: '/storage/emulated/0/Download/truyen.txt',
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () {
                final exists = File(pathCtrl.text.trim()).existsSync();
                setDialogState(() => checkResult = exists ? '✓ File tồn tại' : '✗ Không tìm thấy file');
              },
              icon: const Icon(Icons.fact_check_outlined, size: 16),
              label: const Text('Kiểm tra đường dẫn'),
            ),
            if (checkResult != null)
              Text(checkResult!, style: TextStyle(color: checkResult!.startsWith('✓') ? Colors.green : Colors.red, fontSize: 12)),
            const SizedBox(height: 4),
            const Text(
              'Chỉ hỗ trợ file văn bản thuần (.txt, .md) ở bản này. PDF/DOCX/ảnh sẽ thêm sau.',
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Đính kèm')),
          ],
        );
      }),
    );
    if (ok == true && pathCtrl.text.trim().isNotEmpty) {
      try {
        await docService.importFromPath(pathCtrl.text.trim());
        _load();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    }
  }

  Future<void> _process(ImportedDocument doc, DocumentAction action) async {
    int done = 0;
    final total = doc.chunkCount;
    final progressNotifier = ValueNotifier<String>('Đang xử lý 0/$total đoạn...');

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        content: ValueListenableBuilder<String>(
          valueListenable: progressNotifier,
          builder: (context, value, _) => Row(children: [
            const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
            const SizedBox(width: 16),
            Expanded(child: Text(value)),
          ]),
        ),
      ),
    );

    try {
      final provider = await SettingsService().currentProvider();
      await docService.processDocument(
        doc: doc,
        action: action,
        provider: provider,
        onProgress: (d, t) {
          done = d;
          progressNotifier.value = 'Đang xử lý $d/$t đoạn...';
        },
      );
      if (mounted) Navigator.pop(context);
      if (action == DocumentAction.translate) {
        final dir = await getApplicationDocumentsDirectory();
        final file = await docService.exportResult(doc, dir);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Đã dịch xong $done đoạn — đang mở chia sẻ file...'),
          ));
          await Share.shareXFiles([XFile(file.path)]);
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã tóm tắt xong — dùng khung chat để hỏi đáp về tài liệu này')));
        }
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tài liệu')),
      floatingActionButton: FloatingActionButton(onPressed: _importDialog, child: const Icon(Icons.add)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : documents.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Đính kèm file .txt/.md để dịch cuốn chiếu, tóm tắt, hoặc hỏi đáp về nội dung trong khung chat.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: documents.length,
                  itemBuilder: (context, i) {
                    final doc = documents[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(doc.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                          Text('${doc.chunkCount} đoạn', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.translate),
                              icon: const Icon(Icons.translate, size: 16),
                              label: const Text('Dịch toàn bộ'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.summarize),
                              icon: const Icon(Icons.summarize_outlined, size: 16),
                              label: const Text('Tóm tắt'),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () async {
                                await db.deleteDocument(doc.id);
                                _load();
                              },
                            ),
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
    );
  }
}
