import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/document_service.dart';
import '../services/settings_service.dart';
import '../services/providers/local_provider.dart';
import 'document_chunks_screen.dart';
import 'file_browser_screen.dart';
import '../services/bible_extraction_service.dart';
import 'bible_extraction_review_screen.dart';

class DocumentScreen extends StatefulWidget {
  final String novelId;
  const DocumentScreen({super.key, required this.novelId});
  @override
  State<DocumentScreen> createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  final db = DatabaseService.instance;
  late final DocumentService docService = DocumentService(db);
  List<ImportedDocument> documents = [];
  bool loading = true;
  // ĐÃ THÊM: đếm số đoạn ĐÃ DỊCH (giá trị lớn nhất giữa số đoạn có bản
  // dịch và số đoạn có bản tóm tắt — 2 thao tác độc lập, dùng chung 1 cột
  // resultText nên không phân biệt được loại nào, nhưng đủ để biết tài
  // liệu có tiến độ dở dang hay chưa) — hiện lên danh sách để người dùng
  // BIẾT RÕ có nhiệm vụ dang dở trước khi bấm nút, không cần đoán mò.
  Map<String, int> _doneCounts = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant DocumentScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final all = await db.allDocuments(widget.novelId);
    // ĐÃ THÊM: tải kèm số đoạn đã có kết quả cho từng tài liệu, để hiện
    // tiến độ dở dang trên danh sách — không load hết nội dung đoạn, chỉ
    // đếm, nên không tốn nhiều bộ nhớ/thời gian dù tài liệu dài.
    final doneCounts = <String, int>{};
    for (final doc in all) {
      final chunks = await db.chunksForDocument(doc.id);
      doneCounts[doc.id] = chunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length;
    }
    if (!mounted) return;
    setState(() {
      documents = all;
      _doneCounts = doneCounts;
      loading = false;
    });
  }

  Future<void> _importDialog() async {
    final pathCtrl = TextEditingController();
    String? checkResult;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Đính kèm tài liệu (.txt, .md)'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Đường dẫn file',
                hintText: '/storage/emulated/0/Download/truyen.txt',
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await Navigator.push<String>(
                      context,
                      MaterialPageRoute(builder: (_) => const FileBrowserScreen(allowedExtensions: ['txt', 'md'])),
                    );
                    if (picked != null) {
                      pathCtrl.text = picked;
                      setDialogState(() => checkResult = null);
                    }
                  },
                  icon: const Icon(Icons.folder_open_outlined, size: 16),
                  label: const Text('Duyệt file'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final exists = File(pathCtrl.text.trim()).existsSync();
                    setDialogState(() => checkResult = exists ? '✓ File tồn tại' : '✗ Không tìm thấy file');
                  },
                  icon: const Icon(Icons.fact_check_outlined, size: 16),
                  label: const Text('Kiểm tra'),
                ),
              ),
            ]),
            if (checkResult != null)
              Text(checkResult!, style: TextStyle(color: checkResult!.startsWith('✓') ? Colors.green : Colors.red, fontSize: 12)),
            const SizedBox(height: 4),
            const Text(
              'Chỉ hỗ trợ file văn bản thuần (.txt, .md) ở bản này. PDF/DOCX/ảnh sẽ thêm sau.',
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Đính kèm')),
          ],
        );
      }),
    );
    if (ok == true && pathCtrl.text.trim().isNotEmpty) {
      try {
        await docService.importFromPath(pathCtrl.text.trim(), novelId: widget.novelId);
        _load();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    }
  }

  // Prompt mặc định — hiện ra sẵn trong ô chỉnh sửa để người dùng biết
  // Lấy prompt đã lưu (hoặc mặc định) cho từng loại thao tác.
  Future<String> _defaultPromptFor(DocumentAction action, String novelId) async {
    final settings = SettingsService();
    return action == DocumentAction.translate
        ? await settings.loadDocTranslatePrompt(novelId)
        : await settings.loadDocSummarizePrompt(novelId);
  }

  // Hộp thoại cấu hình trước khi xử lý tài liệu — gồm 3 phần:
  //   1. Chọn model: "Model chính" (active trong Cài đặt) hoặc "Model dịch
  //      ngôn ngữ" (slot 1, model nhỏ cấu hình ở Dịch thuật trung gian).
  //      Chỉ 2 lựa chọn này — không có model sinh văn bản riêng ở đây vì
  //      model chính đã được quản lý tập trung trong tab Cài đặt.
  //   2. Prompt hướng dẫn — load từ Settings (lần trước đã gõ gì thì hiện
  //      lại), lưu lại sau khi xác nhận.
  //   3. Phạm vi đoạn cần xử lý.
  Future<({String prompt, int start, int end, String modelChoice})?> _askProcessConfig(
    DocumentAction action,
    ImportedDocument doc,
  ) async {
    final settings = SettingsService();
    final savedPrompt = await _defaultPromptFor(action, doc.novelId);
    final savedModelChoice = await settings.loadDocModelChoice(doc.novelId);
    final translationModelPath = await settings.loadTranslationModelPath(doc.novelId);
    final hasTranslationModel = translationModelPath != null && translationModelPath.isNotEmpty;

    final ctrl = TextEditingController(text: savedPrompt);
    final maxIndex = (doc.chunkCount - 1).clamp(0, 1 << 30);
    RangeValues range = RangeValues(0, maxIndex.toDouble());
    // Nếu lần trước chọn model dịch nhưng giờ chưa cấu hình, reset về 'active'
    String modelChoice = (savedModelChoice == 'translation' && !hasTranslationModel)
        ? 'active'
        : savedModelChoice;

    return showDialog<({String prompt, int start, int end, String modelChoice})>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (dialogCtx, setDialogState) => AlertDialog(
          title: Text(action == DocumentAction.translate ? 'Cấu hình dịch thuật' : 'Cấu hình tóm tắt'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              // ── Chọn model ──────────────────────────────────────────
              const Text('Model xử lý', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 4),
              // Model chính = model active đang chọn trong tab Cài đặt
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('Model chính (đang chọn trong Cài đặt)'),
                subtitle: const Text('Dùng model đang active, giống chat và viết chương', style: TextStyle(fontSize: 11)),
                value: 'active',
                groupValue: modelChoice,
                onChanged: (v) => setDialogState(() => modelChoice = v!),
              ),
              // Model dịch ngôn ngữ = slot 1, cấu hình ở Dịch thuật trung gian
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(
                  hasTranslationModel
                      ? 'Model dịch ngôn ngữ (slot 1)'
                      : 'Model dịch ngôn ngữ — chưa cấu hình',
                  style: TextStyle(color: hasTranslationModel ? null : Colors.grey),
                ),
                subtitle: Text(
                  hasTranslationModel
                      ? 'Model nhỏ (0.3B–1.5B) cấu hình ở Dịch thuật trung gian — dịch nhanh hơn, ít tốn RAM'
                      : 'Vào Cài đặt → Dịch thuật trung gian → mục 1 để thêm model',
                  style: const TextStyle(fontSize: 11),
                ),
                value: 'translation',
                groupValue: modelChoice,
                onChanged: hasTranslationModel ? (v) => setDialogState(() => modelChoice = v!) : null,
              ),
              const Divider(height: 20),
              // ── Prompt ──────────────────────────────────────────────
              const Text('Prompt hướng dẫn', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 4),
              const Text(
                'AI nhận prompt này trước mỗi đoạn. Được lưu lại cho lần sau.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: ctrl,
                maxLines: 5,
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
              const SizedBox(height: 16),
              // ── Phạm vi đoạn ────────────────────────────────────────
              Text(
                'Phạm vi: đoạn ${range.start.round() + 1} → ${range.end.round() + 1} / ${doc.chunkCount}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              if (maxIndex > 0)
                RangeSlider(
                  values: range,
                  min: 0,
                  max: maxIndex.toDouble(),
                  divisions: maxIndex > 0 ? maxIndex : null,
                  labels: RangeLabels('${range.start.round() + 1}', '${range.end.round() + 1}'),
                  onChanged: (v) => setDialogState(() => range = v),
                )
              else
                const Text('Tài liệu chỉ có 1 đoạn.', style: TextStyle(fontSize: 12, color: Colors.grey)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogCtx), child: const Text('Hủy')),
            FilledButton(
              onPressed: () => Navigator.pop(dialogCtx, (
                prompt: ctrl.text.trim(),
                start: range.start.round(),
                end: range.end.round(),
                modelChoice: modelChoice,
              )),
              child: const Text('Bắt đầu'),
            ),
          ],
        ),
      ),
    );
  }

  // ĐÃ THÊM: cờ theo dõi ở cấp State (trước đây không có) — dùng để
  // PopScope chặn vuốt back (Android 13+ predictive back) trong lúc đang
  // dịch/tóm tắt tài liệu, tránh mất tiến độ giữa chừng do vuốt lỡ tay.
  bool _processingDoc = false;
  // ĐÃ THÊM: cờ huỷ hợp tác — người dùng bấm nút Huỷ trong hộp thoại tiến
  // trình sẽ bật cờ này, vòng lặp xử lý đoạn kiểm tra giữa mỗi đoạn (dừng
  // SẠCH giữa 2 đoạn, không ngắt dở đoạn đang chạy).
  bool _cancelDocRequested = false;
  // ĐÃ THÊM (theo yêu cầu người dùng: thanh tiến trình dời ra góc màn hình
  // thay vì hộp thoại chặn giữa màn hình) — 2 biến đơn giản đủ dùng, không
  // cần ValueNotifier riêng vì tần suất cập nhật thấp (theo từng đoạn, không
  // theo từng chữ như batch tạo chương).
  int _docDone = 0;
  int _docTotal = 0;
  // ĐÃ THÊM (theo phản hồi người dùng: "các màn hình AI tạo sinh văn bản
  // đều làm theo dạng chữ xuất hiện từng chữ 1 hết chứ" — tài liệu là màn
  // cuối còn thiếu, đã sửa): theo dõi chữ đang sinh của TỪNG đoạn (có thể
  // NHIỀU đoạn cùng lúc nếu provider là GPU remote — giống hệt cách
  // `chapters_batch_generate_screen.dart` đã làm với `_InFlightChapter`).
  final Map<String, String> _inFlightChunks = {};

  // Tạo provider theo lựa chọn trong hộp thoại:
  //   'active'      → model đang active trong tab Cài đặt (currentProvider)
  //   'translation' → model dịch ngôn ngữ slot 1 (cấu hình ở Dịch thuật trung gian)
  Future<dynamic> _providerForChoice(String choice) async {
    if (choice == 'translation') {
      final path = await SettingsService().loadTranslationModelPath(widget.novelId);
      if (path == null || path.isEmpty) {
        throw Exception('Model dịch ngôn ngữ chưa cấu hình — vào Cài đặt → Dịch thuật trung gian');
      }
      return LocalLlamaProvider(modelPath: path, slot: 1, novelId: widget.novelId);
    }
    return SettingsService().currentProvider(widget.novelId);
  }

  Future<void> _process(ImportedDocument doc, DocumentAction action) async {
    final config = await _askProcessConfig(action, doc);
    if (config == null || !mounted) return; // người dùng bấm Hủy

    // Lưu prompt và lựa chọn model để lần sau hiện sẵn
    final settings = SettingsService();
    if (config.prompt.isNotEmpty) {
      if (action == DocumentAction.translate) {
        await settings.saveDocTranslatePrompt(doc.novelId, config.prompt);
      } else {
        await settings.saveDocSummarizePrompt(doc.novelId, config.prompt);
      }
    }
    await settings.saveDocModelChoice(doc.novelId, config.modelChoice);

    int done = 0;
    // ĐÃ SỬA: tổng số giờ tính theo PHẠM VI ĐÃ CHỌN, không phải luôn là
    // toàn bộ tài liệu.
    final total = config.end - config.start + 1;
    _cancelDocRequested = false;
    setState(() {
      _processingDoc = true;
      _docDone = 0;
      _docTotal = total;
      _inFlightChunks.clear();
    });

    try {
      final provider = await _providerForChoice(config.modelChoice);
      await docService.processDocument(
        doc: doc,
        action: action,
        provider: provider,
        customInstruction: config.prompt.isEmpty ? null : config.prompt,
        startIndex: config.start,
        endIndex: config.end,
        isCancelled: () => _cancelDocRequested,
        onProgress: (d, t, {currentText, currentChunkId}) {
          done = d;
          if (!mounted) return;
          setState(() {
            _docDone = d;
            _docTotal = t;
            if (currentChunkId != null) {
              if (currentText != null) {
                _inFlightChunks[currentChunkId] = currentText;
              } else {
                // text == null: đoạn này vừa XONG/LỖI — bỏ khỏi danh sách
                // "đang chạy" (giống quy ước ChapterBatchService).
                _inFlightChunks.remove(currentChunkId);
              }
            }
          });
        },
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            _cancelDocRequested
                ? 'Đã huỷ — hoàn thành $done/$total đoạn trong phạm vi đã chọn, bấm chạy lại để tiếp tục đúng chỗ dừng.'
                : '${action == DocumentAction.translate ? "Đã dịch" : "Đã tóm tắt"} xong $done/$total đoạn trong phạm vi đã chọn — '
                    'bấm nút "Xuất kết quả" để lưu file, hoặc dùng khung chat để hỏi đáp về tài liệu này',
          ),
        ));
      }
      _load();
    } catch (e) {
      // ĐÃ THÊM: gọi _load() cả khi lỗi — nếu là DocumentProcessingAnomalyException
      // (mục 64), 1 số đoạn TRƯỚC đoạn bất thường có thể đã lưu thành công,
      // cần cập nhật lại số đếm "đã xong" trên danh sách để phản ánh đúng.
      _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e'), duration: const Duration(seconds: 8)));
    } finally {
      if (mounted) setState(() => _processingDoc = false);
    }
  }

  // Xuất kết quả (bản dịch HOẶC bản tóm tắt, tùy loại đã xử lý gần nhất)
  // ra file — trước đây chỉ tự động làm việc này cho "Dịch toàn bộ",
  // giờ dùng chung cho cả "Tóm tắt", vì cả hai đều là kết quả đáng lưu.
  // ĐÃ SỬA — theo đúng phản hồi người dùng ("đã là giới hạn tại sao không
  // tìm cách khắc phục"): trước đây gộp hết các chunk thành 1 chuỗi rồi
  // CẮT CỤT ở 6000 ký tự đầu — tài liệu dài mất hẳn phần sau. Giờ truyền
  // TỪNG CHUNK RIÊNG BIỆT vào `extractFromChunks` — tài liệu đã được chia
  // nhỏ sẵn từ lúc import (xem `document_service.dart`), mỗi chunk tự nó
  // đã có kích thước hợp lý — trích HẾT các chunk, không bỏ sót chunk nào,
  // rồi tự gộp+lọc trùng+cảnh báo trùng lặp/grounding ở tầng service.
  Future<void> _extractDocumentToBible(ImportedDocument doc) async {
    final chunks = await db.chunksForDocument(doc.id);
    if (chunks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tài liệu chưa có đoạn nào để trích xuất.')));
      return;
    }
    final provider = await SettingsService().currentProvider(widget.novelId);
    if (!mounted) return;

    // Dialog có thanh tiến trình cập nhật được (StatefulBuilder) — tài
    // liệu nhiều chunk có thể mất vài phút (mỗi chunk là 1 lượt generate()
    // riêng), người dùng cần thấy đang chạy tới đâu, không phải màn hình
    // "loading" đứng im không rõ còn bao lâu.
    String progressText = 'Đang trích xuất đoạn 1/${chunks.length}...';
    late void Function(void Function()) dialogSetState;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) {
          dialogSetState = setState;
          return AlertDialog(
            content: Row(children: [
              const CircularProgressIndicator(),
              const SizedBox(width: 16),
              Expanded(child: Text(progressText)),
            ]),
          );
        },
      ),
    );

    BibleExtractionResult result;
    String? error;
    try {
      result = await BibleExtractionService().extractFromChunks(
        chunks.map((c) => c.originalText).toList(),
        provider: provider,
        novelId: widget.novelId,
        onProgress: (done, total) {
          progressText = 'Đang trích xuất đoạn ${done + 1}/$total...';
          try {
            dialogSetState(() {});
          } catch (_) {
            // Dialog co the da bi dong (nguoi dung thoat man hinh giua
            // chung) — bo qua, khong crash vi 1 lan cap nhat tien trinh
            // tre.
          }
        },
      );
    } catch (e) {
      error = '$e';
      result = BibleExtractionResult(entries: [], totalChunks: chunks.length, failedChunkCount: chunks.length);
    }
    if (!mounted) return;
    Navigator.of(context).pop();
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không trích xuất được: $error')));
      return;
    }
    if (!mounted) return;
    final addedCount = await Navigator.of(context).push<int>(MaterialPageRoute(
      builder: (context) => BibleExtractionReviewScreen(
        novelId: widget.novelId,
        entries: result.entries,
        sourceLabel: 'từ tài liệu "${doc.name}" (${result.totalChunks} đoạn)',
        totalChunks: result.totalChunks,
        failedChunkCount: result.failedChunkCount,
      ),
    ));
    if (addedCount != null && addedCount > 0 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Đã thêm $addedCount mục vào Story Bible.')));
    }
  }

  Future<void> _exportResult(ImportedDocument doc) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final file = await docService.exportResult(doc, dir);
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất file: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: chặn vuốt back (Android 13+ predictive back) trong lúc
    // đang dịch/tóm tắt tài liệu — cùng lý do như chapter_editor_screen.dart.
    return PopScope(
      canPop: !_processingDoc,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Đang xử lý tài liệu — đợi xong trước khi thoát để không mất tiến độ.'),
        ));
      },
      child: Scaffold(
      appBar: AppBar(title: const Text('Tài liệu')),
      floatingActionButton: FloatingActionButton(onPressed: _importDialog, child: const Icon(Icons.add)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Stack(children: [
              Column(children: [
                // ĐÃ THÊM (theo phản hồi người dùng — xem giải thích ở
                // `document_service.dart`): hiện chữ đang sinh TRỰC TIẾP
                // của (các) đoạn đang chạy, y hệt cách
                // `chapters_batch_generate_screen.dart` hiện chương đang
                // chạy — KHÔNG thay thế hẳn danh sách tài liệu bên dưới
                // (người dùng vẫn có thể cần thấy các tài liệu khác), chỉ
                // chèn thêm panel này ở TRÊN khi đang có đoạn chạy.
                if (_inFlightChunks.isNotEmpty)
                  ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.35),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                      shrinkWrap: true,
                      children: _inFlightChunks.entries.map((e) {
                        return Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)),
                                const SizedBox(width: 8),
                                Text('Đang xử lý đoạn...', style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
                              ]),
                              const SizedBox(height: 6),
                              ConstrainedBox(
                                constraints: const BoxConstraints(maxHeight: 100),
                                child: SingleChildScrollView(
                                  reverse: true,
                                  child: Text(e.value, style: const TextStyle(fontSize: 13)),
                                ),
                              ),
                            ]),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                Expanded(
                  child: documents.isEmpty
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                          'Đính kèm file .txt/.md để dịch cuốn chiếu, tóm tắt, hoặc hỏi đáp về nội dung trong khung chat.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    )
                  : ListView.builder(
                  itemCount: documents.length,
                  itemBuilder: (context, i) {
                    final doc = documents[i];
                    final done = _doneCounts[doc.id] ?? 0;
                    // ĐÃ THÊM: có tiến độ dở dang (đã dịch/tóm tắt được
                    // 1 phần, chưa xong hết) → đổi nhãn nút thành "Tiếp
                    // tục" kèm số đoạn đã xong, thay vì luôn ghi "Dịch
                    // toàn bộ"/"Tóm tắt" như thể chưa từng chạy — trả lời
                    // đúng câu hỏi "sao không có nút tiếp tục nhiệm vụ
                    // dang dở": NÚT ĐÃ CÓ SẴN (processDocument() tự bỏ
                    // qua đoạn đã xong nhờ resumeFromProgress — mục 55),
                    // chỉ là trước đây không có gì hiện lên để biết còn
                    // dở dang hay không, dễ hiểu lầm là phải làm lại từ đầu.
                    final hasProgress = done > 0 && done < doc.chunkCount;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(doc.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                          Row(children: [
                            Text('${doc.chunkCount} đoạn', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                            if (hasProgress) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primaryContainer,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  'Dang dở: $done/${doc.chunkCount} đoạn đã xong',
                                  style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onPrimaryContainer),
                                ),
                              ),
                            ] else if (done >= doc.chunkCount && doc.chunkCount > 0) ...[
                              const SizedBox(width: 8),
                              const Icon(Icons.check_circle, size: 14, color: Colors.green),
                            ],
                          ]),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            // ĐÃ THÊM: mở màn hình chọn từng đoạn cụ thể — hữu
                            // ích nhất khi 1 đoạn cụ thể hay gây crash (mục
                            // 5.62), có thể bỏ qua đúng đoạn đó, xử lý các
                            // đoạn khác trước.
                            OutlinedButton.icon(
                              onPressed: () async {
                                await Navigator.push(context, MaterialPageRoute(builder: (_) => DocumentChunksScreen(doc: doc)));
                                _load(); // làm mới số đoạn đã xong sau khi quay lại
                              },
                              icon: const Icon(Icons.view_list_outlined, size: 16),
                              label: const Text('Chọn từng đoạn'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.translate),
                              icon: Icon(hasProgress ? Icons.play_arrow : Icons.translate, size: 16),
                              label: Text(hasProgress ? 'Tiếp tục dịch ($done/${doc.chunkCount})' : 'Dịch toàn bộ'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.summarize),
                              icon: Icon(hasProgress ? Icons.play_arrow : Icons.summarize_outlined, size: 16),
                              label: Text(hasProgress ? 'Tiếp tục tóm tắt ($done/${doc.chunkCount})' : 'Tóm tắt'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _exportResult(doc),
                              icon: const Icon(Icons.ios_share_outlined, size: 16),
                              label: const Text('Xuất kết quả'),
                            ),
                            // ĐÃ THÊM — mục BJ, 2026-09-20: trích nội dung tài
                            // liệu này (bản gốc, chưa cần dịch/tóm tắt xong)
                            // thành đề xuất Story Bible — theo đúng yêu cầu
                            // người dùng "up tài liệu bible vào rồi tự cập
                            // nhật vào bible".
                            OutlinedButton.icon(
                              onPressed: () => _extractDocumentToBible(doc),
                              icon: const Icon(Icons.auto_stories_outlined, size: 16),
                              label: const Text('Trích vào Bible'),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () async {
                                await db.deleteDocument(doc.id);
                                _load();
                              },
                            ),
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
                ),
              ]),
              // ĐÃ THÊM (theo yêu cầu người dùng: thanh tiến trình dời ra
              // góc màn hình thay vì hộp thoại chặn giữa màn hình) — thẻ
              // nhỏ nổi ở góc dưới phải, chỉ hiện khi đang xử lý, thay cho
              // AlertDialog `barrierDismissible: false` trước đây.
              if (_processingDoc)
                Positioned(
                  right: 12,
                  bottom: 12,
                  child: Material(
                    elevation: 6,
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      width: 220,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                      ),
                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text('Đã xong $_docDone/$_docTotal đoạn', style: const TextStyle(fontSize: 12))),
                          InkWell(
                            onTap: () => setState(() => _cancelDocRequested = true),
                            child: const Padding(
                              padding: EdgeInsets.all(2),
                              child: Icon(Icons.close, size: 16),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 6),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: _docTotal > 0 ? _docDone / _docTotal : null,
                            minHeight: 6,
                          ),
                        ),
                      ]),
                    ),
                  ),
                ),
            ]),
      ),
    );
  }
}
