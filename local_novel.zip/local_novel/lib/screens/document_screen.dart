import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/document_service.dart';
import '../services/settings_service.dart';
import 'file_browser_screen.dart';

class DocumentScreen extends StatefulWidget {
  final String novelId;
  const DocumentScreen({super.key, required this.novelId});
  @override
  State<DocumentScreen> createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  final db = DatabaseService.instance;
  late final DocumentService docService = DocumentService(db);
  List<ImportedDocument> documents = [];
  bool loading = true;
  // ĐÃ THÊM: đếm số đoạn ĐÃ DỊCH (giá trị lớn nhất giữa số đoạn có bản
  // dịch và số đoạn có bản tóm tắt — 2 thao tác độc lập, dùng chung 1 cột
  // resultText nên không phân biệt được loại nào, nhưng đủ để biết tài
  // liệu có tiến độ dở dang hay chưa) — hiện lên danh sách để người dùng
  // BIẾT RÕ có nhiệm vụ dang dở trước khi bấm nút, không cần đoán mò.
  Map<String, int> _doneCounts = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant DocumentScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final all = await db.allDocuments(widget.novelId);
    // ĐÃ THÊM: tải kèm số đoạn đã có kết quả cho từng tài liệu, để hiện
    // tiến độ dở dang trên danh sách — không load hết nội dung đoạn, chỉ
    // đếm, nên không tốn nhiều bộ nhớ/thời gian dù tài liệu dài.
    final doneCounts = <String, int>{};
    for (final doc in all) {
      final chunks = await db.chunksForDocument(doc.id);
      doneCounts[doc.id] = chunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length;
    }
    if (!mounted) return;
    setState(() {
      documents = all;
      _doneCounts = doneCounts;
      loading = false;
    });
  }

  Future<void> _importDialog() async {
    final pathCtrl = TextEditingController();
    String? checkResult;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Đính kèm tài liệu (.txt, .md)'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Đường dẫn file',
                hintText: '/storage/emulated/0/Download/truyen.txt',
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await Navigator.push<String>(
                      context,
                      MaterialPageRoute(builder: (_) => const FileBrowserScreen(allowedExtensions: ['txt', 'md'])),
                    );
                    if (picked != null) {
                      pathCtrl.text = picked;
                      setDialogState(() => checkResult = null);
                    }
                  },
                  icon: const Icon(Icons.folder_open_outlined, size: 16),
                  label: const Text('Duyệt file'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final exists = File(pathCtrl.text.trim()).existsSync();
                    setDialogState(() => checkResult = exists ? '✓ File tồn tại' : '✗ Không tìm thấy file');
                  },
                  icon: const Icon(Icons.fact_check_outlined, size: 16),
                  label: const Text('Kiểm tra'),
                ),
              ),
            ]),
            if (checkResult != null)
              Text(checkResult!, style: TextStyle(color: checkResult!.startsWith('✓') ? Colors.green : Colors.red, fontSize: 12)),
            const SizedBox(height: 4),
            const Text(
              'Chỉ hỗ trợ file văn bản thuần (.txt, .md) ở bản này. PDF/DOCX/ảnh sẽ thêm sau.',
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Đính kèm')),
          ],
        );
      }),
    );
    if (ok == true && pathCtrl.text.trim().isNotEmpty) {
      try {
        await docService.importFromPath(pathCtrl.text.trim(), novelId: widget.novelId);
        _load();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    }
  }

  // Prompt mặc định — hiện ra sẵn trong ô chỉnh sửa để người dùng biết
  // đang dùng gì và có thể đổi trước khi chạy, thay vì cố định cứng
  // không cho tùy chỉnh như trước.
  String _defaultPromptFor(DocumentAction action) => action == DocumentAction.translate
      ? 'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.'
      : 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.';

  // ĐÃ THÊM: gộp prompt + phạm vi đoạn cần xử lý vào 1 hộp thoại — trước
  // đây chỉ hỏi prompt, LUÔN xử lý toàn bộ tài liệu. Với tài liệu rất dài,
  // người dùng có thể chỉ muốn dịch/tóm tắt 1 phần cụ thể trước.
  Future<({String prompt, int start, int end})?> _askProcessConfig(DocumentAction action, ImportedDocument doc) async {
    final ctrl = TextEditingController(text: _defaultPromptFor(action));
    final maxIndex = (doc.chunkCount - 1).clamp(0, 1 << 30);
    RangeValues range = RangeValues(0, maxIndex.toDouble());
    return showDialog<({String prompt, int start, int end})>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(action == DocumentAction.translate ? 'Cấu hình dịch thuật' : 'Cấu hình tóm tắt'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text(
                'Chỉnh sửa hướng dẫn AI sẽ dùng cho MỖI đoạn văn bản (áp dụng cho toàn bộ phạm vi đã chọn).',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: ctrl,
                maxLines: 5,
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
              const SizedBox(height: 16),
              Text(
                'Phạm vi đoạn: ${range.start.round() + 1} → ${range.end.round() + 1} / ${doc.chunkCount} đoạn',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              if (maxIndex > 0)
                RangeSlider(
                  values: range,
                  min: 0,
                  max: maxIndex.toDouble(),
                  divisions: maxIndex > 0 ? maxIndex : null,
                  labels: RangeLabels('${range.start.round() + 1}', '${range.end.round() + 1}'),
                  onChanged: (v) => setDialogState(() => range = v),
                )
              else
                const Text('Tài liệu chỉ có 1 đoạn.', style: TextStyle(fontSize: 12, color: Colors.grey)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
            FilledButton(
              onPressed: () => Navigator.pop(context, (
                prompt: ctrl.text.trim(),
                start: range.start.round(),
                end: range.end.round(),
              )),
              child: const Text('Bắt đầu'),
            ),
          ],
        ),
      ),
    );
  }

  // ĐÃ THÊM: cờ theo dõi ở cấp State (trước đây không có) — dùng để
  // PopScope chặn vuốt back (Android 13+ predictive back) trong lúc đang
  // dịch/tóm tắt tài liệu, tránh mất tiến độ giữa chừng do vuốt lỡ tay.
  bool _processingDoc = false;
  // ĐÃ THÊM: cờ huỷ hợp tác — người dùng bấm nút Huỷ trong hộp thoại tiến
  // trình sẽ bật cờ này, vòng lặp xử lý đoạn kiểm tra giữa mỗi đoạn (dừng
  // SẠCH giữa 2 đoạn, không ngắt dở đoạn đang chạy).
  bool _cancelDocRequested = false;

  Future<void> _process(ImportedDocument doc, DocumentAction action) async {
    final config = await _askProcessConfig(action, doc);
    if (config == null || !mounted) return; // người dùng bấm Hủy

    int done = 0;
    // ĐÃ SỬA: tổng số giờ tính theo PHẠM VI ĐÃ CHỌN, không phải luôn là
    // toàn bộ tài liệu.
    final total = config.end - config.start + 1;
    final progressNotifier = ValueNotifier<double>(0);
    _cancelDocRequested = false;
    setState(() => _processingDoc = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text(action == DocumentAction.translate ? 'Đang dịch...' : 'Đang tóm tắt...'),
        content: ValueListenableBuilder<double>(
          valueListenable: progressNotifier,
          builder: (context, value, _) => Column(mainAxisSize: MainAxisSize.min, children: [
            // ĐÃ THÊM: thanh tiến trình % thật thay vì chỉ có spinner tròn.
            LinearProgressIndicator(value: total > 0 ? value : null),
            const SizedBox(height: 12),
            Text('Đã xong ${(value * total).round()}/$total đoạn (${(value * 100).round()}%)'),
          ]),
        ),
        actions: [
          // ĐÃ THÊM: nút Huỷ rõ ràng — trước đây chỉ có thể chặn vuốt back
          // (PopScope) chứ không có cách chủ động dừng sạch giữa chừng.
          TextButton(
            onPressed: () {
              _cancelDocRequested = true;
              Navigator.pop(dialogContext);
            },
            child: const Text('Huỷ'),
          ),
        ],
      ),
    );

    try {
      final provider = await SettingsService().currentProvider();
      await docService.processDocument(
        doc: doc,
        action: action,
        provider: provider,
        customInstruction: config.prompt.isEmpty ? null : config.prompt,
        startIndex: config.start,
        endIndex: config.end,
        isCancelled: () => _cancelDocRequested,
        onProgress: (d, t) {
          done = d;
          progressNotifier.value = t > 0 ? d / t : 0;
        },
      );
      if (mounted && !_cancelDocRequested) Navigator.pop(context);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            _cancelDocRequested
                ? 'Đã huỷ — hoàn thành $done/$total đoạn trong phạm vi đã chọn, bấm chạy lại để tiếp tục đúng chỗ dừng.'
                : '${action == DocumentAction.translate ? "Đã dịch" : "Đã tóm tắt"} xong $done/$total đoạn trong phạm vi đã chọn — '
                    'bấm nút "Xuất kết quả" để lưu file, hoặc dùng khung chat để hỏi đáp về tài liệu này',
          ),
        ));
      }
      _load();
    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) setState(() => _processingDoc = false);
    }
  }

  // Xuất kết quả (bản dịch HOẶC bản tóm tắt, tùy loại đã xử lý gần nhất)
  // ra file — trước đây chỉ tự động làm việc này cho "Dịch toàn bộ",
  // giờ dùng chung cho cả "Tóm tắt", vì cả hai đều là kết quả đáng lưu.
  Future<void> _exportResult(ImportedDocument doc) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final file = await docService.exportResult(doc, dir);
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất file: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    // ĐÃ THÊM: chặn vuốt back (Android 13+ predictive back) trong lúc
    // đang dịch/tóm tắt tài liệu — cùng lý do như chapter_editor_screen.dart.
    return PopScope(
      canPop: !_processingDoc,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Đang xử lý tài liệu — đợi xong trước khi thoát để không mất tiến độ.'),
        ));
      },
      child: Scaffold(
      appBar: AppBar(title: const Text('Tài liệu')),
      floatingActionButton: FloatingActionButton(onPressed: _importDialog, child: const Icon(Icons.add)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : documents.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Đính kèm file .txt/.md để dịch cuốn chiếu, tóm tắt, hoặc hỏi đáp về nội dung trong khung chat.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: documents.length,
                  itemBuilder: (context, i) {
                    final doc = documents[i];
                    final done = _doneCounts[doc.id] ?? 0;
                    // ĐÃ THÊM: có tiến độ dở dang (đã dịch/tóm tắt được
                    // 1 phần, chưa xong hết) → đổi nhãn nút thành "Tiếp
                    // tục" kèm số đoạn đã xong, thay vì luôn ghi "Dịch
                    // toàn bộ"/"Tóm tắt" như thể chưa từng chạy — trả lời
                    // đúng câu hỏi "sao không có nút tiếp tục nhiệm vụ
                    // dang dở": NÚT ĐÃ CÓ SẴN (processDocument() tự bỏ
                    // qua đoạn đã xong nhờ resumeFromProgress — mục 55),
                    // chỉ là trước đây không có gì hiện lên để biết còn
                    // dở dang hay không, dễ hiểu lầm là phải làm lại từ đầu.
                    final hasProgress = done > 0 && done < doc.chunkCount;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(doc.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                          Row(children: [
                            Text('${doc.chunkCount} đoạn', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                            if (hasProgress) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primaryContainer,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  'Dang dở: $done/${doc.chunkCount} đoạn đã xong',
                                  style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onPrimaryContainer),
                                ),
                              ),
                            ] else if (done >= doc.chunkCount && doc.chunkCount > 0) ...[
                              const SizedBox(width: 8),
                              const Icon(Icons.check_circle, size: 14, color: Colors.green),
                            ],
                          ]),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.translate),
                              icon: Icon(hasProgress ? Icons.play_arrow : Icons.translate, size: 16),
                              label: Text(hasProgress ? 'Tiếp tục dịch ($done/${doc.chunkCount})' : 'Dịch toàn bộ'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _process(doc, DocumentAction.summarize),
                              icon: Icon(hasProgress ? Icons.play_arrow : Icons.summarize_outlined, size: 16),
                              label: Text(hasProgress ? 'Tiếp tục tóm tắt ($done/${doc.chunkCount})' : 'Tóm tắt'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _exportResult(doc),
                              icon: const Icon(Icons.ios_share_outlined, size: 16),
                              label: const Text('Xuất kết quả'),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () async {
                                await db.deleteDocument(doc.id);
                                _load();
                              },
                            ),
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
      ),
    );
  }
}
