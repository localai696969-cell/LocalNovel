import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/providers/local_provider.dart';

// Trình duyệt file tự viết bằng dart:io — không dùng file_picker hay bất
// kỳ package ngoài nào (đã gây lỗi build nhiều lần trước đây với những
// package tương tự).
//
// ĐÃ ĐỔI (theo yêu cầu người dùng: "cứ như các ứng dụng khác là có nút
// gạt, ko phải bắt người dùng mất công cài đặt thủ công"): khi
// pickDirectory=true, màn này giờ TỰ ĐỘNG thử mở picker hệ thống
// (Storage Access Framework, ACTION_OPEN_DOCUMENT_TREE) ngay khi mở lên
// — 1 chạm, không cần rời app sang Cài đặt. Chỉ khi picker không resolve
// được đường dẫn thật (thường do chọn thẻ nhớ ngoài/USB) mới cần tới
// quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE) và duyệt thủ công
// bằng dart:io như trước — giữ nguyên làm phương án dự phòng, không xoá.
class FileBrowserScreen extends StatefulWidget {
  final List<String>? allowedExtensions; // vd: ['txt','md'] — bỏ qua khi pickDirectory=true
  final bool pickDirectory;
  const FileBrowserScreen({super.key, this.allowedExtensions, this.pickDirectory = false});

  @override
  State<FileBrowserScreen> createState() => _FileBrowserScreenState();
}

class _FileBrowserScreenState extends State<FileBrowserScreen> {
  Directory currentDir = Directory('/storage/emulated/0');
  List<FileSystemEntity> entries = [];
  String? errorMsg;
  bool tryingQuickPick = false;

  @override
  void initState() {
    super.initState();
    if (widget.pickDirectory) {
      // Tự thử ngay khi mở màn — nếu người dùng chọn xong thành công,
      // họ sẽ không bao giờ thấy màn duyệt thủ công bên dưới cả.
      _tryQuickPick(auto: true);
    } else {
      _list();
    }
  }

  // Trả về true nếu đã xử lý xong (chọn được path hoặc pop màn hình) —
  // false nghĩa là rơi về/ở lại màn duyệt thủ công.
  Future<void> _tryQuickPick({required bool auto}) async {
    setState(() => tryingQuickPick = true);
    try {
      final path = await LocalLlamaProvider.pickModelFolder();
      if (!mounted) return;
      if (path != null) {
        Navigator.pop(context, path);
        return;
      }
      // path == null: người dùng bấm huỷ trong picker — không phải lỗi,
      // chỉ cần ở lại màn duyệt thủ công để họ tự tìm nếu muốn.
      setState(() {
        tryingQuickPick = false;
        if (entries.isEmpty && errorMsg == null) _list();
      });
    } on PlatformException catch (e) {
      if (!mounted) return;
      if (e.code == 'PATH_UNRESOLVED') {
        setState(() => tryingQuickPick = false);
        _showUnresolvedPathDialog();
      } else {
        // 'NO_PICKER' (thiết bị quá cũ) hoặc lỗi khác — âm thầm rơi về
        // duyệt thủ công, không cần làm phiền người dùng bằng lỗi kỹ
        // thuật nếu đây là lần tự động thử lúc mở màn.
        setState(() {
          tryingQuickPick = false;
          if (entries.isEmpty && errorMsg == null) _list();
        });
        if (!auto) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Không mở được picker: ${e.message ?? e.code}')),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        tryingQuickPick = false;
        if (entries.isEmpty && errorMsg == null) _list();
      });
    }
  }

  void _showUnresolvedPathDialog() {
    showDialog(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Không xác định được đường dẫn'),
        content: const Text(
          'Thư mục vừa chọn có vẻ nằm trên thẻ nhớ ngoài/USB — Android không cho biết đường dẫn thật '
          'của thư mục đó trong trường hợp này. Bạn có thể:\n\n'
          '• Duyệt thủ công bên dưới (cần quyền "Truy cập mọi tệp" — vào Cài đặt → Tối ưu AI local để cấp), hoặc\n'
          '• Copy model vào bộ nhớ TRONG máy rồi thử lại cách chọn nhanh này.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(dialogCtx);
              if (entries.isEmpty && errorMsg == null) _list();
            },
            child: const Text('Duyệt thủ công'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(dialogCtx);
              _tryQuickPick(auto: false);
            },
            child: const Text('Thử lại'),
          ),
        ],
      ),
    );
  }

  Future<void> _list() async {
    setState(() => errorMsg = null);
    try {
      final all = currentDir.listSync();
      all.sort((a, b) {
        final aDir = a is Directory;
        final bDir = b is Directory;
        if (aDir != bDir) return aDir ? -1 : 1; // thư mục lên trước
        return a.path.toLowerCase().compareTo(b.path.toLowerCase());
      });
      final filtered = all.where((e) {
        if (e is Directory) return true;
        if (widget.pickDirectory) return false; // chế độ chọn thư mục: ẩn hết file lẻ, đỡ rối
        if (widget.allowedExtensions == null) return true;
        final ext = e.path.split('.').last.toLowerCase();
        return widget.allowedExtensions!.contains(ext);
      }).toList();
      setState(() => entries = filtered);
    } catch (e) {
      setState(() {
        entries = [];
        errorMsg = 'Không đọc được thư mục này (thiếu quyền hoặc thư mục hệ thống): $e';
      });
    }
  }

  void _openDir(Directory d) {
    setState(() => currentDir = d);
    _list();
  }

  bool get _canGoUp => currentDir.path != '/storage/emulated/0' && currentDir.parent.path.startsWith('/storage/emulated/0');

  @override
  Widget build(BuildContext context) {
    // Đang tự động thử picker hệ thống lúc vừa mở màn — hiện loading thay
    // vì để lộ ra màn duyệt thủ công trong chớp mắt rồi biến mất ngay,
    // gây giật hình khi picker mở thành công.
    if (tryingQuickPick) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(currentDir.path.replaceFirst('/storage/emulated/0', 'Bộ nhớ trong'), overflow: TextOverflow.ellipsis),
        actions: [
          if (widget.pickDirectory)
            IconButton(
              onPressed: () => _tryQuickPick(auto: false),
              icon: const Icon(Icons.touch_app_outlined),
              tooltip: 'Chọn nhanh (1 chạm, không cần quyền)',
            ),
          if (widget.pickDirectory)
            TextButton(
              onPressed: () => Navigator.pop(context, currentDir.path),
              child: const Text('Chọn thư mục này', style: TextStyle(color: Colors.white)),
            ),
        ],
      ),
      body: Column(children: [
        if (widget.pickDirectory)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3),
            child: Row(children: [
              const Icon(Icons.touch_app_outlined, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Bấm biểu tượng chạm ở góc trên để chọn nhanh 1 lần, không cần cấp quyền gì cả '
                  '(hoạt động với bộ nhớ trong máy).',
                  style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onPrimaryContainer),
                ),
              ),
            ]),
          ),
        if (errorMsg != null)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(errorMsg!, style: const TextStyle(color: Colors.red, fontSize: 12)),
          ),
        if (widget.pickDirectory)
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Text(
              'Hoặc duyệt thủ công tới đúng thư mục chứa model (có file config.json + .mnn bên trong), '
              'rồi bấm "Chọn thư mục này" ở góc trên — cần quyền "Truy cập mọi tệp" (Cài đặt → Tối ưu AI local).',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ),
        Expanded(
          child: ListView(children: [
            if (_canGoUp)
              ListTile(
                leading: const Icon(Icons.arrow_upward),
                title: const Text('.. (lên thư mục cha)'),
                onTap: () => _openDir(currentDir.parent),
              ),
            ...entries.map((e) {
              final isDir = e is Directory;
              final label = e.path.split('/').last;
              return ListTile(
                leading: Icon(isDir ? Icons.folder_outlined : Icons.insert_drive_file_outlined),
                title: Text(label),
                onTap: () {
                  if (isDir) {
                    _openDir(e as Directory);
                  } else {
                    Navigator.pop(context, e.path);
                  }
                },
              );
            }),
          ]),
        ),
      ]),
    );
  }
}
