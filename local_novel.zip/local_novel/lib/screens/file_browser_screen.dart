import 'dart:io';
import 'package:flutter/material.dart';

// Trình duyệt file tự viết bằng dart:io — không dùng file_picker hay bất
// kỳ package ngoài nào (đã gây lỗi build nhiều lần trước đây với những
// package tương tự). Cần quyền MANAGE_EXTERNAL_STORAGE đã khai báo ở
// AndroidManifest mới duyệt được ra ngoài thư mục riêng của app.
class FileBrowserScreen extends StatefulWidget {
  final List<String>? allowedExtensions; // vd: ['gguf'] hoặc ['txt','md']
  const FileBrowserScreen({super.key, this.allowedExtensions});

  @override
  State<FileBrowserScreen> createState() => _FileBrowserScreenState();
}

class _FileBrowserScreenState extends State<FileBrowserScreen> {
  Directory currentDir = Directory('/storage/emulated/0');
  List<FileSystemEntity> entries = [];
  String? errorMsg;

  @override
  void initState() {
    super.initState();
    _list();
  }

  Future<void> _list() async {
    setState(() => errorMsg = null);
    try {
      final all = currentDir.listSync();
      all.sort((a, b) {
        final aDir = a is Directory;
        final bDir = b is Directory;
        if (aDir != bDir) return aDir ? -1 : 1; // thư mục lên trước
        return a.path.toLowerCase().compareTo(b.path.toLowerCase());
      });
      final filtered = all.where((e) {
        if (e is Directory) return true;
        if (widget.allowedExtensions == null) return true;
        final ext = e.path.split('.').last.toLowerCase();
        return widget.allowedExtensions!.contains(ext);
      }).toList();
      setState(() => entries = filtered);
    } catch (e) {
      setState(() {
        entries = [];
        errorMsg = 'Không đọc được thư mục này (thiếu quyền hoặc thư mục hệ thống): $e';
      });
    }
  }

  void _openDir(Directory d) {
    setState(() => currentDir = d);
    _list();
  }

  bool get _canGoUp => currentDir.path != '/storage/emulated/0' && currentDir.parent.path.startsWith('/storage/emulated/0');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(currentDir.path.replaceFirst('/storage/emulated/0', 'Bộ nhớ trong'), overflow: TextOverflow.ellipsis),
      ),
      body: Column(children: [
        if (errorMsg != null)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(errorMsg!, style: const TextStyle(color: Colors.red, fontSize: 12)),
          ),
        Expanded(
          child: ListView(children: [
            if (_canGoUp)
              ListTile(
                leading: const Icon(Icons.arrow_upward),
                title: const Text('.. (lên thư mục cha)'),
                onTap: () => _openDir(currentDir.parent),
              ),
            ...entries.map((e) {
              final isDir = e is Directory;
              final label = e.path.split('/').last;
              return ListTile(
                leading: Icon(isDir ? Icons.folder_outlined : Icons.insert_drive_file_outlined),
                title: Text(label),
                onTap: () {
                  if (isDir) {
                    _openDir(e as Directory);
                  } else {
                    Navigator.pop(context, e.path);
                  }
                },
              );
            }),
          ]),
        ),
      ]),
    );
  }
}
