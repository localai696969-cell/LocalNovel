import 'dart:io';
import 'package:flutter/material.dart';
import '../services/providers/local_provider.dart';

// Trình duyệt file tự viết bằng dart:io — không dùng file_picker hay bất
// kỳ package ngoài nào (đã gây lỗi build nhiều lần trước đây với những
// package tương tự).
//
// ĐÃ THỬ RỒI BỎ (xem mục 5.75 tài liệu kiến trúc): từng thêm chọn nhanh
// qua Storage Access Framework (SAF) — xác nhận qua log thật là KHÔNG
// hoạt động cho nhu cầu app này. SAF chỉ cấp quyền đọc qua content://
// URI, KHÔNG cấp quyền đọc trực tiếp bằng đường dẫn hệ thống file thường
// (dart:io Directory/File, và code native fopen/opendir dùng để mmap
// model) — dù suy ra được "đường dẫn thật" bằng chuỗi, đọc vẫn thất bại
// (thư mục hiện rỗng dù có file thật, xác nhận qua log thiết bị thật).
// File manager thật (đã tra cứu xác nhận) dùng ĐÚNG 1 cơ chế:
// MANAGE_EXTERNAL_STORAGE — xin quyền 1 lần, dùng được cho MỌI thư mục
// mãi mãi, đúng nhu cầu app này (đổi model, đính tài liệu, khôi phục
// backup — đều là duyệt thư mục bất kỳ, lặp lại nhiều lần, không phải
// import 1 lần rồi thôi). Route SAF chỉ hợp với việc import ĐÚNG 1 file
// vào bộ nhớ riêng app (theo đúng cách llama.cpp Android chính thức làm)
// — không hợp bản chất nhu cầu ở đây, đã bỏ hẳn.
class FileBrowserScreen extends StatefulWidget {
  final List<String>? allowedExtensions; // vd: ['txt','md'] — bỏ qua khi pickDirectory=true
  final bool pickDirectory;
  const FileBrowserScreen({super.key, this.allowedExtensions, this.pickDirectory = false});

  @override
  State<FileBrowserScreen> createState() => _FileBrowserScreenState();
}

class _FileBrowserScreenState extends State<FileBrowserScreen> {
  Directory currentDir = Directory('/storage/emulated/0');
  List<FileSystemEntity> entries = [];
  String? errorMsg;
  bool hasPermission = true; // lạc quan ban đầu, _list() sẽ cập nhật lại nếu sai
  bool checkingPermission = true;
  bool requestingPermission = false;

  @override
  void initState() {
    super.initState();
    _checkPermissionThenList();
  }

  Future<void> _checkPermissionThenList() async {
    final has = await LocalLlamaProvider.hasManageStoragePermission();
    if (!mounted) return;
    setState(() {
      hasPermission = has;
      checkingPermission = false;
    });
    if (has) _list();
  }

  Future<void> _requestPermissionNow() async {
    setState(() => requestingPermission = true);
    await LocalLlamaProvider.requestManageStoragePermission();
    // Không biết chính xác lúc nào người dùng gạt xong công tắc và quay
    // lại app — đợi 1 khoảng rồi tự kiểm tra lại, giống cách đã làm ở
    // màn "Tối ưu AI local" cho quyền pin.
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    final has = await LocalLlamaProvider.hasManageStoragePermission();
    setState(() {
      hasPermission = has;
      requestingPermission = false;
    });
    if (has) _list();
  }

  Future<void> _list() async {
    setState(() => errorMsg = null);
    try {
      final all = currentDir.listSync();
      all.sort((a, b) {
        final aDir = a is Directory;
        final bDir = b is Directory;
        if (aDir != bDir) return aDir ? -1 : 1; // thư mục lên trước
        return a.path.toLowerCase().compareTo(b.path.toLowerCase());
      });
      final filtered = all.where((e) {
        if (e is Directory) return true;
        if (widget.pickDirectory) return false; // chế độ chọn thư mục: ẩn hết file lẻ, đỡ rối
        if (widget.allowedExtensions == null) return true;
        final ext = e.path.split('.').last.toLowerCase();
        return widget.allowedExtensions!.contains(ext);
      }).toList();
      setState(() => entries = filtered);
    } catch (e) {
      setState(() {
        entries = [];
        errorMsg = 'Không đọc được thư mục này: $e';
      });
    }
  }

  void _openDir(Directory d) {
    setState(() => currentDir = d);
    _list();
  }

  bool get _canGoUp => currentDir.path != '/storage/emulated/0' && currentDir.parent.path.startsWith('/storage/emulated/0');

  @override
  Widget build(BuildContext context) {
    if (checkingPermission) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // Chưa có quyền — hiện màn xin quyền NGAY TẠI ĐÂY, không bắt người
    // dùng tự điều hướng qua Cài đặt → Tối ưu AI local để tìm nút.
    if (!hasPermission) {
      return Scaffold(
        appBar: AppBar(title: const Text('Cần cấp quyền')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.folder_off_outlined, size: 56, color: Colors.grey.shade500),
              const SizedBox(height: 16),
              const Text(
                'Cần quyền "Truy cập mọi tệp" để duyệt được thư mục ngoài app '
                '(chọn model AI, đính tài liệu, khôi phục backup...).',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14),
              ),
              const SizedBox(height: 4),
              Text(
                'Chỉ cần cấp 1 LẦN DUY NHẤT — dùng được cho mọi thư mục sau này, không phải xin lại.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: requestingPermission ? null : _requestPermissionNow,
                icon: requestingPermission
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.folder_open_outlined),
                label: Text(requestingPermission ? 'Đang mở Cài đặt...' : 'Cấp quyền ngay'),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: _checkPermissionThenList,
                child: const Text('Đã cấp rồi, kiểm tra lại'),
              ),
            ]),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(currentDir.path.replaceFirst('/storage/emulated/0', 'Bộ nhớ trong'), overflow: TextOverflow.ellipsis),
        actions: widget.pickDirectory
            ? [
                TextButton(
                  onPressed: () => Navigator.pop(context, currentDir.path),
                  child: const Text('Chọn thư mục này', style: TextStyle(color: Colors.white)),
                ),
              ]
            : null,
      ),
      body: Column(children: [
        if (errorMsg != null)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(errorMsg!, style: const TextStyle(color: Colors.red, fontSize: 12)),
          ),
        if (widget.pickDirectory)
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Text(
              'Duyệt tới đúng thư mục chứa model (có file config.json + .mnn bên trong), '
              'rồi bấm "Chọn thư mục này" ở góc trên — không bấm vào file bên trong.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ),
        Expanded(
          child: ListView(children: [
            if (_canGoUp)
              ListTile(
                leading: const Icon(Icons.arrow_upward),
                title: const Text('.. (lên thư mục cha)'),
                onTap: () => _openDir(currentDir.parent),
              ),
            ...entries.map((e) {
              final isDir = e is Directory;
              final label = e.path.split('/').last;
              return ListTile(
                leading: Icon(isDir ? Icons.folder_outlined : Icons.insert_drive_file_outlined),
                title: Text(label),
                onTap: () {
                  if (isDir) {
                    _openDir(e as Directory);
                  } else {
                    Navigator.pop(context, e.path);
                  }
                },
              );
            }),
          ]),
        ),
      ]),
    );
  }
}
