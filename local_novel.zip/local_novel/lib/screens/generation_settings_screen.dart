import 'package:flutter/material.dart';
import '../services/settings_service.dart';

class GenerationSettingsScreen extends StatefulWidget {
  const GenerationSettingsScreen({super.key});
  @override
  State<GenerationSettingsScreen> createState() => _GenerationSettingsScreenState();
}

class _GenerationSettingsScreenState extends State<GenerationSettingsScreen> {
  final settings = SettingsService();
  double temperature = 0.8;
  double topP = 0.9;
  int topK = 40;
  double repetitionPenalty = 1.05;
  int maxNewTokens = 1024;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await settings.loadGenerationConfig();
    setState(() {
      temperature = cfg.temperature;
      topP = cfg.topP;
      topK = cfg.topK;
      repetitionPenalty = cfg.repetitionPenalty;
      maxNewTokens = cfg.maxNewTokens;
      loading = false;
    });
  }

  Future<void> _save() async {
    await settings.saveGenerationConfig(
      temperature: temperature,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      maxNewTokens: maxNewTokens,
    );
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu — áp dụng ngay từ lần sinh văn bản tiếp theo, không cần nạp lại model')));
  }

  Widget _sliderRow({
    required String label,
    required String helpText,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required void Function(double) onChanged,
    String Function(double)? displayFormat,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
          Text(displayFormat?.call(value) ?? value.toStringAsFixed(2)),
        ]),
        Text(helpText, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        Slider(value: value, min: min, max: max, divisions: divisions, onChanged: onChanged),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Tham số sinh văn bản'), actions: [
        TextButton(onPressed: _save, child: const Text('Lưu', style: TextStyle(color: Colors.white))),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text(
          'Áp dụng cho model chính (viết chương + chat) — model dịch thuật trung '
          'gian (nếu bật) dùng cấu hình cố định riêng, ưu tiên chính xác hơn sáng tạo.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const Divider(height: 24),
        _sliderRow(
          label: 'Temperature',
          helpText: 'Độ sáng tạo/ngẫu nhiên. Thấp → văn chắc chắn, dễ lặp khuôn mẫu. Cao → đa dạng hơn nhưng dễ lạc đề nếu quá cao.',
          value: temperature,
          min: 0.1,
          max: 1.5,
          divisions: 28,
          onChanged: (v) => setState(() => temperature = v),
        ),
        _sliderRow(
          label: 'top_p (nucleus sampling)',
          helpText: 'Chỉ chọn trong nhóm từ có tổng xác suất cộng dồn đạt tới p. Giá trị phổ biến: 0.9.',
          value: topP,
          min: 0.1,
          max: 1.0,
          divisions: 18,
          onChanged: (v) => setState(() => topP = v),
        ),
        _sliderRow(
          label: 'top_k',
          helpText: 'Chỉ chọn trong đúng k từ có xác suất cao nhất tại mỗi bước. Giá trị phổ biến: 40.',
          value: topK.toDouble(),
          min: 1,
          max: 100,
          divisions: 99,
          displayFormat: (v) => v.round().toString(),
          onChanged: (v) => setState(() => topK = v.round()),
        ),
        _sliderRow(
          label: 'repetition_penalty',
          helpText: 'Phạt các từ/cụm đã xuất hiện trước đó — tăng lên nếu thấy AI lặp từ vô nghĩa.',
          value: repetitionPenalty,
          min: 1.0,
          max: 2.0,
          divisions: 20,
          onChanged: (v) => setState(() => repetitionPenalty = v),
        ),
        _sliderRow(
          label: 'max_new_tokens (độ dài tối đa mỗi lần sinh)',
          helpText: 'Giới hạn độ dài đoạn văn AI sinh ra mỗi lần — không phải giới hạn tổng ngữ cảnh (context_length quản lý riêng ở RAG, xem "Tối ưu AI local").',
          value: maxNewTokens.toDouble(),
          min: 128,
          max: 4096,
          divisions: 31,
          displayFormat: (v) => v.round().toString(),
          onChanged: (v) => setState(() => maxNewTokens = v.round()),
        ),
      ]),
    );
  }
}
