import 'package:flutter/material.dart';
import '../services/settings_service.dart';
import '../services/database_service.dart';

class GenerationSettingsScreen extends StatefulWidget {
  // ĐÃ SỬA (v13 — theo câu hỏi người dùng: "cài đặt riêng từng truyện hay
  // chung cả app?"): 4 cài đặt "Tự tóm tắt cốt truyện luỹ kế" bên dưới giờ
  // RIÊNG CHO TỪNG TRUYỆN (đọc/ghi cột trong bảng `novels`), bắt buộc phải
  // biết đang ở truyện nào — 5 tham số sinh văn bản (temperature...) ở
  // TRÊN vẫn CHUNG toàn app như cũ (tài nguyên máy/model, không phải nội
  // dung truyện, xem mục 2.1 tài liệu kiến trúc).
  final String novelId;
  const GenerationSettingsScreen({super.key, required this.novelId});
  @override
  State<GenerationSettingsScreen> createState() => _GenerationSettingsScreenState();
}

class _GenerationSettingsScreenState extends State<GenerationSettingsScreen> {
  final settings = SettingsService();
  final db = DatabaseService.instance;
  double temperature = 0.8;
  double topP = 0.9;
  int topK = 40;
  double repetitionPenalty = 1.05;
  int maxNewTokens = 1024;
  bool loading = true;
  // ĐÃ THÊM (theo câu hỏi người dùng: "có làm ai local chậm hơn không nếu
  // chương phình to") — xem giải thích chi phí đầy đủ ở
  // RagService.updateCumulativeStorySummary().
  bool plotSummaryEnabled = true;
  int plotSummaryInterval = 1;
  // ĐÃ THÊM (theo đề xuất người dùng — nguồn rẻ hơn thay vì luôn đọc lại
  // toàn bộ nội dung chương): xem giải thích đầy đủ ở story_models.dart
  // (Novel.plotSummaryPreferTimeline/PreferOutline) và RagService.
  bool plotSummaryPreferTimeline = true;
  bool plotSummaryPreferOutline = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await settings.loadGenerationConfig();
    final novel = await db.novelById(widget.novelId);
    setState(() {
      temperature = cfg.temperature;
      topP = cfg.topP;
      topK = cfg.topK;
      repetitionPenalty = cfg.repetitionPenalty;
      maxNewTokens = cfg.maxNewTokens;
      // novel == null không nên xảy ra (novelId truyền vào luôn là truyện
      // đang active) — nếu có, giữ mặc định an toàn thay vì crash màn hình.
      plotSummaryEnabled = novel?.plotSummaryEnabled ?? true;
      plotSummaryInterval = novel?.plotSummaryInterval ?? 1;
      plotSummaryPreferTimeline = novel?.plotSummaryPreferTimeline ?? true;
      plotSummaryPreferOutline = novel?.plotSummaryPreferOutline ?? true;
      loading = false;
    });
  }

  Future<void> _save() async {
    await settings.saveGenerationConfig(
      temperature: temperature,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      maxNewTokens: maxNewTokens,
    );
    await db.updateNovelPlotSummarySettings(
      widget.novelId,
      enabled: plotSummaryEnabled,
      interval: plotSummaryInterval,
      preferTimeline: plotSummaryPreferTimeline,
      preferOutline: plotSummaryPreferOutline,
    );
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu — áp dụng ngay từ lần sinh văn bản tiếp theo, không cần nạp lại model')));
  }

  Widget _sliderRow({
    required String label,
    required String helpText,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required void Function(double) onChanged,
    String Function(double)? displayFormat,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
          Text(displayFormat?.call(value) ?? value.toStringAsFixed(2)),
        ]),
        Text(helpText, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        Slider(value: value, min: min, max: max, divisions: divisions, onChanged: onChanged),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Tham số sinh văn bản'), actions: [
        TextButton(onPressed: _save, child: const Text('Lưu', style: TextStyle(color: Colors.white))),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text(
          'Áp dụng cho model chính (viết chương + chat) — model dịch thuật trung '
          'gian (nếu bật) dùng cấu hình cố định riêng, ưu tiên chính xác hơn sáng tạo.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const Divider(height: 24),
        _sliderRow(
          label: 'Temperature',
          helpText: 'Độ sáng tạo/ngẫu nhiên. Thấp → văn chắc chắn, dễ lặp khuôn mẫu. Cao → đa dạng hơn nhưng dễ lạc đề nếu quá cao.',
          value: temperature,
          min: 0.1,
          max: 1.5,
          divisions: 28,
          onChanged: (v) => setState(() => temperature = v),
        ),
        _sliderRow(
          label: 'top_p (nucleus sampling)',
          helpText: 'Chỉ chọn trong nhóm từ có tổng xác suất cộng dồn đạt tới p. Giá trị phổ biến: 0.9.',
          value: topP,
          min: 0.1,
          max: 1.0,
          divisions: 18,
          onChanged: (v) => setState(() => topP = v),
        ),
        _sliderRow(
          label: 'top_k',
          helpText: 'Chỉ chọn trong đúng k từ có xác suất cao nhất tại mỗi bước. Giá trị phổ biến: 40.',
          value: topK.toDouble(),
          min: 1,
          max: 100,
          divisions: 99,
          displayFormat: (v) => v.round().toString(),
          onChanged: (v) => setState(() => topK = v.round()),
        ),
        _sliderRow(
          label: 'repetition_penalty',
          helpText: 'Phạt các từ/cụm đã xuất hiện trước đó — tăng lên nếu thấy AI lặp từ vô nghĩa.',
          value: repetitionPenalty,
          min: 1.0,
          max: 2.0,
          divisions: 20,
          onChanged: (v) => setState(() => repetitionPenalty = v),
        ),
        _sliderRow(
          label: 'max_new_tokens (độ dài tối đa mỗi lần sinh)',
          helpText: 'Giới hạn độ dài đoạn văn AI sinh ra mỗi lần — không phải giới hạn tổng ngữ cảnh (context_length quản lý riêng ở RAG, xem "Tối ưu AI local").',
          value: maxNewTokens.toDouble(),
          min: 128,
          max: 4096,
          divisions: 31,
          displayFormat: (v) => v.round().toString(),
          onChanged: (v) => setState(() => maxNewTokens = v.round()),
        ),
        const Divider(height: 32),
        Row(children: [
          Expanded(
            child: Text('Tự tóm tắt cốt truyện luỹ kế', style: Theme.of(context).textTheme.titleSmall),
          ),
          Switch(value: plotSummaryEnabled, onChanged: (v) => setState(() => plotSummaryEnabled = v)),
        ]),
        const Text(
          // ĐÃ SỬA (v13): ghi rõ đây là cài đặt RIÊNG CHO TRUYỆN ĐANG MỞ,
          // không còn dùng chung cho mọi truyện — trước đây gây hiểu lầm
          // hợp lý (đổi ở đây tưởng ảnh hưởng truyện khác đang viết cùng
          // lúc, thực ra không).
          'Riêng cho truyện đang mở. Sau mỗi chương hoàn thành, AI nén thêm vào 1 bản tóm tắt '
          'cốt truyện luỹ kế, LUÔN được đưa vào ngữ cảnh ở mọi chương sau — kể cả chương cách xa '
          'hàng trăm chương — để tránh viết mâu thuẫn với chuyện đã xảy ra từ lâu.\n'
          'Đánh đổi: tốn THÊM 1 lượt gọi AI riêng sau mỗi chương (dùng model chính, có thể '
          'nặng nếu đang chạy model local), và mọi chương viết SAU đó đều cõng thêm ngữ cảnh '
          'này vào prompt — máy yếu chạy model local sẽ thấy rõ chậm hơn. Tắt hẳn nếu ưu tiên '
          'tốc độ hơn độ đồng bộ xuyên suốt truyện dài.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        if (plotSummaryEnabled) ...[
          const SizedBox(height: 8),
          _sliderRow(
            label: 'Giãn cách cập nhật (số chương)',
            helpText: '1 = cập nhật sau MỖI chương (đồng bộ chặt nhất, tốn AI nhiều nhất). '
                'Tăng lên để gộp nhiều chương mới gọi AI 1 lần — giảm số lượt gọi phụ trội đúng '
                'theo hệ số này, đổi lại tóm tắt "cũ" hơn tối đa (N-1) chương tại bất kỳ lúc nào '
                '(không mất dữ liệu, chỉ gộp trễ hơn).',
            value: plotSummaryInterval.toDouble(),
            min: 1,
            max: 20,
            divisions: 19,
            displayFormat: (v) => v.round().toString(),
            onChanged: (v) => setState(() => plotSummaryInterval = v.round()),
          ),
          const SizedBox(height: 8),
          // ĐÃ THÊM (theo đề xuất người dùng — ưu tiên nguồn RẺ HƠN thay vì
          // luôn đọc lại toàn bộ nội dung chương): xem giải thích đầy đủ ở
          // story_models.dart và RagService._doUpdateCumulativeStorySummary.
          Row(children: [
            Expanded(
              child: Text('Ưu tiên Dòng thời gian (nếu chương đã có)', style: Theme.of(context).textTheme.bodyMedium),
            ),
            Switch(value: plotSummaryPreferTimeline, onChanged: (v) => setState(() => plotSummaryPreferTimeline = v)),
          ]),
          const Text(
            'Nếu chương vừa xong đã có sẵn sự kiện Dòng thời gian (tự nhập tay hoặc bấm "AI gợi ý"), '
            'dùng đúng các sự kiện đó làm nguyên liệu nén tóm tắt — ngắn gọn hơn, đã lọc qua Bách '
            'khoa, KHÔNG tốn thêm lượt gọi AI nào để lấy. Không tự tạo sự kiện mới ở đây; chương nào '
            'chưa có Dòng thời gian thì rơi xuống nguồn tiếp theo bên dưới.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: Text('Ưu tiên dàn ý/outline (nếu chương đã có)', style: Theme.of(context).textTheme.bodyMedium),
            ),
            Switch(value: plotSummaryPreferOutline, onChanged: (v) => setState(() => plotSummaryPreferOutline = v)),
          ]),
          const Text(
            'Dùng dàn ý đã viết sẵn của chương (thường có với "Tạo chương hàng loạt") thay vì đọc '
            'lại nội dung — rẻ nhất vì có TRƯỚC khi chương tồn tại. Xếp SAU Dòng thời gian ở trên: '
            'dàn ý là KẾ HOẠCH, có thể lệch so với nội dung THỰC SỰ đã viết ra nếu AI đắp thịt khác '
            'outline. Chương không có cả 2 nguồn trên vẫn dùng cách cũ (đọc autoSummary/nội dung).',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ]),
    );
  }
}
