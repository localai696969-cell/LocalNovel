import 'package:flutter/material.dart';
import '../models/device_profile.dart';
import '../services/device_profile_service.dart';
import '../services/benchmark_service.dart';
import '../services/settings_service.dart';
import '../services/translation_service.dart';

class LocalOptimizationScreen extends StatefulWidget {
  const LocalOptimizationScreen({super.key});
  @override
  State<LocalOptimizationScreen> createState() => _LocalOptimizationScreenState();
}

class _LocalOptimizationScreenState extends State<LocalOptimizationScreen> {
  DeviceProfile? profile;
  String deviceLabel = '';
  bool recognized = false;
  bool loading = true;
  bool benchmarking = false;
  bool applying = false;
  BenchmarkResult? result;

  final List<DeviceProfile> manualOverrides = knownChipsetProfiles.values.toList();
  DeviceProfile? overrideChoice;

  // Cho phép người dùng tinh chỉnh tay sau khi áp dụng gợi ý ban đầu.
  int threads = 4;
  int contextSize = 2048;
  int gpuLayers = 99;

  // Mục "Dịch thuật trung gian" đã hứa hẹn trong translation_settings_screen
  // ("xem Tối ưu AI local để biết máy có nên giữ cả 2 model trong RAM hay
  // không") — trước đây màn này chưa thực sự hiển thị phần đó, giờ thêm vào.
  int totalRamMb = 0;
  String keepResidentMode = 'auto'; // 'auto' | 'always' | 'never'
  int backendPreference = 0; // 0 = tự QNN trước, 1 = ép GPU, 2 = ép CPU

  @override
  void initState() {
    super.initState();
    _detect();
  }

  Future<void> _detect() async {
    setState(() => loading = true);
    final r = await DeviceProfileService().detect();
    final current = await SettingsService().loadLocalInferenceConfig();
    final ramMb = await DeviceProfileService().readTotalRamMb();
    final mode = await SettingsService().loadTranslationKeepResidentMode();
    final backend = await SettingsService().loadBackendPreference();
    setState(() {
      profile = r.profile;
      deviceLabel = r.deviceLabel;
      recognized = r.recognized;
      threads = current.threads;
      contextSize = current.contextSize;
      gpuLayers = current.numGpuLayers;
      totalRamMb = ramMb;
      keepResidentMode = mode;
      backendPreference = backend;
      loading = false;
    });
  }

  void _fillFromProfile(DeviceProfile p) {
    setState(() {
      threads = p.recommendedThreads;
      contextSize = p.recommendedContext;
      gpuLayers = p.gpuOffloadLikely ? 99 : 0;
    });
  }

  // Áp dụng ngay lập tức — vì model chạy cùng tiến trình app (fllama),
  // không có bước "khởi động lại server" nào cả. Lần sinh văn bản tiếp
  // theo sẽ dùng ngay cấu hình mới.
  Future<void> _applyNow() async {
    setState(() => applying = true);
    try {
      await SettingsService().saveLocalInferenceConfig(
        threads: threads,
        contextSize: contextSize,
        numGpuLayers: gpuLayers,
      );
      if (profile != null) {
        await SettingsService().saveRagBudget((overrideChoice ?? profile!).ragContextBudgetChars);
      }
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Đã áp dụng — có hiệu lực ngay từ lần sinh văn bản tiếp theo')));
      }
    } finally {
      if (mounted) setState(() => applying = false);
    }
  }

  Future<void> _setKeepResidentMode(String mode) async {
    setState(() => keepResidentMode = mode);
    await SettingsService().saveTranslationKeepResidentMode(mode);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu — có hiệu lực từ lượt dịch tiếp theo')));
    }
  }

  Future<void> _setBackendPreference(int value) async {
    setState(() => backendPreference = value);
    await SettingsService().saveBackendPreference(value);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Đã lưu — có hiệu lực từ lần nạp model tiếp theo (đóng mở lại app để chắc chắn)'),
      ));
    }
  }

  Future<void> _runBenchmark() async {
    setState(() => benchmarking = true);
    try {
      final provider = await SettingsService().currentProvider();
      final r = await BenchmarkService().run(provider);
      setState(() => result = r);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi đo tốc độ: $e')));
    } finally {
      setState(() => benchmarking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = overrideChoice ?? profile;
    return Scaffold(
      appBar: AppBar(title: const Text('Tối ưu AI local')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Thiết bị: $deviceLabel', style: const TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(
                        recognized
                            ? 'Đã nhận diện chipset: ${profile!.chipsetLabel}'
                            : 'Không nhận diện được chipset cụ thể — dùng ước lượng theo RAM (${profile!.chipsetLabel}).',
                        style: TextStyle(fontSize: 12, color: recognized ? Colors.green.shade700 : Colors.orange.shade700),
                      ),
                    ]),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<DeviceProfile?>(
                  value: overrideChoice,
                  decoration: const InputDecoration(labelText: 'Ghi đè hồ sơ thủ công (nếu tự nhận diện sai)', border: OutlineInputBorder()),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('Dùng kết quả tự nhận diện')),
                    ...manualOverrides.map((p) => DropdownMenuItem(value: p, child: Text(p.tierName))),
                  ],
                  onChanged: (v) {
                    setState(() => overrideChoice = v);
                    _fillFromProfile(v ?? profile!);
                  },
                ),
                if (active != null) ...[
                  const SizedBox(height: 8),
                  TextButton.icon(
                    onPressed: () => _fillFromProfile(active),
                    icon: const Icon(Icons.auto_fix_high_outlined, size: 16),
                    label: const Text('Điền lại theo gợi ý cho hồ sơ này'),
                  ),
                  Text(active.note, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  const SizedBox(height: 8),
                  Text('Mức quantize khuyến nghị khi tải model: ${active.recommendedQuant}',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
                ],
                const Divider(height: 32),
                Text('Tham số suy luận (có hiệu lực ngay khi áp dụng)', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _slider('Số luồng CPU (threads)', threads, 1, 8, (v) => setState(() => threads = v)),
                _slider('Context size', contextSize, 512, 8192, (v) => setState(() => contextSize = v), step: 512),
                _slider('GPU layers (0 = tắt GPU offload)', gpuLayers, 0, 99, (v) => setState(() => gpuLayers = v)),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: applying ? null : _applyNow,
                  icon: applying
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.check_circle_outline),
                  label: const Text('Áp dụng ngay'),
                ),
                const Divider(height: 32),
                Text('Dịch thuật trung gian — giữ model trong RAM', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Khi bật "Dịch thuật trung gian" (Cài đặt → Dịch thuật trung gian), máy cần chạy '
                  'tuần tự 2 model (model dịch + model chính). Giữ model dịch trong RAM suốt phiên '
                  'làm việc giúp đỡ mất thời gian nạp lại nhiều lần, nhưng tốn thêm RAM có thể làm '
                  'chậm/crash model chính trên máy ít RAM.',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                Text(
                  totalRamMb > 0
                      ? 'RAM máy phát hiện được: ~${(totalRamMb / 1024).toStringAsFixed(1)} GB '
                          '(ngưỡng tự động giữ RAM: ${(TranslationService.ramKeepResidentThresholdMb / 1024).toStringAsFixed(1)} GB)'
                      : 'Không đọc được tổng RAM máy — chế độ "Tự động" sẽ luôn xả model dịch sau mỗi lần dùng để an toàn.',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'auto', label: Text('Tự động theo RAM')),
                    ButtonSegment(value: 'always', label: Text('Luôn giữ')),
                    ButtonSegment(value: 'never', label: Text('Luôn xả')),
                  ],
                  selected: {keepResidentMode},
                  onSelectionChanged: (s) => _setKeepResidentMode(s.first),
                ),
                const SizedBox(height: 4),
                Text(
                  keepResidentMode == 'auto'
                      ? (totalRamMb >= TranslationService.ramKeepResidentThresholdMb
                          ? '→ Quyết định hiện tại: GIỮ model dịch trong RAM suốt phiên (máy đủ RAM).'
                          : '→ Quyết định hiện tại: XẢ model dịch ngay sau mỗi lần dùng (máy ít RAM).')
                      : (keepResidentMode == 'always'
                          ? '→ Luôn giữ model dịch trong RAM suốt phiên, bất kể máy nhiều hay ít RAM.'
                          : '→ Luôn xả model dịch ngay sau mỗi lần dùng, bất kể máy nhiều hay ít RAM.'),
                  style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                ),
                const Divider(height: 32),
                Text('Backend ưu tiên cho model local', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Đổi được ngay ở đây, KHÔNG cần build lại app. Hữu ích nếu chat/đo tốc độ bị '
                  'thoát app đột ngột (crash) — thử đổi qua GPU hoặc CPU để xem còn crash không, '
                  'giúp khoanh vùng đúng backend nào đang có vấn đề.',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('Tự động (QNN trước)')),
                    ButtonSegment(value: 1, label: Text('Ép GPU')),
                    ButtonSegment(value: 2, label: Text('Ép CPU')),
                  ],
                  selected: {backendPreference},
                  onSelectionChanged: (s) => _setBackendPreference(s.first),
                ),
                const Divider(height: 32),
                Text('Đo tốc độ thực tế', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                const Text(
                  'Chạy một đoạn sinh văn ngắn cố định với cấu hình đang áp dụng, đo tốc độ để biết đã ổn chưa.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: benchmarking ? null : _runBenchmark,
                  icon: benchmarking
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.speed_outlined),
                  label: Text(benchmarking ? 'Đang đo...' : 'Đo tốc độ ngay'),
                ),
                if (result != null) ...[
                  const SizedBox(height: 12),
                  Card(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('~${result!.tokensPerSecond.toStringAsFixed(1)} token/giây (ước lượng)',
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text('${result!.wordCount} từ trong ${result!.elapsed.inMilliseconds}ms', style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 6),
                        Text(_advice(result!.tokensPerSecond), style: const TextStyle(fontSize: 12)),
                      ]),
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  Widget _slider(String label, int value, int min, int max, ValueChanged<int> onChanged, {int step = 1}) {
    final divisions = ((max - min) / step).round();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('$label: $value', style: const TextStyle(fontSize: 13)),
      Slider(
        value: value.toDouble(),
        min: min.toDouble(),
        max: max.toDouble(),
        divisions: divisions,
        label: '$value',
        onChanged: (v) => onChanged(v.round()),
      ),
    ]);
  }

  String _advice(double tps) {
    if (tps >= 8) return 'Tốc độ tốt cho viết tương tác liên tục.';
    if (tps >= 3) {
      return 'Tốc độ chấp nhận được nhưng hơi chậm. Thử giảm context hoặc dùng model nhỏ hơn nếu cần mượt hơn.';
    }
    return 'Khá chậm. Kiểm tra: GPU layers có > 0 chưa? Model có đang ở Q4_K_M trở xuống không? '
        'Nếu vẫn chậm, cân nhắc đổi model nhỏ hơn (2-4B) hoặc dùng API cho các thao tác cần phản hồi nhanh.';
  }
}
