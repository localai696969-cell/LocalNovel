import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import 'chapter_editor_screen.dart';

// Tìm kiếm toàn văn trong TOÀN BỘ chương của 1 truyện — tầng DB (FTS4,
// `chapters_fts`) đã có sẵn từ trước (searchChapters trong
// database_service.dart), màn này chỉ là phần UI còn thiếu để dùng được
// tính năng đó (trước đây chỉ có RAG dùng ngầm, không có ô tìm kiếm cho
// người dùng tự tra cứu).
class SearchScreen extends StatefulWidget {
  final String novelId;
  const SearchScreen({super.key, required this.novelId});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final db = DatabaseService.instance;
  final queryCtrl = TextEditingController();
  List<Chapter> results = [];
  bool searching = false;
  bool searchedOnce = false;
  String? errorMsg;

  Future<void> _search(String query) async {
    final q = query.trim();
    if (q.isEmpty) {
      setState(() {
        results = [];
        searchedOnce = false;
        errorMsg = null;
      });
      return;
    }
    setState(() {
      searching = true;
      errorMsg = null;
    });
    try {
      // FTS4 hiểu cú pháp truy vấn riêng (AND/OR/dấu ngoặc kép cho cụm từ
      // chính xác...) — người dùng gõ bình thường vẫn hoạt động vì FTS4 tự
      // coi nhiều từ cách nhau là AND theo mặc định.
      final found = await db.searchChapters(widget.novelId, q);
      if (!mounted) return;
      setState(() {
        results = found;
        searching = false;
        searchedOnce = true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        searching = false;
        searchedOnce = true;
        errorMsg = 'Không tìm được (có thể do ký tự đặc biệt trong ô tìm kiếm): $e';
      });
    }
  }

  // Cắt 1 đoạn ngắn quanh vị trí từ khóa xuất hiện đầu tiên trong chương,
  // để người dùng biết ngữ cảnh mà không cần mở cả chương ra đọc.
  String _snippet(Chapter c, String query) {
    final content = c.content;
    final terms = query.trim().split(RegExp(r'\s+')).where((t) => t.isNotEmpty);
    int foundAt = -1;
    for (final t in terms) {
      final idx = content.toLowerCase().indexOf(t.toLowerCase());
      if (idx != -1 && (foundAt == -1 || idx < foundAt)) foundAt = idx;
    }
    if (foundAt == -1) {
      return content.length > 140 ? '${content.substring(0, 140)}...' : content;
    }
    final start = (foundAt - 60).clamp(0, content.length);
    final end = (foundAt + 100).clamp(0, content.length);
    final prefix = start > 0 ? '...' : '';
    final suffix = end < content.length ? '...' : '';
    return '$prefix${content.substring(start, end).trim()}$suffix';
  }

  @override
  void dispose() {
    queryCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: queryCtrl,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Tìm trong toàn bộ chương...',
            border: InputBorder.none,
          ),
          style: const TextStyle(fontSize: 18),
          textInputAction: TextInputAction.search,
          onSubmitted: _search,
          onChanged: (v) {
            // Tìm kiếm ngay khi gõ, nhưng không debounce phức tạp — FTS4
            // trên vài nghìn chương vẫn đủ nhanh để tìm theo từng ký tự.
            _search(v);
          },
        ),
        actions: [
          if (queryCtrl.text.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear),
              onPressed: () {
                queryCtrl.clear();
                _search('');
              },
            ),
        ],
      ),
      body: Builder(builder: (context) {
        if (searching) {
          return const Center(child: CircularProgressIndicator());
        }
        if (errorMsg != null) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(errorMsg!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
            ),
          );
        }
        if (!searchedOnce) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Gõ từ khóa để tìm trong toàn bộ nội dung các chương của truyện này '
                '(tên nhân vật, địa danh, tình tiết...).',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            ),
          );
        }
        if (results.isEmpty) {
          return const Center(child: Text('Không tìm thấy kết quả nào.'));
        }
        return ListView.separated(
          itemCount: results.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final c = results[i];
            return ListTile(
              title: Text('Chương ${c.number}: ${c.title}'),
              subtitle: Text(_snippet(c, queryCtrl.text), maxLines: 2, overflow: TextOverflow.ellipsis),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: c))),
            );
          },
        );
      }),
    );
  }
}
