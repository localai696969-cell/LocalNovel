import 'dart:io';
import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/ai_provider.dart';
import '../services/settings_service.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import 'local_optimization_screen.dart';
import 'file_browser_screen.dart';
import 'generation_settings_screen.dart';
import 'translation_settings_screen.dart';
import 'backup_restore_screen.dart';
import 'debug_log_screen.dart';
import '../main.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final settings = SettingsService();
  AIProviderType selected = AIProviderType.localLlama;
  List<LocalModelEntry> localModels = [];
  String? activeLocalModelId;
  List<ApiProviderEntry> apiProviders = [];
  String? activeApiProviderId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final type = await settings.loadProviderType();
    final models = await settings.allLocalModels();
    final activeModelId = await settings.loadActiveLocalModelId();
    final providers = await settings.allApiProviders();
    final activeProviderId = await settings.loadActiveApiProviderId();
    setState(() {
      selected = type;
      localModels = models;
      activeLocalModelId = activeModelId;
      apiProviders = providers;
      activeApiProviderId = activeProviderId;
    });
  }

  Future<void> _addLocalModelDialog() async {
    final nameCtrl = TextEditingController();
    final pathCtrl = TextEditingController();
    String? checkResult;
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Thêm model local'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên gợi nhớ (vd: Qwen 4B)')),
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Thư mục model MNN (chứa config.json + file .mnn)',
                hintText: '/storage/emulated/0/Download/qwen2-1.5b-mnn',
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: Text(
                'Lưu ý: engine hiện tại (MNN) không dùng trực tiếp file .gguf — '
                'cần model đã convert sang định dạng MNN (1 thư mục, không phải 1 file lẻ).',
                style: TextStyle(fontSize: 11, color: Colors.orange),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await Navigator.push<String>(
                      context,
                      MaterialPageRoute(builder: (_) => const FileBrowserScreen(pickDirectory: true)),
                    );
                    if (picked != null) {
                      pathCtrl.text = picked;
                      setDialogState(() => checkResult = null);
                    }
                  },
                  icon: const Icon(Icons.folder_open_outlined, size: 16),
                  label: const Text('Duyệt thư mục'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final dir = Directory(pathCtrl.text.trim());
                    final exists = dir.existsSync();
                    final hasConfig = exists &&
                        (File('${dir.path}/config.json').existsSync() || File('${dir.path}/llm_config.json').existsSync());
                    setDialogState(() => checkResult = hasConfig
                        ? '✓ Thư mục hợp lệ (có config)'
                        : exists
                            ? '⚠ Thư mục tồn tại nhưng không thấy config.json — kiểm tra lại'
                            : '✗ Không tìm thấy thư mục');
                  },
                  icon: const Icon(Icons.fact_check_outlined, size: 16),
                  label: const Text('Kiểm tra'),
                ),
              ),
            ]),
            if (checkResult != null)
              Text(checkResult!, style: TextStyle(color: checkResult!.startsWith('✓') ? Colors.green : Colors.red, fontSize: 12)),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Thêm')),
          ],
        );
      }),
    );
    if (result == true && pathCtrl.text.trim().isNotEmpty) {
      final name = nameCtrl.text.trim().isEmpty ? pathCtrl.text.split('/').last : nameCtrl.text.trim();
      await settings.addLocalModel(name, pathCtrl.text.trim());
      _load();
    }
  }

  Future<void> _addApiProviderDialog() async {
    final nameCtrl = TextEditingController();
    final baseUrlCtrl = TextEditingController(text: 'https://api.openai.com/v1');
    final modelIdCtrl = TextEditingController();
    final apiKeyCtrl = TextEditingController();
    String type = 'openai_compatible';

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Thêm API provider'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên gợi nhớ (vd: Groq, Together...)')),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: 'Loại'),
                items: const [
                  DropdownMenuItem(value: 'openai_compatible', child: Text('Tương thích OpenAI (tự nhập URL)')),
                  DropdownMenuItem(value: 'anthropic', child: Text('Anthropic (Claude)')),
                ],
                onChanged: (v) => setDialogState(() => type = v ?? 'openai_compatible'),
              ),
              if (type == 'openai_compatible')
                TextField(controller: baseUrlCtrl, decoration: const InputDecoration(labelText: 'Base URL')),
              TextField(controller: modelIdCtrl, decoration: const InputDecoration(labelText: 'Model ID (vd: gpt-4o, llama-3.1-70b...)')),
              TextField(controller: apiKeyCtrl, decoration: const InputDecoration(labelText: 'API key'), obscureText: true),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Thêm')),
          ],
        );
      }),
    );
    if (result == true && nameCtrl.text.trim().isNotEmpty) {
      await settings.addApiProvider(
        name: nameCtrl.text.trim(),
        type: type,
        baseUrl: type == 'openai_compatible' ? baseUrlCtrl.text.trim() : null,
        modelId: modelIdCtrl.text.trim(),
        apiKey: apiKeyCtrl.text.trim(),
      );
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt AI')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.swap_horiz_outlined),
              title: const Text('Đổi truyện'),
              subtitle: const Text('Quay lại danh sách truyện để tạo mới hoặc chuyển sang truyện khác'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const NovelListScreen()),
                (route) => false,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.speed_outlined),
              title: const Text('Tối ưu AI local cho máy này'),
              subtitle: const Text('Nhận diện chip, gợi ý cấu hình, đo tốc độ thực tế'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LocalOptimizationScreen())),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.tune_outlined),
              title: const Text('Tham số sinh văn bản'),
              subtitle: const Text('temperature, top_p, top_k, repetition_penalty, độ dài tối đa'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GenerationSettingsScreen())),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.translate_outlined),
              title: const Text('Dịch thuật trung gian'),
              subtitle: const Text('Tùy chọn: dịch qua ngôn ngữ model hiểu tốt rồi dịch ngược, chống lỗi tiếng Việt ngô nghê'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TranslationSettingsScreen())),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.bug_report_outlined),
              title: const Text('Log debug'),
              subtitle: const Text('Xem log ghi ra file — hữu ích khi app bị đóng đột ngột lúc dùng model local'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DebugLogScreen())),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.backup_outlined),
              title: const Text('Sao lưu & khôi phục'),
              subtitle: const Text('Xuất/nhập toàn bộ dữ liệu (mọi truyện) ra 1 file, phòng mất máy hoặc đổi máy'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BackupRestoreScreen())),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'App không thêm bộ lọc nội dung riêng. Khi dùng API của một hãng, '
            'chính sách nội dung của hãng đó vẫn áp dụng phía máy chủ của họ.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 16),

          SegmentedButton<AIProviderType>(
            segments: const [
              ButtonSegment(value: AIProviderType.localLlama, label: Text('AI local'), icon: Icon(Icons.memory_outlined)),
              ButtonSegment(value: AIProviderType.api, label: Text('API'), icon: Icon(Icons.cloud_outlined)),
            ],
            selected: {selected},
            onSelectionChanged: (s) async {
              setState(() => selected = s.first);
              await settings.saveProviderType(s.first);
            },
          ),
          const SizedBox(height: 16),

          if (selected == AIProviderType.localLlama) ...[
            Text('Model local đã thêm', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (localModels.isEmpty)
              const Text('Chưa có model nào. Bấm "Thêm model" bên dưới.', style: TextStyle(color: Colors.grey))
            else
              ...localModels.map((m) => Card(
                    color: m.id == activeLocalModelId ? Theme.of(context).colorScheme.primaryContainer : null,
                    child: ListTile(
                      leading: Icon(m.id == activeLocalModelId ? Icons.radio_button_checked : Icons.radio_button_off),
                      title: Text(m.name),
                      subtitle: Text(m.path, style: const TextStyle(fontSize: 10), maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () async {
                        await settings.setActiveLocalModel(m.id);
                        _load();
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 18),
                        onPressed: () async {
                          await settings.deleteLocalModel(m.id);
                          _load();
                        },
                      ),
                    ),
                  )),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _addLocalModelDialog,
              icon: const Icon(Icons.add),
              label: const Text('Thêm model'),
            ),
          ] else ...[
            Text('API provider đã thêm', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (apiProviders.isEmpty)
              const Text('Chưa có provider nào. Bấm "Thêm provider" bên dưới.', style: TextStyle(color: Colors.grey))
            else
              ...apiProviders.map((p) => Card(
                    color: p.id == activeApiProviderId ? Theme.of(context).colorScheme.primaryContainer : null,
                    child: ListTile(
                      leading: Icon(p.id == activeApiProviderId ? Icons.radio_button_checked : Icons.radio_button_off),
                      title: Text(p.name),
                      subtitle: Text('${p.type == 'anthropic' ? 'Anthropic' : p.baseUrl} · ${p.modelId}',
                          style: const TextStyle(fontSize: 10), maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () async {
                        await settings.setActiveApiProvider(p.id);
                        _load();
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 18),
                        onPressed: () async {
                          await settings.deleteApiProvider(p.id);
                          _load();
                        },
                      ),
                    ),
                  )),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _addApiProviderDialog,
              icon: const Icon(Icons.add),
              label: const Text('Thêm provider'),
            ),
          ],

          const Divider(height: 32),
          const Text(
            'Nếu vừa đổi provider AI, hoặc dữ liệu Story Bible/chương cũ chưa từng '
            'được lập chỉ mục, bấm nút dưới để tính lại toàn bộ embedding.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: reindexing ? null : _reindexAll,
            icon: reindexing
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
            label: Text(reindexing ? 'Đang tái lập chỉ mục...' : 'Tái lập chỉ mục toàn bộ'),
          ),
        ],
      ),
    );
  }

  bool reindexing = false;

  Future<void> _reindexAll() async {
    setState(() => reindexing = true);
    try {
      final novelId = await settings.loadActiveNovelId();
      if (novelId == null) {
        throw Exception('Không xác định được truyện đang mở');
      }
      final db = DatabaseService.instance;
      final rag = RagService(
        db,
        await settings.currentEmbeddingService(),
        novelId: novelId,
        contextBudgetChars: await settings.loadRagBudget(),
      );
      for (final c in await db.allCharacters(novelId)) {
        await rag.indexCharacter(c);
      }
      for (final r in await db.allWorldRules(novelId)) {
        await rag.indexWorldRule(r);
      }
      for (final ch in await db.allChapters(novelId)) {
        await rag.indexChapter(ch);
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã tái lập chỉ mục xong')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) setState(() => reindexing = false);
    }
  }
}
