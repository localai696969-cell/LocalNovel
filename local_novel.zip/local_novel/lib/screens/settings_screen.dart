import 'dart:io';
import 'package:flutter/material.dart';
import '../models/story_models.dart';
import '../services/ai_provider.dart';
import '../services/settings_service.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import 'local_optimization_screen.dart';
import 'file_browser_screen.dart';
import 'generation_settings_screen.dart';
import 'translation_settings_screen.dart';
import 'backup_restore_screen.dart';
import 'background_tasks_screen.dart';
import '../services/background_task_manager.dart';
import 'debug_log_screen.dart';
import '../main.dart';

class SettingsScreen extends StatefulWidget {
  // ĐÃ THÊM (v14 — theo yêu cầu người dùng: "cài đặt thì áp dụng cho quyển
  // truyện chứ không phải cho toàn app"): phần chọn provider/model +
  // "Tối ưu AI local" (benchmark) giờ áp dụng cho ĐÚNG truyện đang mở.
  final String novelId;
  const SettingsScreen({super.key, required this.novelId});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final settings = SettingsService();
  AIProviderType selected = AIProviderType.localLlama;
  List<LocalModelEntry> localModels = [];
  String? activeLocalModelId;
  List<ApiProviderEntry> apiProviders = [];
  String? activeApiProviderId;
  // ĐÃ THÊM: số nhiệm vụ AI được phép chạy đồng thời khi provider active là
  // GPU từ xa (Colab/API khác) — xem BackgroundTaskManager. KHÔNG áp dụng
  // cho model local (luôn = 1, lý do an toàn thật, không phải cấu hình).
  int maxParallelRemoteTasks = 2;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final type = await settings.loadProviderType(widget.novelId);
    final models = await settings.allLocalModels();
    final activeModelId = await settings.loadActiveLocalModelId(widget.novelId);
    final providers = await settings.allApiProviders();
    final activeProviderId = await settings.loadActiveApiProviderId(widget.novelId);
    final maxParallel = await settings.loadMaxParallelRemoteTasks(widget.novelId);
    setState(() {
      selected = type;
      localModels = models;
      activeLocalModelId = activeModelId;
      apiProviders = providers;
      activeApiProviderId = activeProviderId;
      maxParallelRemoteTasks = maxParallel;
    });
  }

  Future<void> _addLocalModelDialog() async {
    final nameCtrl = TextEditingController();
    final pathCtrl = TextEditingController();
    String? checkResult;
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Thêm model local'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên gợi nhớ (vd: Qwen 4B)')),
            TextField(
              controller: pathCtrl,
              decoration: const InputDecoration(
                labelText: 'Thư mục model MNN (chứa config.json + file .mnn)',
                hintText: '/storage/emulated/0/Download/qwen2-1.5b-mnn',
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: Text(
                'Lưu ý: engine hiện tại (MNN) không dùng trực tiếp file .gguf — '
                'cần model đã convert sang định dạng MNN (1 thư mục, không phải 1 file lẻ).',
                style: TextStyle(fontSize: 11, color: Colors.orange),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await Navigator.push<String>(
                      context,
                      MaterialPageRoute(builder: (_) => const FileBrowserScreen(pickDirectory: true)),
                    );
                    if (picked != null) {
                      pathCtrl.text = picked;
                      setDialogState(() => checkResult = null);
                    }
                  },
                  icon: const Icon(Icons.folder_open_outlined, size: 16),
                  label: const Text('Duyệt thư mục'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    final dir = Directory(pathCtrl.text.trim());
                    final exists = dir.existsSync();
                    final hasConfig = exists &&
                        (File('${dir.path}/config.json').existsSync() || File('${dir.path}/llm_config.json').existsSync());
                    setDialogState(() => checkResult = hasConfig
                        ? '✓ Thư mục hợp lệ (có config)'
                        : exists
                            ? '⚠ Thư mục tồn tại nhưng không thấy config.json — kiểm tra lại'
                            : '✗ Không tìm thấy thư mục');
                  },
                  icon: const Icon(Icons.fact_check_outlined, size: 16),
                  label: const Text('Kiểm tra'),
                ),
              ),
            ]),
            if (checkResult != null)
              Text(checkResult!, style: TextStyle(color: checkResult!.startsWith('✓') ? Colors.green : Colors.red, fontSize: 12)),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Thêm')),
          ],
        );
      }),
    );
    if (result == true && pathCtrl.text.trim().isNotEmpty) {
      final name = nameCtrl.text.trim().isEmpty ? pathCtrl.text.split('/').last : nameCtrl.text.trim();
      await settings.addLocalModel(name, pathCtrl.text.trim(), novelId: widget.novelId);
      _load();
    }
  }

  Future<void> _addApiProviderDialog() async {
    final nameCtrl = TextEditingController();
    final baseUrlCtrl = TextEditingController(text: 'https://api.openai.com/v1');
    final modelIdCtrl = TextEditingController();
    final apiKeyCtrl = TextEditingController();
    String type = 'openai_compatible';

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Thêm API provider'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên gợi nhớ (vd: Groq, Together...)')),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: 'Loại'),
                items: const [
                  DropdownMenuItem(value: 'openai_compatible', child: Text('Tương thích OpenAI (tự nhập URL)')),
                  DropdownMenuItem(value: 'anthropic', child: Text('Anthropic (Claude)')),
                  // ĐÃ THÊM: GPU từ xa qua Colab — về BẢN CHẤT kỹ thuật vẫn
                  // là 1 endpoint "tương thích OpenAI" (chạy từ notebook
                  // Colab, lộ ra ngoài qua Cloudflare Tunnel), dùng LẠI
                  // đúng OpenAICompatibleProvider — KHÔNG cần thêm class
                  // provider mới. Tách thành lựa chọn riêng CHỈ để hiện
                  // đúng nhãn/gợi ý phù hợp (URL Colab, "API key" ở đây
                  // thực ra là mật khẩu tự đặt, không phải tài khoản trả
                  // phí nào) — tránh người dùng nhầm lẫn với API OpenAI
                  // thật cần tài khoản/thẻ tín dụng.
                  DropdownMenuItem(value: 'colab_remote_gpu', child: Text('GPU từ xa (Google Colab, miễn phí)')),
                  // ĐÃ THÊM — mục BQ, 2026-09-23: xem giải thích đầy đủ ở
                  // `openrouter_provider.dart` — về bản chất vẫn là 1
                  // endpoint "tương thích OpenAI" (dùng lại
                  // OpenAICompatibleProvider), tách riêng CHỈ để base URL
                  // điền sẵn (người dùng không cần tự gõ) + nhãn/gợi ý
                  // đúng cho model ID kiểu "nhacungcap/ten-model".
                  DropdownMenuItem(value: 'openrouter', child: Text('OpenRouter (nhiều model, 1 API key)')),
                ],
                onChanged: (v) => setDialogState(() => type = v ?? 'openai_compatible'),
              ),
              if (type == 'colab_remote_gpu') ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text(
                      'Cần chạy notebook Colab đi kèm trước (xem file colab_remote_gpu.ipynb). '
                      'Notebook sẽ in ra 2 thứ: URL Cloudflare Tunnel (dán vào ô "Base URL" bên dưới, '
                      'thêm "/v1" ở cuối) và mật khẩu chia sẻ tự sinh (dán vào ô "API key").',
                      style: TextStyle(fontSize: 12),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '⚠️ Mật khẩu chia sẻ BẮT BUỘC phải điền — URL Cloudflare Tunnel là URL công khai '
                      'trên Internet, ai có URL đều gọi được nếu notebook không kiểm tra mật khẩu. Mã hoá '
                      'đường truyền (HTTPS qua Cloudflare) chỉ chống nghe lén trên đường đi, KHÔNG thay thế '
                      'được việc kiểm tra danh tính người gọi.',
                      style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.error),
                    ),
                  ]),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: baseUrlCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Base URL (URL Cloudflare Tunnel + "/v1")',
                    hintText: 'https://vi-du-ngau-nhien.trycloudflare.com/v1',
                  ),
                ),
              ] else if (type == 'openai_compatible')
                TextField(controller: baseUrlCtrl, decoration: const InputDecoration(labelText: 'Base URL'))
              else if (type == 'openrouter') ...[
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'API key lấy tại openrouter.ai (mục "Keys"). Model ID dạng '
                    '"nhacungcap/ten-model" (vd "anthropic/claude-3.5-sonnet", '
                    '"deepseek/deepseek-chat") — xem danh sách đầy đủ, LUÔN cập '
                    'nhật tại openrouter.ai/models.',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
                const SizedBox(height: 8),
              ],
              TextField(
                controller: modelIdCtrl,
                decoration: InputDecoration(
                  labelText: type == 'colab_remote_gpu' ? 'Model ID (điền đúng model đã nạp trong notebook)' : 'Model ID (vd: gpt-4o, llama-3.1-70b...)',
                ),
              ),
              TextField(
                controller: apiKeyCtrl,
                decoration: InputDecoration(
                  labelText: type == 'colab_remote_gpu' ? 'Mật khẩu chia sẻ (đặt trong notebook, KHÔNG phải tài khoản OpenAI)' : 'API key',
                ),
                obscureText: true,
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Thêm')),
          ],
        );
      }),
    );
    if (result == true && nameCtrl.text.trim().isNotEmpty) {
      await settings.addApiProvider(
        name: nameCtrl.text.trim(),
        type: type,
        baseUrl: (type == 'openai_compatible' || type == 'colab_remote_gpu') ? baseUrlCtrl.text.trim() : null,
        modelId: modelIdCtrl.text.trim(),
        apiKey: apiKeyCtrl.text.trim(),
        novelId: widget.novelId,
      );
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt AI')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.swap_horiz_outlined),
              title: const Text('Đổi truyện'),
              subtitle: const Text('Quay lại danh sách truyện để tạo mới hoặc chuyển sang truyện khác'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const NovelListScreen()),
                (route) => false,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.speed_outlined),
              title: const Text('Tối ưu AI local cho máy này'),
              subtitle: const Text('Nhận diện chip, gợi ý cấu hình, đo tốc độ thực tế'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => LocalOptimizationScreen(novelId: widget.novelId))),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.tune_outlined),
              title: const Text('Tham số sinh văn bản'),
              subtitle: const Text('temperature, top_p, top_k, repetition_penalty, độ dài tối đa + tóm tắt cốt truyện (riêng truyện này)'),
              trailing: const Icon(Icons.chevron_right),
              // ĐÃ SỬA (v14): SettingsScreen giờ nhận thẳng `novelId` từ
              // RootScreen (xem main.dart) — không cần tự dò lại
              // `loadActiveNovelId()` ở đây nữa như bản v13 (đường vòng
              // không cần thiết, đã có sẵn đúng truyện đang mở trong tay).
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => GenerationSettingsScreen(novelId: widget.novelId))),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.translate_outlined),
              title: const Text('Dịch thuật trung gian'),
              subtitle: const Text('Tùy chọn: dịch qua ngôn ngữ model hiểu tốt rồi dịch ngược, chống lỗi tiếng Việt ngô nghê'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => TranslationSettingsScreen(novelId: widget.novelId))),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.bug_report_outlined),
              title: const Text('Log debug'),
              subtitle: const Text('Xem log ghi ra file — hữu ích khi app bị đóng đột ngột lúc dùng model local'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DebugLogScreen())),
            ),
          ),
          const SizedBox(height: 12),
          // ĐÃ THÊM: điểm truy cập DUY NHẤT trong app tới `BackgroundTaskManager`
          // — xem giải thích đầy đủ ở `background_tasks_screen.dart`. Dùng
          // `AnimatedBuilder` để badge số lượng tự cập nhật realtime (không
          // cần rời/quay lại màn Cài đặt mới thấy số mới).
          AnimatedBuilder(
            animation: BackgroundTaskManager.instance,
            builder: (context, _) {
              final active = BackgroundTaskManager.instance.runningCount + BackgroundTaskManager.instance.queuedCount;
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.pending_actions_outlined),
                  title: const Text('Tác vụ nền'),
                  subtitle: Text(active > 0
                      ? 'Đang có $active tác vụ đang chạy/chờ (chat, tạo chương hàng loạt, tài liệu)'
                      : 'Xem/huỷ các tác vụ chạy nền — hiện không có tác vụ nào'),
                  trailing: active > 0
                      ? Badge(
                          label: Text('$active'),
                          child: const Icon(Icons.chevron_right),
                        )
                      : const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BackgroundTasksScreen())),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.backup_outlined),
              title: const Text('Sao lưu & khôi phục'),
              subtitle: const Text('Toàn bộ app hoặc riêng 1 truyện — phòng mất máy hoặc đổi máy'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => BackupRestoreScreen(novelId: widget.novelId))),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'App không thêm bộ lọc nội dung riêng. Khi dùng API của một hãng, '
            'chính sách nội dung của hãng đó vẫn áp dụng phía máy chủ của họ.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 16),

          SegmentedButton<AIProviderType>(
            segments: const [
              ButtonSegment(value: AIProviderType.localLlama, label: Text('AI local'), icon: Icon(Icons.memory_outlined)),
              ButtonSegment(value: AIProviderType.api, label: Text('API'), icon: Icon(Icons.cloud_outlined)),
            ],
            selected: {selected},
            onSelectionChanged: (s) async {
              setState(() => selected = s.first);
              await settings.saveProviderType(widget.novelId, s.first);
            },
          ),
          const SizedBox(height: 16),

          if (selected == AIProviderType.localLlama) ...[
            Text('Model local đã thêm', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (localModels.isEmpty)
              const Text('Chưa có model nào. Bấm "Thêm model" bên dưới.', style: TextStyle(color: Colors.grey))
            else
              ...localModels.map((m) => Card(
                    color: m.id == activeLocalModelId ? Theme.of(context).colorScheme.primaryContainer : null,
                    child: ListTile(
                      leading: Icon(m.id == activeLocalModelId ? Icons.radio_button_checked : Icons.radio_button_off),
                      title: Text(m.name),
                      subtitle: Text(m.path, style: const TextStyle(fontSize: 10), maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () async {
                        await settings.setActiveLocalModel(widget.novelId, m.id);
                        _load();
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 18),
                        onPressed: () async {
                          await settings.deleteLocalModel(m.id);
                          _load();
                        },
                      ),
                    ),
                  )),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _addLocalModelDialog,
              icon: const Icon(Icons.add),
              label: const Text('Thêm model'),
            ),
          ] else ...[
            Text('API provider đã thêm', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (apiProviders.isEmpty)
              const Text('Chưa có provider nào. Bấm "Thêm provider" bên dưới.', style: TextStyle(color: Colors.grey))
            else
              ...apiProviders.map((p) => Card(
                    color: p.id == activeApiProviderId ? Theme.of(context).colorScheme.primaryContainer : null,
                    child: ListTile(
                      leading: Icon(
                        p.type == 'colab_remote_gpu'
                            ? Icons.cloud_sync_outlined
                            : (p.id == activeApiProviderId ? Icons.radio_button_checked : Icons.radio_button_off),
                      ),
                      title: Text(p.name),
                      subtitle: Text(
                        '${p.type == 'anthropic' ? 'Anthropic' : (p.type == 'colab_remote_gpu' ? 'GPU từ xa (Colab)' : (p.type == 'openrouter' ? 'OpenRouter' : p.baseUrl))} · ${p.modelId}',
                        style: const TextStyle(fontSize: 10),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      onTap: () async {
                        await settings.setActiveApiProvider(widget.novelId, p.id);
                        _load();
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 18),
                        onPressed: () async {
                          await settings.deleteApiProvider(p.id);
                          _load();
                        },
                      ),
                    ),
                  )),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _addApiProviderDialog,
              icon: const Icon(Icons.add),
              label: const Text('Thêm provider'),
            ),
          ],

          // ĐÃ THÊM (theo yêu cầu người dùng: giới hạn công suất/VRAM khi
          // dùng GPU từ xa, tránh bị văng khỏi phiên Colab do quá tải).
          // LƯU Ý QUAN TRỌNG (không giấu): số này chỉ giới hạn app GỬI TỐI
          // ĐA bao nhiêu request cùng lúc — KHÔNG trực tiếp chỉnh được công
          // suất/VRAM thật của GPU trên Colab (thứ đó do chính notebook
          // quyết định lúc khởi động server, qua tham số n_parallel — xem
          // notebook đi kèm). Số ở đây nên đặt BẰNG HOẶC THẤP HƠN n_parallel
          // đã cấu hình trong notebook để có tác dụng thật; đặt cao hơn chỉ
          // khiến request xếp hàng phía SERVER thay vì phía app, không tăng
          // rủi ro sai nhưng cũng không tăng tốc độ thật.
          const Divider(height: 32),
          Text('Giới hạn công suất GPU từ xa', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text(
            'Số nhiệm vụ AI tối đa được phép chạy CÙNG LÚC khi đang dùng "GPU từ xa (Colab)" — '
            'ví dụ vừa chat vừa tạo chương hàng loạt. Đặt quá cao dễ làm phiên Colab miễn phí bị quá '
            'tải/văng — khuyến nghị 2-3 nếu dùng model 7B trở lên trên GPU T4 miễn phí.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: Slider(
                value: maxParallelRemoteTasks.toDouble(),
                min: 1,
                max: 8,
                divisions: 7,
                label: '$maxParallelRemoteTasks',
                onChanged: (v) => setState(() => maxParallelRemoteTasks = v.round()),
                onChangeEnd: (v) async {
                  await settings.saveMaxParallelRemoteTasks(widget.novelId, v.round());
                },
              ),
            ),
            SizedBox(
              width: 32,
              child: Text('$maxParallelRemoteTasks', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          ]),
          const Text(
            'Model local KHÔNG áp dụng số này — luôn giới hạn ở 1 nhiệm vụ tại 1 thời điểm (lý do an toàn '
            'kỹ thuật, không phải cấu hình có thể đổi — xem mục 5.67/5.78 tài liệu kiến trúc nếu cần chi tiết).',
            style: TextStyle(fontSize: 11, fontStyle: FontStyle.italic, color: Colors.grey),
          ),

          const Divider(height: 32),
          const Text(
            'Nếu vừa đổi provider AI, hoặc dữ liệu Story Bible/chương cũ chưa từng '
            'được lập chỉ mục, bấm nút dưới để tính lại toàn bộ embedding.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: reindexing ? null : _reindexAll,
            icon: reindexing
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
            label: Text(reindexing ? 'Đang tái lập chỉ mục...' : 'Tái lập chỉ mục toàn bộ'),
          ),
        ],
      ),
    );
  }

  bool reindexing = false;

  Future<void> _reindexAll() async {
    setState(() => reindexing = true);
    try {
      final novelId = await settings.loadActiveNovelId();
      if (novelId == null) {
        throw Exception('Không xác định được truyện đang mở');
      }
      final db = DatabaseService.instance;
      final rag = RagService(
        db,
        await settings.currentEmbeddingService(),
        novelId: novelId,
        contextBudgetChars: await settings.loadRagBudget(novelId),
      );
      for (final c in await db.allCharacters(novelId)) {
        await rag.indexCharacter(c);
      }
      for (final r in await db.allWorldRules(novelId)) {
        await rag.indexWorldRule(r);
      }
      for (final ch in await db.allChapters(novelId)) {
        await rag.indexChapter(ch);
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã tái lập chỉ mục xong')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) setState(() => reindexing = false);
    }
  }
}
