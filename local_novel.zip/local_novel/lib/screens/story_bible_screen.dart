import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/settings_service.dart';
import '../services/style_service.dart';
import '../services/rag_service.dart';

class StoryBibleScreen extends StatefulWidget {
  const StoryBibleScreen({super.key});
  @override
  State<StoryBibleScreen> createState() => _StoryBibleScreenState();
}

class _StoryBibleScreenState extends State<StoryBibleScreen> with SingleTickerProviderStateMixin {
  final db = DatabaseService.instance;
  List<Character> characters = [];
  List<WorldRule> rules = [];
  List<StyleProfile> styles = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await db.allCharacters();
    final r = await db.allWorldRules();
    final s = await db.allStyleProfiles();
    setState(() {
      characters = c;
      rules = r;
      styles = s;
    });
  }

  Future<void> _addStyleFromDescription() async {
    final result = await _editDialog(
      title: 'Mô tả văn phong bằng lời',
      fields: {'name': 'Tên hồ sơ (vd: Cổ trang trầm lắng)', 'profile_description': 'Mô tả văn phong'},
    );
    if (result == null) return;
    await db.upsertStyleProfile(StyleProfile(
      id: const Uuid().v4(),
      name: result['name'] ?? '',
      profileDescription: result['profile_description'] ?? '',
    ));
    _load();
  }

  // Dán một đoạn văn CỦA CHÍNH NGƯỜI DÙNG (chương cũ họ tự viết) để AI
  // phân tích ra mô tả văn phong, thay vì lưu lại nguyên văn tác phẩm.
  Future<void> _addStyleFromSample() async {
    final result = await _editDialog(
      title: 'Học văn phong từ mẫu văn của bạn',
      fields: {'name': 'Tên hồ sơ', 'sample': 'Dán một đoạn văn bạn đã viết (không phải của người khác)'},
    );
    if (result == null || (result['sample'] ?? '').trim().isEmpty) return;
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(content: Row(children: [
        CircularProgressIndicator(),
        SizedBox(width: 16),
        Text('Đang phân tích văn phong...'),
      ])),
    );
    try {
      final provider = await SettingsService().currentProvider();
      final description = await StyleService().analyzeStyleFromSample(result['sample']!, provider);
      await db.upsertStyleProfile(StyleProfile(
        id: const Uuid().v4(),
        name: result['name'] ?? 'Văn phong của tôi',
        profileDescription: description,
      ));
      _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _addCharacter() async {
    final result = await _editDialog(
      title: 'Nhân vật mới',
      fields: {'name': 'Tên', 'role': 'Vai trò', 'description': 'Mô tả', 'keywords': 'Từ khóa kích hoạt (cách nhau bởi dấu phẩy)'},
    );
    if (result == null) return;
    final name = result['name'] ?? '';
    final kw = (result['keywords'] ?? '').split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final character = Character(
      id: const Uuid().v4(),
      name: name,
      role: result['role'] ?? '',
      description: result['description'] ?? '',
      keywords: kw.isEmpty ? [name] : kw,
    );
    await db.upsertCharacter(character);
    await (await _rag()).indexCharacter(character);
    _load();
  }

  Future<void> _addRule() async {
    final result = await _editDialog(
      title: 'Luật thế giới mới',
      fields: {'title': 'Tiêu đề', 'content': 'Nội dung luật', 'keywords': 'Từ khóa kích hoạt (nếu không phải luật cứng)'},
    );
    if (result == null) return;
    final rule = WorldRule(
      id: const Uuid().v4(),
      title: result['title'] ?? '',
      content: result['content'] ?? '',
      isHardRule: true,
      keywords: (result['keywords'] ?? '').split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
    );
    await db.upsertWorldRule(rule);
    await (await _rag()).indexWorldRule(rule);
    _load();
  }

  Future<RagService> _rag() async => RagService(db, await SettingsService().currentEmbeddingService(), contextBudgetChars: await SettingsService().loadRagBudget());

  Future<Map<String, String>?> _editDialog({
    required String title,
    required Map<String, String> fields,
  }) async {
    final controllers = {for (final k in fields.keys) k: TextEditingController()};
    return showDialog<Map<String, String>>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: fields.entries
              .map((e) => TextField(
                    controller: controllers[e.key],
                    decoration: InputDecoration(labelText: e.value),
                    maxLines: (e.key == 'description' || e.key == 'content' || e.key == 'profile_description' || e.key == 'sample') ? 5 : 1,
                  ))
              .toList(),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              {for (final k in controllers.keys) k: controllers[k]!.text},
            ),
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Bách khoa truyện'),
          bottom: const TabBar(tabs: [Tab(text: 'Nhân vật'), Tab(text: 'Luật thế giới'), Tab(text: 'Văn phong')]),
        ),
        body: TabBarView(children: [
          ListView(
            children: characters
                .map((c) => ListTile(
                      leading: CircleAvatar(child: Text(c.name.isNotEmpty ? c.name[0] : '?')),
                      title: Text(c.name),
                      subtitle: Text('${c.role} · ${c.description}'),
                    ))
                .toList(),
          ),
          ListView(
            children: rules
                .map((r) => ListTile(
                      leading: Icon(r.isHardRule ? Icons.gavel : Icons.info_outline),
                      title: Text(r.title),
                      subtitle: Text(r.content),
                    ))
                .toList(),
          ),
          ListView(
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Mỗi hồ sơ là một mô tả văn phong (không lưu nguyên văn tác phẩm ai khác). '
                  'Có thể chọn hồ sơ này khi viết tiếp chương hoặc đắp thịt outline.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ),
              ...styles.map((s) => ListTile(
                    leading: const Icon(Icons.edit_note_outlined),
                    title: Text(s.name),
                    subtitle: Text(s.profileDescription, maxLines: 2, overflow: TextOverflow.ellipsis),
                    onLongPress: () async {
                      await db.deleteStyleProfile(s.id);
                      _load();
                    },
                  )),
            ],
          ),
        ]),
        floatingActionButton: Builder(builder: (context) {
          final tabIndex = DefaultTabController.of(context).index;
          if (tabIndex == 0) {
            return FloatingActionButton(onPressed: _addCharacter, child: const Icon(Icons.add));
          } else if (tabIndex == 1) {
            return FloatingActionButton(onPressed: _addRule, child: const Icon(Icons.add));
          }
          return FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet(
              context: context,
              builder: (_) => SafeArea(
                child: Wrap(children: [
                  ListTile(
                    leading: const Icon(Icons.description_outlined),
                    title: const Text('Mô tả bằng lời'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromDescription();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.content_paste_outlined),
                    title: const Text('Học từ mẫu văn của tôi'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromSample();
                    },
                  ),
                ]),
              ),
            ),
            icon: const Icon(Icons.add),
            label: const Text('Thêm văn phong'),
          );
        }),
      ),
    );
  }
}
