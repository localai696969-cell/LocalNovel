import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/settings_service.dart';
import '../services/style_service.dart';
import '../services/rag_service.dart';

const List<String> kCharacterCategories = ['Nhân vật chính', 'Nhân vật phụ', 'Phản diện', 'Khác'];
const List<String> kWorldRuleCategories = ['Luật lệ', 'Địa điểm', 'Vũ khí', 'Tổ chức', 'Vật phẩm', 'Khác'];
const List<String> kGlossaryCategories = ['Địa danh', 'Thuật ngữ', 'Vật phẩm', 'Khác'];

class StoryBibleScreen extends StatefulWidget {
  final String novelId;
  const StoryBibleScreen({super.key, required this.novelId});
  @override
  State<StoryBibleScreen> createState() => _StoryBibleScreenState();
}

class _StoryBibleScreenState extends State<StoryBibleScreen> with SingleTickerProviderStateMixin {
  final db = DatabaseService.instance;
  List<Character> characters = [];
  List<WorldRule> rules = [];
  List<StyleProfile> styles = [];
  List<GlossaryTerm> glossaryTerms = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant StoryBibleScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final c = await db.allCharacters(widget.novelId);
    final r = await db.allWorldRules(widget.novelId);
    final s = await db.allStyleProfiles(widget.novelId);
    final g = await db.allGlossaryTerms(widget.novelId);
    if (!mounted) return;
    setState(() {
      characters = c;
      rules = r;
      styles = s;
      glossaryTerms = g;
    });
  }

  Future<void> _addStyleFromDescription() async {
    final result = await _editDialog(
      title: 'Mô tả văn phong bằng lời',
      fields: {'name': 'Tên hồ sơ (vd: Cổ trang trầm lắng)', 'profile_description': 'Mô tả văn phong'},
    );
    if (result == null) return;
    await db.upsertStyleProfile(StyleProfile(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      name: result['name'] ?? '',
      profileDescription: result['profile_description'] ?? '',
    ));
    _load();
  }

  // Dán một đoạn văn CỦA CHÍNH NGƯỜI DÙNG (chương cũ họ tự viết) để AI
  // phân tích ra mô tả văn phong, thay vì lưu lại nguyên văn tác phẩm.
  Future<void> _addStyleFromSample() async {
    final result = await _editDialog(
      title: 'Học văn phong từ mẫu văn của bạn',
      fields: {'name': 'Tên hồ sơ', 'sample': 'Dán một đoạn văn bạn đã viết (không phải của người khác)'},
    );
    if (result == null || (result['sample'] ?? '').trim().isEmpty) return;
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(content: Row(children: [
        CircularProgressIndicator(),
        SizedBox(width: 16),
        Text('Đang phân tích văn phong...'),
      ])),
    );
    try {
      final provider = await SettingsService().currentProvider();
      final description = await StyleService().analyzeStyleFromSample(result['sample']!, provider);
      await db.upsertStyleProfile(StyleProfile(
        id: const Uuid().v4(),
        novelId: widget.novelId,
        name: result['name'] ?? 'Văn phong của tôi',
        profileDescription: description,
      ));
      _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _addCharacter() async {
    final nameCtrl = TextEditingController();
    final roleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final keywordsCtrl = TextEditingController();
    String category = kCharacterCategories.first;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Nhân vật mới'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên')),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Phân loại'),
                items: kCharacterCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              TextField(controller: roleCtrl, decoration: const InputDecoration(labelText: 'Vai trò (mô tả tự do, vd: Đội trưởng)')),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả'), maxLines: 5),
              TextField(
                controller: keywordsCtrl,
                decoration: const InputDecoration(labelText: 'Từ khóa kích hoạt (cách nhau bởi dấu phẩy)'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final name = nameCtrl.text.trim();
    if (name.isEmpty) return;
    final kw = keywordsCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final character = Character(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      name: name,
      role: roleCtrl.text.trim(),
      category: category,
      description: descCtrl.text.trim(),
      keywords: kw.isEmpty ? [name] : kw,
    );
    await db.upsertCharacter(character);
    await (await _rag()).indexCharacter(character);
    _load();
  }

  Future<void> _addRule() async {
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();
    final keywordsCtrl = TextEditingController();
    String category = kWorldRuleCategories.first;
    bool isHardRule = true;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Luật thế giới mới'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tiêu đề')),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Phân loại'),
                items: kWorldRuleCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              TextField(controller: contentCtrl, decoration: const InputDecoration(labelText: 'Nội dung'), maxLines: 5),
              TextField(
                controller: keywordsCtrl,
                decoration: const InputDecoration(labelText: 'Từ khóa kích hoạt (nếu không phải luật cứng)'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Luật cứng (không bao giờ được vi phạm)'),
                value: isHardRule,
                onChanged: (v) => setDialogState(() => isHardRule = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    final rule = WorldRule(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      title: title,
      content: contentCtrl.text.trim(),
      isHardRule: isHardRule,
      category: category,
      keywords: keywordsCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
    );
    await db.upsertWorldRule(rule);
    await (await _rag()).indexWorldRule(rule);
    _load();
  }

  // ---------- Glossary (bảng thuật ngữ) ----------
  Future<void> _addGlossaryTerm() async {
    final termCtrl = TextEditingController();
    final defCtrl = TextEditingController();
    String category = kGlossaryCategories.first;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Thuật ngữ mới'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: termCtrl, decoration: const InputDecoration(labelText: 'Thuật ngữ')),
            DropdownButtonFormField<String>(
              value: category,
              decoration: const InputDecoration(labelText: 'Phân loại'),
              items: kGlossaryCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (v) => setDialogState(() => category = v ?? category),
            ),
            TextField(controller: defCtrl, decoration: const InputDecoration(labelText: 'Định nghĩa / giải thích'), maxLines: 4),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final term = termCtrl.text.trim();
    if (term.isEmpty) return;
    await db.upsertGlossaryTerm(GlossaryTerm(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      term: term,
      definition: defCtrl.text.trim(),
      category: category,
    ));
    _load();
  }

  Future<void> _deleteGlossaryTerm(GlossaryTerm t) async {
    await db.deleteGlossaryTerm(t.id);
    _load();
  }

  Future<RagService> _rag() async => RagService(
        db,
        await SettingsService().currentEmbeddingService(),
        novelId: widget.novelId,
        contextBudgetChars: await SettingsService().loadRagBudget(),
      );

  Future<Map<String, String>?> _editDialog({
    required String title,
    required Map<String, String> fields,
  }) async {
    final controllers = {for (final k in fields.keys) k: TextEditingController()};
    return showDialog<Map<String, String>>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: fields.entries
              .map((e) => TextField(
                    controller: controllers[e.key],
                    decoration: InputDecoration(labelText: e.value),
                    maxLines: (e.key == 'description' || e.key == 'content' || e.key == 'profile_description' || e.key == 'sample') ? 5 : 1,
                  ))
              .toList(),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              {for (final k in controllers.keys) k: controllers[k]!.text},
            ),
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteCharacter(Character c) async {
    await db.deleteCharacter(c.id);
    _load();
  }

  Future<void> _deleteRule(WorldRule r) async {
    await db.deleteWorldRule(r.id);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Bách khoa truyện'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [Tab(text: 'Nhân vật'), Tab(text: 'Luật thế giới'), Tab(text: 'Văn phong'), Tab(text: 'Thuật ngữ')],
          ),
        ),
        body: TabBarView(children: [
          characters.isEmpty
              ? const Center(child: Text('Chưa có nhân vật nào. Bấm + để thêm.'))
              : ListView(
                  children: characters
                      .map((c) => ListTile(
                            leading: CircleAvatar(child: Text(c.name.isNotEmpty ? c.name[0] : '?')),
                            title: Row(children: [
                              Flexible(child: Text(c.name)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(c.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text('${c.role} · ${c.description}'),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () => _deleteCharacter(c),
                            ),
                          ))
                      .toList(),
                ),
          rules.isEmpty
              ? const Center(child: Text('Chưa có luật thế giới nào. Bấm + để thêm.'))
              : ListView(
                  children: rules
                      .map((r) => ListTile(
                            leading: Icon(r.isHardRule ? Icons.gavel : Icons.info_outline),
                            title: Row(children: [
                              Flexible(child: Text(r.title)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(r.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text(r.content),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () => _deleteRule(r),
                            ),
                          ))
                      .toList(),
                ),
          ListView(
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Mỗi hồ sơ là một mô tả văn phong (không lưu nguyên văn tác phẩm ai khác). '
                  'Có thể chọn hồ sơ này khi viết tiếp chương hoặc đắp thịt outline.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ),
              ...styles.map((s) => ListTile(
                    leading: const Icon(Icons.edit_note_outlined),
                    title: Text(s.name),
                    subtitle: Text(s.profileDescription, maxLines: 2, overflow: TextOverflow.ellipsis),
                    onLongPress: () async {
                      await db.deleteStyleProfile(s.id);
                      _load();
                    },
                  )),
            ],
          ),
          glossaryTerms.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chưa có thuật ngữ nào. Dùng để tra cứu nhanh tên địa danh/thuật ngữ riêng của '
                      'truyện — khác Story Bible ở chỗ KHÔNG tự động nạp vào prompt AI.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView(
                  children: glossaryTerms
                      .map((t) => ListTile(
                            leading: const Icon(Icons.menu_book_outlined),
                            title: Row(children: [
                              Flexible(child: Text(t.term)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(t.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text(t.definition),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () => _deleteGlossaryTerm(t),
                            ),
                          ))
                      .toList(),
                ),
        ]),
        floatingActionButton: AnimatedBuilder(
          // ĐÃ SỬA (bug nút + luôn mở "Nhân vật mới" bất kể đang ở tab
          // nào): `Builder` thường KHÔNG lắng nghe TabController — đọc
          // `DefaultTabController.of(context).index` bên trong nó chỉ
          // lấy đúng giá trị tại lần build ĐẦU TIÊN của toàn màn hình,
          // sau đó vuốt/chạm đổi tab KHÔNG kích hoạt build lại nút FAB
          // (vì TabController.index thay đổi qua notifyListeners(),
          // không phải qua cơ chế InheritedWidget rebuild thông thường).
          // TabController là 1 ChangeNotifier — phải dùng AnimatedBuilder
          // (hoặc addListener thủ công) để thực sự lắng nghe và rebuild
          // đúng lúc tab đổi. Đây là lý do cả 4 tab đều hiện "Nhân vật
          // mới" giống hệt nhau trong ảnh chụp màn hình.
          animation: DefaultTabController.of(context),
          builder: (context, _) {
            final tabIndex = DefaultTabController.of(context).index;
            if (tabIndex == 0) {
              return FloatingActionButton(onPressed: _addCharacter, child: const Icon(Icons.add));
            } else if (tabIndex == 1) {
              return FloatingActionButton(onPressed: _addRule, child: const Icon(Icons.add));
            } else if (tabIndex == 3) {
              return FloatingActionButton(onPressed: _addGlossaryTerm, child: const Icon(Icons.add));
            }
            return FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet(
              context: context,
              builder: (_) => SafeArea(
                child: Wrap(children: [
                  ListTile(
                    leading: const Icon(Icons.description_outlined),
                    title: const Text('Mô tả bằng lời'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromDescription();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.content_paste_outlined),
                    title: const Text('Học từ mẫu văn của tôi'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromSample();
                    },
                  ),
                ]),
              ),
            ),
            icon: const Icon(Icons.add),
            label: const Text('Thêm văn phong'),
          );
          },
        ),
      ),
    );
  }
}
