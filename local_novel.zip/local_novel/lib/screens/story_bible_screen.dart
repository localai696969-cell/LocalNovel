import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/settings_service.dart';
import '../services/style_service.dart';
import '../services/rag_service.dart';
import '../services/translation_service.dart';

const List<String> kCharacterCategories = ['Nhân vật chính', 'Nhân vật phụ', 'Phản diện', 'Khác'];
const List<String> kWorldRuleCategories = ['Luật lệ', 'Địa điểm', 'Vũ khí', 'Tổ chức', 'Vật phẩm', 'Khác'];
const List<String> kGlossaryCategories = ['Địa danh', 'Thuật ngữ', 'Vật phẩm', 'Khác'];

class StoryBibleScreen extends StatefulWidget {
  final String novelId;
  const StoryBibleScreen({super.key, required this.novelId});
  @override
  State<StoryBibleScreen> createState() => _StoryBibleScreenState();
}

class _StoryBibleScreenState extends State<StoryBibleScreen> with SingleTickerProviderStateMixin {
  final db = DatabaseService.instance;
  List<Character> characters = [];
  List<WorldRule> rules = [];
  List<StyleProfile> styles = [];
  List<GlossaryTerm> glossaryTerms = [];
  // ĐÃ THÊM: 3 tab mới hỗ trợ quy trình viết tiểu thuyết — dàn ý toàn
  // truyện, tuyến truyện/subplot, mục tiêu viết mỗi ngày.
  List<PlotBeat> plotBeats = [];
  List<PlotThread> plotThreads = [];
  WritingGoal? writingGoal;
  List<Map<String, dynamic>> wordLog = []; // 30 ngày gần nhất, từ daily_word_log
  bool suggestingBeats = false; // đang gọi AI gợi ý dàn ý — chặn bấm 2 lần
  // ĐÃ SỬA (màn hình trắng xoá — bug do lần sửa trước gây ra): trước đó
  // dùng `DefaultTabController` + gọi `DefaultTabController.of(context)`
  // ngay tại vị trí `animation:` của FAB — nhưng `context` ở đó là context
  // CỦA CHÍNH build() này (nằm TRÊN DefaultTabController trong cây widget
  // thật sự dựng ra), không phải context nằm DƯỚI nó — nên `.of(context)`
  // luôn thất bại ngay khi build, khiến toàn màn hình trắng xoá ở bản
  // release (Flutter ẩn traceback lỗi trong bản release). Giờ tự sở hữu
  // hẳn 1 TabController riêng (class đã có sẵn SingleTickerProviderStateMixin
  // để làm việc này) — không cần `.of(context)` ở đâu nữa, tránh hẳn lỗi
  // định phạm vi context (context scoping) này, đồng thời VẪN giữ đúng
  // hành vi rebuild khi đổi tab (TabController là ChangeNotifier, AnimatedBuilder
  // lắng nghe trực tiếp nó, không qua context nào cả).
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 7, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant StoryBibleScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  Future<void> _load() async {
    final c = await db.allCharacters(widget.novelId);
    final r = await db.allWorldRules(widget.novelId);
    final s = await db.allStyleProfiles(widget.novelId);
    final g = await db.allGlossaryTerms(widget.novelId);
    final beats = await db.allPlotBeats(widget.novelId);
    final threads = await db.allPlotThreads(widget.novelId);
    final goal = await db.loadWritingGoal(widget.novelId);
    final log = await db.recentWordLog(widget.novelId, days: 30);
    if (!mounted) return;
    setState(() {
      characters = c;
      rules = r;
      styles = s;
      glossaryTerms = g;
      plotBeats = beats;
      plotThreads = threads;
      writingGoal = goal;
      wordLog = log;
    });
  }

  Future<void> _addStyleFromDescription() async {
    final result = await _editDialog(
      title: 'Mô tả văn phong bằng lời',
      fields: {'name': 'Tên hồ sơ (vd: Cổ trang trầm lắng)', 'profile_description': 'Mô tả văn phong'},
    );
    if (result == null) return;
    await db.upsertStyleProfile(StyleProfile(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      name: result['name'] ?? '',
      profileDescription: result['profile_description'] ?? '',
    ));
    _load();
  }

  // Dán một đoạn văn CỦA CHÍNH NGƯỜI DÙNG (chương cũ họ tự viết) để AI
  // phân tích ra mô tả văn phong, thay vì lưu lại nguyên văn tác phẩm.
  Future<void> _addStyleFromSample() async {
    final result = await _editDialog(
      title: 'Học văn phong từ mẫu văn của bạn',
      fields: {'name': 'Tên hồ sơ', 'sample': 'Dán một đoạn văn bạn đã viết (không phải của người khác)'},
    );
    if (result == null || (result['sample'] ?? '').trim().isEmpty) return;
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(content: Row(children: [
        CircularProgressIndicator(),
        SizedBox(width: 16),
        Text('Đang phân tích văn phong...'),
      ])),
    );
    try {
      final provider = await SettingsService().currentProvider();
      final description = await StyleService().analyzeStyleFromSample(result['sample']!, provider);
      await db.upsertStyleProfile(StyleProfile(
        id: const Uuid().v4(),
        novelId: widget.novelId,
        name: result['name'] ?? 'Văn phong của tôi',
        profileDescription: description,
      ));
      _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _addCharacter() async {
    final nameCtrl = TextEditingController();
    final roleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final keywordsCtrl = TextEditingController();
    String category = kCharacterCategories.first;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Nhân vật mới'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên')),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Phân loại'),
                items: kCharacterCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              TextField(controller: roleCtrl, decoration: const InputDecoration(labelText: 'Vai trò (mô tả tự do, vd: Đội trưởng)')),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả'), maxLines: 5),
              TextField(
                controller: keywordsCtrl,
                decoration: const InputDecoration(labelText: 'Từ khóa kích hoạt (cách nhau bởi dấu phẩy)'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final name = nameCtrl.text.trim();
    if (name.isEmpty) return;
    final kw = keywordsCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final character = Character(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      name: name,
      role: roleCtrl.text.trim(),
      category: category,
      description: descCtrl.text.trim(),
      keywords: kw.isEmpty ? [name] : kw,
    );
    await db.upsertCharacter(character);
    await (await _rag()).indexCharacter(character);
    _load();
  }

  Future<void> _addRule() async {
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();
    final keywordsCtrl = TextEditingController();
    String category = kWorldRuleCategories.first;
    bool isHardRule = true;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Luật thế giới mới'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tiêu đề')),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Phân loại'),
                items: kWorldRuleCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              TextField(controller: contentCtrl, decoration: const InputDecoration(labelText: 'Nội dung'), maxLines: 5),
              TextField(
                controller: keywordsCtrl,
                decoration: const InputDecoration(labelText: 'Từ khóa kích hoạt (nếu không phải luật cứng)'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Luật cứng (không bao giờ được vi phạm)'),
                value: isHardRule,
                onChanged: (v) => setDialogState(() => isHardRule = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    final rule = WorldRule(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      title: title,
      content: contentCtrl.text.trim(),
      isHardRule: isHardRule,
      category: category,
      keywords: keywordsCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
    );
    await db.upsertWorldRule(rule);
    await (await _rag()).indexWorldRule(rule);
    _load();
  }

  // ---------- Glossary (bảng thuật ngữ) ----------
  Future<void> _addGlossaryTerm() async {
    final termCtrl = TextEditingController();
    final defCtrl = TextEditingController();
    String category = kGlossaryCategories.first;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Thuật ngữ mới'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: termCtrl, decoration: const InputDecoration(labelText: 'Thuật ngữ')),
            DropdownButtonFormField<String>(
              value: category,
              decoration: const InputDecoration(labelText: 'Phân loại'),
              items: kGlossaryCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (v) => setDialogState(() => category = v ?? category),
            ),
            TextField(controller: defCtrl, decoration: const InputDecoration(labelText: 'Định nghĩa / giải thích'), maxLines: 4),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final term = termCtrl.text.trim();
    if (term.isEmpty) return;
    await db.upsertGlossaryTerm(GlossaryTerm(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      term: term,
      definition: defCtrl.text.trim(),
      category: category,
    ));
    _load();
  }

  Future<void> _deleteGlossaryTerm(GlossaryTerm t) async {
    await db.deleteGlossaryTerm(t.id);
    _load();
  }

  Future<RagService> _rag() async => RagService(
        db,
        await SettingsService().currentEmbeddingService(),
        novelId: widget.novelId,
        contextBudgetChars: await SettingsService().loadRagBudget(),
      );

  Future<Map<String, String>?> _editDialog({
    required String title,
    required Map<String, String> fields,
  }) async {
    final controllers = {for (final k in fields.keys) k: TextEditingController()};
    return showDialog<Map<String, String>>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: fields.entries
              .map((e) => TextField(
                    controller: controllers[e.key],
                    decoration: InputDecoration(labelText: e.value),
                    maxLines: (e.key == 'description' || e.key == 'content' || e.key == 'profile_description' || e.key == 'sample') ? 5 : 1,
                  ))
              .toList(),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              {for (final k in controllers.keys) k: controllers[k]!.text},
            ),
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteCharacter(Character c) async {
    await db.deleteCharacter(c.id);
    _load();
  }

  Future<void> _deleteRule(WorldRule r) async {
    await db.deleteWorldRule(r.id);
    _load();
  }

  // ---------- Dàn ý toàn truyện (PlotBeat) ----------
  static const kBeatTypes = ['Mở đầu', 'Điểm nút', 'Cao trào', 'Kết thúc', 'Khác'];

  Future<void> _addOrEditBeat({PlotBeat? existing}) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    String beatType = existing?.beatType ?? kBeatTypes.first;
    String status = existing?.status ?? 'planned';

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: Text(existing == null ? 'Điểm nút mới' : 'Sửa điểm nút'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên (vd: Nhân vật chính rời làng)')),
              DropdownButtonFormField<String>(
                value: beatType,
                decoration: const InputDecoration(labelText: 'Loại'),
                items: kBeatTypes.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => beatType = v ?? beatType),
              ),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả'), maxLines: 4),
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(labelText: 'Trạng thái'),
                items: const [
                  DropdownMenuItem(value: 'planned', child: Text('Mới lên kế hoạch')),
                  DropdownMenuItem(value: 'drafted', child: Text('Đang viết')),
                  DropdownMenuItem(value: 'done', child: Text('Đã xong')),
                ],
                onChanged: (v) => setDialogState(() => status = v ?? status),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    await db.upsertPlotBeat(PlotBeat(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      title: title,
      description: descCtrl.text.trim(),
      beatType: beatType,
      orderIndex: existing?.orderIndex ?? plotBeats.length,
      linkedChapterNumber: existing?.linkedChapterNumber,
      status: status,
    ));
    _load();
  }

  Future<void> _deleteBeat(PlotBeat b) async {
    await db.deletePlotBeat(b.id);
    _load();
  }

  Future<void> _reorderBeats(int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex -= 1;
    final list = List<PlotBeat>.from(plotBeats);
    final item = list.removeAt(oldIndex);
    list.insert(newIndex, item);
    setState(() => plotBeats = list);
    await db.reorderPlotBeats(list);
  }

  // AI gợi ý beat sheet dựa trên mô tả truyện (Novel.description) + văn
  // phong/nhân vật hiện có (nếu có) — chạy qua TranslationService để tôn
  // trọng cài đặt dịch thuật trung gian VÀ được bảo vệ Foreground Service
  // tự động (đã sửa gốc, xem translation_service.dart). Model local có
  // thể không tuân JSON nghiêm ngặt, nên dùng định dạng dòng đơn giản dễ
  // parse: "Loại | Tên | Mô tả" — bỏ qua dòng nào không đúng định dạng
  // thay vì crash cả phần gợi ý.
  // Mã loại điểm nút bằng tiếng Anh viết hoa (KHÔNG phải nhãn tiếng Việt
  // hiển thị) — lý do: khi dịch thuật trung gian BẬT, câu trả lời của AI
  // phải đi qua 1 vòng dịch Việt->ngôn ngữ trung gian->Việt; nhãn tiếng
  // Việt tự nhiên ("Mở đầu", "Điểm nút"...) KHÔNG đảm bảo dịch đi dịch lại
  // ra ĐÚNG Y HỆT chữ gốc (dịch không phải phép biến đổi 2 chiều hoàn hảo)
  // — khiến logic so khớp loại dễ sai, rơi hết vào "Khác". Mã tiếng Anh
  // viết hoa dạng token (OPENING/TURN/CLIMAX/ENDING) ít bị dịch thuật biến
  // dạng hơn nhiều so với cụm từ tiếng Việt tự nhiên, nên dùng làm định
  // dạng trung gian, rồi tự ánh xạ sang nhãn tiếng Việt hiển thị ở tầng
  // Dart — không phụ thuộc vào việc dịch có khớp chính xác hay không.
  static const Map<String, String> _beatTypeCodeToLabel = {
    'OPENING': 'Mở đầu',
    'TURN': 'Điểm nút',
    'CLIMAX': 'Cao trào',
    'ENDING': 'Kết thúc',
  };

  Future<void> _suggestBeatsWithAI() async {
    final novel = await db.novelById(widget.novelId);
    if (novel == null || !mounted) return;
    if (novel.description.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Truyện chưa có mô tả — vào Cài đặt truyện để thêm mô tả trước, AI cần đó để gợi ý.'),
      ));
      return;
    }
    setState(() => suggestingBeats = true);
    try {
      final provider = await SettingsService().currentProvider();
      final raw = await TranslationService(SettingsService()).generateWithOptionalTranslation(
        mainProvider: provider,
        systemPrompt: 'Bạn là biên tập viên tiểu thuyết. Chỉ trả lời đúng định dạng yêu cầu, '
            'mỗi điểm nút 1 dòng, không đánh số, không giải thích thêm. '
            'GIỮ NGUYÊN mã loại viết hoa (OPENING/TURN/CLIMAX/ENDING) — KHÔNG dịch mã này sang tiếng Việt hay ngôn ngữ khác.',
        userPrompt: 'Dựa trên mô tả truyện sau, gợi ý 6-10 điểm nút cốt truyện chính (beat sheet) '
            'theo cấu trúc 3 hồi (mở đầu, điểm nút, cao trào, kết thúc). '
            'Mỗi dòng theo đúng định dạng: MÃ_LOẠI | Tên ngắn gọn | Mô tả 1 câu\n'
            'MÃ_LOẠI chỉ được là 1 trong 4 mã sau, viết hoa y hệt, không dịch: OPENING, TURN, CLIMAX, ENDING.\n\n'
            'Mô tả truyện: ${novel.description}',
        temperature: 0.8,
        maxTokens: 800,
      );
      final lines = raw.split('\n').map((l) => l.trim()).where((l) => l.contains('|'));
      var order = plotBeats.length;
      var added = 0;
      for (final line in lines) {
        final parts = line.split('|').map((p) => p.trim()).toList();
        if (parts.length < 2) continue; // dòng không đúng định dạng, bỏ qua thay vì crash
        // Tìm mã loại (không phân biệt hoa/thường, bỏ qua ký tự thừa AI có
        // thể chèn quanh mã) trong TOÀN BỘ dòng thay vì chỉ đúng parts[0] —
        // AI đôi khi trả về "Loại: OPENING" thay vì "OPENING" trần trụi.
        final codeMatch = _beatTypeCodeToLabel.keys.firstWhere(
          (code) => line.toUpperCase().contains(code),
          orElse: () => '',
        );
        final type = codeMatch.isEmpty ? 'Khác' : _beatTypeCodeToLabel[codeMatch]!;
        final title = parts[1];
        final desc = parts.length >= 3 ? parts[2] : '';
        if (title.isEmpty) continue;
        await db.upsertPlotBeat(PlotBeat(
          id: const Uuid().v4(),
          novelId: widget.novelId,
          title: title,
          description: desc,
          beatType: type,
          orderIndex: order++,
          status: 'planned',
        ));
        added++;
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(added > 0 ? 'Đã thêm $added điểm nút gợi ý — sửa lại tùy ý.' : 'AI không trả về gợi ý hợp lệ, thử lại.'),
        ));
      }
      _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) setState(() => suggestingBeats = false);
    }
  }

  // ---------- Tuyến truyện / subplot (PlotThread) ----------
  static const kThreadColors = [0xFF6750A4, 0xFFD32F2F, 0xFF388E3C, 0xFF1976D2, 0xFFF57C00, 0xFF7B1FA2, 0xFF00796B];

  Future<void> _addOrEditThread({PlotThread? existing}) async {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    int colorValue = existing?.colorValue ?? kThreadColors.first;
    String status = existing?.status ?? 'active';

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: Text(existing == null ? 'Tuyến truyện mới' : 'Sửa tuyến truyện'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên tuyến (vd: Tuyến chính, Tình cảm phụ)')),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả'), maxLines: 3),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: kThreadColors
                    .map((c) => GestureDetector(
                          onTap: () => setDialogState(() => colorValue = c),
                          child: CircleAvatar(
                            backgroundColor: Color(c),
                            radius: 14,
                            child: colorValue == c ? const Icon(Icons.check, size: 16, color: Colors.white) : null,
                          ),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(labelText: 'Trạng thái'),
                items: const [
                  DropdownMenuItem(value: 'active', child: Text('Đang chạy')),
                  DropdownMenuItem(value: 'paused', child: Text('Tạm gác')),
                  DropdownMenuItem(value: 'resolved', child: Text('Đã khép lại')),
                ],
                onChanged: (v) => setDialogState(() => status = v ?? status),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final name = nameCtrl.text.trim();
    if (name.isEmpty) return;
    await db.upsertPlotThread(PlotThread(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      name: name,
      description: descCtrl.text.trim(),
      colorValue: colorValue,
      status: status,
    ));
    _load();
  }

  Future<void> _deleteThread(PlotThread t) async {
    await db.deletePlotThread(t.id);
    _load();
  }

  // Hiện danh sách chương thuộc tuyến này — giúp phát hiện tuyến bị "bỏ
  // quên" quá lâu (không chương nào thúc đẩy tuyến này trong 1 khoảng dài).
  Future<void> _showChaptersInThread(PlotThread t) async {
    final allChapters = await db.allChapters(widget.novelId);
    final inThread = allChapters.where((c) => c.threadIds.contains(t.id)).toList()..sort((a, b) => a.number.compareTo(b.number));
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: inThread.isEmpty
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: Text('Chưa chương nào gắn tuyến này. Vào màn soạn chương để gắn.'),
              )
            : ListView(
                shrinkWrap: true,
                children: inThread
                    .map((c) => ListTile(
                          leading: Text('#${c.number}'),
                          title: Text(c.title.isEmpty ? '(Chưa đặt tên)' : c.title),
                        ))
                    .toList(),
              ),
      ),
    );
  }

  // ---------- Mục tiêu viết mỗi ngày ----------
  Future<void> _editGoal() async {
    final ctrl = TextEditingController(text: (writingGoal?.dailyTargetWords ?? 500).toString());
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Mục tiêu viết mỗi ngày'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Số chữ / ngày', suffixText: 'chữ'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
        ],
      ),
    );
    if (ok != true) return;
    final target = int.tryParse(ctrl.text.trim()) ?? 500;
    await db.saveWritingGoal(WritingGoal(novelId: widget.novelId, dailyTargetWords: target));
    _load();
  }

  // Tính (ngày -> số chữ viết TRONG ngày đó) từ dãy snapshot tổng số chữ
  // — hiệu số giữa 2 snapshot liền kề. Ngày đầu tiên trong dãy không có
  // ngày trước để so sánh nên bỏ qua (không tính vào streak).
  List<MapEntry<String, int>> _dailyDeltas() {
    final result = <MapEntry<String, int>>[];
    for (var i = 1; i < wordLog.length; i++) {
      final prev = wordLog[i - 1]['total_words'] as int;
      final cur = wordLog[i]['total_words'] as int;
      result.add(MapEntry(wordLog[i]['date'] as String, (cur - prev).clamp(0, 1 << 30)));
    }
    return result;
  }

  int _currentStreak(int target) {
    final deltas = _dailyDeltas();
    var streak = 0;
    for (var i = deltas.length - 1; i >= 0; i--) {
      if (deltas[i].value >= target) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Bách khoa truyện'),
          bottom: TabBar(
            controller: _tabController,
            isScrollable: true,
            tabs: const [
              Tab(text: 'Nhân vật'),
              Tab(text: 'Luật thế giới'),
              Tab(text: 'Văn phong'),
              Tab(text: 'Thuật ngữ'),
              Tab(text: 'Dàn ý'),
              Tab(text: 'Tuyến truyện'),
              Tab(text: 'Mục tiêu'),
            ],
          ),
        ),
        body: TabBarView(controller: _tabController, children: [
          characters.isEmpty
              ? const Center(child: Text('Chưa có nhân vật nào. Bấm + để thêm.'))
              : ListView(
                  children: characters
                      .map((c) => ListTile(
                            leading: CircleAvatar(child: Text(c.name.isNotEmpty ? c.name[0] : '?')),
                            title: Row(children: [
                              Flexible(child: Text(c.name)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(c.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text('${c.role} · ${c.description}'),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () => _deleteCharacter(c),
                            ),
                          ))
                      .toList(),
                ),
          rules.isEmpty
              ? const Center(child: Text('Chưa có luật thế giới nào. Bấm + để thêm.'))
              : ListView(
                  children: rules
                      .map((r) => ListTile(
                            leading: Icon(r.isHardRule ? Icons.gavel : Icons.info_outline),
                            title: Row(children: [
                              Flexible(child: Text(r.title)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(r.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text(r.content),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () => _deleteRule(r),
                            ),
                          ))
                      .toList(),
                ),
          ListView(
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Mỗi hồ sơ là một mô tả văn phong (không lưu nguyên văn tác phẩm ai khác). '
                  'Có thể chọn hồ sơ này khi viết tiếp chương hoặc đắp thịt outline.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ),
              ...styles.map((s) => ListTile(
                    leading: const Icon(Icons.edit_note_outlined),
                    title: Text(s.name),
                    subtitle: Text(s.profileDescription, maxLines: 2, overflow: TextOverflow.ellipsis),
                    onLongPress: () async {
                      await db.deleteStyleProfile(s.id);
                      _load();
                    },
                  )),
            ],
          ),
          glossaryTerms.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chưa có thuật ngữ nào. Dùng để tra cứu nhanh tên địa danh/thuật ngữ riêng của '
                      'truyện — khác Story Bible ở chỗ KHÔNG tự động nạp vào prompt AI.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView(
                  children: glossaryTerms
                      .map((t) => ListTile(
                            leading: const Icon(Icons.menu_book_outlined),
                            title: Row(children: [
                              Flexible(child: Text(t.term)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(t.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text(t.definition),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () => _deleteGlossaryTerm(t),
                            ),
                          ))
                      .toList(),
                ),
          // ── Tab "Dàn ý": beat sheet toàn truyện, kéo-thả sắp xếp ──
          Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                const Expanded(
                  child: Text(
                    'Điểm nút cốt truyện toàn truyện — kéo-thả để sắp xếp lại thứ tự.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
                FilledButton.icon(
                  onPressed: suggestingBeats ? null : _suggestBeatsWithAI,
                  icon: suggestingBeats
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome_outlined, size: 16),
                  label: Text(suggestingBeats ? 'Đang gợi ý...' : 'AI gợi ý'),
                ),
              ]),
            ),
            Expanded(
              child: plotBeats.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Chưa có điểm nút nào. Bấm + để tự thêm, hoặc "AI gợi ý" để có bản nháp ban đầu.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    )
                  : ReorderableListView(
                      onReorder: _reorderBeats,
                      children: plotBeats
                          .map((b) => ListTile(
                                key: ValueKey(b.id),
                                leading: CircleAvatar(
                                  radius: 14,
                                  child: Icon(
                                    b.status == 'done'
                                        ? Icons.check_circle_outline
                                        : b.status == 'drafted'
                                            ? Icons.edit_outlined
                                            : Icons.circle_outlined,
                                    size: 16,
                                  ),
                                ),
                                title: Row(children: [
                                  Flexible(child: Text(b.title)),
                                  const SizedBox(width: 6),
                                  Chip(
                                    label: Text(b.beatType, style: const TextStyle(fontSize: 10)),
                                    visualDensity: VisualDensity.compact,
                                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    padding: EdgeInsets.zero,
                                  ),
                                ]),
                                subtitle: Text(b.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                                onTap: () => _addOrEditBeat(existing: b),
                                trailing: IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 18),
                                  onPressed: () => _deleteBeat(b),
                                ),
                              ))
                          .toList(),
                    ),
            ),
          ]),
          // ── Tab "Tuyến truyện": subplot, chấm màu nhận diện ──
          plotThreads.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chưa có tuyến truyện nào. Bấm + để thêm (vd "Tuyến chính", "Tình cảm phụ").',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView(
                  children: plotThreads
                      .map((t) => ListTile(
                            leading: CircleAvatar(backgroundColor: Color(t.colorValue), radius: 10),
                            title: Text(t.name),
                            subtitle: Text(
                              t.description.isEmpty
                                  ? (t.status == 'active' ? 'Đang chạy' : t.status == 'paused' ? 'Tạm gác' : 'Đã khép lại')
                                  : t.description,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () => _showChaptersInThread(t),
                            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                              IconButton(
                                icon: const Icon(Icons.edit_outlined, size: 18),
                                onPressed: () => _addOrEditThread(existing: t),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 18),
                                onPressed: () => _deleteThread(t),
                              ),
                            ]),
                          ))
                      .toList(),
                ),
          // ── Tab "Mục tiêu": số chữ/ngày, streak, 14 ngày gần nhất ──
          Builder(builder: (context) {
            final target = writingGoal?.dailyTargetWords ?? 500;
            final deltas = _dailyDeltas();
            final todayKey = () {
              final now = DateTime.now();
              return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
            }();
            final todayEntry = deltas.where((e) => e.key == todayKey);
            final todayWords = todayEntry.isEmpty ? 0 : todayEntry.first.value;
            final streak = _currentStreak(target);
            final recentDeltas = deltas.reversed.take(14).toList().reversed.toList();
            return ListView(padding: const EdgeInsets.all(16), children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Text('Mục tiêu hôm nay', style: TextStyle(fontWeight: FontWeight.bold)),
                      const Spacer(),
                      TextButton(onPressed: _editGoal, child: const Text('Sửa mục tiêu')),
                    ]),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: target == 0 ? 0 : (todayWords / target).clamp(0, 1)),
                    const SizedBox(height: 8),
                    Text('$todayWords / $target chữ'),
                    if (streak > 0) ...[
                      const SizedBox(height: 4),
                      Text('🔥 $streak ngày liên tiếp đạt mục tiêu', style: const TextStyle(color: Colors.orange)),
                    ],
                  ]),
                ),
              ),
              const SizedBox(height: 16),
              const Text('14 ngày gần nhất', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (recentDeltas.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('Chưa có dữ liệu — lưu 1 chương để bắt đầu theo dõi.', style: TextStyle(color: Colors.grey)),
                )
              else
                ...recentDeltas.map((e) => ListTile(
                      dense: true,
                      leading: Icon(
                        e.value >= target ? Icons.check_circle : Icons.circle_outlined,
                        color: e.value >= target ? Colors.green : Colors.grey,
                        size: 18,
                      ),
                      title: Text(e.key),
                      trailing: Text('${e.value} chữ'),
                    )),
            ]);
          }),
        ]),
        floatingActionButton: AnimatedBuilder(
          // ĐÃ SỬA (bug nút + luôn mở "Nhân vật mới" bất kể đang ở tab
          // nào): `Builder` thường KHÔNG lắng nghe TabController — đọc
          // `DefaultTabController.of(context).index` bên trong nó chỉ
          // lấy đúng giá trị tại lần build ĐẦU TIÊN của toàn màn hình,
          // sau đó vuốt/chạm đổi tab KHÔNG kích hoạt build lại nút FAB
          // (vì TabController.index thay đổi qua notifyListeners(),
          // không phải qua cơ chế InheritedWidget rebuild thông thường).
          // TabController là 1 ChangeNotifier — phải dùng AnimatedBuilder
          // (hoặc addListener thủ công) để thực sự lắng nghe và rebuild
          // đúng lúc tab đổi. Đây là lý do cả 4 tab đều hiện "Nhân vật
          // mới" giống hệt nhau trong ảnh chụp màn hình.
          animation: _tabController,
          builder: (context, _) {
            final tabIndex = _tabController.index;
            if (tabIndex == 0) {
              return FloatingActionButton(onPressed: _addCharacter, child: const Icon(Icons.add));
            } else if (tabIndex == 1) {
              return FloatingActionButton(onPressed: _addRule, child: const Icon(Icons.add));
            } else if (tabIndex == 3) {
              return FloatingActionButton(onPressed: _addGlossaryTerm, child: const Icon(Icons.add));
            } else if (tabIndex == 4) {
              return FloatingActionButton(onPressed: () => _addOrEditBeat(), child: const Icon(Icons.add));
            } else if (tabIndex == 5) {
              return FloatingActionButton(onPressed: () => _addOrEditThread(), child: const Icon(Icons.add));
            } else if (tabIndex == 6) {
              // Tab "Mục tiêu" không có danh sách để "thêm mới" — sửa mục
              // tiêu đã có nút riêng ngay trong nội dung tab, không cần FAB.
              return const SizedBox.shrink();
            } else if (tabIndex != 2) {
              return const SizedBox.shrink();
            }
            return FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet(
              context: context,
              builder: (_) => SafeArea(
                child: Wrap(children: [
                  ListTile(
                    leading: const Icon(Icons.description_outlined),
                    title: const Text('Mô tả bằng lời'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromDescription();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.content_paste_outlined),
                    title: const Text('Học từ mẫu văn của tôi'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromSample();
                    },
                  ),
                ]),
              ),
            ),
            icon: const Icon(Icons.add),
            label: const Text('Thêm văn phong'),
          );
          },
        ),
    );
  }
}
