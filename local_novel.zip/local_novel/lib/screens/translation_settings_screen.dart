import 'package:flutter/material.dart';
import '../services/settings_service.dart';
import 'file_browser_screen.dart';
import 'local_optimization_screen.dart';

class TranslationSettingsScreen extends StatefulWidget {
  // ĐÃ THÊM (v14 — hệ quả gián tiếp: `LocalOptimizationScreen` giờ cần
  // `novelId` để chạy benchmark đúng model của 1 truyện, mà màn này có
  // link điều hướng sang đó, xem `_LocalOptimizationScreenState._runBenchmark`)
  // — CHƯA có nghĩa là cài đặt dịch thuật đã chuyển sang riêng-truyện,
  // chỉ tạm truyền `novelId` xuyên qua để nút "Tối ưu AI local" trong màn
  // này vẫn mở được (xem thảo luận ở LocalNovel_Architecture_Spec.md về
  // việc mở rộng phạm vi riêng-truyện ra dịch thuật/cấu hình phần cứng,
  // vẫn đang chờ làm ở phiên sau).
  final String novelId;
  const TranslationSettingsScreen({super.key, required this.novelId});
  @override
  State<TranslationSettingsScreen> createState() => _TranslationSettingsScreenState();
}

class _TranslationSettingsScreenState extends State<TranslationSettingsScreen> {
  final settings = SettingsService();
  bool enabled = false;
  String modelPath = '';         // model dịch ngôn ngữ (nhỏ, 0.3B–1.5B)
  String targetLanguage = 'tiếng Anh';
  String stylePrompt = '';
  String promptToTarget = '';    // prompt Việt → ngôn ngữ trung gian
  String promptFromTarget = '';  // prompt ngôn ngữ trung gian → Việt
  bool loading = true;

  // Controllers — khởi tạo ở initState, dispose ở dispose()
  late final TextEditingController _pathCtrl;
  late final TextEditingController _langCtrl;
  late final TextEditingController _styleCtrl;
  late final TextEditingController _promptToCtrl;
  late final TextEditingController _promptFromCtrl;

  @override
  void initState() {
    super.initState();
    _pathCtrl = TextEditingController();
    _langCtrl = TextEditingController();
    _styleCtrl = TextEditingController();
    _promptToCtrl = TextEditingController();
    _promptFromCtrl = TextEditingController();
    _load();
  }

  @override
  void dispose() {
    _pathCtrl.dispose();
    _langCtrl.dispose();
    _styleCtrl.dispose();
    _promptToCtrl.dispose();
    _promptFromCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final e = await settings.loadTranslationEnabled(widget.novelId);
    final p = await settings.loadTranslationModelPath(widget.novelId);
    final lang = await settings.loadTranslationTargetLanguage(widget.novelId);
    final style = await settings.loadTranslationStylePrompt(widget.novelId);
    final pt = await settings.loadTranslationPromptToTarget(widget.novelId);
    final pf = await settings.loadTranslationPromptFromTarget(widget.novelId);
    setState(() {
      enabled = e;
      modelPath = p ?? '';
      targetLanguage = lang;
      stylePrompt = style;
      promptToTarget = pt;
      promptFromTarget = pf;
      _pathCtrl.text = modelPath;
      _langCtrl.text = targetLanguage;
      _styleCtrl.text = stylePrompt;
      _promptToCtrl.text = promptToTarget;
      _promptFromCtrl.text = promptFromTarget;
      loading = false;
    });
  }

  Future<void> _save() async {
    await settings.saveTranslationEnabled(widget.novelId, enabled);
    await settings.saveTranslationModelPath(widget.novelId, _pathCtrl.text.trim());
    await settings.saveTranslationTargetLanguage(widget.novelId, _langCtrl.text.trim());
    await settings.saveTranslationStylePrompt(widget.novelId, _styleCtrl.text.trim());
    await settings.saveTranslationPromptToTarget(widget.novelId, _promptToCtrl.text.trim());
    await settings.saveTranslationPromptFromTarget(widget.novelId, _promptFromCtrl.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đã lưu cài đặt dịch thuật')),
      );
    }
  }

  Future<void> _pickDir(TextEditingController ctrl) async {
    final picked = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const FileBrowserScreen(pickDirectory: true)),
    );
    if (picked != null) setState(() => ctrl.text = picked);
  }

  Widget _sectionHeader(String title) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 4),
        child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
      );

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dịch thuật trung gian'),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('Lưu', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        // ── Giới thiệu ──────────────────────────────────────────────────
        const Text(
          'Nhiều model viết truyện hay lại không được huấn luyện nhiều trên '
          'tiếng Việt, viết trực tiếp dễ ra câu ngô nghê, lặp từ vô nghĩa, ký '
          'tự lạ. Bật tính năng này để: dịch câu hỏi/outline sang ngôn ngữ '
          'model hiểu tốt → model chính sinh văn bản → dịch kết quả về tiếng Việt.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => LocalOptimizationScreen(novelId: widget.novelId)),
            ),
            icon: const Icon(Icons.tune_outlined, size: 16),
            label: const Text('Mở "Tối ưu AI local" (giữ/xả model trong RAM)'),
          ),
        ),
        const Divider(height: 24),

        // ── Bật/tắt ─────────────────────────────────────────────────────
        SwitchListTile(
          title: const Text('Bật dịch thuật trung gian'),
          subtitle: const Text('Tắt theo mặc định — chỉ bật nếu thấy AI viết tiếng Việt lỗi'),
          value: enabled,
          onChanged: (v) => setState(() => enabled = v),
        ),
        const Divider(height: 24),

        // ── Model dịch ngôn ngữ ──────────────────────────────────────────
        _sectionHeader('1. Model dịch ngôn ngữ (nhỏ, 0.3B–1.5B)'),
        const Text(
          'Dùng để dịch câu hỏi Việt → ngôn ngữ trung gian và dịch kết quả ngược về Việt. '
          'Nên chọn model nhỏ để dịch nhanh, tiết kiệm RAM.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _pathCtrl,
          decoration: const InputDecoration(
            labelText: 'Thư mục model dịch ngôn ngữ',
            helperText: 'Thư mục chứa config.json của model MNN',
            helperMaxLines: 2,
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: OutlinedButton.icon(
            onPressed: () => _pickDir(_pathCtrl),
            icon: const Icon(Icons.folder_open_outlined, size: 16),
            label: const Text('Duyệt thư mục'),
          ),
        ),

        const Divider(height: 24),

        // ── Cài đặt dịch ────────────────────────────────────────────────
        // ĐÃ XOÁ mục "Model sinh văn bản riêng" từng có ở đây — chốt lại
        // sau khi người dùng chỉ ra xung đột: lựa chọn "model chính hay
        // model dịch thuật" CHỈ tồn tại ở hộp thoại xử lý tài liệu
        // (document_screen.dart), KHÔNG phải tính năng toàn app. Mọi nơi
        // khác (kể cả dịch thuật trung gian) LUÔN dùng model đang active
        // trong tab Cài đặt — xem mục 5.73 tài liệu kiến trúc.
        _sectionHeader('2. Ngôn ngữ và phong cách dịch'),
        TextField(
          controller: _langCtrl,
          decoration: const InputDecoration(
            labelText: 'Ngôn ngữ trung gian',
            hintText: 'tiếng Anh',
            helperText: 'Ngôn ngữ model sinh văn bản hiểu tốt nhất (thường là tiếng Anh)',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _styleCtrl,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'Chỉ dẫn phong cách dịch (thêm vào cả 2 chiều)',
            hintText: 'Vd: Giữ đúng văn phong tiểu thuyết, tự nhiên, không dịch máy móc từng chữ.',
          ),
        ),
        const Divider(height: 24),

        // ── Prompt tùy chỉnh ─────────────────────────────────────────────
        _sectionHeader('3. Prompt dịch (nâng cao)'),
        const Text(
          'Tùy chỉnh prompt hệ thống cho từng chiều dịch. '
          '{targetLanguage} sẽ tự được thay bằng ngôn ngữ trung gian đã chọn ở trên. '
          'Để trống để dùng prompt mặc định.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _promptToCtrl,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Prompt chiều Việt → {targetLanguage}',
            hintText:
                'Dịch đoạn văn bản tiếng Việt sau sang {targetLanguage}. '
                'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.',
            helperText: 'Hỗ trợ placeholder {targetLanguage}',
            helperMaxLines: 2,
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
            onPressed: () => setState(() => _promptToCtrl.text = ''),
            child: const Text('Reset về mặc định'),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _promptFromCtrl,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Prompt chiều {targetLanguage} → Việt',
            hintText:
                'Dịch đoạn văn bản {targetLanguage} sau sang tiếng Việt tự nhiên, đúng văn phong tiểu thuyết. '
                'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.',
            helperText: 'Hỗ trợ placeholder {targetLanguage}',
            helperMaxLines: 2,
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
            onPressed: () => setState(() => _promptFromCtrl.text = ''),
            child: const Text('Reset về mặc định'),
          ),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
