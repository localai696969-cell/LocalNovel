// Mọi provider AI (local hay cloud API) đều implement interface này.
// App không tự thêm bất kỳ lớp lọc/kiểm duyệt nội dung nào ở tầng này —
// request được chuyển thẳng tới provider, response trả thẳng về app.
// Lưu ý: mỗi provider cloud (Anthropic, OpenAI, ...) vẫn áp dụng chính sách
// nội dung riêng của họ ở phía server — đó là giới hạn nằm ngoài phạm vi
// kiểm soát của app, áp dụng bất kể app có "bộ lọc" hay không.
abstract class AIProvider {
  String get name;
  String get description;

  // Sinh văn bản một lần (không streaming) — dùng cho các tác vụ ngắn
  // như tóm tắt chương, kiểm tra nhất quán.
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  });

  // Sinh văn bản dạng stream — dùng cho khung chat và viết tiếp chương,
  // để người dùng thấy chữ hiện ra dần thay vì chờ toàn bộ phản hồi.
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  });

  // Kiểm tra provider có sẵn sàng không (model đã tải xong / API key hợp lệ)
  Future<bool> isReady();
}

enum AIProviderType { localLlama, api }

class AIProviderConfig {
  AIProviderType type;
  String? apiKey;
  String? baseUrl; // dùng cho local server hoặc endpoint tương thích OpenAI
  String? modelId;

  AIProviderConfig({
    required this.type,
    this.apiKey,
    this.baseUrl,
    this.modelId,
  });
}
