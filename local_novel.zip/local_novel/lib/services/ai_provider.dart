// Mọi provider AI (local hay cloud API) đều implement interface này.
// App không tự thêm bất kỳ lớp lọc/kiểm duyệt nội dung nào ở tầng này —
// request được chuyển thẳng tới provider, response trả thẳng về app.
// Lưu ý: mỗi provider cloud (Anthropic, OpenAI, ...) vẫn áp dụng chính sách
// nội dung riêng của họ ở phía server — đó là giới hạn nằm ngoài phạm vi
// kiểm soát của app, áp dụng bất kể app có "bộ lọc" hay không.
abstract class AIProvider {
  String get name;
  String get description;

  // Sinh văn bản một lần (không streaming) — dùng cho các tác vụ ngắn
  // như tóm tắt chương, kiểm tra nhất quán.
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  });

  // Sinh văn bản dạng stream — dùng cho khung chat và viết tiếp chương,
  // để người dùng thấy chữ hiện ra dần thay vì chờ toàn bộ phản hồi.
  // ĐÃ THÊM: reuseKv — CHỈ có tác dụng với LocalLlamaProvider (đề nghị
  // MNN tái sử dụng KV-cache từ lượt trước trong cùng phiên, giảm thời
  // gian chờ prefill cho các lượt chat sau lượt đầu — xem giải thích đầy
  // đủ trong local_provider.dart). Provider cloud API bỏ qua tham số này
  // (không có khái niệm tương đương ở tầng gọi API). Mặc định false —
  // AN TOÀN cho các tác vụ 1 lần độc lập (dịch/tóm tắt tài liệu từng
  // đoạn) — bật true chỉ nên dùng cho hội thoại thật sự nhiều lượt liên
  // tục, nếu không có thể làm lẫn ngữ cảnh giữa các lần gọi không liên
  // quan tới nhau.
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false,
  });

  // Kiểm tra provider có sẵn sàng không (model đã tải xong / API key hợp lệ)
  Future<bool> isReady();
}

enum AIProviderType { localLlama, api }

class AIProviderConfig {
  AIProviderType type;
  String? apiKey;
  String? baseUrl; // dùng cho local server hoặc endpoint tương thích OpenAI
  String? modelId;

  AIProviderConfig({
    required this.type,
    this.apiKey,
    this.baseUrl,
    this.modelId,
  });
}
