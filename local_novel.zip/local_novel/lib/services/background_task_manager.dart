import 'dart:async';
import 'package:flutter/foundation.dart';
import 'ai_provider.dart';
import 'providers/local_provider.dart';
import 'settings_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng: "các nhiệm vụ khác khi thực hiện đều
// đưa vào làm song song, ví dụ vừa tạo chương, vừa chat, vừa dịch tài
// liệu") — bộ quản lý nhiệm vụ nền DÙNG CHUNG TOÀN APP, thay cho việc mỗi
// màn hình tự `await` việc của riêng nó (trước đây: chat_screen, document_
// screen, chapters_batch_generate_screen đều tự chờ tuần tự, không màn nào
// biết màn khác đang làm gì).
//
// QUYẾT ĐỊNH KIẾN TRÚC QUAN TRỌNG NHẤT (đã đọc kỹ mục 5.67 tài liệu kiến
// trúc trước khi viết dòng nào): crash "heap corruption" từng gặp trước
// đây là do 2 lệnh `generate()` CHẠY ĐÈ LÊN NHAU TRÊN CÙNG 1 SLOT model
// LOCAL (Llm::response() của MNN không an toàn khi 2 luồng cùng ghi vào
// chung 1 KV-cache của cùng 1 instance). Lỗi đó CHỈ có thể xảy ra với
// model local (chung tiến trình, chung bộ nhớ trong máy) — gọi HTTP song
// song tới model REMOTE (Colab/API khác) thì mỗi request độc lập hoàn
// toàn, không có vùng nhớ chung nào bị 2 bên cùng ghi. Vì vậy:
//   - Provider LOCAL  → giới hạn đồng thời = 1 (giữ nguyên tuần tự như cũ,
//     khoá Mutex ở tầng Kotlin vẫn là lưới an toàn cuối cùng nếu có gọi
//     nhầm — không cần đổi gì ở đó).
//   - Provider REMOTE → cho phép NHIỀU nhiệm vụ chạy thật sự đồng thời,
//     giới hạn theo cấu hình người dùng đặt (mặc định thận trọng, vì VRAM
//     GPU miễn phí của Colab có hạn — mỗi nhiệm vụ song song cần vùng
//     KV-cache riêng trên server).
//
// Nhiệm vụ SỐNG ĐỘC LẬP với vòng đời màn hình tạo ra nó — rời màn hình
// (back) không huỷ nhiệm vụ đang chạy, đúng yêu cầu "vừa làm A vừa làm B"
// (phải rời màn A mới mở được màn B trên cùng 1 khung điện thoại).
enum TaskStatus { queued, running, done, error, cancelled }

class BackgroundTask {
  final String id;
  final String label; // hiện trong UI, vd "Chương 5: Trận đấu cuối"
  final String category; // 'chat' | 'chapter_batch' | 'document' — để lọc/nhóm hiển thị
  final Future<void> Function() run; // công việc thật — KHÔNG được phụ thuộc BuildContext/State.mounted
  final void Function()? onCancelRequested; // callback tuỳ chọn để runner tự kiểm tra cờ huỷ giữa chừng
  // ĐÃ THÊM — mục BF, 2026-09-19: gắn NGAY LÚC NỘP nhiệm vụ này dùng
  // provider LOCAL hay REMOTE — xem giải thích đầy đủ ở `_scheduleNext()`.
  final bool isLocalProvider;
  TaskStatus status;
  String? errorMessage;
  DateTime createdAt;

  BackgroundTask({
    required this.id,
    required this.label,
    required this.category,
    required this.run,
    required this.isLocalProvider,
    this.onCancelRequested,
    this.status = TaskStatus.queued,
    this.errorMessage,
  }) : createdAt = DateTime.now();
}

class BackgroundTaskManager extends ChangeNotifier {
  BackgroundTaskManager._();
  static final BackgroundTaskManager instance = BackgroundTaskManager._();

  final List<BackgroundTask> _tasks = [];
  List<BackgroundTask> get tasks => List.unmodifiable(_tasks);

  int get runningCount => _tasks.where((t) => t.status == TaskStatus.running).length;
  int get queuedCount => _tasks.where((t) => t.status == TaskStatus.queued).length;

  // ĐÃ SỬA — mục BF, 2026-09-19, theo đúng yêu cầu người dùng "đồng bộ dữ
  // liệu và tiến trình giữa local và remote model" — sửa ĐÚNG giới hạn
  // thật đã tự ghi ở v14 (xem lịch sử bên dưới vẫn giữ nguyên để đối
  // chiếu): trước đây CẢ HÀNG ĐỢI dùng CHUNG 1 cap DUY NHẤT, tính theo
  // provider của "truyện đang mở trên máy" tại THỜI ĐIỂM LÊN LỊCH — nhiệm
  // vụ REMOTE của truyện B có thể bị tính nhầm cap=1 (giới hạn của LOCAL)
  // chỉ vì truyện A (đang mở) đang dùng model local, dù 2 việc không liên
  // quan gì nhau; NGƯỢC LẠI, nhiệm vụ LOCAL của truyện A cũng có thể bị
  // tính nhầm cap rộng hơn (theo cấu hình remote) nếu truyện đang mở lại
  // là 1 truyện KHÁC đang dùng remote — đây mới là hướng NGUY HIỂM thật sự
  // (từng chỉ tự nhận biết "không bao giờ lỏng hơn cho local" nhưng thực
  // ra logic cũ CÓ THỂ xảy ra đúng ca này, vì cap là 1 số DUY NHẤT áp dụng
  // chung cho toàn bộ `runningCount`, không tách theo loại task).
  //
  // BẢN VÁ THẬT: mỗi `BackgroundTask` tự mang theo `isLocalProvider` NGAY
  // từ lúc nộp (nơi gọi luôn biết chắc mình sắp dùng provider nào, không
  // cần suy luận lại ở tầng hàng đợi) — tính RIÊNG 2 bộ đếm "đang chạy":
  // local và remote, mỗi loại so với cap CỦA ĐÚNG LOẠI ĐÓ. Local và remote
  // giờ hoàn toàn ĐỘC LẬP — không còn tình huống 1 bên "mượn" giới hạn của
  // bên kia nữa, dù có bao nhiêu truyện/provider khác nhau đang xen kẽ
  // trong hàng đợi.
  //
  // Cap LOCAL luôn = 1 — lý do an toàn thật KHÔNG đổi (xem giải thích ở
  // đầu file: heap corruption khi 2 lệnh generate() cùng ghi 1 KV-cache).
  static const int _localCap = 1;

  // Cap REMOTE — vẫn phải tra theo "truyện đang mở trên máy" để biết cấu
  // hình max-parallel-remote-tasks, vì setting này lưu theo từng truyện,
  // không lưu theo từng BackgroundTask. GIỚI HẠN THẬT CÒN LẠI (không giấu,
  // nhỏ hơn hẳn giới hạn cũ): nếu 2 truyện khác nhau CÙNG đang chạy nhiệm
  // vụ remote nhưng đặt cấu hình max-parallel KHÁC NHAU, cap áp dụng chung
  // cho CẢ HAI vẫn chỉ lấy theo truyện đang mở — trường hợp hiếm hơn nhiều
  // so với lỗi đã sửa (lẫn giữa LOCAL và REMOTE), và không gây nguy hiểm
  // (local vẫn luôn tách riêng, không bị ảnh hưởng bởi việc này).
  Future<int> _remoteCap() async {
    final activeNovelId = await SettingsService().loadActiveNovelId();
    if (activeNovelId == null) return 1;
    try {
      return await SettingsService().loadMaxParallelRemoteTasks(activeNovelId);
    } catch (_) {
      return 1;
    }
  }

  // Thêm 1 nhiệm vụ vào hàng đợi — trả về NGAY (không đợi chạy xong), để
  // nơi gọi (màn hình) không bị chặn UI, có thể điều hướng đi nơi khác.
  String submit({
    required String label,
    required String category,
    required Future<void> Function() run,
    required bool isLocalProvider,
    void Function()? onCancelRequested,
  }) {
    final id = '${DateTime.now().microsecondsSinceEpoch}_${_tasks.length}';
    _tasks.add(BackgroundTask(
      id: id,
      label: label,
      category: category,
      run: run,
      onCancelRequested: onCancelRequested,
      isLocalProvider: isLocalProvider,
    ));
    notifyListeners();
    _scheduleNext();
    return id;
  }

  void requestCancel(String id) {
    // KHÔNG dùng .firstOrNull (thuộc package:collection, chưa phải
    // dependency của dự án — tránh thêm gói mới theo đúng bài học đã có
    // về rủi ro build từ các gói ngoài, xem pubspec.yaml).
    BackgroundTask? t;
    for (final task in _tasks) {
      if (task.id == id) {
        t = task;
        break;
      }
    }
    if (t == null) return;
    if (t.status == TaskStatus.queued) {
      t.status = TaskStatus.cancelled;
      notifyListeners();
      return;
    }
    // Đang chạy — chỉ gọi hộ callback (nếu runner có hỗ trợ tự kiểm tra cờ
    // huỷ giữa chừng, giống cách chapters_batch_generate_screen đã làm
    // trước đây với isCancelled()); không ép dừng cứng Future đang chạy vì
    // Dart không có cách huỷ Future an toàn giữa chừng khi nó đang gọi
    // native/HTTP — dừng nửa chừng dễ để lại trạng thái dở dang hơn là để
    // nó tự kiểm tra cờ và thoát sạch ở điểm an toàn tiếp theo.
    t.onCancelRequested?.call();
  }

  Future<void> _scheduleNext() async {
    // ĐÃ SỬA — mục BF: đếm RIÊNG số nhiệm vụ ĐANG CHẠY theo từng loại, so
    // với cap CỦA ĐÚNG LOẠI ĐÓ — xem giải thích đầy đủ ở `_remoteCap()`.
    final remoteCap = await _remoteCap();
    var runningLocal = _tasks.where((t) => t.status == TaskStatus.running && t.isLocalProvider).length;
    var runningRemote = _tasks.where((t) => t.status == TaskStatus.running && !t.isLocalProvider).length;

    while (true) {
      BackgroundTask? next;
      for (final task in _tasks) {
        if (task.status != TaskStatus.queued) continue;
        // Bỏ qua (không phải huỷ — vẫn nằm nguyên trong hàng đợi) nhiệm vụ
        // mà LOẠI của nó đã đầy cap — thử nhiệm vụ tiếp theo trong hàng
        // đợi (có thể thuộc loại KHÁC còn chỗ trống). Đây là điểm khác
        // duy nhất so với hành vi cũ: 1 nhiệm vụ remote nộp SAU 1 nhiệm vụ
        // local đang bị chặn (cap local đầy) vẫn được chạy NGAY nếu cap
        // remote còn chỗ — đúng tinh thần "local và remote độc lập nhau"
        // đã ghi ở đầu file, không còn bị xếp hàng chờ oan uổng phía sau
        // 1 loại tài nguyên hoàn toàn khác.
        if (task.isLocalProvider && runningLocal >= _localCap) continue;
        if (!task.isLocalProvider && runningRemote >= remoteCap) continue;
        next = task;
        break;
      }
      if (next == null) break;
      next.status = TaskStatus.running;
      if (next.isLocalProvider) {
        runningLocal++;
      } else {
        runningRemote++;
      }
      notifyListeners();
      // Không await ở đây — chạy "buông tay" (fire-and-forget quản lý bởi
      // chính manager, không phải bởi widget nào) để _scheduleNext() có
      // thể tiếp tục vòng lặp lên lịch thêm nhiệm vụ khác nếu cap > 1.
      unawaited(_runTask(next));
    }
  }

  Future<void> _runTask(BackgroundTask task) async {
    try {
      await task.run();
      if (task.status != TaskStatus.cancelled) task.status = TaskStatus.done;
    } catch (e) {
      task.status = TaskStatus.error;
      task.errorMessage = e.toString();
    } finally {
      notifyListeners();
      // 1 nhiệm vụ vừa xong (dù thành/bại) → có thể còn chỗ trống cho
      // nhiệm vụ khác trong hàng đợi, thử lên lịch tiếp.
      _scheduleNext();
    }
  }

  // Dọn các nhiệm vụ đã xong/lỗi/huỷ khỏi danh sách hiển thị — gọi thủ
  // công từ UI (nút "Xoá lịch sử"), KHÔNG tự động xoá ngay khi xong, để
  // người dùng còn kịp thấy kết quả/lỗi trước khi nó biến mất.
  void clearFinished() {
    _tasks.removeWhere((t) => t.status == TaskStatus.done || t.status == TaskStatus.error || t.status == TaskStatus.cancelled);
    notifyListeners();
  }

  // ĐÃ THÊM: helper cho các màn hình vốn quen "await rồi cập nhật UI của
  // chính mình" (chat, soạn chương, xử lý tài liệu...) — thay vì phải tự
  // viết Completer thủ công ở từng nơi gọi (như chapter_batch_service.dart
  // đã làm cho tạo chương hàng loạt), dùng chung 1 hàm duy nhất: vẫn nộp
  // việc vào manager (được xếp hàng/giới hạn đồng thời đúng theo provider
  // đang active), nhưng trả về y hệt 1 Future<T> bình thường để nơi gọi
  // `await` như trước giờ vẫn quen, không cần đổi cấu trúc code nhiều.
  // ĐÃ SỬA (bug xác nhận thật qua điều tra log: nút "X" ở màn "Tác vụ nền"
  // gọi `requestCancel(id)` → `t.onCancelRequested?.call()`, nhưng MỌI
  // nhiệm vụ tạo qua `submitAndWait()` — CHÍNH LÀ CHAT — đều có
  // `onCancelRequested == null` vì hàm này trước đây KHÔNG nhận tham số đó
  // và KHÔNG truyền gì xuống `submit()`. Bấm X trong lúc chat local đang
  // stream chỉ "ghi nhận" mà không có tác dụng thật gì. Giờ nhận thêm 1
  // callback tuỳ chọn, truyền thẳng xuống `submit()` — nơi gọi (chat_screen)
  // tự quyết định "huỷ" nghĩa là gì (thường là bật 1 cờ `bool cancelled`,
  // kiểm tra định kỳ trong `onChunk`/`isCancelled`).
  Future<T> submitAndWait<T>({
    required String label,
    required String category,
    required Future<T> Function() run,
    required bool isLocalProvider,
    void Function(String id)? onSubmitted,
    void Function()? onCancelRequested,
  }) async {
    final completer = Completer<T>();
    final id = submit(
      label: label,
      category: category,
      onCancelRequested: onCancelRequested,
      isLocalProvider: isLocalProvider,
      run: () async {
        try {
          final result = await run();
          if (!completer.isCompleted) completer.complete(result);
        } catch (e, st) {
          if (!completer.isCompleted) completer.completeError(e, st);
          rethrow; // để _runTask() vẫn tự đánh dấu task.status = error đúng như bình thường
        }
      },
    );
    onSubmitted?.call(id);
    return completer.future;
  }

  // Tra trạng thái 1 nhiệm vụ theo id — màn hình dùng để biết nên hiện
  // "Đang chờ — có tác vụ khác đang chạy trước" (queued) hay "Đang chạy..."
  // (running) thay vì chỉ có 1 trạng thái "đang xử lý" chung chung mù mờ
  // như trước đây (đúng yêu cầu người dùng: không im lặng chờ nữa).
  TaskStatus? statusOf(String id) {
    for (final t in _tasks) {
      if (t.id == id) return t.status;
    }
    return null;
  }

  // Đếm số nhiệm vụ đang XẾP HÀNG TRƯỚC 1 id cụ thể (không tính chính nó)
  // — dùng để hiện "Đang chờ, phía trước còn N tác vụ khác" cụ thể hơn là
  // chỉ nói chung chung "đang chờ".
  int queuedAheadOf(String id) {
    var count = 0;
    for (final t in _tasks) {
      if (t.id == id) break;
      if (t.status == TaskStatus.queued || t.status == TaskStatus.running) count++;
    }
    return count;
  }
}
