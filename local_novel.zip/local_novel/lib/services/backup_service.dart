import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path_provider/path_provider.dart';
import 'database_service.dart';

// Sao lưu/khôi phục dữ liệu app ra 1 file .zip chứa JSON.
// KHÔNG bao gồm API key (nằm ở flutter_secure_storage riêng, không xuất vì
// lý do bảo mật — sau khi khôi phục trên máy mới, người dùng cần nhập lại
// API key, nhưng danh sách provider/model local vẫn được khôi phục đầy đủ).
//
// ĐÃ THÊM (theo yêu cầu người dùng: "sao lưu thì nên có 2 lựa chọn là sao
// lưu toàn app hay sao lưu từng truyện cho người dùng lựa chọn") — 2 chế
// độ xuất riêng biệt, `manifest['scope']` ('app' | 'novel') đánh dấu file
// backup thuộc loại nào để `readBackupFile()`/màn hình khôi phục biết cách
// xử lý đúng (backup 'novel' chỉ chứa 1 truyện, không nên hiểu nhầm là
// "khôi phục sẽ thay thế toàn bộ app").
class BackupService {
  final db = DatabaseService.instance;

  Future<File> exportBackup() async {
    final data = await db.exportAllData();
    final manifest = {
      'app': 'LocalNovel',
      'backup_format_version': 1,
      'scope': 'app',
      'exported_at': DateTime.now().toIso8601String(),
      'data': data,
    };
    return _writeZip(manifest, 'localnovel_backup');
  }

  // Xuất ĐÚNG 1 truyện — xem `DatabaseService.exportNovelData` để biết cách
  // lọc từng bảng. `novelTitle` chỉ để đặt TÊN FILE dễ nhận biết (không
  // ảnh hưởng nội dung khôi phục — dữ liệu thật đọc từ `manifest['data']`).
  Future<File> exportNovelBackup(String novelId, String novelTitle) async {
    final data = await db.exportNovelData(novelId);
    final manifest = {
      'app': 'LocalNovel',
      'backup_format_version': 1,
      'scope': 'novel',
      'novel_id': novelId,
      'novel_title': novelTitle,
      'exported_at': DateTime.now().toIso8601String(),
      'data': data,
    };
    // Tên file an toàn — bỏ ký tự có thể gây lỗi trên 1 số hệ thống file.
    final safeTitle = novelTitle.replaceAll(RegExp(r'[^\w\-. ]'), '_').trim();
    return _writeZip(manifest, 'localnovel_backup_${safeTitle.isEmpty ? novelId : safeTitle}');
  }

  Future<File> _writeZip(Map<String, dynamic> manifest, String filenamePrefix) async {
    final jsonBytes = utf8.encode(jsonEncode(manifest));
    final archive = Archive();
    archive.addFile(ArchiveFile('localnovel_backup.json', jsonBytes.length, jsonBytes));
    final zipBytes = ZipEncoder().encode(archive)!;

    final dir = await getApplicationDocumentsDirectory();
    final outDir = Directory('${dir.path}/exports');
    if (!await outDir.exists()) await outDir.create(recursive: true);
    final stamp = DateTime.now().toIso8601String().replaceAll(RegExp(r'[:.]'), '-');
    final file = File('${outDir.path}/${filenamePrefix}_$stamp.zip');
    await file.writeAsBytes(zipBytes);
    return file;
  }

  // Chấp nhận cả 2 dạng file: .zip (từ exportBackup()) hoặc .json trần (đề
  // phòng người dùng lỡ giải nén/đổi tên) — tự nhận diện qua nội dung byte
  // đầu file thay vì chỉ dựa vào phần mở rộng, tránh lỗi vặt khi người
  // dùng đổi tên file backup mà quên đổi đúng đuôi.
  Future<BackupPreview> readBackupFile(File file) async {
    final bytes = await file.readAsBytes();
    String jsonStr;
    // Zip file luôn bắt đầu bằng "PK" (magic bytes 0x50 0x4B).
    if (bytes.length >= 2 && bytes[0] == 0x50 && bytes[1] == 0x4B) {
      final archive = ZipDecoder().decodeBytes(bytes);
      final jsonEntry = archive.files.firstWhere(
        (f) => f.name.endsWith('.json'),
        orElse: () => throw Exception('File zip này không chứa file backup .json hợp lệ.'),
      );
      jsonStr = utf8.decode(jsonEntry.content as List<int>);
    } else {
      jsonStr = utf8.decode(bytes);
    }

    final manifest = jsonDecode(jsonStr) as Map<String, dynamic>;
    if (manifest['app'] != 'LocalNovel' || manifest['data'] == null) {
      throw Exception('File này không phải bản sao lưu hợp lệ của LocalNovel.');
    }
    final data = manifest['data'] as Map<String, dynamic>;
    final novelCount = (data['novels'] as List?)?.length ?? 0;
    final chapterCount = (data['chapters'] as List?)?.length ?? 0;
    // ĐÃ THÊM: backup cũ (trước khi có lựa chọn theo truyện) không có
    // trường 'scope' — coi như 'app' để không đổi hành vi khôi phục của
    // các file backup đã xuất từ trước.
    final scope = manifest['scope'] as String? ?? 'app';
    return BackupPreview(
      exportedAt: DateTime.tryParse(manifest['exported_at'] as String? ?? ''),
      novelCount: novelCount,
      chapterCount: chapterCount,
      rawData: data,
      scope: scope,
      novelTitle: manifest['novel_title'] as String?,
      novelId: manifest['novel_id'] as String?,
    );
  }

  Future<void> restoreFromPreview(BackupPreview preview) async {
    if (preview.scope == 'novel') {
      await db.importNovelData(preview.rawData);
    } else {
      await db.importAllData(preview.rawData);
    }
  }
}

class BackupPreview {
  final DateTime? exportedAt;
  final int novelCount;
  final int chapterCount;
  final Map<String, dynamic> rawData;
  final String scope; // 'app' | 'novel'
  final String? novelTitle; // chỉ có khi scope == 'novel'
  final String? novelId; // chỉ có khi scope == 'novel'

  BackupPreview({
    required this.exportedAt,
    required this.novelCount,
    required this.chapterCount,
    required this.rawData,
    required this.scope,
    this.novelTitle,
    this.novelId,
  });
}
