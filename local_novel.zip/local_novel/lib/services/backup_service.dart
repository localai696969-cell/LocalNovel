import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path_provider/path_provider.dart';
import 'database_service.dart';

// Sao lưu/khôi phục TOÀN BỘ dữ liệu app (mọi truyện — Story Bible, chương,
// version snapshot, chat, tài liệu, thuật ngữ...) ra 1 file .zip chứa JSON.
// KHÔNG bao gồm API key (nằm ở flutter_secure_storage riêng, không xuất vì
// lý do bảo mật — sau khi khôi phục trên máy mới, người dùng cần nhập lại
// API key, nhưng danh sách provider/model local vẫn được khôi phục đầy đủ).
class BackupService {
  final db = DatabaseService.instance;

  Future<File> exportBackup() async {
    final data = await db.exportAllData();
    final manifest = {
      'app': 'LocalNovel',
      'backup_format_version': 1,
      'exported_at': DateTime.now().toIso8601String(),
      'data': data,
    };
    final jsonBytes = utf8.encode(jsonEncode(manifest));

    final archive = Archive();
    archive.addFile(ArchiveFile('localnovel_backup.json', jsonBytes.length, jsonBytes));
    final zipBytes = ZipEncoder().encode(archive)!;

    final dir = await getApplicationDocumentsDirectory();
    final outDir = Directory('${dir.path}/exports');
    if (!await outDir.exists()) await outDir.create(recursive: true);
    final stamp = DateTime.now().toIso8601String().replaceAll(RegExp(r'[:.]'), '-');
    final file = File('${outDir.path}/localnovel_backup_$stamp.zip');
    await file.writeAsBytes(zipBytes);
    return file;
  }

  // Chấp nhận cả 2 dạng file: .zip (từ exportBackup()) hoặc .json trần (đề
  // phòng người dùng lỡ giải nén/đổi tên) — tự nhận diện qua nội dung byte
  // đầu file thay vì chỉ dựa vào phần mở rộng, tránh lỗi vặt khi người
  // dùng đổi tên file backup mà quên đổi đúng đuôi.
  Future<BackupPreview> readBackupFile(File file) async {
    final bytes = await file.readAsBytes();
    String jsonStr;
    // Zip file luôn bắt đầu bằng "PK" (magic bytes 0x50 0x4B).
    if (bytes.length >= 2 && bytes[0] == 0x50 && bytes[1] == 0x4B) {
      final archive = ZipDecoder().decodeBytes(bytes);
      final jsonEntry = archive.files.firstWhere(
        (f) => f.name.endsWith('.json'),
        orElse: () => throw Exception('File zip này không chứa file backup .json hợp lệ.'),
      );
      jsonStr = utf8.decode(jsonEntry.content as List<int>);
    } else {
      jsonStr = utf8.decode(bytes);
    }

    final manifest = jsonDecode(jsonStr) as Map<String, dynamic>;
    if (manifest['app'] != 'LocalNovel' || manifest['data'] == null) {
      throw Exception('File này không phải bản sao lưu hợp lệ của LocalNovel.');
    }
    final data = manifest['data'] as Map<String, dynamic>;
    final novelCount = (data['novels'] as List?)?.length ?? 0;
    final chapterCount = (data['chapters'] as List?)?.length ?? 0;
    return BackupPreview(
      exportedAt: DateTime.tryParse(manifest['exported_at'] as String? ?? ''),
      novelCount: novelCount,
      chapterCount: chapterCount,
      rawData: data,
    );
  }

  Future<void> restoreFromPreview(BackupPreview preview) async {
    await db.importAllData(preview.rawData);
  }
}

class BackupPreview {
  final DateTime? exportedAt;
  final int novelCount;
  final int chapterCount;
  final Map<String, dynamic> rawData;

  BackupPreview({
    required this.exportedAt,
    required this.novelCount,
    required this.chapterCount,
    required this.rawData,
  });
}
