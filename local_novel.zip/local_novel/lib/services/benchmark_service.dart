import 'dart:math';
import '../services/ai_provider.dart';

class BenchmarkResult {
  final double tokensPerSecond;
  final int wordCount;
  final Duration elapsed;
  BenchmarkResult(this.tokensPerSecond, this.wordCount, this.elapsed);
}

// Đo tốc độ bằng một prompt cố định, ngắn gọn, không phụ thuộc Story
// Bible — mục đích là đo hiệu năng thô của provider/model đang chọn,
// không phải đo chất lượng RAG.
class BenchmarkService {
  static const _testPrompt =
      'Viết một đoạn văn khoảng 150 từ mô tả một khu chợ đêm nhộn nhịp, có mùi thức ăn và ánh đèn lồng.';

  Future<BenchmarkResult> run(AIProvider provider) async {
    final stopwatch = Stopwatch()..start();
    int wordCount = 0;
    final stream = provider.generateStream(
      systemPrompt: 'Bạn là trợ lý viết văn. Chỉ trả lời bằng đoạn văn được yêu cầu.',
      userPrompt: _testPrompt,
      maxTokens: 300,
    );
    await for (final chunk in stream) {
      wordCount += chunk.trim().isEmpty ? 0 : chunk.split(RegExp(r'\s+')).length;
    }
    stopwatch.stop();

    // Model thật cần tối thiểu vài trăm ms để load context + sinh vài
    // chục từ. Nếu xong trong tích tắc với rất ít từ, gần như chắc chắn
    // là lỗi (model không load được) chứ không phải tốc độ thật — báo
    // rõ thay vì đưa ra con số tok/s vô nghĩa.
    if (stopwatch.elapsedMilliseconds < 300 && wordCount < 20) {
      throw Exception(
        'Kết quả bất thường (xong trong ${stopwatch.elapsedMilliseconds}ms, chỉ $wordCount từ) — '
        'khả năng cao model chưa load được đúng cách, không phải do tốc độ máy. '
        'Kiểm tra lại đường dẫn model và thử chat thử trước khi đo tốc độ.',
      );
    }

    final seconds = max(stopwatch.elapsedMilliseconds / 1000, 0.001);
    final estimatedTokens = wordCount * 1.4;
    return BenchmarkResult(estimatedTokens / seconds, wordCount, stopwatch.elapsed);
  }
}
