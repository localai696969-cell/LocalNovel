import 'dart:convert';
import 'package:uuid/uuid.dart';
import 'ai_provider.dart';
import 'database_service.dart';

// ĐÃ THÊM — mục BJ, 2026-09-20 — theo đúng yêu cầu người dùng: "khung chat
// tư vấn về bible rồi tự cập nhật vào bible, hoặc người dùng up tài liệu
// bible vào rồi tự cập nhật vào bible". Tính năng MỚI hoàn toàn — trước
// mục này, KHÔNG có cơ chế nào trích xuất nội dung chat/tài liệu thành
// entry Story Bible có cấu trúc (đã đọc kỹ `document_service.dart` +
// `rag_service.dart` + schema DB để xác nhận, không đoán).
//
// THIẾT KẾ — CỐ Ý KHÔNG tự động ghi thẳng vào Bible: LLM trích xuất có
// thể sai/bịa (đúng loại rủi ro đã thấy xuyên suốt cả cuộc điều tra lặp ký
// tự) — nếu tự động ghi thẳng, 1 lần trích sai là hỏng luôn dữ liệu Bible
// gốc của người dùng, không có "hoàn tác" dễ dàng. Luồng đúng: trích xuất
// → NGƯỜI DÙNG TỰ XEM LẠI, chọn, sửa nếu cần → mới ghi vào DB thật (xem
// `BibleExtractionReviewScreen`). Đây là entry point DUY NHẤT ghi dữ liệu
// — `extractFromText()` bên dưới KHÔNG đụng gì tới DatabaseService cả.

/// 1 mục Story Bible do LLM đề xuất — CHƯA ghi vào DB, chỉ tồn tại trong
/// bộ nhớ cho tới khi người dùng xác nhận ở màn hình xem lại.
class ExtractedBibleEntry {
  final String type; // 'character' | 'world_rule' | 'glossary' | 'plot_thread'
  String title; // name/title/term/name tuỳ loại — cho phép người dùng sửa trước khi lưu
  String content; // description/content/definition/description tuỳ loại
  String category; // tuỳ loại — xem _defaultCategoryFor()
  bool selected; // trạng thái checkbox ở màn xem lại — mặc định true (đã chọn sẵn)
  // ĐÃ THÊM — theo đúng phản hồi người dùng ("đã là giới hạn tại sao
  // không tìm cách khắc phục"): 2 cảnh báo THẬT, không phải chỉ ghi vào
  // mục "giới hạn" rồi bỏ đó.
  String? duplicateWarning; // khác null = nghi trùng với entry Bible ĐÃ CÓ SẴN, ghi rõ tên entry đó
  bool isGrounded; // false = không tìm thấy `title` xuất hiện trong chính văn bản gốc — CẢNH BÁO nghi model bịa, KHÔNG chắc chắn tuyệt đối (xem giải thích ở _flagGroundingAndDuplicates)

  ExtractedBibleEntry({
    required this.type,
    required this.title,
    required this.content,
    required this.category,
    this.selected = true,
    this.duplicateWarning,
    this.isGrounded = true,
  });
}

class BibleExtractionException implements Exception {
  final String message;
  BibleExtractionException(this.message);
  @override
  String toString() => message;
}

/// Kết quả của `extractFromChunks` — kèm thông tin có bao nhiêu chunk bị
/// bỏ sót (lỗi generate/parse) để màn hình xem lại BÁO THẬT cho người
/// dùng biết, không im lặng bỏ qua.
class BibleExtractionResult {
  final List<ExtractedBibleEntry> entries;
  final int totalChunks;
  final int failedChunkCount;
  BibleExtractionResult({required this.entries, required this.totalChunks, required this.failedChunkCount});
}

class BibleExtractionService {
  // ĐÃ THÊM: prompt yêu cầu model trả về ĐÚNG 1 khối JSON, không kèm chữ
  // thừa — đây là cách phổ biến/đáng tin cậy nhất để lấy dữ liệu có cấu
  // trúc từ LLM mà không cần model hỗ trợ "function calling" chính thức
  // (nhiều model local nhỏ/cũ không hỗ trợ). `_parseJsonLoose()` bên dưới
  // vẫn phòng hờ trường hợp model lỡ kèm markdown fence hoặc vài câu dẫn.
  static const _systemPrompt = '''
Bạn là trợ lý đọc văn bản và trích xuất dữ kiện xây dựng thế giới (world-building) có thể dùng làm "Story Bible" cho một cuốn tiểu thuyết.

Đọc đoạn văn bản người dùng cung cấp (có thể là 1 đoạn tư vấn/trò chuyện, hoặc nội dung tài liệu). CHỈ trích những dữ kiện CỤ THỂ, MỚI, có thể tái sử dụng lâu dài (tên nhân vật + đặc điểm, luật lệ/quy tắc thế giới, địa danh/thuật ngữ riêng, tuyến truyện đang phát triển). KHÔNG trích những câu tư vấn/nhận xét chung chung không chứa dữ kiện cụ thể nào (vd "bạn nên miêu tả kỹ hơn", "văn phong ổn").

Nếu đoạn văn bản KHÔNG chứa dữ kiện cụ thể nào đáng lưu, trả về đúng JSON với tất cả mảng rỗng — KHÔNG bịa ra dữ kiện không có trong văn bản.

CHỈ trả về ĐÚNG 1 khối JSON theo khuôn sau, KHÔNG kèm bất kỳ chữ nào khác trước/sau, KHÔNG dùng markdown code fence:
{"characters":[{"name":"","role":"","description":""}],"world_rules":[{"title":"","content":"","category":"Luật lệ|Địa điểm|Vũ khí|Tổ chức|Vật phẩm|Khác"}],"glossary":[{"term":"","definition":"","category":"Địa danh|Thuật ngữ|Vật phẩm|Khác"}],"plot_threads":[{"name":"","description":""}]}
''';

  /// Gọi LLM trích xuất — KHÔNG ghi gì vào DB, chỉ trả về danh sách đề
  /// xuất để người dùng tự xem lại. `provider` dùng interface chung
  /// `AIProvider.generate()` — hoạt động với CẢ model local lẫn API
  /// remote, không phân biệt (đúng tinh thần đồng bộ local/remote mục BF).
  Future<List<ExtractedBibleEntry>> extractFromText(
    String sourceText, {
    required AIProvider provider,
  }) async {
    if (sourceText.trim().isEmpty) return [];
    // Cắt bớt nếu quá dài — tránh prompt khổng lồ cho 1 tác vụ trích xuất
    // đơn giản; 6000 ký tự đủ cho hầu hết 1 đoạn chat hoặc 1 chunk tài
    // liệu, không cần gửi nguyên văn cả tài liệu dài.
    final trimmed = sourceText.length > 6000 ? sourceText.substring(0, 6000) : sourceText;

    final raw = await provider.generate(
      systemPrompt: _systemPrompt,
      userPrompt: 'Văn bản cần trích xuất:\n\n$trimmed',
      temperature: 0.3, // thấp — đây là tác vụ trích xuất dữ kiện, không cần sáng tạo
      maxTokens: 1024,
    );

    if (raw.contains(kAiFailureMarker)) {
      throw BibleExtractionException('Model báo lỗi khi trích xuất: $raw');
    }

    final json = _parseJsonLoose(raw);
    if (json == null) {
      throw BibleExtractionException(
          'Không đọc được kết quả trích xuất dạng JSON từ model (model có thể không tuân theo định dạng yêu cầu — thử lại hoặc đổi model khác).');
    }

    final entries = <ExtractedBibleEntry>[];
    void addAll(String key, String type, String Function(Map) titleOf, String Function(Map) contentOf, String Function(Map) categoryOf) {
      final list = json[key];
      if (list is! List) return;
      for (final item in list) {
        if (item is! Map) continue;
        final title = titleOf(item).trim();
        final content = contentOf(item).trim();
        if (title.isEmpty && content.isEmpty) continue; // model trả entry rỗng — bỏ qua, không thêm mục trống
        entries.add(ExtractedBibleEntry(
          type: type,
          title: title,
          content: content,
          category: categoryOf(item).trim(),
        ));
      }
    }

    addAll('characters', 'character', (m) => '${m['name'] ?? ''}', (m) => '${m['description'] ?? ''}', (m) => '${m['role'] ?? 'Khác'}');
    addAll('world_rules', 'world_rule', (m) => '${m['title'] ?? ''}', (m) => '${m['content'] ?? ''}', (m) => '${m['category'] ?? 'Luật lệ'}');
    addAll('glossary', 'glossary', (m) => '${m['term'] ?? ''}', (m) => '${m['definition'] ?? ''}', (m) => '${m['category'] ?? 'Thuật ngữ'}');
    addAll('plot_threads', 'plot_thread', (m) => '${m['name'] ?? ''}', (m) => '${m['description'] ?? ''}', (m) => '');

    return entries;
  }

  // ĐÃ THÊM — theo đúng phản hồi người dùng, giải quyết THẬT thay vì chỉ
  // ghi "giới hạn" rồi để đó. Nhận NHIỀU đoạn văn bản (mỗi đoạn 1 chunk
  // tài liệu, hoặc 1 tin nhắn chat — dùng chung 1 hàm cho cả 2 luồng) —
  // trích XUẤT TỪNG ĐOẠN riêng (mỗi đoạn vẫn qua đúng giới hạn 6000 ký tự
  // của `extractFromText`, nhưng giờ KHÔNG còn bị bỏ sót phần còn lại của
  // tài liệu dài — mỗi chunk đã có sẵn kích thước hợp lý từ lúc import,
  // xem `document_service.dart`), rồi GỘP + LỌC TRÙNG kết quả, rồi ĐỐI
  // CHIẾU với Bible đã có sẵn để cảnh báo trùng lặp thật, rồi kiểm tra
  // "grounding" (từng mục có thật xuất hiện trong văn bản gốc không).
  //
  // 1 chunk lỗi (model trả JSON hỏng, hoặc generate() báo lỗi) KHÔNG làm
  // hỏng toàn bộ quá trình — bỏ qua đúng chunk đó, tiếp tục các chunk còn
  // lại, gom lỗi để báo cáo tổng kết cho người dùng biết chunk nào bị bỏ
  // sót thay vì im lặng.
  Future<BibleExtractionResult> extractFromChunks(
    List<String> textChunks, {
    required AIProvider provider,
    required String novelId,
    void Function(int done, int total)? onProgress,
  }) async {
    final allEntries = <ExtractedBibleEntry>[];
    final failedChunks = <int>[];
    final nonEmptyChunks = textChunks.where((c) => c.trim().isNotEmpty).toList();
    for (var i = 0; i < nonEmptyChunks.length; i++) {
      onProgress?.call(i, nonEmptyChunks.length);
      try {
        final entries = await extractFromText(nonEmptyChunks[i], provider: provider);
        allEntries.addAll(entries);
      } catch (_) {
        failedChunks.add(i);
      }
    }
    onProgress?.call(nonEmptyChunks.length, nonEmptyChunks.length);

    final deduped = _dedupeWithinResults(allEntries);
    await _flagGroundingAndDuplicates(deduped, novelId: novelId, fullSourceText: nonEmptyChunks.join('\n\n'));

    return BibleExtractionResult(entries: deduped, totalChunks: nonEmptyChunks.length, failedChunkCount: failedChunks.length);
  }

  // Nhiều chunk của CÙNG 1 tài liệu rất có thể cùng nhắc tới 1 nhân vật/
  // luật/thuật ngữ (vd nhân vật xuất hiện xuyên suốt nhiều đoạn) — gộp
  // các entry CÙNG LOẠI có tên gần giống nhau (so khớp không phân biệt
  // hoa/thường, bỏ khoảng trắng thừa) thành 1 entry DUY NHẤT, nối nội dung
  // lại thay vì hiện trùng lặp nhiều lần trong màn xem lại.
  List<ExtractedBibleEntry> _dedupeWithinResults(List<ExtractedBibleEntry> entries) {
    final result = <ExtractedBibleEntry>[];
    for (final e in entries) {
      final existing = _firstWhereOrNull(result, (r) => r.type == e.type && _normalizedTitle(r.title) == _normalizedTitle(e.title) && _normalizedTitle(e.title).isNotEmpty);
      if (existing != null) {
        if (!existing.content.contains(e.content) && e.content.isNotEmpty) {
          existing.content = existing.content.isEmpty ? e.content : '${existing.content}\n${e.content}';
        }
      } else {
        result.add(e);
      }
    }
    return result;
  }

  // ĐÃ THÊM: hàm "tìm phần tử đầu tiên khớp, hoặc null" tự viết — tránh
  // phụ thuộc `package:collection` (`.firstOrNull`) khi CHƯA xác nhận
  // được gói đó có trong pubspec.yaml hay không (Dart core `Iterable`
  // không có sẵn hàm này) — không đoán mù về dependency có sẵn hay không.
  T? _firstWhereOrNull<T>(Iterable<T> items, bool Function(T) test) {
    for (final item in items) {
      if (test(item)) return item;
    }
    return null;
  }

  // ĐÃ THÊM — sửa đúng giới hạn tự ghi ở mục BL ("So khớp trùng lặp chỉ
  // dựa tên CHÍNH XÁC, chưa xử lý được biến thể tên vd 'Thuỷ' vs
  // 'Thủy'"). 2 cách gõ đó là CÙNG 1 âm tiết, chỉ khác vị trí đặt dấu
  // thanh trên cặp nguyên âm "uy" (kiểu cũ đặt dấu ở nguyên âm đầu, kiểu
  // mới đặt ở nguyên âm cuối) — so khớp lowercase+trim cũ không bắt được.
  // Bảng dưới đây gấp MỌI ký tự có dấu tiếng Việt về đúng chữ cái gốc
  // (bỏ dấu thanh + dấu phụ) — khi đó "Thuỷ" và "Thủy" đều gấp về "thuy",
  // trùng khớp bất kể dấu đặt ở nguyên âm nào. CHỈ dùng để SO SÁNH nội bộ
  // (dedupe trong 1 lượt trích + đối chiếu Bible đã có sẵn) — KHÔNG dùng
  // cho hiển thị/lưu trữ, `title` gốc của người dùng giữ nguyên dấu.
  static const Map<String, String> _vietnameseFold = {
    'à': 'a', 'á': 'a', 'ả': 'a', 'ã': 'a', 'ạ': 'a',
    'ă': 'a', 'ằ': 'a', 'ắ': 'a', 'ẳ': 'a', 'ẵ': 'a', 'ặ': 'a',
    'â': 'a', 'ầ': 'a', 'ấ': 'a', 'ẩ': 'a', 'ẫ': 'a', 'ậ': 'a',
    'đ': 'd',
    'è': 'e', 'é': 'e', 'ẻ': 'e', 'ẽ': 'e', 'ẹ': 'e',
    'ê': 'e', 'ề': 'e', 'ế': 'e', 'ể': 'e', 'ễ': 'e', 'ệ': 'e',
    'ì': 'i', 'í': 'i', 'ỉ': 'i', 'ĩ': 'i', 'ị': 'i',
    'ò': 'o', 'ó': 'o', 'ỏ': 'o', 'õ': 'o', 'ọ': 'o',
    'ô': 'o', 'ồ': 'o', 'ố': 'o', 'ổ': 'o', 'ỗ': 'o', 'ộ': 'o',
    'ơ': 'o', 'ờ': 'o', 'ớ': 'o', 'ở': 'o', 'ỡ': 'o', 'ợ': 'o',
    'ù': 'u', 'ú': 'u', 'ủ': 'u', 'ũ': 'u', 'ụ': 'u',
    'ư': 'u', 'ừ': 'u', 'ứ': 'u', 'ử': 'u', 'ữ': 'u', 'ự': 'u',
    'ỳ': 'y', 'ý': 'y', 'ỷ': 'y', 'ỹ': 'y', 'ỵ': 'y',
  };

  String _normalizedTitle(String s) {
    final lower = s.trim().toLowerCase();
    final buf = StringBuffer();
    for (final rune in lower.runes) {
      final ch = String.fromCharCode(rune);
      buf.write(_vietnameseFold[ch] ?? ch);
    }
    // Gộp khoảng trắng thừa (model đôi khi chèn thêm khoảng trắng khi
    // trích lại cùng 1 tên) — tránh " Thủy" và "Thủy" bị coi là khác nhau.
    return buf.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  // ĐÃ THÊM: 2 lớp cảnh báo THẬT, không phải chỉ liệt kê giới hạn.
  // 1) Trùng lặp: so tên với Bible ĐÃ CÓ SẴN trong DB — khớp gần đúng
  //    (không phân biệt hoa/thường) thì cảnh báo rõ tên entry cũ, mặc định
  //    BỎ CHỌN (an toàn hơn — buộc người dùng chủ động xem xét thay vì vô
  //    tình tạo bản trùng do lướt qua nhanh).
  // 2) Grounding: kiểm tra `title` có xuất hiện (không phân biệt hoa/
  //    thường) trong CHÍNH văn bản gốc hay không — CẢNH BÁO THAM KHẢO,
  //    KHÔNG chắc chắn tuyệt đối model đã bịa (model có thể diễn đạt lại
  //    tên hơi khác so với văn bản gốc mà vẫn đúng) — vì vậy KHÔNG tự động
  //    bỏ chọn, chỉ hiện cảnh báo để người dùng tự cân nhắc kỹ hơn.
  Future<void> _flagGroundingAndDuplicates(
    List<ExtractedBibleEntry> entries, {
    required String novelId,
    required String fullSourceText,
  }) async {
    final db = DatabaseService.instance;
    final existingCharacters = await db.allCharacters(novelId);
    final existingRules = await db.allWorldRules(novelId);
    final existingGlossary = await db.allGlossaryTerms(novelId);
    final existingThreads = await db.allPlotThreads(novelId);
    // ĐÃ SỬA: gấp dấu tiếng Việt (xem `_normalizedTitle`) thay vì chỉ
    // lowercase — model có thể trích ra tên với dấu đặt khác kiểu so với
    // chính văn bản gốc (vd model trả "Thủy" trong khi văn bản gốc viết
    // "Thuỷ") mà vẫn ĐÚNG, không phải bịa — trước đây sẽ bị cảnh báo
    // grounding SAI (báo động giả).
    final sourceFolded = _normalizedTitle(fullSourceText);

    for (final e in entries) {
      final normTitle = _normalizedTitle(e.title);
      if (normTitle.isNotEmpty) {
        String? matchName;
        switch (e.type) {
          case 'character':
            matchName = _firstWhereOrNull(existingCharacters, (c) => _normalizedTitle(c.name) == normTitle)?.name;
            break;
          case 'world_rule':
            matchName = _firstWhereOrNull(existingRules, (r) => _normalizedTitle(r.title) == normTitle)?.title;
            break;
          case 'glossary':
            matchName = _firstWhereOrNull(existingGlossary, (g) => _normalizedTitle(g.term) == normTitle)?.term;
            break;
          case 'plot_thread':
            matchName = _firstWhereOrNull(existingThreads, (p) => _normalizedTitle(p.name) == normTitle)?.name;
            break;
        }
        if (matchName != null) {
          e.duplicateWarning = 'Có thể trùng với "$matchName" đã có sẵn trong Bible';
          e.selected = false;
        }
      }
      // Kiểm tra grounding — chỉ áp dụng khi title đủ dài để so khớp có ý
      // nghĩa (title quá ngắn, vd 1-2 ký tự, dễ "tình cờ trùng" trong bất
      // kỳ văn bản nào, gây cảnh báo giả).
      if (e.title.trim().length >= 3) {
        e.isGrounded = sourceFolded.contains(normTitle);
      }
    }
  }

  // ĐÃ THÊM: giữ lại hàm cũ (extractFromText, 1 đoạn duy nhất) để tương
  // thích ngược — nhưng giờ nó chỉ còn là "lõi" gọi model 1 lần, không tự
  // gộp/lọc trùng nữa (việc đó chuyển hết sang `extractFromChunks`).

  // ĐÃ THÊM: model local nhỏ (đặc biệt loại đã lặp/quantize nặng, xem toàn
  // bộ điều tra mục AY-BI) THƯỜNG KHÔNG tuân thủ tuyệt đối "chỉ trả JSON"
  // — hay kèm ```json fence hoặc 1 câu dẫn ("Dưới đây là kết quả:"). Thử
  // parse thẳng trước, thất bại thì tìm khối {...} NGOÀI CÙNG trong toàn
  // bộ chuỗi bằng chỉ số dấu ngoặc (không dùng regex — an toàn hơn với
  // JSON có ngoặc lồng nhau/chuỗi chứa ký tự đặc biệt).
  Map<String, dynamic>? _parseJsonLoose(String raw) {
    try {
      final decoded = jsonDecode(raw.trim());
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (_) {
      // rơi xuống thử tìm khối JSON bên trong
    }
    final start = raw.indexOf('{');
    if (start == -1) return null;
    var depth = 0;
    for (var i = start; i < raw.length; i++) {
      if (raw[i] == '{') depth++;
      if (raw[i] == '}') {
        depth--;
        if (depth == 0) {
          final candidate = raw.substring(start, i + 1);
          try {
            final decoded = jsonDecode(candidate);
            if (decoded is Map<String, dynamic>) return decoded;
          } catch (_) {
            return null;
          }
        }
      }
    }
    return null;
  }
}

/// Sinh id mới theo đúng quy ước UUID đã dùng xuyên suốt app (xem
/// story_models.dart/database_service.dart — mọi bảng đều dùng `Uuid().v4()`).
String generateBibleEntryId() => const Uuid().v4();
