import '../models/story_models.dart';
import 'ai_provider.dart';
import 'database_service.dart';
import 'providers/local_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'style_service.dart';
import 'translation_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng): tạo chương HÀNG LOẠT từ dàn ý/outline
// đã viết sẵn (không gọi AI lúc viết dàn ý) — người dùng lên kế hoạch
// nhiều chương ("chương mồi") TRƯỚC, rồi chọn chương nào cần AI viết,
// chạy TUẦN TỰ theo hàng đợi (không đồng thời — đây chính là cách né
// nguyên nhân crash "2 lệnh generate chạy chồng chéo" đã tìm ra ở mục
// 5.67 kiến trúc: nếu người dùng phải ngồi chờ AI viết XONG TỪNG CHƯƠNG
// MỘT trước khi làm việc khác, sẽ không còn tình huống 2 tác vụ AI tình
// cờ trùng thời điểm).
class ChapterBatchService {
  final DatabaseService db;
  ChapterBatchService(this.db);

  // Kết quả trả về NGAY LẬP TỨC nếu 1 chương gặp lỗi/kết quả bất thường —
  // giống hệt cách DocumentProcessingAnomalyException đã làm cho tài liệu
  // (mục 64) — không lưu rác, dừng ngay, không chạy tiếp qua các chương
  // khác trong hàng đợi (nếu model đang gặp vấn đề, chương sau cũng sẽ
  // hỏng, chạy tiếp chỉ tổ tốn thời gian + có nguy cơ lưu thêm rác).
  Future<void> generateBatch({
    required List<Chapter> chapters, // các chương ĐÃ CHỌN, có outline
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle)? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(),
    );
    final styleService = StyleService();
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) {
      await LocalLlamaProvider.beginPipeline('Đang tạo chương hàng loạt...');
    }

    try {
      for (final chapter in chapters) {
        if (isCancelled?.call() ?? false) break;
        final outline = chapter.outline?.trim() ?? '';
        if (outline.isEmpty) {
          done++;
          continue; // bỏ qua chương không có outline, không tính là lỗi
        }
        if (isLocal) {
          await LocalLlamaProvider.updatePipelineStage('Đang viết: ${chapter.title} (${done + 1}/${chapters.length})...');
        }
        onProgress?.call(done, chapters.length, chapter.title);

        // ĐÃ SỬA: trước dùng StyleService.fleshOutOutline() — hàm này TỰ
        // GHI RÕ trong comment là "gọi thẳng provider, không qua dịch
        // thuật trung gian" — nghĩa là tạo chương hàng loạt sẽ ÂM THẦM BỎ
        // QUA cài đặt dịch thuật trung gian của người dùng nếu đã bật.
        // Giờ tự build prompt (dùng lại buildFleshOutPrompt công khai,
        // logic prompt giống hệt) rồi gọi qua generateWithOptionalTranslation
        // — nhất quán với luồng "Đắp thịt" đơn lẻ trong chapter_editor_screen.dart.
        final prompt = await styleService.buildFleshOutPrompt(outline: outline, style: style, rag: rag);
        final result = await TranslationService(SettingsService()).generateWithOptionalTranslation(
          mainProvider: provider,
          systemPrompt: prompt.systemPrompt,
          userPrompt: prompt.userPrompt,
          temperature: 0.95,
          maxTokens: 1500,
          onStage: (stage) {
            if (isLocal) LocalLlamaProvider.updatePipelineStage('${chapter.title}: $stage');
          },
        );
        final resultTrimmed = result.trim();
        // Cùng ngưỡng kiểm tra tính hợp lý đã dùng cho tài liệu (mục 64) —
        // 1 chương văn hợp lý gần như không bao giờ ngắn hơn hẳn outline.
        final looksCorrupted = resultTrimmed.isEmpty || resultTrimmed.length < outline.length * 0.5;
        if (looksCorrupted) {
          throw ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
        }

        chapter.content = chapter.content.trim().isEmpty ? resultTrimmed : '${chapter.content}\n\n$resultTrimmed';
        await db.upsertChapter(chapter);
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
      }
    } finally {
      if (isLocal) await LocalLlamaProvider.endPipeline();
    }
  }
}

class ChapterBatchAnomalyException implements Exception {
  final String chapterTitle;
  final String rawResult;
  ChapterBatchAnomalyException({required this.chapterTitle, required this.rawResult});

  @override
  String toString() =>
      'Chương "$chapterTitle": kết quả bất thường (${rawResult.length} ký tự) — '
      'có thể model bị lỗi giữa chừng, ĐÃ DỪNG tạo các chương còn lại trong hàng đợi.';
}
