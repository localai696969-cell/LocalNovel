import 'dart:async';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'background_task_manager.dart';
import 'database_service.dart';
import 'providers/local_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'style_service.dart';
import 'summary_service.dart';
import 'translation_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng): tạo chương HÀNG LOẠT từ dàn ý/outline
// đã viết sẵn (không gọi AI lúc viết dàn ý) — người dùng lên kế hoạch
// nhiều chương ("chương mồi") TRƯỚC, rồi chọn chương nào cần AI viết.
//
// ĐÃ SỬA (theo yêu cầu người dùng: các nhiệm vụ AI đều nên chạy song song
// được với nhau, không riêng "tạo chương hàng loạt"): tách 2 đường hoàn
// toàn khác nhau theo loại provider —
//   - LOCAL: GIỮ NGUYÊN 100% hành vi cũ — chạy TUẦN TỰ, không đổi 1 dòng
//     logic nào so với bản gốc. Đây là cách né đúng nguyên nhân crash "2
//     lệnh generate chạy chồng chéo" đã tìm ra ở mục 5.67 kiến trúc —
//     Llm::response() của MNN không an toàn khi 2 luồng cùng ghi vào
//     chung 1 KV-cache của cùng 1 instance model LOCAL. Không có lý do
//     kỹ thuật nào để đổi nhánh này — model local vẫn bị giới hạn cứng ở
//     2 slot native (xem generateMutexes trong MnnBridge.kt), chạy "song
//     song" nhiều chương cùng lúc chỉ khiến chúng xếp hàng chờ nhau ở
//     cùng 1 khoá, không nhanh hơn, chỉ thêm phức tạp.
//   - REMOTE (Colab/API khác, qua HTTP): mỗi request độc lập hoàn toàn,
//     không có vùng nhớ chung nào bị 2 bên cùng ghi — an toàn để chạy
//     THẬT SỰ đồng thời. Thả từng chương vào BackgroundTaskManager dùng
//     chung toàn app, giới hạn số lượng đồng thời theo cấu hình người
//     dùng (SettingsService.loadMaxParallelRemoteTasks()).
class ChapterBatchService {
  final DatabaseService db;
  ChapterBatchService(this.db);

  // Điều phối: chọn đúng nhánh theo loại provider — xem giải thích đầy đủ
  // ở comment đầu class về lý do KHÔNG được đổi hành vi nhánh local.
  Future<void> generateBatch({
    required List<Chapter> chapters, // các chương ĐÃ CHỌN, có outline
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    // ĐÃ SỬA (theo yêu cầu người dùng: "thanh tiến trình không chỉ hiện số
    // chương đang chạy mà hiển thị luôn cả % của chương"): thêm tham số
    // đặt tên `currentPercent` (0-99, null = không áp dụng/chưa có dữ
    // liệu) — CHỈ nhánh REMOTE cung cấp giá trị thật (xem
    // _generateBatchParallel), nhánh LOCAL vẫn gọi callback y hệt bản gốc
    // (không có `currentPercent`, mặc định null) vì KHÔNG đổi nhánh đó.
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent})? onProgress,
  }) async {
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) {
      await _generateBatchSequential(
        chapters: chapters,
        provider: provider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    } else {
      await _generateBatchParallel(
        chapters: chapters,
        provider: provider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    }
  }

  // ===== Nhánh LOCAL — GIỮ NGUYÊN 100% so với bản gốc, không đổi 1 dòng
  // logic nào. Kết quả trả về NGAY LẬP TỨC nếu 1 chương gặp lỗi/kết quả
  // bất thường — giống hệt cách DocumentProcessingAnomalyException đã làm
  // cho tài liệu (mục 64) — không lưu rác, dừng ngay, không chạy tiếp qua
  // các chương khác trong hàng đợi.
  //
  // GHI CHÚ (theo yêu cầu người dùng về resume/streaming khi GPU sập —
  // xem mục 5.93 tài liệu kiến trúc): tính năng streaming + checkpoint +
  // resume CHỈ áp dụng cho nhánh REMOTE bên dưới trong lần sửa này — model
  // LOCAL khi "sập" (crash app/OOM) thường kéo theo crash luôn tiến trình
  // Dart đang giữ state checkpoint trong RAM (khác hẳn remote: GPU chết
  // nhưng app Dart trên điện thoại vẫn sống, vẫn giữ được state), nên lợi
  // ích thực tế thấp hơn hẳn so với rủi ro đổi 1 vùng code đã ổn định. Có
  // thể làm thêm ở phiên sau nếu cần, không nằm trong yêu cầu lần này
  // (người dùng hỏi cụ thể về "quy trình chạy model GPU remote"). =====
  Future<void> _generateBatchSequential({
    required List<Chapter> chapters,
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent})? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(),
    );
    final styleService = StyleService();
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    await LocalLlamaProvider.beginPipeline('Đang tạo chương hàng loạt...');

    try {
      for (final chapter in chapters) {
        if (isCancelled?.call() ?? false) break;
        final outline = chapter.outline?.trim() ?? '';
        if (outline.isEmpty) {
          done++;
          continue; // bỏ qua chương không có outline, không tính là lỗi
        }
        await LocalLlamaProvider.updatePipelineStage('Đang viết: ${chapter.title} (${done + 1}/${chapters.length})...');
        onProgress?.call(done, chapters.length, chapter.title);

        // ĐÃ SỬA: trước dùng StyleService.fleshOutOutline() — hàm này TỰ
        // GHI RÕ trong comment là "gọi thẳng provider, không qua dịch
        // thuật trung gian" — nghĩa là tạo chương hàng loạt sẽ ÂM THẦM BỎ
        // QUA cài đặt dịch thuật trung gian của người dùng nếu đã bật.
        // Giờ tự build prompt (dùng lại buildFleshOutPrompt công khai,
        // logic prompt giống hệt) rồi gọi qua generateWithOptionalTranslation
        // — nhất quán với luồng "Đắp thịt" đơn lẻ trong chapter_editor_screen.dart.
        final prompt = await styleService.buildFleshOutPrompt(outline: outline, style: style, rag: rag, currentChapterNumber: chapter.number);
        final result = await TranslationService(SettingsService()).generateWithOptionalTranslation(
          mainProvider: provider,
          systemPrompt: prompt.systemPrompt,
          userPrompt: prompt.userPrompt,
          temperature: 0.95,
          maxTokens: 1500,
          onStage: (stage) {
            LocalLlamaProvider.updatePipelineStage('${chapter.title}: $stage');
          },
        );
        final resultTrimmed = result.trim();
        // Cùng ngưỡng kiểm tra tính hợp lý đã dùng cho tài liệu (mục 64) —
        // 1 chương văn hợp lý gần như không bao giờ ngắn hơn hẳn outline.
        final looksCorrupted = resultTrimmed.isEmpty || resultTrimmed.length < outline.length * 0.5;
        if (looksCorrupted) {
          throw ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
        }

        chapter.content = chapter.content.trim().isEmpty ? resultTrimmed : '${chapter.content}\n\n$resultTrimmed';
        await db.upsertChapter(chapter);
        // ĐÃ THÊM (rà soát toàn hệ thống — cùng lỗi "chưa nối dây" đã sửa
        // ở chapter_editor_screen.dart _save(); xem giải thích đầy đủ ở
        // đó): tạo hàng loạt là 1 trong 2 CÁCH CHÍNH nội dung chương được
        // lưu, nếu không ghi log ở đây thì mục tiêu viết mỗi ngày chỉ tính
        // đúng phần viết tay/AI hỗ trợ đơn lẻ, bỏ sót toàn bộ phần tạo
        // hàng loạt — sai lệch nghiêm trọng với "số chữ đã viết hôm nay".
        await db.recordWordSnapshot(novelId);
        // ĐÃ THÊM (rà soát toàn hệ thống, phát hiện khi làm tính năng "đồng
        // bộ chương 1000 với chương 1"): trước đây batch KHÔNG hề gọi tóm
        // tắt/index embedding cho chương vừa tạo — nghĩa là phần LỚN NHẤT
        // của 1 truyện dài (chương do "Tạo hàng loạt" sinh ra, không phải
        // viết tay) hoàn toàn VÔ HÌNH với "Chương liên quan (truy xuất ngữ
        // nghĩa)" ở RagService — mục đó chỉ thấy được chương ĐÃ được
        // index qua editor. Giờ gọi y hệt _updateSummaryAndIndexInBackground()
        // bên chapter_editor_screen.dart: tóm tắt → index embedding → nén
        // vào "Cốt truyện đã diễn ra".
        await _finalizeChapterMemory(chapter: chapter, provider: provider, rag: rag);
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
      }
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }

  // ===== Nhánh REMOTE. Thả từng chương vào BackgroundTaskManager, chạy
  // THẬT SỰ đồng thời (giới hạn theo cấu hình người dùng). Giữ đúng hợp
  // đồng cũ với nơi gọi: vẫn ném ChapterBatchAnomalyException nếu có
  // chương bất thường (nơi gọi ở chapters_batch_generate_screen.dart bắt
  // lỗi này y hệt như trước, không cần sửa gì ở đó), vẫn gọi onProgress
  // đúng số lượng — chỉ khác thứ tự hoàn thành giờ có thể không tuần tự
  // theo đúng thứ tự trong danh sách `chapters` nữa (vì chạy song song).
  //
  // ĐÃ SỬA (theo yêu cầu người dùng — mục 5.93 tài liệu kiến trúc): trước
  // đây gọi `generateWithOptionalTranslation()` (HTTP không streaming) —
  // nếu GPU remote sập giữa chừng, MẤT SẠCH phần đã sinh, không có cách
  // nào tiếp tục đúng chỗ gãy, lần chạy lại phải viết lại từ đầu chương.
  // Giờ dùng `generateResumableWithOptionalTranslation()` — streaming
  // từng đoạn NGAY KHI model sinh ra (giống hệt cách model LOCAL đã
  // streaming trong khung chat), lưu checkpoint định kỳ vào
  // `chapter.generationCheckpoint`. Nếu chương ĐÃ CÓ checkpoint từ lần
  // chạy trước (do lần đó bị lỗi giữa chừng, chưa kịp lưu `content` cuối
  // cùng) — TỰ ĐỘNG coi đây là resume, gửi kèm checkpoint để model viết
  // TIẾP thay vì viết lại từ đầu. `onProgress` giờ báo thêm `currentPercent`
  // ước lượng (dựa trên độ dài văn bản thô đã nhận / độ dài kỳ vọng theo
  // `maxTokens`) — CHỈ là ước lượng thô để có cảm giác tiến trình, không
  // phải số chính xác tuyệt đối (không có cách nào biết trước chính xác
  // model sẽ viết bao nhiêu chữ). =====
  Future<void> _generateBatchParallel({
    required List<Chapter> chapters,
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent})? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(),
    );
    final styleService = StyleService();
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    // Cờ dùng chung giữa các nhiệm vụ song song — 1 chương phát hiện bất
    // thường sẽ CHẶN việc thả THÊM chương mới vào hàng đợi (đúng tinh
    // thần "không tổ tốn thời gian nếu model đang gặp vấn đề" của bản
    // gốc), nhưng KHÔNG ép dừng cứng các chương ĐANG chạy dở song song —
    // Dart không có cách huỷ Future đang await HTTP giữa chừng 1 cách an
    // toàn, để chúng tự hoàn tất là lựa chọn ít rủi ro hơn.
    ChapterBatchAnomalyException? capturedAnomaly;
    final completers = <Completer<void>>[];

    for (final chapter in chapters) {
      if (isCancelled?.call() ?? false) break;
      if (capturedAnomaly != null) break;
      final outline = chapter.outline?.trim() ?? '';
      if (outline.isEmpty) {
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
        continue;
      }

      final completer = Completer<void>();
      completers.add(completer);
      // Checkpoint còn sót từ lần chạy trước bị lỗi giữa chừng (nếu có) —
      // đây chính là "chỗ gãy" cần resume từ đó, không phải viết lại từ đầu.
      final resumeFrom = chapter.generationCheckpoint?.trim().isNotEmpty == true ? chapter.generationCheckpoint : null;

      BackgroundTaskManager.instance.submit(
        label: 'Chương: ${chapter.title}',
        category: 'chapter_batch',
        run: () async {
          try {
            final prompt = await styleService.buildFleshOutPrompt(outline: outline, style: style, rag: rag, currentChapterNumber: chapter.number);
            final result = await TranslationService(SettingsService()).generateResumableWithOptionalTranslation(
              mainProvider: provider,
              systemPrompt: prompt.systemPrompt,
              userPrompt: prompt.userPrompt,
              resumeFrom: resumeFrom,
              temperature: 0.95,
              maxTokens: maxTokensPerChapter,
              onCheckpoint: (rawSoFar) {
                // Không `await` — ghi checkpoint là tối ưu "cố gắng lưu
                // càng gần thời điểm hiện tại càng tốt", không được phép
                // làm chậm việc nhận chunk kế tiếp từ stream.
                unawaited(db.updateChapterCheckpoint(chapter.id, rawSoFar));
                onProgress?.call(done, chapters.length, chapter.title,
                    currentPercent: estimatePercent(rawSoFar.length));
              },
            );
            final resultTrimmed = result.trim();
            final looksCorrupted = resultTrimmed.isEmpty || resultTrimmed.length < outline.length * 0.5;
            if (looksCorrupted) {
              // Kết quả ĐÃ sinh xong (không phải lỗi kết nối) nhưng hỏng —
              // resume từ văn bản hỏng không có ý nghĩa, xoá checkpoint để
              // lần chạy sau viết lại sạch từ đầu thay vì nối vào rác.
              await db.updateChapterCheckpoint(chapter.id, null);
              capturedAnomaly ??= ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
              return; // không lưu kết quả hỏng, không tăng done
            }
            chapter.content = chapter.content.trim().isEmpty ? resultTrimmed : '${chapter.content}\n\n$resultTrimmed';
            chapter.generationCheckpoint = null; // xong hẳn — xoá checkpoint, không còn "dở dang" nữa
            await db.upsertChapter(chapter);
            // ĐÃ THÊM (rà soát toàn hệ thống — cùng lỗi "chưa nối dây" ở
            // nhánh local phía trên, xem giải thích đầy đủ ở đó).
            await db.recordWordSnapshot(novelId);
            await _finalizeChapterMemory(chapter: chapter, provider: provider, rag: rag);
            done++;
            onProgress?.call(done, chapters.length, chapter.title);
          } catch (e) {
            // Lỗi giữa chừng (mất kết nối/GPU sập...) — GIỮ NGUYÊN checkpoint
            // đã lưu qua onCheckpoint (không xoá) để lần chạy sau resume
            // đúng chỗ gãy thay vì viết lại từ đầu.
            capturedAnomaly ??= ChapterBatchAnomalyException(
              chapterTitle: chapter.title,
              rawResult: e.toString(),
              resumable: true,
            );
          } finally {
            if (!completer.isCompleted) completer.complete();
          }
        },
      );
    }

    // Đợi TẤT CẢ nhiệm vụ ĐÃ THẢ vào hàng đợi chạy xong (dù thành/bại) —
    // generateBatch() chỉ coi là hoàn tất khi không còn gì đang chạy dở.
    await Future.wait(completers.map((c) => c.future));

    if (capturedAnomaly != null) throw capturedAnomaly!;
  }

  // Dùng chung cho cả 2 nhánh (local + remote) — tóm tắt chương + index
  // embedding + nén vào "Cốt truyện đã diễn ra". Best-effort: lỗi ở đây
  // KHÔNG được phép làm hỏng cả batch (chương đã lưu thành công rồi, đây
  // chỉ là bước bổ trợ cho lần viết SAU) — nuốt lỗi, không rethrow.
  Future<void> _finalizeChapterMemory({
    required Chapter chapter,
    required AIProvider provider,
    required RagService rag,
  }) async {
    try {
      final summary = await SummaryService().summarizeChapter(chapter, provider);
      chapter.autoSummary = summary;
      await db.upsertChapter(chapter);
      await rag.indexChapter(chapter);
      await rag.updateCumulativeStorySummary(chapter, provider);
    } catch (_) {
      // im lặng bỏ qua — xem giải thích ở comment đầu hàm.
    }
  }

  // Ước lượng % tiến trình trong 1 chương từ độ dài văn bản thô đã nhận —
  // CHỈ là ước lượng (không có cách nào biết trước chính xác model sẽ viết
  // bao nhiêu chữ). 2.6 ký tự/token là ước lượng thô cho tiếng Việt có dấu;
  // nếu đang dịch thuật trung gian, văn bản thô nằm ở ngôn ngữ trung gian
  // (thường tiếng Anh, mật độ ký tự/token gần tương tự nên vẫn dùng chung
  // hệ số này, không tách riêng để đơn giản). Chặn trần ở 95% cho tới khi
  // thật sự xong hẳn (còn phải qua bước dịch ngược + kiểm tra hợp lý).
  // ĐÃ ĐỔI sang public + static (trước là private) — chapters_batch_
  // generate_screen.dart cũng cần đúng công thức này để hiện % ước lượng
  // ngay trong danh sách chọn chương (chương có checkpoint dở dang), tránh
  // chép lại công thức ở 2 nơi rồi lệch nhau khi có ai sửa 1 chỗ mà quên chỗ kia.
  static const maxTokensPerChapter = 1500;
  static int estimatePercent(int rawChars, {int maxTokens = maxTokensPerChapter}) {
    const charsPerTokenEstimate = 2.6;
    final estTargetChars = (maxTokens * charsPerTokenEstimate).clamp(500, 100000);
    return (rawChars / estTargetChars * 100).clamp(0, 95).round();
  }
}

class ChapterBatchAnomalyException implements Exception {
  final String chapterTitle;
  final String rawResult;
  // ĐÃ THÊM: true nếu lỗi này có checkpoint đã lưu, resume được ở lần chạy
  // sau (lỗi kết nối/GPU sập giữa chừng) — false nếu là kết quả hỏng đã
  // sinh xong hẳn (không có checkpoint để resume, phải viết lại từ đầu).
  final bool resumable;
  ChapterBatchAnomalyException({required this.chapterTitle, required this.rawResult, this.resumable = false});

  @override
  String toString() => resumable
      ? 'Chương "$chapterTitle": lỗi giữa chừng (có thể do mất kết nối/GPU remote sập) — '
          'ĐÃ DỪNG tạo các chương còn lại. Phần đã viết được cho chương này ĐÃ LƯU TẠM, '
          'chạy lại sẽ tiếp tục đúng chỗ gãy thay vì viết lại từ đầu.'
      : 'Chương "$chapterTitle": kết quả bất thường (${rawResult.length} ký tự) — '
          'có thể model bị lỗi giữa chừng, ĐÃ DỪNG tạo các chương còn lại trong hàng đợi.';
}
