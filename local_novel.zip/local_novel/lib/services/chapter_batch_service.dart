import 'dart:async';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'background_task_manager.dart';
import 'database_service.dart';
import 'providers/local_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'style_service.dart';
import 'translation_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng): tạo chương HÀNG LOẠT từ dàn ý/outline
// đã viết sẵn (không gọi AI lúc viết dàn ý) — người dùng lên kế hoạch
// nhiều chương ("chương mồi") TRƯỚC, rồi chọn chương nào cần AI viết.
//
// ĐÃ SỬA (theo yêu cầu người dùng: các nhiệm vụ AI đều nên chạy song song
// được với nhau, không riêng "tạo chương hàng loạt"): tách 2 đường hoàn
// toàn khác nhau theo loại provider —
//   - LOCAL: GIỮ NGUYÊN 100% hành vi cũ — chạy TUẦN TỰ, không đổi 1 dòng
//     logic nào so với bản gốc. Đây là cách né đúng nguyên nhân crash "2
//     lệnh generate chạy chồng chéo" đã tìm ra ở mục 5.67 kiến trúc —
//     Llm::response() của MNN không an toàn khi 2 luồng cùng ghi vào
//     chung 1 KV-cache của cùng 1 instance model LOCAL. Không có lý do
//     kỹ thuật nào để đổi nhánh này — model local vẫn bị giới hạn cứng ở
//     2 slot native (xem generateMutexes trong MnnBridge.kt), chạy "song
//     song" nhiều chương cùng lúc chỉ khiến chúng xếp hàng chờ nhau ở
//     cùng 1 khoá, không nhanh hơn, chỉ thêm phức tạp.
//   - REMOTE (Colab/API khác, qua HTTP): mỗi request độc lập hoàn toàn,
//     không có vùng nhớ chung nào bị 2 bên cùng ghi — an toàn để chạy
//     THẬT SỰ đồng thời. Thả từng chương vào BackgroundTaskManager dùng
//     chung toàn app, giới hạn số lượng đồng thời theo cấu hình người
//     dùng (SettingsService.loadMaxParallelRemoteTasks()).
class ChapterBatchService {
  final DatabaseService db;
  ChapterBatchService(this.db);

  // Điều phối: chọn đúng nhánh theo loại provider — xem giải thích đầy đủ
  // ở comment đầu class về lý do KHÔNG được đổi hành vi nhánh local.
  Future<void> generateBatch({
    required List<Chapter> chapters, // các chương ĐÃ CHỌN, có outline
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle)? onProgress,
  }) async {
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) {
      await _generateBatchSequential(
        chapters: chapters,
        provider: provider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    } else {
      await _generateBatchParallel(
        chapters: chapters,
        provider: provider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    }
  }

  // ===== Nhánh LOCAL — GIỮ NGUYÊN 100% so với bản gốc, không đổi 1 dòng
  // logic nào. Kết quả trả về NGAY LẬP TỨC nếu 1 chương gặp lỗi/kết quả
  // bất thường — giống hệt cách DocumentProcessingAnomalyException đã làm
  // cho tài liệu (mục 64) — không lưu rác, dừng ngay, không chạy tiếp qua
  // các chương khác trong hàng đợi. =====
  Future<void> _generateBatchSequential({
    required List<Chapter> chapters,
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle)? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(),
    );
    final styleService = StyleService();
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    await LocalLlamaProvider.beginPipeline('Đang tạo chương hàng loạt...');

    try {
      for (final chapter in chapters) {
        if (isCancelled?.call() ?? false) break;
        final outline = chapter.outline?.trim() ?? '';
        if (outline.isEmpty) {
          done++;
          continue; // bỏ qua chương không có outline, không tính là lỗi
        }
        await LocalLlamaProvider.updatePipelineStage('Đang viết: ${chapter.title} (${done + 1}/${chapters.length})...');
        onProgress?.call(done, chapters.length, chapter.title);

        // ĐÃ SỬA: trước dùng StyleService.fleshOutOutline() — hàm này TỰ
        // GHI RÕ trong comment là "gọi thẳng provider, không qua dịch
        // thuật trung gian" — nghĩa là tạo chương hàng loạt sẽ ÂM THẦM BỎ
        // QUA cài đặt dịch thuật trung gian của người dùng nếu đã bật.
        // Giờ tự build prompt (dùng lại buildFleshOutPrompt công khai,
        // logic prompt giống hệt) rồi gọi qua generateWithOptionalTranslation
        // — nhất quán với luồng "Đắp thịt" đơn lẻ trong chapter_editor_screen.dart.
        final prompt = await styleService.buildFleshOutPrompt(outline: outline, style: style, rag: rag, currentChapterNumber: chapter.number);
        final result = await TranslationService(SettingsService()).generateWithOptionalTranslation(
          mainProvider: provider,
          systemPrompt: prompt.systemPrompt,
          userPrompt: prompt.userPrompt,
          temperature: 0.95,
          maxTokens: 1500,
          onStage: (stage) {
            LocalLlamaProvider.updatePipelineStage('${chapter.title}: $stage');
          },
        );
        final resultTrimmed = result.trim();
        // Cùng ngưỡng kiểm tra tính hợp lý đã dùng cho tài liệu (mục 64) —
        // 1 chương văn hợp lý gần như không bao giờ ngắn hơn hẳn outline.
        final looksCorrupted = resultTrimmed.isEmpty || resultTrimmed.length < outline.length * 0.5;
        if (looksCorrupted) {
          throw ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
        }

        chapter.content = chapter.content.trim().isEmpty ? resultTrimmed : '${chapter.content}\n\n$resultTrimmed';
        await db.upsertChapter(chapter);
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
      }
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }

  // ===== Nhánh REMOTE — MỚI. Thả từng chương vào BackgroundTaskManager,
  // chạy THẬT SỰ đồng thời (giới hạn theo cấu hình người dùng). Giữ đúng
  // hợp đồng cũ với nơi gọi: vẫn ném ChapterBatchAnomalyException nếu có
  // chương bất thường (nơi gọi ở chapters_batch_generate_screen.dart bắt
  // lỗi này y hệt như trước, không cần sửa gì ở đó), vẫn gọi onProgress
  // đúng số lượng — chỉ khác thứ tự hoàn thành giờ có thể không tuần tự
  // theo đúng thứ tự trong danh sách `chapters` nữa (vì chạy song song). =====
  Future<void> _generateBatchParallel({
    required List<Chapter> chapters,
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle)? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(),
    );
    final styleService = StyleService();
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    // Cờ dùng chung giữa các nhiệm vụ song song — 1 chương phát hiện bất
    // thường sẽ CHẶN việc thả THÊM chương mới vào hàng đợi (đúng tinh
    // thần "không tổ tốn thời gian nếu model đang gặp vấn đề" của bản
    // gốc), nhưng KHÔNG ép dừng cứng các chương ĐANG chạy dở song song —
    // Dart không có cách huỷ Future đang await HTTP giữa chừng 1 cách an
    // toàn, để chúng tự hoàn tất là lựa chọn ít rủi ro hơn.
    ChapterBatchAnomalyException? capturedAnomaly;
    final completers = <Completer<void>>[];

    for (final chapter in chapters) {
      if (isCancelled?.call() ?? false) break;
      if (capturedAnomaly != null) break;
      final outline = chapter.outline?.trim() ?? '';
      if (outline.isEmpty) {
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
        continue;
      }

      final completer = Completer<void>();
      completers.add(completer);

      BackgroundTaskManager.instance.submit(
        label: 'Chương: ${chapter.title}',
        category: 'chapter_batch',
        run: () async {
          try {
            final prompt = await styleService.buildFleshOutPrompt(outline: outline, style: style, rag: rag, currentChapterNumber: chapter.number);
            final result = await TranslationService(SettingsService()).generateWithOptionalTranslation(
              mainProvider: provider,
              systemPrompt: prompt.systemPrompt,
              userPrompt: prompt.userPrompt,
              temperature: 0.95,
              maxTokens: 1500,
            );
            final resultTrimmed = result.trim();
            final looksCorrupted = resultTrimmed.isEmpty || resultTrimmed.length < outline.length * 0.5;
            if (looksCorrupted) {
              capturedAnomaly ??= ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
              return; // không lưu kết quả hỏng, không tăng done
            }
            chapter.content = chapter.content.trim().isEmpty ? resultTrimmed : '${chapter.content}\n\n$resultTrimmed';
            await db.upsertChapter(chapter);
            done++;
            onProgress?.call(done, chapters.length, chapter.title);
          } catch (e) {
            capturedAnomaly ??= ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: e.toString());
          } finally {
            if (!completer.isCompleted) completer.complete();
          }
        },
      );
    }

    // Đợi TẤT CẢ nhiệm vụ ĐÃ THẢ vào hàng đợi chạy xong (dù thành/bại) —
    // generateBatch() chỉ coi là hoàn tất khi không còn gì đang chạy dở.
    await Future.wait(completers.map((c) => c.future));

    if (capturedAnomaly != null) throw capturedAnomaly!;
  }
}

class ChapterBatchAnomalyException implements Exception {
  final String chapterTitle;
  final String rawResult;
  ChapterBatchAnomalyException({required this.chapterTitle, required this.rawResult});

  @override
  String toString() =>
      'Chương "$chapterTitle": kết quả bất thường (${rawResult.length} ký tự) — '
      'có thể model bị lỗi giữa chừng, ĐÃ DỪNG tạo các chương còn lại trong hàng đợi.';
}
