import 'dart:async';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'background_task_manager.dart';
import 'database_service.dart';
import 'providers/local_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'style_service.dart';
import 'summary_service.dart';
import 'translation_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng): tạo chương HÀNG LOẠT từ dàn ý/outline
// đã viết sẵn (không gọi AI lúc viết dàn ý) — người dùng lên kế hoạch
// nhiều chương ("chương mồi") TRƯỚC, rồi chọn chương nào cần AI viết.
//
// ĐÃ SỬA (theo yêu cầu người dùng: các nhiệm vụ AI đều nên chạy song song
// được với nhau, không riêng "tạo chương hàng loạt"): tách 2 đường hoàn
// toàn khác nhau theo loại provider —
//   - LOCAL: GIỮ NGUYÊN 100% hành vi cũ — chạy TUẦN TỰ, không đổi 1 dòng
//     logic nào so với bản gốc. Đây là cách né đúng nguyên nhân crash "2
//     lệnh generate chạy chồng chéo" đã tìm ra ở mục 5.67 kiến trúc —
//     Llm::response() của MNN không an toàn khi 2 luồng cùng ghi vào
//     chung 1 KV-cache của cùng 1 instance model LOCAL. Không có lý do
//     kỹ thuật nào để đổi nhánh này — model local vẫn bị giới hạn cứng ở
//     2 slot native (xem generateMutexes trong MnnBridge.kt), chạy "song
//     song" nhiều chương cùng lúc chỉ khiến chúng xếp hàng chờ nhau ở
//     cùng 1 khoá, không nhanh hơn, chỉ thêm phức tạp.
//   - REMOTE (Colab/API khác, qua HTTP): mỗi request độc lập hoàn toàn,
//     không có vùng nhớ chung nào bị 2 bên cùng ghi — an toàn để chạy
//     THẬT SỰ đồng thời. Thả từng chương vào BackgroundTaskManager dùng
//     chung toàn app, giới hạn số lượng đồng thời theo cấu hình người
//     dùng (SettingsService.loadMaxParallelRemoteTasks()).
class ChapterBatchService {
  final DatabaseService db;
  ChapterBatchService(this.db);

  // Điều phối: chọn đúng nhánh theo loại provider — xem giải thích đầy đủ
  // ở comment đầu class về lý do KHÔNG được đổi hành vi nhánh local.
  Future<void> generateBatch({
    required List<Chapter> chapters, // các chương ĐÃ CHỌN, có outline
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    // ĐÃ SỬA (theo yêu cầu người dùng: "thanh tiến trình không chỉ hiện số
    // chương đang chạy mà hiển thị luôn cả % của chương"): thêm tham số
    // đặt tên `currentPercent` (0-99, null = không áp dụng/chưa có dữ
    // liệu) — CHỈ nhánh REMOTE cung cấp giá trị thật (xem
    // _generateBatchParallel), nhánh LOCAL vẫn gọi callback y hệt bản gốc
    // (không có `currentPercent`, mặc định null) vì KHÔNG đổi nhánh đó.
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent, String? currentText, String? currentChapterId})? onProgress,
  }) async {
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) {
      await _generateBatchSequential(
        chapters: chapters,
        provider: provider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    } else {
      await _generateBatchParallel(
        chapters: chapters,
        provider: provider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    }
  }

  // ===== Nhánh LOCAL — cấu trúc chạy TUẦN TỰ giữ NGUYÊN 100% (không đổi 1
  // dòng logic điều khiển luồng nào — vẫn `await` xong chương này mới sang
  // chương kế, không có 2 lệnh generate() nào chạy chồng lên nhau).
  //
  // ĐÃ SỬA (theo phản hồi người dùng — "tạo chương hàng loạt khi chữ chạy
  // thì liên quan gì đến crash khi yêu cầu 2 cái chạy cùng lúc": ĐÚNG, nhận
  // định trước đó của Claude nhầm lẫn 2 việc khác nhau): thêm `onChunk` để
  // hiện chữ dần lên UI — đây CHỈ là quan sát THỤ ĐỘNG lên đúng 1 lệnh
  // generate() vốn dĩ đã chạy tuần tự, không làm phát sinh thêm bất kỳ lệnh
  // gọi model song song nào, nên KHÔNG liên quan gì tới rủi ro crash "2 lệnh
  // generate chạy chồng chéo" (mục 5.67) — 2 việc độc lập, xem chi tiết ở
  // đúng chỗ gọi `onChunk` bên dưới.
  //
  // Kết quả trả về NGAY LẬP TỨC nếu 1 chương gặp lỗi/kết quả bất thường —
  // giống hệt cách DocumentProcessingAnomalyException đã làm cho tài liệu
  // (mục 64) — không lưu rác, dừng ngay, không chạy tiếp qua các chương
  // khác trong hàng đợi.
  //
  // GHI CHÚ (theo yêu cầu người dùng về resume/streaming khi GPU sập — xem
  // mục 5.93 tài liệu kiến trúc): tính năng CHECKPOINT + RESUME (khác với
  // hiện-chữ-dần vừa thêm ở trên — đây là việc LƯU TẠM xuống DB để phục hồi
  // sau khi crash) CHỈ áp dụng cho nhánh REMOTE bên dưới — model LOCAL khi
  // "sập" (crash app/OOM) thường kéo theo crash luôn tiến trình Dart đang
  // giữ state checkpoint trong RAM (khác hẳn remote: GPU chết nhưng app
  // Dart trên điện thoại vẫn sống, vẫn giữ được state), nên lợi ích thực tế
  // thấp hơn hẳn so với rủi ro đổi 1 vùng code đã ổn định. Có thể làm thêm
  // ở phiên sau nếu cần, không nằm trong yêu cầu lần này (người dùng hỏi cụ
  // thể về "quy trình chạy model GPU remote"). =====
  Future<void> _generateBatchSequential({
    required List<Chapter> chapters,
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent, String? currentText, String? currentChapterId})? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(novelId),
    );
    final styleService = StyleService();
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    await LocalLlamaProvider.beginPipeline('Đang tạo chương hàng loạt...');

    try {
      for (final chapter in chapters) {
        if (isCancelled?.call() ?? false) break;
        final outline = chapter.outline?.trim() ?? '';
        if (outline.isEmpty) {
          done++;
          continue; // bỏ qua chương không có outline, không tính là lỗi
        }
        await LocalLlamaProvider.updatePipelineStage('Đang viết: ${chapter.title} (${done + 1}/${chapters.length})...');
        onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);

        // ĐÃ SỬA: trước dùng StyleService.fleshOutOutline() — hàm này TỰ
        // GHI RÕ trong comment là "gọi thẳng provider, không qua dịch
        // thuật trung gian" — nghĩa là tạo chương hàng loạt sẽ ÂM THẦM BỎ
        // QUA cài đặt dịch thuật trung gian của người dùng nếu đã bật.
        // Giờ tự build prompt (dùng lại buildFleshOutPrompt công khai,
        // logic prompt giống hệt) rồi gọi qua generateWithOptionalTranslation
        // — nhất quán với luồng "Đắp thịt" đơn lẻ trong chapter_editor_screen.dart.
        final prompt = await styleService.buildFleshOutPrompt(outline: outline, style: style, rag: rag, currentChapterNumber: chapter.number);
        // ĐÃ SỬA (theo phản hồi người dùng — "tạo chương hàng loạt khi chữ
        // chạy thì liên quan gì đến crash khi yêu cầu 2 cái chạy cùng lúc":
        // ĐÚNG, nhận xét trước đó của Claude sai — nhánh này CHỈ có ĐÚNG 1
        // lệnh `generateWithOptionalTranslation` đang chạy tại bất kỳ thời
        // điểm nào (vòng `for` ở trên luôn `await` xong chương này mới sang
        // chương kế — không đổi gì ở đây), thêm `onChunk` KHÔNG làm phát
        // sinh thêm bất kỳ lệnh generate() song song nào — chỉ đơn giản là
        // lộ thêm phần văn bản của CHÍNH lệnh generate() đang chạy, y hệt
        // cách nhánh REMOTE đã lộ qua `onCheckpoint`. Lo ngại crash "2 lệnh
        // generate chạy chồng chéo" (mục 5.67) áp dụng cho việc ĐỔI CẤU
        // TRÚC CHẠY (song song hoá), không áp dụng cho việc thêm 1 callback
        // quan sát THỤ ĐỘNG lên 1 lệnh vốn dĩ đã tuần tự.
        // ĐÃ SỬA — mục AW, 2026-09-16 — LỖI THẬT xác nhận qua đọc code (không
        // đoán): hàm này (`_generateBatchSequential`) nhận sẵn tham số
        // `isCancelled` và CÓ kiểm tra nó (dòng `if (isCancelled?.call() ??
        // false) break;` ở đầu vòng `for` phía trên) — NHƯNG trước đây KHÔNG
        // truyền `isCancelled` xuống lời gọi `generateWithOptionalTranslation`
        // này, dù chính hàm đó ĐÃ khai báo sẵn tham số `isCancelled` và tự
        // kiểm tra nó SAU MỖI CHUNK stream (xem `translation_service.dart`,
        // dòng `if (isCancelled?.call() ?? false) break;` bên trong `await
        // for` — cơ chế y hệt đã hoạt động đúng ở `chat_screen.dart`, nút
        // "X" ở đó truyền đúng `isCancelled` xuống chỗ này).
        // HẬU QUẢ THẬT (khớp đúng triệu chứng người dùng báo — "tạo chương
        // hàng loạt: nhấn Hủy/quay lại cỡ nào cũng không dừng, kể cả sau khi
        // thoát app/tác vụ nền báo trống"): vòng `for` CHỈ kiểm tra
        // `isCancelled` GIỮA 2 chương — bấm "Hủy" trong lúc 1 chương ĐANG
        // sinh không có tác dụng gì cho tới khi chương đó tự chạy xong hẳn
        // (có thể hàng chục phút nếu rơi vào lặp vô tận hoặc máy ngủ giữa
        // chừng — xem log native `nativeGenerate`, có ca lệch STEADY/WALL tới
        // ~15 phút). Vì `generateStream()` (`local_provider.dart`) CHỈ gọi
        // `cancelGenerate()` xuống native khi CHÍNH nó bị huỷ giữa chừng —
        // không ai huỷ nó do thiếu `isCancelled` này — lệnh generate() native
        // tiếp tục chạy MỒ CÔI, đúng khớp "vuốt tắt app / tác vụ nền báo
        // không còn gì nhưng máy vẫn tạo sinh". Truyền xuống đúng tham số có
        // sẵn là đủ sửa — không cần thêm cơ chế huỷ mới nào.
        final result = await TranslationService(SettingsService(), novelId: novelId).generateWithOptionalTranslation(
          mainProvider: provider,
          systemPrompt: prompt.systemPrompt,
          userPrompt: prompt.userPrompt,
          temperature: 0.95,
          maxTokens: 1500,
          isCancelled: isCancelled,
          onStage: (stage) {
            LocalLlamaProvider.updatePipelineStage('${chapter.title}: $stage');
          },
          onChunk: (textSoFar) {
            onProgress?.call(done, chapters.length, chapter.title,
                currentText: textSoFar, currentChapterId: chapter.id);
          },
        );
        // ĐÃ THÊM — mục AW: nếu vừa bị huỷ GIỮA CHỪNG chính chương này (khác
        // với "model tự sinh xong nhưng kết quả tệ"), dừng SẠCH hàng đợi
        // ngay tại đây — KHÔNG được rơi xuống nhánh `looksCorrupted` bên
        // dưới, vì văn bản dở dang do CHỦ ĐỘNG huỷ không phải "kết quả bất
        // thường" của model (sẽ báo nhầm thành lỗi cho người dùng qua
        // `ChapterBatchAnomalyException`) — đúng nguyên tắc đã áp dụng cho
        // nhánh REMOTE với `GenerationCancelledException` ở `_generateBatchParallel`.
        // Chương này coi như "chưa xong" (không tăng `done`, không lưu phần
        // dở dang — nhánh local chưa có checkpoint tăng dần như nhánh remote,
        // xem "GHI CHÚ" ở đầu hàm) — người dùng tạo lại đúng chương này ở
        // lần sau, viết lại từ đầu.
        if (isCancelled?.call() ?? false) {
          onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          break;
        }
        final resultTrimmed = result.trim();
        // ĐÃ SỬA (2026-09-07, sau sự cố mục W): trước đây chỉ so độ dài —
        // nếu outline đủ dài, chuỗi cảnh báo lỗi nội bộ (~180 ký tự, xem
        // `kAiFailureMarker`) có thể KHÔNG bị coi là "quá ngắn" và lọt
        // qua, bị ghi thẳng vào chương trong lúc chạy batch KHÔNG AI GIÁM
        // SÁT (đúng use-case "chạy qua đêm" — hậu quả nặng hơn hẳn so với
        // soạn tay 1 chương, vì không ai nhận ra ngay để dừng lại). Kiểm
        // tra `kAiFailureMarker` TRƯỚC, độc lập với ngưỡng độ dài.
        final looksCorrupted = resultTrimmed.isEmpty ||
            resultTrimmed.contains(kAiFailureMarker) ||
            resultTrimmed.length < outline.length * 0.5;
        if (looksCorrupted) {
          onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          throw ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
        }

        chapter.content = chapter.content.trim().isEmpty ? resultTrimmed : '${chapter.content}\n\n$resultTrimmed';
        await db.upsertChapter(chapter);
        // ĐÃ THÊM (rà soát toàn hệ thống — cùng lỗi "chưa nối dây" đã sửa
        // ở chapter_editor_screen.dart _save(); xem giải thích đầy đủ ở
        // đó): tạo hàng loạt là 1 trong 2 CÁCH CHÍNH nội dung chương được
        // lưu, nếu không ghi log ở đây thì mục tiêu viết mỗi ngày chỉ tính
        // đúng phần viết tay/AI hỗ trợ đơn lẻ, bỏ sót toàn bộ phần tạo
        // hàng loạt — sai lệch nghiêm trọng với "số chữ đã viết hôm nay".
        await db.recordWordSnapshot(novelId);
        // ĐÃ THÊM (rà soát toàn hệ thống, phát hiện khi làm tính năng "đồng
        // bộ chương 1000 với chương 1"): trước đây batch KHÔNG hề gọi tóm
        // tắt/index embedding cho chương vừa tạo — nghĩa là phần LỚN NHẤT
        // của 1 truyện dài (chương do "Tạo hàng loạt" sinh ra, không phải
        // viết tay) hoàn toàn VÔ HÌNH với "Chương liên quan (truy xuất ngữ
        // nghĩa)" ở RagService — mục đó chỉ thấy được chương ĐÃ được
        // index qua editor. Giờ gọi y hệt _updateSummaryAndIndexInBackground()
        // bên chapter_editor_screen.dart: tóm tắt → index embedding → nén
        // vào "Cốt truyện đã diễn ra".
        await _finalizeChapterMemory(chapter: chapter, provider: provider, rag: rag);
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
      }
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }

  // ===== Nhánh REMOTE. Thả từng chương vào BackgroundTaskManager, chạy
  // THẬT SỰ đồng thời (giới hạn theo cấu hình người dùng). Giữ đúng hợp
  // đồng cũ với nơi gọi: vẫn ném ChapterBatchAnomalyException nếu có
  // chương bất thường (nơi gọi ở chapters_batch_generate_screen.dart bắt
  // lỗi này y hệt như trước, không cần sửa gì ở đó), vẫn gọi onProgress
  // đúng số lượng — chỉ khác thứ tự hoàn thành giờ có thể không tuần tự
  // theo đúng thứ tự trong danh sách `chapters` nữa (vì chạy song song).
  //
  // ĐÃ SỬA (theo yêu cầu người dùng — mục 5.93 tài liệu kiến trúc): trước
  // đây gọi `generateWithOptionalTranslation()` (HTTP không streaming) —
  // nếu GPU remote sập giữa chừng, MẤT SẠCH phần đã sinh, không có cách
  // nào tiếp tục đúng chỗ gãy, lần chạy lại phải viết lại từ đầu chương.
  // Giờ dùng `generateResumableWithOptionalTranslation()` — streaming
  // từng đoạn NGAY KHI model sinh ra (giống hệt cách model LOCAL đã
  // streaming trong khung chat), lưu checkpoint định kỳ vào
  // `chapter.generationCheckpoint`. Nếu chương ĐÃ CÓ checkpoint từ lần
  // chạy trước (do lần đó bị lỗi giữa chừng, chưa kịp lưu `content` cuối
  // cùng) — TỰ ĐỘNG coi đây là resume, gửi kèm checkpoint để model viết
  // TIẾP thay vì viết lại từ đầu. `onProgress` giờ báo thêm `currentPercent`
  // ước lượng (dựa trên độ dài văn bản thô đã nhận / độ dài kỳ vọng theo
  // `maxTokens`) — CHỈ là ước lượng thô để có cảm giác tiến trình, không
  // phải số chính xác tuyệt đối (không có cách nào biết trước chính xác
  // model sẽ viết bao nhiêu chữ). =====
  Future<void> _generateBatchParallel({
    required List<Chapter> chapters,
    required AIProvider provider,
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent, String? currentText, String? currentChapterId})? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(novelId),
    );
    final styleService = StyleService();
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    // Cờ dùng chung giữa các nhiệm vụ song song — 1 chương phát hiện bất
    // thường sẽ CHẶN việc thả THÊM chương mới vào hàng đợi (đúng tinh
    // thần "không tổ tốn thời gian nếu model đang gặp vấn đề" của bản
    // gốc), nhưng KHÔNG ép dừng cứng các chương ĐANG chạy dở song song —
    // Dart không có cách huỷ Future đang await HTTP giữa chừng 1 cách an
    // toàn, để chúng tự hoàn tất là lựa chọn ít rủi ro hơn.
    ChapterBatchAnomalyException? capturedAnomaly;
    final completers = <Completer<void>>[];
    // ĐÃ THÊM (theo yêu cầu người dùng — "hủy giữa chừng lúc đang batch tạo
    // chương, không phải đợi xong toàn bộ", xem giải thích đầy đủ ở
    // `TranslationService.generateResumableWithOptionalTranslation`): 1 cờ
    // huỷ RIÊNG cho MỖI chương (không phải 1 cờ chung cho cả lô) — khớp
    // đúng cách `BackgroundTaskManager` biểu diễn: MỖI chương là 1
    // `BackgroundTask` ĐỘC LẬP, người dùng có thể huỷ đúng 1 chương đang
    // chạy dở từ màn "Tác vụ nền" (sống độc lập với vòng đời màn hình tạo
    // hàng loạt — huỷ được NGAY CẢ SAU KHI đã rời màn đó) mà không ảnh
    // hưởng các chương khác đang chạy song song.
    final cancelledChapterIds = <String>{};

    for (final chapter in chapters) {
      if (isCancelled?.call() ?? false) break;
      if (capturedAnomaly != null) break;
      final outline = chapter.outline?.trim() ?? '';
      if (outline.isEmpty) {
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
        continue;
      }

      final completer = Completer<void>();
      completers.add(completer);
      // Checkpoint còn sót từ lần chạy trước bị lỗi giữa chừng (nếu có) —
      // đây chính là "chỗ gãy" cần resume từ đó, không phải viết lại từ đầu.
      final resumeFrom = chapter.generationCheckpoint?.trim().isNotEmpty == true ? chapter.generationCheckpoint : null;

      BackgroundTaskManager.instance.submit(
        label: 'Chương: ${chapter.title}',
        category: 'chapter_batch',
        isLocalProvider: provider is LocalLlamaProvider,
        onCancelRequested: () => cancelledChapterIds.add(chapter.id),
        run: () async {
          try {
            final prompt = await styleService.buildFleshOutPrompt(outline: outline, style: style, rag: rag, currentChapterNumber: chapter.number);
            final result = await TranslationService(SettingsService(), novelId: novelId).generateResumableWithOptionalTranslation(
              mainProvider: provider,
              systemPrompt: prompt.systemPrompt,
              userPrompt: prompt.userPrompt,
              resumeFrom: resumeFrom,
              temperature: 0.95,
              maxTokens: maxTokensPerChapter,
              isCancelled: () => cancelledChapterIds.contains(chapter.id),
              onCheckpoint: (rawSoFar) {
                // Không `await` — ghi checkpoint là tối ưu "cố gắng lưu
                // càng gần thời điểm hiện tại càng tốt", không được phép
                // làm chậm việc nhận chunk kế tiếp từ stream.
                unawaited(db.updateChapterCheckpoint(chapter.id, rawSoFar));
                // ĐÃ THÊM (theo yêu cầu người dùng: "sinh chữ nào hiện chữ
                // đó trên màn hình, áp dụng cả cho GPU remote"): gửi luôn
                // văn bản thô ĐÃ NHẬN ĐƯỢC — UI hiện trực tiếp, không đợi
                // xong cả chương. Khi dịch thuật trung gian TẮT (mặc định),
                // đây CHÍNH LÀ văn bản cuối cùng (không dịch gì thêm) — khi
                // BẬT, đây là văn bản ngôn ngữ trung gian TẠM THỜI, sẽ được
                // `onTranslatedChunk` bên dưới ghi ĐÈ bằng bản tiếng Việt
                // thật ngay khi bước dịch ngược bắt đầu (xem giải thích ở
                // `TranslationService.generateResumableWithOptionalTranslation`).
                onProgress?.call(done, chapters.length, chapter.title,
                    currentPercent: estimatePercent(rawSoFar.length), currentText: rawSoFar, currentChapterId: chapter.id);
              },
              onTranslatedChunk: (textSoFar) {
                // ĐÃ THÊM (theo phản hồi người dùng — bản trước tự cho rằng
                // dịch thuật bật thì không stream được ở batch remote là
                // SAI, cùng lý do đã sửa ở `chapter_editor_screen.dart`):
                // bước dịch NGƯỢC là bước DUY NHẤT người dùng thực sự nhìn
                // thấy khi dịch thuật bật — không có `currentPercent` ở đây
                // vì độ dài bản dịch không tỉ lệ thẳng với `maxTokens` gốc
                // (ước lượng % sẽ sai), giữ % cuối cùng đã có từ bước sinh.
                onProgress?.call(done, chapters.length, chapter.title, currentText: textSoFar, currentChapterId: chapter.id);
              },
            );
            final resultTrimmed = result.trim();
            // ĐÃ SỬA (2026-09-07, sau sự cố mục W — xem giải thích đầy đủ
            // ở nhánh sequential phía trên, `_generateBatchSequential`):
            // cùng kiểm tra `kAiFailureMarker`, không chỉ độ dài.
            final looksCorrupted = resultTrimmed.isEmpty ||
                resultTrimmed.contains(kAiFailureMarker) ||
                resultTrimmed.length < outline.length * 0.5;
            if (looksCorrupted) {
              // Kết quả ĐÃ sinh xong (không phải lỗi kết nối) nhưng hỏng —
              // resume từ văn bản hỏng không có ý nghĩa, xoá checkpoint để
              // lần chạy sau viết lại sạch từ đầu thay vì nối vào rác.
              await db.updateChapterCheckpoint(chapter.id, null);
              capturedAnomaly ??= ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
              onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
              return; // không lưu kết quả hỏng, không tăng done
            }
            chapter.content = chapter.content.trim().isEmpty ? resultTrimmed : '${chapter.content}\n\n$resultTrimmed';
            chapter.generationCheckpoint = null; // xong hẳn — xoá checkpoint, không còn "dở dang" nữa
            await db.upsertChapter(chapter);
            // ĐÃ THÊM (rà soát toàn hệ thống — cùng lỗi "chưa nối dây" ở
            // nhánh local phía trên, xem giải thích đầy đủ ở đó).
            await db.recordWordSnapshot(novelId);
            await _finalizeChapterMemory(chapter: chapter, provider: provider, rag: rag);
            done++;
            onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          } on GenerationCancelledException {
            // ĐÃ THÊM: bị huỷ THEO Ý MUỐN người dùng (nút Huỷ ở màn "Tác vụ
            // nền") — KHÔNG phải bất thường, KHÔNG set `capturedAnomaly`
            // (sẽ chặn thả thêm chương mới vào hàng đợi nếu set — đúng cho
            // lỗi thật, sai cho huỷ chủ động). Checkpoint đã được lưu tại
            // đúng điểm dừng (xem `runStream`) — chương này coi như "chưa
            // xong", user có thể tạo lại đúng chương này sau, sẽ tự resume
            // đúng chỗ gãy. Không tăng `done`.
            // Báo UI bỏ chương này khỏi danh sách "đang chạy" (không còn
            // text mới để hiện) — không đổi `done`/`total`.
            onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          } catch (e) {
            // Lỗi giữa chừng (mất kết nối/GPU sập...) — GIỮ NGUYÊN checkpoint
            // đã lưu qua onCheckpoint (không xoá) để lần chạy sau resume
            // đúng chỗ gãy thay vì viết lại từ đầu.
            capturedAnomaly ??= ChapterBatchAnomalyException(
              chapterTitle: chapter.title,
              rawResult: e.toString(),
              resumable: true,
            );
            onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          } finally {
            if (!completer.isCompleted) completer.complete();
          }
        },
      );
    }

    // Đợi TẤT CẢ nhiệm vụ ĐÃ THẢ vào hàng đợi chạy xong (dù thành/bại) —
    // generateBatch() chỉ coi là hoàn tất khi không còn gì đang chạy dở.
    await Future.wait(completers.map((c) => c.future));

    if (capturedAnomaly != null) throw capturedAnomaly!;
  }

  // Dùng chung cho cả 2 nhánh (local + remote) — tóm tắt chương + index
  // embedding + nén vào "Cốt truyện đã diễn ra". Best-effort: lỗi ở đây
  // KHÔNG được phép làm hỏng cả batch (chương đã lưu thành công rồi, đây
  // chỉ là bước bổ trợ cho lần viết SAU) — nuốt lỗi, không rethrow.
  Future<void> _finalizeChapterMemory({
    required Chapter chapter,
    required AIProvider provider,
    required RagService rag,
  }) async {
    try {
      final summary = await SummaryService().summarizeChapter(chapter, provider);
      // ĐÃ THÊM (2026-09-07, sau sự cố mục W): cùng lỗ hổng y hệt đã vá ở
      // `chapter_editor_screen.dart` (`_updateSummaryAndIndexInBackground`)
      // — hàm NÀY là bản riêng dùng cho batch, không tự động thừa hưởng
      // bản vá ở màn soạn 1 chương, phải vá lại đúng chỗ này mới thật sự
      // che được luồng "chạy hàng loạt qua đêm".
      if (summary.trim().isEmpty || summary.contains(kAiFailureMarker)) {
        return;
      }
      chapter.autoSummary = summary;
      await db.upsertChapter(chapter);
      await rag.indexChapter(chapter);
      await rag.updateCumulativeStorySummary(chapter, provider);
    } catch (_) {
      // im lặng bỏ qua — xem giải thích ở comment đầu hàm.
    }
  }

  // Ước lượng % tiến trình trong 1 chương từ độ dài văn bản thô đã nhận —
  // CHỈ là ước lượng (không có cách nào biết trước chính xác model sẽ viết
  // bao nhiêu chữ). 2.6 ký tự/token là ước lượng thô cho tiếng Việt có dấu;
  // nếu đang dịch thuật trung gian, văn bản thô nằm ở ngôn ngữ trung gian
  // (thường tiếng Anh, mật độ ký tự/token gần tương tự nên vẫn dùng chung
  // hệ số này, không tách riêng để đơn giản). Chặn trần ở 95% cho tới khi
  // thật sự xong hẳn (còn phải qua bước dịch ngược + kiểm tra hợp lý).
  // ĐÃ ĐỔI sang public + static (trước là private) — chapters_batch_
  // generate_screen.dart cũng cần đúng công thức này để hiện % ước lượng
  // ngay trong danh sách chọn chương (chương có checkpoint dở dang), tránh
  // chép lại công thức ở 2 nơi rồi lệch nhau khi có ai sửa 1 chỗ mà quên chỗ kia.
  static const maxTokensPerChapter = 1500;
  static int estimatePercent(int rawChars, {int maxTokens = maxTokensPerChapter}) {
    const charsPerTokenEstimate = 2.6;
    final estTargetChars = (maxTokens * charsPerTokenEstimate).clamp(500, 100000);
    return (rawChars / estTargetChars * 100).clamp(0, 95).round();
  }
}

class ChapterBatchAnomalyException implements Exception {
  final String chapterTitle;
  final String rawResult;
  // ĐÃ THÊM: true nếu lỗi này có checkpoint đã lưu, resume được ở lần chạy
  // sau (lỗi kết nối/GPU sập giữa chừng) — false nếu là kết quả hỏng đã
  // sinh xong hẳn (không có checkpoint để resume, phải viết lại từ đầu).
  final bool resumable;
  ChapterBatchAnomalyException({required this.chapterTitle, required this.rawResult, this.resumable = false});

  @override
  String toString() => resumable
      ? 'Chương "$chapterTitle": lỗi giữa chừng (có thể do mất kết nối/GPU remote sập) — '
          'ĐÃ DỪNG tạo các chương còn lại. Phần đã viết được cho chương này ĐÃ LƯU TẠM, '
          'chạy lại sẽ tiếp tục đúng chỗ gãy thay vì viết lại từ đầu.'
      : 'Chương "$chapterTitle": kết quả bất thường (${rawResult.length} ký tự) — '
          'có thể model bị lỗi giữa chừng, ĐÃ DỪNG tạo các chương còn lại trong hàng đợi.';
}
