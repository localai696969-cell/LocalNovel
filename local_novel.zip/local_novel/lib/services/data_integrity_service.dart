import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import 'ai_provider.dart' show kAiFailureMarker;
import 'database_service.dart';

// ĐÃ THÊM (2026-09-05, sau sự cố "Tạo lại tất cả ghi chú" ghi đè nội dung
// chương bằng thông báo lỗi nội bộ khi slot AI bị kẹt — xem giải thích đầy
// đủ trong lịch sử debug): dùng chung đúng 1 định nghĩa `kAiFailureMarker`
// (khai báo ở ai_provider.dart) với nơi CHẶN việc ghi rác vào chương
// (_applyAllPendingRewrites) — nếu định nghĩa 2 chuỗi riêng ở 2 nơi, chỉ
// cần 1 bên sửa/gõ sai là toàn bộ cơ chế phát hiện lệch nhau, mất tác
// dụng mà không ai biết. class này CHỈ dùng để QUÉT dữ liệu ĐÃ LỠ bị ghi
// (từ trước khi có bản sửa) — không thay thế bản sửa chặn ở gốc.
//
// ĐÃ THÊM (2026-09-07, sau sự cố mục W: "Đắp thịt" lặp vô tận ngay từ ký
// tự 60 BẤT KỂ outline là gì): mở rộng quét thêm 2 nguồn NGUY HIỂM HƠN
// rác trong 1 đoạn văn thường — `Novel.plotProgressSummary` ("Cốt truyện
// đã diễn ra") và `Chapter.autoSummary` đều được `RagService.buildContext()`
// nhúng vào NGỮ CẢNH CỐ ĐỊNH của MỌI prompt sinh chương sau đó (không phụ
// thuộc nội dung/outline đang viết) — 1 lần ghi rác ở 1 trong 2 chỗ này
// làm hỏng NGẦM mọi lần "Viết tiếp"/"Đắp thịt" tiếp theo, rất khó nhận ra
// vì triệu chứng (model lặp/không ra chữ) không rõ ràng trỏ về đúng
// nguyên nhân như khi rác nằm thẳng trong nội dung chương.
enum CorruptionKind { chapterContent, novelPlotSummary, chapterAutoSummary }

class CorruptionFinding {
  final CorruptionKind kind;
  final String title;
  final String contextSnippet;
  final int occurrences;
  final Chapter? chapter; // dùng cho chapterContent + chapterAutoSummary
  final ChapterVersion? cleanVersion; // dùng cho chapterContent
  final Novel? novel; // dùng cho novelPlotSummary

  CorruptionFinding({
    required this.kind,
    required this.title,
    required this.contextSnippet,
    required this.occurrences,
    this.chapter,
    this.cleanVersion,
    this.novel,
  });

  // Chỉ chapterContent mới có đường "khôi phục về bản cũ" (nhờ snapshot).
  // 2 loại còn lại KHÔNG có lịch sử phiên bản riêng — cách an toàn duy
  // nhất là XOÁ SẠCH phần bị lỗi (ép AI tự tóm tắt lại từ đầu ở lần lưu
  // chương kế tiếp), không đoán mò giữ lại phần nào "còn dùng được".
  bool get canAutoFix => kind != CorruptionKind.chapterContent || cleanVersion != null;
}

class DataIntegrityService {
  final DatabaseService db;
  DataIntegrityService(this.db);

  int _countOccurrences(String haystack, String needle) {
    var count = 0;
    var start = 0;
    while (true) {
      final idx = haystack.indexOf(needle, start);
      if (idx == -1) break;
      count++;
      start = idx + needle.length;
    }
    return count;
  }

  String _snippetAround(String content, String marker) {
    final idx = content.indexOf(marker);
    if (idx == -1) return content.substring(0, content.length.clamp(0, 200));
    final start = (idx - 60).clamp(0, content.length);
    final end = (idx + marker.length + 120).clamp(0, content.length);
    final prefix = start > 0 ? '…' : '';
    final suffix = end < content.length ? '…' : '';
    return '$prefix${content.substring(start, end)}$suffix';
  }

  // Quét toàn bộ chương + 2 nguồn ngữ cảnh cố định của 1 truyện. Không
  // giới hạn số lượng (dùng `allChapters` không truyền limit) vì đây là
  // thao tác chạy 1 lần khi người dùng chủ động bấm "Kiểm tra dữ liệu
  // lỗi", không chạy nền/lặp lại.
  Future<List<CorruptionFinding>> scanNovel(String novelId) async {
    final findings = <CorruptionFinding>[];

    final novel = await db.novelById(novelId);
    final plotSummary = novel?.plotProgressSummary;
    if (novel != null && plotSummary != null && plotSummary.contains(kAiFailureMarker)) {
      findings.add(CorruptionFinding(
        kind: CorruptionKind.novelPlotSummary,
        title: 'Cốt truyện đã diễn ra (tóm tắt luỹ kế toàn truyện)',
        contextSnippet: _snippetAround(plotSummary, kAiFailureMarker),
        occurrences: _countOccurrences(plotSummary, kAiFailureMarker),
        novel: novel,
      ));
    }

    final chapters = await db.allChapters(novelId);
    for (final chapter in chapters) {
      if (chapter.content.contains(kAiFailureMarker)) {
        final versions = await db.versionsForChapter(chapter.id); // đã sort created_at DESC
        ChapterVersion? clean;
        for (final v in versions) {
          if (!v.content.contains(kAiFailureMarker)) {
            clean = v;
            break;
          }
        }
        findings.add(CorruptionFinding(
          kind: CorruptionKind.chapterContent,
          title: 'Chương ${chapter.number}: ${chapter.title}',
          contextSnippet: _snippetAround(chapter.content, kAiFailureMarker),
          occurrences: _countOccurrences(chapter.content, kAiFailureMarker),
          chapter: chapter,
          cleanVersion: clean,
        ));
      }
      final autoSummary = chapter.autoSummary;
      if (autoSummary != null && autoSummary.contains(kAiFailureMarker)) {
        findings.add(CorruptionFinding(
          kind: CorruptionKind.chapterAutoSummary,
          title: 'Tóm tắt riêng của chương ${chapter.number}: ${chapter.title}',
          contextSnippet: _snippetAround(autoSummary, kAiFailureMarker),
          occurrences: _countOccurrences(autoSummary, kAiFailureMarker),
          chapter: chapter,
        ));
      }
    }
    return findings;
  }

  // Khôi phục/xoá 1 kết quả quét — hành vi tuỳ loại:
  //  - chapterContent: khôi phục về bản snapshot sạch (tự chụp lại bản
  //    hiện tại trước, không mất gì nếu khôi phục nhầm).
  //  - novelPlotSummary: XOÁ SẠCH `plotProgressSummary` VÀ reset
  //    `plotProgressSummaryChapter` về null — bắt buộc reset cả 2 cùng
  //    lúc, nếu chỉ xoá text mà giữ nguyên số chương đã gộp, các chương
  //    TRƯỚC số đó sẽ bị bỏ sót VĨNH VIỄN (logic gộp chỉ nhìn về phía
  //    trước, không bao giờ quay lại gộp chương cũ hơn số đã lưu).
  //  - chapterAutoSummary: xoá `autoSummary`, tự sinh lại ở lần lưu chương
  //    kế tiếp (xem `_updateSummaryAndIndexInBackground`).
  Future<void> restore(CorruptionFinding finding) async {
    switch (finding.kind) {
      case CorruptionKind.chapterContent:
        final clean = finding.cleanVersion;
        final chapter = finding.chapter!;
        if (clean == null) {
          throw StateError('Chương "${chapter.title}" không có bản snapshot sạch nào để khôi phục tự động.');
        }
        await db.saveChapterVersion(ChapterVersion(
          id: const Uuid().v4(),
          chapterId: chapter.id,
          novelId: chapter.novelId,
          title: chapter.title,
          content: chapter.content,
          label: 'Trước khi tự động khôi phục do phát hiện dữ liệu lỗi',
        ));
        chapter.title = clean.title;
        chapter.content = clean.content;
        chapter.updatedAt = DateTime.now();
        await db.upsertChapter(chapter);
        break;
      case CorruptionKind.novelPlotSummary:
        final novel = finding.novel!;
        // ĐÃ SỬA (2026-09-11 — cùng đợt với `SettingsService.renameNovel()`,
        // sau khi phát hiện qua log thật lỗi "Lost Update": `upsertNovel()`
        // ghi đè TOÀN BỘ hàng bằng 1 `Novel` object có thể đã cũ hơn DB tại
        // thời điểm này — CHỈ nên đụng đúng 2 cột thật sự cần xoá ở đây).
        await db.updateNovelSettings(novel.id, {
          'plot_progress_summary': null,
          'plot_progress_summary_chapter': null,
        });
        break;
      case CorruptionKind.chapterAutoSummary:
        final chapter = finding.chapter!;
        chapter.autoSummary = null;
        chapter.updatedAt = DateTime.now();
        await db.upsertChapter(chapter);
        break;
    }
  }
}
