import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import 'ai_provider.dart' show kAiFailureMarker;
import 'database_service.dart';

// ĐÃ THÊM (2026-09-05, sau sự cố "Tạo lại tất cả ghi chú" ghi đè nội dung
// chương bằng thông báo lỗi nội bộ khi slot AI bị kẹt — xem giải thích đầy
// đủ trong lịch sử debug): dùng chung đúng 1 định nghĩa `kAiFailureMarker`
// (khai báo ở ai_provider.dart) với nơi CHẶN việc ghi rác vào chương
// (_applyAllPendingRewrites) — nếu định nghĩa 2 chuỗi riêng ở 2 nơi, chỉ
// cần 1 bên sửa/gõ sai là toàn bộ cơ chế phát hiện lệch nhau, mất tác
// dụng mà không ai biết. class này CHỈ dùng để QUÉT dữ liệu ĐÃ LỠ bị ghi
// (từ trước khi có bản sửa) — không thay thế bản sửa chặn ở gốc.

class CorruptionFinding {
  final Chapter chapter;
  // Đoạn trích quanh vị trí phát hiện lỗi, để người dùng xem trước khi bấm
  // khôi phục — không phải toàn bộ chương (có thể rất dài).
  final String contextSnippet;
  // Bản snapshot gần nhất (nếu có) KHÔNG chứa markẻr lỗi — null nếu không
  // tìm được bản nào sạch (vd snapshot cũ đã bị dọn do vượt quá
  // `maxVersionsPerChapter`, hoặc chương này chưa từng có snapshot).
  final ChapterVersion? cleanVersion;
  final int occurrences;

  CorruptionFinding({
    required this.chapter,
    required this.contextSnippet,
    required this.cleanVersion,
    required this.occurrences,
  });
}

class DataIntegrityService {
  final DatabaseService db;
  DataIntegrityService(this.db);

  int _countOccurrences(String haystack, String needle) {
    var count = 0;
    var start = 0;
    while (true) {
      final idx = haystack.indexOf(needle, start);
      if (idx == -1) break;
      count++;
      start = idx + needle.length;
    }
    return count;
  }

  String _snippetAround(String content, String marker) {
    final idx = content.indexOf(marker);
    if (idx == -1) return content.substring(0, content.length.clamp(0, 200));
    final start = (idx - 60).clamp(0, content.length);
    final end = (idx + marker.length + 120).clamp(0, content.length);
    final prefix = start > 0 ? '…' : '';
    final suffix = end < content.length ? '…' : '';
    return '$prefix${content.substring(start, end)}$suffix';
  }

  // Quét toàn bộ chương của 1 truyện. Không giới hạn số lượng (dùng
  // `allChapters` không truyền limit) vì đây là thao tác chạy 1 lần khi
  // người dùng chủ động bấm "Kiểm tra dữ liệu lỗi", không chạy nền/lặp lại.
  Future<List<CorruptionFinding>> scanNovel(String novelId) async {
    final chapters = await db.allChapters(novelId);
    final findings = <CorruptionFinding>[];
    for (final chapter in chapters) {
      if (!chapter.content.contains(kAiFailureMarker)) continue;
      final versions = await db.versionsForChapter(chapter.id); // đã sort created_at DESC
      ChapterVersion? clean;
      for (final v in versions) {
        if (!v.content.contains(kAiFailureMarker)) {
          clean = v;
          break;
        }
      }
      findings.add(CorruptionFinding(
        chapter: chapter,
        contextSnippet: _snippetAround(chapter.content, kAiFailureMarker),
        cleanVersion: clean,
        occurrences: _countOccurrences(chapter.content, kAiFailureMarker),
      ));
    }
    return findings;
  }

  // Khôi phục 1 chương về bản snapshot sạch đã tìm được — TỰ ĐỘNG chụp lại
  // trạng thái hiện tại (dính lỗi) trước khi ghi đè, giống hệt nguyên tắc
  // "không mất gì vĩnh viễn" đã áp dụng cho _openVersionHistory() — nếu
  // khôi phục nhầm vẫn có đường lùi lại qua màn Lịch sử phiên bản.
  Future<void> restore(CorruptionFinding finding) async {
    final clean = finding.cleanVersion;
    if (clean == null) {
      throw StateError('Chương "${finding.chapter.title}" không có bản snapshot sạch nào để khôi phục tự động.');
    }
    await db.saveChapterVersion(ChapterVersion(
      id: const Uuid().v4(),
      chapterId: finding.chapter.id,
      novelId: finding.chapter.novelId,
      title: finding.chapter.title,
      content: finding.chapter.content,
      label: 'Trước khi tự động khôi phục do phát hiện dữ liệu lỗi',
    ));
    finding.chapter.title = clean.title;
    finding.chapter.content = clean.content;
    finding.chapter.updatedAt = DateTime.now();
    await db.upsertChapter(finding.chapter);
  }
}
