import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';

// Toàn bộ dữ liệu truyện lưu local trên máy (SQLite), không phụ thuộc mạng.
// Đây là "bộ nhớ dài hạn" thay thế cho việc nhồi cả 1000 chương vào context AI.
//
// Hỗ trợ NHIỀU TRUYỆN (novels): mọi bảng nội dung (characters, world_rules,
// timeline_events, chapters, style_profiles, chat_sessions, chat_messages,
// imported_documents) đều có cột novel_id để tách biệt hoàn toàn dữ liệu
// giữa các truyện khác nhau. local_models/api_providers KHÔNG gắn theo
// novel_id vì đó là tài nguyên máy (model .gguf, API key) dùng chung.
class DatabaseService {
  static final DatabaseService instance = DatabaseService._internal();
  DatabaseService._internal();
  Database? _db;

  static const int schemaVersion = 4;

  Future<Database> get db async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'local_novel.db');
    return openDatabase(
      path,
      version: schemaVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE novels(
            id TEXT PRIMARY KEY, title TEXT, author TEXT, description TEXT,
            created_at TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE characters(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, role TEXT, category TEXT, description TEXT,
            voice_style TEXT, keywords TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE world_rules(
            id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, content TEXT,
            is_hard_rule INTEGER, category TEXT, keywords TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE timeline_events(
            id TEXT PRIMARY KEY, novel_id TEXT, chapter_number INTEGER, summary TEXT, in_story_date TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chapters(
            id TEXT PRIMARY KEY, novel_id TEXT, number INTEGER, title TEXT, content TEXT,
            outline TEXT, auto_summary TEXT, consistency_checked INTEGER,
            consistency_warning TEXT, updated_at TEXT
          )
        ''');
        // FTS ảo để tìm kiếm toàn văn nhanh trong hàng nghìn chương
        await db.execute('''
          CREATE VIRTUAL TABLE chapters_fts USING fts4(
            chapter_id, novel_id, title, content
          )
        ''');
        await db.execute('''
          CREATE TABLE local_models(
            id TEXT PRIMARY KEY, name TEXT, path TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE api_providers(
            id TEXT PRIMARY KEY, name TEXT, type TEXT, base_url TEXT, model_id TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE imported_documents(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, source_path TEXT,
            chunk_count INTEGER, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE document_chunks(
            id TEXT PRIMARY KEY, document_id TEXT, idx INTEGER, original_text TEXT, result_text TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_sessions(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_messages(
            id TEXT PRIMARY KEY, session_id TEXT, from_user INTEGER, text TEXT,
            provider_label TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE style_profiles(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, profile_description TEXT, updated_at TEXT
          )
        ''');
        // Vector embedding cho RAG ngữ nghĩa. entity_type: 'character' |
        // 'world_rule' | 'chapter'. vector lưu dạng chuỗi số cách nhau
        // bởi dấu phẩy — đơn giản, đủ dùng cho quy mô vài nghìn entry.
        await db.execute('''
          CREATE TABLE embeddings(
            entity_type TEXT, entity_id TEXT, vector TEXT, updated_at TEXT,
            PRIMARY KEY (entity_type, entity_id)
          )
        ''');
        // Version snapshot — bản nháp cũ của chương, chụp trước khi bị ghi
        // đè (AI viết tiếp/đắp thịt/rewrite hoặc lưu tay), cho phép undo.
        await db.execute('''
          CREATE TABLE chapter_versions(
            id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT, title TEXT,
            content TEXT, label TEXT, created_at TEXT
          )
        ''');
        // Bảng thuật ngữ riêng của truyện — tra cứu nhanh, không tham gia
        // lorebook tự động nạp prompt (khác Character/WorldRule).
        await db.execute('''
          CREATE TABLE glossary_terms(
            id TEXT PRIMARY KEY, novel_id TEXT, term TEXT, definition TEXT,
            category TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE pending_rewrites(
            id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT,
            original_text TEXT, note TEXT, status TEXT,
            result_text TEXT, created_at TEXT
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await _migrateToMultiNovel(db);
        }
        if (oldVersion < 3) {
          await _migrateToV3(db);
        }
        if (oldVersion < 4) {
          await _migrateToV4(db);
        }
      },
    );
  }

  // Migration v3 -> v4: thêm cột "outline" (dàn ý/định hướng chương, cho
  // phép viết "chương mồi" trước, tạo hàng loạt sau — xem
  // ChaptersBatchGenerateScreen) và bảng pending_rewrites (ghi chú chờ xử
  // lý khi bôi đen sửa — xem PendingRewrite trong story_models.dart).
  Future<void> _migrateToV4(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'outline', 'TEXT');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS pending_rewrites(
        id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT,
        original_text TEXT, note TEXT, status TEXT,
        result_text TEXT, created_at TEXT
      )
    ''');
  }

  // Migration v2 -> v3: thêm "phân loại thẻ chi tiết" (category) cho
  // characters/world_rules, thêm bảng version snapshot (chapter_versions)
  // và bảng thuật ngữ (glossary_terms). Toàn bộ đều là ADD COLUMN/CREATE
  // TABLE IF NOT EXISTS — không đụng tới dữ liệu cũ.
  Future<void> _migrateToV3(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('characters', 'category', 'TEXT');
    await addColumnIfMissing('world_rules', 'category', 'TEXT');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS chapter_versions(
        id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT, title TEXT,
        content TEXT, label TEXT, created_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS glossary_terms(
        id TEXT PRIMARY KEY, novel_id TEXT, term TEXT, definition TEXT,
        category TEXT, updated_at TEXT
      )
    ''');
  }

  // Migration v1 -> v2: thêm khái niệm "nhiều truyện". Máy đã cài bản cũ
  // (chỉ 1 truyện, không có cột novel_id) sẽ được tự động gom toàn bộ dữ
  // liệu sẵn có vào một truyện mặc định "Truyện của tôi" — không mất dữ
  // liệu người dùng đã viết trước khi cập nhật.
  Future<void> _migrateToMultiNovel(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS novels(
        id TEXT PRIMARY KEY, title TEXT, author TEXT, description TEXT,
        created_at TEXT, updated_at TEXT
      )
    ''');

    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('characters', 'novel_id', 'TEXT');
    await addColumnIfMissing('world_rules', 'novel_id', 'TEXT');
    await addColumnIfMissing('timeline_events', 'novel_id', 'TEXT');
    await addColumnIfMissing('chapters', 'novel_id', 'TEXT');
    await addColumnIfMissing('style_profiles', 'novel_id', 'TEXT');
    await addColumnIfMissing('chat_sessions', 'novel_id', 'TEXT');
    await addColumnIfMissing('imported_documents', 'novel_id', 'TEXT');

    // chapters_fts (fts4) không hỗ trợ ALTER TABLE ADD COLUMN — dựng lại
    // từ dữ liệu chapters hiện có, kèm cột novel_id.
    final ftsExists = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='chapters_fts'",
    );
    if (ftsExists.isNotEmpty) {
      await db.execute('DROP TABLE chapters_fts');
    }
    await db.execute('''
      CREATE VIRTUAL TABLE chapters_fts USING fts4(
        chapter_id, novel_id, title, content
      )
    ''');

    // Có dữ liệu cũ (chương/nhân vật...) mà chưa có truyện nào chứa nó
    // -> tạo 1 truyện mặc định và gán toàn bộ dữ liệu mồ côi vào đó.
    final hasOldChapters = await db.query('chapters', limit: 1);
    final hasOldCharacters = await db.query('characters', limit: 1);
    final hasAnyOldData = hasOldChapters.isNotEmpty || hasOldCharacters.isNotEmpty;

    if (hasAnyOldData) {
      final defaultId = const Uuid().v4();
      final now = DateTime.now().toIso8601String();
      await db.insert('novels', {
        'id': defaultId,
        'title': 'Truyện của tôi',
        'author': '',
        'description': 'Được tự động tạo khi nâng cấp app lên bản hỗ trợ nhiều truyện.',
        'created_at': now,
        'updated_at': now,
      });
      for (final table in [
        'characters',
        'world_rules',
        'timeline_events',
        'chapters',
        'style_profiles',
        'chat_sessions',
        'imported_documents',
      ]) {
        await db.update(table, {'novel_id': defaultId}, where: 'novel_id IS NULL');
      }
      final chapters = await db.query('chapters', where: 'novel_id = ?', whereArgs: [defaultId]);
      for (final c in chapters) {
        await db.insert('chapters_fts', {
          'chapter_id': c['id'],
          'novel_id': defaultId,
          'title': c['title'],
          'content': c['content'],
        });
      }
    }
  }

  // ---------- Novels ----------
  Future<void> upsertNovel(Novel n) async {
    final d = await db;
    await d.insert('novels', n.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Novel>> allNovels() async {
    final d = await db;
    final rows = await d.query('novels', orderBy: 'updated_at DESC');
    return rows.map((r) => Novel.fromMap(r)).toList();
  }

  Future<Novel?> novelById(String id) async {
    final d = await db;
    final rows = await d.query('novels', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return Novel.fromMap(rows.first);
  }

  // Xóa 1 truyện và TOÀN BỘ dữ liệu riêng của nó (chương, nhân vật, luật,
  // timeline, văn phong, chat, tài liệu) — không đụng tới truyện khác.
  Future<void> deleteNovel(String id) async {
    final d = await db;
    await d.delete('chapters_fts', where: 'novel_id = ?', whereArgs: [id]);
    final chapterIds = (await d.query('chapters', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final chId in chapterIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['chapter', chId]);
    }
    final charIds = (await d.query('characters', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final cid in charIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['character', cid]);
    }
    final ruleIds = (await d.query('world_rules', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final rid in ruleIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['world_rule', rid]);
    }
    final sessionIds = (await d.query('chat_sessions', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final sid in sessionIds) {
      await d.delete('chat_messages', where: 'session_id = ?', whereArgs: [sid]);
    }
    final docIds = (await d.query('imported_documents', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final did in docIds) {
      await d.delete('document_chunks', where: 'document_id = ?', whereArgs: [did]);
    }
    await d.delete('characters', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('world_rules', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('timeline_events', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chapters', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chapter_versions', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('glossary_terms', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('style_profiles', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chat_sessions', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('imported_documents', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('novels', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Characters ----------
  Future<void> upsertCharacter(Character c) async {
    final d = await db;
    await d.insert('characters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Character>> allCharacters(String novelId) async {
    final d = await db;
    final rows = await d.query('characters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => Character.fromMap(r)).toList();
  }

  Future<void> deleteCharacter(String id) async {
    final d = await db;
    await d.delete('characters', where: 'id = ?', whereArgs: [id]);
    await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['character', id]);
  }

  // ---------- World rules ----------
  Future<void> upsertWorldRule(WorldRule r) async {
    final d = await db;
    await d.insert('world_rules', r.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<WorldRule>> allWorldRules(String novelId) async {
    final d = await db;
    final rows = await d.query('world_rules', where: 'novel_id = ?', whereArgs: [novelId]);
    return rows.map((r) => WorldRule.fromMap(r)).toList();
  }

  Future<void> deleteWorldRule(String id) async {
    final d = await db;
    await d.delete('world_rules', where: 'id = ?', whereArgs: [id]);
    await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['world_rule', id]);
  }

  // ---------- Timeline ----------
  Future<void> upsertTimelineEvent(TimelineEvent e) async {
    final d = await db;
    await d.insert('timeline_events', e.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<TimelineEvent>> allTimelineEvents(String novelId) async {
    final d = await db;
    final rows =
        await d.query('timeline_events', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'chapter_number');
    return rows.map((r) => TimelineEvent.fromMap(r)).toList();
  }

  // ---------- Chapters ----------
  Future<void> upsertChapter(Chapter c) async {
    final d = await db;
    await d.insert('chapters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    await d.delete('chapters_fts', where: 'chapter_id = ?', whereArgs: [c.id]);
    await d.insert('chapters_fts',
        {'chapter_id': c.id, 'novel_id': c.novelId, 'title': c.title, 'content': c.content});
  }

  Future<List<Chapter>> allChapters(String novelId, {int? limit, int? offset}) async {
    final d = await db;
    final rows = await d.query('chapters',
        where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number DESC', limit: limit, offset: offset);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  Future<List<Chapter>> recentChapters(String novelId, int count) async {
    final d = await db;
    final rows =
        await d.query('chapters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number DESC', limit: count);
    return rows.map((r) => Chapter.fromMap(r)).toList().reversed.toList();
  }

  // ĐÃ THÊM: DAO cho hàng đợi ghi chú bôi đen sửa (PendingRewrite) — xem
  // giải thích đầy đủ ở định nghĩa class trong story_models.dart.
  Future<void> upsertPendingRewrite(PendingRewrite p) async {
    final d = await db;
    await d.insert('pending_rewrites', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<PendingRewrite>> pendingRewritesForChapter(String chapterId) async {
    final d = await db;
    final rows = await d.query('pending_rewrites',
        where: 'chapter_id = ?', whereArgs: [chapterId], orderBy: 'created_at ASC');
    return rows.map((r) => PendingRewrite.fromMap(r)).toList();
  }

  Future<void> deletePendingRewrite(String id) async {
    final d = await db;
    await d.delete('pending_rewrites', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAllPendingRewritesForChapter(String chapterId) async {
    final d = await db;
    await d.delete('pending_rewrites', where: 'chapter_id = ?', whereArgs: [chapterId]);
  }

  // Tìm kiếm toàn văn — dùng cho cả thanh search và cho RAG khi cần
  // tra cứu chương cũ có nhắc tới một từ khóa cụ thể. Luôn giới hạn
  // trong đúng 1 truyện, không lẫn sang truyện khác.
  Future<List<Chapter>> searchChapters(String novelId, String query) async {
    final d = await db;
    final ids = await d.rawQuery(
      'SELECT chapter_id FROM chapters_fts WHERE chapters_fts MATCH ? AND novel_id = ?',
      [query, novelId],
    );
    if (ids.isEmpty) return [];
    final idList = ids.map((r) => r['chapter_id'] as String).toList();
    final rows = await d.query('chapters',
        where: 'novel_id = ? AND id IN (${List.filled(idList.length, '?').join(',')})',
        whereArgs: [novelId, ...idList]);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // Dùng khi xuất file: cần thứ tự tăng dần theo số chương, không phải
  // "mới nhất trước" như danh sách hiển thị trong app.
  Future<List<Chapter>> allChaptersAscending(String novelId) async {
    final d = await db;
    final rows = await d.query('chapters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number ASC');
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // ---------- Chapter versions (snapshot/undo) ----------
  // Số bản snapshot tối đa giữ lại CHO MỖI CHƯƠNG — vượt quá thì tự xóa
  // bản cũ nhất, tránh phình dung lượng DB vô hạn qua hàng nghìn lần AI
  // viết tiếp/rewrite.
  static const int maxVersionsPerChapter = 20;

  Future<void> saveChapterVersion(ChapterVersion v) async {
    final d = await db;
    await d.insert('chapter_versions', v.toMap());
    final rows = await d.query(
      'chapter_versions',
      columns: ['id'],
      where: 'chapter_id = ?',
      whereArgs: [v.chapterId],
      orderBy: 'created_at DESC',
    );
    if (rows.length > maxVersionsPerChapter) {
      final toDelete = rows.skip(maxVersionsPerChapter).map((r) => r['id'] as String).toList();
      await d.delete(
        'chapter_versions',
        where: 'id IN (${List.filled(toDelete.length, '?').join(',')})',
        whereArgs: toDelete,
      );
    }
  }

  Future<List<ChapterVersion>> versionsForChapter(String chapterId) async {
    final d = await db;
    final rows = await d.query('chapter_versions', where: 'chapter_id = ?', whereArgs: [chapterId], orderBy: 'created_at DESC');
    return rows.map((r) => ChapterVersion.fromMap(r)).toList();
  }

  Future<void> deleteChapterVersion(String id) async {
    final d = await db;
    await d.delete('chapter_versions', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Glossary (bảng thuật ngữ) ----------
  Future<void> upsertGlossaryTerm(GlossaryTerm t) async {
    final d = await db;
    await d.insert('glossary_terms', t.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<GlossaryTerm>> allGlossaryTerms(String novelId) async {
    final d = await db;
    final rows = await d.query('glossary_terms', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'term');
    return rows.map((r) => GlossaryTerm.fromMap(r)).toList();
  }

  Future<void> deleteGlossaryTerm(String id) async {
    final d = await db;
    await d.delete('glossary_terms', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Local models (nhiều model, chọn 1 model active, dùng chung mọi truyện) ----------
  Future<void> upsertLocalModel(LocalModelEntry m) async {
    final d = await db;
    await d.insert('local_models', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<LocalModelEntry>> allLocalModels() async {
    final d = await db;
    final rows = await d.query('local_models', orderBy: 'name');
    return rows.map((r) => LocalModelEntry.fromMap(r)).toList();
  }

  Future<void> deleteLocalModel(String id) async {
    final d = await db;
    await d.delete('local_models', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- API providers (nhiều provider, không hardcode, dùng chung mọi truyện) ----------
  Future<void> upsertApiProvider(ApiProviderEntry p) async {
    final d = await db;
    await d.insert('api_providers', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ApiProviderEntry>> allApiProviders() async {
    final d = await db;
    final rows = await d.query('api_providers', orderBy: 'name');
    return rows.map((r) => ApiProviderEntry.fromMap(r)).toList();
  }

  Future<void> deleteApiProvider(String id) async {
    final d = await db;
    await d.delete('api_providers', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Imported documents (dịch/tóm tắt/hỏi đáp cuốn chiếu) ----------
  Future<void> upsertDocument(ImportedDocument doc) async {
    final d = await db;
    await d.insert('imported_documents', doc.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ImportedDocument>> allDocuments(String novelId) async {
    final d = await db;
    final rows =
        await d.query('imported_documents', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'created_at DESC');
    return rows.map((r) => ImportedDocument.fromMap(r)).toList();
  }

  Future<void> deleteDocument(String id) async {
    final d = await db;
    await d.delete('imported_documents', where: 'id = ?', whereArgs: [id]);
    await d.delete('document_chunks', where: 'document_id = ?', whereArgs: [id]);
  }

  Future<void> upsertDocumentChunk(DocumentChunk c) async {
    final d = await db;
    await d.insert('document_chunks', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<DocumentChunk>> chunksForDocument(String documentId) async {
    final d = await db;
    final rows = await d.query('document_chunks', where: 'document_id = ?', whereArgs: [documentId], orderBy: 'idx ASC');
    return rows.map((r) => DocumentChunk.fromMap(r)).toList();
  }

  // ---------- Chat sessions (nhiều cửa sổ chat, theo từng truyện) ----------
  Future<void> upsertChatSession(ChatSession s) async {
    final d = await db;
    await d.insert('chat_sessions', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatSession>> allChatSessions(String novelId) async {
    final d = await db;
    final rows =
        await d.query('chat_sessions', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'created_at DESC');
    return rows.map((r) => ChatSession.fromMap(r)).toList();
  }

  Future<void> deleteChatSession(String id) async {
    final d = await db;
    await d.delete('chat_sessions', where: 'id = ?', whereArgs: [id]);
    await d.delete('chat_messages', where: 'session_id = ?', whereArgs: [id]);
  }

  // ---------- Chat messages (bền vững - không mất khi đổi tab/model) ----------
  Future<void> upsertChatMessage(ChatMessageRecord m) async {
    final d = await db;
    await d.insert('chat_messages', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatMessageRecord>> chatMessagesForSession(String sessionId) async {
    final d = await db;
    final rows = await d.query('chat_messages', where: 'session_id = ?', whereArgs: [sessionId], orderBy: 'created_at ASC');
    return rows.map((r) => ChatMessageRecord.fromMap(r)).toList();
  }

  // ---------- Style profiles ----------
  Future<void> upsertStyleProfile(StyleProfile s) async {
    final d = await db;
    await d.insert('style_profiles', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<StyleProfile>> allStyleProfiles(String novelId) async {
    final d = await db;
    final rows = await d.query('style_profiles', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => StyleProfile.fromMap(r)).toList();
  }

  Future<void> deleteStyleProfile(String id) async {
    final d = await db;
    await d.delete('style_profiles', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Embeddings ----------
  Future<void> upsertEmbedding(String entityType, String entityId, List<double> vector) async {
    final d = await db;
    await d.insert(
      'embeddings',
      {
        'entity_type': entityType,
        'entity_id': entityId,
        'vector': vector.map((v) => v.toStringAsFixed(6)).join(','),
        'updated_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Trả về map entity_id -> vector cho một loại entity, dùng để so sánh
  // cosine similarity với vector của đoạn văn đang viết. entityIds giới
  // hạn kết quả về đúng những entity thuộc truyện đang active (vì bảng
  // embeddings không có cột novel_id riêng, lọc chéo qua danh sách id).
  Future<Map<String, List<double>>> embeddingsFor(String entityType, {List<String>? entityIds}) async {
    final d = await db;
    final rows = await d.query('embeddings', where: 'entity_type = ?', whereArgs: [entityType]);
    final map = {
      for (final r in rows)
        r['entity_id'] as String: (r['vector'] as String).split(',').map(double.parse).toList(),
    };
    if (entityIds == null) return map;
    final idSet = entityIds.toSet();
    map.removeWhere((key, _) => !idSet.contains(key));
    return map;
  }

  // ---------- Backup / Restore toàn bộ dữ liệu ----------
  // Xuất TOÀN BỘ dữ liệu mọi truyện thành 1 cấu trúc JSON thuần (không xuất
  // API key — API key nằm trong flutter_secure_storage riêng, tách biệt có
  // chủ đích vì lý do bảo mật, người dùng cần nhập lại API key sau khi khôi
  // phục trên máy mới). Dùng JSON thay vì copy thẳng file .db để: (1) không
  // phụ thuộc journal mode/WAL còn dở dang lúc copy, (2) portable — khôi
  // phục được cả khi cấu trúc file nội bộ giữa các bản app hơi khác nhau,
  // vì import chạy qua đúng các hàm upsert bình thường (tự re-index FTS,
  // v.v.) thay vì ghi đè thẳng file nhị phân.
  static const List<String> _backupTables = [
    'novels',
    'characters',
    'world_rules',
    'timeline_events',
    'chapters',
    'chapter_versions',
    'glossary_terms',
    'style_profiles',
    'chat_sessions',
    'chat_messages',
    'imported_documents',
    'document_chunks',
    'local_models',
    'api_providers', // KHÔNG có api_key — chỉ metadata (tên/model/base_url)
  ];

  Future<Map<String, dynamic>> exportAllData() async {
    final d = await db;
    final data = <String, dynamic>{};
    for (final table in _backupTables) {
      data[table] = await d.query(table);
    }
    return data;
  }

  // Ghi đè theo id (upsert) — an toàn để chạy nhiều lần, không tạo bản
  // trùng. Chapters cần đồng bộ lại chapters_fts nên đi qua upsertChapter()
  // thay vì insert thẳng bảng chapters.
  Future<void> importAllData(Map<String, dynamic> data) async {
    final d = await db;
    for (final table in _backupTables) {
      final rows = (data[table] as List?)?.cast<Map<String, dynamic>>() ?? [];
      if (table == 'chapters') {
        for (final r in rows) {
          await upsertChapter(Chapter.fromMap(r));
        }
        continue;
      }
      for (final r in rows) {
        await d.insert(table, r, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    }
  }
}
