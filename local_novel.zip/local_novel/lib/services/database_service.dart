import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';

// Toàn bộ dữ liệu truyện lưu local trên máy (SQLite), không phụ thuộc mạng.
// Đây là "bộ nhớ dài hạn" thay thế cho việc nhồi cả 1000 chương vào context AI.
//
// Hỗ trợ NHIỀU TRUYỆN (novels): mọi bảng nội dung (characters, world_rules,
// timeline_events, chapters, style_profiles, chat_sessions, chat_messages,
// imported_documents) đều có cột novel_id để tách biệt hoàn toàn dữ liệu
// giữa các truyện khác nhau. local_models/api_providers KHÔNG gắn theo
// novel_id vì đó là tài nguyên máy (model .gguf, API key) dùng chung.
class DatabaseService {
  static final DatabaseService instance = DatabaseService._internal();
  DatabaseService._internal();
  Database? _db;

  static const int schemaVersion = 9;

  Future<Database> get db async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'local_novel.db');
    return openDatabase(
      path,
      version: schemaVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE novels(
            id TEXT PRIMARY KEY, title TEXT, author TEXT, description TEXT,
            created_at TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE characters(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, role TEXT, category TEXT, description TEXT,
            voice_style TEXT, keywords TEXT, effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE world_rules(
            id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, content TEXT,
            is_hard_rule INTEGER, category TEXT, keywords TEXT,
            effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE timeline_events(
            id TEXT PRIMARY KEY, novel_id TEXT, chapter_number INTEGER, summary TEXT, in_story_date TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chapters(
            id TEXT PRIMARY KEY, novel_id TEXT, number INTEGER, title TEXT, content TEXT,
            outline TEXT, auto_summary TEXT, consistency_checked INTEGER,
            consistency_warning TEXT, updated_at TEXT,
            thread_ids TEXT, volume_id TEXT
          )
        ''');
        // FTS ảo để tìm kiếm toàn văn nhanh trong hàng nghìn chương
        await db.execute('''
          CREATE VIRTUAL TABLE chapters_fts USING fts4(
            chapter_id, novel_id, title, content
          )
        ''');
        await db.execute('''
          CREATE TABLE local_models(
            id TEXT PRIMARY KEY, name TEXT, path TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE api_providers(
            id TEXT PRIMARY KEY, name TEXT, type TEXT, base_url TEXT, model_id TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE imported_documents(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, source_path TEXT,
            chunk_count INTEGER, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE document_chunks(
            id TEXT PRIMARY KEY, document_id TEXT, idx INTEGER, original_text TEXT, result_text TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_sessions(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_messages(
            id TEXT PRIMARY KEY, session_id TEXT, from_user INTEGER, text TEXT,
            provider_label TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE style_profiles(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, profile_description TEXT,
            effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        // Vector embedding cho RAG ngữ nghĩa. entity_type: 'character' |
        // 'world_rule' | 'chapter'. vector lưu dạng chuỗi số cách nhau
        // bởi dấu phẩy — đơn giản, đủ dùng cho quy mô vài nghìn entry.
        await db.execute('''
          CREATE TABLE embeddings(
            entity_type TEXT, entity_id TEXT, vector TEXT, updated_at TEXT,
            PRIMARY KEY (entity_type, entity_id)
          )
        ''');
        // Version snapshot — bản nháp cũ của chương, chụp trước khi bị ghi
        // đè (AI viết tiếp/đắp thịt/rewrite hoặc lưu tay), cho phép undo.
        await db.execute('''
          CREATE TABLE chapter_versions(
            id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT, title TEXT,
            content TEXT, label TEXT, created_at TEXT
          )
        ''');
        // Bảng thuật ngữ riêng của truyện — tra cứu nhanh, không tham gia
        // lorebook tự động nạp prompt (khác Character/WorldRule).
        await db.execute('''
          CREATE TABLE glossary_terms(
            id TEXT PRIMARY KEY, novel_id TEXT, term TEXT, definition TEXT,
            category TEXT, effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE pending_rewrites(
            id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT,
            original_text TEXT, note TEXT, status TEXT,
            result_text TEXT, created_at TEXT
          )
        ''');
        // MỚI (v5): dàn ý toàn truyện + tuyến truyện/subplot + mục tiêu viết —
        // xem PlotBeat/PlotThread/WritingGoal trong story_models.dart.
        await db.execute('''
          CREATE TABLE plot_beats(
            id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
            beat_type TEXT, order_index INTEGER, linked_chapter_number INTEGER,
            status TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE plot_threads(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, description TEXT,
            color_value INTEGER, status TEXT, effective_from_chapter INTEGER,
            effective_to_chapter INTEGER, effective_from_volume_id TEXT,
            effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE writing_goals(
            novel_id TEXT PRIMARY KEY, daily_target_words INTEGER, updated_at TEXT
          )
        ''');
        // Ảnh chụp tổng số chữ của 1 truyện tại 1 ngày cụ thể — hiệu số
        // giữa 2 ngày liền kề = số chữ đã viết trong ngày đó. Không lưu
        // trực tiếp "số chữ viết trong ngày" vì phải cộng dồn đúng mọi
        // lượt lưu chương trong ngày (có thể sửa đi sửa lại nhiều lần) —
        // snapshot tổng rồi tính hiệu số ở tầng đọc đơn giản và chính xác
        // hơn cộng dồn từng delta.
        await db.execute('''
          CREATE TABLE daily_word_log(
            novel_id TEXT, date TEXT, total_words INTEGER,
            PRIMARY KEY (novel_id, date)
          )
        ''');
        // ĐÃ SỬA: 2 cột `thread_ids` (v5) và `volume_id` (v6) trước đây CHỈ
        // được thêm qua ALTER TABLE trong onUpgrade — người cài app MỚI
        // HOÀN TOÀN (DB tạo thẳng ở version hiện tại qua onCreate, không
        // đi qua onUpgrade) không hề có 2 cột này, trong khi Chapter.toMap()
        // luôn ghi cả 2 field đó xuống DB. Hậu quả: MỌI lần insert/update
        // chương (kể cả bấm nút "+" tạo chương) đều ném lỗi "no column
        // named thread_ids/volume_id" ở tầng sqflite — lỗi này KHÔNG được
        // bắt ở nơi gọi (`_newChapter()` trong chapters_screen.dart không
        // có try/catch), Future lỗi rơi âm thầm, người dùng thấy y hệt như
        // bấm nút mà không có gì xảy ra. Đã thêm cả 2 cột thẳng vào DDL
        // gốc để bảng luôn khớp với model ngay từ lúc tạo DB.
        //
        // MỚI (v6): tầng "Quyển/Hồi" nhóm nhiều chương — xem Volume trong
        // story_models.dart. Chapter.number KHÔNG đổi cách đánh số (vẫn liên
        // tục xuyên suốt truyện), volume chỉ là nhãn gom nhóm hiển thị.
        await db.execute('''
          CREATE TABLE volumes(
            id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
            order_index INTEGER, updated_at TEXT
          )
        ''');
        // MỚI (v9): "chi tiết theo giai đoạn" (BibleFact) — 1 bảng DÙNG
        // CHUNG cho cả 5 loại Bible, mỗi entry có thể có NHIỀU chi tiết,
        // MỖI chi tiết 1 phạm vi hiệu lực RIÊNG (tách biệt khỏi phạm vi
        // của entry cha) — xem story_models.dart.
        await db.execute('''
          CREATE TABLE bible_facts(
            id TEXT PRIMARY KEY, novel_id TEXT, parent_type TEXT, parent_id TEXT,
            fact_text TEXT, order_index INTEGER,
            effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await _migrateToMultiNovel(db);
        }
        if (oldVersion < 3) {
          await _migrateToV3(db);
        }
        if (oldVersion < 4) {
          await _migrateToV4(db);
        }
        if (oldVersion < 5) {
          await _migrateToV5(db);
        }
        if (oldVersion < 6) {
          await _migrateToV6(db);
        }
        if (oldVersion < 7) {
          await _migrateToV7(db);
        }
        if (oldVersion < 8) {
          await _migrateToV8(db);
        }
        if (oldVersion < 9) {
          await _migrateToV9(db);
        }
      },
    );
  }

  // Migration v3 -> v4: thêm cột "outline" (dàn ý/định hướng chương, cho
  // phép viết "chương mồi" trước, tạo hàng loạt sau — xem
  // ChaptersBatchGenerateScreen) và bảng pending_rewrites (ghi chú chờ xử
  // lý khi bôi đen sửa — xem PendingRewrite trong story_models.dart).
  Future<void> _migrateToV4(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'outline', 'TEXT');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS pending_rewrites(
        id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT,
        original_text TEXT, note TEXT, status TEXT,
        result_text TEXT, created_at TEXT
      )
    ''');
  }

  // Migration v4 -> v5: dàn ý toàn truyện (plot_beats) + tuyến truyện/subplot
  // (plot_threads, cột thread_ids trong chapters) + mục tiêu viết hàng ngày
  // (writing_goals, daily_word_log) — xem PlotBeat/PlotThread/WritingGoal
  // trong story_models.dart. Toàn bộ CREATE TABLE IF NOT EXISTS/ADD COLUMN,
  // không đụng tới dữ liệu cũ.
  Future<void> _migrateToV5(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'thread_ids', 'TEXT');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS plot_beats(
        id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
        beat_type TEXT, order_index INTEGER, linked_chapter_number INTEGER,
        status TEXT, updated_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS plot_threads(
        id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, description TEXT,
        color_value INTEGER, status TEXT, updated_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS writing_goals(
        novel_id TEXT PRIMARY KEY, daily_target_words INTEGER, updated_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS daily_word_log(
        novel_id TEXT, date TEXT, total_words INTEGER,
        PRIMARY KEY (novel_id, date)
      )
    ''');
  }

  // Migration v5 -> v6: tầng "Quyển/Hồi" (Volume) nhóm nhiều chương —
  // xem Volume trong story_models.dart. ADD COLUMN/CREATE TABLE IF NOT
  // EXISTS — không đụng dữ liệu cũ, Chapter.number giữ nguyên cách đánh
  // số liên tục xuyên suốt truyện.
  Future<void> _migrateToV6(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'volume_id', 'TEXT');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS volumes(
        id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
        order_index INTEGER, updated_at TEXT
      )
    ''');
  }

  // Migration v6 -> v7: "phạm vi hiệu lực theo số chương" (effective_from_
  // chapter/effective_to_chapter) cho 5 bảng: characters, world_rules,
  // style_profiles, glossary_terms, plot_threads — xem story_models.dart
  // và rag_service.dart (_isInScope). Toàn bộ ADD COLUMN, mặc định NULL =
  // luôn có hiệu lực, không đụng dữ liệu cũ, không đổi hành vi hiện có.
  Future<void> _migrateToV7(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    for (final table in ['characters', 'world_rules', 'style_profiles', 'glossary_terms', 'plot_threads']) {
      await addColumnIfMissing(table, 'effective_from_chapter', 'INTEGER');
      await addColumnIfMissing(table, 'effective_to_chapter', 'INTEGER');
    }
  }

  // Migration v7 -> v8: thêm phạm vi hiệu lực THEO QUYỂN/HỒI (bên cạnh
  // theo số chương đã có ở v7) — xem story_models.dart. Cho phép người
  // dùng chọn "áp dụng trong Quyển 2" mà KHÔNG cần biết trước quyển đó
  // kết thúc ở chương bao nhiêu (tự dò lại khi dùng, xem
  // volumeChapterRanges() bên dưới) — đúng yêu cầu người dùng: không ép
  // chọn cứng giữa "theo chương" hay "theo quyển", linh hoạt cả 2.
  Future<void> _migrateToV8(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    for (final table in ['characters', 'world_rules', 'style_profiles', 'glossary_terms', 'plot_threads']) {
      await addColumnIfMissing(table, 'effective_from_volume_id', 'TEXT');
      await addColumnIfMissing(table, 'effective_to_volume_id', 'TEXT');
    }
  }

  // Migration v8 -> v9: "chi tiết theo giai đoạn" (BibleFact) — 1 bảng
  // dùng chung cho cả 5 loại Bible, mỗi entry có nhiều chi tiết, mỗi chi
  // tiết 1 phạm vi hiệu lực riêng — xem story_models.dart. CREATE TABLE
  // IF NOT EXISTS — không đụng dữ liệu cũ.
  Future<void> _migrateToV9(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS bible_facts(
        id TEXT PRIMARY KEY, novel_id TEXT, parent_type TEXT, parent_id TEXT,
        fact_text TEXT, order_index INTEGER,
        effective_from_chapter INTEGER, effective_to_chapter INTEGER,
        effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
      )
    ''');
  }

  // Migration v2 -> v3: thêm "phân loại thẻ chi tiết" (category) cho
  // characters/world_rules, thêm bảng version snapshot (chapter_versions)
  // và bảng thuật ngữ (glossary_terms). Toàn bộ đều là ADD COLUMN/CREATE
  // TABLE IF NOT EXISTS — không đụng tới dữ liệu cũ.
  Future<void> _migrateToV3(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('characters', 'category', 'TEXT');
    await addColumnIfMissing('world_rules', 'category', 'TEXT');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS chapter_versions(
        id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT, title TEXT,
        content TEXT, label TEXT, created_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS glossary_terms(
        id TEXT PRIMARY KEY, novel_id TEXT, term TEXT, definition TEXT,
        category TEXT, updated_at TEXT
      )
    ''');
  }

  // Migration v1 -> v2: thêm khái niệm "nhiều truyện". Máy đã cài bản cũ
  // (chỉ 1 truyện, không có cột novel_id) sẽ được tự động gom toàn bộ dữ
  // liệu sẵn có vào một truyện mặc định "Truyện của tôi" — không mất dữ
  // liệu người dùng đã viết trước khi cập nhật.
  Future<void> _migrateToMultiNovel(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS novels(
        id TEXT PRIMARY KEY, title TEXT, author TEXT, description TEXT,
        created_at TEXT, updated_at TEXT
      )
    ''');

    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('characters', 'novel_id', 'TEXT');
    await addColumnIfMissing('world_rules', 'novel_id', 'TEXT');
    await addColumnIfMissing('timeline_events', 'novel_id', 'TEXT');
    await addColumnIfMissing('chapters', 'novel_id', 'TEXT');
    await addColumnIfMissing('style_profiles', 'novel_id', 'TEXT');
    await addColumnIfMissing('chat_sessions', 'novel_id', 'TEXT');
    await addColumnIfMissing('imported_documents', 'novel_id', 'TEXT');

    // chapters_fts (fts4) không hỗ trợ ALTER TABLE ADD COLUMN — dựng lại
    // từ dữ liệu chapters hiện có, kèm cột novel_id.
    final ftsExists = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='chapters_fts'",
    );
    if (ftsExists.isNotEmpty) {
      await db.execute('DROP TABLE chapters_fts');
    }
    await db.execute('''
      CREATE VIRTUAL TABLE chapters_fts USING fts4(
        chapter_id, novel_id, title, content
      )
    ''');

    // Có dữ liệu cũ (chương/nhân vật...) mà chưa có truyện nào chứa nó
    // -> tạo 1 truyện mặc định và gán toàn bộ dữ liệu mồ côi vào đó.
    final hasOldChapters = await db.query('chapters', limit: 1);
    final hasOldCharacters = await db.query('characters', limit: 1);
    final hasAnyOldData = hasOldChapters.isNotEmpty || hasOldCharacters.isNotEmpty;

    if (hasAnyOldData) {
      final defaultId = const Uuid().v4();
      final now = DateTime.now().toIso8601String();
      await db.insert('novels', {
        'id': defaultId,
        'title': 'Truyện của tôi',
        'author': '',
        'description': 'Được tự động tạo khi nâng cấp app lên bản hỗ trợ nhiều truyện.',
        'created_at': now,
        'updated_at': now,
      });
      for (final table in [
        'characters',
        'world_rules',
        'timeline_events',
        'chapters',
        'style_profiles',
        'chat_sessions',
        'imported_documents',
      ]) {
        await db.update(table, {'novel_id': defaultId}, where: 'novel_id IS NULL');
      }
      final chapters = await db.query('chapters', where: 'novel_id = ?', whereArgs: [defaultId]);
      for (final c in chapters) {
        await db.insert('chapters_fts', {
          'chapter_id': c['id'],
          'novel_id': defaultId,
          'title': c['title'],
          'content': c['content'],
        });
      }
    }
  }

  // ---------- Novels ----------
  Future<void> upsertNovel(Novel n) async {
    final d = await db;
    await d.insert('novels', n.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Novel>> allNovels() async {
    final d = await db;
    final rows = await d.query('novels', orderBy: 'updated_at DESC');
    return rows.map((r) => Novel.fromMap(r)).toList();
  }

  Future<Novel?> novelById(String id) async {
    final d = await db;
    final rows = await d.query('novels', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return Novel.fromMap(rows.first);
  }

  // Xóa 1 truyện và TOÀN BỘ dữ liệu riêng của nó (chương, nhân vật, luật,
  // timeline, văn phong, chat, tài liệu) — không đụng tới truyện khác.
  Future<void> deleteNovel(String id) async {
    final d = await db;
    await d.delete('chapters_fts', where: 'novel_id = ?', whereArgs: [id]);
    final chapterIds = (await d.query('chapters', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final chId in chapterIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['chapter', chId]);
    }
    final charIds = (await d.query('characters', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final cid in charIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['character', cid]);
    }
    final ruleIds = (await d.query('world_rules', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final rid in ruleIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['world_rule', rid]);
    }
    final sessionIds = (await d.query('chat_sessions', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final sid in sessionIds) {
      await d.delete('chat_messages', where: 'session_id = ?', whereArgs: [sid]);
    }
    final docIds = (await d.query('imported_documents', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final did in docIds) {
      await d.delete('document_chunks', where: 'document_id = ?', whereArgs: [did]);
    }
    await d.delete('characters', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('world_rules', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('timeline_events', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chapters', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chapter_versions', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('glossary_terms', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('style_profiles', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chat_sessions', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('imported_documents', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('novels', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Characters ----------
  Future<void> upsertCharacter(Character c) async {
    final d = await db;
    await d.insert('characters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Character>> allCharacters(String novelId) async {
    final d = await db;
    final rows = await d.query('characters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => Character.fromMap(r)).toList();
  }

  Future<void> deleteCharacter(String id) async {
    final d = await db;
    await d.delete('characters', where: 'id = ?', whereArgs: [id]);
    await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['character', id]);
    await deleteFactsForParent('character', id);
  }

  // ---------- World rules ----------
  Future<void> upsertWorldRule(WorldRule r) async {
    final d = await db;
    await d.insert('world_rules', r.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<WorldRule>> allWorldRules(String novelId) async {
    final d = await db;
    final rows = await d.query('world_rules', where: 'novel_id = ?', whereArgs: [novelId]);
    return rows.map((r) => WorldRule.fromMap(r)).toList();
  }

  Future<void> deleteWorldRule(String id) async {
    final d = await db;
    await d.delete('world_rules', where: 'id = ?', whereArgs: [id]);
    await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['world_rule', id]);
    await deleteFactsForParent('world_rule', id);
  }

  // ---------- Timeline ----------
  Future<void> upsertTimelineEvent(TimelineEvent e) async {
    final d = await db;
    await d.insert('timeline_events', e.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<TimelineEvent>> allTimelineEvents(String novelId) async {
    final d = await db;
    final rows =
        await d.query('timeline_events', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'chapter_number');
    return rows.map((r) => TimelineEvent.fromMap(r)).toList();
  }

  // ---------- Chapters ----------
  Future<void> upsertChapter(Chapter c) async {
    final d = await db;
    await d.insert('chapters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    await d.delete('chapters_fts', where: 'chapter_id = ?', whereArgs: [c.id]);
    await d.insert('chapters_fts',
        {'chapter_id': c.id, 'novel_id': c.novelId, 'title': c.title, 'content': c.content});
  }

  Future<List<Chapter>> allChapters(String novelId, {int? limit, int? offset}) async {
    final d = await db;
    final rows = await d.query('chapters',
        where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number DESC', limit: limit, offset: offset);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  Future<List<Chapter>> recentChapters(String novelId, int count) async {
    final d = await db;
    final rows =
        await d.query('chapters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number DESC', limit: count);
    return rows.map((r) => Chapter.fromMap(r)).toList().reversed.toList();
  }

  // ĐÃ THÊM: DAO cho hàng đợi ghi chú bôi đen sửa (PendingRewrite) — xem
  // giải thích đầy đủ ở định nghĩa class trong story_models.dart.
  Future<void> upsertPendingRewrite(PendingRewrite p) async {
    final d = await db;
    await d.insert('pending_rewrites', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<PendingRewrite>> pendingRewritesForChapter(String chapterId) async {
    final d = await db;
    final rows = await d.query('pending_rewrites',
        where: 'chapter_id = ?', whereArgs: [chapterId], orderBy: 'created_at ASC');
    return rows.map((r) => PendingRewrite.fromMap(r)).toList();
  }

  Future<void> deletePendingRewrite(String id) async {
    final d = await db;
    await d.delete('pending_rewrites', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAllPendingRewritesForChapter(String chapterId) async {
    final d = await db;
    await d.delete('pending_rewrites', where: 'chapter_id = ?', whereArgs: [chapterId]);
  }

  // Tìm kiếm toàn văn — dùng cho cả thanh search và cho RAG khi cần
  // tra cứu chương cũ có nhắc tới một từ khóa cụ thể. Luôn giới hạn
  // trong đúng 1 truyện, không lẫn sang truyện khác.
  Future<List<Chapter>> searchChapters(String novelId, String query) async {
    final d = await db;
    final ids = await d.rawQuery(
      'SELECT chapter_id FROM chapters_fts WHERE chapters_fts MATCH ? AND novel_id = ?',
      [query, novelId],
    );
    if (ids.isEmpty) return [];
    final idList = ids.map((r) => r['chapter_id'] as String).toList();
    final rows = await d.query('chapters',
        where: 'novel_id = ? AND id IN (${List.filled(idList.length, '?').join(',')})',
        whereArgs: [novelId, ...idList]);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // Dùng khi xuất file: cần thứ tự tăng dần theo số chương, không phải
  // "mới nhất trước" như danh sách hiển thị trong app.
  Future<List<Chapter>> allChaptersAscending(String novelId) async {
    final d = await db;
    final rows = await d.query('chapters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number ASC');
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // ---------- Chapter versions (snapshot/undo) ----------
  // Số bản snapshot tối đa giữ lại CHO MỖI CHƯƠNG — vượt quá thì tự xóa
  // bản cũ nhất, tránh phình dung lượng DB vô hạn qua hàng nghìn lần AI
  // viết tiếp/rewrite.
  static const int maxVersionsPerChapter = 20;

  Future<void> saveChapterVersion(ChapterVersion v) async {
    final d = await db;
    await d.insert('chapter_versions', v.toMap());
    final rows = await d.query(
      'chapter_versions',
      columns: ['id'],
      where: 'chapter_id = ?',
      whereArgs: [v.chapterId],
      orderBy: 'created_at DESC',
    );
    if (rows.length > maxVersionsPerChapter) {
      final toDelete = rows.skip(maxVersionsPerChapter).map((r) => r['id'] as String).toList();
      await d.delete(
        'chapter_versions',
        where: 'id IN (${List.filled(toDelete.length, '?').join(',')})',
        whereArgs: toDelete,
      );
    }
  }

  Future<List<ChapterVersion>> versionsForChapter(String chapterId) async {
    final d = await db;
    final rows = await d.query('chapter_versions', where: 'chapter_id = ?', whereArgs: [chapterId], orderBy: 'created_at DESC');
    return rows.map((r) => ChapterVersion.fromMap(r)).toList();
  }

  Future<void> deleteChapterVersion(String id) async {
    final d = await db;
    await d.delete('chapter_versions', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Glossary (bảng thuật ngữ) ----------
  Future<void> upsertGlossaryTerm(GlossaryTerm t) async {
    final d = await db;
    await d.insert('glossary_terms', t.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<GlossaryTerm>> allGlossaryTerms(String novelId) async {
    final d = await db;
    final rows = await d.query('glossary_terms', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'term');
    return rows.map((r) => GlossaryTerm.fromMap(r)).toList();
  }

  Future<void> deleteGlossaryTerm(String id) async {
    final d = await db;
    await d.delete('glossary_terms', where: 'id = ?', whereArgs: [id]);
    await deleteFactsForParent('glossary_term', id);
  }

  // ---------- Dàn ý toàn truyện (plot_beats) ----------
  Future<void> upsertPlotBeat(PlotBeat b) async {
    final d = await db;
    await d.insert('plot_beats', b.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<PlotBeat>> allPlotBeats(String novelId) async {
    final d = await db;
    final rows = await d.query('plot_beats', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'order_index');
    return rows.map((r) => PlotBeat.fromMap(r)).toList();
  }

  Future<void> deletePlotBeat(String id) async {
    final d = await db;
    await d.delete('plot_beats', where: 'id = ?', whereArgs: [id]);
  }

  // Lưu lại thứ tự mới sau khi người dùng kéo-thả sắp xếp lại — ghi đè
  // order_index của TỪNG beat theo đúng vị trí mới trong danh sách truyền
  // vào (đã sắp xếp sẵn ở tầng UI).
  Future<void> reorderPlotBeats(List<PlotBeat> orderedBeats) async {
    final d = await db;
    final batch = d.batch();
    for (var i = 0; i < orderedBeats.length; i++) {
      batch.update('plot_beats', {'order_index': i}, where: 'id = ?', whereArgs: [orderedBeats[i].id]);
    }
    await batch.commit(noResult: true);
  }

  // ---------- Tuyến truyện / subplot (plot_threads) ----------
  Future<void> upsertPlotThread(PlotThread t) async {
    final d = await db;
    await d.insert('plot_threads', t.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<PlotThread>> allPlotThreads(String novelId) async {
    final d = await db;
    final rows = await d.query('plot_threads', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => PlotThread.fromMap(r)).toList();
  }

  Future<void> deletePlotThread(String id) async {
    final d = await db;
    await d.delete('plot_threads', where: 'id = ?', whereArgs: [id]);
    await deleteFactsForParent('plot_thread', id);
    // Gỡ tham chiếu id tuyến vừa xoá khỏi MỌI chương đang gắn nó — tránh
    // để lại id "ma" (trỏ tới tuyến không còn tồn tại) trong thread_ids.
    final chapters = await d.query('chapters', where: "thread_ids LIKE ?", whereArgs: ['%$id%']);
    for (final row in chapters) {
      final ids = ((row['thread_ids'] as String?) ?? '').split(',').where((e) => e.isNotEmpty && e != id).join(',');
      await d.update('chapters', {'thread_ids': ids}, where: 'id = ?', whereArgs: [row['id']]);
    }
  }

  // ---------- Quyển/Hồi (volumes) ----------
  Future<void> upsertVolume(Volume v) async {
    final d = await db;
    await d.insert('volumes', v.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Volume>> allVolumes(String novelId) async {
    final d = await db;
    final rows = await d.query('volumes', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'order_index');
    return rows.map((r) => Volume.fromMap(r)).toList();
  }

  // Xoá quyển — KHÔNG xoá các chương đang thuộc quyển đó, chỉ gỡ tham
  // chiếu volume_id (đưa các chương đó về trạng thái "chưa gom quyển"),
  // đúng khuôn mẫu deletePlotThread đã áp dụng.
  Future<void> deleteVolume(String id) async {
    final d = await db;
    await d.delete('volumes', where: 'id = ?', whereArgs: [id]);
    await d.update('chapters', {'volume_id': null}, where: 'volume_id = ?', whereArgs: [id]);
  }

  Future<void> reorderVolumes(List<Volume> orderedVolumes) async {
    final d = await db;
    final batch = d.batch();
    for (var i = 0; i < orderedVolumes.length; i++) {
      batch.update('volumes', {'order_index': i}, where: 'id = ?', whereArgs: [orderedVolumes[i].id]);
    }
    await batch.commit(noResult: true);
  }

  // Dò khoảng số chương THẬT SỰ hiện có của MỖI quyển (min/max trong số
  // các chương ĐANG gán volume_id = quyển đó) — dùng cho phạm vi hiệu lực
  // "theo Quyển/Hồi" (RagService._resolveScope). CỐ TÌNH tính lại MỖI LẦN
  // gọi (không cache/đóng băng) — đúng yêu cầu người dùng: viết thêm
  // chương vào quyển sau này, phạm vi tự mở rộng theo, không cần cập nhật
  // thủ công entry nào. Quyển chưa có chương nào → không xuất hiện trong
  // map trả về (coi như phạm vi rỗng, chưa có gì để lọc).
  Future<Map<String, (int, int)>> volumeChapterRanges(String novelId) async {
    final d = await db;
    final rows = await d.rawQuery(
      'SELECT volume_id, MIN(number) as min_num, MAX(number) as max_num FROM chapters '
      'WHERE novel_id = ? AND volume_id IS NOT NULL GROUP BY volume_id',
      [novelId],
    );
    final result = <String, (int, int)>{};
    for (final r in rows) {
      final volumeId = r['volume_id'] as String?;
      if (volumeId == null) continue;
      result[volumeId] = (r['min_num'] as int, r['max_num'] as int);
    }
    return result;
  }

  // ---------- Chi tiết theo giai đoạn (BibleFact — dùng chung 5 loại Bible) ----------
  Future<void> upsertBibleFact(BibleFact f) async {
    final d = await db;
    await d.insert('bible_facts', f.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<BibleFact>> factsFor(String parentType, String parentId) async {
    final d = await db;
    final rows = await d.query(
      'bible_facts',
      where: 'parent_type = ? AND parent_id = ?',
      whereArgs: [parentType, parentId],
      orderBy: 'order_index',
    );
    return rows.map((r) => BibleFact.fromMap(r)).toList();
  }

  // Nạp TOÀN BỘ fact của 1 LOẠI (vd tất cả fact của mọi Character trong
  // truyện) trong 1 LẦN TRUY VẤN DUY NHẤT — dùng cho RagService.buildContext,
  // tránh N+1 query (1 query riêng cho từng nhân vật khi build ngữ cảnh).
  Future<Map<String, List<BibleFact>>> allFactsForType(String novelId, String parentType) async {
    final d = await db;
    final rows = await d.query(
      'bible_facts',
      where: 'novel_id = ? AND parent_type = ?',
      whereArgs: [novelId, parentType],
      orderBy: 'order_index',
    );
    final result = <String, List<BibleFact>>{};
    for (final r in rows) {
      final f = BibleFact.fromMap(r);
      result.putIfAbsent(f.parentId, () => []).add(f);
    }
    return result;
  }

  Future<void> deleteBibleFact(String id) async {
    final d = await db;
    await d.delete('bible_facts', where: 'id = ?', whereArgs: [id]);
  }

  // Xoá TOÀN BỘ fact thuộc 1 entry — gọi khi xoá chính entry đó (Character/
  // WorldRule/...) để không để lại fact "mồ côi" không còn entry cha.
  Future<void> deleteFactsForParent(String parentType, String parentId) async {
    final d = await db;
    await d.delete('bible_facts', where: 'parent_type = ? AND parent_id = ?', whereArgs: [parentType, parentId]);
  }

  // ---------- Mục tiêu viết + nhật ký số chữ mỗi ngày ----------
  Future<void> saveWritingGoal(WritingGoal g) async {
    final d = await db;
    await d.insert('writing_goals', g.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<WritingGoal?> loadWritingGoal(String novelId) async {
    final d = await db;
    final rows = await d.query('writing_goals', where: 'novel_id = ?', whereArgs: [novelId], limit: 1);
    if (rows.isEmpty) return null;
    return WritingGoal.fromMap(rows.first);
  }

  // Ghi lại tổng số chữ HIỆN TẠI của cả truyện tại NGÀY HÔM NAY — gọi mỗi
  // khi 1 chương được lưu (xem chapter_editor_screen.dart _save()). Ghi
  // đè (upsert) nếu hôm nay đã có snapshot rồi — luôn phản ánh đúng tổng
  // mới nhất trong ngày, không cộng dồn sai nếu lưu chương nhiều lần.
  Future<void> recordWordSnapshot(String novelId) async {
    final d = await db;
    final rows = await d.query('chapters', columns: ['content'], where: 'novel_id = ?', whereArgs: [novelId]);
    int total = 0;
    for (final r in rows) {
      final content = (r['content'] as String?) ?? '';
      if (content.trim().isNotEmpty) total += content.trim().split(RegExp(r'\s+')).length;
    }
    final today = DateTime.now();
    final dateKey = '${today.year.toString().padLeft(4, '0')}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
    await d.insert(
      'daily_word_log',
      {'novel_id': novelId, 'date': dateKey, 'total_words': total},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Trả về danh sách (ngày, tổng số chữ SNAPSHOT tại ngày đó) trong
  // `days` ngày gần nhất, sắp xếp CŨ -> MỚI — tầng UI tự tính hiệu số
  // giữa các ngày liền kề để ra "số chữ viết trong ngày", và tự tính
  // streak (chuỗi ngày liên tiếp có viết) từ dãy hiệu số đó.
  Future<List<Map<String, dynamic>>> recentWordLog(String novelId, {int days = 30}) async {
    final d = await db;
    final since = DateTime.now().subtract(Duration(days: days));
    final sinceKey = '${since.year.toString().padLeft(4, '0')}-${since.month.toString().padLeft(2, '0')}-${since.day.toString().padLeft(2, '0')}';
    final rows = await d.query(
      'daily_word_log',
      where: 'novel_id = ? AND date >= ?',
      whereArgs: [novelId, sinceKey],
      orderBy: 'date ASC',
    );
    return rows;
  }

  // ---------- Local models (nhiều model, chọn 1 model active, dùng chung mọi truyện) ----------
  Future<void> upsertLocalModel(LocalModelEntry m) async {
    final d = await db;
    await d.insert('local_models', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<LocalModelEntry>> allLocalModels() async {
    final d = await db;
    final rows = await d.query('local_models', orderBy: 'name');
    return rows.map((r) => LocalModelEntry.fromMap(r)).toList();
  }

  Future<void> deleteLocalModel(String id) async {
    final d = await db;
    await d.delete('local_models', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- API providers (nhiều provider, không hardcode, dùng chung mọi truyện) ----------
  Future<void> upsertApiProvider(ApiProviderEntry p) async {
    final d = await db;
    await d.insert('api_providers', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ApiProviderEntry>> allApiProviders() async {
    final d = await db;
    final rows = await d.query('api_providers', orderBy: 'name');
    return rows.map((r) => ApiProviderEntry.fromMap(r)).toList();
  }

  Future<void> deleteApiProvider(String id) async {
    final d = await db;
    await d.delete('api_providers', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Imported documents (dịch/tóm tắt/hỏi đáp cuốn chiếu) ----------
  Future<void> upsertDocument(ImportedDocument doc) async {
    final d = await db;
    await d.insert('imported_documents', doc.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ImportedDocument>> allDocuments(String novelId) async {
    final d = await db;
    final rows =
        await d.query('imported_documents', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'created_at DESC');
    return rows.map((r) => ImportedDocument.fromMap(r)).toList();
  }

  Future<void> deleteDocument(String id) async {
    final d = await db;
    await d.delete('imported_documents', where: 'id = ?', whereArgs: [id]);
    await d.delete('document_chunks', where: 'document_id = ?', whereArgs: [id]);
  }

  Future<void> upsertDocumentChunk(DocumentChunk c) async {
    final d = await db;
    await d.insert('document_chunks', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<DocumentChunk>> chunksForDocument(String documentId) async {
    final d = await db;
    final rows = await d.query('document_chunks', where: 'document_id = ?', whereArgs: [documentId], orderBy: 'idx ASC');
    return rows.map((r) => DocumentChunk.fromMap(r)).toList();
  }

  // ---------- Chat sessions (nhiều cửa sổ chat, theo từng truyện) ----------
  Future<void> upsertChatSession(ChatSession s) async {
    final d = await db;
    await d.insert('chat_sessions', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatSession>> allChatSessions(String novelId) async {
    final d = await db;
    final rows =
        await d.query('chat_sessions', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'created_at DESC');
    return rows.map((r) => ChatSession.fromMap(r)).toList();
  }

  Future<void> deleteChatSession(String id) async {
    final d = await db;
    await d.delete('chat_sessions', where: 'id = ?', whereArgs: [id]);
    await d.delete('chat_messages', where: 'session_id = ?', whereArgs: [id]);
  }

  // ---------- Chat messages (bền vững - không mất khi đổi tab/model) ----------
  Future<void> upsertChatMessage(ChatMessageRecord m) async {
    final d = await db;
    await d.insert('chat_messages', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatMessageRecord>> chatMessagesForSession(String sessionId) async {
    final d = await db;
    final rows = await d.query('chat_messages', where: 'session_id = ?', whereArgs: [sessionId], orderBy: 'created_at ASC');
    return rows.map((r) => ChatMessageRecord.fromMap(r)).toList();
  }

  // ---------- Style profiles ----------
  Future<void> upsertStyleProfile(StyleProfile s) async {
    final d = await db;
    await d.insert('style_profiles', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<StyleProfile>> allStyleProfiles(String novelId) async {
    final d = await db;
    final rows = await d.query('style_profiles', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => StyleProfile.fromMap(r)).toList();
  }

  Future<void> deleteStyleProfile(String id) async {
    final d = await db;
    await d.delete('style_profiles', where: 'id = ?', whereArgs: [id]);
    await deleteFactsForParent('style_profile', id);
  }

  // ---------- Embeddings ----------
  Future<void> upsertEmbedding(String entityType, String entityId, List<double> vector) async {
    final d = await db;
    await d.insert(
      'embeddings',
      {
        'entity_type': entityType,
        'entity_id': entityId,
        'vector': vector.map((v) => v.toStringAsFixed(6)).join(','),
        'updated_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Trả về map entity_id -> vector cho một loại entity, dùng để so sánh
  // cosine similarity với vector của đoạn văn đang viết. entityIds giới
  // hạn kết quả về đúng những entity thuộc truyện đang active (vì bảng
  // embeddings không có cột novel_id riêng, lọc chéo qua danh sách id).
  Future<Map<String, List<double>>> embeddingsFor(String entityType, {List<String>? entityIds}) async {
    final d = await db;
    final rows = await d.query('embeddings', where: 'entity_type = ?', whereArgs: [entityType]);
    final map = {
      for (final r in rows)
        r['entity_id'] as String: (r['vector'] as String).split(',').map(double.parse).toList(),
    };
    if (entityIds == null) return map;
    final idSet = entityIds.toSet();
    map.removeWhere((key, _) => !idSet.contains(key));
    return map;
  }

  // ---------- Backup / Restore toàn bộ dữ liệu ----------
  // Xuất TOÀN BỘ dữ liệu mọi truyện thành 1 cấu trúc JSON thuần (không xuất
  // API key — API key nằm trong flutter_secure_storage riêng, tách biệt có
  // chủ đích vì lý do bảo mật, người dùng cần nhập lại API key sau khi khôi
  // phục trên máy mới). Dùng JSON thay vì copy thẳng file .db để: (1) không
  // phụ thuộc journal mode/WAL còn dở dang lúc copy, (2) portable — khôi
  // phục được cả khi cấu trúc file nội bộ giữa các bản app hơi khác nhau,
  // vì import chạy qua đúng các hàm upsert bình thường (tự re-index FTS,
  // v.v.) thay vì ghi đè thẳng file nhị phân.
  static const List<String> _backupTables = [
    'novels',
    'characters',
    'world_rules',
    'timeline_events',
    'chapters',
    'chapter_versions',
    'glossary_terms',
    'style_profiles',
    'chat_sessions',
    'chat_messages',
    'imported_documents',
    'document_chunks',
    'local_models',
    'api_providers', // KHÔNG có api_key — chỉ metadata (tên/model/base_url)
    // ĐÃ THÊM: 5 bảng của tính năng "quy trình viết tiểu thuyết" (mục 4.16/
    // 5.77 tài liệu kiến trúc) — trước đây thiếu, khôi phục từ backup cũ sẽ
    // mất outline/tuyến/mục tiêu/quyển dù chương vẫn còn nguyên. 'volumes'
    // đặt TRƯỚC 'chapters' về mặt khái niệm (chapters tham chiếu volume_id)
    // nhưng thứ tự import không quan trọng ở đây vì chapters.volume_id chỉ
    // là chuỗi id, không có ràng buộc khóa ngoại cứng (SQLite không ép FK
    // theo mặc định trong app này) — import theo thứ tự nào cũng an toàn.
    'plot_beats',
    'plot_threads',
    'writing_goals',
    'daily_word_log',
    'volumes',
    'bible_facts', // "chi tiết theo giai đoạn" — xem story_models.dart BibleFact
  ];

  Future<Map<String, dynamic>> exportAllData() async {
    final d = await db;
    final data = <String, dynamic>{};
    for (final table in _backupTables) {
      data[table] = await d.query(table);
    }
    return data;
  }

  // Ghi đè theo id (upsert) — an toàn để chạy nhiều lần, không tạo bản
  // trùng. Chapters cần đồng bộ lại chapters_fts nên đi qua upsertChapter()
  // thay vì insert thẳng bảng chapters.
  Future<void> importAllData(Map<String, dynamic> data) async {
    final d = await db;
    for (final table in _backupTables) {
      final rows = (data[table] as List?)?.cast<Map<String, dynamic>>() ?? [];
      if (table == 'chapters') {
        for (final r in rows) {
          await upsertChapter(Chapter.fromMap(r));
        }
        continue;
      }
      for (final r in rows) {
        await d.insert(table, r, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    }
  }
}
