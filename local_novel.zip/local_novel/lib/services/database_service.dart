import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/story_models.dart';

// Toàn bộ dữ liệu truyện lưu local trên máy (SQLite), không phụ thuộc mạng.
// Đây là "bộ nhớ dài hạn" thay thế cho việc nhồi cả 1000 chương vào context AI.
class DatabaseService {
  static final DatabaseService instance = DatabaseService._internal();
  DatabaseService._internal();
  Database? _db;

  Future<Database> get db async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'local_novel.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE characters(
            id TEXT PRIMARY KEY, name TEXT, role TEXT, description TEXT,
            voice_style TEXT, keywords TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE world_rules(
            id TEXT PRIMARY KEY, title TEXT, content TEXT,
            is_hard_rule INTEGER, keywords TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE timeline_events(
            id TEXT PRIMARY KEY, chapter_number INTEGER, summary TEXT, in_story_date TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chapters(
            id TEXT PRIMARY KEY, number INTEGER, title TEXT, content TEXT,
            auto_summary TEXT, consistency_checked INTEGER,
            consistency_warning TEXT, updated_at TEXT
          )
        ''');
        // FTS ảo để tìm kiếm toàn văn nhanh trong hàng nghìn chương
        await db.execute('''
          CREATE VIRTUAL TABLE chapters_fts USING fts4(
            chapter_id, title, content
          )
        ''');
        await db.execute('''
          CREATE TABLE local_models(
            id TEXT PRIMARY KEY, name TEXT, path TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE api_providers(
            id TEXT PRIMARY KEY, name TEXT, type TEXT, base_url TEXT, model_id TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_sessions(
            id TEXT PRIMARY KEY, name TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_messages(
            id TEXT PRIMARY KEY, session_id TEXT, from_user INTEGER, text TEXT,
            provider_label TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE style_profiles(
            id TEXT PRIMARY KEY, name TEXT, profile_description TEXT, updated_at TEXT
          )
        ''');
        // Vector embedding cho RAG ngữ nghĩa. entity_type: 'character' |
        // 'world_rule' | 'chapter'. vector lưu dạng chuỗi số cách nhau
        // bởi dấu phẩy — đơn giản, đủ dùng cho quy mô vài nghìn entry.
        await db.execute('''
          CREATE TABLE embeddings(
            entity_type TEXT, entity_id TEXT, vector TEXT, updated_at TEXT,
            PRIMARY KEY (entity_type, entity_id)
          )
        ''');
      },
    );
  }

  // ---------- Characters ----------
  Future<void> upsertCharacter(Character c) async {
    final d = await db;
    await d.insert('characters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Character>> allCharacters() async {
    final d = await db;
    final rows = await d.query('characters', orderBy: 'name');
    return rows.map((r) => Character.fromMap(r)).toList();
  }

  // ---------- World rules ----------
  Future<void> upsertWorldRule(WorldRule r) async {
    final d = await db;
    await d.insert('world_rules', r.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<WorldRule>> allWorldRules() async {
    final d = await db;
    final rows = await d.query('world_rules');
    return rows.map((r) => WorldRule.fromMap(r)).toList();
  }

  // ---------- Timeline ----------
  Future<void> upsertTimelineEvent(TimelineEvent e) async {
    final d = await db;
    await d.insert('timeline_events', e.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<TimelineEvent>> allTimelineEvents() async {
    final d = await db;
    final rows = await d.query('timeline_events', orderBy: 'chapter_number');
    return rows.map((r) => TimelineEvent.fromMap(r)).toList();
  }

  // ---------- Chapters ----------
  Future<void> upsertChapter(Chapter c) async {
    final d = await db;
    await d.insert('chapters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    await d.delete('chapters_fts', where: 'chapter_id = ?', whereArgs: [c.id]);
    await d.insert('chapters_fts', {'chapter_id': c.id, 'title': c.title, 'content': c.content});
  }

  Future<List<Chapter>> allChapters({int? limit, int? offset}) async {
    final d = await db;
    final rows = await d.query('chapters', orderBy: 'number DESC', limit: limit, offset: offset);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  Future<List<Chapter>> recentChapters(int count) async {
    final d = await db;
    final rows = await d.query('chapters', orderBy: 'number DESC', limit: count);
    return rows.map((r) => Chapter.fromMap(r)).toList().reversed.toList();
  }

  // Tìm kiếm toàn văn — dùng cho cả thanh search và cho RAG khi cần
  // tra cứu chương cũ có nhắc tới một từ khóa cụ thể.
  Future<List<Chapter>> searchChapters(String query) async {
    final d = await db;
    final ids = await d.rawQuery(
      'SELECT chapter_id FROM chapters_fts WHERE chapters_fts MATCH ?',
      [query],
    );
    if (ids.isEmpty) return [];
    final idList = ids.map((r) => r['chapter_id'] as String).toList();
    final rows = await d.query('chapters',
        where: 'id IN (${List.filled(idList.length, '?').join(',')})', whereArgs: idList);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // Dùng khi xuất file: cần thứ tự tăng dần theo số chương, không phải
  // "mới nhất trước" như danh sách hiển thị trong app.
  Future<List<Chapter>> allChaptersAscending() async {
    final d = await db;
    final rows = await d.query('chapters', orderBy: 'number ASC');
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // ---------- Local models (nhiều model, chọn 1 model active) ----------
  Future<void> upsertLocalModel(LocalModelEntry m) async {
    final d = await db;
    await d.insert('local_models', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<LocalModelEntry>> allLocalModels() async {
    final d = await db;
    final rows = await d.query('local_models', orderBy: 'name');
    return rows.map((r) => LocalModelEntry.fromMap(r)).toList();
  }

  Future<void> deleteLocalModel(String id) async {
    final d = await db;
    await d.delete('local_models', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- API providers (nhiều provider, không hardcode) ----------
  Future<void> upsertApiProvider(ApiProviderEntry p) async {
    final d = await db;
    await d.insert('api_providers', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ApiProviderEntry>> allApiProviders() async {
    final d = await db;
    final rows = await d.query('api_providers', orderBy: 'name');
    return rows.map((r) => ApiProviderEntry.fromMap(r)).toList();
  }

  Future<void> deleteApiProvider(String id) async {
    final d = await db;
    await d.delete('api_providers', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Chat sessions (nhiều cửa sổ chat) ----------
  Future<void> upsertChatSession(ChatSession s) async {
    final d = await db;
    await d.insert('chat_sessions', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatSession>> allChatSessions() async {
    final d = await db;
    final rows = await d.query('chat_sessions', orderBy: 'created_at DESC');
    return rows.map((r) => ChatSession.fromMap(r)).toList();
  }

  Future<void> deleteChatSession(String id) async {
    final d = await db;
    await d.delete('chat_sessions', where: 'id = ?', whereArgs: [id]);
    await d.delete('chat_messages', where: 'session_id = ?', whereArgs: [id]);
  }

  // ---------- Chat messages (bền vững - không mất khi đổi tab/model) ----------
  Future<void> upsertChatMessage(ChatMessageRecord m) async {
    final d = await db;
    await d.insert('chat_messages', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatMessageRecord>> chatMessagesForSession(String sessionId) async {
    final d = await db;
    final rows = await d.query('chat_messages', where: 'session_id = ?', whereArgs: [sessionId], orderBy: 'created_at ASC');
    return rows.map((r) => ChatMessageRecord.fromMap(r)).toList();
  }

  // ---------- Style profiles ----------
  Future<void> upsertStyleProfile(StyleProfile s) async {
    final d = await db;
    await d.insert('style_profiles', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<StyleProfile>> allStyleProfiles() async {
    final d = await db;
    final rows = await d.query('style_profiles', orderBy: 'name');
    return rows.map((r) => StyleProfile.fromMap(r)).toList();
  }

  Future<void> deleteStyleProfile(String id) async {
    final d = await db;
    await d.delete('style_profiles', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Embeddings ----------
  Future<void> upsertEmbedding(String entityType, String entityId, List<double> vector) async {
    final d = await db;
    await d.insert(
      'embeddings',
      {
        'entity_type': entityType,
        'entity_id': entityId,
        'vector': vector.map((v) => v.toStringAsFixed(6)).join(','),
        'updated_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Trả về map entity_id -> vector cho một loại entity, dùng để so sánh
  // cosine similarity với vector của đoạn văn đang viết.
  Future<Map<String, List<double>>> embeddingsFor(String entityType) async {
    final d = await db;
    final rows = await d.query('embeddings', where: 'entity_type = ?', whereArgs: [entityType]);
    return {
      for (final r in rows)
        r['entity_id'] as String: (r['vector'] as String).split(',').map(double.parse).toList(),
    };
  }
}
