import 'package:sqflite/sqflite.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import 'debug_log_service.dart';

// Toàn bộ dữ liệu truyện lưu local trên máy (SQLite), không phụ thuộc mạng.
// Đây là "bộ nhớ dài hạn" thay thế cho việc nhồi cả 1000 chương vào context AI.
//
// Hỗ trợ NHIỀU TRUYỆN (novels): mọi bảng nội dung (characters, world_rules,
// timeline_events, chapters, style_profiles, chat_sessions, chat_messages,
// imported_documents) đều có cột novel_id để tách biệt hoàn toàn dữ liệu
// giữa các truyện khác nhau. local_models/api_providers KHÔNG gắn theo
// novel_id vì đó là tài nguyên máy (model .gguf, API key) dùng chung.
class DatabaseService {
  static final DatabaseService instance = DatabaseService._internal();
  DatabaseService._internal();
  Database? _db;

  static const int schemaVersion = 16;

  Future<Database> get db async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'local_novel.db');
    final database = await openDatabase(
      path,
      version: schemaVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE novels(
            id TEXT PRIMARY KEY, title TEXT, author TEXT, description TEXT,
            created_at TEXT, updated_at TEXT,
            plot_progress_summary TEXT, plot_progress_summary_chapter INTEGER,
            plot_summary_enabled INTEGER, plot_summary_interval INTEGER,
            plot_summary_prefer_timeline INTEGER, plot_summary_prefer_outline INTEGER,
            provider_type TEXT, active_local_model_id TEXT, active_api_provider_id TEXT,
            gen_temperature REAL, gen_top_p REAL, gen_top_k INTEGER,
            gen_repetition_penalty REAL, gen_max_new_tokens INTEGER,
            local_threads INTEGER, local_context INTEGER, local_gpu_layers INTEGER,
            backend_preference INTEGER, rag_context_budget INTEGER,
            translation_enabled INTEGER, translation_model_path TEXT,
            translation_target_language TEXT, translation_style_prompt TEXT,
            translation_prompt_to_target TEXT, translation_prompt_from_target TEXT,
            translation_keep_resident_mode TEXT, max_parallel_remote_tasks INTEGER,
            doc_translate_prompt TEXT, doc_summarize_prompt TEXT, doc_model_choice TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE characters(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, role TEXT, category TEXT, description TEXT,
            voice_style TEXT, keywords TEXT, effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE world_rules(
            id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, content TEXT,
            is_hard_rule INTEGER, category TEXT, keywords TEXT,
            effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE timeline_events(
            id TEXT PRIMARY KEY, novel_id TEXT, chapter_number INTEGER, summary TEXT, in_story_date TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chapters(
            id TEXT PRIMARY KEY, novel_id TEXT, number INTEGER, title TEXT, content TEXT,
            outline TEXT, auto_summary TEXT, consistency_checked INTEGER,
            consistency_warning TEXT, updated_at TEXT,
            thread_ids TEXT, volume_id TEXT, generation_checkpoint TEXT
          )
        ''');
        // FTS ảo để tìm kiếm toàn văn nhanh trong hàng nghìn chương
        await db.execute('''
          CREATE VIRTUAL TABLE chapters_fts USING fts4(
            chapter_id, novel_id, title, content
          )
        ''');
        await db.execute('''
          CREATE TABLE local_models(
            id TEXT PRIMARY KEY, name TEXT, path TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE api_providers(
            id TEXT PRIMARY KEY, name TEXT, type TEXT, base_url TEXT, model_id TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE imported_documents(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, source_path TEXT,
            chunk_count INTEGER, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE document_chunks(
            id TEXT PRIMARY KEY, document_id TEXT, idx INTEGER, original_text TEXT, result_text TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_sessions(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE chat_messages(
            id TEXT PRIMARY KEY, session_id TEXT, from_user INTEGER, text TEXT,
            provider_label TEXT, created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE style_profiles(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, profile_description TEXT,
            effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        // Vector embedding cho RAG ngữ nghĩa. entity_type: 'character' |
        // 'world_rule' | 'chapter'. vector lưu dạng chuỗi số cách nhau
        // bởi dấu phẩy — đơn giản, đủ dùng cho quy mô vài nghìn entry.
        await db.execute('''
          CREATE TABLE embeddings(
            entity_type TEXT, entity_id TEXT, vector TEXT, updated_at TEXT,
            PRIMARY KEY (entity_type, entity_id)
          )
        ''');
        // Version snapshot — bản nháp cũ của chương, chụp trước khi bị ghi
        // đè (AI viết tiếp/đắp thịt/rewrite hoặc lưu tay), cho phép undo.
        await db.execute('''
          CREATE TABLE chapter_versions(
            id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT, title TEXT,
            content TEXT, label TEXT, created_at TEXT
          )
        ''');
        // Bảng thuật ngữ riêng của truyện — tra cứu nhanh, không tham gia
        // lorebook tự động nạp prompt (khác Character/WorldRule).
        await db.execute('''
          CREATE TABLE glossary_terms(
            id TEXT PRIMARY KEY, novel_id TEXT, term TEXT, definition TEXT,
            category TEXT, effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE pending_rewrites(
            id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT,
            original_text TEXT, note TEXT, status TEXT,
            result_text TEXT, created_at TEXT
          )
        ''');
        // MỚI (v5): dàn ý toàn truyện + tuyến truyện/subplot + mục tiêu viết —
        // xem PlotBeat/PlotThread/WritingGoal trong story_models.dart.
        // ĐÃ SỬA (v10): thêm sẵn 4 cột "Phạm vi hiệu lực" ngay trong DDL gốc
        // (effective_from/to_chapter + effective_from/to_volume_id) — RÚT
        // KINH NGHIỆM từ lỗi y hệt từng xảy ra ở bảng `chapters` (cột
        // thread_ids/volume_id chỉ thêm qua ALTER TABLE trong migration,
        // khiến người CÀI APP MỚI HOÀN TOÀN thiếu cột, mọi lần lưu đều lỗi
        // âm thầm) — giờ thêm thẳng vào đây để onCreate và migration LUÔN
        // cho ra cùng 1 schema, không lệch nhau giữa 2 đường tạo DB.
        await db.execute('''
          CREATE TABLE plot_beats(
            id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
            beat_type TEXT, order_index INTEGER, linked_chapter_number INTEGER,
            status TEXT, updated_at TEXT,
            effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE plot_threads(
            id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, description TEXT,
            color_value INTEGER, status TEXT, effective_from_chapter INTEGER,
            effective_to_chapter INTEGER, effective_from_volume_id TEXT,
            effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE writing_goals(
            novel_id TEXT PRIMARY KEY, daily_target_words INTEGER, updated_at TEXT
          )
        ''');
        // Ảnh chụp tổng số chữ của 1 truyện tại 1 ngày cụ thể — hiệu số
        // giữa 2 ngày liền kề = số chữ đã viết trong ngày đó. Không lưu
        // trực tiếp "số chữ viết trong ngày" vì phải cộng dồn đúng mọi
        // lượt lưu chương trong ngày (có thể sửa đi sửa lại nhiều lần) —
        // snapshot tổng rồi tính hiệu số ở tầng đọc đơn giản và chính xác
        // hơn cộng dồn từng delta.
        await db.execute('''
          CREATE TABLE daily_word_log(
            novel_id TEXT, date TEXT, total_words INTEGER,
            PRIMARY KEY (novel_id, date)
          )
        ''');
        // ĐÃ SỬA: 2 cột `thread_ids` (v5) và `volume_id` (v6) trước đây CHỈ
        // được thêm qua ALTER TABLE trong onUpgrade — người cài app MỚI
        // HOÀN TOÀN (DB tạo thẳng ở version hiện tại qua onCreate, không
        // đi qua onUpgrade) không hề có 2 cột này, trong khi Chapter.toMap()
        // luôn ghi cả 2 field đó xuống DB. Hậu quả: MỌI lần insert/update
        // chương (kể cả bấm nút "+" tạo chương) đều ném lỗi "no column
        // named thread_ids/volume_id" ở tầng sqflite — lỗi này KHÔNG được
        // bắt ở nơi gọi (`_newChapter()` trong chapters_screen.dart không
        // có try/catch), Future lỗi rơi âm thầm, người dùng thấy y hệt như
        // bấm nút mà không có gì xảy ra. Đã thêm cả 2 cột thẳng vào DDL
        // gốc để bảng luôn khớp với model ngay từ lúc tạo DB.
        //
        // MỚI (v6): tầng "Quyển/Hồi" nhóm nhiều chương — xem Volume trong
        // story_models.dart. Chapter.number KHÔNG đổi cách đánh số (vẫn liên
        // tục xuyên suốt truyện), volume chỉ là nhãn gom nhóm hiển thị.
        await db.execute('''
          CREATE TABLE volumes(
            id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
            order_index INTEGER, updated_at TEXT
          )
        ''');
        // MỚI (v9): "chi tiết theo giai đoạn" (BibleFact) — 1 bảng DÙNG
        // CHUNG cho cả 5 loại Bible, mỗi entry có thể có NHIỀU chi tiết,
        // MỖI chi tiết 1 phạm vi hiệu lực RIÊNG (tách biệt khỏi phạm vi
        // của entry cha) — xem story_models.dart.
        await db.execute('''
          CREATE TABLE bible_facts(
            id TEXT PRIMARY KEY, novel_id TEXT, parent_type TEXT, parent_id TEXT,
            fact_text TEXT, order_index INTEGER,
            effective_from_chapter INTEGER, effective_to_chapter INTEGER,
            effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        // ĐÃ THÊM (mục AD, 2026-09-10) — xem giải thích đầy đủ ở `main.dart`:
        // ghi rõ oldVersion/newVersion THẬT mỗi lần mở DB sau khi cài bản
        // mới, để xác nhận CHẮC CHẮN qua log xem `onUpgrade` (và từng
        // migration bên trong, đặc biệt `_migrateToV16`) có thực sự chạy
        // hay không — không suy đoán nữa.
        await DebugLogService.instance
            .log('DatabaseService.onUpgrade: oldVersion=$oldVersion -> newVersion=$newVersion');
        if (oldVersion < 2) {
          await _migrateToMultiNovel(db);
        }
        if (oldVersion < 3) {
          await _migrateToV3(db);
        }
        if (oldVersion < 4) {
          await _migrateToV4(db);
        }
        if (oldVersion < 5) {
          await _migrateToV5(db);
        }
        if (oldVersion < 6) {
          await _migrateToV6(db);
        }
        if (oldVersion < 7) {
          await _migrateToV7(db);
        }
        if (oldVersion < 8) {
          await _migrateToV8(db);
        }
        if (oldVersion < 9) {
          await _migrateToV9(db);
        }
        if (oldVersion < 10) {
          await _migrateToV10(db);
        }
        if (oldVersion < 11) {
          await _migrateToV11(db);
        }
        if (oldVersion < 12) {
          await _migrateToV12(db);
        }
        if (oldVersion < 13) {
          await _migrateToV13(db);
        }
        if (oldVersion < 14) {
          await _migrateToV14(db);
        }
        if (oldVersion < 15) {
          await _migrateToV15(db);
        }
        if (oldVersion < 16) {
          await _migrateToV16(db);
        }
        await DebugLogService.instance.log('DatabaseService.onUpgrade: xong, khong crash');
      },
    );
    // ĐÃ THÊM (2026-09-11, tiếp nối mục AD — theo yêu cầu người dùng: log
    // thật ngày 2026-09-10 vẫn cho thấy repetition_penalty:1.05 dù build đã
    // có `_migrateToV16` bên trên): `_migrateToV16` chỉ chạy ĐÚNG 1 LẦN bên
    // trong `onUpgrade`, và CHỈ khi `oldVersion < 16` — nếu máy này đã lên
    // v16 từ một phiên TRƯỚC (onUpgrade không chạy lại nữa ở các lần mở sau,
    // đây là hành vi bình thường của sqflite), thì dù dòng 1.05 vẫn còn kẹt
    // (vd do lệch dấu phẩy động khiến WHERE so khớp tuyệt đối của
    // `_migrateToV16` bỏ sót — xem giải thích đầy đủ ở
    // `_selfHealStuckRepetitionPenalty`), sẽ KHÔNG CÒN CƠ HỘI nào tự sửa lại
    // nữa. Gọi lại đúng phép dọn dẹp đó ở ĐÂY — MỖI LẦN mở app (không chỉ
    // lúc nâng schema) — biến nó thành 1 bước "tự chữa lành" thường trực. An
    // toàn để gọi lặp lại vô hạn lần: chỉ đụng dòng còn giá trị legacy, và
    // dùng ngưỡng sai số thay vì so khớp tuyệt đối `=` như bản `_migrateToV16`
    // cũ (phòng đúng khả năng chính sự lệch dấu phẩy động là lý do bỏ sót).
    await _selfHealStuckRepetitionPenalty(database, trigger: 'moi-lan-mo-app');
    return database;
  }

  // Xem giải thích đầy đủ ở lời gọi trong `_initDb()` và ở `_migrateToV16`
  // phía dưới. Idempotent — gọi bao nhiêu lần cũng an toàn, chỉ nâng đúng
  // những dòng còn giá trị "di sản" ~1.05, không đụng tới lựa chọn tự chỉnh
  // của người dùng (kể cả khi họ tự chỉnh về đúng 1.05 — xem ngưỡng hẹp
  // 0.001, đủ nhỏ để không bao giờ nuốt nhầm 1 lựa chọn tự chỉnh thật, đủ
  // rộng để bắt được sai số dấu phẩy động điển hình).
  Future<void> _selfHealStuckRepetitionPenalty(Database db, {required String trigger}) async {
    final affected = await db.update(
      'novels',
      {'gen_repetition_penalty': 1.15},
      where: 'gen_repetition_penalty IS NOT NULL AND ABS(gen_repetition_penalty - 1.05) < 0.001',
    );
    await DebugLogService.instance
        .log('DatabaseService._selfHealStuckRepetitionPenalty (trigger=$trigger): da nang $affected novel tu ~1.05 len 1.15');
    // ĐÃ THÊM (mục AG, 2026-09-11 — sau khi mục AF KHÔNG giải quyết được,
    // log 11:44-11:45 cùng ngày lặp lại y hệt kịch bản mục AE dù đã vá cả
    // `renameNovel`/Data Integrity): rà tĩnh (đọc code) đã hết cách — cần
    // NHÌN THẲNG dữ liệu thật, không suy luận thêm. Ghi lại NGUYÊN VẸN giá
    // trị `gen_repetition_penalty` của TỪNG novel NGAY SAU self-heal — nếu
    // lần sau giá trị SAI xuất hiện, so 2 dòng log này (đây vs
    // `loadGenerationConfig` ở đúng novelId đó) sẽ biết CHẮC CHẮN giá trị
    // sai đã có ngay từ lúc mở app (self-heal bỏ sót thật) hay xuất hiện
    // SAU đó (bị ghi đè bởi 1 thao tác nào đó) — không cần đoán nữa.
    final rows = await db.query('novels', columns: ['id', 'gen_repetition_penalty', 'title']);
    final dump = rows.map((r) => '${r['id']}=${r['gen_repetition_penalty']}(${r['title']})').join(', ');
    await DebugLogService.instance
        .log('DatabaseService._selfHealStuckRepetitionPenalty (trigger=$trigger): DUMP NGAY SAU khi sua: $dump');
  }

  // ĐÃ THÊM (mục AG, 2026-09-11): log MỌI lần cột `gen_repetition_penalty`
  // có khả năng bị ghi — không chỉ đoán call site nào là thủ phạm nữa, mà
  // để CHÍNH LOG TỰ NÓI. `origin` là tên hàm gọi (tự truyền tay, Dart
  // không có cách lấy tên hàm gọi trực tiếp rẻ mà đáng tin cậy trên mọi
  // nền tảng) — mỗi nơi có khả năng ghi cột này (`upsertNovel`,
  // `updateNovelSettings` khi field có mặt, `importNovelData`/
  // `importAllData` khi bảng là `novels`) đều phải gọi hàm này TRƯỚC khi
  // ghi thật — xem từng lời gọi cụ thể ở đúng hàm đó.
  Future<void> _logRepetitionPenaltyWrite(String origin, String? novelId, dynamic newValue) async {
    await DebugLogService.instance
        .log('DatabaseService [GHI gen_repetition_penalty] origin=$origin novelId=$novelId newValue=$newValue');
  }

  // Migration v3 -> v4: thêm cột "outline" (dàn ý/định hướng chương, cho
  // phép viết "chương mồi" trước, tạo hàng loạt sau — xem
  // ChaptersBatchGenerateScreen) và bảng pending_rewrites (ghi chú chờ xử
  // lý khi bôi đen sửa — xem PendingRewrite trong story_models.dart).
  Future<void> _migrateToV4(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'outline', 'TEXT');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS pending_rewrites(
        id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT,
        original_text TEXT, note TEXT, status TEXT,
        result_text TEXT, created_at TEXT
      )
    ''');
  }

  // Migration v4 -> v5: dàn ý toàn truyện (plot_beats) + tuyến truyện/subplot
  // (plot_threads, cột thread_ids trong chapters) + mục tiêu viết hàng ngày
  // (writing_goals, daily_word_log) — xem PlotBeat/PlotThread/WritingGoal
  // trong story_models.dart. Toàn bộ CREATE TABLE IF NOT EXISTS/ADD COLUMN,
  // không đụng tới dữ liệu cũ.
  Future<void> _migrateToV5(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'thread_ids', 'TEXT');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS plot_beats(
        id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
        beat_type TEXT, order_index INTEGER, linked_chapter_number INTEGER,
        status TEXT, updated_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS plot_threads(
        id TEXT PRIMARY KEY, novel_id TEXT, name TEXT, description TEXT,
        color_value INTEGER, status TEXT, updated_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS writing_goals(
        novel_id TEXT PRIMARY KEY, daily_target_words INTEGER, updated_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS daily_word_log(
        novel_id TEXT, date TEXT, total_words INTEGER,
        PRIMARY KEY (novel_id, date)
      )
    ''');
  }

  // Migration v5 -> v6: tầng "Quyển/Hồi" (Volume) nhóm nhiều chương —
  // xem Volume trong story_models.dart. ADD COLUMN/CREATE TABLE IF NOT
  // EXISTS — không đụng dữ liệu cũ, Chapter.number giữ nguyên cách đánh
  // số liên tục xuyên suốt truyện.
  Future<void> _migrateToV6(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'volume_id', 'TEXT');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS volumes(
        id TEXT PRIMARY KEY, novel_id TEXT, title TEXT, description TEXT,
        order_index INTEGER, updated_at TEXT
      )
    ''');
  }

  // Migration v6 -> v7: "phạm vi hiệu lực theo số chương" (effective_from_
  // chapter/effective_to_chapter) cho 5 bảng: characters, world_rules,
  // style_profiles, glossary_terms, plot_threads — xem story_models.dart
  // và rag_service.dart (_isInScope). Toàn bộ ADD COLUMN, mặc định NULL =
  // luôn có hiệu lực, không đụng dữ liệu cũ, không đổi hành vi hiện có.
  Future<void> _migrateToV7(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    for (final table in ['characters', 'world_rules', 'style_profiles', 'glossary_terms', 'plot_threads']) {
      await addColumnIfMissing(table, 'effective_from_chapter', 'INTEGER');
      await addColumnIfMissing(table, 'effective_to_chapter', 'INTEGER');
    }
  }

  // Migration v7 -> v8: thêm phạm vi hiệu lực THEO QUYỂN/HỒI (bên cạnh
  // theo số chương đã có ở v7) — xem story_models.dart. Cho phép người
  // dùng chọn "áp dụng trong Quyển 2" mà KHÔNG cần biết trước quyển đó
  // kết thúc ở chương bao nhiêu (tự dò lại khi dùng, xem
  // volumeChapterRanges() bên dưới) — đúng yêu cầu người dùng: không ép
  // chọn cứng giữa "theo chương" hay "theo quyển", linh hoạt cả 2.
  Future<void> _migrateToV8(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    for (final table in ['characters', 'world_rules', 'style_profiles', 'glossary_terms', 'plot_threads']) {
      await addColumnIfMissing(table, 'effective_from_volume_id', 'TEXT');
      await addColumnIfMissing(table, 'effective_to_volume_id', 'TEXT');
    }
  }

  // Migration v8 -> v9: "chi tiết theo giai đoạn" (BibleFact) — 1 bảng
  // dùng chung cho cả 5 loại Bible, mỗi entry có nhiều chi tiết, mỗi chi
  // tiết 1 phạm vi hiệu lực riêng — xem story_models.dart. CREATE TABLE
  // IF NOT EXISTS — không đụng dữ liệu cũ.
  Future<void> _migrateToV9(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS bible_facts(
        id TEXT PRIMARY KEY, novel_id TEXT, parent_type TEXT, parent_id TEXT,
        fact_text TEXT, order_index INTEGER,
        effective_from_chapter INTEGER, effective_to_chapter INTEGER,
        effective_from_volume_id TEXT, effective_to_volume_id TEXT, updated_at TEXT
      )
    ''');
  }

  // Migration v9 -> v10: thêm "Phạm vi hiệu lực" cho Dàn ý (PlotBeat) —
  // theo báo cáo người dùng "cái dàn ý thì không thấy chỗ điều chỉnh phạm
  // vi". 4 cột này đã có ở characters/world_rules/style_profiles/
  // glossary_terms/plot_threads từ v8, nhưng plot_beats bị BỎ SÓT — dùng
  // đúng 4 cột cùng tên để tái sử dụng nguyên vẹn `_pickScope()`/
  // `_scopeSummary()`/`RagService._resolveScope()` đã có sẵn, không cần
  // viết logic phạm vi riêng cho beat.
  Future<void> _migrateToV10(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('plot_beats', 'effective_from_chapter', 'INTEGER');
    await addColumnIfMissing('plot_beats', 'effective_to_chapter', 'INTEGER');
    await addColumnIfMissing('plot_beats', 'effective_from_volume_id', 'TEXT');
    await addColumnIfMissing('plot_beats', 'effective_to_volume_id', 'TEXT');
  }

  // Migration v10 -> v11: "checkpoint" cho việc sinh chương bằng AI — theo
  // yêu cầu người dùng: "gãy cấp độ chương [khi GPU remote sập giữa chừng],
  // cần cách để streaming... dẫn đến khi sập ở 99% thì không cần chạy lại
  // từ đầu chương". Cột này lưu phần văn bản THÔ (chưa dịch, nếu đang bật
  // dịch thuật trung gian) mà model đã sinh được TÍNH TỚI LẦN CHECKPOINT
  // GẦN NHẤT — không phải nội dung chương thật (cột `content`), chỉ là
  // "trạng thái dở dang" để lần chạy sau nối tiếp thay vì viết lại từ đầu.
  // Xem ChapterBatchService/TranslationService.generateResumableWithOptionalTranslation.
  Future<void> _migrateToV11(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('chapters', 'generation_checkpoint', 'TEXT');
  }

  // Migration v11 -> v12: "Cốt truyện đã diễn ra" — bản tóm tắt luỹ kế do
  // AI tự cập nhật sau mỗi chương, giải quyết vấn đề "chương 1000 không
  // biết chuyện chương 1" mà truy xuất ngữ nghĩa (top-K) không đảm bảo
  // được với truyện quá dài. Xem giải thích đầy đủ ở Novel/RagService.
  Future<void> _migrateToV12(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('novels', 'plot_progress_summary', 'TEXT');
    await addColumnIfMissing('novels', 'plot_progress_summary_chapter', 'INTEGER');
  }

  // Migration v12 -> v13: chuyển 2 cài đặt "Tự tóm tắt cốt truyện luỹ kế"
  // (bật/tắt + giãn cách N chương) từ SharedPreferences (chung TOÀN APP)
  // thành cột RIÊNG của từng truyện trong bảng `novels` — theo yêu cầu
  // người dùng ("cài đặt riêng từng truyện hay chung cả app"), vì chiến
  // lược đồng bộ hợp lý cho 1 truyện có thể không hợp với truyện khác.
  // Thêm luôn 2 cột MỚI (chưa từng có ở SharedPreferences vì tính năng
  // này mới hoàn toàn): `plot_summary_prefer_timeline`/`..._prefer_outline`
  // — bật ưu tiên dùng Timeline event/outline đã có sẵn làm nguyên liệu
  // rẻ hơn thay vì luôn đọc lại nội dung chương đầy đủ (xem RagService).
  //
  // GIỮ NGUYÊN CẢM NHẬN NGƯỜI DÙNG CŨ: đọc lại 2 giá trị SharedPreferences
  // cũ (nếu có) MỘT LẦN DUY NHẤT tại đây và sao chép làm giá trị khởi tạo
  // cho MỌI truyện đang có — vì cài đặt cũ vốn áp dụng chung cho toàn bộ
  // truyện nên đây là điểm khởi đầu đúng nhất, không phải đoán mò. 2 cột
  // mới (prefer_timeline/prefer_outline) không có giá trị cũ tương ứng —
  // mặc định bật (true), vì đây là tối ưu "chỉ tận dụng nếu dữ liệu đã có
  // sẵn", không có rủi ro chạy sai nếu Timeline/outline đang trống.
  Future<void> _migrateToV13(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('novels', 'plot_summary_enabled', 'INTEGER');
    await addColumnIfMissing('novels', 'plot_summary_interval', 'INTEGER');
    await addColumnIfMissing('novels', 'plot_summary_prefer_timeline', 'INTEGER');
    await addColumnIfMissing('novels', 'plot_summary_prefer_outline', 'INTEGER');

    int enabledValue = 1;
    int intervalValue = 1;
    try {
      final prefs = await SharedPreferences.getInstance();
      enabledValue = (prefs.getBool('plot_summary_enabled') ?? true) ? 1 : 0;
      intervalValue = prefs.getInt('plot_summary_interval') ?? 1;
    } catch (_) {
      // Không đọc được SharedPreferences (không nên xảy ra) — vẫn tiếp
      // tục với mặc định an toàn (bật, giãn cách 1) thay vì làm hỏng cả
      // migration vì 1 bước không bắt buộc.
    }

    await db.update('novels', {
      'plot_summary_enabled': enabledValue,
      'plot_summary_interval': intervalValue,
      'plot_summary_prefer_timeline': 1,
      'plot_summary_prefer_outline': 1,
    });
  }

  // Migration v13 -> v14: theo yêu cầu người dùng ("cài đặt thì áp dụng
  // cho quyển truyện chứ không phải cho toàn app... không thể đánh đồng
  // chung được") — chuyển tiếp 2 NHÓM cài đặt CÒN LẠI (từng bị coi nhầm là
  // "tài nguyên máy nên dùng chung", xem story_models.dart) từ
  // SharedPreferences sang cột riêng của bảng `novels`, CÙNG CÁCH LÀM đã
  // dùng cho v13 (đọc SharedPreferences CŨ 1 LẦN, sao chép làm giá trị
  // khởi tạo cho MỌI truyện đã có, giữ nguyên cảm nhận người dùng cũ):
  //   1. Provider/model đang chọn (`provider_type`, `active_local_model_id`,
  //      `active_api_provider_id`).
  //   2. 5 tham số sinh văn bản (`gen_temperature`...`gen_max_new_tokens`).
  // Bảng `local_models`/`api_providers` (danh sách THẬT các model/provider
  // đã cấu hình) VẪN dùng chung toàn app — chỉ CON TRỎ "truyện này đang
  // chọn cái nào trong danh sách đó" mới tách riêng. Điều này có nghĩa: 2
  // truyện có thể cùng trỏ tới 1 model local/API provider trong danh sách,
  // hoặc mỗi truyện trỏ tới 1 cái khác nhau — độc lập hoàn toàn.
  Future<void> _migrateToV14(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('novels', 'provider_type', 'TEXT');
    await addColumnIfMissing('novels', 'active_local_model_id', 'TEXT');
    await addColumnIfMissing('novels', 'active_api_provider_id', 'TEXT');
    await addColumnIfMissing('novels', 'gen_temperature', 'REAL');
    await addColumnIfMissing('novels', 'gen_top_p', 'REAL');
    await addColumnIfMissing('novels', 'gen_top_k', 'INTEGER');
    await addColumnIfMissing('novels', 'gen_repetition_penalty', 'REAL');
    await addColumnIfMissing('novels', 'gen_max_new_tokens', 'INTEGER');

    String? providerType;
    String? activeLocalModelId;
    String? activeApiProviderId;
    double genTemperature = 0.8;
    double genTopP = 0.9;
    int genTopK = 40;
    double genRepetitionPenalty = 1.05;
    int genMaxNewTokens = 1024;
    try {
      final prefs = await SharedPreferences.getInstance();
      providerType = prefs.getString('provider_type');
      activeLocalModelId = prefs.getString('active_local_model_id');
      activeApiProviderId = prefs.getString('active_api_provider_id');
      genTemperature = prefs.getDouble('gen_temperature') ?? 0.8;
      genTopP = prefs.getDouble('gen_top_p') ?? 0.9;
      genTopK = prefs.getInt('gen_top_k') ?? 40;
      genRepetitionPenalty = prefs.getDouble('gen_repetition_penalty') ?? 1.05;
      genMaxNewTokens = prefs.getInt('gen_max_new_tokens') ?? 1024;
    } catch (_) {
      // Không đọc được SharedPreferences — vẫn tiếp tục với mặc định an
      // toàn, không làm hỏng cả migration vì 1 bước không bắt buộc.
    }

    await db.update('novels', {
      'provider_type': providerType,
      'active_local_model_id': activeLocalModelId,
      'active_api_provider_id': activeApiProviderId,
      'gen_temperature': genTemperature,
      'gen_top_p': genTopP,
      'gen_top_k': genTopK,
      'gen_repetition_penalty': genRepetitionPenalty,
      'gen_max_new_tokens': genMaxNewTokens,
    });
  }

  // Migration v14 -> v15: theo yêu cầu người dùng ("tất cả [cài đặt còn
  // lại], kể cả threads/gpu layers/backend thuần phần cứng" cũng tách
  // riêng theo truyện) — chuyển NỐT toàn bộ cài đặt CÒN LẠI đang ở
  // SharedPreferences sang cột riêng của `novels`, CÙNG CÁCH LÀM v13/v14
  // (đọc SharedPreferences CŨ 1 LẦN, sao chép cho MỌI truyện đã có).
  // GHI CHÚ THẬT (đã cảnh báo người dùng trước khi làm, người dùng đã xác
  // nhận chấp nhận đánh đổi): `local_threads`/`local_context`/
  // `local_gpu_layers`/`backend_preference` vốn là cấu hình PHẦN CỨNG máy,
  // không phải nội dung truyện — tách riêng theo truyện nghĩa là ĐỔI
  // TRUYỆN có thể kéo theo NẠP LẠI model nếu 2 truyện có cấu hình khác
  // nhau (tốn thời gian hơn so với chỉ đổi con trỏ model đang chọn).
  Future<void> _migrateToV15(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('novels', 'local_threads', 'INTEGER');
    await addColumnIfMissing('novels', 'local_context', 'INTEGER');
    await addColumnIfMissing('novels', 'local_gpu_layers', 'INTEGER');
    await addColumnIfMissing('novels', 'backend_preference', 'INTEGER');
    await addColumnIfMissing('novels', 'rag_context_budget', 'INTEGER');
    await addColumnIfMissing('novels', 'translation_enabled', 'INTEGER');
    await addColumnIfMissing('novels', 'translation_model_path', 'TEXT');
    await addColumnIfMissing('novels', 'translation_target_language', 'TEXT');
    await addColumnIfMissing('novels', 'translation_style_prompt', 'TEXT');
    await addColumnIfMissing('novels', 'translation_prompt_to_target', 'TEXT');
    await addColumnIfMissing('novels', 'translation_prompt_from_target', 'TEXT');
    await addColumnIfMissing('novels', 'translation_keep_resident_mode', 'TEXT');
    await addColumnIfMissing('novels', 'max_parallel_remote_tasks', 'INTEGER');
    await addColumnIfMissing('novels', 'doc_translate_prompt', 'TEXT');
    await addColumnIfMissing('novels', 'doc_summarize_prompt', 'TEXT');
    await addColumnIfMissing('novels', 'doc_model_choice', 'TEXT');

    final values = <String, dynamic>{};
    try {
      final prefs = await SharedPreferences.getInstance();
      values['local_threads'] = prefs.getInt('local_threads') ?? 4;
      values['local_context'] = prefs.getInt('local_context') ?? 2048;
      values['local_gpu_layers'] = prefs.getInt('local_gpu_layers') ?? 99;
      values['backend_preference'] = prefs.getInt('backend_preference') ?? 0;
      values['rag_context_budget'] = prefs.getInt('rag_context_budget') ?? 3500;
      values['translation_enabled'] = (prefs.getBool('translation_enabled') ?? false) ? 1 : 0;
      values['translation_model_path'] = prefs.getString('translation_model_path');
      values['translation_target_language'] = prefs.getString('translation_target_language') ?? 'tiếng Anh';
      values['translation_style_prompt'] = prefs.getString('translation_style_prompt') ??
          'Giữ đúng văn phong tiểu thuyết, tự nhiên, không dịch máy móc từng chữ.';
      values['translation_prompt_to_target'] = prefs.getString('translation_prompt_to_target') ??
          'Dịch đoạn văn bản tiếng Việt sau sang {targetLanguage}. '
              'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.';
      values['translation_prompt_from_target'] = prefs.getString('translation_prompt_from_target') ??
          'Dịch đoạn văn bản {targetLanguage} sau sang tiếng Việt tự nhiên, đúng văn phong tiểu thuyết. '
              'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.';
      values['translation_keep_resident_mode'] = prefs.getString('translation_keep_resident_mode') ?? 'auto';
      values['max_parallel_remote_tasks'] = prefs.getInt('max_parallel_remote_tasks') ?? 2;
      values['doc_translate_prompt'] = prefs.getString('doc_translate_prompt') ??
          'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.';
      values['doc_summarize_prompt'] =
          prefs.getString('doc_summarize_prompt') ?? 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.';
      values['doc_model_choice'] = prefs.getString('doc_model_choice') ?? 'active';
    } catch (_) {
      // Không đọc được SharedPreferences — bỏ qua bước sao chép giá trị
      // cũ, mỗi truyện sẽ dùng mặc định của `Novel.fromMap` (an toàn,
      // không làm hỏng migration vì 1 bước không bắt buộc).
      return;
    }

    await db.update('novels', values);
  }

  // Migration v15 -> v16: sửa TẬN GỐC bug lặp vô tận đã lặp lại NHIỀU LẦN
  // (khung chat từ phiên 13-15, rồi lại đúng y lỗi này ở "Đắp thịt"/"Viết
  // tiếp" ngày 2026-09-08/09/10 — xem mục AA/AB tài liệu kiến trúc) —
  // nguyên nhân THẬT không phải code sinh chương, mà chính LÀ
  // `_migrateToV14` ở TRÊN: dòng 574 `double genRepetitionPenalty = 1.05;`
  // (giá trị mặc định CŨ, trước khi phiên 13 phát hiện 1.05 gây lặp vô
  // tận và nâng mặc định lên 1.15 ở `settings_service.dart`) đã ghi CỨNG
  // 1.05 vào cột `gen_repetition_penalty` của MỌI truyện đã tồn tại tại
  // thời điểm lên schema v14 — không có ngoại lệ, không WHERE gì cả (xem
  // `db.update('novels', {...})` không điều kiện ở dòng 591-600). Từ đó,
  // `loadGenerationConfig()`'s `novel?.genRepetitionPenalty ?? 1.15` KHÔNG
  // BAO GIỜ rơi vào nhánh `?? 1.15` cho các truyện đó nữa — cột đã có giá
  // trị THẬT (1.05, không NULL), mặc định mới ở tầng code không có cách
  // nào chạm tới được. Đây là lý do bug "cứ tưởng đã sửa (đổi mặc định
  // code) mà log vẫn ra 1.05" tái diễn ít nhất 3 lần độc lập (phiên 14
  // 2026-08-25, mục AA 2026-09-09, và vẫn còn nguyên ở log 2026-09-10) —
  // mỗi lần đều bị chẩn đoán ĐÚNG nhưng chỉ dừng ở mức "gợi ý người dùng
  // tự vào Cài đặt sửa tay", không có ai từng thực sự đi sửa ĐÚNG chỗ ghi
  // đè này.
  //
  // Sửa: chỉ nâng CHÍNH XÁC những dòng còn giữ đúng giá trị CŨ `1.05` (SQL
  // so sánh dấu phẩy động — SQLite lưu REAL theo IEEE754, `1.05` được ghi
  // bằng đúng 1 lệnh Dart double literal ở cả 2 nơi (migration này và
  // `_migrateToV14`) nên so khớp chính xác, không lo sai số làm trôi giá
  // trị) lên `1.15` — KHÔNG đụng tới truyện nào người dùng đã tự chỉnh
  // sang giá trị KHÁC 1.05 (0.95/1.2/1.3...), dù cao hay thấp hơn — tôn
  // trọng lựa chọn đã có của người dùng, chỉ dọn đúng phần "di sản" do
  // chính migration cũ để lại.
  Future<void> _migrateToV16(Database db) async {
    // ĐÃ SỬA (2026-09-11): bản gốc so khớp TUYỆT ĐỐI (`= 1.05`) — log thật
    // ngày 2026-09-10 (SAU KHI build này đã có migration này) vẫn cho thấy
    // repetition_penalty:1.05, tức là ít nhất 1 trong 2 khả năng đã xảy ra:
    // (a) `onUpgrade` chưa từng chạy tới migration này trên máy đó (schema
    // đã ở v16 từ trước vì lý do khác), hoặc (b) dòng bị kẹt không còn
    // ĐÚNG BIT `1.05` nữa (vd lệch dấu phẩy động do đi qua Slider ở
    // `generation_settings_screen.dart`) nên `WHERE = 1.05` bỏ sót. Logic
    // thật (so khớp ngưỡng sai số, IDEMPOTENT) giờ nằm ở
    // `_selfHealStuckRepetitionPenalty` — gọi lại được AN TOÀN mỗi lần mở
    // app (xem `_initDb()`), không chỉ đúng 1 lần lúc nâng schema như hàm
    // này — nên xử lý được cả (a) lẫn (b), không chỉ dựa vào đúng 1 lần
    // chạy onUpgrade nữa. Giữ lại lời gọi ở đây (đường onUpgrade) chỉ để
    // người dùng nâng cấp từ bản CŨ vẫn thấy dòng log quen thuộc ngay lúc
    // nâng schema, không đợi tới lần tự-chữa-lành kế tiếp.
    await _selfHealStuckRepetitionPenalty(db, trigger: 'onUpgrade-v16');
  }

  // Migration v2 -> v3: thêm "phân loại thẻ chi tiết" (category) cho
  // characters/world_rules, thêm bảng version snapshot (chapter_versions)
  // và bảng thuật ngữ (glossary_terms). Toàn bộ đều là ADD COLUMN/CREATE
  // TABLE IF NOT EXISTS — không đụng tới dữ liệu cũ.
  Future<void> _migrateToV3(Database db) async {
    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('characters', 'category', 'TEXT');
    await addColumnIfMissing('world_rules', 'category', 'TEXT');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS chapter_versions(
        id TEXT PRIMARY KEY, chapter_id TEXT, novel_id TEXT, title TEXT,
        content TEXT, label TEXT, created_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS glossary_terms(
        id TEXT PRIMARY KEY, novel_id TEXT, term TEXT, definition TEXT,
        category TEXT, updated_at TEXT
      )
    ''');
  }

  // Migration v1 -> v2: thêm khái niệm "nhiều truyện". Máy đã cài bản cũ
  // (chỉ 1 truyện, không có cột novel_id) sẽ được tự động gom toàn bộ dữ
  // liệu sẵn có vào một truyện mặc định "Truyện của tôi" — không mất dữ
  // liệu người dùng đã viết trước khi cập nhật.
  Future<void> _migrateToMultiNovel(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS novels(
        id TEXT PRIMARY KEY, title TEXT, author TEXT, description TEXT,
        created_at TEXT, updated_at TEXT
      )
    ''');

    Future<void> addColumnIfMissing(String table, String column, String type) async {
      final info = await db.rawQuery('PRAGMA table_info($table)');
      final exists = info.any((c) => c['name'] == column);
      if (!exists) {
        await db.execute('ALTER TABLE $table ADD COLUMN $column $type');
      }
    }

    await addColumnIfMissing('characters', 'novel_id', 'TEXT');
    await addColumnIfMissing('world_rules', 'novel_id', 'TEXT');
    await addColumnIfMissing('timeline_events', 'novel_id', 'TEXT');
    await addColumnIfMissing('chapters', 'novel_id', 'TEXT');
    await addColumnIfMissing('style_profiles', 'novel_id', 'TEXT');
    await addColumnIfMissing('chat_sessions', 'novel_id', 'TEXT');
    await addColumnIfMissing('imported_documents', 'novel_id', 'TEXT');

    // chapters_fts (fts4) không hỗ trợ ALTER TABLE ADD COLUMN — dựng lại
    // từ dữ liệu chapters hiện có, kèm cột novel_id.
    final ftsExists = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='chapters_fts'",
    );
    if (ftsExists.isNotEmpty) {
      await db.execute('DROP TABLE chapters_fts');
    }
    await db.execute('''
      CREATE VIRTUAL TABLE chapters_fts USING fts4(
        chapter_id, novel_id, title, content
      )
    ''');

    // Có dữ liệu cũ (chương/nhân vật...) mà chưa có truyện nào chứa nó
    // -> tạo 1 truyện mặc định và gán toàn bộ dữ liệu mồ côi vào đó.
    final hasOldChapters = await db.query('chapters', limit: 1);
    final hasOldCharacters = await db.query('characters', limit: 1);
    final hasAnyOldData = hasOldChapters.isNotEmpty || hasOldCharacters.isNotEmpty;

    if (hasAnyOldData) {
      final defaultId = const Uuid().v4();
      final now = DateTime.now().toIso8601String();
      await db.insert('novels', {
        'id': defaultId,
        'title': 'Truyện của tôi',
        'author': '',
        'description': 'Được tự động tạo khi nâng cấp app lên bản hỗ trợ nhiều truyện.',
        'created_at': now,
        'updated_at': now,
      });
      for (final table in [
        'characters',
        'world_rules',
        'timeline_events',
        'chapters',
        'style_profiles',
        'chat_sessions',
        'imported_documents',
      ]) {
        await db.update(table, {'novel_id': defaultId}, where: 'novel_id IS NULL');
      }
      final chapters = await db.query('chapters', where: 'novel_id = ?', whereArgs: [defaultId]);
      for (final c in chapters) {
        await db.insert('chapters_fts', {
          'chapter_id': c['id'],
          'novel_id': defaultId,
          'title': c['title'],
          'content': c['content'],
        });
      }
    }
  }

  // ---------- Novels ----------
  Future<void> upsertNovel(Novel n) async {
    final d = await db;
    // ĐÃ THÊM (mục AG): xem giải thích đầy đủ ở `_logRepetitionPenaltyWrite`.
    await _logRepetitionPenaltyWrite('upsertNovel', n.id, n.genRepetitionPenalty);
    await d.insert('novels', n.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Novel>> allNovels() async {
    final d = await db;
    final rows = await d.query('novels', orderBy: 'updated_at DESC');
    return rows.map((r) => Novel.fromMap(r)).toList();
  }

  Future<Novel?> novelById(String id) async {
    final d = await db;
    final rows = await d.query('novels', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return Novel.fromMap(rows.first);
  }

  // ĐÃ THÊM (theo yêu cầu người dùng — "Cốt truyện đã diễn ra") — update
  // NHẸ, chỉ 2 cột, dùng cho RagService gọi mỗi khi 1 chương hoàn thành
  // (không dùng upsertNovel() vì sẽ phải đọc lại toàn bộ Novel trước, tốn
  // hơn, và tăng rủi ro ghi đè nếu người dùng đang sửa tiêu đề/mô tả truyện
  // ở màn khác đúng lúc này).
  Future<void> updateNovelProgressSummary(String novelId, String summary, int upToChapter) async {
    final d = await db;
    await d.update(
      'novels',
      {'plot_progress_summary': summary, 'plot_progress_summary_chapter': upToChapter},
      where: 'id = ?',
      whereArgs: [novelId],
    );
  }

  // ĐÃ THÊM (v13 — cài đặt "Tự tóm tắt cốt truyện luỹ kế" chuyển từ chung
  // toàn app sang riêng từng truyện, xem giải thích ở Novel/story_models.dart
  // và _migrateToV13). Update nhẹ, chỉ 4 cột liên quan, không đụng các
  // trường khác của Novel — gọi từ GenerationSettingsScreen.
  Future<void> updateNovelPlotSummarySettings(
    String novelId, {
    required bool enabled,
    required int interval,
    required bool preferTimeline,
    required bool preferOutline,
  }) async {
    final d = await db;
    await d.update(
      'novels',
      {
        'plot_summary_enabled': enabled ? 1 : 0,
        'plot_summary_interval': interval,
        'plot_summary_prefer_timeline': preferTimeline ? 1 : 0,
        'plot_summary_prefer_outline': preferOutline ? 1 : 0,
      },
      where: 'id = ?',
      whereArgs: [novelId],
    );
  }

  // ĐÃ THÊM (v14 — cài đặt provider/model/tham số sinh văn bản chuyển từ
  // chung toàn app sang riêng từng truyện, xem story_models.dart và
  // _migrateToV14). 3 hàm set TÁCH RIÊNG (không gộp 1 hàm update chung)
  // để hàm nào cũng ghi được cả giá trị NULL một cách rõ ràng (vd "bỏ chọn
  // model" khi model đang chọn bị xoá khỏi danh sách, xem
  // `clearNovelsActiveLocalModel` bên dưới) — gộp chung dễ nhầm giữa
  // "không đổi field này" và "đổi field này thành null".
  Future<void> setNovelActiveLocalModel(String novelId, String? modelId) async {
    final d = await db;
    await d.update('novels', {'active_local_model_id': modelId}, where: 'id = ?', whereArgs: [novelId]);
  }

  Future<void> setNovelActiveApiProvider(String novelId, String? providerId) async {
    final d = await db;
    await d.update('novels', {'active_api_provider_id': providerId}, where: 'id = ?', whereArgs: [novelId]);
  }

  Future<void> setNovelProviderType(String novelId, String providerType) async {
    final d = await db;
    await d.update('novels', {'provider_type': providerType}, where: 'id = ?', whereArgs: [novelId]);
  }

  // ĐÃ THÊM (v14 — hệ quả TRỰC TIẾP của việc "con trỏ đang chọn" giờ RIÊNG
  // từng truyện thay vì 1 giá trị global DUY NHẤT): trước đây xoá 1 model/
  // provider khỏi danh sách chỉ cần xoá đúng 1 giá trị SharedPreferences
  // (nếu nó đang là "cái active"). Giờ CÓ THỂ có NHIỀU truyện cùng trỏ tới
  // đúng model/provider vừa bị xoá — phải quét XOÁ con trỏ ở MỌI truyện
  // đang trỏ tới nó, nếu không sẽ để lại tham chiếu treo (id không còn tồn
  // tại trong `local_models`/`api_providers` nhưng vẫn nằm trong
  // `novels.active_local_model_id`/`active_api_provider_id`).
  Future<void> clearNovelsActiveLocalModel(String modelId) async {
    final d = await db;
    await d.update('novels', {'active_local_model_id': null}, where: 'active_local_model_id = ?', whereArgs: [modelId]);
  }

  Future<void> clearNovelsActiveApiProvider(String providerId) async {
    final d = await db;
    await d.update('novels', {'active_api_provider_id': null}, where: 'active_api_provider_id = ?', whereArgs: [providerId]);
  }

  Future<void> updateNovelGenerationConfig(
    String novelId, {
    required double temperature,
    required double topP,
    required int topK,
    required double repetitionPenalty,
    required int maxNewTokens,
  }) async {
    final d = await db;
    // ĐÃ THÊM (mục AG): xem giải thích đầy đủ ở `_logRepetitionPenaltyWrite`.
    await _logRepetitionPenaltyWrite('updateNovelGenerationConfig', novelId, repetitionPenalty);
    await d.update(
      'novels',
      {
        'gen_temperature': temperature,
        'gen_top_p': topP,
        'gen_top_k': topK,
        'gen_repetition_penalty': repetitionPenalty,
        'gen_max_new_tokens': maxNewTokens,
      },
      where: 'id = ?',
      whereArgs: [novelId],
    );
  }

  // ĐÃ THÊM (v15 — theo yêu cầu người dùng: "tất cả" cài đặt còn lại cũng
  // riêng từng truyện). 1 hàm update CHUNG, nhận `Map<String, dynamic>`
  // thay vì tách hàm riêng cho từng nhóm như v13/v14 — số lượng field quá
  // nhiều (16 cột) để tách hợp lý, và các màn hình gọi hàm này
  // (`local_optimization_screen.dart`/`translation_settings_screen.dart`/
  // `settings_screen.dart`/`document_screen.dart`) đều chỉ đổi 1-3 field
  // cùng lúc — dùng chung 1 hàm với `Map` rõ ràng field nào đang đổi hơn
  // là định nghĩa 4-5 hàm chỉ khác nhau ở danh sách tham số.
  Future<void> updateNovelSettings(String novelId, Map<String, dynamic> fields) async {
    if (fields.isEmpty) return;
    final d = await db;
    // ĐÃ THÊM (mục AG): xem giải thích đầy đủ ở `_logRepetitionPenaltyWrite`.
    if (fields.containsKey('gen_repetition_penalty')) {
      await _logRepetitionPenaltyWrite('updateNovelSettings', novelId, fields['gen_repetition_penalty']);
    }
    await d.update('novels', fields, where: 'id = ?', whereArgs: [novelId]);
  }

  // Xóa 1 truyện và TOÀN BỘ dữ liệu riêng của nó (chương, nhân vật, luật,
  // timeline, văn phong, chat, tài liệu) — không đụng tới truyện khác.
  Future<void> deleteNovel(String id) async {
    final d = await db;
    await d.delete('chapters_fts', where: 'novel_id = ?', whereArgs: [id]);
    final chapterIds = (await d.query('chapters', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final chId in chapterIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['chapter', chId]);
    }
    final charIds = (await d.query('characters', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final cid in charIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['character', cid]);
    }
    final ruleIds = (await d.query('world_rules', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final rid in ruleIds) {
      await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['world_rule', rid]);
    }
    final sessionIds = (await d.query('chat_sessions', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final sid in sessionIds) {
      await d.delete('chat_messages', where: 'session_id = ?', whereArgs: [sid]);
    }
    final docIds = (await d.query('imported_documents', columns: ['id'], where: 'novel_id = ?', whereArgs: [id]))
        .map((r) => r['id'] as String)
        .toList();
    for (final did in docIds) {
      await d.delete('document_chunks', where: 'document_id = ?', whereArgs: [did]);
    }
    await d.delete('characters', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('world_rules', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('timeline_events', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chapters', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chapter_versions', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('glossary_terms', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('style_profiles', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('chat_sessions', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('imported_documents', where: 'novel_id = ?', whereArgs: [id]);
    await d.delete('novels', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Characters ----------
  Future<void> upsertCharacter(Character c) async {
    final d = await db;
    await d.insert('characters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Character>> allCharacters(String novelId) async {
    final d = await db;
    final rows = await d.query('characters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => Character.fromMap(r)).toList();
  }

  Future<void> deleteCharacter(String id) async {
    final d = await db;
    await d.delete('characters', where: 'id = ?', whereArgs: [id]);
    await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['character', id]);
    await deleteFactsForParent('character', id);
  }

  // ---------- World rules ----------
  Future<void> upsertWorldRule(WorldRule r) async {
    final d = await db;
    await d.insert('world_rules', r.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<WorldRule>> allWorldRules(String novelId) async {
    final d = await db;
    final rows = await d.query('world_rules', where: 'novel_id = ?', whereArgs: [novelId]);
    return rows.map((r) => WorldRule.fromMap(r)).toList();
  }

  Future<void> deleteWorldRule(String id) async {
    final d = await db;
    await d.delete('world_rules', where: 'id = ?', whereArgs: [id]);
    await d.delete('embeddings', where: 'entity_type = ? AND entity_id = ?', whereArgs: ['world_rule', id]);
    await deleteFactsForParent('world_rule', id);
  }

  // ---------- Timeline ----------
  Future<void> upsertTimelineEvent(TimelineEvent e) async {
    final d = await db;
    await d.insert('timeline_events', e.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<TimelineEvent>> allTimelineEvents(String novelId) async {
    final d = await db;
    final rows =
        await d.query('timeline_events', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'chapter_number');
    return rows.map((r) => TimelineEvent.fromMap(r)).toList();
  }

  // ĐÃ THÊM (rà soát toàn hệ thống theo yêu cầu người dùng: "tính năng nào
  // chưa nối dây thì làm lại") — `timeline_events` có đủ bảng/model/CRUD
  // đọc-ghi từ trước nhưng THIẾU đúng hàm xoá 1 sự kiện, và KHÔNG có màn
  // hình nào gọi tới bất kỳ hàm nào ở khối "Timeline" này — tính năng tồn
  // tại hoàn toàn ở tầng dữ liệu nhưng vô hình với người dùng. Xem UI mới
  // ở `story_bible_screen.dart` (tab "Dòng thời gian").
  Future<void> deleteTimelineEvent(String id) async {
    final d = await db;
    await d.delete('timeline_events', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Chapters ----------
  Future<void> upsertChapter(Chapter c) async {
    final d = await db;
    await d.insert('chapters', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    await d.delete('chapters_fts', where: 'chapter_id = ?', whereArgs: [c.id]);
    await d.insert('chapters_fts',
        {'chapter_id': c.id, 'novel_id': c.novelId, 'title': c.title, 'content': c.content});
  }

  // ĐÃ THÊM (theo yêu cầu người dùng — resume khi GPU remote sập giữa
  // chừng): update NHẸ, chỉ đúng 1 cột `generation_checkpoint` — dùng cho
  // ChapterBatchService gọi liên tục (mỗi vài giây, mỗi lần model sinh
  // thêm 1 đoạn) trong lúc AI đang viết. Không dùng `upsertChapter()` cho
  // việc này vì: (1) tốn hơn hẳn (ghi lại TOÀN BỘ cột + xoá/ghi lại cả FTS
  // index mỗi vài giây, trong khi nội dung chương thật `content` chưa hề
  // đổi cho tới lúc xong hẳn); (2) AN TOÀN hơn nếu người dùng lỡ tay sửa
  // tay chương này ở màn khác trong lúc AI đang chạy nền — update 1 cột
  // không đè lên các cột khác họ vừa sửa.
  Future<void> updateChapterCheckpoint(String chapterId, String? checkpoint) async {
    final d = await db;
    await d.update('chapters', {'generation_checkpoint': checkpoint}, where: 'id = ?', whereArgs: [chapterId]);
  }

  Future<List<Chapter>> allChapters(String novelId, {int? limit, int? offset}) async {
    final d = await db;
    final rows = await d.query('chapters',
        where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number DESC', limit: limit, offset: offset);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  Future<List<Chapter>> recentChapters(String novelId, int count) async {
    final d = await db;
    final rows =
        await d.query('chapters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number DESC', limit: count);
    return rows.map((r) => Chapter.fromMap(r)).toList().reversed.toList();
  }

  // ĐÃ THÊM: DAO cho hàng đợi ghi chú bôi đen sửa (PendingRewrite) — xem
  // giải thích đầy đủ ở định nghĩa class trong story_models.dart.
  Future<void> upsertPendingRewrite(PendingRewrite p) async {
    final d = await db;
    await d.insert('pending_rewrites', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<PendingRewrite>> pendingRewritesForChapter(String chapterId) async {
    final d = await db;
    final rows = await d.query('pending_rewrites',
        where: 'chapter_id = ?', whereArgs: [chapterId], orderBy: 'created_at ASC');
    return rows.map((r) => PendingRewrite.fromMap(r)).toList();
  }

  Future<void> deletePendingRewrite(String id) async {
    final d = await db;
    await d.delete('pending_rewrites', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAllPendingRewritesForChapter(String chapterId) async {
    final d = await db;
    await d.delete('pending_rewrites', where: 'chapter_id = ?', whereArgs: [chapterId]);
  }

  // Tìm kiếm toàn văn — dùng cho cả thanh search và cho RAG khi cần
  // tra cứu chương cũ có nhắc tới một từ khóa cụ thể. Luôn giới hạn
  // trong đúng 1 truyện, không lẫn sang truyện khác.
  Future<List<Chapter>> searchChapters(String novelId, String query) async {
    final d = await db;
    final ids = await d.rawQuery(
      'SELECT chapter_id FROM chapters_fts WHERE chapters_fts MATCH ? AND novel_id = ?',
      [query, novelId],
    );
    if (ids.isEmpty) return [];
    final idList = ids.map((r) => r['chapter_id'] as String).toList();
    final rows = await d.query('chapters',
        where: 'novel_id = ? AND id IN (${List.filled(idList.length, '?').join(',')})',
        whereArgs: [novelId, ...idList]);
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // Dùng khi xuất file: cần thứ tự tăng dần theo số chương, không phải
  // "mới nhất trước" như danh sách hiển thị trong app.
  Future<List<Chapter>> allChaptersAscending(String novelId) async {
    final d = await db;
    final rows = await d.query('chapters', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'number ASC');
    return rows.map((r) => Chapter.fromMap(r)).toList();
  }

  // ---------- Chapter versions (snapshot/undo) ----------
  // Số bản snapshot tối đa giữ lại CHO MỖI CHƯƠNG — vượt quá thì tự xóa
  // bản cũ nhất, tránh phình dung lượng DB vô hạn qua hàng nghìn lần AI
  // viết tiếp/rewrite.
  static const int maxVersionsPerChapter = 20;

  Future<void> saveChapterVersion(ChapterVersion v) async {
    final d = await db;
    await d.insert('chapter_versions', v.toMap());
    final rows = await d.query(
      'chapter_versions',
      columns: ['id'],
      where: 'chapter_id = ?',
      whereArgs: [v.chapterId],
      orderBy: 'created_at DESC',
    );
    if (rows.length > maxVersionsPerChapter) {
      final toDelete = rows.skip(maxVersionsPerChapter).map((r) => r['id'] as String).toList();
      await d.delete(
        'chapter_versions',
        where: 'id IN (${List.filled(toDelete.length, '?').join(',')})',
        whereArgs: toDelete,
      );
    }
  }

  Future<List<ChapterVersion>> versionsForChapter(String chapterId) async {
    final d = await db;
    final rows = await d.query('chapter_versions', where: 'chapter_id = ?', whereArgs: [chapterId], orderBy: 'created_at DESC');
    return rows.map((r) => ChapterVersion.fromMap(r)).toList();
  }

  Future<void> deleteChapterVersion(String id) async {
    final d = await db;
    await d.delete('chapter_versions', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Glossary (bảng thuật ngữ) ----------
  Future<void> upsertGlossaryTerm(GlossaryTerm t) async {
    final d = await db;
    await d.insert('glossary_terms', t.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<GlossaryTerm>> allGlossaryTerms(String novelId) async {
    final d = await db;
    final rows = await d.query('glossary_terms', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'term');
    return rows.map((r) => GlossaryTerm.fromMap(r)).toList();
  }

  Future<void> deleteGlossaryTerm(String id) async {
    final d = await db;
    await d.delete('glossary_terms', where: 'id = ?', whereArgs: [id]);
    await deleteFactsForParent('glossary_term', id);
  }

  // ---------- Dàn ý toàn truyện (plot_beats) ----------
  Future<void> upsertPlotBeat(PlotBeat b) async {
    final d = await db;
    await d.insert('plot_beats', b.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<PlotBeat>> allPlotBeats(String novelId) async {
    final d = await db;
    final rows = await d.query('plot_beats', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'order_index');
    return rows.map((r) => PlotBeat.fromMap(r)).toList();
  }

  Future<void> deletePlotBeat(String id) async {
    final d = await db;
    await d.delete('plot_beats', where: 'id = ?', whereArgs: [id]);
  }

  // Lưu lại thứ tự mới sau khi người dùng kéo-thả sắp xếp lại — ghi đè
  // order_index của TỪNG beat theo đúng vị trí mới trong danh sách truyền
  // vào (đã sắp xếp sẵn ở tầng UI).
  Future<void> reorderPlotBeats(List<PlotBeat> orderedBeats) async {
    final d = await db;
    final batch = d.batch();
    for (var i = 0; i < orderedBeats.length; i++) {
      batch.update('plot_beats', {'order_index': i}, where: 'id = ?', whereArgs: [orderedBeats[i].id]);
    }
    await batch.commit(noResult: true);
  }

  // ---------- Tuyến truyện / subplot (plot_threads) ----------
  Future<void> upsertPlotThread(PlotThread t) async {
    final d = await db;
    await d.insert('plot_threads', t.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<PlotThread>> allPlotThreads(String novelId) async {
    final d = await db;
    final rows = await d.query('plot_threads', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => PlotThread.fromMap(r)).toList();
  }

  Future<void> deletePlotThread(String id) async {
    final d = await db;
    await d.delete('plot_threads', where: 'id = ?', whereArgs: [id]);
    await deleteFactsForParent('plot_thread', id);
    // Gỡ tham chiếu id tuyến vừa xoá khỏi MỌI chương đang gắn nó — tránh
    // để lại id "ma" (trỏ tới tuyến không còn tồn tại) trong thread_ids.
    final chapters = await d.query('chapters', where: "thread_ids LIKE ?", whereArgs: ['%$id%']);
    for (final row in chapters) {
      final ids = ((row['thread_ids'] as String?) ?? '').split(',').where((e) => e.isNotEmpty && e != id).join(',');
      await d.update('chapters', {'thread_ids': ids}, where: 'id = ?', whereArgs: [row['id']]);
    }
  }

  // ---------- Quyển/Hồi (volumes) ----------
  Future<void> upsertVolume(Volume v) async {
    final d = await db;
    await d.insert('volumes', v.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Volume>> allVolumes(String novelId) async {
    final d = await db;
    final rows = await d.query('volumes', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'order_index');
    return rows.map((r) => Volume.fromMap(r)).toList();
  }

  // Xoá quyển — KHÔNG xoá các chương đang thuộc quyển đó, chỉ gỡ tham
  // chiếu volume_id (đưa các chương đó về trạng thái "chưa gom quyển"),
  // đúng khuôn mẫu deletePlotThread đã áp dụng.
  Future<void> deleteVolume(String id) async {
    final d = await db;
    await d.delete('volumes', where: 'id = ?', whereArgs: [id]);
    await d.update('chapters', {'volume_id': null}, where: 'volume_id = ?', whereArgs: [id]);
  }

  Future<void> reorderVolumes(List<Volume> orderedVolumes) async {
    final d = await db;
    final batch = d.batch();
    for (var i = 0; i < orderedVolumes.length; i++) {
      batch.update('volumes', {'order_index': i}, where: 'id = ?', whereArgs: [orderedVolumes[i].id]);
    }
    await batch.commit(noResult: true);
  }

  // Dò khoảng số chương THẬT SỰ hiện có của MỖI quyển (min/max trong số
  // các chương ĐANG gán volume_id = quyển đó) — dùng cho phạm vi hiệu lực
  // "theo Quyển/Hồi" (RagService._resolveScope). CỐ TÌNH tính lại MỖI LẦN
  // gọi (không cache/đóng băng) — đúng yêu cầu người dùng: viết thêm
  // chương vào quyển sau này, phạm vi tự mở rộng theo, không cần cập nhật
  // thủ công entry nào. Quyển chưa có chương nào → không xuất hiện trong
  // map trả về (coi như phạm vi rỗng, chưa có gì để lọc).
  Future<Map<String, (int, int)>> volumeChapterRanges(String novelId) async {
    final d = await db;
    final rows = await d.rawQuery(
      'SELECT volume_id, MIN(number) as min_num, MAX(number) as max_num FROM chapters '
      'WHERE novel_id = ? AND volume_id IS NOT NULL GROUP BY volume_id',
      [novelId],
    );
    final result = <String, (int, int)>{};
    for (final r in rows) {
      final volumeId = r['volume_id'] as String?;
      if (volumeId == null) continue;
      result[volumeId] = (r['min_num'] as int, r['max_num'] as int);
    }
    return result;
  }

  // ---------- Chi tiết theo giai đoạn (BibleFact — dùng chung 5 loại Bible) ----------
  Future<void> upsertBibleFact(BibleFact f) async {
    final d = await db;
    await d.insert('bible_facts', f.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<BibleFact>> factsFor(String parentType, String parentId) async {
    final d = await db;
    final rows = await d.query(
      'bible_facts',
      where: 'parent_type = ? AND parent_id = ?',
      whereArgs: [parentType, parentId],
      orderBy: 'order_index',
    );
    return rows.map((r) => BibleFact.fromMap(r)).toList();
  }

  // Nạp TOÀN BỘ fact của 1 LOẠI (vd tất cả fact của mọi Character trong
  // truyện) trong 1 LẦN TRUY VẤN DUY NHẤT — dùng cho RagService.buildContext,
  // tránh N+1 query (1 query riêng cho từng nhân vật khi build ngữ cảnh).
  Future<Map<String, List<BibleFact>>> allFactsForType(String novelId, String parentType) async {
    final d = await db;
    final rows = await d.query(
      'bible_facts',
      where: 'novel_id = ? AND parent_type = ?',
      whereArgs: [novelId, parentType],
      orderBy: 'order_index',
    );
    final result = <String, List<BibleFact>>{};
    for (final r in rows) {
      final f = BibleFact.fromMap(r);
      result.putIfAbsent(f.parentId, () => []).add(f);
    }
    return result;
  }

  Future<void> deleteBibleFact(String id) async {
    final d = await db;
    await d.delete('bible_facts', where: 'id = ?', whereArgs: [id]);
  }

  // Xoá TOÀN BỘ fact thuộc 1 entry — gọi khi xoá chính entry đó (Character/
  // WorldRule/...) để không để lại fact "mồ côi" không còn entry cha.
  Future<void> deleteFactsForParent(String parentType, String parentId) async {
    final d = await db;
    await d.delete('bible_facts', where: 'parent_type = ? AND parent_id = ?', whereArgs: [parentType, parentId]);
  }

  // ---------- Mục tiêu viết + nhật ký số chữ mỗi ngày ----------
  Future<void> saveWritingGoal(WritingGoal g) async {
    final d = await db;
    await d.insert('writing_goals', g.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<WritingGoal?> loadWritingGoal(String novelId) async {
    final d = await db;
    final rows = await d.query('writing_goals', where: 'novel_id = ?', whereArgs: [novelId], limit: 1);
    if (rows.isEmpty) return null;
    return WritingGoal.fromMap(rows.first);
  }

  // Ghi lại tổng số chữ HIỆN TẠI của cả truyện tại NGÀY HÔM NAY — gọi mỗi
  // khi 1 chương được lưu (xem chapter_editor_screen.dart _save()). Ghi
  // đè (upsert) nếu hôm nay đã có snapshot rồi — luôn phản ánh đúng tổng
  // mới nhất trong ngày, không cộng dồn sai nếu lưu chương nhiều lần.
  Future<void> recordWordSnapshot(String novelId) async {
    final d = await db;
    final rows = await d.query('chapters', columns: ['content'], where: 'novel_id = ?', whereArgs: [novelId]);
    int total = 0;
    for (final r in rows) {
      final content = (r['content'] as String?) ?? '';
      if (content.trim().isNotEmpty) total += content.trim().split(RegExp(r'\s+')).length;
    }
    final today = DateTime.now();
    final dateKey = '${today.year.toString().padLeft(4, '0')}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
    await d.insert(
      'daily_word_log',
      {'novel_id': novelId, 'date': dateKey, 'total_words': total},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Trả về danh sách (ngày, tổng số chữ SNAPSHOT tại ngày đó) trong
  // `days` ngày gần nhất, sắp xếp CŨ -> MỚI — tầng UI tự tính hiệu số
  // giữa các ngày liền kề để ra "số chữ viết trong ngày", và tự tính
  // streak (chuỗi ngày liên tiếp có viết) từ dãy hiệu số đó.
  Future<List<Map<String, dynamic>>> recentWordLog(String novelId, {int days = 30}) async {
    final d = await db;
    final since = DateTime.now().subtract(Duration(days: days));
    final sinceKey = '${since.year.toString().padLeft(4, '0')}-${since.month.toString().padLeft(2, '0')}-${since.day.toString().padLeft(2, '0')}';
    final rows = await d.query(
      'daily_word_log',
      where: 'novel_id = ? AND date >= ?',
      whereArgs: [novelId, sinceKey],
      orderBy: 'date ASC',
    );
    return rows;
  }

  // ---------- Local models (nhiều model, chọn 1 model active, dùng chung mọi truyện) ----------
  Future<void> upsertLocalModel(LocalModelEntry m) async {
    final d = await db;
    await d.insert('local_models', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<LocalModelEntry>> allLocalModels() async {
    final d = await db;
    final rows = await d.query('local_models', orderBy: 'name');
    return rows.map((r) => LocalModelEntry.fromMap(r)).toList();
  }

  Future<void> deleteLocalModel(String id) async {
    final d = await db;
    await d.delete('local_models', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- API providers (nhiều provider, không hardcode, dùng chung mọi truyện) ----------
  Future<void> upsertApiProvider(ApiProviderEntry p) async {
    final d = await db;
    await d.insert('api_providers', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ApiProviderEntry>> allApiProviders() async {
    final d = await db;
    final rows = await d.query('api_providers', orderBy: 'name');
    return rows.map((r) => ApiProviderEntry.fromMap(r)).toList();
  }

  Future<void> deleteApiProvider(String id) async {
    final d = await db;
    await d.delete('api_providers', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Imported documents (dịch/tóm tắt/hỏi đáp cuốn chiếu) ----------
  Future<void> upsertDocument(ImportedDocument doc) async {
    final d = await db;
    await d.insert('imported_documents', doc.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ImportedDocument>> allDocuments(String novelId) async {
    final d = await db;
    final rows =
        await d.query('imported_documents', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'created_at DESC');
    return rows.map((r) => ImportedDocument.fromMap(r)).toList();
  }

  Future<void> deleteDocument(String id) async {
    final d = await db;
    await d.delete('imported_documents', where: 'id = ?', whereArgs: [id]);
    await d.delete('document_chunks', where: 'document_id = ?', whereArgs: [id]);
  }

  Future<void> upsertDocumentChunk(DocumentChunk c) async {
    final d = await db;
    await d.insert('document_chunks', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<DocumentChunk>> chunksForDocument(String documentId) async {
    final d = await db;
    final rows = await d.query('document_chunks', where: 'document_id = ?', whereArgs: [documentId], orderBy: 'idx ASC');
    return rows.map((r) => DocumentChunk.fromMap(r)).toList();
  }

  // ---------- Chat sessions (nhiều cửa sổ chat, theo từng truyện) ----------
  Future<void> upsertChatSession(ChatSession s) async {
    final d = await db;
    await d.insert('chat_sessions', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatSession>> allChatSessions(String novelId) async {
    final d = await db;
    final rows =
        await d.query('chat_sessions', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'created_at DESC');
    return rows.map((r) => ChatSession.fromMap(r)).toList();
  }

  Future<void> deleteChatSession(String id) async {
    final d = await db;
    await d.delete('chat_sessions', where: 'id = ?', whereArgs: [id]);
    await d.delete('chat_messages', where: 'session_id = ?', whereArgs: [id]);
  }

  // ---------- Chat messages (bền vững - không mất khi đổi tab/model) ----------
  Future<void> upsertChatMessage(ChatMessageRecord m) async {
    final d = await db;
    await d.insert('chat_messages', m.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatMessageRecord>> chatMessagesForSession(String sessionId) async {
    final d = await db;
    final rows = await d.query('chat_messages', where: 'session_id = ?', whereArgs: [sessionId], orderBy: 'created_at ASC');
    return rows.map((r) => ChatMessageRecord.fromMap(r)).toList();
  }

  // ---------- Style profiles ----------
  Future<void> upsertStyleProfile(StyleProfile s) async {
    final d = await db;
    await d.insert('style_profiles', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<StyleProfile>> allStyleProfiles(String novelId) async {
    final d = await db;
    final rows = await d.query('style_profiles', where: 'novel_id = ?', whereArgs: [novelId], orderBy: 'name');
    return rows.map((r) => StyleProfile.fromMap(r)).toList();
  }

  Future<void> deleteStyleProfile(String id) async {
    final d = await db;
    await d.delete('style_profiles', where: 'id = ?', whereArgs: [id]);
    await deleteFactsForParent('style_profile', id);
  }

  // ---------- Embeddings ----------
  Future<void> upsertEmbedding(String entityType, String entityId, List<double> vector) async {
    final d = await db;
    await d.insert(
      'embeddings',
      {
        'entity_type': entityType,
        'entity_id': entityId,
        'vector': vector.map((v) => v.toStringAsFixed(6)).join(','),
        'updated_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Trả về map entity_id -> vector cho một loại entity, dùng để so sánh
  // cosine similarity với vector của đoạn văn đang viết. entityIds giới
  // hạn kết quả về đúng những entity thuộc truyện đang active (vì bảng
  // embeddings không có cột novel_id riêng, lọc chéo qua danh sách id).
  Future<Map<String, List<double>>> embeddingsFor(String entityType, {List<String>? entityIds}) async {
    final d = await db;
    final rows = await d.query('embeddings', where: 'entity_type = ?', whereArgs: [entityType]);
    final map = {
      for (final r in rows)
        r['entity_id'] as String: (r['vector'] as String).split(',').map(double.parse).toList(),
    };
    if (entityIds == null) return map;
    final idSet = entityIds.toSet();
    map.removeWhere((key, _) => !idSet.contains(key));
    return map;
  }

  // ---------- Backup / Restore toàn bộ dữ liệu ----------
  // Xuất TOÀN BỘ dữ liệu mọi truyện thành 1 cấu trúc JSON thuần (không xuất
  // API key — API key nằm trong flutter_secure_storage riêng, tách biệt có
  // chủ đích vì lý do bảo mật, người dùng cần nhập lại API key sau khi khôi
  // phục trên máy mới). Dùng JSON thay vì copy thẳng file .db để: (1) không
  // phụ thuộc journal mode/WAL còn dở dang lúc copy, (2) portable — khôi
  // phục được cả khi cấu trúc file nội bộ giữa các bản app hơi khác nhau,
  // vì import chạy qua đúng các hàm upsert bình thường (tự re-index FTS,
  // v.v.) thay vì ghi đè thẳng file nhị phân.
  static const List<String> _backupTables = [
    'novels',
    'characters',
    'world_rules',
    'timeline_events',
    'chapters',
    'chapter_versions',
    'glossary_terms',
    'style_profiles',
    'chat_sessions',
    'chat_messages',
    'imported_documents',
    'document_chunks',
    'local_models',
    'api_providers', // KHÔNG có api_key — chỉ metadata (tên/model/base_url)
    // ĐÃ THÊM: 5 bảng của tính năng "quy trình viết tiểu thuyết" (mục 4.16/
    // 5.77 tài liệu kiến trúc) — trước đây thiếu, khôi phục từ backup cũ sẽ
    // mất outline/tuyến/mục tiêu/quyển dù chương vẫn còn nguyên. 'volumes'
    // đặt TRƯỚC 'chapters' về mặt khái niệm (chapters tham chiếu volume_id)
    // nhưng thứ tự import không quan trọng ở đây vì chapters.volume_id chỉ
    // là chuỗi id, không có ràng buộc khóa ngoại cứng (SQLite không ép FK
    // theo mặc định trong app này) — import theo thứ tự nào cũng an toàn.
    'plot_beats',
    'plot_threads',
    'writing_goals',
    'daily_word_log',
    'volumes',
    'bible_facts', // "chi tiết theo giai đoạn" — xem story_models.dart BibleFact
    // ĐÃ THÊM (rà soát lại theo yêu cầu "sao lưu theo từng truyện" — phát
    // hiện 2 bảng này bị THIẾU ở đây từ trước, khôi phục backup app cũ mất
    // 2 loại dữ liệu sau mà không cảnh báo gì):
    'pending_rewrites', // hàng đợi gợi ý sửa chương đang chờ duyệt
    'embeddings', // vector RAG của characters/world_rules/chapters
  ];

  Future<Map<String, dynamic>> exportAllData() async {
    final d = await db;
    final data = <String, dynamic>{};
    for (final table in _backupTables) {
      data[table] = await d.query(table);
    }
    return data;
  }

  // ĐÃ THÊM (theo yêu cầu người dùng: "sao lưu thì nên có 2 lựa chọn là sao
  // lưu toàn app hay sao lưu từng truyện"): xuất ĐÚNG dữ liệu của 1 truyện
  // — mọi bảng liên quan (Bách khoa, chương, version, chat, tài liệu, tiến
  // độ viết...), KHÔNG kèm `local_models`/`api_providers` (danh sách model/
  // API dùng CHUNG toàn app, không phải nội dung riêng của truyện, xem
  // _backupTables ở trên).
  //
  // 3 bảng KHÔNG có cột `novel_id` trực tiếp cần lọc GIÁN TIẾP:
  //   - `document_chunks` qua `document_id` (thuộc `imported_documents` của
  //     truyện)
  //   - `chat_messages` qua `session_id` (thuộc `chat_sessions` của truyện)
  //   - `embeddings` qua `entity_id` (thuộc characters/world_rules/chapters
  //     của truyện, phân biệt bằng `entity_type`)
  // Phải xuất `imported_documents`/`chat_sessions`/3 bảng gốc kia TRƯỚC để
  // có danh sách id làm căn cứ lọc.
  Future<Map<String, dynamic>> exportNovelData(String novelId) async {
    final d = await db;
    final data = <String, dynamic>{};

    data['novels'] = await d.query('novels', where: 'id = ?', whereArgs: [novelId]);

    const novelScopedTables = [
      'characters',
      'world_rules',
      'timeline_events',
      'chapters',
      'chapter_versions',
      'glossary_terms',
      'style_profiles',
      'chat_sessions',
      'imported_documents',
      'plot_beats',
      'plot_threads',
      'writing_goals',
      'daily_word_log',
      'volumes',
      'bible_facts',
      'pending_rewrites',
    ];
    for (final table in novelScopedTables) {
      data[table] = await d.query(table, where: 'novel_id = ?', whereArgs: [novelId]);
    }

    final docIds = (data['imported_documents'] as List).map((r) => (r as Map)['id'] as String).toList();
    data['document_chunks'] = docIds.isEmpty
        ? <Map<String, dynamic>>[]
        : await d.query('document_chunks',
            where: 'document_id IN (${List.filled(docIds.length, '?').join(',')})', whereArgs: docIds);

    final sessionIds = (data['chat_sessions'] as List).map((r) => (r as Map)['id'] as String).toList();
    data['chat_messages'] = sessionIds.isEmpty
        ? <Map<String, dynamic>>[]
        : await d.query('chat_messages',
            where: 'session_id IN (${List.filled(sessionIds.length, '?').join(',')})', whereArgs: sessionIds);

    final charIds = (data['characters'] as List).map((r) => (r as Map)['id'] as String).toList();
    final ruleIds = (data['world_rules'] as List).map((r) => (r as Map)['id'] as String).toList();
    final chapterIds = (data['chapters'] as List).map((r) => (r as Map)['id'] as String).toList();
    final embeddingRows = <Map<String, dynamic>>[];
    Future<void> collectEmbeddings(String entityType, List<String> ids) async {
      if (ids.isEmpty) return;
      final rows = await d.query(
        'embeddings',
        where: 'entity_type = ? AND entity_id IN (${List.filled(ids.length, '?').join(',')})',
        whereArgs: [entityType, ...ids],
      );
      embeddingRows.addAll(rows);
    }

    await collectEmbeddings('character', charIds);
    await collectEmbeddings('world_rule', ruleIds);
    await collectEmbeddings('chapter', chapterIds);
    data['embeddings'] = embeddingRows;

    return data;
  }

  // ĐÃ THÊM (cùng lúc với `exportNovelData` — rà soát lại phát hiện
  // `_backupTables`/`importAllData` (dùng cho backup TOÀN APP) đang THIẾU
  // 2 bảng: `pending_rewrites` (hàng đợi gợi ý sửa chưa duyệt) và
  // `embeddings` (vector RAG) — khôi phục từ backup CŨ (trước bản vá này)
  // sẽ mất 2 loại dữ liệu này mà KHÔNG có cảnh báo gì. Đã bổ sung cả 2 vào
  // `_backupTables` bên dưới — backup TOÀN APP từ giờ đầy đủ hơn; backup
  // CŨ (thiếu 2 bảng) vẫn khôi phục được bình thường, chỉ đơn giản là
  // không có gì để phục hồi cho 2 bảng đó (rơi vào nhánh danh sách rỗng).
  Future<void> importNovelData(Map<String, dynamic> data) async {
    final d = await db;
    const allNovelBackupTables = [
      'novels',
      'characters',
      'world_rules',
      'timeline_events',
      'chapters',
      'chapter_versions',
      'glossary_terms',
      'style_profiles',
      'chat_sessions',
      'chat_messages',
      'imported_documents',
      'document_chunks',
      'plot_beats',
      'plot_threads',
      'writing_goals',
      'daily_word_log',
      'volumes',
      'bible_facts',
      'pending_rewrites',
      'embeddings',
    ];
    for (final table in allNovelBackupTables) {
      final rows = (data[table] as List?)?.cast<Map<String, dynamic>>() ?? [];
      if (table == 'chapters') {
        for (final r in rows) {
          await upsertChapter(Chapter.fromMap(r));
        }
        continue;
      }
      // ĐÃ THÊM (mục AG): xem giải thích đầy đủ ở `_logRepetitionPenaltyWrite`.
      if (table == 'novels') {
        for (final r in rows) {
          await _logRepetitionPenaltyWrite('importNovelData', r['id'] as String?, r['gen_repetition_penalty']);
        }
      }
      for (final r in rows) {
        await d.insert(table, r, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    }
    // ĐÃ THÊM (mục AH, 2026-09-11 — log 17:02-17:08 CHỈ ĐÍCH DANH:
    // `[GHI gen_repetition_penalty] origin=importNovelData novelId=...
    // newValue=1.05`, 25 giây sau khi mở app — ĐÂY MỚI LÀ THỦ PHẠM THẬT,
    // không còn suy đoán). File backup .zip cũ (xuất TỪ TRƯỚC mục AC/AE)
    // tất nhiên còn nguyên giá trị legacy 1.05 — khôi phục file đó là
    // đúng chức năng "khôi phục" (mang lại NGUYÊN VẸN trạng thái cũ), tự
    // nó không sai — nhưng hệ quả là legacy value quay lại. Gọi lại
    // NGAY LẬP TỨC đúng phép tự chữa lành đã có (mục AE) sau khi restore
    // xong — vá đúng lỗ hổng NÀY mà không cần sửa ý nghĩa "khôi phục" của
    // tính năng (không lọc field nào khỏi backup, khôi phục vẫn đầy đủ
    // 100% như trước — chỉ tự nâng cấp NGAY giá trị legacy đã biết rõ là
    // có hại, giống hệt lúc mở app).
    await _selfHealStuckRepetitionPenalty(d, trigger: 'sau-importNovelData');
  }

  // Ghi đè theo id (upsert) — an toàn để chạy nhiều lần, không tạo bản
  // trùng. Chapters cần đồng bộ lại chapters_fts nên đi qua upsertChapter()
  // thay vì insert thẳng bảng chapters.
  Future<void> importAllData(Map<String, dynamic> data) async {
    final d = await db;
    for (final table in _backupTables) {
      final rows = (data[table] as List?)?.cast<Map<String, dynamic>>() ?? [];
      if (table == 'chapters') {
        for (final r in rows) {
          await upsertChapter(Chapter.fromMap(r));
        }
        continue;
      }
      // ĐÃ THÊM (mục AG): xem giải thích đầy đủ ở `_logRepetitionPenaltyWrite`.
      if (table == 'novels') {
        for (final r in rows) {
          await _logRepetitionPenaltyWrite('importAllData', r['id'] as String?, r['gen_repetition_penalty']);
        }
      }
      for (final r in rows) {
        await d.insert(table, r, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    }
    // ĐÃ THÊM (mục AH, 2026-09-11): cùng lý do với `importNovelData` ở
    // trên — khôi phục TOÀN APP từ backup cũ cũng có thể mang legacy
    // 1.05 trở lại cho MỌI truyện trong backup đó, không chỉ 1 truyện.
    await _selfHealStuckRepetitionPenalty(d, trigger: 'sau-importAllData');
  }
}
