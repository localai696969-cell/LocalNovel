import 'dart:io';
import 'package:path_provider/path_provider.dart';

// Ghi log ra FILE THẬT (flush ngay lập tức, không đợi buffer hệ điều hành)
// — mục đích riêng: khi app bị crash native (SIGSEGV ở tầng C++, Kotlin
// try/catch không bắt được, toàn bộ tiến trình chết ngay lập tức không kịp
// hiện lỗi gì), dòng log CUỐI CÙNG trong file này vẫn còn nguyên trên đĩa,
// cho biết chính xác app đang làm gì (gọi lệnh native nào, slot mấy, model
// nào) ngay trước khi chết — thay thế tạm cho việc không lấy được logcat
// thật (cần máy tính + ADB, nhiều người dùng không có sẵn).
//
// QUAN TRỌNG: dùng `getApplicationSupportDirectory()` (KHÔNG phải
// `getApplicationDocumentsDirectory()`) — trên Android, ApplicationSupport
// mới tương ứng đúng `context.getFilesDir()`, còn ApplicationDocuments lại
// map sang 1 thư mục KHÁC (`.../app_flutter`). Tầng Kotlin/C++
// (MnnBridge.kt, mnn_bridge.cpp) ghi log native vào `appContext.filesDir`
// — phải dùng đúng hàm Dart này thì mới đọc được CÙNG thư mục, không thì
// sẽ không bao giờ thấy file log native dù nó ghi ra thành công.
//
// Đây KHÔNG thay thế được logcat/tombstone thật (không biết được lý do sâu
// ở tầng C++, chỉ biết được ĐANG LÀM GÌ lúc chết) nhưng đủ để khoanh vùng
// chính xác bước nào gây crash mà không cần máy tính.
class DebugLogService {
  static final DebugLogService instance = DebugLogService._();
  DebugLogService._();

  File? _file;
  static const int _maxBytesBeforeTrim = 512 * 1024; // 512KB — đủ nhiều dòng, không phình vô hạn

  Future<File> _getFile() async {
    if (_file != null) return _file!;
    final dir = await getApplicationSupportDirectory();
    _file = File('${dir.path}/debug_log.txt');
    return _file!;
  }

  // File log ghi từ tầng Kotlin/C++ (MnnBridge.kt, mnn_bridge.cpp) — nằm
  // CÙNG thư mục (appContext.filesDir == getApplicationSupportDirectory
  // trên Android) nhưng tên file khác, đọc riêng để không lẫn 2 nguồn log.
  Future<File> _getNativeFile() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/native_debug.txt');
  }

  Future<void> log(String message) async {
    try {
      final f = await _getFile();
      final line = '[${DateTime.now().toIso8601String()}] $message\n';
      final sink = f.openWrite(mode: FileMode.append);
      sink.write(line);
      await sink.flush();
      await sink.close();

      // Cắt bớt nếu file phình quá to (giữ lại phần cuối, gần crash nhất
      // vẫn quan trọng hơn phần đầu).
      final size = await f.length();
      if (size > _maxBytesBeforeTrim) {
        final content = await f.readAsString();
        final trimmed = content.substring(content.length - (_maxBytesBeforeTrim ~/ 2));
        await f.writeAsString(trimmed, flush: true);
      }
    } catch (_) {
      // Không để lỗi ghi log làm hỏng luồng chính — đây chỉ là công cụ hỗ
      // trợ chẩn đoán, không được phép tự nó gây thêm lỗi.
    }
  }

  // Đọc CẢ 2 nguồn (Dart + Kotlin/C++), gộp lại theo mốc thời gian ghi
  // (mỗi dòng đã tự có timestamp riêng, chỉ cần nối chuỗi là đủ dễ đọc —
  // không cần parse/sort phức tạp, người đọc tự so timestamp bằng mắt).
  Future<String> readAll() async {
    final buffer = StringBuffer();
    try {
      final f = await _getFile();
      if (await f.exists()) {
        final c = await f.readAsString();
        if (c.isNotEmpty) {
          buffer.writeln('===== Log tầng Dart (debug_log.txt) =====');
          buffer.writeln(c);
        }
      }
    } catch (e) {
      buffer.writeln('(Lỗi đọc log Dart: $e)');
    }

    try {
      final nf = await _getNativeFile();
      if (await nf.exists()) {
        final c = await nf.readAsString();
        if (c.isNotEmpty) {
          buffer.writeln('===== Log tầng Kotlin/C++ (native_debug.txt) =====');
          buffer.writeln(c);
        }
      }
    } catch (e) {
      buffer.writeln('(Lỗi đọc log native: $e)');
    }

    final result = buffer.toString();
    return result.isEmpty
        ? '(Chưa có log nào — log sẽ tự ghi khi bạn dùng model local.)'
        : result;
  }

  Future<void> clear() async {
    try {
      final f = await _getFile();
      if (await f.exists()) await f.writeAsString('', flush: true);
    } catch (_) {}
    try {
      final nf = await _getNativeFile();
      if (await nf.exists()) await nf.writeAsString('', flush: true);
    } catch (_) {}
  }

  Future<String> filePath() async => (await _getFile()).path;
}
