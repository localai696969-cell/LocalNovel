import 'dart:io';
import 'package:path_provider/path_provider.dart';

// Ghi log ra FILE THẬT (flush ngay lập tức, không đợi buffer hệ điều hành)
// — mục đích riêng: khi app bị crash native (SIGSEGV ở tầng C++, Kotlin
// try/catch không bắt được, toàn bộ tiến trình chết ngay lập tức không kịp
// hiện lỗi gì), dòng log CUỐI CÙNG trong file này vẫn còn nguyên trên đĩa,
// cho biết chính xác app đang làm gì (gọi lệnh native nào, slot mấy, model
// nào) ngay trước khi chết — thay thế tạm cho việc không lấy được logcat
// thật (cần máy tính + ADB, nhiều người dùng không có sẵn).
//
// Đây KHÔNG thay thế được logcat/tombstone thật (không biết được lý do sâu
// ở tầng C++, chỉ biết được ĐANG LÀM GÌ lúc chết) nhưng đủ để khoanh vùng
// chính xác bước nào gây crash mà không cần máy tính.
class DebugLogService {
  static final DebugLogService instance = DebugLogService._();
  DebugLogService._();

  File? _file;
  static const int _maxBytesBeforeTrim = 512 * 1024; // 512KB — đủ nhiều dòng, không phình vô hạn

  Future<File> _getFile() async {
    if (_file != null) return _file!;
    final dir = await getApplicationDocumentsDirectory();
    _file = File('${dir.path}/debug_log.txt');
    return _file!;
  }

  Future<void> log(String message) async {
    try {
      final f = await _getFile();
      final line = '[${DateTime.now().toIso8601String()}] $message\n';
      final sink = f.openWrite(mode: FileMode.append);
      sink.write(line);
      await sink.flush();
      await sink.close();

      // Cắt bớt nếu file phình quá to (giữ lại phần cuối, gần crash nhất
      // vẫn quan trọng hơn phần đầu).
      final size = await f.length();
      if (size > _maxBytesBeforeTrim) {
        final content = await f.readAsString();
        final trimmed = content.substring(content.length - (_maxBytesBeforeTrim ~/ 2));
        await f.writeAsString(trimmed, flush: true);
      }
    } catch (_) {
      // Không để lỗi ghi log làm hỏng luồng chính — đây chỉ là công cụ hỗ
      // trợ chẩn đoán, không được phép tự nó gây thêm lỗi.
    }
  }

  Future<String> readAll() async {
    try {
      final f = await _getFile();
      if (!await f.exists()) return '(Chưa có log nào — log sẽ tự ghi khi bạn dùng model local.)';
      final content = await f.readAsString();
      return content.isEmpty ? '(File log rỗng.)' : content;
    } catch (e) {
      return 'Lỗi đọc file log: $e';
    }
  }

  Future<void> clear() async {
    try {
      final f = await _getFile();
      if (await f.exists()) await f.writeAsString('', flush: true);
    } catch (_) {}
  }

  Future<String> filePath() async => (await _getFile()).path;
}
