import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import '../models/device_profile.dart';

class DeviceProfileService {
  Future<({DeviceProfile profile, String deviceLabel, bool recognized})> detect() async {
    if (!Platform.isAndroid) {
      return (
        profile: fallbackProfileByRam(8000),
        deviceLabel: 'Không phải Android (${Platform.operatingSystem})',
        recognized: false,
      );
    }
    final info = await DeviceInfoPlugin().androidInfo;
    // `hardware`/`board` thường trùng mã nội bộ chipset trên máy Qualcomm.
    final hardwareKey = info.hardware.toLowerCase();
    final boardKey = info.board.toLowerCase();
    final label = '${info.manufacturer} ${info.model}';

    final matched = knownChipsetProfiles[hardwareKey] ?? knownChipsetProfiles[boardKey];
    if (matched != null) {
      return (profile: matched, deviceLabel: label, recognized: true);
    }

    // Không nhận diện được chipset cụ thể -> ước lượng theo RAM tổng,
    // đọc trực tiếp từ /proc/meminfo (luôn khả dụng trên Android, không
    // cần quyền đặc biệt để đọc).
    final totalRamMb = await _readTotalRamMb();
    return (profile: fallbackProfileByRam(totalRamMb), deviceLabel: label, recognized: false);
  }

  // Public để các service khác (vd TranslationService) tái dùng, quyết
  // định có nên giữ nhiều model cùng lúc trong RAM hay không.
  Future<int> readTotalRamMb() async => _readTotalRamMb();

  Future<int> _readTotalRamMb() async {
    try {
      final content = await File('/proc/meminfo').readAsString();
      final match = RegExp(r'MemTotal:\s+(\d+)\s+kB').firstMatch(content);
      if (match != null) {
        final kb = int.parse(match.group(1)!);
        return kb ~/ 1024;
      }
    } catch (_) {
      // Một số máy/bản ROM giới hạn quyền đọc — rơi về giá trị ước lượng
      // trung bình an toàn thay vì làm app lỗi.
    }
    return 6000;
  }
}
