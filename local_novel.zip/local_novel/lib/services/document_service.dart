import 'dart:async';
import 'dart:io';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'background_task_manager.dart';
import 'database_service.dart';
import 'providers/local_provider.dart';
import 'settings_service.dart';
import 'translation_service.dart';

enum DocumentAction { translate, summarize }

// ĐÃ THÊM (rà soát toàn hệ thống theo yêu cầu người dùng: "tính năng nào
// chưa đi qua quy trình dịch-sinh-dịch thì làm lại"): trước đây CẢ 2 hành
// động (Dịch, Tóm tắt) đều gọi thẳng `provider.generate()`, bỏ qua hoàn
// toàn `TranslationService` — cùng lớp lỗi với Bible đã sửa ở mục 5.90
// (systemPrompt tiếng Việt gửi thẳng cho model không giỏi tiếng Việt).
//
// NHƯNG 2 hành động này KHÔNG đối xứng, nên xử lý khác nhau:
//
// - "Tóm tắt": input là văn bản BẤT KỲ ngôn ngữ nào, output PHẢI là tóm
//   tắt tự do bằng tiếng Việt — hệt bản chất "sinh văn xuôi tiếng Việt"
//   như Viết tiếp/Đắp thịt/Chat. Ở ĐÂY đúng là bị bỏ sót, ĐÃ SỬA: đi qua
//   `TranslationService.generateWithOptionalTranslation()` như mọi tác vụ
//   sinh văn bản Việt khác.
//
// - "Dịch": bản chất nhiệm vụ CHÍNH LÀ đổi ngôn ngữ (từ ngôn ngữ nguồn của
//   `chunk.originalText`, thường đã KHÔNG phải tiếng Việt — vd dịch 1
//   chương tiểu thuyết tiếng Trung/Anh — sang tiếng Việt). Nếu bọc thêm 1
//   lớp dịch-sinh-dịch nữa (dịch cả systemPrompt LẪN content nguồn sang
//   ngôn ngữ trung gian, để model sinh ra... vẫn phải là tiếng Việt vì đó
//   là NHIỆM VỤ, rồi lại "dịch kết quả về tiếng Việt" lần 2 dù nó ĐÃ là
//   tiếng Việt) sẽ dịch 2 lần chồng chéo, sai ngôn ngữ ở bước cuối (dịch
//   ngược 1 văn bản ĐÃ là tiếng Việt sẽ làm hỏng nó). Vì vậy "Dịch" CỐ
//   TÌNH giữ nguyên gọi thẳng `provider.generate()` — không phải bỏ sót.
// ĐÃ SỬA (theo phản hồi người dùng: "các màn hình AI tạo sinh văn bản đều
// làm theo dạng chữ xuất hiện từng chữ 1 hết chứ" — tài liệu là màn CUỐI
// CÙNG còn thiếu, đã trì hoãn ở phiên trước với lý do "mỗi đoạn ngắn, ưu
// tiên thấp" — không hợp lý khi người dùng muốn NHẤT QUÁN 100%, sửa luôn):
// thêm `onChunk` — stream đúng bước NGƯỜI DÙNG NHÌN THẤY kết quả cho CẢ 2
// hành động. "Tóm tắt" đã qua `TranslationService.generateWithOptionalTranslation`
// (đã tự hỗ trợ `onChunk` từ phiên trước) — chỉ cần truyền xuống. "Dịch"
// gọi thẳng `provider.generateStream()` thay vì `provider.generate()` —
// cùng interface `AIProvider`, đổi 1 dòng là đủ, không có rào cản kỹ thuật
// nào (y hệt bài học đã rút ra ở phiên trước với dịch thuật trung gian).
Future<String> _generateChunk({
  required AIProvider provider,
  required DocumentAction action,
  required String systemPrompt,
  required DocumentChunk chunk,
  required String novelId,
  void Function(String textSoFar)? onChunk,
}) async {
  if (action == DocumentAction.summarize) {
    return TranslationService(SettingsService(), novelId: novelId).generateWithOptionalTranslation(
      mainProvider: provider,
      systemPrompt: systemPrompt,
      userPrompt: chunk.originalText,
      maxTokens: 400,
      temperature: 0.3,
      onChunk: onChunk,
    );
  }
  // DocumentAction.translate — cố tình KHÔNG qua TranslationService, xem
  // giải thích đầy đủ ở comment đầu file (dịch 2 lớp chồng nhau sẽ hỏng
  // ngôn ngữ ở bước cuối) — nhưng VẪN stream trực tiếp từ provider được,
  // đây là 2 việc độc lập (đi qua TranslationService hay không ≠ stream
  // hay không stream).
  if (onChunk == null) {
    return provider.generate(
      systemPrompt: systemPrompt,
      userPrompt: chunk.originalText,
      maxTokens: 2000,
      temperature: 0.3,
    );
  }
  final buffer = StringBuffer();
  await for (final part in provider.generateStream(
    systemPrompt: systemPrompt,
    userPrompt: chunk.originalText,
    maxTokens: 2000,
    temperature: 0.3,
  )) {
    buffer.write(part);
    onChunk(buffer.toString());
  }
  return buffer.toString();
}

// ĐÃ THÊM (2026-08-01, sau khi phát hiện qua log thật): sau 1 lần crash
// SIGSEGV THẬT SỰ trong lúc generate() (mục 62/63), trạng thái nội bộ
// của đối tượng `Llm` phía native CÓ THỂ bị hỏng (heap corruption) mà
// KHÔNG lập tức làm chết app — các lần generate() SAU ĐÓ vẫn "chạy xong,
// không crash" theo nghĩa kỹ thuật, nhưng trả về kết quả RỖNG hoặc CỰC
// NGẮN một cách bất thường (ví dụ 17 ký tự cho 1 đoạn văn 800+ ký tự) —
// và trước đây code vẫn LƯU những kết quả rác này vào DB, đánh dấu đoạn
// "đã xong" (dấu tick xanh) như thể dịch/tóm tắt thành công thật sự.
// Class này đại diện cho việc PHÁT HIỆN kết quả bất thường đó, để dừng
// vòng lặp xử lý nhiều đoạn NGAY LẬP TỨC thay vì tiếp tục chạy qua hàng
// chục đoạn khác cũng sẽ ra rác (vì trạng thái native đã hỏng), và KHÔNG
// lưu kết quả rác vào DB coi như đã xong.
class DocumentProcessingAnomalyException implements Exception {
  final int chunkIndex; // 0-based, ứng với DocumentChunk.index
  final String rawResult;
  final int sourceLength;
  DocumentProcessingAnomalyException({required this.chunkIndex, required this.rawResult, required this.sourceLength});

  @override
  String toString() =>
      'Đoạn ${chunkIndex + 1}: kết quả bất thường (${rawResult.length} ký tự cho nguồn dài $sourceLength ký tự) — '
      'rất có thể model bị lỗi native giữa chừng (xem log debug), ĐÃ DỪNG xử lý các đoạn còn lại để tránh lưu thêm kết quả rác.';
}

// Xử lý "cuốn chiếu": văn bản dài (có thể hàng trăm nghìn chữ) được
// chia thành nhiều đoạn nhỏ vừa với ngữ cảnh model, xử lý TUẦN TỰ từng
// đoạn (không gửi cả file cùng lúc — model local/API nào cũng có giới
// hạn context), rồi ráp kết quả từng đoạn lại thành file hoàn chỉnh.
// Dùng thuần dart:io để đọc file — không thêm package nào, tránh lặp
// lại các lỗi build đã gặp với file_picker/fllama.
class DocumentService {
  final DatabaseService db;
  DocumentService(this.db);

  static const int chunkSizeChars = 3000;

  Future<ImportedDocument> importFromPath(String path, {required String novelId}) async {
    final file = File(path);
    if (!await file.exists()) {
      throw Exception('Không tìm thấy file ở đường dẫn: $path');
    }
    final content = await file.readAsString();
    final chunks = _splitIntoChunks(content);

    final doc = ImportedDocument(
      id: const Uuid().v4(),
      novelId: novelId,
      name: path.split('/').last,
      sourcePath: path,
      chunkCount: chunks.length,
    );
    await db.upsertDocument(doc);
    for (var i = 0; i < chunks.length; i++) {
      await db.upsertDocumentChunk(DocumentChunk(
        id: const Uuid().v4(),
        documentId: doc.id,
        index: i,
        originalText: chunks[i],
      ));
    }
    return doc;
  }

  // Ưu tiên cắt tại ranh giới đoạn văn (dòng trống) để không cắt ngang
  // câu, giữ ngữ cảnh mỗi đoạn mạch lạc nhất có thể.
  List<String> _splitIntoChunks(String text) {
    final paragraphs = text.split(RegExp(r'\n\s*\n'));
    final chunks = <String>[];
    final buffer = StringBuffer();
    for (final p in paragraphs) {
      if (buffer.length + p.length > chunkSizeChars && buffer.isNotEmpty) {
        chunks.add(buffer.toString().trim());
        buffer.clear();
      }
      buffer.writeln(p);
      buffer.writeln();
    }
    if (buffer.isNotEmpty) chunks.add(buffer.toString().trim());
    return chunks.isEmpty ? [text] : chunks;
  }

  // Xử lý tuần tự từng đoạn, gọi onProgress sau mỗi đoạn để UI cập nhật
  // thanh tiến trình — có thể mất nhiều phút với tài liệu dài, người
  // dùng cần thấy đang chạy tới đâu chứ không phải màn hình treo.
  // ĐÃ SỬA (theo yêu cầu người dùng: mọi nhiệm vụ AI đi qua chung 1 hàng
  // đợi, chạy song song được khi dùng GPU từ xa): điều phối theo loại
  // provider, cùng nguyên tắc đã áp dụng cho ChapterBatchService —
  //   - LOCAL: GIỮ NGUYÊN 100% hành vi cũ (tuần tự, không đổi 1 dòng nào)
  //     — lý do an toàn thật ở mục 5.67 tài liệu kiến trúc (Llm::response()
  //     của MNN không an toàn khi 2 luồng cùng ghi vào chung 1 KV-cache).
  //   - REMOTE: thả từng đoạn vào BackgroundTaskManager, chạy thật sự
  //     đồng thời (giới hạn theo cấu hình người dùng).
  Future<void> processDocument({
    required ImportedDocument doc,
    required DocumentAction action,
    required AIProvider provider,
    String? customInstruction,
    bool resumeFromProgress = true,
    int? startIndex,
    int? endIndex,
    Set<int>? chunkIndices,
    bool Function()? isCancelled,
    void Function(int done, int total, {String? currentText, String? currentChunkId})? onProgress,
  }) async {
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) {
      await _processDocumentSequential(
        doc: doc,
        action: action,
        provider: provider,
        customInstruction: customInstruction,
        resumeFromProgress: resumeFromProgress,
        startIndex: startIndex,
        endIndex: endIndex,
        chunkIndices: chunkIndices,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    } else {
      await _processDocumentParallel(
        doc: doc,
        action: action,
        provider: provider,
        customInstruction: customInstruction,
        resumeFromProgress: resumeFromProgress,
        startIndex: startIndex,
        endIndex: endIndex,
        chunkIndices: chunkIndices,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    }
  }

  // Tách phần chọn targetChunks dùng chung cho cả 2 nhánh — tránh lặp
  // logic (đã có sẵn từ bản gốc, không đổi).
  Future<(List<DocumentChunk>, bool)> _resolveTargetChunks({
    required ImportedDocument doc,
    bool resumeFromProgress = true,
    int? startIndex,
    int? endIndex,
    Set<int>? chunkIndices,
  }) async {
    final allChunks = await db.chunksForDocument(doc.id);
    List<DocumentChunk> targetChunks;
    final bool explicitSelection = chunkIndices != null && chunkIndices.isNotEmpty;
    if (explicitSelection) {
      targetChunks = allChunks.where((c) => chunkIndices.contains(c.index)).toList();
    } else {
      final effectiveStart = (startIndex ?? 0).clamp(0, allChunks.isEmpty ? 0 : allChunks.length - 1);
      final effectiveEnd = (endIndex ?? (allChunks.length - 1)).clamp(effectiveStart, allChunks.isEmpty ? 0 : allChunks.length - 1);
      targetChunks = allChunks.isEmpty ? <DocumentChunk>[] : allChunks.sublist(effectiveStart, effectiveEnd + 1);
    }
    final effectiveResume = resumeFromProgress && !explicitSelection;
    return (targetChunks, effectiveResume);
  }

  // ===== Nhánh LOCAL — GIỮ NGUYÊN 100% logic gốc. =====
  Future<void> _processDocumentSequential({
    required ImportedDocument doc,
    required DocumentAction action,
    required AIProvider provider,
    String? customInstruction,
    bool resumeFromProgress = true,
    int? startIndex,
    int? endIndex,
    Set<int>? chunkIndices,
    bool Function()? isCancelled,
    void Function(int done, int total, {String? currentText, String? currentChunkId})? onProgress,
  }) async {
    final allChunks = await db.chunksForDocument(doc.id);
    final systemPrompt = action == DocumentAction.translate
        ? (customInstruction ?? 'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.')
        : (customInstruction ?? 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.');

    final (targetChunks, effectiveResume) = await _resolveTargetChunks(
      doc: doc,
      resumeFromProgress: resumeFromProgress,
      startIndex: startIndex,
      endIndex: endIndex,
      chunkIndices: chunkIndices,
    );

    var done = effectiveResume ? targetChunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length : 0;
    onProgress?.call(done, targetChunks.length);

    await LocalLlamaProvider.beginPipeline(
      action == DocumentAction.translate ? 'Đang dịch tài liệu...' : 'Đang tóm tắt tài liệu...',
    );

    try {
      for (var i = 0; i < targetChunks.length; i++) {
        if (isCancelled?.call() ?? false) break;
        final chunk = targetChunks[i];
        if (effectiveResume && chunk.resultText != null && chunk.resultText!.isNotEmpty) {
          continue; // đã có kết quả từ lần chạy trước, bỏ qua
        }
        await LocalLlamaProvider.updatePipelineStage('Đang xử lý đoạn ${chunk.index + 1}/${allChunks.length}...');
        onProgress?.call(done, targetChunks.length, currentChunkId: chunk.id);
        // ĐÃ SỬA (theo phản hồi người dùng — xem giải thích đầy đủ ở
        // `_generateChunk`): thêm `onChunk` KHÔNG đổi cấu trúc chạy tuần tự
        // ở đây (vòng `for` vẫn `await` xong đoạn này mới sang đoạn kế) —
        // chỉ quan sát thụ động lên đúng 1 lệnh generate() đang chạy, cùng
        // lý do đã áp dụng cho `ChapterBatchService._generateBatchSequential`.
        final result = await _generateChunk(
          provider: provider,
          action: action,
          systemPrompt: systemPrompt,
          chunk: chunk,
          novelId: doc.novelId,
          onChunk: (textSoFar) => onProgress?.call(done, targetChunks.length, currentText: textSoFar, currentChunkId: chunk.id),
        );
        final resultTrimmed = result.trim();
        final sourceLen = chunk.originalText.trim().length;
        // ĐÃ THÊM (mục AB tài liệu kiến trúc, 2026-09-09 — rà soát toàn bộ
        // codebase theo yêu cầu người dùng, không chờ log mới): thiếu hẳn
        // `kAiFailureMarker` ở đây — chỉ dựa vào tỉ lệ độ dài kết quả/nguồn
        // (< 15%) để đoán "bất thường". Với hành động "Tóm tắt", kết quả
        // NGẮN HƠN nguồn là chuyện BÌNH THƯỜNG (đúng bản chất tóm tắt), nên
        // ngưỡng tỉ lệ này không đáng tin cậy để phân biệt "tóm tắt ngắn
        // nhưng đúng" với "rác + cảnh báo lỗi native/Dart" — kiểm tra
        // `kAiFailureMarker` trực tiếp mới chắc chắn, không phụ thuộc độ
        // dài nguồn/kết quả.
        final looksCorrupted = resultTrimmed.isEmpty ||
            resultTrimmed.contains(kAiFailureMarker) ||
            (sourceLen > 50 && resultTrimmed.length < sourceLen * 0.15);
        if (looksCorrupted) {
          onProgress?.call(done, targetChunks.length, currentChunkId: chunk.id);
          throw DocumentProcessingAnomalyException(chunkIndex: chunk.index, rawResult: resultTrimmed, sourceLength: sourceLen);
        }
        chunk.resultText = resultTrimmed;
        await db.upsertDocumentChunk(chunk);
        done++;
        onProgress?.call(done, targetChunks.length, currentChunkId: chunk.id);
      }
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }

  // ===== Nhánh REMOTE — MỚI. Thả từng đoạn vào BackgroundTaskManager,
  // chạy thật sự đồng thời. Giữ đúng hợp đồng cũ: vẫn ném
  // DocumentProcessingAnomalyException nếu có đoạn bất thường (nơi gọi ở
  // document_screen.dart bắt lỗi này y hệt như trước), vẫn gọi onProgress
  // đúng số lượng — chỉ khác thứ tự hoàn thành có thể không tuần tự theo
  // đúng thứ tự đoạn nữa (vì chạy song song). =====
  Future<void> _processDocumentParallel({
    required ImportedDocument doc,
    required DocumentAction action,
    required AIProvider provider,
    String? customInstruction,
    bool resumeFromProgress = true,
    int? startIndex,
    int? endIndex,
    Set<int>? chunkIndices,
    bool Function()? isCancelled,
    void Function(int done, int total, {String? currentText, String? currentChunkId})? onProgress,
  }) async {
    final systemPrompt = action == DocumentAction.translate
        ? (customInstruction ?? 'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.')
        : (customInstruction ?? 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.');

    final (targetChunks, effectiveResume) = await _resolveTargetChunks(
      doc: doc,
      resumeFromProgress: resumeFromProgress,
      startIndex: startIndex,
      endIndex: endIndex,
      chunkIndices: chunkIndices,
    );

    var done = effectiveResume ? targetChunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length : 0;
    onProgress?.call(done, targetChunks.length);

    DocumentProcessingAnomalyException? capturedAnomaly;
    final completers = <Completer<void>>[];

    for (final chunk in targetChunks) {
      if (isCancelled?.call() ?? false) break;
      if (capturedAnomaly != null) break;
      if (effectiveResume && chunk.resultText != null && chunk.resultText!.isNotEmpty) {
        continue; // đã có kết quả từ lần chạy trước, bỏ qua
      }

      final completer = Completer<void>();
      completers.add(completer);

      BackgroundTaskManager.instance.submit(
        label: 'Đoạn ${chunk.index + 1}: ${doc.name}',
        category: 'document',
        isLocalProvider: provider is LocalLlamaProvider,
        run: () async {
          try {
            final result = await _generateChunk(
              provider: provider,
              action: action,
              systemPrompt: systemPrompt,
              chunk: chunk,
              novelId: doc.novelId,
              onChunk: (textSoFar) =>
                  onProgress?.call(done, targetChunks.length, currentText: textSoFar, currentChunkId: chunk.id),
            );
            final resultTrimmed = result.trim();
            final sourceLen = chunk.originalText.trim().length;
            // ĐÃ THÊM (mục AB, 2026-09-09) — cùng lỗ hổng/cùng cách vá như
            // nhánh tuần tự (LOCAL) ở trên; đây là bản riêng cho nhánh
            // REMOTE (song song), không tự thừa hưởng bản vá của nhánh kia.
            final looksCorrupted = resultTrimmed.isEmpty ||
                resultTrimmed.contains(kAiFailureMarker) ||
                (sourceLen > 50 && resultTrimmed.length < sourceLen * 0.15);
            if (looksCorrupted) {
              capturedAnomaly ??= DocumentProcessingAnomalyException(chunkIndex: chunk.index, rawResult: resultTrimmed, sourceLength: sourceLen);
              onProgress?.call(done, targetChunks.length, currentChunkId: chunk.id);
              return; // không lưu kết quả hỏng, không tăng done
            }
            chunk.resultText = resultTrimmed;
            await db.upsertDocumentChunk(chunk);
            done++;
            onProgress?.call(done, targetChunks.length, currentChunkId: chunk.id);
          } catch (e) {
            capturedAnomaly ??= DocumentProcessingAnomalyException(chunkIndex: chunk.index, rawResult: e.toString(), sourceLength: 0);
            onProgress?.call(done, targetChunks.length, currentChunkId: chunk.id);
          } finally {
            if (!completer.isCompleted) completer.complete();
          }
        },
      );
    }

    await Future.wait(completers.map((c) => c.future));

    if (capturedAnomaly != null) throw capturedAnomaly!;
  }

  // Ráp toàn bộ kết quả từng đoạn thành 1 file hoàn chỉnh.
  Future<File> exportResult(ImportedDocument doc, Directory outputDir) async {
    final chunks = await db.chunksForDocument(doc.id);
    final buffer = StringBuffer();
    for (final c in chunks) {
      buffer.writeln(c.resultText ?? '[Chưa xử lý đoạn ${c.index + 1}]');
      buffer.writeln();
    }
    final outFile = File('${outputDir.path}/${doc.name}_ket_qua.txt');
    return outFile.writeAsString(buffer.toString());
  }

  // Toàn văn tóm tắt các đoạn — dùng làm ngữ cảnh khi người dùng hỏi
  // đáp về tài liệu trong khung chat.
  Future<String> buildQaContext(ImportedDocument doc) async {
    final chunks = await db.chunksForDocument(doc.id);
    final buffer = StringBuffer('### Nội dung tài liệu "${doc.name}" (đã tóm tắt theo từng đoạn)\n');
    for (final c in chunks) {
      if (c.resultText != null) {
        buffer.writeln('- Đoạn ${c.index + 1}: ${c.resultText}');
      }
    }
    return buffer.toString();
  }
}
