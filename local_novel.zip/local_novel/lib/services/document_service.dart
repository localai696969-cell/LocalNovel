import 'dart:io';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'database_service.dart';

enum DocumentAction { translate, summarize }

// Xử lý "cuốn chiếu": văn bản dài (có thể hàng trăm nghìn chữ) được
// chia thành nhiều đoạn nhỏ vừa với ngữ cảnh model, xử lý TUẦN TỰ từng
// đoạn (không gửi cả file cùng lúc — model local/API nào cũng có giới
// hạn context), rồi ráp kết quả từng đoạn lại thành file hoàn chỉnh.
// Dùng thuần dart:io để đọc file — không thêm package nào, tránh lặp
// lại các lỗi build đã gặp với file_picker/fllama.
class DocumentService {
  final DatabaseService db;
  DocumentService(this.db);

  static const int chunkSizeChars = 3000;

  Future<ImportedDocument> importFromPath(String path, {required String novelId}) async {
    final file = File(path);
    if (!await file.exists()) {
      throw Exception('Không tìm thấy file ở đường dẫn: $path');
    }
    final content = await file.readAsString();
    final chunks = _splitIntoChunks(content);

    final doc = ImportedDocument(
      id: const Uuid().v4(),
      novelId: novelId,
      name: path.split('/').last,
      sourcePath: path,
      chunkCount: chunks.length,
    );
    await db.upsertDocument(doc);
    for (var i = 0; i < chunks.length; i++) {
      await db.upsertDocumentChunk(DocumentChunk(
        id: const Uuid().v4(),
        documentId: doc.id,
        index: i,
        originalText: chunks[i],
      ));
    }
    return doc;
  }

  // Ưu tiên cắt tại ranh giới đoạn văn (dòng trống) để không cắt ngang
  // câu, giữ ngữ cảnh mỗi đoạn mạch lạc nhất có thể.
  List<String> _splitIntoChunks(String text) {
    final paragraphs = text.split(RegExp(r'\n\s*\n'));
    final chunks = <String>[];
    final buffer = StringBuffer();
    for (final p in paragraphs) {
      if (buffer.length + p.length > chunkSizeChars && buffer.isNotEmpty) {
        chunks.add(buffer.toString().trim());
        buffer.clear();
      }
      buffer.writeln(p);
      buffer.writeln();
    }
    if (buffer.isNotEmpty) chunks.add(buffer.toString().trim());
    return chunks.isEmpty ? [text] : chunks;
  }

  // Xử lý tuần tự từng đoạn, gọi onProgress sau mỗi đoạn để UI cập nhật
  // thanh tiến trình — có thể mất nhiều phút với tài liệu dài, người
  // dùng cần thấy đang chạy tới đâu chứ không phải màn hình treo.
  Future<void> processDocument({
    required ImportedDocument doc,
    required DocumentAction action,
    required AIProvider provider,
    String? customInstruction,
    bool resumeFromProgress = true,
    void Function(int done, int total)? onProgress,
  }) async {
    final chunks = await db.chunksForDocument(doc.id);
    final systemPrompt = action == DocumentAction.translate
        ? (customInstruction ?? 'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.')
        : (customInstruction ?? 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.');

    // ĐÃ SỬA: trước đây luôn xử lý lại TOÀN BỘ từ đoạn đầu tiên, kể cả
    // đoạn đã có kết quả từ lần chạy trước. Với tài liệu dài (hàng trăm
    // đoạn, có thể mất hàng chục phút), nếu app văng giữa chừng (lỗi
    // native khi generate — hiện CHƯA được cô lập như bước load QNN),
    // người dùng phải làm lại từ đầu, mất hết tiến độ đã có. Giờ mặc
    // định BỎ QUA đoạn đã có resultText, chỉ xử lý tiếp đoạn còn thiếu
    // — bấm lại nút xử lý sau khi app văng sẽ tiếp tục đúng chỗ dở dang
    // thay vì chạy lại từ đầu.
    var done = resumeFromProgress ? chunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length : 0;
    onProgress?.call(done, chunks.length);

    for (var i = 0; i < chunks.length; i++) {
      final chunk = chunks[i];
      if (resumeFromProgress && chunk.resultText != null && chunk.resultText!.isNotEmpty) {
        continue; // đã có kết quả từ lần chạy trước, bỏ qua
      }
      final result = await provider.generate(
        systemPrompt: systemPrompt,
        userPrompt: chunk.originalText,
        maxTokens: action == DocumentAction.translate ? 2000 : 400,
        temperature: 0.3,
      );
      chunk.resultText = result.trim();
      await db.upsertDocumentChunk(chunk);
      done++;
      onProgress?.call(done, chunks.length);
    }
  }

  // Ráp toàn bộ kết quả từng đoạn thành 1 file hoàn chỉnh.
  Future<File> exportResult(ImportedDocument doc, Directory outputDir) async {
    final chunks = await db.chunksForDocument(doc.id);
    final buffer = StringBuffer();
    for (final c in chunks) {
      buffer.writeln(c.resultText ?? '[Chưa xử lý đoạn ${c.index + 1}]');
      buffer.writeln();
    }
    final outFile = File('${outputDir.path}/${doc.name}_ket_qua.txt');
    return outFile.writeAsString(buffer.toString());
  }

  // Toàn văn tóm tắt các đoạn — dùng làm ngữ cảnh khi người dùng hỏi
  // đáp về tài liệu trong khung chat.
  Future<String> buildQaContext(ImportedDocument doc) async {
    final chunks = await db.chunksForDocument(doc.id);
    final buffer = StringBuffer('### Nội dung tài liệu "${doc.name}" (đã tóm tắt theo từng đoạn)\n');
    for (final c in chunks) {
      if (c.resultText != null) {
        buffer.writeln('- Đoạn ${c.index + 1}: ${c.resultText}');
      }
    }
    return buffer.toString();
  }
}
