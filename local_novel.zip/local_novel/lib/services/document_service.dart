import 'dart:io';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'database_service.dart';
import 'providers/local_provider.dart';

enum DocumentAction { translate, summarize }

// ĐÃ THÊM (2026-08-01, sau khi phát hiện qua log thật): sau 1 lần crash
// SIGSEGV THẬT SỰ trong lúc generate() (mục 62/63), trạng thái nội bộ
// của đối tượng `Llm` phía native CÓ THỂ bị hỏng (heap corruption) mà
// KHÔNG lập tức làm chết app — các lần generate() SAU ĐÓ vẫn "chạy xong,
// không crash" theo nghĩa kỹ thuật, nhưng trả về kết quả RỖNG hoặc CỰC
// NGẮN một cách bất thường (ví dụ 17 ký tự cho 1 đoạn văn 800+ ký tự) —
// và trước đây code vẫn LƯU những kết quả rác này vào DB, đánh dấu đoạn
// "đã xong" (dấu tick xanh) như thể dịch/tóm tắt thành công thật sự.
// Class này đại diện cho việc PHÁT HIỆN kết quả bất thường đó, để dừng
// vòng lặp xử lý nhiều đoạn NGAY LẬP TỨC thay vì tiếp tục chạy qua hàng
// chục đoạn khác cũng sẽ ra rác (vì trạng thái native đã hỏng), và KHÔNG
// lưu kết quả rác vào DB coi như đã xong.
class DocumentProcessingAnomalyException implements Exception {
  final int chunkIndex; // 0-based, ứng với DocumentChunk.index
  final String rawResult;
  final int sourceLength;
  DocumentProcessingAnomalyException({required this.chunkIndex, required this.rawResult, required this.sourceLength});

  @override
  String toString() =>
      'Đoạn ${chunkIndex + 1}: kết quả bất thường (${rawResult.length} ký tự cho nguồn dài $sourceLength ký tự) — '
      'rất có thể model bị lỗi native giữa chừng (xem log debug), ĐÃ DỪNG xử lý các đoạn còn lại để tránh lưu thêm kết quả rác.';
}

// Xử lý "cuốn chiếu": văn bản dài (có thể hàng trăm nghìn chữ) được
// chia thành nhiều đoạn nhỏ vừa với ngữ cảnh model, xử lý TUẦN TỰ từng
// đoạn (không gửi cả file cùng lúc — model local/API nào cũng có giới
// hạn context), rồi ráp kết quả từng đoạn lại thành file hoàn chỉnh.
// Dùng thuần dart:io để đọc file — không thêm package nào, tránh lặp
// lại các lỗi build đã gặp với file_picker/fllama.
class DocumentService {
  final DatabaseService db;
  DocumentService(this.db);

  static const int chunkSizeChars = 3000;

  Future<ImportedDocument> importFromPath(String path, {required String novelId}) async {
    final file = File(path);
    if (!await file.exists()) {
      throw Exception('Không tìm thấy file ở đường dẫn: $path');
    }
    final content = await file.readAsString();
    final chunks = _splitIntoChunks(content);

    final doc = ImportedDocument(
      id: const Uuid().v4(),
      novelId: novelId,
      name: path.split('/').last,
      sourcePath: path,
      chunkCount: chunks.length,
    );
    await db.upsertDocument(doc);
    for (var i = 0; i < chunks.length; i++) {
      await db.upsertDocumentChunk(DocumentChunk(
        id: const Uuid().v4(),
        documentId: doc.id,
        index: i,
        originalText: chunks[i],
      ));
    }
    return doc;
  }

  // Ưu tiên cắt tại ranh giới đoạn văn (dòng trống) để không cắt ngang
  // câu, giữ ngữ cảnh mỗi đoạn mạch lạc nhất có thể.
  List<String> _splitIntoChunks(String text) {
    final paragraphs = text.split(RegExp(r'\n\s*\n'));
    final chunks = <String>[];
    final buffer = StringBuffer();
    for (final p in paragraphs) {
      if (buffer.length + p.length > chunkSizeChars && buffer.isNotEmpty) {
        chunks.add(buffer.toString().trim());
        buffer.clear();
      }
      buffer.writeln(p);
      buffer.writeln();
    }
    if (buffer.isNotEmpty) chunks.add(buffer.toString().trim());
    return chunks.isEmpty ? [text] : chunks;
  }

  // Xử lý tuần tự từng đoạn, gọi onProgress sau mỗi đoạn để UI cập nhật
  // thanh tiến trình — có thể mất nhiều phút với tài liệu dài, người
  // dùng cần thấy đang chạy tới đâu chứ không phải màn hình treo.
  Future<void> processDocument({
    required ImportedDocument doc,
    required DocumentAction action,
    required AIProvider provider,
    String? customInstruction,
    bool resumeFromProgress = true,
    // Chọn phạm vi LIÊN TỤC (0-based, bao gồm cả 2 đầu) — null = từ đầu/tới cuối.
    int? startIndex,
    int? endIndex,
    // ĐÃ THÊM: chọn đoạn RỜI RẠC theo `DocumentChunk.index` cụ thể — dùng
    // cho màn hình chọn đoạn thủ công (`document_chunks_screen.dart`).
    // Khi có giá trị này, BỎ QUA startIndex/endIndex, và LUÔN xử lý lại
    // các đoạn được chọn (kể cả đã có resultText từ trước) — vì người
    // dùng chủ động chọn lại nghĩa là muốn làm lại đoạn đó (ví dụ: đoạn
    // từng bị crash dở, hoặc kết quả cũ chưa ưng ý).
    Set<int>? chunkIndices,
    bool Function()? isCancelled,
    void Function(int done, int total)? onProgress,
  }) async {
    final allChunks = await db.chunksForDocument(doc.id);
    final systemPrompt = action == DocumentAction.translate
        ? (customInstruction ?? 'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.')
        : (customInstruction ?? 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.');

    List<DocumentChunk> targetChunks;
    final bool explicitSelection = chunkIndices != null && chunkIndices.isNotEmpty;
    if (explicitSelection) {
      targetChunks = allChunks.where((c) => chunkIndices.contains(c.index)).toList();
    } else {
      final effectiveStart = (startIndex ?? 0).clamp(0, allChunks.isEmpty ? 0 : allChunks.length - 1);
      final effectiveEnd = (endIndex ?? (allChunks.length - 1)).clamp(effectiveStart, allChunks.isEmpty ? 0 : allChunks.length - 1);
      targetChunks = allChunks.isEmpty ? <DocumentChunk>[] : allChunks.sublist(effectiveStart, effectiveEnd + 1);
    }

    // Chọn thủ công = luôn làm lại, không áp dụng resumeFromProgress skip.
    final effectiveResume = resumeFromProgress && !explicitSelection;
    var done = effectiveResume ? targetChunks.where((c) => c.resultText != null && c.resultText!.isNotEmpty).length : 0;
    onProgress?.call(done, targetChunks.length);

    // ĐÃ THÊM: bọc cả vòng lặp nhiều đoạn bằng beginPipeline/endPipeline
    // (đã có sẵn, trước đây chỉ dùng cho TranslationService) thay vì để
    // MỖI đoạn tự bật/tắt Foreground Service riêng qua generate() — với
    // tài liệu dài (hàng trăm đoạn), bật/tắt liên tục tạo khe hở giữa các
    // đoạn có thể bị Android trừ tiến trình nếu tắt màn hình đúng lúc đó.
    // Chỉ áp dụng khi provider là LocalLlamaProvider — provider cloud API
    // không cần Foreground Service (không có xử lý native tốn pin/CPU).
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) {
      await LocalLlamaProvider.beginPipeline(
        action == DocumentAction.translate ? 'Đang dịch tài liệu...' : 'Đang tóm tắt tài liệu...',
      );
    }

    try {
      for (var i = 0; i < targetChunks.length; i++) {
        if (isCancelled?.call() ?? false) break;
        final chunk = targetChunks[i];
        if (effectiveResume && chunk.resultText != null && chunk.resultText!.isNotEmpty) {
          continue; // đã có kết quả từ lần chạy trước, bỏ qua
        }
        if (isLocal) {
          await LocalLlamaProvider.updatePipelineStage('Đang xử lý đoạn ${chunk.index + 1}/${allChunks.length}...');
        }
        final result = await provider.generate(
          systemPrompt: systemPrompt,
          userPrompt: chunk.originalText,
          maxTokens: action == DocumentAction.translate ? 2000 : 400,
          temperature: 0.3,
        );
        final resultTrimmed = result.trim();
        // ĐÃ THÊM: kiểm tra tính hợp lý của kết quả TRƯỚC KHI lưu — xem
        // giải thích đầy đủ ở định nghĩa DocumentProcessingAnomalyException
        // phía trên. Ngưỡng 15%: bản dịch/tóm tắt hợp lý gần như không bao
        // giờ ngắn hơn 15% độ dài nguồn (kể cả tóm tắt rất súc tích) — chỉ
        // áp dụng khi nguồn đủ dài (>50 ký tự) để tránh báo nhầm ở đoạn
        // ngắn hợp lệ.
        final sourceLen = chunk.originalText.trim().length;
        final looksCorrupted = resultTrimmed.isEmpty || (sourceLen > 50 && resultTrimmed.length < sourceLen * 0.15);
        if (looksCorrupted) {
          throw DocumentProcessingAnomalyException(chunkIndex: chunk.index, rawResult: resultTrimmed, sourceLength: sourceLen);
        }
        chunk.resultText = resultTrimmed;
        await db.upsertDocumentChunk(chunk);
        done++;
        onProgress?.call(done, targetChunks.length);
      }
    } finally {
      if (isLocal) await LocalLlamaProvider.endPipeline();
    }
  }

  // Ráp toàn bộ kết quả từng đoạn thành 1 file hoàn chỉnh.
  Future<File> exportResult(ImportedDocument doc, Directory outputDir) async {
    final chunks = await db.chunksForDocument(doc.id);
    final buffer = StringBuffer();
    for (final c in chunks) {
      buffer.writeln(c.resultText ?? '[Chưa xử lý đoạn ${c.index + 1}]');
      buffer.writeln();
    }
    final outFile = File('${outputDir.path}/${doc.name}_ket_qua.txt');
    return outFile.writeAsString(buffer.toString());
  }

  // Toàn văn tóm tắt các đoạn — dùng làm ngữ cảnh khi người dùng hỏi
  // đáp về tài liệu trong khung chat.
  Future<String> buildQaContext(ImportedDocument doc) async {
    final chunks = await db.chunksForDocument(doc.id);
    final buffer = StringBuffer('### Nội dung tài liệu "${doc.name}" (đã tóm tắt theo từng đoạn)\n');
    for (final c in chunks) {
      if (c.resultText != null) {
        buffer.writeln('- Đoạn ${c.index + 1}: ${c.resultText}');
      }
    }
    return buffer.toString();
  }
}
