import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

// Interface chung: biến một đoạn văn bản thành vector số để so sánh
// mức độ liên quan bằng cosine similarity.
abstract class EmbeddingService {
  Future<List<double>> embed(String text);
}

// Dùng endpoint /embedding có sẵn trong llama-server (llama.cpp) khi
// model local hỗ trợ sinh embedding thật. Chính xác hơn hẳn so với
// khớp từ khóa vì bắt được các câu diễn đạt khác nhau nhưng cùng ý.
// LƯU Ý: lớp này hiện KHÔNG được gọi ở đâu trong app kể từ khi chuyển
// sang kiến trúc nhúng thẳng qua fllama (không còn llama-server độc lập
// để gọi endpoint /embedding). Giữ lại cho trường hợp mở rộng sau này
// nếu quay lại dùng chế độ server, hoặc nếu fllama expose API embedding
// ở bản mới hơn. Hiện tại RagService dùng HashingEmbeddingService.
class LocalEmbeddingService implements EmbeddingService {
  final String baseUrl;
  LocalEmbeddingService({this.baseUrl = 'http://127.0.0.1:8080'});

  @override
  Future<List<double>> embed(String text) async {
    final res = await http
        .post(
          Uri.parse('$baseUrl/embedding'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'content': text}),
        )
        .timeout(const Duration(seconds: 10));
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    // llama-server có thể trả về {"embedding": [...]} hoặc [{"embedding": [...]}]
    final raw = data is List ? data[0]['embedding'] : data['embedding'];
    return (raw as List).map((e) => (e as num).toDouble()).toList();
  }
}

// Dự phòng khi không có model embedding thật (dùng Anthropic API, hoặc
// local server không bật embedding): vector "hashing trick" — băm từng
// từ vào một chỉ số cố định trong vector 256 chiều, đếm tần suất, rồi
// chuẩn hóa. Không "hiểu" ngữ nghĩa sâu như embedding model thật, nhưng
// vẫn bắt được các đoạn dùng chung nhiều từ vựng — chạy 100% offline,
// không phụ thuộc bất kỳ model hay mạng nào, tốc độ tức thời.
class HashingEmbeddingService implements EmbeddingService {
  static const int dimensions = 256;

  @override
  Future<List<double>> embed(String text) async {
    final vector = List<double>.filled(dimensions, 0);
    final words = text
        .toLowerCase()
        .replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), ' ')
        .split(RegExp(r'\s+'))
        .where((w) => w.length > 1);
    for (final w in words) {
      final idx = w.hashCode.abs() % dimensions;
      vector[idx] += 1;
    }
    final norm = sqrt(vector.fold<double>(0, (s, v) => s + v * v));
    if (norm == 0) return vector;
    return vector.map((v) => v / norm).toList();
  }
}

double cosineSimilarity(List<double> a, List<double> b) {
  if (a.isEmpty || b.isEmpty || a.length != b.length) return 0;
  double dot = 0, normA = 0, normB = 0;
  for (var i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA == 0 || normB == 0) return 0;
  return dot / (sqrt(normA) * sqrt(normB));
}
