import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path_provider/path_provider.dart';
import '../models/story_models.dart';

// Xuất bản là điểm yếu chung của các app viết truyện AI hiện nay (kể cả
// Sudowrite, NovelAI) — hầu hết không có EPUB/DOCX. Service này tự dựng
// cấu trúc file thay vì phụ thuộc dịch vụ ngoài, nên chạy được hoàn
// toàn offline, đúng tinh thần của app.
class ExportService {
  Future<Directory> _outputDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final out = Directory('${dir.path}/exports');
    if (!await out.exists()) await out.create(recursive: true);
    return out;
  }

  String _escapeXml(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');

  // ---------- TXT ----------
  Future<File> exportTxt({required String title, required List<Chapter> chapters}) async {
    final buffer = StringBuffer('$title\n\n');
    for (final c in chapters) {
      buffer.writeln('Chương ${c.number}: ${c.title}');
      buffer.writeln();
      buffer.writeln(c.content);
      buffer.writeln('\n----------\n');
    }
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(title)}.txt');
    return file.writeAsString(buffer.toString());
  }

  // ---------- EPUB ----------
  Future<File> exportEpub({
    required String title,
    required String author,
    required List<Chapter> chapters,
  }) async {
    final archive = Archive();

    // mimetype phải là file đầu tiên và KHÔNG nén — yêu cầu bắt buộc
    // của chuẩn EPUB để reader nhận diện đúng định dạng.
    final mimetypeBytes = utf8.encode('application/epub+zip');
    // Lưu ý: chuẩn EPUB khuyến nghị mimetype không nén, nhưng archive 4.x
    // không còn expose thuộc tính compress trên ArchiveFile như bản 3.x —
    // hầu hết trình đọc EPUB vẫn chấp nhận file nén, chấp nhận đánh đổi
    // nhỏ này để tránh lỗi build.
    final mimetypeFile = ArchiveFile('mimetype', mimetypeBytes.length, mimetypeBytes);
    archive.addFile(mimetypeFile);

    _addString(archive, 'META-INF/container.xml', '''
<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>''');

    final manifestItems = StringBuffer();
    final spineItems = StringBuffer();
    final navPoints = StringBuffer();

    for (var i = 0; i < chapters.length; i++) {
      final c = chapters[i];
      final id = 'chap${i + 1}';
      final fileName = 'chapter_${(i + 1).toString().padLeft(4, '0')}.xhtml';
      manifestItems.writeln(
          '<item id="$id" href="$fileName" media-type="application/xhtml+xml"/>');
      spineItems.writeln('<itemref idref="$id"/>');
      navPoints.writeln('''
<navPoint id="nav$id" playOrder="${i + 1}">
  <navLabel><text>${_escapeXml('Chương ${c.number}: ${c.title}')}</text></navLabel>
  <content src="$fileName"/>
</navPoint>''');

      final paragraphs = c.content
          .split(RegExp(r'\n\s*\n'))
          .where((p) => p.trim().isNotEmpty)
          .map((p) => '<p>${_escapeXml(p.trim())}</p>')
          .join('\n');

      _addString(archive, 'OEBPS/$fileName', '''
<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>${_escapeXml(c.title)}</title></head>
<body>
<h1>${_escapeXml('Chương ${c.number}: ${c.title}')}</h1>
$paragraphs
</body>
</html>''');
    }

    _addString(archive, 'OEBPS/content.opf', '''
<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid" version="2.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:title>${_escapeXml(title)}</dc:title>
    <dc:creator>${_escapeXml(author)}</dc:creator>
    <dc:language>vi</dc:language>
    <dc:identifier id="bookid">urn:uuid:${DateTime.now().millisecondsSinceEpoch}</dc:identifier>
  </metadata>
  <manifest>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    $manifestItems
  </manifest>
  <spine toc="ncx">
    $spineItems
  </spine>
</package>''');

    _addString(archive, 'OEBPS/toc.ncx', '''
<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="urn:uuid:${DateTime.now().millisecondsSinceEpoch}"/>
  </head>
  <docTitle><text>${_escapeXml(title)}</text></docTitle>
  <navMap>
    $navPoints
  </navMap>
</ncx>''');

    final zipBytes = ZipEncoder().encode(archive)!;
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(title)}.epub');
    await file.writeAsBytes(zipBytes);
    return file;
  }

  // ---------- DOCX ----------
  // Cấu trúc tối giản (không style nâng cao) nhưng đủ chuẩn OOXML để
  // Word / Google Docs / LibreOffice mở được không báo lỗi.
  Future<File> exportDocx({
    required String title,
    required List<Chapter> chapters,
  }) async {
    final archive = Archive();

    _addString(archive, '[Content_Types].xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>''');

    _addString(archive, '_rels/.rels', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>''');

    final body = StringBuffer();
    body.writeln('<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>${_escapeXml(title)}</w:t></w:r></w:p>');
    for (final c in chapters) {
      body.writeln(
          '<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>${_escapeXml('Chương ${c.number}: ${c.title}')}</w:t></w:r></w:p>');
      final paragraphs = c.content.split(RegExp(r'\n\s*\n')).where((p) => p.trim().isNotEmpty);
      for (final p in paragraphs) {
        body.writeln('<w:p><w:r><w:t xml:space="preserve">${_escapeXml(p.trim())}</w:t></w:r></w:p>');
      }
    }

    _addString(archive, 'word/document.xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    $body
  </w:body>
</w:document>''');

    final zipBytes = ZipEncoder().encode(archive)!;
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(title)}.docx');
    await file.writeAsBytes(zipBytes);
    return file;
  }

  void _addString(Archive archive, String path, String content) {
    final bytes = utf8.encode(content);
    archive.addFile(ArchiveFile(path, bytes.length, bytes));
  }

  String _safeFileName(String s) => s.replaceAll(RegExp(r'[^\w\s-]'), '').trim().replaceAll(' ', '_');
}
