import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path_provider/path_provider.dart';
import '../models/story_models.dart';

// Xuất bản là điểm yếu chung của các app viết truyện AI hiện nay (kể cả
// Sudowrite, NovelAI) — hầu hết không có EPUB/DOCX. Service này tự dựng
// cấu trúc file thay vì phụ thuộc dịch vụ ngoài, nên chạy được hoàn
// toàn offline, đúng tinh thần của app.
class ExportService {
  Future<Directory> _outputDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final out = Directory('${dir.path}/exports');
    if (!await out.exists()) await out.create(recursive: true);
    return out;
  }

  String _escapeXml(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');

  // ---------- TXT ----------
  Future<File> exportTxt({required String title, required List<Chapter> chapters}) async {
    final buffer = StringBuffer('$title\n\n');
    for (final c in chapters) {
      buffer.writeln('Chương ${c.number}: ${c.title}');
      buffer.writeln();
      buffer.writeln(c.content);
      buffer.writeln('\n----------\n');
    }
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(title)}.txt');
    return file.writeAsString(buffer.toString());
  }

  // Sinh ảnh bìa đơn giản (gradient + tên truyện + tác giả) bằng dart:ui —
  // không cần người dùng tự chuẩn bị ảnh bìa (app không có tính năng chọn
  // ảnh — đã cố tình bỏ file_picker vì lịch sử lỗi build, xem pubspec.yaml).
  // Không phải bìa nghệ thuật, nhưng hơn hẳn EPUB không có bìa nào.
  Future<Uint8List> _generateCoverPngBytes(String title, String author) async {
    const width = 900.0;
    const height = 1350.0;
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder, const ui.Rect.fromLTWH(0, 0, width, height));

    final bgPaint = ui.Paint()
      ..shader = ui.Gradient.linear(
        const ui.Offset(0, 0),
        const ui.Offset(width, height),
        [const ui.Color(0xFF2A1414), const ui.Color(0xFFA32D2D)],
      );
    canvas.drawRect(const ui.Rect.fromLTWH(0, 0, width, height), bgPaint);

    // Viền trang trí đơn giản cho đỡ trống trải.
    final borderPaint = ui.Paint()
      ..color = const ui.Color(0x33FFFFFF)
      ..style = ui.PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawRect(const ui.Rect.fromLTWH(40, 40, width - 80, height - 80), borderPaint);

    void drawCenteredText(String text, double fontSize, double centerY, {ui.Color color = const ui.Color(0xFFFFFFFF), bool bold = false}) {
      final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
        textAlign: ui.TextAlign.center,
        fontWeight: bold ? ui.FontWeight.bold : ui.FontWeight.normal,
        maxLines: 6,
      ))
        ..pushStyle(ui.TextStyle(color: color, fontSize: fontSize))
        ..addText(text);
      final paragraph = builder.build()..layout(const ui.ParagraphConstraints(width: width - 140));
      canvas.drawParagraph(paragraph, ui.Offset(70, centerY - paragraph.height / 2));
    }

    drawCenteredText(title, 58, height * 0.42, bold: true);
    if (author.trim().isNotEmpty) {
      drawCenteredText(author, 30, height * 0.58, color: const ui.Color(0xCCFFFFFF));
    }

    final picture = recorder.endRecording();
    final image = await picture.toImage(width.toInt(), height.toInt());
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    return byteData!.buffer.asUint8List();
  }

  // ---------- EPUB ----------
  Future<File> exportEpub({
    required String title,
    required String author,
    required List<Chapter> chapters,
  }) async {
    final archive = Archive();

    // mimetype phải là file đầu tiên và KHÔNG nén — yêu cầu bắt buộc
    // của chuẩn EPUB để reader nhận diện đúng định dạng.
    final mimetypeBytes = utf8.encode('application/epub+zip');
    // Lưu ý: chuẩn EPUB khuyến nghị mimetype không nén, nhưng archive 4.x
    // không còn expose thuộc tính compress trên ArchiveFile như bản 3.x —
    // hầu hết trình đọc EPUB vẫn chấp nhận file nén, chấp nhận đánh đổi
    // nhỏ này để tránh lỗi build.
    final mimetypeFile = ArchiveFile('mimetype', mimetypeBytes.length, mimetypeBytes);
    archive.addFile(mimetypeFile);

    _addString(archive, 'META-INF/container.xml', '''
<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>''');

    // Ảnh bìa — tự sinh bằng dart:ui, không cần người dùng chuẩn bị sẵn.
    final coverBytes = await _generateCoverPngBytes(title, author);
    archive.addFile(ArchiveFile('OEBPS/cover.png', coverBytes.length, coverBytes));
    _addString(archive, 'OEBPS/cover.xhtml', '''
<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Bìa</title></head>
<body style="margin:0;text-align:center;">
  <img src="cover.png" alt="${_escapeXml(title)}" style="max-width:100%;height:auto;"/>
</body>
</html>''');

    final manifestItems = StringBuffer();
    final spineItems = StringBuffer();
    final navPoints = StringBuffer();
    final navListItems = StringBuffer();

    for (var i = 0; i < chapters.length; i++) {
      final c = chapters[i];
      final id = 'chap${i + 1}';
      final fileName = 'chapter_${(i + 1).toString().padLeft(4, '0')}.xhtml';
      final label = 'Chương ${c.number}: ${c.title}';
      manifestItems.writeln(
          '<item id="$id" href="$fileName" media-type="application/xhtml+xml"/>');
      spineItems.writeln('<itemref idref="$id"/>');
      navPoints.writeln('''
<navPoint id="nav$id" playOrder="${i + 2}">
  <navLabel><text>${_escapeXml(label)}</text></navLabel>
  <content src="$fileName"/>
</navPoint>''');
      navListItems.writeln('<li><a href="$fileName">${_escapeXml(label)}</a></li>');

      final paragraphs = c.content
          .split(RegExp(r'\n\s*\n'))
          .where((p) => p.trim().isNotEmpty)
          .map((p) => '<p>${_escapeXml(p.trim())}</p>')
          .join('\n');

      _addString(archive, 'OEBPS/$fileName', '''
<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>${_escapeXml(c.title)}</title></head>
<body>
<h1>${_escapeXml(label)}</h1>
$paragraphs
</body>
</html>''');
    }

    // Trang "Mục lục" THẬT — nằm ngay trong nội dung sách (không chỉ dựa
    // vào bảng điều hướng riêng của app đọc sách), nhấp được từng chương,
    // là trang đầu tiên sau bìa khi mở sách.
    _addString(archive, 'OEBPS/nav.xhtml', '''
<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>Mục lục</title></head>
<body>
<nav epub:type="toc" id="toc">
<h1>Mục lục</h1>
<ol>
$navListItems
</ol>
</nav>
</body>
</html>''');

    _addString(archive, 'OEBPS/content.opf', '''
<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid" version="3.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">
    <dc:title>${_escapeXml(title)}</dc:title>
    <dc:creator>${_escapeXml(author)}</dc:creator>
    <dc:language>vi</dc:language>
    <dc:identifier id="bookid">urn:uuid:${DateTime.now().millisecondsSinceEpoch}</dc:identifier>
    <meta property="dcterms:modified">${DateTime.now().toUtc().toIso8601String().split('.').first}Z</meta>
    <meta name="cover" content="cover-img"/>
  </metadata>
  <manifest>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="cover-img" href="cover.png" media-type="image/png" properties="cover-image"/>
    <item id="cover-page" href="cover.xhtml" media-type="application/xhtml+xml"/>
    $manifestItems
  </manifest>
  <spine toc="ncx">
    <itemref idref="cover-page"/>
    <itemref idref="nav"/>
    $spineItems
  </spine>
</package>''');

    _addString(archive, 'OEBPS/toc.ncx', '''
<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="urn:uuid:${DateTime.now().millisecondsSinceEpoch}"/>
  </head>
  <docTitle><text>${_escapeXml(title)}</text></docTitle>
  <navMap>
    <navPoint id="navtoc" playOrder="1">
      <navLabel><text>Mục lục</text></navLabel>
      <content src="nav.xhtml"/>
    </navPoint>
    $navPoints
  </navMap>
</ncx>''');

    final zipBytes = ZipEncoder().encode(archive)!;
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(title)}.epub');
    await file.writeAsBytes(zipBytes);
    return file;
  }

  // ---------- DOCX ----------
  // Cấu trúc tối giản (không style nâng cao) nhưng đủ chuẩn OOXML để
  // Word / Google Docs / LibreOffice mở được không báo lỗi.
  Future<File> exportDocx({
    required String title,
    required List<Chapter> chapters,
  }) async {
    final archive = Archive();

    _addString(archive, '[Content_Types].xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>''');

    _addString(archive, '_rels/.rels', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>''');

    final body = StringBuffer();
    body.writeln('<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>${_escapeXml(title)}</w:t></w:r></w:p>');
    for (final c in chapters) {
      body.writeln(
          '<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>${_escapeXml('Chương ${c.number}: ${c.title}')}</w:t></w:r></w:p>');
      final paragraphs = c.content.split(RegExp(r'\n\s*\n')).where((p) => p.trim().isNotEmpty);
      for (final p in paragraphs) {
        body.writeln('<w:p><w:r><w:t xml:space="preserve">${_escapeXml(p.trim())}</w:t></w:r></w:p>');
      }
    }

    _addString(archive, 'word/document.xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    $body
  </w:body>
</w:document>''');

    final zipBytes = ZipEncoder().encode(archive)!;
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(title)}.docx');
    await file.writeAsBytes(zipBytes);
    return file;
  }

  // ---------- Xuất đoạn hội thoại chat ----------
  // Trước đây chỉ xuất được Chương; nay thêm xuất cả 1 cửa sổ chat (hỏi
  // đáp với trợ lý AI) ra file — dùng khi người dùng muốn lưu lại một
  // đoạn tư vấn cốt truyện hay hỏi đáp tài liệu để đọc lại/chia sẻ.
  Future<File> exportChatSessionTxt({
    required String sessionName,
    required List<ChatMessageRecord> messages,
  }) async {
    final buffer = StringBuffer('$sessionName\n\n');
    for (final m in messages) {
      final speaker = m.fromUser ? 'Bạn' : (m.providerLabel != null ? 'AI (${m.providerLabel})' : 'AI');
      buffer.writeln('$speaker:');
      buffer.writeln(m.text);
      buffer.writeln();
    }
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(sessionName)}_chat.txt');
    return file.writeAsString(buffer.toString());
  }

  Future<File> exportChatSessionDocx({
    required String sessionName,
    required List<ChatMessageRecord> messages,
  }) async {
    final archive = Archive();

    _addString(archive, '[Content_Types].xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>''');

    _addString(archive, '_rels/.rels', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>''');

    final body = StringBuffer();
    body.writeln('<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>${_escapeXml(sessionName)}</w:t></w:r></w:p>');
    for (final m in messages) {
      final speaker = m.fromUser ? 'Bạn' : (m.providerLabel != null ? 'AI (${m.providerLabel})' : 'AI');
      body.writeln('<w:p><w:pPr><w:pStyle w:val="Heading2"/></w:pPr><w:r><w:t>${_escapeXml(speaker)}</w:t></w:r></w:p>');
      body.writeln('<w:p><w:r><w:t xml:space="preserve">${_escapeXml(m.text)}</w:t></w:r></w:p>');
    }

    _addString(archive, 'word/document.xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    $body
  </w:body>
</w:document>''');

    final zipBytes = ZipEncoder().encode(archive)!;
    final dir = await _outputDir();
    final file = File('${dir.path}/${_safeFileName(sessionName)}_chat.docx');
    await file.writeAsBytes(zipBytes);
    return file;
  }

  void _addString(Archive archive, String path, String content) {
    final bytes = utf8.encode(content);
    archive.addFile(ArchiveFile(path, bytes.length, bytes));
  }

  String _safeFileName(String s) => s.replaceAll(RegExp(r'[^\w\s-]'), '').trim().replaceAll(' ', '_');
}
