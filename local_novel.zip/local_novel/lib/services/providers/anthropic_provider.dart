import 'dart:convert';
import 'package:http/http.dart' as http;
import '../ai_provider.dart';

// Provider gọi Anthropic API (Claude) trực tiếp từ app bằng API key
// người dùng tự nhập trong Cài đặt. Key lưu bằng flutter_secure_storage,
// không gửi đi đâu ngoài api.anthropic.com.
//
// Lưu ý quan trọng: đây là API chính thức của Anthropic, nên mọi request
// vẫn tuân theo chính sách sử dụng nội dung của Anthropic ở phía server —
// app không có cách nào và không nên tìm cách bỏ qua điều đó. Nếu người
// dùng cần viết nội dung không phù hợp với chính sách của một nhà cung
// cấp cụ thể, lựa chọn hợp lý là dùng model local thay vì cố "lách" API.
class AnthropicProvider implements AIProvider {
  final String apiKey;
  final String modelId;

  AnthropicProvider({required this.apiKey, this.modelId = 'claude-sonnet-5'});

  @override
  String get name => 'Anthropic API (Claude)';

  @override
  String get description => 'Chất lượng văn cao, cần API key và kết nối mạng, tính phí theo token.';

  @override
  Future<bool> isReady() async => apiKey.isNotEmpty;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      };

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) async {
    final res = await http.post(
      Uri.parse('https://api.anthropic.com/v1/messages'),
      headers: _headers,
      body: jsonEncode({
        'model': modelId,
        'system': systemPrompt,
        'messages': [
          {'role': 'user', 'content': userPrompt}
        ],
        'temperature': temperature,
        'max_tokens': maxTokens,
        // Anthropic Messages API hỗ trợ thẳng top_p/top_k (khác OpenAI).
        // repetition_penalty không phải tham số của API này nên không gửi —
        // giữ tham số trong signature chỉ để khớp interface AIProvider dùng
        // chung cho mọi provider (local + cloud).
        'top_p': topP,
        'top_k': topK,
      }),
    );
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    if (res.statusCode != 200) {
      throw Exception('Lỗi Anthropic API: ${data['error']?['message'] ?? res.body}');
    }
    return (data['content'] as List).map((b) => b['text'] ?? '').join();
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false, // không dùng — chỉ có ý nghĩa với LocalLlamaProvider
  }) async* {
    final req = http.Request('POST', Uri.parse('https://api.anthropic.com/v1/messages'));
    req.headers.addAll(_headers);
    req.body = jsonEncode({
      'model': modelId,
      'system': systemPrompt,
      'messages': [
        {'role': 'user', 'content': userPrompt}
      ],
      'temperature': temperature,
      'max_tokens': maxTokens,
      'top_p': topP,
      'top_k': topK,
      'stream': true,
    });
    final streamed = await req.send();
    await for (final chunk in streamed.stream.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (!line.startsWith('data: ')) continue;
        final payload = line.substring(6).trim();
        if (payload.isEmpty) continue;
        try {
          final data = jsonDecode(payload);
          if (data['type'] == 'content_block_delta') {
            final text = data['delta']?['text'];
            if (text != null) yield text as String;
          }
        } catch (_) {}
      }
    }
  }
}
