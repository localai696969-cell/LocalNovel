import 'package:lib_llama_cpp/lib_llama_cpp.dart';
import '../ai_provider.dart';

// Chạy model NHÚNG THẲNG trong tiến trình app qua FFI, dùng lib_llama_cpp
// (published trên pub.dev, có isolate riêng cho suy luận, API dạng
// "OpenAI-shaped" rõ ràng hơn nhiều so với fllama).
//
// LƯU Ý QUAN TRỌNG: tôi không có thiết bị thật để tự kiểm thử gói này —
// nếu build lỗi do sai tên field/tham số, gửi log lỗi để chỉnh đúng theo
// API thật của phiên bản đã cài, giống cách đã sửa các lỗi build trước.
//
// Tham số threads/contextSize/numGpuLayers hiện CHƯA được truyền vào
// LlamaModelConfig vì chưa xác nhận chắc chắn tên field đúng — ưu tiên
// làm cho việc load model chạy được trước, tinh chỉnh tốc độ sau khi đã
// xác nhận luồng cơ bản hoạt động.
class LocalLlamaProvider implements AIProvider {
  final String modelPath;
  final int threads;
  final int contextSize;
  final int numGpuLayers;

  LocalLlamaProvider({
    required this.modelPath,
    this.threads = 4,
    this.contextSize = 2048,
    this.numGpuLayers = 99,
  });

  @override
  String get name => 'AI local (nhúng trong APK)';

  @override
  String get description => 'Chạy hoàn toàn offline, ngay trong app, không cần server hay Termux.';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  LlamaOpenAIClient _buildClient() => LlamaOpenAIClient(
        models: {'local': LlamaModelConfig(modelPath: modelPath)},
      );

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
  }) async {
    final client = _buildClient();
    final response = await client.responses.create(
      model: 'local',
      input: '$systemPrompt\n\n$userPrompt',
    );
    return response.outputText;
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
  }) async* {
    final client = _buildClient();
    final combined = '$systemPrompt\n\n$userPrompt';
    await for (final event in client.responses.stream(model: 'local', input: combined)) {
      if (event case LlamaResponseOutputTextDelta(:final delta)) {
        yield delta;
      }
    }
  }
}
