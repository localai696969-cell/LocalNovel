import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import '../ai_provider.dart';
import '../debug_log_service.dart';
import '../settings_service.dart';

// Gọi vào tầng native (MNN-LLM + QNN) qua Platform Channel — KHÔNG dùng
// dart:ffi nữa (loại bỏ tận gốc lỗi "libllama.so not found" trước đây).
//
// slot: 0 = model chính, 1 = model dịch thuật trung gian (dùng bởi
// TranslationService) — 2 slot độc lập, có thể cùng tồn tại trong RAM
// nếu máy đủ khỏe, xem device_profile_service.dart để biết máy có nên
// giữ cả 2 hay không.
class LocalLlamaProvider implements AIProvider {
  static const _methodChannel = MethodChannel('com.localnovel/mnn_method');
  static const _eventChannel = EventChannel('com.localnovel/mnn_stream');

  // ĐÃ THÊM (2026-09-05): ngưỡng "không tiến triển" để ensureLoaded() coi
  // 1 slot đang generate là mồ côi/treo THẬT — xem giải thích đầy đủ ở
  // ensureLoaded(). Cố tình khá rộng rãi (3 phút KHÔNG có token mới nào,
  // không phải 3 phút tổng thời gian chạy) vì: (1) prompt dài + ngữ cảnh
  // Story Bible có thể khiến bước prefill (trước token đầu tiên) mất tới
  // 1-2 phút trên máy yếu; (2) model 8B đã xác nhận vốn chậm ở tầng tính
  // toán cốt lõi (xem ghi chú xoá lớp trì trệ theo elapsed-time cũ ở
  // mnn_bridge.cpp) — 1 khoảng lặng vài chục giây giữa 2 token là bình
  // thường, KHÔNG phải dấu hiệu treo.
  static const _stalledThreshold = Duration(minutes: 3);

  // ĐÃ THÊM (theo yêu cầu người dùng: "sao tác vụ nền không báo có bất cứ
  // cái gì hết" khi 1 lệnh generate() mồ côi từ phiên TRƯỚC vẫn đang chạy
  // dưới native — đúng, `BackgroundTaskManager` chỉ là 1 List trong RAM
  // của phiên HIỆN TẠI, không có cách nào tự biết về việc đó). Hỏi thẳng
  // native — nơi DUY NHẤT còn giữ đúng sự thật slot có đang bận hay
  // không — dùng ở `background_tasks_screen.dart` để hiện đúng tình
  // trạng thay vì im lặng khó hiểu.
  static Future<bool> isSlotGenerating(int slot) async {
    try {
      final busy = await _methodChannel.invokeMethod<bool>('isSlotGenerating', {'slot': slot});
      return busy ?? false;
    } catch (_) {
      return false; // không hỏi được (vd lỗi kênh) — coi như không chắc, đừng doạ người dùng vô căn cứ
    }
  }

  // ĐÃ THÊM: cho phép huỷ 1 slot TỪ BÊN NGOÀI vòng đời của chính
  // provider/instance đang giữ nó — cần cho trường hợp "tác vụ mồ côi"
  // (`background_tasks_screen.dart`): không còn `LocalLlamaProvider`
  // instance nào của phiên trước để gọi `generateStream()`/`finally` như
  // bình thường, nhưng lệnh `cancelGenerate` chỉ cần đúng số `slot`, không
  // cần instance — gọi thẳng method channel là đủ.
  static Future<void> requestCancelSlot(int slot) async {
    try {
      await _methodChannel.invokeMethod('cancelGenerate', {'slot': slot});
    } catch (_) {
      // Bỏ qua — nơi gọi (`background_tasks_screen.dart`) đã tự hỏi lại
      // trạng thái sau đó để biết có thành công hay không, không cần ném
      // lỗi lên đây.
    }
  }

  // ĐÃ THÊM (2026-09-01 — theo yêu cầu người dùng: dọn cache autotuning
  // OpenCL "khi thoát hẳn ứng dụng thậm chí khi đổi model" thay vì mỗi
  // lần nạp — xem giải thích đầy đủ ở mnn_bridge.cpp, buildOptimizedOpenCLConfig
  // + nativeEnforceOpenCLCacheCap): gọi ĐÚNG 1 lần, ngay TRƯỚC
  // `SystemNavigator.pop()` trong `main.dart`, sau khi đã huỷ + đợi lưu
  // xong 2 slot. `await` ở đây là CỐ Ý (không bỏ qua) — bên native cũng
  // cố ý chạy đồng bộ để đảm bảo dọn xong THẬT trước khi tiến trình bị
  // đóng, không phải "bắn lệnh rồi thoát ngay" như lỗi đã sửa ở chính
  // đoạn exit này trước đây (xem comment ở main.dart).
  static Future<void> cleanupCacheOnExit() async {
    try {
      await _methodChannel.invokeMethod('cleanupCacheOnExit');
    } catch (_) {
      // Bỏ qua — app đang thoát, không còn chỗ nào để báo lỗi này cho
      // người dùng nữa, và không dọn được lần này thì lần dọn SAU (lần
      // đổi model kế tiếp, hoặc lần thoát app kế tiếp) vẫn sẽ thử lại.
    }
  }

  final String modelPath; // đường dẫn THƯ MỤC model MNN export
  final int slot;
  // ĐÃ THÊM (v15 — `backendPreference` giờ RIÊNG TỪNG TRUYỆN, xem
  // `SettingsService`/`story_models.dart`): provider cần biết đang phục
  // vụ TRUYỆN NÀO để đọc đúng cấu hình backend của truyện đó. NULLABLE vì
  // slot dịch thuật (slot=1, `TranslationService`) đôi khi được tạo trước
  // khi có `novelId` rõ ràng trong tay — khi đó rơi về
  // `loadActiveNovelId()` (truyện đang mở trên máy) làm căn cứ, xem
  // `_resolveBackendPreference()` bên dưới — cùng cách xử lý đã dùng ở
  // `BackgroundTaskManager._currentConcurrencyCap()`.
  final String? novelId;
  String? _activeBackend;
  bool _loaded = false;
  String? _loadedPath;

  LocalLlamaProvider({required this.modelPath, this.slot = 0, this.novelId});

  // ĐÃ THÊM — mục AV, 2026-09-15 — theo đúng yêu cầu người dùng: hardcode
  // khuôn chat theo TÊN model (mục AT/AU từng cân nhắc) nghĩa là mỗi lần
  // thêm model mới lại phải sửa code + build lại GitHub Actions — không
  // ai muốn vậy. Giải pháp đúng: chính `llm_config.json` của MỌI model
  // MNN (không riêng model nào) đã có sẵn đúng khuôn chat của model đó,
  // do công cụ xuất model (`llmexport.py`) tự trích từ model gốc lúc xuất
  // — xác nhận qua tài liệu MNN chính thức, xem mục AQ. App tự đọc file
  // này NGAY TRÊN MÁY, không cần biết trước là model gì — thêm model mới
  // chỉ cần copy đúng thư mục model (đã có sẵn `llm_config.json` đúng),
  // không cần đụng tới code/build lại app.
  // Cache theo `modelPath` — chỉ đọc file 1 lần cho mỗi model, không đọc
  // lại mỗi lần generate() (file không đổi trong lúc app đang chạy).
  static final Map<String, String?> _promptTemplateCache = {};

  // ĐÃ THÊM — mục AX, 2026-09-16 — theo đúng yêu cầu người dùng: "Chọn mẫu
  // cố định dựa trên loại kiến trúc mô hình". Lớp dự phòng THỨ 2 (sau
  // `prompt_template` dạng %s trực tiếp ở trên, vẫn ưu tiên cao nhất khi có
  // sẵn) — dùng khi model CHỈ có khuôn Jinja đầy đủ (không có bản rút gọn
  // %s), đúng đúng giới hạn thật đã tự ghi ở `_readPromptTemplateForModel`.
  // Khớp theo `model_type` đọc THẲNG từ `llm_config.json` của model (không
  // đoán theo tên thư mục/tên model — HỌC ĐÚNG bài học mục AP: hardcode
  // theo TÊN model từng áp nhầm khuôn Llama 3 cho model hoá ra là Hunyuan).
  //
  // Khớp theo TIỀN TỐ (không so khớp tuyệt đối) để tự đúng luôn với các
  // biến thể CÙNG HỌ kiến trúc (vd "hunyuan_v1_dense", "hunyuan_v1_moe"...
  // đều bắt đầu bằng "hunyuan") mà không cần sửa code mỗi khi thêm model
  // mới cùng họ — đúng tinh thần "tự động đúng khi thêm model MỚI cùng họ
  // kiến trúc" mục AV đã đặt ra.
  //
  // CHỈ thêm đúng những kiến trúc đã XÁC NHẬN THẬT (đối chiếu trực tiếp với
  // `chat_template.jinja`/`tokenizer_config.json` CHÍNH THỨC của chính họ
  // model đó) — không đoán mù:
  // - "qwen2": model_type CHÍNH THỨC dùng chung cho cả Qwen2 VÀ Qwen2.5
  //   (HuggingFace `config.json`), cùng dùng ChatML — khớp ĐÚNG với ví dụ
  //   `llm_config.json` mẫu của chính Qwen2 trong tài liệu MNN chính thức
  //   (mnn-docs.readthedocs.io/en/latest/transformers/llm.html — mục
  //   "配置文件示例"): "<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n".
  // - "hunyuan": khớp ĐÚNG `chat_template.jinja` chính thức của Tencent trên
  //   HuggingFace (tencent/Hunyuan-4B-Instruct, Hunyuan-0.5B-Instruct...):
  //   bắt đầu bằng <|hy_begin▁of▁sentence|>, vai user dùng <|hy_User|>, phần
  //   sinh tiếp bắt đầu bằng <|hy_Assistant|> (không có role hệ thống riêng
  //   trong khuôn ĐƠN GIẢN 1-lượt ở đây, vì app đã tự gộp systemPrompt vào
  //   userPrompt từ trước ở `_buildFinalPrompt`).
  //
  // CỐ Ý KHÔNG thêm "llama" — model_type "llama" (HuggingFace) dùng CHUNG
  // cho cả Llama 2 VÀ Llama 3, 2 khuôn chat KHÁC NHAU HOÀN TOÀN — không đủ
  // căn cứ để chọn đúng bản nào chỉ từ mỗi `model_type`. Đây CHÍNH LÀ loại
  // giả định mơ hồ đã gây hồi quy thật ở mục AP (hardcode Llama 3, áp nhầm
  // cho model hoá ra là Hunyuan). Bài học: chỉ thêm entry khi `model_type`
  // xác định DUY NHẤT đúng 1 khuôn chat, không mơ hồ giữa nhiều phiên bản.
  // Muốn thêm kiến trúc mới: tra `chat_template.jinja`/`tokenizer_config.json`
  // THẬT của đúng model đó trên HuggingFace trước, không suy đoán từ tên.
  static const Map<String, String> _fixedTemplatesByModelTypePrefix = {
    'qwen2': '<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n',
    'hunyuan': '<|hy_begin\u2581of\u2581sentence|><|hy_User|>%s<|hy_Assistant|>',
  };

  // Đọc `prompt_template` (dạng có 1 chỗ trống `%s`) từ `llm_config.json`
  // của ĐÚNG model đang dùng (`modelPath`). Trả về `null` nếu không đọc
  // được/không có trường này — khi đó nơi gọi tự lùi về cách ghép thô cũ
  // (an toàn, đã dùng suốt từ đầu, không tệ hơn hiện tại).
  // GIỚI HẠN THẬT: chỉ đọc được khuôn dạng `%s` đơn giản — nếu model chỉ
  // có khuôn Jinja đầy đủ (`jinja.chat_template`, cú pháp phức tạp hơn
  // nhiều — vòng lặp, điều kiện, nhiều vai trò) mà KHÔNG có sẵn bản rút
  // gọn `prompt_template`, hàm này KHÔNG tự dựng được khuôn đó (viết 1
  // bộ thông dịch Jinja đầy đủ bằng Dart ngoài phạm vi sửa hiện tại) —
  // sẽ lùi về ghép thô, y hệt như model đó chưa từng có khuôn nào.
  Future<String?> _readPromptTemplateForModel() async {
    if (_promptTemplateCache.containsKey(modelPath)) {
      return _promptTemplateCache[modelPath];
    }
    String? template;
    String templateSource = '';
    try {
      final file = File('$modelPath/llm_config.json');
      if (await file.exists()) {
        final raw = await file.readAsString();
        final json = jsonDecode(raw) as Map<String, dynamic>;
        final direct = json['prompt_template'];
        if (direct is String && direct.contains('%s')) {
          template = direct;
          templateSource = 'prompt_template truc tiep trong llm_config.json';
        } else {
          // ĐÃ THÊM — mục AX: không có prompt_template rút gọn -> thử suy ra
          // mẫu CỐ ĐỊNH theo model_type (họ kiến trúc), xem giải thích đầy
          // đủ ở khai báo `_fixedTemplatesByModelTypePrefix` phía trên. Nếu
          // model_type không có/không khớp entry nào đã biết, `template`
          // vẫn là null — lùi về ghép thô y hệt hành vi cũ, KHÔNG thay đổi
          // gì cho model chưa nằm trong bảng.
          final modelType = json['model_type'];
          if (modelType is String && modelType.isNotEmpty) {
            final lower = modelType.toLowerCase();
            for (final entry in _fixedTemplatesByModelTypePrefix.entries) {
              if (lower.startsWith(entry.key)) {
                template = entry.value;
                templateSource = 'mau CO DINH theo model_type="$modelType" (khop tien to "${entry.key}")';
                break;
              }
            }
          }
        }
      }
    } catch (e) {
      unawaited(DebugLogService.instance.log(
          'LocalLlamaProvider._readPromptTemplateForModel: doc/parse llm_config.json THAT BAI cho modelPath=$modelPath — loi: $e (se lui ve ghep tho)'));
    }
    _promptTemplateCache[modelPath] = template;
    unawaited(DebugLogService.instance.log(
        'LocalLlamaProvider._readPromptTemplateForModel: modelPath=$modelPath -> ${template == null ? "KHONG co prompt_template dang %s va KHONG khop model_type nao da biet, se ghep tho" : "DUNG $templateSource: [$template]"}'));
    return template;
  }

  // Ghép prompt cuối cùng gửi native — tự động dùng đúng khuôn của model
  // đang nạp nếu đọc được, không thì lùi về ghép thô (hành vi hiện tại,
  // an toàn với mọi model chưa biết).
  Future<String> _buildFinalPrompt(String systemPrompt, String userPrompt) async {
    final combined = systemPrompt.isEmpty ? userPrompt : '$systemPrompt\n\n$userPrompt';
    final template = await _readPromptTemplateForModel();
    if (template == null) return combined;
    return template.replaceFirst('%s', combined);
  }

  Future<int> _resolveBackendPreference() async {
    final id = novelId ?? await SettingsService().loadActiveNovelId();
    if (id == null) return 0; // chưa xác định được truyện nào — mặc định an toàn
    return SettingsService().loadBackendPreference(id);
  }

  // Điều phối Foreground Service cho 1 PIPELINE nhiều bước (vd dịch → sinh
  // → dịch ngược của TranslationService). Gọi beginPipeline() 1 lần trước
  // bước đầu tiên, updatePipelineStage() giữa các bước, endPipeline() 1 lần
  // sau bước cuối — tránh khoảng hở ngắn giữa các bước do trước đây mỗi
  // lệnh loadModel/generate tự start/stop service riêng (xem mục 2.3 tài
  // liệu kiến trúc). Các phương thức này là static vì Foreground Service là
  // tài nguyên toàn cục dùng chung cho cả 2 slot, không thuộc riêng instance
  // provider nào.
  static Future<void> beginPipeline(String stage) =>
      _methodChannel.invokeMethod('beginPipeline', {'stage': stage});

  static Future<void> updatePipelineStage(String stage) =>
      _methodChannel.invokeMethod('updateStage', {'stage': stage});

  static Future<void> endPipeline() => _methodChannel.invokeMethod('endPipeline');

  // ĐÃ THÊM: lớp phòng vệ cuối cho độ tin cậy chạy xuyên đêm — xem giải
  // thích đầy đủ ở MnnBridge.kt. Trả về false an toàn nếu có lỗi (thiết
  // bị không hỗ trợ, hoặc lỗi native khác) thay vì ném exception làm vỡ
  // UI cho 1 tính năng phụ trợ không bắt buộc.
  static Future<bool> isIgnoringBatteryOptimizations() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestIgnoreBatteryOptimizations() async {
    try {
      await _methodChannel.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {
      // Bỏ qua lỗi — đây là tính năng phụ trợ, không chặn luồng chính
      // nếu thiết bị/OEM nào đó không hỗ trợ intent này.
    }
  }

  // ĐÃ THÊM: quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE) không thể
  // bật bằng hộp thoại Cho phép/Từ chối như 2 quyền trên — Android bắt
  // buộc đi qua 1 màn Cài đặt (chủ đích bảo mật). Cặp hàm này chỉ đưa
  // người dùng ĐẾN THẲNG đúng trang gạt quyền của app, đỡ phải tự mò.
  static Future<bool> hasManageStoragePermission() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('hasManageStoragePermission');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestManageStoragePermission() async {
    try {
      await _methodChannel.invokeMethod('requestManageStoragePermission');
    } catch (_) {
      // Bỏ qua lỗi — người dùng vẫn có thể tự vào Cài đặt máy nếu intent
      // không hoạt động trên thiết bị/ROM cụ thể nào đó.
    }
  }

  // ĐÃ SỬA (theo phản hồi người dùng: "trong khung chat kết quả hiển thị
  // là AI local đang trả lời nhưng không biết là model nào" — đúng, tên
  // hiển thị trước đây CỐ ĐỊNH "AI local (MNN + QNN)" bất kể model nào
  // đang thật sự nạp/trả lời, dễ gây hiểu lầm khi vừa đổi model xong (vd
  // tưởng Qwen trả lời nhưng thật ra là OccultAI-Morpheus vừa nạp). Giờ
  // lấy luôn tên thư mục model (basename của `modelPath`) làm tên hiển
  // thị — đúng là model NÀO đang gắn với provider này, không đoán.
  @override
  String get name {
    if (slot != 0) return 'Model dịch thuật local';
    final folderName = modelPath.split(RegExp(r'[\\/]')).where((s) => s.isNotEmpty).lastOrNull;
    if (folderName == null || folderName.isEmpty) return 'AI local (MNN + QNN)';
    return 'AI local — $folderName';
  }

  @override
  String get description => _activeBackend == null
      ? 'Chưa nạp model'
      : 'Đang chạy backend: $_activeBackend'
          '${_activeBackend == 'qnn' ? ' (NPU thật)' : _activeBackend == 'opencl' ? ' (GPU)' : ' (CPU — chậm hơn)'}';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  Future<bool> get isLoadedInNative async =>
      await _methodChannel.invokeMethod<bool>('isLoaded', {'slot': slot}) ?? false;

  Future<void> ensureLoaded() async {
    if (_loaded && _loadedPath == modelPath) {
      // ĐÃ THÊM (2026-08-29 — theo yêu cầu người dùng): "sao lại bắt người
      // dùng tự giải quyết thủ công" thay vì tự động, khi thấy thông báo
      // "Cần nạp lại model trước khi tiếp tục" lặp lại ở MỌI tin nhắn sau
      // đó, dù người dùng có gửi lại bao nhiêu lần cũng vậy — vì trước
      // đây `ensureLoaded()` chỉ so `_loadedPath == modelPath` rồi bỏ qua
      // hẳn bước loadModel(), không hề biết native đã đánh dấu slot này
      // "không an toàn để dùng tiếp" (xem g_slotNeedsFullReload,
      // mnn_bridge.cpp) sau 1 lần generate() bị ngắt giữa chừng (huỷ/lặp
      // vô tận). Giờ hỏi thẳng native TRƯỚC khi quyết định bỏ qua — nếu
      // native báo "cần nạp lại", KHÔNG return sớm nữa, chạy tiếp xuống
      // dưới để gọi loadModel() thật (dù CÙNG modelPath), tự khớp đúng
      // với native rồi thôi, người dùng không cần tự đổi model qua lại
      // hay khởi động lại app nữa.
      bool needsReload = false;
      try {
        needsReload = await _methodChannel.invokeMethod<bool>('needsFullReload', {'slot': slot}) ?? false;
      } catch (e) {
        await DebugLogService.instance.log('ensureLoaded: hoi needsFullReload LOI (coi nhu khong can, giu hanh vi cu): $e');
      }
      // ĐÃ THÊM (2026-08-30 — theo yêu cầu người dùng: "cả 2 vấn đề luôn"
      // — needsFullReload CHỈ bật khi lệnh generate() trước dừng SẠCH
      // (có exception: huỷ/lặp vô tận). Nếu lệnh trước TREO THẬT SỰ (0 ký
      // tự, KHÔNG hề ném exception — xác nhận qua log thật, tự nạp lại
      // mục I.1 không áp dụng được cho trường hợp này) thì cờ đó KHÔNG
      // BAO GIỜ bật, dù slot rõ ràng vẫn "kẹt". Hỏi thẳng thêm
      // isSlotGenerating — nếu true ở đúng lúc Dart CHUẨN BỊ bắt đầu 1
      // lượt chat MỚI (Dart chưa hề tự gửi lệnh generate nào của riêng
      // nó lúc này), đó CHỈ có thể là 1 lệnh mồ côi từ phiên trước, không
      // phải lệnh hợp lệ nào của lượt chat hiện tại — coi như cần nạp lại
      // y hệt needsFullReload. An toàn để nạp lại NGAY dù đang "generating"
      // thật vì g_slots giờ dùng shared_ptr (xem mnn_bridge.cpp) — lệnh mồ
      // côi đó tự giữ tham chiếu riêng, không còn nguy cơ crash.
      // ĐÃ SỬA (2026-09-05, sau sự cố "Tạo lại tất cả ghi chú" ngày
      // 2026-09-03 — xem lịch sử debug đầy đủ): bản 2026-08-30 coi MỌI
      // lúc isSlotGenerating=true là "chắc chắn mồ côi từ phiên trước" rồi
      // nạp đè NGAY — giả định đó SAI khi có 2 tính năng trong CÙNG phiên
      // cùng gọi slot này gần như đồng thời (vd người dùng rời màn soạn
      // chương lúc đang "Viết tiếp" rồi mở lại bấm tiếp, hoặc "Tạo lại tất
      // cả ghi chú" xử lý mục kế trong lúc mục trước vẫn chưa xong hẳn) —
      // nạp đè NGAY LÚC ĐÓ biến 1 lệnh THẬT, đang chạy bình thường (chỉ là
      // chậm — model 8B này đã xác nhận vốn chậm, xem ghi chú xoá lớp trì
      // trệ theo elapsed-time ở mnn_bridge.cpp) thành mồ côi thật, gây ra
      // chuỗi hàng chục lệnh generate() chồng chéo lẫn nhau.
      // Giờ hỏi thêm `slotStalledMs` (số ms từ TOKEN CUỐI CÙNG, không phải
      // từ lúc bắt đầu) trước khi kết luận: nếu vẫn đang có tiến triển đều
      // đặn (dưới ngưỡng), coi như KHÔNG cần nạp lại — cứ để Mutex ở tầng
      // Kotlin tự xếp hàng lệnh generate() MỚI phía sau lệnh đang chạy,
      // đúng như thiết kế ban đầu của Mutex đó. CHỈ khi thật sự không tiến
      // triển gì (0 token mới) suốt quá ngưỡng mới coi là treo hẳn — an
      // toàn để nạp đè.
      if (!needsReload) {
        bool stillGenerating = false;
        try {
          stillGenerating = await _methodChannel.invokeMethod<bool>('isSlotGenerating', {'slot': slot}) ?? false;
        } catch (e) {
          await DebugLogService.instance.log('ensureLoaded: hoi isSlotGenerating LOI (coi nhu khong can, giu hanh vi cu): $e');
        }
        if (stillGenerating) {
          int stalledMs = -1;
          bool queryFailed = false;
          try {
            stalledMs = await _methodChannel.invokeMethod<int>('slotStalledMs', {'slot': slot}) ?? -1;
          } catch (e) {
            queryFailed = true;
            await DebugLogService.instance.log('ensureLoaded: hoi slotStalledMs LOI — coi nhu treo that de an toan: $e');
          }
          if (queryFailed || stalledMs < 0 || stalledMs > _stalledThreshold.inMilliseconds) {
            needsReload = true;
            if (!queryFailed) {
              await DebugLogService.instance.log(
                'ensureLoaded: slot=$slot isSlotGenerating=true VA khong tien trien gi trong ${stalledMs}ms (nguong ${_stalledThreshold.inMilliseconds}ms) — coi la mo coi THAT, se nap lai',
              );
            }
          } else {
            await DebugLogService.instance.log(
              'ensureLoaded: slot=$slot isSlotGenerating=true NHUNG van dang tien trien (${stalledMs}ms tu token cuoi, duoi nguong) — KHONG nap lai, de Mutex tu xep hang lenh moi phia sau',
            );
          }
        }
      }
      if (!needsReload) return;
      await DebugLogService.instance.log(
        'ensureLoaded: slot=$slot dang can nap lai (needsFullReload hoac isSlotGenerating=true) — TU DONG nap lai NGAY, khong doi qua model khac nua, khong doi gi ca',
      );
    }
    // backendPreference đọc từ cài đặt (mặc định 0 = tự thử QNN trước) —
    // có thể đổi qua GPU/CPU trong "Tối ưu AI local" MÀ KHÔNG CẦN build lại
    // app, hữu ích để khoanh vùng crash native (nếu QNN gây crash cứng,
    // Kotlin/Dart không bắt được lỗi, chỉ có cách thử đổi backend rồi xem
    // có còn crash không).
    final backendPreference = await _resolveBackendPreference();
    await DebugLogService.instance.log(
      'ensureLoaded: slot=$slot, modelPath=$modelPath, backendPreference=$backendPreference — CHUẨN BỊ gọi loadModel native',
    );
    final Map? result;
    try {
      result = await _methodChannel.invokeMethod<Map>('loadModel', {
        'slot': slot,
        'configPath': modelPath,
        'backendPreference': backendPreference,
      });
    } catch (e) {
      await DebugLogService.instance.log('ensureLoaded: loadModel NÉM LỖI (Dart/Kotlin bắt được): $e');
      rethrow;
    }
    await DebugLogService.instance.log('ensureLoaded: loadModel TRẢ VỀ xong: $result');
    if (result == null || result['success'] != true) {
      throw Exception('Không nạp được model tại $modelPath');
    }
    _activeBackend = result['backend'] as String?;
    _loaded = true;
    _loadedPath = modelPath;
  }

  // Xả model khỏi RAM (máy yếu, cần giải phóng chỗ cho model khác dùng
  // trước khi nạp) — gọi rõ ràng, không tự động, vì tầng trên (RAM đủ
  // hay không) mới biết lúc nào nên xả.
  Future<void> unload() async {
    if (!_loaded) return;
    await _methodChannel.invokeMethod('unload', {'slot': slot});
    _loaded = false;
    _activeBackend = null;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) async {
    final buffer = StringBuffer();
    await for (final chunk in generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      // ĐÃ THÊM: luôn false cho tác vụ 1 lần (vd từng đoạn tài liệu dịch/
      // tóm tắt) — mỗi đoạn nội dung độc lập, không liên quan đoạn trước,
      // tái sử dụng KV-cache ở đây có thể làm lẫn ngữ cảnh sai giữa các
      // đoạn không liên quan.
      reuseKv: false,
    )) {
      buffer.write(chunk);
    }
    return buffer.toString();
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    String stageLabel = 'Đang sinh văn bản...',
    bool reuseKv = false,
  }) async* {
    await ensureLoaded();

    // ĐÃ THÊM (2026-09-06, xem giải thích đầy đủ ở khai báo requestId trong
    // MnnBridge.kt "generate"): mỗi LẦN GỌI hàm này có 1 ID riêng — dùng để
    // lọc đúng token/done của CHÍNH lệnh này ở listener bên dưới, không
    // nhận nhầm của lệnh khác đang chạy song song trên cùng slot.
    final requestId = '$slot-${DateTime.now().microsecondsSinceEpoch}';

    // Đăng ký lắng nghe stream TRƯỚC khi gọi lệnh generate, tránh bỏ lỡ
    // kết quả đầu tiên (race condition giữa 2 kênh). Lọc đúng theo slot,
    // vì cả 2 slot dùng chung 1 EventChannel.
    final controller = StreamController<String>();
    late final StreamSubscription sub;
    // ĐÃ THÊM (lỗi CRASH THẬT phát hiện từ log runtime — SIGSEGV khi 2 lệnh
    // generate() chạy chồng lên nhau trên CÙNG 1 slot, xem chat_screen.dart):
    // trước đây, nếu người gọi hàm này (vd chat_screen.dart) NGỪNG LẮNG NGHE
    // stream giữa chừng — rời màn hình, đóng app, hoặc bất kỳ lý do gì
    // KHÁC với việc thật sự nhận đủ token `done=true` — lệnh `generate`
    // native đã gửi (`invokeMethod('generate', ...)` ở dưới, dùng
    // `unawaited`) VẪN TIẾP TỤC CHẠY MỒ CÔI trong nền, không có cách nào
    // huỷ. Nếu người dùng quay lại và gửi thêm 1 lệnh generate MỚI trên
    // CÙNG slot trước khi lệnh mồ côi đó chạy xong, 2 lệnh native VA CHẠM
    // nhau, làm hỏng session/KV-cache nội bộ MNN — chính là nguyên nhân
    // crash SIGSEGV đã xác nhận qua log CI. `doneReceived` theo dõi xem đã
    // nhận được tín hiệu `done=true` THẬT SỰ chưa, dùng ở khối `finally`
    // bên dưới.
    bool doneReceived = false;
    // ĐÃ THÊM: lớp phòng vệ "lặp vô tận" — xác nhận thật qua log (mục
    // 5.68 tài liệu kiến trúc: model dịch trả "8888888"; ảnh chụp màn
    // hình: Qwen 7B trả cả màn hình dấu "(((((("). Trước đây model rơi
    // vào lặp 1 ký tự/1 cụm ngắn thì KHÔNG có gì phát hiện — chạy tới hết
    // max_new_tokens (log thật: 1024 token trong 550 giây, máy nóng vô
    // ích). Đặt DUY NHẤT ở đây (trong listener EventChannel) vì đây là
    // điểm DUY NHẤT mọi nơi gọi generateStream() (chat, viết chương, dịch
    // thuật...) đều đi qua — sửa 1 chỗ, bảo vệ mọi nơi, không cần từng nơi
    // gọi tự cài lại logic phát hiện riêng.
    // ĐÃ SỬA — mục AJ, 2026-09-12 — TỰ PHÊ BÌNH, ghi thẳng ra đây để không
    // lặp lại: mục AI (2026-09-11) đã nới đúng ngưỡng này ở tầng NATIVE
    // (`mnn_bridge.cpp`, 60→320 byte) sau khi xác nhận `repetitionPenalty`
    // không phải nguyên nhân — nhưng mục Z, đoạn NGAY TRÊN đây, đã tự ghi
    // rõ ràng "Chỉ còn tầng Dart (`local_provider.dart`) làm việc" là 1
    // bộ dò THỨ HAI, HOÀN TOÀN riêng — mục AI đọc tới đoạn đó, TRÍCH DẪN
    // nó, nhưng chỉ sửa đúng 1 trong 2 chỗ chính nó vừa đọc thấy. Log
    // 2026-09-12T04:47 xác nhận: sau khi native đã được nới lên 320,
    // generateStream() vẫn cắt ở đúng 60 ký tự — vì đây, bộ dò Dart, chưa
    // hề đổi gì — TỰ nó gọi `cancelGenerate()` xuống native trước khi
    // native kịp chờ tới ngưỡng 320 mới của chính nó. Áp NGUYÊN VẸN cùng 1
    // thay đổi, cùng 1 lý do, ở đây.
    bool repetitionStopped = false;
    final fullTextSoFar = StringBuffer();
    sub = _eventChannel.receiveBroadcastStream().listen(
      (event) {
        final map = event as Map;
        if ((map['slot'] as int?) != slot) return;
        // ĐÃ THÊM (2026-09-06): bỏ qua event của lệnh KHÁC đang chạy trùng
        // slot — xem giải thích đầy đủ ở khai báo requestId phía trên. So
        // sánh null-an toàn: backup cũ của app (nếu có) hoặc lỗi đọc
        // argument phía Kotlin có thể trả `requestId: null` — trong
        // trường hợp đó vẫn CHO QUA (coi như không lọc được) thay vì lặng
        // lẽ bỏ toàn bộ event, tránh biến 1 lỗi nhỏ thành "generate không
        // bao giờ nhận được token nào".
        final eventRequestId = map['requestId'] as String?;
        if (eventRequestId != null && eventRequestId != requestId) return;
        final token = map['token'] as String? ?? '';
        final done = map['done'] as bool? ?? false;
        if (token.isNotEmpty) {
          fullTextSoFar.write(token);
          controller.add(token);
          if (!repetitionStopped && fullTextSoFar.length >= 320) {
            final text = fullTextSoFar.toString();
            final tail = text.length > 200 ? text.substring(text.length - 200) : text;
            if (_looksLikeRepetitionLoop(tail)) {
              repetitionStopped = true;
              doneReceived = true; // ta tự gọi cancelGenerate ngay dưới đây — finally không cần gọi lại
              unawaited(DebugLogService.instance.log(
                'generateStream: slot=$slot — PHÁT HIỆN LẶP VÔ TẬN (repetition loop) sau ${fullTextSoFar.length} ký tự, dừng sớm + gọi cancelGenerate() native '
                '— [MAU LAP THAT] toan bo noi dung da tich luy: [$text]',
              ));
              controller.add(
                '\n\n⚠️ [Đã tự dừng: model rơi vào lặp vô tận. Thử tăng "Phạt lặp từ" (repetition penalty) trong Cài đặt sinh văn bản, hoặc đổi model khác.]',
              );
              controller.close();
              sub.cancel();
              unawaited(() async {
                try {
                  await _methodChannel.invokeMethod('cancelGenerate', {'slot': slot});
                } catch (_) {
                  // Bỏ qua — mục tiêu chính (ngừng nhận thêm token rác vào
                  // UI) đã đạt, lệnh generate mồ côi phía native tự kết
                  // thúc bình thường khi hết max_new_tokens nếu cancel lỗi.
                }
              }());
              return;
            }
          }
        }
        if (done) {
          doneReceived = true;
          controller.close();
          sub.cancel();
        }
      },
      onError: (e) {
        // Lỗi cũng coi như "đã xong" theo nghĩa không cần gọi cancelGenerate
        // nữa — native tự nó đã dừng (lỗi mới có thể phát ra được).
        doneReceived = true;
        controller.addError(e);
        controller.close();
        sub.cancel();
      },
    );

    unawaited(DebugLogService.instance.log(
      'generateStream: slot=$slot — CHUẨN BỊ gọi generate native (prompt dài ${systemPrompt.length + userPrompt.length} ký tự)',
    ));
    // ĐÃ SỬA — mục AV, 2026-09-15 (thay cho lý luận mục AS/AU — quyết định
    // TỔNG QUÁT, không hardcode theo tên model): mục AP (hardcode Llama 3)
    // rồi mục AU (hardcode ChatML/Hunyuan theo tên model) đều bị chính
    // người dùng chỉ đúng vấn đề: mỗi lần thêm model mới lại phải sửa
    // code + build lại app — không chấp nhận được. Giải pháp đúng: tự đọc
    // `prompt_template` từ `llm_config.json` của ĐÚNG model đang nạp (xem
    // `_buildFinalPrompt()`/`_readPromptTemplateForModel()` ở đầu file) —
    // file này LUÔN có sẵn, đúng riêng cho model đó, do chính công cụ
    // xuất model tạo ra lúc export — không cần app biết trước là khuôn
    // gì, không cần sửa code khi thêm model mới, chỉ cần model đó được
    // xuất chuẩn bằng `llmexport.py` (công cụ chính thức duy nhất).
    final finalPrompt = await _buildFinalPrompt(systemPrompt, userPrompt);
    unawaited(_methodChannel.invokeMethod('generate', {
      'slot': slot,
      'requestId': requestId,
      'prompt': finalPrompt,
      'stageLabel': stageLabel,
      'temperature': temperature,
      'topP': topP,
      'topK': topK,
      'repetitionPenalty': repetitionPenalty,
      'maxNewTokens': maxTokens,
      'reuseKv': reuseKv,
    }).then((_) {
      DebugLogService.instance.log('generateStream: slot=$slot — lệnh generate native trả về xong (không crash)');
    }).catchError((e) {
      DebugLogService.instance.log('generateStream: slot=$slot — generate NÉM LỖI (Dart/Kotlin bắt được): $e');
    }));

    try {
      yield* controller.stream;
    } finally {
      // ĐÃ THÊM: đây là điểm THỰC THI khi consumer NGỪNG LẮNG NGHE stream
      // này, DÙ VÌ LÝ DO GÌ (nhận đủ done=true bình thường, HOẶC bị huỷ
      // giữa chừng từ bên ngoài — vd `await for` bị `break`, widget bị
      // dispose khi đang generate). `sub.cancel()` gọi lại lần 2 (nếu đã
      // cancel ở nhánh `done` phía trên) là AN TOÀN — StreamSubscription
      // cho phép gọi `cancel()` nhiều lần không lỗi.
      await sub.cancel();
      if (!doneReceived) {
        unawaited(DebugLogService.instance.log(
          'generateStream: slot=$slot — consumer huỷ giữa chừng (CHƯA nhận done=true) — gọi cancelGenerate() native để không mồ côi',
        ));
        try {
          await _methodChannel.invokeMethod('cancelGenerate', {'slot': slot});
        } catch (e) {
          unawaited(DebugLogService.instance
              .log('generateStream: slot=$slot — cancelGenerate() native báo lỗi (bỏ qua, không phải lỗi nghiêm trọng): $e'));
        }
      }
    }
  }

  // ĐÃ THÊM: kiểm tra 1 cửa sổ ký tự cuối cùng (đã stream về) có "trông
  // giống" lặp vô tận hay không. Cố tình đơn giản/rẻ (chạy mỗi token mới)
  // thay vì phân tích thống kê đầy đủ kiểu `RepetitionAnalyzer` (dùng cho
  // "Kiểm tra lặp từ" thủ công trong chương đã viết xong — bài toán khác:
  // ở đó cần độ chính xác cao trên văn bản hoàn chỉnh, ở đây cần rẻ + đủ
  // nhạy để cắt sớm 1 luồng đang rõ ràng hỏng).
  //
  // 2 dấu hiệu, khớp đúng 2 trường hợp THẬT đã gặp trong log/ảnh chụp:
  // (a) 1 ký tự DUY NHẤT chiếm áp đảo cửa sổ — "8888888", "(((((((("
  // (b) 1 cụm ngắn (2-6 ký tự) lặp lại khít cả cửa sổ — tổng quát hơn,
  //     phòng trường hợp model lặp 1 cặp/cụm thay vì đúng 1 ký tự.
  static bool _looksLikeRepetitionLoop(String tailWindow) {
    // Bỏ khoảng trắng/xuống dòng trước khi đếm — văn bản bình thường có
    // rất nhiều khoảng trắng lặp lại hợp lệ, không phải dấu hiệu lỗi.
    final compact = tailWindow.replaceAll(RegExp(r'\s+'), '');
    if (compact.length < 60) return false; // cửa sổ còn quá ngắn, chưa đủ căn cứ để kết luận

    final counts = <String, int>{};
    for (final ch in compact.split('')) {
      counts[ch] = (counts[ch] ?? 0) + 1;
    }
    final maxCount = counts.values.fold<int>(0, (a, b) => a > b ? a : b);
    if (maxCount / compact.length > 0.85) return true;

    for (var period = 2; period <= 6; period++) {
      if (compact.length < period * 4) continue; // cần ít nhất 4 chu kỳ mới đủ chắc chắn
      final unit = compact.substring(0, period);
      var matches = true;
      for (var i = 0; i < compact.length; i += period) {
        final end = (i + period <= compact.length) ? i + period : compact.length;
        if (compact.substring(i, end) != unit.substring(0, end - i)) {
          matches = false;
          break;
        }
      }
      if (matches) return true;
    }
    return false;
  }

  Future<void> dispose() => unload();
}
