import 'dart:async';
import 'package:llama_cpp_dart/llama_cpp_dart.dart';
import '../ai_provider.dart';

// llama_cpp_dart (netdur) — build sẵn thư viện native cho Android
// (không tự compile CMake như fllama/flutter_llama, né được lỗi build
// đã gặp trước đây), có bản build riêng "Hexagon NPU + OpenCL AAR" cho
// Snapdragon. Dùng API "Managed Isolate" (LlamaParent) — chạy suy luận
// trên isolate riêng, không chặn UI thread, đúng cho app chat.
//
// LƯU Ý: chưa xác nhận chắc chắn cách chọn bản Hexagon AAR thay vì bản
// CPU AAR mặc định (có thể cần cấu hình Gradle riêng) — bắt đầu bằng
// tích hợp cơ bản chạy được đã, sẽ tinh chỉnh để bật đúng backend NPU
// sau khi xác nhận luồng cơ bản hoạt động.
class LocalLlamaProvider implements AIProvider {
  final String modelPath;
  final int threads;
  final int contextSize;
  final int numGpuLayers;

  LocalLlamaProvider({
    required this.modelPath,
    this.threads = 4,
    this.contextSize = 1024,
    this.numGpuLayers = 0,
  });

  static LlamaParent? _parent;
  static String? _loadedPath;

  @override
  String get name => 'AI local (nhúng trong APK)';

  @override
  String get description => 'Chạy hoàn toàn offline, ngay trong app — có hỗ trợ Hexagon NPU/OpenCL trên Snapdragon.';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  Future<LlamaParent> _ensureLoaded() async {
    if (_parent != null && _loadedPath == modelPath) return _parent!;
    if (_parent != null) {
      _parent!.dispose();
      _parent = null;
    }
    final loadCommand = LlamaLoad(
      path: modelPath,
      modelParams: ModelParams(),
      contextParams: ContextParams(),
      samplingParams: SamplerParams(),
      format: ChatMLFormat(),
    );
    final parent = LlamaParent(loadCommand);
    await parent.init();
    _parent = parent;
    _loadedPath = modelPath;
    return parent;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
  }) async {
    final buffer = StringBuffer();
    await for (final chunk in generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
    )) {
      buffer.write(chunk);
    }
    return buffer.toString();
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
  }) async* {
    final parent = await _ensureLoaded();
    final controller = StreamController<String>();
    late final StreamSubscription sub;
    // Tài liệu package chưa xác nhận rõ tín hiệu "đã sinh xong" của
    // stream này (có thể là DoneEvent, có thể không) — dùng khoảng lặng
    // 30 giây không có token mới làm dấu hiệu "coi như xong". Để 30s vì
    // model lớn có thể chỉ đạt 1 token/giây, khoảng lặng ngắn hơn sẽ cắt
    // ngang câu trả lời đang sinh dở.
    Timer? silenceTimer;
    void resetSilenceTimer() {
      silenceTimer?.cancel();
      silenceTimer = Timer(const Duration(seconds: 30), () {
        if (!controller.isClosed) controller.close();
      });
    }

    resetSilenceTimer();
    sub = parent.stream.listen(
      (response) {
        controller.add(response.toString());
        resetSilenceTimer();
      },
      onError: (e) {
        if (!controller.isClosed) controller.addError(e);
      },
      onDone: () {
        silenceTimer?.cancel();
        if (!controller.isClosed) controller.close();
      },
    );
    parent.sendPrompt('$systemPrompt\n\n$userPrompt');
    yield* controller.stream;
    silenceTimer?.cancel();
    await sub.cancel();
  }
}
