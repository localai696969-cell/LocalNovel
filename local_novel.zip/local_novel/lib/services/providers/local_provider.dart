import 'dart:async';
import 'package:flutter/services.dart';
import '../ai_provider.dart';
import '../debug_log_service.dart';
import '../settings_service.dart';

// Gọi vào tầng native (MNN-LLM + QNN) qua Platform Channel — KHÔNG dùng
// dart:ffi nữa (loại bỏ tận gốc lỗi "libllama.so not found" trước đây).
//
// slot: 0 = model chính, 1 = model dịch thuật trung gian (dùng bởi
// TranslationService) — 2 slot độc lập, có thể cùng tồn tại trong RAM
// nếu máy đủ khỏe, xem device_profile_service.dart để biết máy có nên
// giữ cả 2 hay không.
class LocalLlamaProvider implements AIProvider {
  static const _methodChannel = MethodChannel('com.localnovel/mnn_method');
  static const _eventChannel = EventChannel('com.localnovel/mnn_stream');

  final String modelPath; // đường dẫn THƯ MỤC model MNN export
  final int slot;
  // ĐÃ THÊM (v15 — `backendPreference` giờ RIÊNG TỪNG TRUYỆN, xem
  // `SettingsService`/`story_models.dart`): provider cần biết đang phục
  // vụ TRUYỆN NÀO để đọc đúng cấu hình backend của truyện đó. NULLABLE vì
  // slot dịch thuật (slot=1, `TranslationService`) đôi khi được tạo trước
  // khi có `novelId` rõ ràng trong tay — khi đó rơi về
  // `loadActiveNovelId()` (truyện đang mở trên máy) làm căn cứ, xem
  // `_resolveBackendPreference()` bên dưới — cùng cách xử lý đã dùng ở
  // `BackgroundTaskManager._currentConcurrencyCap()`.
  final String? novelId;
  String? _activeBackend;
  bool _loaded = false;
  String? _loadedPath;

  LocalLlamaProvider({required this.modelPath, this.slot = 0, this.novelId});

  Future<int> _resolveBackendPreference() async {
    final id = novelId ?? await SettingsService().loadActiveNovelId();
    if (id == null) return 0; // chưa xác định được truyện nào — mặc định an toàn
    return SettingsService().loadBackendPreference(id);
  }

  // Điều phối Foreground Service cho 1 PIPELINE nhiều bước (vd dịch → sinh
  // → dịch ngược của TranslationService). Gọi beginPipeline() 1 lần trước
  // bước đầu tiên, updatePipelineStage() giữa các bước, endPipeline() 1 lần
  // sau bước cuối — tránh khoảng hở ngắn giữa các bước do trước đây mỗi
  // lệnh loadModel/generate tự start/stop service riêng (xem mục 2.3 tài
  // liệu kiến trúc). Các phương thức này là static vì Foreground Service là
  // tài nguyên toàn cục dùng chung cho cả 2 slot, không thuộc riêng instance
  // provider nào.
  static Future<void> beginPipeline(String stage) =>
      _methodChannel.invokeMethod('beginPipeline', {'stage': stage});

  static Future<void> updatePipelineStage(String stage) =>
      _methodChannel.invokeMethod('updateStage', {'stage': stage});

  static Future<void> endPipeline() => _methodChannel.invokeMethod('endPipeline');

  // ĐÃ THÊM: lớp phòng vệ cuối cho độ tin cậy chạy xuyên đêm — xem giải
  // thích đầy đủ ở MnnBridge.kt. Trả về false an toàn nếu có lỗi (thiết
  // bị không hỗ trợ, hoặc lỗi native khác) thay vì ném exception làm vỡ
  // UI cho 1 tính năng phụ trợ không bắt buộc.
  static Future<bool> isIgnoringBatteryOptimizations() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestIgnoreBatteryOptimizations() async {
    try {
      await _methodChannel.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {
      // Bỏ qua lỗi — đây là tính năng phụ trợ, không chặn luồng chính
      // nếu thiết bị/OEM nào đó không hỗ trợ intent này.
    }
  }

  // ĐÃ THÊM: quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE) không thể
  // bật bằng hộp thoại Cho phép/Từ chối như 2 quyền trên — Android bắt
  // buộc đi qua 1 màn Cài đặt (chủ đích bảo mật). Cặp hàm này chỉ đưa
  // người dùng ĐẾN THẲNG đúng trang gạt quyền của app, đỡ phải tự mò.
  static Future<bool> hasManageStoragePermission() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('hasManageStoragePermission');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestManageStoragePermission() async {
    try {
      await _methodChannel.invokeMethod('requestManageStoragePermission');
    } catch (_) {
      // Bỏ qua lỗi — người dùng vẫn có thể tự vào Cài đặt máy nếu intent
      // không hoạt động trên thiết bị/ROM cụ thể nào đó.
    }
  }

  @override
  String get name => slot == 0 ? 'AI local (MNN + QNN)' : 'Model dịch thuật local';

  @override
  String get description => _activeBackend == null
      ? 'Chưa nạp model'
      : 'Đang chạy backend: $_activeBackend'
          '${_activeBackend == 'qnn' ? ' (NPU thật)' : _activeBackend == 'opencl' ? ' (GPU)' : ' (CPU — chậm hơn)'}';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  Future<bool> get isLoadedInNative async =>
      await _methodChannel.invokeMethod<bool>('isLoaded', {'slot': slot}) ?? false;

  Future<void> ensureLoaded() async {
    if (_loaded && _loadedPath == modelPath) return;
    // backendPreference đọc từ cài đặt (mặc định 0 = tự thử QNN trước) —
    // có thể đổi qua GPU/CPU trong "Tối ưu AI local" MÀ KHÔNG CẦN build lại
    // app, hữu ích để khoanh vùng crash native (nếu QNN gây crash cứng,
    // Kotlin/Dart không bắt được lỗi, chỉ có cách thử đổi backend rồi xem
    // có còn crash không).
    final backendPreference = await _resolveBackendPreference();
    await DebugLogService.instance.log(
      'ensureLoaded: slot=$slot, modelPath=$modelPath, backendPreference=$backendPreference — CHUẨN BỊ gọi loadModel native',
    );
    final Map? result;
    try {
      result = await _methodChannel.invokeMethod<Map>('loadModel', {
        'slot': slot,
        'configPath': modelPath,
        'backendPreference': backendPreference,
      });
    } catch (e) {
      await DebugLogService.instance.log('ensureLoaded: loadModel NÉM LỖI (Dart/Kotlin bắt được): $e');
      rethrow;
    }
    await DebugLogService.instance.log('ensureLoaded: loadModel TRẢ VỀ xong: $result');
    if (result == null || result['success'] != true) {
      throw Exception('Không nạp được model tại $modelPath');
    }
    _activeBackend = result['backend'] as String?;
    _loaded = true;
    _loadedPath = modelPath;
  }

  // Xả model khỏi RAM (máy yếu, cần giải phóng chỗ cho model khác dùng
  // trước khi nạp) — gọi rõ ràng, không tự động, vì tầng trên (RAM đủ
  // hay không) mới biết lúc nào nên xả.
  Future<void> unload() async {
    if (!_loaded) return;
    await _methodChannel.invokeMethod('unload', {'slot': slot});
    _loaded = false;
    _activeBackend = null;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) async {
    final buffer = StringBuffer();
    await for (final chunk in generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      // ĐÃ THÊM: luôn false cho tác vụ 1 lần (vd từng đoạn tài liệu dịch/
      // tóm tắt) — mỗi đoạn nội dung độc lập, không liên quan đoạn trước,
      // tái sử dụng KV-cache ở đây có thể làm lẫn ngữ cảnh sai giữa các
      // đoạn không liên quan.
      reuseKv: false,
    )) {
      buffer.write(chunk);
    }
    return buffer.toString();
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    String stageLabel = 'Đang sinh văn bản...',
    bool reuseKv = false,
  }) async* {
    await ensureLoaded();

    // Đăng ký lắng nghe stream TRƯỚC khi gọi lệnh generate, tránh bỏ lỡ
    // kết quả đầu tiên (race condition giữa 2 kênh). Lọc đúng theo slot,
    // vì cả 2 slot dùng chung 1 EventChannel.
    final controller = StreamController<String>();
    late final StreamSubscription sub;
    sub = _eventChannel.receiveBroadcastStream().listen(
      (event) {
        final map = event as Map;
        if ((map['slot'] as int?) != slot) return;
        final token = map['token'] as String? ?? '';
        final done = map['done'] as bool? ?? false;
        if (token.isNotEmpty) controller.add(token);
        if (done) {
          controller.close();
          sub.cancel();
        }
      },
      onError: (e) {
        controller.addError(e);
        controller.close();
        sub.cancel();
      },
    );

    unawaited(DebugLogService.instance.log(
      'generateStream: slot=$slot — CHUẨN BỊ gọi generate native (prompt dài ${systemPrompt.length + userPrompt.length} ký tự)',
    ));
    unawaited(_methodChannel.invokeMethod('generate', {
      'slot': slot,
      'prompt': '$systemPrompt\n\n$userPrompt',
      'stageLabel': stageLabel,
      'temperature': temperature,
      'topP': topP,
      'topK': topK,
      'repetitionPenalty': repetitionPenalty,
      'maxNewTokens': maxTokens,
      'reuseKv': reuseKv,
    }).then((_) {
      DebugLogService.instance.log('generateStream: slot=$slot — lệnh generate native trả về xong (không crash)');
    }).catchError((e) {
      DebugLogService.instance.log('generateStream: slot=$slot — generate NÉM LỖI (Dart/Kotlin bắt được): $e');
    }));

    yield* controller.stream;
  }

  Future<void> dispose() => unload();
}
