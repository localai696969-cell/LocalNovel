import 'dart:async';
import 'package:flutter/services.dart';
import '../ai_provider.dart';

// Gọi vào tầng native (MNN-LLM + QNN) qua Platform Channel — KHÔNG dùng
// dart:ffi nữa. Đây là thay đổi kiến trúc quan trọng: mọi lỗi trước đây
// dạng "libllama.so not found" đều bắt nguồn từ việc FFI dlopen tìm
// thư viện .so không đúng cách. Platform Channel để Gradle/Android tự
// lo việc đóng gói và nạp thư viện native theo đúng cơ chế chuẩn của
// Android, không còn tự dò đường dẫn thủ công.
//
// Phía Kotlin/C++ nằm ở android_native/ (được build.yml ghép vào project
// Android lúc build). Xem android_native/app/src/main/cpp/mnn_bridge.cpp
// để biết chi tiết cách nạp model/sinh văn bản thật.
class LocalLlamaProvider implements AIProvider {
  static const _methodChannel = MethodChannel('com.localnovel/mnn_method');
  static const _eventChannel = EventChannel('com.localnovel/mnn_stream');

  final String modelPath; // đường dẫn THƯ MỤC model MNN export (không phải 1 file .gguf)
  String? _activeBackend; // 'qnn' | 'opencl' | 'cpu' | null (chưa nạp)
  bool _loaded = false;
  String? _loadedPath;

  LocalLlamaProvider({required this.modelPath});

  @override
  String get name => 'AI local (MNN + QNN)';

  @override
  String get description => _activeBackend == null
      ? 'Chưa nạp model'
      : 'Đang chạy backend: $_activeBackend'
          '${_activeBackend == 'qnn' ? ' (NPU thật)' : _activeBackend == 'opencl' ? ' (GPU)' : ' (CPU — chậm hơn, máy không hỗ trợ GPU/NPU cho cấu hình này)'}';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  Future<void> _ensureLoaded() async {
    if (_loaded && _loadedPath == modelPath) return;
    final result = await _methodChannel.invokeMethod<Map>('loadModel', {'configPath': modelPath});
    if (result == null || result['success'] != true) {
      throw Exception('Không nạp được model tại $modelPath');
    }
    _activeBackend = result['backend'] as String?;
    _loaded = true;
    _loadedPath = modelPath;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
  }) async {
    final buffer = StringBuffer();
    await for (final chunk in generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
    )) {
      buffer.write(chunk);
    }
    return buffer.toString();
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
  }) async* {
    await _ensureLoaded();

    // Đăng ký lắng nghe stream token TRƯỚC khi gọi lệnh generate, để
    // không bỏ lỡ token đầu tiên (tránh race condition giữa 2 kênh).
    final controller = StreamController<String>();
    late final StreamSubscription sub;
    sub = _eventChannel.receiveBroadcastStream().listen(
      (event) {
        final map = event as Map;
        final token = map['token'] as String? ?? '';
        final done = map['done'] as bool? ?? false;
        if (token.isNotEmpty) controller.add(token);
        if (done) {
          controller.close();
          sub.cancel();
        }
      },
      onError: (e) {
        controller.addError(e);
        controller.close();
        sub.cancel();
      },
    );

    unawaited(_methodChannel.invokeMethod('generate', {
      'prompt': '$systemPrompt\n\n$userPrompt',
    }));

    yield* controller.stream;
  }

  Future<void> dispose() async {
    if (_loaded) {
      await _methodChannel.invokeMethod('unload');
      _loaded = false;
      _activeBackend = null;
    }
  }
}
