import 'dart:async';
import 'package:llama_cpp_dart/llama_cpp_dart.dart';
import '../ai_provider.dart';

// API dưới đây dùng đúng theo ví dụ nguyên văn trong README chính thức
// của netdur/llama_cpp_dart (LlamaEngine.spawn / EngineSession.generate /
// GenerationEvent sealed class) — không suy đoán tên hàm.
//
// CHỖ DUY NHẤT CHƯA CHẮC CHẮN: README ví dụ minh họa trên macOS truyền
// `libraryPath` trỏ tới file .dylib. Trên Android, thư viện native được
// đóng gói sẵn trong AAR (không phải file rời để trỏ đường dẫn), nên
// không rõ có cần tham số này không hay để trống app tự nhận diện. Nếu
// build báo lỗi thiếu tham số bắt buộc ở dòng LlamaEngine.spawn, đó là
// đúng chỗ cần sửa theo thông báo lỗi thật.
class LocalLlamaProvider implements AIProvider {
  final String modelPath;
  final int threads;
  final int contextSize;
  final int numGpuLayers;

  LocalLlamaProvider({
    required this.modelPath,
    this.threads = 4,
    this.contextSize = 2048,
    this.numGpuLayers = 99,
  });

  static LlamaEngine? _engine;
  static String? _loadedPath;

  @override
  String get name => 'AI local (nhúng trong APK)';

  @override
  String get description => 'Chạy hoàn toàn offline, ngay trong app — có hỗ trợ Hexagon NPU/OpenCL trên Snapdragon.';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  Future<LlamaEngine> _ensureLoaded() async {
    if (_engine != null && _loadedPath == modelPath) return _engine!;
    if (_engine != null) {
      await _engine!.dispose();
      _engine = null;
    }
    final engine = await LlamaEngine.spawn(
      libraryPath: 'libllama.so', // Android tự dò trong thư viện native đã đóng gói sẵn trong APK qua tên này
      modelParams: ModelParams(path: modelPath, gpuLayers: numGpuLayers),
      contextParams: ContextParams(nCtx: contextSize),
    );
    _engine = engine;
    _loadedPath = modelPath;
    return engine;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
  }) async {
    final buffer = StringBuffer();
    await for (final chunk in generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
    )) {
      buffer.write(chunk);
    }
    return buffer.toString();
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
  }) async* {
    final engine = await _ensureLoaded();
    final session = await engine.createSession();
    await for (final event in session.generate(
      prompt: '$systemPrompt\n\n$userPrompt',
      addSpecial: true,
      sampler: SamplerParams(temperature: temperature),
      maxTokens: maxTokens,
    )) {
      switch (event) {
        case TokenEvent():
          yield event.text;
        case ShiftEvent():
          break; // KV bị dịch chuyển để lấy chỗ trống — chỉ ghi nhận nội bộ, bỏ qua
        default:
          break; // DoneEvent hoặc sự kiện khác — stream tự đóng khi model sinh xong
      }
    }
  }
}
