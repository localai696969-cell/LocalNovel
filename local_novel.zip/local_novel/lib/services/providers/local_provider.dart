import 'dart:async';
import 'package:flutter/services.dart';
import '../ai_provider.dart';
import '../debug_log_service.dart';
import '../settings_service.dart';

// Gọi vào tầng native (MNN-LLM + QNN) qua Platform Channel — KHÔNG dùng
// dart:ffi nữa (loại bỏ tận gốc lỗi "libllama.so not found" trước đây).
//
// slot: 0 = model chính, 1 = model dịch thuật trung gian (dùng bởi
// TranslationService) — 2 slot độc lập, có thể cùng tồn tại trong RAM
// nếu máy đủ khỏe, xem device_profile_service.dart để biết máy có nên
// giữ cả 2 hay không.
class LocalLlamaProvider implements AIProvider {
  static const _methodChannel = MethodChannel('com.localnovel/mnn_method');
  static const _eventChannel = EventChannel('com.localnovel/mnn_stream');

  // ĐÃ THÊM (theo yêu cầu người dùng: "sao tác vụ nền không báo có bất cứ
  // cái gì hết" khi 1 lệnh generate() mồ côi từ phiên TRƯỚC vẫn đang chạy
  // dưới native — đúng, `BackgroundTaskManager` chỉ là 1 List trong RAM
  // của phiên HIỆN TẠI, không có cách nào tự biết về việc đó). Hỏi thẳng
  // native — nơi DUY NHẤT còn giữ đúng sự thật slot có đang bận hay
  // không — dùng ở `background_tasks_screen.dart` để hiện đúng tình
  // trạng thay vì im lặng khó hiểu.
  static Future<bool> isSlotGenerating(int slot) async {
    try {
      final busy = await _methodChannel.invokeMethod<bool>('isSlotGenerating', {'slot': slot});
      return busy ?? false;
    } catch (_) {
      return false; // không hỏi được (vd lỗi kênh) — coi như không chắc, đừng doạ người dùng vô căn cứ
    }
  }

  // ĐÃ THÊM: cho phép huỷ 1 slot TỪ BÊN NGOÀI vòng đời của chính
  // provider/instance đang giữ nó — cần cho trường hợp "tác vụ mồ côi"
  // (`background_tasks_screen.dart`): không còn `LocalLlamaProvider`
  // instance nào của phiên trước để gọi `generateStream()`/`finally` như
  // bình thường, nhưng lệnh `cancelGenerate` chỉ cần đúng số `slot`, không
  // cần instance — gọi thẳng method channel là đủ.
  static Future<void> requestCancelSlot(int slot) async {
    try {
      await _methodChannel.invokeMethod('cancelGenerate', {'slot': slot});
    } catch (_) {
      // Bỏ qua — nơi gọi (`background_tasks_screen.dart`) đã tự hỏi lại
      // trạng thái sau đó để biết có thành công hay không, không cần ném
      // lỗi lên đây.
    }
  }

  final String modelPath; // đường dẫn THƯ MỤC model MNN export
  final int slot;
  // ĐÃ THÊM (v15 — `backendPreference` giờ RIÊNG TỪNG TRUYỆN, xem
  // `SettingsService`/`story_models.dart`): provider cần biết đang phục
  // vụ TRUYỆN NÀO để đọc đúng cấu hình backend của truyện đó. NULLABLE vì
  // slot dịch thuật (slot=1, `TranslationService`) đôi khi được tạo trước
  // khi có `novelId` rõ ràng trong tay — khi đó rơi về
  // `loadActiveNovelId()` (truyện đang mở trên máy) làm căn cứ, xem
  // `_resolveBackendPreference()` bên dưới — cùng cách xử lý đã dùng ở
  // `BackgroundTaskManager._currentConcurrencyCap()`.
  final String? novelId;
  String? _activeBackend;
  bool _loaded = false;
  String? _loadedPath;

  LocalLlamaProvider({required this.modelPath, this.slot = 0, this.novelId});

  Future<int> _resolveBackendPreference() async {
    final id = novelId ?? await SettingsService().loadActiveNovelId();
    if (id == null) return 0; // chưa xác định được truyện nào — mặc định an toàn
    return SettingsService().loadBackendPreference(id);
  }

  // Điều phối Foreground Service cho 1 PIPELINE nhiều bước (vd dịch → sinh
  // → dịch ngược của TranslationService). Gọi beginPipeline() 1 lần trước
  // bước đầu tiên, updatePipelineStage() giữa các bước, endPipeline() 1 lần
  // sau bước cuối — tránh khoảng hở ngắn giữa các bước do trước đây mỗi
  // lệnh loadModel/generate tự start/stop service riêng (xem mục 2.3 tài
  // liệu kiến trúc). Các phương thức này là static vì Foreground Service là
  // tài nguyên toàn cục dùng chung cho cả 2 slot, không thuộc riêng instance
  // provider nào.
  static Future<void> beginPipeline(String stage) =>
      _methodChannel.invokeMethod('beginPipeline', {'stage': stage});

  static Future<void> updatePipelineStage(String stage) =>
      _methodChannel.invokeMethod('updateStage', {'stage': stage});

  static Future<void> endPipeline() => _methodChannel.invokeMethod('endPipeline');

  // ĐÃ THÊM: lớp phòng vệ cuối cho độ tin cậy chạy xuyên đêm — xem giải
  // thích đầy đủ ở MnnBridge.kt. Trả về false an toàn nếu có lỗi (thiết
  // bị không hỗ trợ, hoặc lỗi native khác) thay vì ném exception làm vỡ
  // UI cho 1 tính năng phụ trợ không bắt buộc.
  static Future<bool> isIgnoringBatteryOptimizations() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('isIgnoringBatteryOptimizations');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestIgnoreBatteryOptimizations() async {
    try {
      await _methodChannel.invokeMethod('requestIgnoreBatteryOptimizations');
    } catch (_) {
      // Bỏ qua lỗi — đây là tính năng phụ trợ, không chặn luồng chính
      // nếu thiết bị/OEM nào đó không hỗ trợ intent này.
    }
  }

  // ĐÃ THÊM: quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE) không thể
  // bật bằng hộp thoại Cho phép/Từ chối như 2 quyền trên — Android bắt
  // buộc đi qua 1 màn Cài đặt (chủ đích bảo mật). Cặp hàm này chỉ đưa
  // người dùng ĐẾN THẲNG đúng trang gạt quyền của app, đỡ phải tự mò.
  static Future<bool> hasManageStoragePermission() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('hasManageStoragePermission');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestManageStoragePermission() async {
    try {
      await _methodChannel.invokeMethod('requestManageStoragePermission');
    } catch (_) {
      // Bỏ qua lỗi — người dùng vẫn có thể tự vào Cài đặt máy nếu intent
      // không hoạt động trên thiết bị/ROM cụ thể nào đó.
    }
  }

  // ĐÃ SỬA (theo phản hồi người dùng: "trong khung chat kết quả hiển thị
  // là AI local đang trả lời nhưng không biết là model nào" — đúng, tên
  // hiển thị trước đây CỐ ĐỊNH "AI local (MNN + QNN)" bất kể model nào
  // đang thật sự nạp/trả lời, dễ gây hiểu lầm khi vừa đổi model xong (vd
  // tưởng Qwen trả lời nhưng thật ra là OccultAI-Morpheus vừa nạp). Giờ
  // lấy luôn tên thư mục model (basename của `modelPath`) làm tên hiển
  // thị — đúng là model NÀO đang gắn với provider này, không đoán.
  @override
  String get name {
    if (slot != 0) return 'Model dịch thuật local';
    final folderName = modelPath.split(RegExp(r'[\\/]')).where((s) => s.isNotEmpty).lastOrNull;
    if (folderName == null || folderName.isEmpty) return 'AI local (MNN + QNN)';
    return 'AI local — $folderName';
  }

  @override
  String get description => _activeBackend == null
      ? 'Chưa nạp model'
      : 'Đang chạy backend: $_activeBackend'
          '${_activeBackend == 'qnn' ? ' (NPU thật)' : _activeBackend == 'opencl' ? ' (GPU)' : ' (CPU — chậm hơn)'}';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  Future<bool> get isLoadedInNative async =>
      await _methodChannel.invokeMethod<bool>('isLoaded', {'slot': slot}) ?? false;

  Future<void> ensureLoaded() async {
    if (_loaded && _loadedPath == modelPath) {
      // ĐÃ THÊM (2026-08-29 — theo yêu cầu người dùng): "sao lại bắt người
      // dùng tự giải quyết thủ công" thay vì tự động, khi thấy thông báo
      // "Cần nạp lại model trước khi tiếp tục" lặp lại ở MỌI tin nhắn sau
      // đó, dù người dùng có gửi lại bao nhiêu lần cũng vậy — vì trước
      // đây `ensureLoaded()` chỉ so `_loadedPath == modelPath` rồi bỏ qua
      // hẳn bước loadModel(), không hề biết native đã đánh dấu slot này
      // "không an toàn để dùng tiếp" (xem g_slotNeedsFullReload,
      // mnn_bridge.cpp) sau 1 lần generate() bị ngắt giữa chừng (huỷ/lặp
      // vô tận). Giờ hỏi thẳng native TRƯỚC khi quyết định bỏ qua — nếu
      // native báo "cần nạp lại", KHÔNG return sớm nữa, chạy tiếp xuống
      // dưới để gọi loadModel() thật (dù CÙNG modelPath), tự khớp đúng
      // với native rồi thôi, người dùng không cần tự đổi model qua lại
      // hay khởi động lại app nữa.
      bool needsReload = false;
      try {
        needsReload = await _methodChannel.invokeMethod<bool>('needsFullReload', {'slot': slot}) ?? false;
      } catch (e) {
        await DebugLogService.instance.log('ensureLoaded: hoi needsFullReload LOI (coi nhu khong can, giu hanh vi cu): $e');
      }
      if (!needsReload) return;
      await DebugLogService.instance.log(
        'ensureLoaded: slot=$slot dang can nap lai (native bao needsFullReload=true) — TU DONG nap lai, khong doi qua model khac nua',
      );
    }
    // backendPreference đọc từ cài đặt (mặc định 0 = tự thử QNN trước) —
    // có thể đổi qua GPU/CPU trong "Tối ưu AI local" MÀ KHÔNG CẦN build lại
    // app, hữu ích để khoanh vùng crash native (nếu QNN gây crash cứng,
    // Kotlin/Dart không bắt được lỗi, chỉ có cách thử đổi backend rồi xem
    // có còn crash không).
    final backendPreference = await _resolveBackendPreference();
    await DebugLogService.instance.log(
      'ensureLoaded: slot=$slot, modelPath=$modelPath, backendPreference=$backendPreference — CHUẨN BỊ gọi loadModel native',
    );
    final Map? result;
    try {
      result = await _methodChannel.invokeMethod<Map>('loadModel', {
        'slot': slot,
        'configPath': modelPath,
        'backendPreference': backendPreference,
      });
    } catch (e) {
      await DebugLogService.instance.log('ensureLoaded: loadModel NÉM LỖI (Dart/Kotlin bắt được): $e');
      rethrow;
    }
    await DebugLogService.instance.log('ensureLoaded: loadModel TRẢ VỀ xong: $result');
    if (result == null || result['success'] != true) {
      throw Exception('Không nạp được model tại $modelPath');
    }
    _activeBackend = result['backend'] as String?;
    _loaded = true;
    _loadedPath = modelPath;
  }

  // Xả model khỏi RAM (máy yếu, cần giải phóng chỗ cho model khác dùng
  // trước khi nạp) — gọi rõ ràng, không tự động, vì tầng trên (RAM đủ
  // hay không) mới biết lúc nào nên xả.
  Future<void> unload() async {
    if (!_loaded) return;
    await _methodChannel.invokeMethod('unload', {'slot': slot});
    _loaded = false;
    _activeBackend = null;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) async {
    final buffer = StringBuffer();
    await for (final chunk in generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      // ĐÃ THÊM: luôn false cho tác vụ 1 lần (vd từng đoạn tài liệu dịch/
      // tóm tắt) — mỗi đoạn nội dung độc lập, không liên quan đoạn trước,
      // tái sử dụng KV-cache ở đây có thể làm lẫn ngữ cảnh sai giữa các
      // đoạn không liên quan.
      reuseKv: false,
    )) {
      buffer.write(chunk);
    }
    return buffer.toString();
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    String stageLabel = 'Đang sinh văn bản...',
    bool reuseKv = false,
  }) async* {
    await ensureLoaded();

    // Đăng ký lắng nghe stream TRƯỚC khi gọi lệnh generate, tránh bỏ lỡ
    // kết quả đầu tiên (race condition giữa 2 kênh). Lọc đúng theo slot,
    // vì cả 2 slot dùng chung 1 EventChannel.
    final controller = StreamController<String>();
    late final StreamSubscription sub;
    // ĐÃ THÊM (lỗi CRASH THẬT phát hiện từ log runtime — SIGSEGV khi 2 lệnh
    // generate() chạy chồng lên nhau trên CÙNG 1 slot, xem chat_screen.dart):
    // trước đây, nếu người gọi hàm này (vd chat_screen.dart) NGỪNG LẮNG NGHE
    // stream giữa chừng — rời màn hình, đóng app, hoặc bất kỳ lý do gì
    // KHÁC với việc thật sự nhận đủ token `done=true` — lệnh `generate`
    // native đã gửi (`invokeMethod('generate', ...)` ở dưới, dùng
    // `unawaited`) VẪN TIẾP TỤC CHẠY MỒ CÔI trong nền, không có cách nào
    // huỷ. Nếu người dùng quay lại và gửi thêm 1 lệnh generate MỚI trên
    // CÙNG slot trước khi lệnh mồ côi đó chạy xong, 2 lệnh native VA CHẠM
    // nhau, làm hỏng session/KV-cache nội bộ MNN — chính là nguyên nhân
    // crash SIGSEGV đã xác nhận qua log CI. `doneReceived` theo dõi xem đã
    // nhận được tín hiệu `done=true` THẬT SỰ chưa, dùng ở khối `finally`
    // bên dưới.
    bool doneReceived = false;
    // ĐÃ THÊM: lớp phòng vệ "lặp vô tận" — xác nhận thật qua log (mục
    // 5.68 tài liệu kiến trúc: model dịch trả "8888888"; ảnh chụp màn
    // hình: Qwen 7B trả cả màn hình dấu "(((((("). Trước đây model rơi
    // vào lặp 1 ký tự/1 cụm ngắn thì KHÔNG có gì phát hiện — chạy tới hết
    // max_new_tokens (log thật: 1024 token trong 550 giây, máy nóng vô
    // ích). Đặt DUY NHẤT ở đây (trong listener EventChannel) vì đây là
    // điểm DUY NHẤT mọi nơi gọi generateStream() (chat, viết chương, dịch
    // thuật...) đều đi qua — sửa 1 chỗ, bảo vệ mọi nơi, không cần từng nơi
    // gọi tự cài lại logic phát hiện riêng.
    bool repetitionStopped = false;
    final fullTextSoFar = StringBuffer();
    sub = _eventChannel.receiveBroadcastStream().listen(
      (event) {
        final map = event as Map;
        if ((map['slot'] as int?) != slot) return;
        final token = map['token'] as String? ?? '';
        final done = map['done'] as bool? ?? false;
        if (token.isNotEmpty) {
          fullTextSoFar.write(token);
          controller.add(token);
          if (!repetitionStopped && fullTextSoFar.length >= 60) {
            final text = fullTextSoFar.toString();
            final tail = text.length > 200 ? text.substring(text.length - 200) : text;
            if (_looksLikeRepetitionLoop(tail)) {
              repetitionStopped = true;
              doneReceived = true; // ta tự gọi cancelGenerate ngay dưới đây — finally không cần gọi lại
              unawaited(DebugLogService.instance.log(
                'generateStream: slot=$slot — PHÁT HIỆN LẶP VÔ TẬN (repetition loop) sau ${fullTextSoFar.length} ký tự, dừng sớm + gọi cancelGenerate() native',
              ));
              controller.add(
                '\n\n⚠️ [Đã tự dừng: model rơi vào lặp vô tận. Thử tăng "Phạt lặp từ" (repetition penalty) trong Cài đặt sinh văn bản, hoặc đổi model khác.]',
              );
              controller.close();
              sub.cancel();
              unawaited(() async {
                try {
                  await _methodChannel.invokeMethod('cancelGenerate', {'slot': slot});
                } catch (_) {
                  // Bỏ qua — mục tiêu chính (ngừng nhận thêm token rác vào
                  // UI) đã đạt, lệnh generate mồ côi phía native tự kết
                  // thúc bình thường khi hết max_new_tokens nếu cancel lỗi.
                }
              }());
              return;
            }
          }
        }
        if (done) {
          doneReceived = true;
          controller.close();
          sub.cancel();
        }
      },
      onError: (e) {
        // Lỗi cũng coi như "đã xong" theo nghĩa không cần gọi cancelGenerate
        // nữa — native tự nó đã dừng (lỗi mới có thể phát ra được).
        doneReceived = true;
        controller.addError(e);
        controller.close();
        sub.cancel();
      },
    );

    unawaited(DebugLogService.instance.log(
      'generateStream: slot=$slot — CHUẨN BỊ gọi generate native (prompt dài ${systemPrompt.length + userPrompt.length} ký tự)',
    ));
    unawaited(_methodChannel.invokeMethod('generate', {
      'slot': slot,
      'prompt': '$systemPrompt\n\n$userPrompt',
      'stageLabel': stageLabel,
      'temperature': temperature,
      'topP': topP,
      'topK': topK,
      'repetitionPenalty': repetitionPenalty,
      'maxNewTokens': maxTokens,
      'reuseKv': reuseKv,
    }).then((_) {
      DebugLogService.instance.log('generateStream: slot=$slot — lệnh generate native trả về xong (không crash)');
    }).catchError((e) {
      DebugLogService.instance.log('generateStream: slot=$slot — generate NÉM LỖI (Dart/Kotlin bắt được): $e');
    }));

    try {
      yield* controller.stream;
    } finally {
      // ĐÃ THÊM: đây là điểm THỰC THI khi consumer NGỪNG LẮNG NGHE stream
      // này, DÙ VÌ LÝ DO GÌ (nhận đủ done=true bình thường, HOẶC bị huỷ
      // giữa chừng từ bên ngoài — vd `await for` bị `break`, widget bị
      // dispose khi đang generate). `sub.cancel()` gọi lại lần 2 (nếu đã
      // cancel ở nhánh `done` phía trên) là AN TOÀN — StreamSubscription
      // cho phép gọi `cancel()` nhiều lần không lỗi.
      await sub.cancel();
      if (!doneReceived) {
        unawaited(DebugLogService.instance.log(
          'generateStream: slot=$slot — consumer huỷ giữa chừng (CHƯA nhận done=true) — gọi cancelGenerate() native để không mồ côi',
        ));
        try {
          await _methodChannel.invokeMethod('cancelGenerate', {'slot': slot});
        } catch (e) {
          unawaited(DebugLogService.instance
              .log('generateStream: slot=$slot — cancelGenerate() native báo lỗi (bỏ qua, không phải lỗi nghiêm trọng): $e'));
        }
      }
    }
  }

  // ĐÃ THÊM: kiểm tra 1 cửa sổ ký tự cuối cùng (đã stream về) có "trông
  // giống" lặp vô tận hay không. Cố tình đơn giản/rẻ (chạy mỗi token mới)
  // thay vì phân tích thống kê đầy đủ kiểu `RepetitionAnalyzer` (dùng cho
  // "Kiểm tra lặp từ" thủ công trong chương đã viết xong — bài toán khác:
  // ở đó cần độ chính xác cao trên văn bản hoàn chỉnh, ở đây cần rẻ + đủ
  // nhạy để cắt sớm 1 luồng đang rõ ràng hỏng).
  //
  // 2 dấu hiệu, khớp đúng 2 trường hợp THẬT đã gặp trong log/ảnh chụp:
  // (a) 1 ký tự DUY NHẤT chiếm áp đảo cửa sổ — "8888888", "(((((((("
  // (b) 1 cụm ngắn (2-6 ký tự) lặp lại khít cả cửa sổ — tổng quát hơn,
  //     phòng trường hợp model lặp 1 cặp/cụm thay vì đúng 1 ký tự.
  static bool _looksLikeRepetitionLoop(String tailWindow) {
    // Bỏ khoảng trắng/xuống dòng trước khi đếm — văn bản bình thường có
    // rất nhiều khoảng trắng lặp lại hợp lệ, không phải dấu hiệu lỗi.
    final compact = tailWindow.replaceAll(RegExp(r'\s+'), '');
    if (compact.length < 60) return false; // cửa sổ còn quá ngắn, chưa đủ căn cứ để kết luận

    final counts = <String, int>{};
    for (final ch in compact.split('')) {
      counts[ch] = (counts[ch] ?? 0) + 1;
    }
    final maxCount = counts.values.fold<int>(0, (a, b) => a > b ? a : b);
    if (maxCount / compact.length > 0.85) return true;

    for (var period = 2; period <= 6; period++) {
      if (compact.length < period * 4) continue; // cần ít nhất 4 chu kỳ mới đủ chắc chắn
      final unit = compact.substring(0, period);
      var matches = true;
      for (var i = 0; i < compact.length; i += period) {
        final end = (i + period <= compact.length) ? i + period : compact.length;
        if (compact.substring(i, end) != unit.substring(0, end - i)) {
          matches = false;
          break;
        }
      }
      if (matches) return true;
    }
    return false;
  }

  Future<void> dispose() => unload();
}
