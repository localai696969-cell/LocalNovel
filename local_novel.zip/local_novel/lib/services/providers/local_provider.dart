import 'package:flutter_llama/flutter_llama.dart';
import '../ai_provider.dart';

// Chạy model nhúng thẳng qua flutter_llama — package này expose đầy đủ
// tham số GPU offload (nGpuLayers), số luồng (nThreads), context size,
// đúng như 3 thanh trượt ở màn "Tối ưu AI local" cần điều khiển. Model
// chỉ load lại khi đường dẫn thay đổi, không load lại mỗi lần chat để
// đỡ tốn thời gian (model 7-8B load rất chậm).
class LocalLlamaProvider implements AIProvider {
  final String modelPath;
  final int threads;
  final int contextSize;
  final int numGpuLayers;

  LocalLlamaProvider({
    required this.modelPath,
    this.threads = 4,
    this.contextSize = 2048,
    this.numGpuLayers = 99,
  });

  static String? _loadedPath;
  static final _llama = FlutterLlama.instance;

  @override
  String get name => 'AI local (nhúng trong APK)';

  @override
  String get description => 'Chạy hoàn toàn offline, ngay trong app, có GPU offload — không cần server hay Termux.';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  Future<void> _ensureLoaded() async {
    if (_loadedPath == modelPath) return; // đã load đúng model này rồi, khỏi load lại
    final config = LlamaConfig(
      modelPath: modelPath,
      nThreads: threads,
      nGpuLayers: numGpuLayers, // 0 = CPU thuần, -1 = toàn bộ layer trên GPU
      contextSize: contextSize,
      batchSize: 512,
      useGpu: true,
      verbose: false,
    );
    final success = await _llama.loadModel(config);
    if (!success) {
      throw Exception(
        'Không load được model tại "$modelPath". Kiểm tra: đường dẫn đúng chưa, '
        'file có bị lỗi/tải thiếu không, model có quá lớn so với RAM máy không.',
      );
    }
    _loadedPath = modelPath;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
  }) async {
    await _ensureLoaded();
    final response = await _llama.generate(GenerationParams(
      prompt: '$systemPrompt\n\n$userPrompt',
      temperature: temperature,
      maxTokens: maxTokens,
    ));
    return response.text;
  }

  // LƯU Ý: tài liệu flutter_llama chỉ thấy API generate() trả toàn bộ
  // kết quả một lần, chưa xác nhận có API stream token-by-token hay
  // không — nên hiện tại "giả lập" stream bằng cách trả nguyên khối kết
  // quả sau khi generate xong, thay vì hiện dần từng chữ như trước. Nếu
  // package có hỗ trợ stream thật, có thể cải thiện lại sau.
  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
  }) async* {
    final text = await generate(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
    );
    yield text;
  }
}
