import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../ai_provider.dart';

// Provider dùng chung cho OpenAI và bất kỳ dịch vụ nào expose API theo
// chuẩn "OpenAI-compatible" (rất phổ biến, kể cả một số dịch vụ cho phép
// chọn model ít giới hạn hơn dành riêng cho viết truyện hư cấu).
// Người dùng tự nhập baseUrl + apiKey trong Cài đặt, app không hardcode
// một nhà cung cấp cụ thể nào.
class OpenAICompatibleProvider implements AIProvider {
  final String baseUrl; // ví dụ: https://api.openai.com/v1
  final String apiKey;
  final String modelId;

  // ĐÃ THÊM (theo câu hỏi người dùng về hành vi khi GPU remote — vd Colab
  // — sập giữa chừng): trước đây `http.post`/`http.Request.send()` KHÔNG
  // có timeout nào cả. Nếu server sập theo kiểu "treo" (tiến trình đơ,
  // TCP không đóng sạch — thực tế rất dễ xảy ra với Colab miễn phí: hết
  // phiên, GPU OOM, hoặc Cloudflare Tunnel rớt giữa chừng) thay vì báo lỗi
  // kết nối rõ ràng ngay, request sẽ CHỜ VÔ THỜI HẠN — không exception,
  // không timeout, app trông như treo cứng. Tệ hơn: nút "Huỷ" trong
  // `chapters_batch_generate_screen.dart` chỉ kiểm tra cờ GIỮA các chương
  // (`isCancelled?.call()` trước khi bắt đầu chương kế), không cắt được 1
  // request HTTP đang treo giữa chừng — nghĩa là không có timeout thì
  // "Huỷ" gần như vô dụng đúng lúc cần nó nhất (khi server đã có vấn đề).
  // 10 phút: đủ rộng cho model 7B trên GPU T4 miễn phí (chia sẻ giữa
  // nhiều người dùng Colab khác, tốc độ không ổn định) sinh 1 chương
  // ~1500 token, nhưng vẫn đủ chặt để không để người dùng chờ mù cả buổi
  // nếu server thực sự đã treo.
  static const _requestTimeout = Duration(minutes: 10);
  // Idle timeout cho streaming (chat) — ngắn hơn hẳn timeout tổng ở trên vì
  // đây là khoảng cách chờ GIỮA 2 chunk liên tiếp, không phải cho cả lượt
  // sinh — 2 phút không có chunk mới nào là dấu hiệu rõ ràng server đã treo.
  static const _streamIdleTimeout = Duration(minutes: 2);

  OpenAICompatibleProvider({
    required this.baseUrl,
    required this.apiKey,
    required this.modelId,
  });

  @override
  String get name => 'API tương thích OpenAI';

  @override
  String get description => 'Dùng cho OpenAI hoặc bất kỳ endpoint tương thích nào bạn tự cấu hình.';

  @override
  Future<bool> isReady() async => apiKey.isNotEmpty && baseUrl.isNotEmpty;

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) async {
    final http.Response res;
    try {
      res = await http
          .post(
            Uri.parse('$baseUrl/chat/completions'),
            headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $apiKey'},
            body: jsonEncode({
              'model': modelId,
              'messages': [
                {'role': 'system', 'content': systemPrompt},
                {'role': 'user', 'content': userPrompt},
              ],
              'temperature': temperature,
              'max_tokens': maxTokens,
              // Chuẩn OpenAI chat/completions không có top_k/repetition_penalty
              // chính thức — top_p thì có, repetition_penalty gần tương đương
              // frequency_penalty (thang giá trị khác nhau nên chỉ chuyển đổi thô).
              // Nhiều endpoint "tương thích OpenAI" (vd llama.cpp server, vLLM,
              // Ollama) chấp nhận thêm top_k như phần mở rộng ngoài chuẩn — gửi
              // kèm, endpoint nào không hỗ trợ sẽ tự bỏ qua field lạ.
              'top_p': topP,
              'top_k': topK,
              'frequency_penalty': (repetitionPenalty - 1.0).clamp(-2.0, 2.0),
            }),
          )
          .timeout(_requestTimeout);
    } on TimeoutException {
      throw Exception(
          'Hết thời gian chờ (${_requestTimeout.inMinutes} phút) — server không phản hồi. '
          'Nếu đang dùng GPU từ xa (Colab): phiên có thể đã bị ngắt/GPU đã sập, '
          'thử chạy lại notebook Colab và cập nhật URL mới trong Cài đặt.');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    if (res.statusCode != 200) {
      throw Exception('Lỗi API: ${data['error']?['message'] ?? res.body}');
    }
    return data['choices'][0]['message']['content'] as String;
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false, // không dùng — chỉ có ý nghĩa với LocalLlamaProvider
  }) async* {
    final req = http.Request('POST', Uri.parse('$baseUrl/chat/completions'));
    req.headers['Content-Type'] = 'application/json';
    req.headers['Authorization'] = 'Bearer $apiKey';
    req.body = jsonEncode({
      'model': modelId,
      'messages': [
        {'role': 'system', 'content': systemPrompt},
        {'role': 'user', 'content': userPrompt},
      ],
      'temperature': temperature,
      'max_tokens': maxTokens,
      'top_p': topP,
      'top_k': topK,
      'frequency_penalty': (repetitionPenalty - 1.0).clamp(-2.0, 2.0),
      'stream': true,
    });
    final http.StreamedResponse streamed;
    try {
      streamed = await req.send().timeout(_requestTimeout);
    } on TimeoutException {
      throw Exception(
          'Hết thời gian chờ (${_requestTimeout.inMinutes} phút) — server không phản hồi kết nối ban đầu. '
          'Nếu đang dùng GPU từ xa (Colab): phiên có thể đã bị ngắt/GPU đã sập.');
    }
    // ĐÃ THÊM: timeout THEO TỪNG CHUNK (không phải timeout tổng) — 1 chương
    // dài streaming token-by-token có thể chạy hợp lệ nhiều phút, nhưng
    // KHOẢNG CÁCH giữa 2 token/chunk liên tiếp mà quá dài là dấu hiệu server
    // đã treo (GPU sập giữa chừng nhưng chưa đóng kết nối TCP) — không có
    // dòng này, `await for` sẽ chờ vô thời hạn không báo lỗi, y hệt vấn đề
    // đã có ở generate() (xem giải thích ở _requestTimeout phía trên).
    final byteStream = streamed.stream.timeout(
      _streamIdleTimeout,
      onTimeout: (sink) => sink.addError(TimeoutException(
          'Server ngừng phản hồi giữa chừng quá ${_streamIdleTimeout.inMinutes} phút — '
          'có thể GPU từ xa đã sập, kiểm tra lại notebook Colab.')),
    );
    await for (final chunk in byteStream.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (!line.startsWith('data: ')) continue;
        final payload = line.substring(6).trim();
        if (payload == '[DONE]') return;
        if (payload.isEmpty) continue;
        try {
          final data = jsonDecode(payload);
          final delta = data['choices'][0]['delta']['content'];
          if (delta != null) yield delta as String;
        } catch (_) {}
      }
    }
  }
}
