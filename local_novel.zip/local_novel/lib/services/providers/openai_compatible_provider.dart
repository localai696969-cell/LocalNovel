import 'dart:convert';
import 'package:http/http.dart' as http;
import '../ai_provider.dart';

// Provider dùng chung cho OpenAI và bất kỳ dịch vụ nào expose API theo
// chuẩn "OpenAI-compatible" (rất phổ biến, kể cả một số dịch vụ cho phép
// chọn model ít giới hạn hơn dành riêng cho viết truyện hư cấu).
// Người dùng tự nhập baseUrl + apiKey trong Cài đặt, app không hardcode
// một nhà cung cấp cụ thể nào.
class OpenAICompatibleProvider implements AIProvider {
  final String baseUrl; // ví dụ: https://api.openai.com/v1
  final String apiKey;
  final String modelId;

  OpenAICompatibleProvider({
    required this.baseUrl,
    required this.apiKey,
    required this.modelId,
  });

  @override
  String get name => 'API tương thích OpenAI';

  @override
  String get description => 'Dùng cho OpenAI hoặc bất kỳ endpoint tương thích nào bạn tự cấu hình.';

  @override
  Future<bool> isReady() async => apiKey.isNotEmpty && baseUrl.isNotEmpty;

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/chat/completions'),
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $apiKey'},
      body: jsonEncode({
        'model': modelId,
        'messages': [
          {'role': 'system', 'content': systemPrompt},
          {'role': 'user', 'content': userPrompt},
        ],
        'temperature': temperature,
        'max_tokens': maxTokens,
      }),
    );
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    if (res.statusCode != 200) {
      throw Exception('Lỗi API: ${data['error']?['message'] ?? res.body}');
    }
    return data['choices'][0]['message']['content'] as String;
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
  }) async* {
    final req = http.Request('POST', Uri.parse('$baseUrl/chat/completions'));
    req.headers['Content-Type'] = 'application/json';
    req.headers['Authorization'] = 'Bearer $apiKey';
    req.body = jsonEncode({
      'model': modelId,
      'messages': [
        {'role': 'system', 'content': systemPrompt},
        {'role': 'user', 'content': userPrompt},
      ],
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': true,
    });
    final streamed = await req.send();
    await for (final chunk in streamed.stream.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (!line.startsWith('data: ')) continue;
        final payload = line.substring(6).trim();
        if (payload == '[DONE]') return;
        if (payload.isEmpty) continue;
        try {
          final data = jsonDecode(payload);
          final delta = data['choices'][0]['delta']['content'];
          if (delta != null) yield delta as String;
        } catch (_) {}
      }
    }
  }
}
