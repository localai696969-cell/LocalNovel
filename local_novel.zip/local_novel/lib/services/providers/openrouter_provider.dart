import '../ai_provider.dart';
import 'openai_compatible_provider.dart';

// ĐÃ THÊM — mục BQ, 2026-09-23, theo yêu cầu người dùng ("thêm tính năng
// api model openrouter").
//
// OpenRouter (openrouter.ai) tổng hợp NHIỀU model từ NHIỀU nhà cung cấp
// (Anthropic, Google, Meta, Mistral, DeepSeek, các model mã nguồn mở
// không kiểm duyệt dành cho viết hư cấu...) sau ĐÚNG 1 API key DUY NHẤT,
// và expose đúng chuẩn "OpenAI-compatible" (/chat/completions, cùng định
// dạng request/response) — về bản chất kỹ thuật GIỐNG HỆT
// `OpenAICompatibleProvider` đã có sẵn, chỉ khác duy nhất 1 điều: base
// URL cố định. Vì vậy provider này KHÔNG viết lại logic request/stream/
// timeout (đã có, đã qua dùng thực tế) — chỉ BỌC lại
// `OpenAICompatibleProvider` với base URL đã điền sẵn, để người dùng
// không cần tự gõ đúng URL (khác hẳn lựa chọn "Tương thích OpenAI (tự
// nhập URL)" đã có, nơi phải tự biết/gõ URL).
//
// modelId vẫn để người dùng tự nhập tự do (KHÔNG hardcode 1 model cụ
// thể) — OpenRouter có hàng trăm model, thêm/bớt thường xuyên, dạng
// "nhacungcap/ten-model" (vd "anthropic/claude-3.5-sonnet",
// "deepseek/deepseek-chat", "meta-llama/llama-3.1-70b-instruct") — xem
// danh sách ĐẦY ĐỦ, LUÔN cập nhật tại openrouter.ai/models (app không tự
// tải/hiển thị danh sách này — model mới xuất hiện liên tục, hardcode 1
// danh sách trong app sẽ lập tức lỗi thời).
//
// Giới hạn thật, chưa xác nhận — không giấu: KHÔNG gửi kèm 2 header
// OpenRouter khuyến nghị (không bắt buộc) là `HTTP-Referer`/`X-Title`
// (dùng cho xếp hạng/thống kê phía OpenRouter, không ảnh hưởng việc gọi
// API có thành công hay không) — cố tình bỏ qua để giữ code đơn giản,
// tái dùng nguyên vẹn `OpenAICompatibleProvider` mà không cần sửa lớp đó
// để nhận thêm header tuỳ chỉnh. Cũng CHƯA build/test thật (môi trường
// soạn không có Flutter/Dart SDK — xem quy tắc bắt buộc mục 0 tài liệu
// kiến trúc).
class OpenRouterProvider implements AIProvider {
  static const _baseUrl = 'https://openrouter.ai/api/v1';

  final String apiKey;
  final String modelId;
  final OpenAICompatibleProvider _delegate;

  OpenRouterProvider({required this.apiKey, required this.modelId})
      : _delegate = OpenAICompatibleProvider(baseUrl: _baseUrl, apiKey: apiKey, modelId: modelId);

  @override
  String get name => 'OpenRouter';

  @override
  String get description =>
      'Dùng chung 1 API key của OpenRouter (openrouter.ai) để gọi nhiều model từ nhiều nhà cung cấp khác nhau — nhập đúng modelId (vd "anthropic/claude-3.5-sonnet"), xem danh sách đầy đủ tại openrouter.ai/models.';

  @override
  Future<bool> isReady() => _delegate.isReady();

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) {
    return _delegate.generate(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
    );
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false,
  }) {
    return _delegate.generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      reuseKv: reuseKv,
    );
  }
}
