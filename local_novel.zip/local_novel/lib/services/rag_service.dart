import '../models/story_models.dart';
import 'database_service.dart';
import 'embedding_service.dart';

// Đây là phần giải quyết bài toán "truyện 1000+ chương mà AI không quên,
// không vi phạm luật thế giới". Model local trên điện thoại chỉ có
// context window nhỏ (vài nghìn token), nên KHÔNG nhồi toàn bộ truyện
// vào prompt. Thay vào đó: chỉ chọn đúng phần liên quan, qua 3 cơ chế
// kết hợp (giống Lorebook của NovelAI, cộng thêm lớp ngữ nghĩa):
//
//  1. Luật cứng (isHardRule): luôn luôn nạp toàn bộ, không phụ thuộc
//     từ khóa hay độ liên quan, vì đây là ràng buộc không được phép quên.
//  2. Khớp từ khóa: quét đoạn văn/câu hỏi hiện tại, tìm entry nào trong
//     Character/WorldRule có keyword xuất hiện nguyên văn -> nạp entry đó.
//     Nhanh, chính xác tuyệt đối khi đúng tên riêng, nhưng bỏ lỡ các
//     cách diễn đạt khác (ví dụ nói "vực sâu" thay vì đúng tên riêng).
//  3. Truy xuất embedding: biến đoạn đang viết + từng entry/chương thành
//     vector, xếp hạng theo cosine similarity, lấy top-K liên quan nhất
//     dù không trùng từ khóa nguyên văn — đây là lớp "nhớ ngữ nghĩa"
//     thật sự, giúp mở rộng ra ngoài giới hạn của khớp từ khóa.
//
// TÁCH THEO TỪNG TRUYỆN: mọi truy vấn đều giới hạn trong novelId được
// truyền vào constructor — RAG của truyện A không bao giờ lẫn dữ liệu
// của truyện B, kể cả 2 truyện đang dùng chung 1 model/provider AI.
class RagService {
  final DatabaseService db;
  final EmbeddingService embedder;
  final String novelId;
  final int contextBudgetChars;
  RagService(this.db, this.embedder, {required this.novelId, this.contextBudgetChars = 3500});

  static const int topKSemantic = 4;
  static const double similarityThreshold = 0.15;

  Future<void> indexCharacter(Character c) async {
    final vec = await embedder.embed('${c.name}. ${c.role}. ${c.description}');
    await db.upsertEmbedding('character', c.id, vec);
  }

  Future<void> indexWorldRule(WorldRule r) async {
    final vec = await embedder.embed('${r.title}. ${r.content}');
    await db.upsertEmbedding('world_rule', r.id, vec);
  }

  Future<void> indexChapter(Chapter c) async {
    final basis = c.autoSummary ?? c.content;
    final vec = await embedder.embed('Chương ${c.number}: ${c.title}. $basis');
    await db.upsertEmbedding('chapter', c.id, vec);
  }

  Future<List<String>> _topMatches(
    String entityType,
    List<double> queryVector,
    List<String> allowedIds, {
    int topK = topKSemantic,
  }) async {
    if (allowedIds.isEmpty) return [];
    final all = await db.embeddingsFor(entityType, entityIds: allowedIds);
    final scored = all.entries
        .map((e) => MapEntry(e.key, cosineSimilarity(queryVector, e.value)))
        .where((e) => e.value >= similarityThreshold)
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return scored.take(topK).map((e) => e.key).toList();
  }

  Future<String> buildContext({
    required String currentText,
    int recentChapterCount = 2,
  }) async {
    final buffer = StringBuffer();
    int used = 0;

    void addSection(String title, List<String> lines) {
      if (lines.isEmpty) return;
      final text = '### $title\n${lines.join('\n')}\n\n';
      if (used + text.length > contextBudgetChars) return;
      buffer.write(text);
      used += text.length;
    }

    final queryVector = await embedder.embed(currentText);
    final lowerText = currentText.toLowerCase();

    final rules = await db.allWorldRules(novelId);
    final hardRules = rules.where((r) => r.isHardRule);
    addSection(
      'Luật thế giới (tuyệt đối không vi phạm)',
      hardRules.map((r) => '- ${r.title}: ${r.content}').toList(),
    );

    final characters = await db.allCharacters(novelId);
    final keywordCharIds = characters
        .where((c) => c.keywords.any((k) => lowerText.contains(k.toLowerCase())))
        .map((c) => c.id)
        .toSet();
    final semanticCharIds =
        (await _topMatches('character', queryVector, characters.map((c) => c.id).toList())).toSet();
    final relevantCharIds = keywordCharIds.union(semanticCharIds);
    final relevantChars = characters.where((c) => relevantCharIds.contains(c.id));
    addSection(
      'Nhân vật liên quan',
      relevantChars.map((c) => '- ${c.name} (${c.role}): ${c.description}').toList(),
    );

    final softRules = rules.where((r) => !r.isHardRule);
    final keywordRuleIds = softRules
        .where((r) => r.keywords.any((k) => lowerText.contains(k.toLowerCase())))
        .map((r) => r.id)
        .toSet();
    final semanticRuleIds =
        (await _topMatches('world_rule', queryVector, softRules.map((r) => r.id).toList())).toSet();
    final relevantRuleIds = keywordRuleIds.union(semanticRuleIds);
    final relevantRules = softRules.where((r) => relevantRuleIds.contains(r.id));
    addSection(
      'Bối cảnh liên quan',
      relevantRules.map((r) => '- ${r.title}: ${r.content}').toList(),
    );

    final allChapters = await db.allChapters(novelId);
    final chapterById = {for (final c in allChapters) c.id: c};
    final semanticChapterIds =
        await _topMatches('chapter', queryVector, allChapters.map((c) => c.id).toList(), topK: 3);
    final semanticChapters = semanticChapterIds.map((id) => chapterById[id]).whereType<Chapter>();
    addSection(
      'Chương liên quan (truy xuất ngữ nghĩa)',
      semanticChapters
          .map((c) => '- Chương ${c.number} (${c.title}): ${c.autoSummary ?? _excerpt(c.content)}')
          .toList(),
    );

    final recent = await db.recentChapters(novelId, recentChapterCount);
    addSection(
      'Tóm tắt các chương gần nhất',
      recent.map((c) => '- Chương ${c.number} (${c.title}): ${c.autoSummary ?? _excerpt(c.content)}').toList(),
    );

    return buffer.toString();
  }

  String _excerpt(String content) => content.substring(0, content.length > 200 ? 200 : content.length);

  Future<List<String>> previewActiveEntries(String currentText) async {
    final queryVector = await embedder.embed(currentText);
    final lowerText = currentText.toLowerCase();
    final characters = await db.allCharacters(novelId);
    final rules = await db.allWorldRules(novelId);

    final names = <String>[];
    for (final c in characters) {
      final keywordHit = c.keywords.any((k) => lowerText.contains(k.toLowerCase()));
      if (keywordHit) names.add(c.name);
    }
    final semanticCharIds = await _topMatches('character', queryVector, characters.map((c) => c.id).toList(), topK: 3);
    for (final id in semanticCharIds) {
      final matches = characters.where((x) => x.id == id);
      if (matches.isNotEmpty && !names.contains(matches.first.name)) {
        names.add('${matches.first.name} (ngữ nghĩa)');
      }
    }
    for (final r in rules.where((r) => r.isHardRule)) {
      names.add('[Luật] ${r.title}');
    }
    return names;
  }

  Future<String> buildSystemPrompt({
    required String userInstruction,
    required String currentText,
  }) async {
    final context = await buildContext(currentText: currentText);
    // ĐÃ SỬA: trước đây, khi Story Bible CHƯA CÓ GÌ (chưa nhập luật thế
    // giới/nhân vật/chương nào), `context` ở đây là chuỗi RỖNG — nhưng
    // đoạn văn bản luôn viết cứng "Dưới đây là dữ liệu Story Bible..."
    // rồi để trống ngay sau đó, và vẫn ra lệnh model "tham chiếu đúng
    // Story Bible". Model 7B (đặc biệt bản uncensored, dễ cố "chiều"
    // theo yêu cầu) khi bị bắt tham chiếu một thứ trống rỗng thường TỰ
    // BỊA ra nội dung Story Bible giả cho có, gây hiểu lầm là app rò rỉ
    // dữ liệu lạ/có bộ lọc ẩn — thực chất chỉ là ảo giác (hallucination)
    // do cách viết prompt cũ. Giờ nói thẳng với model khi trống, cấm bịa.
    final hasContext = context.trim().isNotEmpty;
    final bibleSection = hasContext
        ? '''Dưới đây là dữ liệu Story Bible liên quan tới đoạn đang viết. Bám sát
các luật thế giới và thông tin nhân vật này; nếu nội dung mới có khả
năng mâu thuẫn với dữ liệu dưới đây, hãy nêu rõ mâu thuẫn đó thay vì
lờ đi.

$context'''
        : '''Story Bible của truyện này HIỆN ĐANG TRỐNG — chưa có luật thế giới,
nhân vật, hay chương nào được lưu trong hệ thống. TUYỆT ĐỐI KHÔNG được
tự bịa ra bất kỳ chi tiết Story Bible nào (thế giới, nhân vật, mục
tiêu, luật lệ...). Nếu người dùng hỏi về Story Bible hoặc yêu cầu tham
chiếu nó, hãy trả lời trung thực rằng chưa có dữ liệu nào được nhập và
đề nghị họ thêm vào phần Bách khoa trước.''';

    return '''
Bạn là trợ lý viết tiểu thuyết dài kỳ.

$bibleSection

Yêu cầu chung của người viết: $userInstruction
''';
  }

  Future<String> buildConsistencyCheckPrompt(Chapter chapter) async {
    final context = await buildContext(currentText: chapter.content, recentChapterCount: 1);
    final hasContext = context.trim().isNotEmpty;
    if (!hasContext) {
      // ĐÃ SỬA: cùng lỗi hallucination như buildSystemPrompt ở trên —
      // Story Bible trống thì không có gì để đối chiếu, không nên gọi
      // model đi "tìm mâu thuẫn" với dữ liệu không tồn tại.
      return '''
Story Bible của truyện này hiện đang trống — chưa có luật thế giới hay
nhân vật nào được lưu để đối chiếu. Chỉ trả lời đúng 1 câu: "Chưa có dữ
liệu Story Bible để đối chiếu." Không bịa ra bất kỳ điểm mâu thuẫn nào.
''';
    }
    return '''
Đối chiếu nội dung chương sau với Story Bible bên dưới. Chỉ trả lời
bằng "OK" nếu không có mâu thuẫn, hoặc liệt kê ngắn gọn từng điểm nghi
ngờ mâu thuẫn (tên riêng, mốc thời gian, luật thế giới, trạng thái
nhân vật).

$context

### Nội dung chương ${chapter.number}: ${chapter.title}
${chapter.content}
''';
  }
}
