import '../models/story_models.dart';
import 'database_service.dart';
import 'embedding_service.dart';

// Đây là phần giải quyết bài toán "truyện 1000+ chương mà AI không quên,
// không vi phạm luật thế giới". Model local trên điện thoại chỉ có
// context window nhỏ (vài nghìn token), nên KHÔNG nhồi toàn bộ truyện
// vào prompt. Thay vào đó: chỉ chọn đúng phần liên quan, qua 3 cơ chế
// kết hợp (giống Lorebook của NovelAI, cộng thêm lớp ngữ nghĩa):
//
//  1. Luật cứng (isHardRule): luôn luôn nạp toàn bộ, không phụ thuộc
//     từ khóa hay độ liên quan, vì đây là ràng buộc không được phép quên.
//  2. Khớp từ khóa: quét đoạn văn/câu hỏi hiện tại, tìm entry nào trong
//     Character/WorldRule có keyword xuất hiện nguyên văn -> nạp entry đó.
//     Nhanh, chính xác tuyệt đối khi đúng tên riêng, nhưng bỏ lỡ các
//     cách diễn đạt khác (ví dụ nói "vực sâu" thay vì đúng tên riêng).
//  3. Truy xuất embedding: biến đoạn đang viết + từng entry/chương thành
//     vector, xếp hạng theo cosine similarity, lấy top-K liên quan nhất
//     dù không trùng từ khóa nguyên văn — đây là lớp "nhớ ngữ nghĩa"
//     thật sự, giúp mở rộng ra ngoài giới hạn của khớp từ khóa.
//
// TÁCH THEO TỪNG TRUYỆN: mọi truy vấn đều giới hạn trong novelId được
// truyền vào constructor — RAG của truyện A không bao giờ lẫn dữ liệu
// của truyện B, kể cả 2 truyện đang dùng chung 1 model/provider AI.
class RagService {
  final DatabaseService db;
  final EmbeddingService embedder;
  final String novelId;
  final int contextBudgetChars;
  RagService(this.db, this.embedder, {required this.novelId, this.contextBudgetChars = 3500});

  static const int topKSemantic = 4;
  static const double similarityThreshold = 0.15;

  // ĐÃ THÊM (theo yêu cầu người dùng: "dàn ý/tuyến truyện/luật thế giới
  // đều hardcode cho toàn truyện, không tuỳ chọn theo chương/hồi/quyển")
  // — kiểm tra 1 entry (Character/WorldRule) có "đang có hiệu lực" tại
  // SỐ CHƯƠNG đang viết hay không. `currentChapterNumber == null` (không
  // biết đang viết ở đâu, vd chat tự do không gắn theo 1 chương cụ thể)
  // → KHÔNG lọc, giữ nguyên hành vi CŨ (nạp hết như trước khi có tính
  // năng này). Entry có `from`/`to` đều null (mặc định của MỌI entry
  // trước khi tính năng này tồn tại) → luôn có hiệu lực, không đổi gì.
  static bool _isInScope(int? from, int? to, int? currentChapterNumber) {
    if (currentChapterNumber == null) return true;
    if (from != null && currentChapterNumber < from) return false;
    if (to != null && currentChapterNumber > to) return false;
    return true;
  }

  // ĐÃ THÊM: giải quyết phạm vi hiệu lực khi entry có thể chọn 1 trong 2
  // kiểu — theo SỐ CHƯƠNG cụ thể (effectiveFromChapter/effectiveToChapter)
  // HOẶC theo QUYỂN/HỒI (effectiveFromVolumeId/effectiveToVolumeId, dò lại
  // khoảng chương thật của quyển đó MỖI LẦN gọi qua volumeRanges — không
  // đóng băng, tự mở rộng khi quyển có thêm chương). Quyển được ƯU TIÊN
  // nếu entry lỡ có cả 2 kiểu cùng lúc (không nên xảy ra ở UI, nhưng xử
  // lý an toàn nếu có). volumeRanges truyền vào từ NGOÀI (buildContext chỉ
  // truy vấn 1 LẦN DUY NHẤT cho cả loạt entry, không lặp lại N lần).
  static (int?, int?) _resolveScope(
    int? fromChapter,
    int? toChapter,
    String? fromVolumeId,
    String? toVolumeId,
    Map<String, (int, int)> volumeRanges,
  ) {
    if (fromVolumeId != null || toVolumeId != null) {
      final fromRange = fromVolumeId != null ? volumeRanges[fromVolumeId] : null;
      final toRange = toVolumeId != null ? volumeRanges[toVolumeId] : null;
      // Quyển được chọn nhưng CHƯA có chương nào (fromRange/toRange null)
      // → coi như phạm vi rỗng thật sự (không chương nào hiện đang thuộc
      // quyển đó) — trả về (1, 0): from > to, mọi so sánh số chương thật
      // sẽ luôn trượt ra ngoài, đúng ngữ nghĩa "chưa có gì để áp dụng".
      final from = fromRange?.$1 ?? (fromVolumeId != null ? 1 : null);
      final to = toRange?.$2 ?? (toVolumeId != null ? 0 : null);
      return (from, to);
    }
    return (fromChapter, toChapter);
  }

  // ĐÃ THÊM (theo yêu cầu người dùng: "nếu ai không tham chiếu thì mấy cái
  // bible đâu có ý nghĩa tồn tại đâu nữa") — hàm CÔNG KHAI, dùng chung cho
  // BẤT KỲ nơi nào khác trong app cần "mô tả + chi tiết đúng giai đoạn"
  // của 1 entry Bible bất kỳ, không riêng buildContext() ở dưới. Trước
  // tiên dùng cho StyleProfile (style_service.dart) — trước đây văn phong
  // được chọn thủ công chỉ lấy `profileDescription` gốc, KHÔNG ghép chi
  // tiết theo giai đoạn dù người dùng đã có thể thêm chi tiết cho nó.
  Future<String> describeEntryWithFacts({
    required String parentType,
    required String parentId,
    required String baseDescription,
    int? currentChapterNumber,
  }) async {
    final volumeRanges = await db.volumeChapterRanges(novelId);
    final facts = await db.factsFor(parentType, parentId);
    final inScopeFacts = facts.where((f) {
      final (from, to) =
          _resolveScope(f.effectiveFromChapter, f.effectiveToChapter, f.effectiveFromVolumeId, f.effectiveToVolumeId, volumeRanges);
      return _isInScope(from, to, currentChapterNumber);
    });
    final factText = inScopeFacts.map((f) => f.factText).join('; ');
    return factText.isEmpty ? baseDescription : '$baseDescription ($factText)';
  }

  Future<void> indexCharacter(Character c) async {
    final vec = await embedder.embed('${c.name}. ${c.role}. ${c.description}');
    await db.upsertEmbedding('character', c.id, vec);
  }

  Future<void> indexWorldRule(WorldRule r) async {
    final vec = await embedder.embed('${r.title}. ${r.content}');
    await db.upsertEmbedding('world_rule', r.id, vec);
  }

  Future<void> indexChapter(Chapter c) async {
    final basis = c.autoSummary ?? c.content;
    final vec = await embedder.embed('Chương ${c.number}: ${c.title}. $basis');
    await db.upsertEmbedding('chapter', c.id, vec);
  }

  Future<List<String>> _topMatches(
    String entityType,
    List<double> queryVector,
    List<String> allowedIds, {
    int topK = topKSemantic,
  }) async {
    if (allowedIds.isEmpty) return [];
    final all = await db.embeddingsFor(entityType, entityIds: allowedIds);
    final scored = all.entries
        .map((e) => MapEntry(e.key, cosineSimilarity(queryVector, e.value)))
        .where((e) => e.value >= similarityThreshold)
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return scored.take(topK).map((e) => e.key).toList();
  }

  Future<String> buildContext({
    required String currentText,
    int recentChapterCount = 2,
    // ĐÃ THÊM: số chương đang viết/soạn — dùng để lọc Character/WorldRule
    // theo phạm vi hiệu lực (effectiveFromChapter/effectiveToChapter).
    // null (mặc định) = không biết/không áp dụng, KHÔNG lọc gì cả — giữ
    // nguyên hành vi cũ cho mọi nơi gọi CHƯA cập nhật để truyền vào.
    int? currentChapterNumber,
  }) async {
    final buffer = StringBuffer();
    int used = 0;

    void addSection(String title, List<String> lines) {
      if (lines.isEmpty) return;
      final text = '### $title\n${lines.join('\n')}\n\n';
      if (used + text.length > contextBudgetChars) return;
      buffer.write(text);
      used += text.length;
    }

    final queryVector = await embedder.embed(currentText);
    final lowerText = currentText.toLowerCase();

    // Fetch 1 LẦN DUY NHẤT cho cả loạt entry bên dưới — tránh truy vấn DB
    // lặp lại cho từng Character/WorldRule riêng lẻ.
    final volumeRanges = await db.volumeChapterRanges(novelId);
    bool inScope(int? fc, int? tc, String? fv, String? tv) {
      final (from, to) = _resolveScope(fc, tc, fv, tv, volumeRanges);
      return _isInScope(from, to, currentChapterNumber);
    }

    final rules = await db.allWorldRules(novelId);
    final scopedRules = rules
        .where((r) => inScope(r.effectiveFromChapter, r.effectiveToChapter, r.effectiveFromVolumeId, r.effectiveToVolumeId))
        .toList();
    // ĐÃ THÊM: "chi tiết theo giai đoạn" (BibleFact) — nạp 1 LẦN cho TOÀN
    // BỘ luật thế giới trong truyện (tránh N+1 query), rồi lọc theo phạm
    // vi TỪNG fact khi ghép vào từng dòng bên dưới. Ví dụ: luật ở Hồi 1
    // nói "X là điều cấm kỵ", Hồi 2 lật lại "X không còn cấm nữa" — AI chỉ
    // thấy ĐÚNG fact khớp chương đang viết, không thấy cả 2 gây mâu thuẫn.
    final ruleFactsByParent = await db.allFactsForType(novelId, 'world_rule');
    String describeRule(WorldRule r) {
      final facts = (ruleFactsByParent[r.id] ?? [])
          .where((f) => inScope(f.effectiveFromChapter, f.effectiveToChapter, f.effectiveFromVolumeId, f.effectiveToVolumeId));
      final factText = facts.map((f) => f.factText).join('; ');
      return factText.isEmpty ? '- ${r.title}: ${r.content}' : '- ${r.title}: ${r.content} (${factText})';
    }

    final hardRules = scopedRules.where((r) => r.isHardRule);
    addSection(
      'Luật thế giới (tuyệt đối không vi phạm)',
      hardRules.map(describeRule).toList(),
    );

    final characters = await db.allCharacters(novelId);
    final scopedCharacters = characters
        .where((c) => inScope(c.effectiveFromChapter, c.effectiveToChapter, c.effectiveFromVolumeId, c.effectiveToVolumeId))
        .toList();
    final characterFactsByParent = await db.allFactsForType(novelId, 'character');
    String describeCharacter(Character c) {
      final facts = (characterFactsByParent[c.id] ?? [])
          .where((f) => inScope(f.effectiveFromChapter, f.effectiveToChapter, f.effectiveFromVolumeId, f.effectiveToVolumeId));
      final factText = facts.map((f) => f.factText).join('; ');
      final base = '- ${c.name} (${c.role}): ${c.description}';
      return factText.isEmpty ? base : '$base ($factText)';
    }

    final keywordCharIds = scopedCharacters
        .where((c) => c.keywords.any((k) => lowerText.contains(k.toLowerCase())))
        .map((c) => c.id)
        .toSet();
    final semanticCharIds =
        (await _topMatches('character', queryVector, scopedCharacters.map((c) => c.id).toList())).toSet();
    final relevantCharIds = keywordCharIds.union(semanticCharIds);
    final relevantChars = scopedCharacters.where((c) => relevantCharIds.contains(c.id));
    addSection(
      'Nhân vật liên quan',
      relevantChars.map(describeCharacter).toList(),
    );

    final softRules = scopedRules.where((r) => !r.isHardRule);
    final keywordRuleIds = softRules
        .where((r) => r.keywords.any((k) => lowerText.contains(k.toLowerCase())))
        .map((r) => r.id)
        .toSet();
    final semanticRuleIds =
        (await _topMatches('world_rule', queryVector, softRules.map((r) => r.id).toList())).toSet();
    final relevantRuleIds = keywordRuleIds.union(semanticRuleIds);
    final relevantRules = softRules.where((r) => relevantRuleIds.contains(r.id));
    addSection(
      'Bối cảnh liên quan',
      relevantRules.map(describeRule).toList(),
    );

    final allChapters = await db.allChapters(novelId);
    final chapterById = {for (final c in allChapters) c.id: c};
    final semanticChapterIds =
        await _topMatches('chapter', queryVector, allChapters.map((c) => c.id).toList(), topK: 3);
    final semanticChapters = semanticChapterIds.map((id) => chapterById[id]).whereType<Chapter>();
    addSection(
      'Chương liên quan (truy xuất ngữ nghĩa)',
      semanticChapters
          .map((c) => '- Chương ${c.number} (${c.title}): ${c.autoSummary ?? _excerpt(c.content)}')
          .toList(),
    );

    final recent = await db.recentChapters(novelId, recentChapterCount);
    addSection(
      'Tóm tắt các chương gần nhất',
      recent.map((c) => '- Chương ${c.number} (${c.title}): ${c.autoSummary ?? _excerpt(c.content)}').toList(),
    );

    // ĐÃ THÊM (theo yêu cầu người dùng: "nếu ai không tham chiếu thì mấy
    // cái bible kia tồn tại làm chi") — nối nốt 3 loại Bible còn lại chưa
    // hề được AI tham chiếu tới: Thuật ngữ, Tuyến truyện, Dàn ý.

    // Thuật ngữ — chỉ đưa vào nếu TÊN thuật ngữ xuất hiện trong văn bản
    // đang viết (giống cách lọc Nhân vật/Luật bằng từ khóa) — tránh nhồi
    // cả bảng thuật ngữ vào mọi lượt viết dù không liên quan.
    final glossaryTerms = await db.allGlossaryTerms(novelId);
    final scopedGlossary = glossaryTerms
        .where((t) => inScope(t.effectiveFromChapter, t.effectiveToChapter, t.effectiveFromVolumeId, t.effectiveToVolumeId))
        .where((t) => lowerText.contains(t.term.toLowerCase()));
    final glossaryFactsByParent = await db.allFactsForType(novelId, 'glossary_term');
    addSection(
      'Thuật ngữ cần dùng đúng',
      scopedGlossary.map((t) {
        final facts = (glossaryFactsByParent[t.id] ?? [])
            .where((f) => inScope(f.effectiveFromChapter, f.effectiveToChapter, f.effectiveFromVolumeId, f.effectiveToVolumeId));
        final factText = facts.map((f) => f.factText).join('; ');
        final base = '- ${t.term}: ${t.definition}';
        return factText.isEmpty ? base : '$base ($factText)';
      }).toList(),
    );

    // Tuyến truyện — chỉ đưa các tuyến ĐANG CHẠY (status active) và đang
    // trong phạm vi hiệu lực, làm lời nhắc để AI không quên các mạch
    // truyện phụ đang dang dở khi viết tiếp.
    final plotThreads = await db.allPlotThreads(novelId);
    final scopedThreads = plotThreads
        .where((t) => t.status == 'active')
        .where((t) => inScope(t.effectiveFromChapter, t.effectiveToChapter, t.effectiveFromVolumeId, t.effectiveToVolumeId));
    final threadFactsByParent = await db.allFactsForType(novelId, 'plot_thread');
    addSection(
      'Tuyến truyện đang diễn ra (đừng bỏ quên nếu phù hợp)',
      scopedThreads.map((t) {
        final facts = (threadFactsByParent[t.id] ?? [])
            .where((f) => inScope(f.effectiveFromChapter, f.effectiveToChapter, f.effectiveFromVolumeId, f.effectiveToVolumeId));
        final factText = facts.map((f) => f.factText).join('; ');
        final base = '- ${t.name}: ${t.description}';
        return factText.isEmpty ? base : '$base ($factText)';
      }).toList(),
    );

    // Dàn ý — chỉ có ý nghĩa khi BIẾT đang viết chương số mấy (currentChapterNumber).
    // Đưa vào: điểm nút gắn ĐÚNG chương này (nếu có), và điểm nút SẮP TỚI
    // gần nhất (giúp AI viết hướng đúng mạch truyện đã lên kế hoạch mà
    // không cần liệt kê cả dàn ý toàn truyện, dễ lộ spoil/loãng ngữ cảnh).
    //
    // ĐÃ SỬA (v10, theo báo cáo người dùng "dàn ý không có chỗ điều chỉnh
    // phạm vi"): trước đây CHỈ xét `linkedChapterNumber` (ghim đúng 1
    // chương). Giờ 1 điểm nút CHƯA ghim đúng chương nào nhưng đã gán
    // "Phạm vi hiệu lực" (theo khoảng chương hoặc theo Quyển/Hồi — cùng cơ
    // chế Character/WorldRule...) cũng được coi là "của chương này" MIỄN
    // currentChapterNumber rơi vào đúng phạm vi đó. `linkedChapterNumber`
    // (nếu có) vẫn ưu tiên hơn vì đó là cam kết chính xác hơn.
    if (currentChapterNumber != null) {
      final beats = await db.allPlotBeats(novelId);
      final currentBeats = beats.where((b) =>
          b.linkedChapterNumber == currentChapterNumber ||
          (b.linkedChapterNumber == null &&
              inScope(b.effectiveFromChapter, b.effectiveToChapter, b.effectiveFromVolumeId, b.effectiveToVolumeId) &&
              (b.effectiveFromChapter != null || b.effectiveToChapter != null || b.effectiveFromVolumeId != null || b.effectiveToVolumeId != null)));
      final upcoming = beats.where((b) => (b.linkedChapterNumber ?? -1) > currentChapterNumber).toList()
        ..sort((a, b) => (a.linkedChapterNumber ?? 0).compareTo(b.linkedChapterNumber ?? 0));
      final lines = <String>[
        ...currentBeats.map((b) => '- [Điểm nút CỦA CHƯƠNG NÀY] ${b.title}: ${b.description}'),
        if (upcoming.isNotEmpty) '- [Điểm nút sắp tới] ${upcoming.first.title}: ${upcoming.first.description}',
      ];
      addSection('Dàn ý', lines);
    }

    return buffer.toString();
  }

  String _excerpt(String content) => content.substring(0, content.length > 200 ? 200 : content.length);

  Future<List<String>> previewActiveEntries(String currentText, {int? currentChapterNumber}) async {
    final queryVector = await embedder.embed(currentText);
    final lowerText = currentText.toLowerCase();
    final volumeRanges = await db.volumeChapterRanges(novelId);
    bool inScope(int? fc, int? tc, String? fv, String? tv) {
      final (from, to) = _resolveScope(fc, tc, fv, tv, volumeRanges);
      return _isInScope(from, to, currentChapterNumber);
    }
    final characters = await db.allCharacters(novelId);
    final scopedCharacters = characters
        .where((c) => inScope(c.effectiveFromChapter, c.effectiveToChapter, c.effectiveFromVolumeId, c.effectiveToVolumeId))
        .toList();
    final rules = await db.allWorldRules(novelId);
    final scopedRules =
        rules.where((r) => inScope(r.effectiveFromChapter, r.effectiveToChapter, r.effectiveFromVolumeId, r.effectiveToVolumeId));

    final names = <String>[];
    for (final c in scopedCharacters) {
      final keywordHit = c.keywords.any((k) => lowerText.contains(k.toLowerCase()));
      if (keywordHit) names.add(c.name);
    }
    final semanticCharIds = await _topMatches('character', queryVector, scopedCharacters.map((c) => c.id).toList(), topK: 3);
    for (final id in semanticCharIds) {
      final matches = scopedCharacters.where((x) => x.id == id);
      if (matches.isNotEmpty && !names.contains(matches.first.name)) {
        names.add('${matches.first.name} (ngữ nghĩa)');
      }
    }
    for (final r in scopedRules.where((r) => r.isHardRule)) {
      names.add('[Luật] ${r.title}');
    }
    return names;
  }

  Future<String> buildSystemPrompt({
    required String userInstruction,
    required String currentText,
    int? currentChapterNumber,
  }) async {
    final context = await buildContext(currentText: currentText, currentChapterNumber: currentChapterNumber);
    // ĐÃ SỬA: trước đây, khi Story Bible CHƯA CÓ GÌ (chưa nhập luật thế
    // giới/nhân vật/chương nào), `context` ở đây là chuỗi RỖNG — nhưng
    // đoạn văn bản luôn viết cứng "Dưới đây là dữ liệu Story Bible..."
    // rồi để trống ngay sau đó, và vẫn ra lệnh model "tham chiếu đúng
    // Story Bible". Model 7B (đặc biệt bản uncensored, dễ cố "chiều"
    // theo yêu cầu) khi bị bắt tham chiếu một thứ trống rỗng thường TỰ
    // BỊA ra nội dung Story Bible giả cho có, gây hiểu lầm là app rò rỉ
    // dữ liệu lạ/có bộ lọc ẩn — thực chất chỉ là ảo giác (hallucination)
    // do cách viết prompt cũ. Giờ nói thẳng với model khi trống, cấm bịa.
    final hasContext = context.trim().isNotEmpty;
    final bibleSection = hasContext
        ? '''Dưới đây là dữ liệu Story Bible liên quan tới đoạn đang viết. Bám sát
các luật thế giới và thông tin nhân vật này; nếu nội dung mới có khả
năng mâu thuẫn với dữ liệu dưới đây, hãy nêu rõ mâu thuẫn đó thay vì
lờ đi.

$context'''
        : '''Story Bible của truyện này HIỆN ĐANG TRỐNG — chưa có luật thế giới,
nhân vật, hay chương nào được lưu trong hệ thống. TUYỆT ĐỐI KHÔNG được
tự bịa ra bất kỳ chi tiết Story Bible nào (thế giới, nhân vật, mục
tiêu, luật lệ...). Nếu người dùng hỏi về Story Bible hoặc yêu cầu tham
chiếu nó, hãy trả lời trung thực rằng chưa có dữ liệu nào được nhập và
đề nghị họ thêm vào phần Bách khoa trước.''';

    return '''
Bạn là trợ lý viết tiểu thuyết dài kỳ.

$bibleSection

Yêu cầu chung của người viết: $userInstruction
''';
  }

  Future<String> buildConsistencyCheckPrompt(Chapter chapter) async {
    // ĐÃ SỬA: truyền chapter.number vào để lọc đúng Character/WorldRule
    // đang có hiệu lực TẠI chương này — trước đây kiểm tra mâu thuẫn có
    // thể so sánh chương với dữ liệu KHÔNG CÒN đúng ở thời điểm đó (vd
    // luật đã bị lật lại ở chương sau) hoặc CHƯA tồn tại (spoil trước).
    final context = await buildContext(currentText: chapter.content, recentChapterCount: 1, currentChapterNumber: chapter.number);
    final hasContext = context.trim().isNotEmpty;
    if (!hasContext) {
      // ĐÃ SỬA: cùng lỗi hallucination như buildSystemPrompt ở trên —
      // Story Bible trống thì không có gì để đối chiếu, không nên gọi
      // model đi "tìm mâu thuẫn" với dữ liệu không tồn tại.
      return '''
Story Bible của truyện này hiện đang trống — chưa có luật thế giới hay
nhân vật nào được lưu để đối chiếu. Chỉ trả lời đúng 1 câu: "Chưa có dữ
liệu Story Bible để đối chiếu." Không bịa ra bất kỳ điểm mâu thuẫn nào.
''';
    }
    return '''
Đối chiếu nội dung chương sau với Story Bible bên dưới. Chỉ trả lời
bằng "OK" nếu không có mâu thuẫn, hoặc liệt kê ngắn gọn từng điểm nghi
ngờ mâu thuẫn (tên riêng, mốc thời gian, luật thế giới, trạng thái
nhân vật).

$context

### Nội dung chương ${chapter.number}: ${chapter.title}
${chapter.content}
''';
  }
}
