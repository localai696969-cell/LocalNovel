// Thống kê chống lặp từ — giúp người viết phát hiện từ/cụm từ bị dùng lặp
// đi lặp lại quá nhiều trong 1 đoạn văn dài, điều rất dễ xảy ra khi có AI
// hỗ trợ viết (model nhỏ hay bị "lặp từ vô nghĩa" — đúng vấn đề đã ghi trong
// tài liệu kiến trúc, mục 4.8). Đây là tiện ích thuần Dart (không phụ thuộc
// Flutter), có thể test độc lập.
//
// Lưu ý về tiếng Việt: mỗi "từ" tiếng Việt thường gồm NHIỀU âm tiết cách
// nhau bởi dấu cách (vd "cẩn thận" là 1 từ, 2 âm tiết) — đếm riêng từng âm
// tiết (unigram) sẽ cho kết quả nhiễu (âm tiết phổ biến như "một", "người"
// lặp lại là bình thường). Vì vậy công cụ này đếm CẢ âm tiết đơn LẪN cụm 2
// âm tiết liền nhau (bigram) — cụm 2 âm tiết lặp nhiều thường phản ánh đúng
// hơn việc 1 TỪ (theo nghĩa tiếng Việt) bị lặp.
class RepetitionAnalyzer {
  // Các âm tiết chức năng (hư từ) rất phổ biến trong tiếng Việt — lặp lại
  // là bình thường, không phải lỗi văn phong, nên loại khỏi thống kê.
  static const Set<String> stopSyllables = {
    'và', 'là', 'có', 'không', 'một', 'những', 'các', 'này', 'đó', 'để',
    'cho', 'với', 'khi', 'thì', 'mà', 'ở', 'trong', 'ra', 'vào', 'lên',
    'xuống', 'rồi', 'đã', 'sẽ', 'đang', 'của', 'từ', 'theo', 'như', 'nếu',
    'nhưng', 'vì', 'nên', 'bị', 'được', 'lại', 'cũng', 'còn', 'chỉ', 'đến',
    'qua', 'sau', 'trước', 'trên', 'dưới', 'ngoài', 'tại', 'do', 'bởi',
    'vậy', 'thế', 'a', 'ừ', 'ơi', 'à', 'nhé', 'nha', 'ạ', 'đi', 'thôi',
    'tôi', 'anh', 'em', 'chị', 'cô', 'chú', 'bạn', 'nó', 'họ', 'ta', 'mình',
    'người', 'một cách', 'là một', 'rất', 'quá', 'nhiều', 'ít', 'hơn',
  };

  // Tách văn bản thành danh sách "âm tiết" (giữ nguyên dấu tiếng Việt),
  // loại bỏ dấu câu/số. \p{L} khớp mọi chữ cái Unicode (bao gồm chữ có dấu
  // tiếng Việt), cần cờ `unicode: true` để RegExp hiểu \p{L}.
  List<String> _tokenize(String text) {
    final matches = RegExp(r'[\p{L}]+', unicode: true).allMatches(text.toLowerCase());
    return matches.map((m) => m.group(0)!).toList();
  }

  List<String> _paragraphs(String text) =>
      text.split(RegExp(r'\n\s*\n')).where((p) => p.trim().isNotEmpty).toList();

  RepetitionReport analyze(String text, {int topN = 15}) {
    final paragraphs = _paragraphs(text.isEmpty ? [text].join() : text);
    final effectiveParagraphs = paragraphs.isEmpty ? [text] : paragraphs;

    final unigramCounts = <String, int>{};
    final unigramParagraphs = <String, Set<int>>{};
    final bigramCounts = <String, int>{};
    final bigramParagraphs = <String, Set<int>>{};
    int totalSyllables = 0;

    for (var pIndex = 0; pIndex < effectiveParagraphs.length; pIndex++) {
      final syllables = _tokenize(effectiveParagraphs[pIndex]);
      totalSyllables += syllables.length;
      for (var i = 0; i < syllables.length; i++) {
        final w = syllables[i];
        if (w.length < 2 || stopSyllables.contains(w)) continue;
        unigramCounts[w] = (unigramCounts[w] ?? 0) + 1;
        (unigramParagraphs[w] ??= {}).add(pIndex);

        if (i + 1 < syllables.length) {
          final w2 = syllables[i + 1];
          if (w2.length >= 2 && !stopSyllables.contains(w2)) {
            final bigram = '$w $w2';
            bigramCounts[bigram] = (bigramCounts[bigram] ?? 0) + 1;
            (bigramParagraphs[bigram] ??= {}).add(pIndex);
          }
        }
      }
    }

    List<WordRepetitionEntry> buildEntries(Map<String, int> counts, Map<String, Set<int>> byParagraph) {
      final entries = counts.entries
          .where((e) => e.value >= 2) // chỉ báo cáo từ/cụm XUẤT HIỆN LẶP (>=2 lần)
          .map((e) => WordRepetitionEntry(
                phrase: e.key,
                count: e.value,
                paragraphIndexes: (byParagraph[e.key] ?? {}).toList()..sort(),
              ))
          .toList();
      entries.sort((a, b) => b.count.compareTo(a.count));
      return entries.take(topN).toList();
    }

    final topWords = buildEntries(unigramCounts, unigramParagraphs);
    final topPhrases = buildEntries(bigramCounts, bigramParagraphs);

    // "Lặp gần" — từ/cụm xuất hiện NHIỀU LẦN TRONG CÙNG 1 đoạn văn (không
    // chỉ rải rác toàn chương) — đây là kiểu lặp dễ gây khó chịu khi đọc
    // nhất, đáng chú ý hơn lặp rải rác xuyên suốt chương dài.
    final nearRepeats = <WordRepetitionEntry>[];
    void collectNearRepeats(Map<String, int> counts, Map<String, Set<int>> byParagraph) {
      for (final entry in counts.entries) {
        if (entry.value < 3) continue;
        final paras = byParagraph[entry.key] ?? {};
        // Nếu số lần xuất hiện dồn vào rất ít đoạn văn so với tổng số lần
        // xuất hiện -> nhiều khả năng lặp sát nhau trong cùng đoạn.
        if (paras.isNotEmpty && entry.value / paras.length >= 2.5) {
          nearRepeats.add(WordRepetitionEntry(
            phrase: entry.key,
            count: entry.value,
            paragraphIndexes: paras.toList()..sort(),
          ));
        }
      }
    }

    collectNearRepeats(unigramCounts, unigramParagraphs);
    collectNearRepeats(bigramCounts, bigramParagraphs);
    nearRepeats.sort((a, b) => b.count.compareTo(a.count));

    return RepetitionReport(
      totalSyllables: totalSyllables,
      paragraphCount: effectiveParagraphs.length,
      topWords: topWords,
      topPhrases: topPhrases,
      nearRepeats: nearRepeats.take(topN).toList(),
    );
  }
}

class WordRepetitionEntry {
  final String phrase;
  final int count;
  final List<int> paragraphIndexes; // đoạn văn (0-based) có chứa từ/cụm này

  WordRepetitionEntry({required this.phrase, required this.count, required this.paragraphIndexes});
}

class RepetitionReport {
  final int totalSyllables;
  final int paragraphCount;
  final List<WordRepetitionEntry> topWords;
  final List<WordRepetitionEntry> topPhrases;
  final List<WordRepetitionEntry> nearRepeats;

  RepetitionReport({
    required this.totalSyllables,
    required this.paragraphCount,
    required this.topWords,
    required this.topPhrases,
    required this.nearRepeats,
  });
}
