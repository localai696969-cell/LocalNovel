import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'database_service.dart';
import 'embedding_service.dart';
import 'providers/local_provider.dart';
import 'providers/anthropic_provider.dart';
import 'providers/openai_compatible_provider.dart';

class SettingsService {
  static const _secure = FlutterSecureStorage();
  final db = DatabaseService.instance;

  // BUG ĐÃ SỬA (phát hiện qua debug_log.txt ngày 2026-07-26): trước đây
  // currentProvider() dựng 1 LocalLlamaProvider() MỚI mỗi lần được gọi (tức
  // là mỗi lần gửi tin nhắn/bấm AI), khiến cờ `_loaded` bên trong instance đó
  // luôn là false lúc bắt đầu → ensureLoaded() luôn gọi lại loadModel native
  // dù model không đổi. Không sai tới mức crash (MNN dùng mmap nên "load lại"
  // vẫn nhanh vì trang nhớ đã có sẵn trong cache của OS), nhưng tốn thời gian
  // dựng lại ngữ cảnh không cần thiết mỗi lần chat. Giữ 1 instance dùng
  // chung, chỉ tạo mới khi modelPath thật sự đổi (đổi model trong Cài đặt).
  static LocalLlamaProvider? _cachedLocalProvider;
  static String? _cachedLocalModelPath;

  static const _kProviderType = 'provider_type';
  static const _kActiveLocalModelId = 'active_local_model_id';
  static const _kActiveApiProviderId = 'active_api_provider_id';
  static const _kLocalThreads = 'local_threads';
  static const _kLocalContext = 'local_context';
  static const _kLocalGpuLayers = 'local_gpu_layers';
  static const _kRagBudget = 'rag_context_budget';

  static const _kActiveNovelId = 'active_novel_id';

  // ---------- Tham số sinh văn bản (temperature/top_p/top_k/...) ----------
  // Áp dụng cho mọi lần gọi model chính (chat + viết chương) — không
  // hardcode trong code, người dùng tự chỉnh trong Cài đặt.
  static const _kTemperature = 'gen_temperature';
  static const _kTopP = 'gen_top_p';
  static const _kTopK = 'gen_top_k';
  static const _kRepetitionPenalty = 'gen_repetition_penalty';
  static const _kMaxNewTokens = 'gen_max_new_tokens';

  Future<void> saveGenerationConfig({
    required double temperature,
    required double topP,
    required int topK,
    required double repetitionPenalty,
    required int maxNewTokens,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kTemperature, temperature);
    await prefs.setDouble(_kTopP, topP);
    await prefs.setInt(_kTopK, topK);
    await prefs.setDouble(_kRepetitionPenalty, repetitionPenalty);
    await prefs.setInt(_kMaxNewTokens, maxNewTokens);
  }

  Future<({double temperature, double topP, int topK, double repetitionPenalty, int maxNewTokens})>
      loadGenerationConfig() async {
    final prefs = await SharedPreferences.getInstance();
    return (
      temperature: prefs.getDouble(_kTemperature) ?? 0.8,
      topP: prefs.getDouble(_kTopP) ?? 0.9,
      topK: prefs.getInt(_kTopK) ?? 40,
      repetitionPenalty: prefs.getDouble(_kRepetitionPenalty) ?? 1.05,
      maxNewTokens: prefs.getInt(_kMaxNewTokens) ?? 1024,
    );
  }

  // ---------- Dịch thuật trung gian (tùy chọn, mặc định TẮT) ----------
  static const _kTranslationEnabled = 'translation_enabled';
  static const _kTranslationModelPath = 'translation_model_path';
  static const _kTranslationTargetLanguage = 'translation_target_language';
  static const _kTranslationStylePrompt = 'translation_style_prompt';

  Future<void> saveTranslationEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kTranslationEnabled, enabled);
  }

  Future<bool> loadTranslationEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kTranslationEnabled) ?? false;
  }

  Future<void> saveTranslationModelPath(String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kTranslationModelPath, path);
  }

  Future<String?> loadTranslationModelPath() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kTranslationModelPath);
  }

  Future<void> saveTranslationTargetLanguage(String lang) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kTranslationTargetLanguage, lang);
  }

  Future<String> loadTranslationTargetLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kTranslationTargetLanguage) ?? 'tiếng Anh';
  }

  Future<void> saveTranslationStylePrompt(String prompt) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kTranslationStylePrompt, prompt);
  }

  Future<String> loadTranslationStylePrompt() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kTranslationStylePrompt) ??
        'Giữ đúng văn phong tiểu thuyết, tự nhiên, không dịch máy móc từng chữ.';
  }

  // Có nên giữ model dịch thuật NẰM trong RAM suốt phiên làm việc (đỡ nạp
  // lại nhiều lần) hay xả ngay sau mỗi lần dùng (đỡ tốn RAM cho model
  // chính). Mặc định 'auto' — TranslationService tự quyết theo tổng RAM
  // máy (xem ramKeepResidentThresholdMb). Người dùng có thể ghi đè thủ
  // công ở màn "Tối ưu AI local" nếu tự động đoán sai nhu cầu thực tế.
  static const _kTranslationKeepResidentMode = 'translation_keep_resident_mode';

  Future<void> saveTranslationKeepResidentMode(String mode) async {
    assert(mode == 'auto' || mode == 'always' || mode == 'never');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kTranslationKeepResidentMode, mode);
  }

  Future<String> loadTranslationKeepResidentMode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kTranslationKeepResidentMode) ?? 'auto';
  }

  // Backend ưu tiên cho model local — 0 = tự thử QNN (NPU) trước, rơi về
  // GPU/CPU nếu lỗi; 1 = ép thẳng GPU (OpenCL), bỏ qua QNN hoàn toàn; 2 =
  // ép thẳng CPU (chậm nhất nhưng an toàn nhất). Đổi được ngay trong app,
  // KHÔNG cần build lại APK — dùng để khoanh vùng backend nào gây crash
  // native (Kotlin/Dart không bắt được crash cứng SIGSEGV, nên đây là cách
  // thực nghiệm duy nhất không cần logcat/máy tính).
  static const _kBackendPreference = 'backend_preference';

  Future<void> saveBackendPreference(int value) async {
    assert(value == 0 || value == 1 || value == 2);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kBackendPreference, value);
  }

  Future<int> loadBackendPreference() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_kBackendPreference) ?? 0;
  }

  // ---------- Truyện đang active (đa truyện) ----------
  Future<List<Novel>> allNovels() => db.allNovels();

  Future<Novel> createNovel(String title, {String author = ''}) async {
    final novel = Novel(id: DateTime.now().millisecondsSinceEpoch.toString(), title: title, author: author);
    await db.upsertNovel(novel);
    return novel;
  }

  Future<void> renameNovel(Novel novel) async {
    novel.updatedAt = DateTime.now();
    await db.upsertNovel(novel);
  }

  Future<void> deleteNovel(String id) async {
    await db.deleteNovel(id);
    final activeId = await loadActiveNovelId();
    if (activeId == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kActiveNovelId);
    }
  }

  Future<void> setActiveNovel(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kActiveNovelId, id);
  }

  Future<String?> loadActiveNovelId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kActiveNovelId);
  }

  Future<void> saveProviderType(AIProviderType type) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kProviderType, type.name);
  }

  Future<AIProviderType> loadProviderType() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kProviderType);
    return AIProviderType.values.firstWhere((t) => t.name == raw, orElse: () => AIProviderType.localLlama);
  }

  // ---------- Local models (nhiều model, chọn 1 đang active) ----------
  Future<void> addLocalModel(String name, String path) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await db.upsertLocalModel(LocalModelEntry(id: id, name: name, path: path));
    // Nếu đây là model đầu tiên được thêm, tự đặt làm active luôn.
    final all = await db.allLocalModels();
    if (all.length == 1) await setActiveLocalModel(id);
  }

  Future<List<LocalModelEntry>> allLocalModels() => db.allLocalModels();

  Future<void> deleteLocalModel(String id) async {
    await db.deleteLocalModel(id);
    final activeId = await loadActiveLocalModelId();
    if (activeId == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kActiveLocalModelId);
    }
  }

  Future<void> setActiveLocalModel(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kActiveLocalModelId, id);
  }

  Future<String?> loadActiveLocalModelId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kActiveLocalModelId);
  }

  Future<void> saveLocalInferenceConfig({
    required int threads,
    required int contextSize,
    required int numGpuLayers,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kLocalThreads, threads);
    await prefs.setInt(_kLocalContext, contextSize);
    await prefs.setInt(_kLocalGpuLayers, numGpuLayers);
  }

  Future<({int threads, int contextSize, int numGpuLayers})> loadLocalInferenceConfig() async {
    final prefs = await SharedPreferences.getInstance();
    return (
      threads: prefs.getInt(_kLocalThreads) ?? 4,
      contextSize: prefs.getInt(_kLocalContext) ?? 2048,
      numGpuLayers: prefs.getInt(_kLocalGpuLayers) ?? 99,
    );
  }

  // ---------- API providers (nhiều provider tự thêm, chọn 1 đang active) ----------
  Future<void> addApiProvider({
    required String name,
    required String type, // 'anthropic' | 'openai_compatible'
    String? baseUrl,
    required String modelId,
    required String apiKey,
  }) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await db.upsertApiProvider(ApiProviderEntry(id: id, name: name, type: type, baseUrl: baseUrl, modelId: modelId));
    await _secure.write(key: 'api_key_$id', value: apiKey);
    final all = await db.allApiProviders();
    if (all.length == 1) await setActiveApiProvider(id);
  }

  Future<List<ApiProviderEntry>> allApiProviders() => db.allApiProviders();

  Future<void> deleteApiProvider(String id) async {
    await db.deleteApiProvider(id);
    await _secure.delete(key: 'api_key_$id');
    final activeId = await loadActiveApiProviderId();
    if (activeId == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kActiveApiProviderId);
    }
  }

  Future<void> setActiveApiProvider(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kActiveApiProviderId, id);
  }

  Future<String?> loadActiveApiProviderId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kActiveApiProviderId);
  }

  Future<void> saveRagBudget(int chars) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kRagBudget, chars);
  }

  Future<int> loadRagBudget() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_kRagBudget) ?? 3500;
  }

  // Dựng provider đang active, sẵn sàng dùng ngay. Throw rõ ràng nếu
  // chưa có gì được chọn, thay vì âm thầm dùng giá trị rỗng/mặc định.
  Future<AIProvider> currentProvider() async {
    final type = await loadProviderType();
    if (type == AIProviderType.localLlama) {
      final activeId = await loadActiveLocalModelId();
      final models = await db.allLocalModels();
      final active = models.where((m) => m.id == activeId).toList();
      if (active.isEmpty) {
        throw Exception('Chưa chọn model local nào đang active. Vào Cài đặt → thêm/chọn model.');
      }
      // Không còn truyền threads/contextSize/numGpuLayers thủ công nữa —
      // engine MNN+QNN mới tự thử QNN → OpenCL (GPU) → CPU theo thứ tự,
      // không cần cấu hình tay như bản llama_cpp_dart cũ.
      //
      // Dùng lại instance đã cache nếu modelPath không đổi (xem giải thích ở
      // đầu class) — tránh gọi loadModel native lại mỗi lần chat/viết chương.
      final path = active.first.path;
      if (_cachedLocalProvider != null && _cachedLocalModelPath == path) {
        return _cachedLocalProvider!;
      }
      final provider = LocalLlamaProvider(modelPath: path);
      _cachedLocalProvider = provider;
      _cachedLocalModelPath = path;
      return provider;
    }

    final activeId = await loadActiveApiProviderId();
    final providers = await db.allApiProviders();
    final active = providers.where((p) => p.id == activeId).toList();
    if (active.isEmpty) {
      throw Exception('Chưa chọn API provider nào đang active. Vào Cài đặt → thêm/chọn provider.');
    }
    final entry = active.first;
    final apiKey = await _secure.read(key: 'api_key_${entry.id}') ?? '';
    if (entry.type == 'anthropic') {
      return AnthropicProvider(apiKey: apiKey, modelId: entry.modelId);
    }
    return OpenAICompatibleProvider(
      baseUrl: entry.baseUrl ?? 'https://api.openai.com/v1',
      apiKey: apiKey,
      modelId: entry.modelId,
    );
  }

  // Embedding cho RAG: fllama chưa expose API embedding cấp cao, dùng
  // vector hashing thuần Dart — luôn chạy được, không phụ thuộc gì thêm.
  Future<EmbeddingService> currentEmbeddingService() async => HashingEmbeddingService();
}
