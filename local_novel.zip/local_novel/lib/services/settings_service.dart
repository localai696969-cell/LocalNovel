import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'database_service.dart';
import 'embedding_service.dart';
import 'providers/local_provider.dart';
import 'providers/anthropic_provider.dart';
import 'providers/openai_compatible_provider.dart';

class SettingsService {
  static const _secure = FlutterSecureStorage();
  final db = DatabaseService.instance;

  // BUG ĐÃ SỬA (phát hiện qua debug_log.txt ngày 2026-07-26): trước đây
  // currentProvider() dựng 1 LocalLlamaProvider() MỚI mỗi lần được gọi (tức
  // là mỗi lần gửi tin nhắn/bấm AI), khiến cờ `_loaded` bên trong instance đó
  // luôn là false lúc bắt đầu → ensureLoaded() luôn gọi lại loadModel native
  // dù model không đổi. Không sai tới mức crash (MNN dùng mmap nên "load lại"
  // vẫn nhanh vì trang nhớ đã có sẵn trong cache của OS), nhưng tốn thời gian
  // dựng lại ngữ cảnh không cần thiết mỗi lần chat. Giữ 1 instance dùng
  // chung, chỉ tạo mới khi modelPath thật sự đổi (đổi model trong Cài đặt).
  static LocalLlamaProvider? _cachedLocalProvider;
  static String? _cachedLocalModelPath;

  // ĐÃ XOÁ (v15): _kProviderType/_kActiveLocalModelId/_kActiveApiProviderId
  // (từ v14)/_kLocalThreads/_kLocalContext/_kLocalGpuLayers/_kRagBudget
  // (từ v15) từng ở đây — không còn hàm nào trong lớp này dùng tới, y hệt
  // pattern _kPlotSummaryEnabled/_kPlotSummaryInterval đã xoá ở v13 (xem
  // ngay dưới). CÁC KEY STRING GỐC ('provider_type'/'active_local_model_id'/
  // 'active_api_provider_id'/'local_threads'/'local_context'/
  // 'local_gpu_layers'/'rag_context_budget') vẫn còn Ý NGHĨA THẬT —
  // `DatabaseService._migrateToV14`/`_migrateToV15` đọc thẳng các chuỗi
  // này để lấy giá trị SharedPreferences CŨ. ĐỪNG đổi các chuỗi đó ở phía
  // `database_service.dart` nếu không cố ý bỏ qua bước di trú giá trị cũ.
  // ĐÃ THÊM (theo câu hỏi người dùng: "có làm chậm AI local nếu chương
  // phình to không") — cho phép người dùng tự cân bằng giữa "đồng bộ
  // xuyên suốt truyện dài" và "tốc độ", xem giải thích đầy đủ ở
  // RagService.updateCumulativeStorySummary().
  // ĐÃ XOÁ (v13): _kPlotSummaryEnabled/_kPlotSummaryInterval từng ở đây —
  // không còn hàm nào trong lớp này dùng tới (xem giải thích đầy đủ phía
  // dưới, khu vực trước `currentProvider()`). 2 KEY STRING GỐC
  // ('plot_summary_enabled'/'plot_summary_interval') vẫn còn Ý NGHĨA THẬT
  // — `DatabaseService._migrateToV13` đọc thẳng 2 chuỗi này (viết trực
  // tiếp, không qua hằng số) để lấy giá trị SharedPreferences CŨ, sao chép
  // làm khởi tạo cho `Novel.plotSummaryEnabled/plotSummaryInterval` của
  // mọi truyện đã có. ĐỪNG đổi tên 2 chuỗi đó ở phía `database_service.dart`
  // nếu không cố ý muốn bỏ qua bước di trú giá trị cũ.

  static const _kActiveNovelId = 'active_novel_id';

  // ---------- Tham số sinh văn bản (temperature/top_p/top_k/...) ----------
  // Áp dụng cho mọi lần gọi model chính (chat + viết chương) — không
  // hardcode trong code, người dùng tự chỉnh trong Cài đặt.
  // ĐÃ XOÁ (v14): _kTemperature/_kTopP/_kTopK/_kRepetitionPenalty/
  // _kMaxNewTokens từng ở đây — không còn hàm nào trong lớp này dùng tới
  // (xem giải thích ở `saveGenerationConfig`/`loadGenerationConfig` phía
  // dưới). 5 KEY STRING GỐC ('gen_temperature'/'gen_top_p'/'gen_top_k'/
  // 'gen_repetition_penalty'/'gen_max_new_tokens') vẫn còn Ý NGHĨA THẬT —
  // `DatabaseService._migrateToV14` đọc thẳng các chuỗi này (viết trực
  // tiếp, không qua hằng số) để lấy giá trị SharedPreferences CŨ. ĐỪNG đổi
  // 5 chuỗi đó ở phía `database_service.dart` nếu không cố ý bỏ qua bước
  // di trú giá trị cũ.

  // ĐÃ CHUYỂN (v14 — theo yêu cầu người dùng: "cài đặt thì áp dụng cho
  // quyển truyện chứ không phải cho toàn app... tham số sinh văn bản cũng
  // khác nhau, không thể đánh đồng chung được"). `saveGenerationConfig`/
  // `loadGenerationConfig` KHÔNG còn đọc/ghi SharedPreferences nữa — đọc/
  // ghi thẳng `Novel.genTemperature/.../genMaxNewTokens` (cột trong bảng
  // `novels`, xem story_models.dart) qua `DatabaseService`. Giữ NGUYÊN 2
  // tên hàm + chữ ký gần giống cũ (chỉ thêm `novelId`) để nơi gọi
  // (`generation_settings_screen.dart`) không cần đổi cấu trúc code nhiều.
  // 5 KEY STRING GỐC ('gen_temperature'... phía trên) vẫn còn Ý NGHĨA THẬT
  // — `DatabaseService._migrateToV14` đọc thẳng các chuỗi này để lấy giá
  // trị SharedPreferences CŨ, sao chép làm khởi tạo cho mọi truyện đã có.
  Future<void> saveGenerationConfig(
    String novelId, {
    required double temperature,
    required double topP,
    required int topK,
    required double repetitionPenalty,
    required int maxNewTokens,
  }) async {
    await db.updateNovelGenerationConfig(
      novelId,
      temperature: temperature,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      maxNewTokens: maxNewTokens,
    );
  }

  Future<({double temperature, double topP, int topK, double repetitionPenalty, int maxNewTokens})>
      loadGenerationConfig(String novelId) async {
    final novel = await db.novelById(novelId);
    return (
      temperature: novel?.genTemperature ?? 0.8,
      topP: novel?.genTopP ?? 0.9,
      topK: novel?.genTopK ?? 40,
      // ĐÃ SỬA (mục AC, 2026-09-10): dòng `?? 1.15` này TRÊN THỰC TẾ hầu
      // như không bao giờ chạy tới — `novel?.genRepetitionPenalty` chỉ là
      // `double?` vì `novel` (đối tượng) có thể null, KHÔNG phải vì cột DB
      // có thể null; `Novel.fromMap()`/constructor mặc định đã tự quy đổi
      // giá trị null/thiếu thành 1 số double CỤ THỂ (nay đã đồng bộ đúng
      // 1.15, xem `story_models.dart`) từ trước khi tới được đây. Giữ lại
      // `?? 1.15` ở đây chỉ như 1 lớp phòng vệ vô hại (phòng trường hợp
      // hiếm: `novelById` trả null vì truyện không tồn tại) — KHÔNG PHẢI
      // nơi quyết định giá trị thật, đừng nhầm sửa ở đây mà tưởng đã sửa
      // xong (đúng lỗi đã lặp lại nhiều lần trước khi tìm ra ở mục AC).
      repetitionPenalty: novel?.genRepetitionPenalty ?? 1.15,
      maxNewTokens: novel?.genMaxNewTokens ?? 1024,
    );
  }

  // ---------- Dịch thuật trung gian (tùy chọn, mặc định TẮT, v15: riêng
  // từng truyện) ----------
  // ĐÃ XOÁ (v15): 6 hằng số _kTranslation* từng ở đây (cùng lý do với khối
  // giải thích phía trên đầu file) — 6 KEY STRING GỐC vẫn còn ý nghĩa thật
  // cho `DatabaseService._migrateToV15`, đừng đổi tên chúng ở đó.

  Future<void> saveTranslationEnabled(String novelId, bool enabled) async {
    await db.updateNovelSettings(novelId, {'translation_enabled': enabled ? 1 : 0});
  }

  Future<bool> loadTranslationEnabled(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.translationEnabled ?? false;
  }

  Future<void> saveTranslationModelPath(String novelId, String path) async {
    await db.updateNovelSettings(novelId, {'translation_model_path': path});
  }

  Future<String?> loadTranslationModelPath(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.translationModelPath;
  }

  Future<void> saveTranslationTargetLanguage(String novelId, String lang) async {
    await db.updateNovelSettings(novelId, {'translation_target_language': lang});
  }

  Future<String> loadTranslationTargetLanguage(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.translationTargetLanguage ?? 'tiếng Anh';
  }

  Future<void> saveTranslationStylePrompt(String novelId, String prompt) async {
    await db.updateNovelSettings(novelId, {'translation_style_prompt': prompt});
  }

  Future<String> loadTranslationStylePrompt(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.translationStylePrompt ?? 'Giữ đúng văn phong tiểu thuyết, tự nhiên, không dịch máy móc từng chữ.';
  }

  Future<void> saveTranslationPromptToTarget(String novelId, String prompt) async {
    await db.updateNovelSettings(novelId, {'translation_prompt_to_target': prompt});
  }

  Future<String> loadTranslationPromptToTarget(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.translationPromptToTarget ??
        'Dịch đoạn văn bản tiếng Việt sau sang {targetLanguage}. '
            'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.';
  }

  Future<void> saveTranslationPromptFromTarget(String novelId, String prompt) async {
    await db.updateNovelSettings(novelId, {'translation_prompt_from_target': prompt});
  }

  Future<String> loadTranslationPromptFromTarget(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.translationPromptFromTarget ??
        'Dịch đoạn văn bản {targetLanguage} sau sang tiếng Việt tự nhiên, đúng văn phong tiểu thuyết. '
            'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.';
  }

  // Có nên giữ model dịch thuật NẰM trong RAM suốt phiên làm việc (đỡ nạp
  // lại nhiều lần) hay xả ngay sau mỗi lần dùng (đỡ tốn RAM cho model
  // chính). Mặc định 'auto' — TranslationService tự quyết theo tổng RAM
  // máy (xem ramKeepResidentThresholdMb). Người dùng có thể ghi đè thủ
  // công ở màn "Tối ưu AI local" nếu tự động đoán sai nhu cầu thực tế.
  static const _kTranslationKeepResidentMode = 'translation_keep_resident_mode';

  Future<void> saveTranslationKeepResidentMode(String novelId, String mode) async {
    assert(mode == 'auto' || mode == 'always' || mode == 'never');
    await db.updateNovelSettings(novelId, {'translation_keep_resident_mode': mode});
  }

  Future<String> loadTranslationKeepResidentMode(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.translationKeepResidentMode ?? 'auto';
  }

  // ĐÃ THÊM: số nhiệm vụ AI được phép chạy THẬT SỰ đồng thời khi provider
  // đang active là GPU từ xa (Colab/API khác) — xem BackgroundTaskManager.
  // KHÔNG áp dụng cho model local (luôn giới hạn = 1, lý do an toàn thật
  // đã ghi ở đầu background_task_manager.dart, không phải giá trị này).
  // Mặc định 2 — thận trọng, vì VRAM GPU T4 miễn phí của Colab có hạn, mỗi
  // nhiệm vụ song song cần vùng KV-cache riêng trên server.
  Future<void> saveMaxParallelRemoteTasks(String novelId, int n) async {
    await db.updateNovelSettings(novelId, {'max_parallel_remote_tasks': n.clamp(1, 8)});
  }

  Future<int> loadMaxParallelRemoteTasks(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.maxParallelRemoteTasks ?? 2;
  }

  // ---------- Prompt + model choice cho xử lý tài liệu ----------
  // 'active' = model chính đang active trong Cài đặt
  // 'translation' = model dịch ngôn ngữ slot 1 (Dịch thuật trung gian)
  Future<void> saveDocTranslatePrompt(String novelId, String p) async =>
      db.updateNovelSettings(novelId, {'doc_translate_prompt': p});

  Future<String> loadDocTranslatePrompt(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.docTranslatePrompt ??
        'Dịch đoạn văn sau sang tiếng Việt, giữ nguyên văn phong và tên riêng, chỉ trả lời bằng bản dịch.';
  }

  Future<void> saveDocSummarizePrompt(String novelId, String p) async =>
      db.updateNovelSettings(novelId, {'doc_summarize_prompt': p});

  Future<String> loadDocSummarizePrompt(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.docSummarizePrompt ?? 'Tóm tắt đoạn văn sau trong 3-5 câu, giữ đúng tên riêng và sự kiện chính.';
  }

  Future<void> saveDocModelChoice(String novelId, String choice) async =>
      db.updateNovelSettings(novelId, {'doc_model_choice': choice});

  Future<String> loadDocModelChoice(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.docModelChoice ?? 'active';
  }

  // Backend ưu tiên cho model local — 0 = tự thử QNN (NPU) trước, rơi về
  // GPU/CPU nếu lỗi; 1 = ép thẳng GPU (OpenCL), bỏ qua QNN hoàn toàn; 2 =
  // ép thẳng CPU (chậm nhất nhưng an toàn nhất). Đổi được ngay trong app,
  // ĐÃ SỬA Ý NGHĨA (sau khi xác nhận Hexagon 780/v68 trên máy test nằm
  // dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU — yêu cầu v73+):
  //   0 = mặc định, đi thẳng OpenCL đã tối ưu (precision/memory/thread_num
  //       theo khuyến nghị MNN) — KHÔNG còn tự thử QNN trước nữa, tránh
  //       phí thời gian chờ vô ích mỗi lần mở model.
  //   1 = ép buộc OpenCL (giống hệt 0 ở thời điểm này, giữ riêng để có
  //       thể tách hành vi khác nhau sau này nếu cần).
  //   2 = ép buộc CPU (dự phòng khi GPU có vấn đề trên 1 máy cụ thể).
  //   3 = THỬ NGHIỆM — thử QNN trước khi rơi xuống OpenCL, dùng cơ chế
  //       cách ly tiến trình con + timeout 90s (an toàn, không văng app
  //       dù QNN crash/treo). Chỉ nên bật thủ công nếu đổi sang máy chip
  //       mới hơn (Snapdragon 8 Gen 2+, Hexagon v73+) và muốn thử lại.
  Future<void> saveBackendPreference(String novelId, int value) async {
    assert(value >= 0 && value <= 3);
    await db.updateNovelSettings(novelId, {'backend_preference': value});
  }

  Future<int> loadBackendPreference(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.backendPreference ?? 0;
  }

  // ---------- Truyện đang active (đa truyện) ----------
  Future<List<Novel>> allNovels() => db.allNovels();

  Future<Novel> createNovel(String title, {String author = ''}) async {
    final novel = Novel(id: DateTime.now().millisecondsSinceEpoch.toString(), title: title, author: author);
    await db.upsertNovel(novel);
    return novel;
  }

  Future<void> renameNovel(Novel novel) async {
    novel.updatedAt = DateTime.now();
    await db.upsertNovel(novel);
  }

  Future<void> deleteNovel(String id) async {
    await db.deleteNovel(id);
    final activeId = await loadActiveNovelId();
    if (activeId == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kActiveNovelId);
    }
  }

  Future<void> setActiveNovel(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kActiveNovelId, id);
  }

  Future<String?> loadActiveNovelId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kActiveNovelId);
  }

  // ĐÃ CHUYỂN (v14 — theo yêu cầu người dùng, xem giải thích đầy đủ ở
  // story_models.dart Novel.providerType): đọc/ghi thẳng cột `provider_type`
  // của ĐÚNG truyện `novelId`, không còn qua SharedPreferences.
  Future<void> saveProviderType(String novelId, AIProviderType type) async {
    await db.setNovelProviderType(novelId, type.name);
  }

  Future<AIProviderType> loadProviderType(String novelId) async {
    final novel = await db.novelById(novelId);
    return AIProviderType.values.firstWhere((t) => t.name == novel?.providerType, orElse: () => AIProviderType.localLlama);
  }

  // ---------- Local models (nhiều model DÙNG CHUNG toàn app, mỗi truyện tự
  // chọn 1 cái đang active — xem giải thích ở story_models.dart) ----------
  //
  // ĐÃ SỬA (v14): `addLocalModel` giờ nhận `novelId` — trước đây "model
  // đầu tiên từng thêm" tự làm active CHO CẢ APP (chỉ có 1 con trỏ active
  // toàn cục); giờ mỗi truyện có con trỏ riêng, nên điều kiện tự-chọn đổi
  // thành "TRUYỆN NÀY chưa từng chọn model nào" (không phải "app chưa từng
  // có model nào") — thêm model thứ 5 vào danh sách chung vẫn tự chọn cho
  // 1 truyện MỚI TẠO (chưa có gì), nhưng không đụng tới lựa chọn của các
  // truyện khác đã có sẵn.
  Future<void> addLocalModel(String name, String path, {required String novelId}) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await db.upsertLocalModel(LocalModelEntry(id: id, name: name, path: path));
    final novel = await db.novelById(novelId);
    if (novel?.activeLocalModelId == null || novel!.activeLocalModelId!.isEmpty) {
      await setActiveLocalModel(novelId, id);
    }
  }

  Future<List<LocalModelEntry>> allLocalModels() => db.allLocalModels();

  // ĐÃ SỬA (v14): xoá 1 model khỏi danh sách CHUNG giờ phải dọn con trỏ
  // đang trỏ tới nó ở MỌI truyện (có thể nhiều hơn 1 — khác hẳn trước đây
  // chỉ có tối đa 1 nơi trỏ tới nó, xem `DatabaseService.clearNovelsActiveLocalModel`).
  Future<void> deleteLocalModel(String id) async {
    await db.deleteLocalModel(id);
    await db.clearNovelsActiveLocalModel(id);
  }

  Future<void> setActiveLocalModel(String novelId, String id) async {
    await db.setNovelActiveLocalModel(novelId, id);
  }

  Future<String?> loadActiveLocalModelId(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.activeLocalModelId;
  }

  Future<void> saveLocalInferenceConfig(
    String novelId, {
    required int threads,
    required int contextSize,
    required int numGpuLayers,
  }) async {
    await db.updateNovelSettings(novelId, {
      'local_threads': threads,
      'local_context': contextSize,
      'local_gpu_layers': numGpuLayers,
    });
  }

  Future<({int threads, int contextSize, int numGpuLayers})> loadLocalInferenceConfig(String novelId) async {
    final novel = await db.novelById(novelId);
    return (
      threads: novel?.localThreads ?? 4,
      contextSize: novel?.localContextSize ?? 2048,
      numGpuLayers: novel?.localGpuLayers ?? 99,
    );
  }

  // ---------- API providers (nhiều provider DÙNG CHUNG toàn app, mỗi
  // truyện tự chọn 1 cái đang active — cùng cách làm với local models) ----------
  Future<void> addApiProvider({
    required String name,
    required String type, // 'anthropic' | 'openai_compatible'
    String? baseUrl,
    required String modelId,
    required String apiKey,
    required String novelId,
  }) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await db.upsertApiProvider(ApiProviderEntry(id: id, name: name, type: type, baseUrl: baseUrl, modelId: modelId));
    await _secure.write(key: 'api_key_$id', value: apiKey);
    final novel = await db.novelById(novelId);
    if (novel?.activeApiProviderId == null || novel!.activeApiProviderId!.isEmpty) {
      await setActiveApiProvider(novelId, id);
    }
  }

  Future<List<ApiProviderEntry>> allApiProviders() => db.allApiProviders();

  Future<void> deleteApiProvider(String id) async {
    await db.deleteApiProvider(id);
    await _secure.delete(key: 'api_key_$id');
    await db.clearNovelsActiveApiProvider(id);
  }

  Future<void> setActiveApiProvider(String novelId, String id) async {
    await db.setNovelActiveApiProvider(novelId, id);
  }

  Future<String?> loadActiveApiProviderId(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.activeApiProviderId;
  }

  Future<void> saveRagBudget(String novelId, int chars) async {
    await db.updateNovelSettings(novelId, {'rag_context_budget': chars});
  }

  Future<int> loadRagBudget(String novelId) async {
    final novel = await db.novelById(novelId);
    return novel?.ragBudgetChars ?? 3500;
  }

  // ĐÃ XOÁ (v13 — theo câu hỏi "cài đặt riêng từng truyện hay chung cả
  // app?"): trước đây có 2 hàm `loadPlotSummaryEnabled`/`loadPlotSummaryInterval`
  // + 2 hàm `save*` tương ứng ở đây. `Novel.plotSummaryEnabled/plotSummaryInterval/...`
  // (cột trong bảng `novels`, xem story_models.dart) đã thay thế hoàn
  // toàn — cài đặt RIÊNG CHO TỪNG TRUYỆN, không hợp lý để chung 1 giá trị
  // cho mọi truyện. RÀ SOÁT LẠI (đúng yêu cầu "kiểm tra tính năng nào có
  // UI nhưng không hoạt động/mã bề ngoài"): phát hiện lượt trước đã để sót
  // — comment cũ ở đây từng nói "giữ lại vì migration cần dùng", nhưng
  // `DatabaseService._migrateToV13` thực ra đọc THẲNG SharedPreferences
  // bằng `prefs.getBool('plot_summary_enabled')`/`prefs.getInt('plot_summary_interval')`
  // (đúng 2 key string bên dưới), KHÔNG gọi qua 4 hàm này — nghĩa là 4 hàm
  // này đã là code CHẾT thật sự (0 nơi gọi) ngay từ lúc viết, không phải
  // "sắp cần". Xoá hẳn để tài liệu/code không mâu thuẫn nhau nữa; migration
  // vẫn hoạt động đúng vì nó không phụ thuộc các hàm đã xoá.
  // Dựng provider đang active, sẵn sàng dùng ngay. Throw rõ ràng nếu
  // chưa có gì được chọn, thay vì âm thầm dùng giá trị rỗng/mặc định.
  //
  // ĐÃ THÊM (rà soát toàn hệ thống theo yêu cầu người dùng — "kiểm tra
  // tính năng nào có UI nhưng không hoạt động"): phát hiện `AIProvider.isReady()`
  // (khai báo interface, CẢ 3 provider đều implement — xem `ai_provider.dart`
  // và `providers/*.dart`) trước đó KHÔNG hề được gọi ở BẤT KỲ đâu trong
  // toàn app. Hệ quả thật: nếu người dùng ĐÃ chọn 1 API provider (entry
  // tồn tại trong danh sách) nhưng QUÊN nhập API key (hoặc model local có
  // entry nhưng `path` rỗng do lỗi copy file) — nhánh kiểm tra
  // `active.isEmpty` phía trên KHÔNG bắt được lỗi này (entry vẫn tồn tại,
  // chỉ có 1 field con rỗng) — Future generate() sau đó sẽ ném lỗi HTTP
  // 401/thô từ chính provider, không phải thông báo dễ hiểu. Gọi
  // `isReady()` ngay tại ĐÂY — 1 điểm DUY NHẤT, vì mọi nơi tạo chương/chat/
  // dịch tài liệu trong app đều đi qua `currentProvider()` (xem danh sách
  // nơi gọi) — thay vì phải nhớ gọi lại `isReady()` rải rác ở từng màn hình.
  // ĐÃ SỬA (v14 — theo yêu cầu người dùng: "cài đặt thì áp dụng cho quyển
  // truyện chứ không phải cho toàn app"): `currentProvider()`/`_buildProvider()`
  // giờ BẮT BUỘC nhận `novelId` — dựng ĐÚNG provider mà TRUYỆN ĐÓ đang
  // chọn, không còn 1 provider "active" DUY NHẤT dùng chung mọi truyện.
  // Đã cập nhật toàn bộ ~14 nơi gọi `currentProvider()` trong app để
  // truyền đúng `novelId` của ngữ cảnh đang thao tác (xem
  // `chapter_editor_screen.dart` dùng `widget.chapter.novelId`,
  // `chat_screen.dart`/`story_bible_screen.dart`/`document_screen.dart`/
  // `chapters_batch_generate_screen.dart` dùng `widget.novelId`,
  // `document_chunks_screen.dart` dùng `widget.doc.novelId`,
  // `local_optimization_screen.dart`/`background_task_manager.dart` nhận
  // `novelId` truyền từ nơi gọi — riêng `background_task_manager.dart`
  // không có "màn hình" cụ thể nào, dùng `loadActiveNovelId()` để suy ra
  // "truyện đang mở trên máy tại thời điểm lên lịch tác vụ", xem giải
  // thích đầy đủ ở đó).
  Future<AIProvider> currentProvider(String novelId) async {
    final provider = await _buildProvider(novelId);
    if (!await provider.isReady()) {
      throw Exception(
        provider is LocalLlamaProvider
            ? 'Model local đã chọn nhưng đường dẫn file bị thiếu/rỗng — vào Cài đặt → Model local, chọn lại file model.'
            : 'Provider đã chọn nhưng thiếu API key — vào Cài đặt → Provider API, nhập lại API key cho provider này.',
      );
    }
    return provider;
  }

  Future<AIProvider> _buildProvider(String novelId) async {
    final type = await loadProviderType(novelId);
    if (type == AIProviderType.localLlama) {
      final activeId = await loadActiveLocalModelId(novelId);
      final models = await db.allLocalModels();
      final active = models.where((m) => m.id == activeId).toList();
      if (active.isEmpty) {
        throw Exception('Truyện này chưa chọn model local nào đang active. Vào Cài đặt → thêm/chọn model.');
      }
      // Không còn truyền threads/contextSize/numGpuLayers thủ công nữa —
      // engine MNN+QNN mới tự thử QNN → OpenCL (GPU) → CPU theo thứ tự,
      // không cần cấu hình tay như bản llama_cpp_dart cũ.
      //
      // Dùng lại instance đã cache nếu modelPath KHÔNG đổi — tránh gọi
      // loadModel native lại mỗi lần chat/viết chương.
      // ĐÃ SỬA (v15 — `backendPreference` giờ RIÊNG TỪNG TRUYỆN): khoá cache
      // TRƯỚC ĐÂY chỉ theo model path — SAI nếu 2 truyện cùng chọn 1 model
      // nhưng khác `backendPreference` (vd truyện A ép CPU để né crash QNN,
      // truyện B để mặc định OpenCL) — dùng lại instance cũ sẽ ĐEM NHẦM
      // backend của truyện A sang cho truyện B, vì `ensureLoaded()` chỉ gọi
      // `loadModel` native (đọc `backendPreference`) khi CHƯA `_loaded`. Khoá
      // cache giờ theo CẶP (path, novelId) — 2 truyện cùng model vẫn nạp lại
      // (chấp nhận đánh đổi, đã cảnh báo người dùng trước khi làm mục 4 ở
      // LocalNovel_Architecture_Spec.md), nhưng đúng backend từng truyện.
      final path = active.first.path;
      final cacheKey = '$path::$novelId';
      if (_cachedLocalProvider != null && _cachedLocalModelPath == cacheKey) {
        return _cachedLocalProvider!;
      }
      final provider = LocalLlamaProvider(modelPath: path, novelId: novelId);
      _cachedLocalProvider = provider;
      _cachedLocalModelPath = cacheKey;
      return provider;
    }

    final activeId = await loadActiveApiProviderId(novelId);
    final providers = await db.allApiProviders();
    final active = providers.where((p) => p.id == activeId).toList();
    if (active.isEmpty) {
      throw Exception('Truyện này chưa chọn API provider nào đang active. Vào Cài đặt → thêm/chọn provider.');
    }
    final entry = active.first;
    final apiKey = await _secure.read(key: 'api_key_${entry.id}') ?? '';
    if (entry.type == 'anthropic') {
      return AnthropicProvider(apiKey: apiKey, modelId: entry.modelId);
    }
    return OpenAICompatibleProvider(
      baseUrl: entry.baseUrl ?? 'https://api.openai.com/v1',
      apiKey: apiKey,
      modelId: entry.modelId,
    );
  }

  // Embedding cho RAG: fllama chưa expose API embedding cấp cao, dùng
  // vector hashing thuần Dart — luôn chạy được, không phụ thuộc gì thêm.
  Future<EmbeddingService> currentEmbeddingService() async => HashingEmbeddingService();
}

