import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'database_service.dart';
import 'embedding_service.dart';
import 'providers/local_provider.dart';
import 'providers/anthropic_provider.dart';
import 'providers/openai_compatible_provider.dart';

class SettingsService {
  static const _secure = FlutterSecureStorage();
  final db = DatabaseService.instance;

  static const _kProviderType = 'provider_type';
  static const _kActiveLocalModelId = 'active_local_model_id';
  static const _kActiveApiProviderId = 'active_api_provider_id';
  static const _kLocalThreads = 'local_threads';
  static const _kLocalContext = 'local_context';
  static const _kLocalGpuLayers = 'local_gpu_layers';
  static const _kRagBudget = 'rag_context_budget';

  static const _kActiveNovelId = 'active_novel_id';

  // ---------- Truyện đang active (đa truyện) ----------
  Future<List<Novel>> allNovels() => db.allNovels();

  Future<Novel> createNovel(String title, {String author = ''}) async {
    final novel = Novel(id: DateTime.now().millisecondsSinceEpoch.toString(), title: title, author: author);
    await db.upsertNovel(novel);
    return novel;
  }

  Future<void> renameNovel(Novel novel) async {
    novel.updatedAt = DateTime.now();
    await db.upsertNovel(novel);
  }

  Future<void> deleteNovel(String id) async {
    await db.deleteNovel(id);
    final activeId = await loadActiveNovelId();
    if (activeId == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kActiveNovelId);
    }
  }

  Future<void> setActiveNovel(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kActiveNovelId, id);
  }

  Future<String?> loadActiveNovelId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kActiveNovelId);
  }

  Future<void> saveProviderType(AIProviderType type) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kProviderType, type.name);
  }

  Future<AIProviderType> loadProviderType() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kProviderType);
    return AIProviderType.values.firstWhere((t) => t.name == raw, orElse: () => AIProviderType.localLlama);
  }

  // ---------- Local models (nhiều model, chọn 1 đang active) ----------
  Future<void> addLocalModel(String name, String path) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await db.upsertLocalModel(LocalModelEntry(id: id, name: name, path: path));
    // Nếu đây là model đầu tiên được thêm, tự đặt làm active luôn.
    final all = await db.allLocalModels();
    if (all.length == 1) await setActiveLocalModel(id);
  }

  Future<List<LocalModelEntry>> allLocalModels() => db.allLocalModels();

  Future<void> deleteLocalModel(String id) async {
    await db.deleteLocalModel(id);
    final activeId = await loadActiveLocalModelId();
    if (activeId == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kActiveLocalModelId);
    }
  }

  Future<void> setActiveLocalModel(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kActiveLocalModelId, id);
  }

  Future<String?> loadActiveLocalModelId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kActiveLocalModelId);
  }

  Future<void> saveLocalInferenceConfig({
    required int threads,
    required int contextSize,
    required int numGpuLayers,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kLocalThreads, threads);
    await prefs.setInt(_kLocalContext, contextSize);
    await prefs.setInt(_kLocalGpuLayers, numGpuLayers);
  }

  Future<({int threads, int contextSize, int numGpuLayers})> loadLocalInferenceConfig() async {
    final prefs = await SharedPreferences.getInstance();
    return (
      threads: prefs.getInt(_kLocalThreads) ?? 4,
      contextSize: prefs.getInt(_kLocalContext) ?? 2048,
      numGpuLayers: prefs.getInt(_kLocalGpuLayers) ?? 99,
    );
  }

  // ---------- API providers (nhiều provider tự thêm, chọn 1 đang active) ----------
  Future<void> addApiProvider({
    required String name,
    required String type, // 'anthropic' | 'openai_compatible'
    String? baseUrl,
    required String modelId,
    required String apiKey,
  }) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await db.upsertApiProvider(ApiProviderEntry(id: id, name: name, type: type, baseUrl: baseUrl, modelId: modelId));
    await _secure.write(key: 'api_key_$id', value: apiKey);
    final all = await db.allApiProviders();
    if (all.length == 1) await setActiveApiProvider(id);
  }

  Future<List<ApiProviderEntry>> allApiProviders() => db.allApiProviders();

  Future<void> deleteApiProvider(String id) async {
    await db.deleteApiProvider(id);
    await _secure.delete(key: 'api_key_$id');
    final activeId = await loadActiveApiProviderId();
    if (activeId == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kActiveApiProviderId);
    }
  }

  Future<void> setActiveApiProvider(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kActiveApiProviderId, id);
  }

  Future<String?> loadActiveApiProviderId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kActiveApiProviderId);
  }

  Future<void> saveRagBudget(int chars) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kRagBudget, chars);
  }

  Future<int> loadRagBudget() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_kRagBudget) ?? 3500;
  }

  // Dựng provider đang active, sẵn sàng dùng ngay. Throw rõ ràng nếu
  // chưa có gì được chọn, thay vì âm thầm dùng giá trị rỗng/mặc định.
  Future<AIProvider> currentProvider() async {
    final type = await loadProviderType();
    if (type == AIProviderType.localLlama) {
      final activeId = await loadActiveLocalModelId();
      final models = await db.allLocalModels();
      final active = models.where((m) => m.id == activeId).toList();
      if (active.isEmpty) {
        throw Exception('Chưa chọn model local nào đang active. Vào Cài đặt → thêm/chọn model.');
      }
      // Không còn truyền threads/contextSize/numGpuLayers thủ công nữa —
      // engine MNN+QNN mới tự thử QNN → OpenCL (GPU) → CPU theo thứ tự,
      // không cần cấu hình tay như bản llama_cpp_dart cũ.
      return LocalLlamaProvider(modelPath: active.first.path);
    }

    final activeId = await loadActiveApiProviderId();
    final providers = await db.allApiProviders();
    final active = providers.where((p) => p.id == activeId).toList();
    if (active.isEmpty) {
      throw Exception('Chưa chọn API provider nào đang active. Vào Cài đặt → thêm/chọn provider.');
    }
    final entry = active.first;
    final apiKey = await _secure.read(key: 'api_key_${entry.id}') ?? '';
    if (entry.type == 'anthropic') {
      return AnthropicProvider(apiKey: apiKey, modelId: entry.modelId);
    }
    return OpenAICompatibleProvider(
      baseUrl: entry.baseUrl ?? 'https://api.openai.com/v1',
      apiKey: apiKey,
      modelId: entry.modelId,
    );
  }

  // Embedding cho RAG: fllama chưa expose API embedding cấp cao, dùng
  // vector hashing thuần Dart — luôn chạy được, không phụ thuộc gì thêm.
  Future<EmbeddingService> currentEmbeddingService() async => HashingEmbeddingService();
}
