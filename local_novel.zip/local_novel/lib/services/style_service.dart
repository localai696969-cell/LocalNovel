import '../models/story_models.dart';
import 'ai_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'translation_service.dart';

class StyleService {
  // Phân tích một mẫu văn (của chính người dùng, hoặc văn bản không có
  // bản quyền như tác phẩm public domain) thành MÔ TẢ văn phong bằng
  // lời — nhịp câu, cách thoại, từ vựng, tông giọng — chứ không lưu lại
  // nguyên văn. Đây là cách app "học giọng văn" mà không cần giữ bản
  // sao tác phẩm gốc trong máy.
  Future<String> analyzeStyleFromSample(String sampleText, AIProvider provider) async {
    // ĐÃ SỬA (rà soát toàn hệ thống): mẫu văn phong người dùng đưa vào là
    // văn bản TIẾNG VIỆT (mẫu để "học giọng văn" cho AI viết tiếp tiếng
    // Việt) — trước đây gọi thẳng provider.generate(), bỏ qua dịch thuật
    // trung gian như mọi tác vụ dùng nội dung tiếng Việt khác.
    return TranslationService(SettingsService()).generateWithOptionalTranslation(
      mainProvider: provider,
      systemPrompt: 'Bạn là nhà phê bình văn học. Chỉ trả lời bằng bản mô tả văn phong, '
          'không trích dẫn lại nguyên văn đoạn mẫu.',
      userPrompt: 'Phân tích văn phong của đoạn văn sau: độ dài câu, cách dùng từ, '
          'nhịp điệu, cách viết thoại, tông giọng, những đặc điểm lặp lại. '
          'Viết thành một đoạn mô tả 5-8 câu để dùng làm hướng dẫn văn phong cho AI viết tiếp, '
          'không trích dẫn lại câu chữ gốc:\n\n$sampleText',
      maxTokens: 400,
      temperature: 0.3,
    );
  }

  // Dựng sẵn cặp (systemPrompt, userPrompt) cho tác vụ "đắp thịt" — tách
  // riêng khỏi việc gọi provider để tầng trên (chapter_editor_screen) có
  // thể tự quyết định gọi thẳng provider.generate() hay đi qua
  // TranslationService.generateWithOptionalTranslation() (dịch thuật trung
  // gian tùy chọn), đồng thời tự áp tham số sinh văn bản người dùng đã
  // cấu hình (GenerationSettingsScreen) thay vì hardcode ở đây.
  Future<({String systemPrompt, String userPrompt})> buildFleshOutPrompt({
    required String outline,
    required StyleProfile? style,
    required RagService rag,
  }) async {
    final context = await rag.buildContext(currentText: outline);
    final styleInstruction = style == null
        ? 'Dùng văn phong mạch lạc, tự nhiên, phù hợp thể loại.'
        : 'Viết đúng theo văn phong sau: ${style.profileDescription}';

    final systemPrompt = '''
Bạn là người viết tiểu thuyết dài kỳ, nhận một outline sơ sài (định hướng
cốt truyện, chưa phải văn xuôi) và triển khai thành một chương hoàn
chỉnh, có thoại, diễn biến, miêu tả — không chỉ liệt kê lại outline.

$styleInstruction

Bám sát Story Bible liên quan dưới đây, không vi phạm luật thế giới hay
làm sai thông tin nhân vật:

$context
''';

    return (
      systemPrompt: systemPrompt,
      userPrompt: 'Outline cốt truyện cần triển khai thành chương đầy đủ:\n\n$outline',
    );
  }

  // "Đắp thịt": nhận outline sơ sài (vài gạch đầu dòng định hướng cốt
  // truyện) + văn phong mong muốn + toàn bộ ngữ cảnh Story Bible liên
  // quan (qua RagService), rồi sinh ra một chương văn đầy đủ. Giữ lại hàm
  // này (gọi thẳng provider, không qua dịch thuật trung gian) để tương
  // thích ngược cho nơi nào chưa cần luồng dịch thuật.
  Future<String> fleshOutOutline({
    required String outline,
    required StyleProfile? style,
    required RagService rag,
    required AIProvider provider,
    double temperature = 0.95,
    int maxTokens = 1500,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) async {
    final prompt = await buildFleshOutPrompt(outline: outline, style: style, rag: rag);
    return provider.generate(
      systemPrompt: prompt.systemPrompt,
      userPrompt: prompt.userPrompt,
      maxTokens: maxTokens,
      temperature: temperature,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
    );
  }
}
