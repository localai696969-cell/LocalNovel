import '../models/story_models.dart';
import 'ai_provider.dart';
import 'rag_service.dart';

class StyleService {
  // Phân tích một mẫu văn (của chính người dùng, hoặc văn bản không có
  // bản quyền như tác phẩm public domain) thành MÔ TẢ văn phong bằng
  // lời — nhịp câu, cách thoại, từ vựng, tông giọng — chứ không lưu lại
  // nguyên văn. Đây là cách app "học giọng văn" mà không cần giữ bản
  // sao tác phẩm gốc trong máy.
  Future<String> analyzeStyleFromSample(String sampleText, AIProvider provider) async {
    return provider.generate(
      systemPrompt: 'Bạn là nhà phê bình văn học. Chỉ trả lời bằng bản mô tả văn phong, '
          'không trích dẫn lại nguyên văn đoạn mẫu.',
      userPrompt: 'Phân tích văn phong của đoạn văn sau: độ dài câu, cách dùng từ, '
          'nhịp điệu, cách viết thoại, tông giọng, những đặc điểm lặp lại. '
          'Viết thành một đoạn mô tả 5-8 câu để dùng làm hướng dẫn văn phong cho AI viết tiếp, '
          'không trích dẫn lại câu chữ gốc:\n\n$sampleText',
      maxTokens: 400,
      temperature: 0.3,
    );
  }

  // "Đắp thịt": nhận outline sơ sài (vài gạch đầu dòng định hướng cốt
  // truyện) + văn phong mong muốn + toàn bộ ngữ cảnh Story Bible liên
  // quan (qua RagService), rồi sinh ra một chương văn đầy đủ.
  Future<String> fleshOutOutline({
    required String outline,
    required StyleProfile? style,
    required RagService rag,
    required AIProvider provider,
  }) async {
    final context = await rag.buildContext(currentText: outline);
    final styleInstruction = style == null
        ? 'Dùng văn phong mạch lạc, tự nhiên, phù hợp thể loại.'
        : 'Viết đúng theo văn phong sau: ${style.profileDescription}';

    final systemPrompt = '''
Bạn là người viết tiểu thuyết dài kỳ, nhận một outline sơ sài (định hướng
cốt truyện, chưa phải văn xuôi) và triển khai thành một chương hoàn
chỉnh, có thoại, diễn biến, miêu tả — không chỉ liệt kê lại outline.

$styleInstruction

Bám sát Story Bible liên quan dưới đây, không vi phạm luật thế giới hay
làm sai thông tin nhân vật:

$context
''';

    return provider.generate(
      systemPrompt: systemPrompt,
      userPrompt: 'Outline cốt truyện cần triển khai thành chương đầy đủ:\n\n$outline',
      maxTokens: 1500,
      temperature: 0.95,
    );
  }
}
