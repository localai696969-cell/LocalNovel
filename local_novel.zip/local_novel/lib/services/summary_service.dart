import '../models/story_models.dart';
import '../services/ai_provider.dart';

// Tóm tắt tự động là lớp "bộ nhớ nén" giúp RagService không phải nhét
// nguyên văn hàng nghìn chữ của mỗi chương vào ngữ cảnh. Chạy sau khi
// người dùng lưu chương, không chặn UI.
class SummaryService {
  Future<String> summarizeChapter(Chapter chapter, AIProvider provider) async {
    if (chapter.content.trim().isEmpty) return '';
    final result = await provider.generate(
      systemPrompt: 'Bạn là biên tập viên tóm tắt tiểu thuyết. Chỉ trả lời bằng đoạn tóm tắt, '
          'không thêm lời dẫn hay tiêu đề.',
      userPrompt: 'Tóm tắt chương sau trong 3-5 câu, giữ đúng tên riêng nhân vật/địa danh, '
          'nêu rõ sự kiện chính và thay đổi trạng thái nhân vật (nếu có):\n\n${chapter.content}',
      maxTokens: 300,
      temperature: 0.3,
    );
    return result.trim();
  }
}
