import '../models/story_models.dart';
import '../services/ai_provider.dart';
import 'settings_service.dart';
import 'translation_service.dart';

// Tóm tắt tự động là lớp "bộ nhớ nén" giúp RagService không phải nhét
// nguyên văn hàng nghìn chữ của mỗi chương vào ngữ cảnh. Chạy sau khi
// người dùng lưu chương, không chặn UI.
class SummaryService {
  Future<String> summarizeChapter(Chapter chapter, AIProvider provider) async {
    if (chapter.content.trim().isEmpty) return '';
    // ĐÃ SỬA (phát hiện qua rà soát toàn hệ thống theo yêu cầu người dùng):
    // trước đây gọi thẳng provider.generate(), BỎ QUA dịch thuật trung
    // gian — nội dung chương (chapter.content) là văn bản TIẾNG VIỆT thật
    // sự (khác hẳn document_service.dart, nơi văn bản gốc là ngoại ngữ
    // chưa dịch, KHÔNG được đi qua bước này vì sẽ dịch sai) — nên tóm tắt
    // chương đúng phải đi qua cùng pipeline dịch thuật như mọi tác vụ AI
    // khác dùng nội dung tiếng Việt của người dùng, nếu người dùng đã bật.
    //
    // ĐÃ SỬA (mục Z tài liệu kiến trúc, 2026-09-08 — sự cố THẬT xác nhận
    // qua debug log: prompt hệ thống dưới đây khớp NGUYÊN VĂN với lệnh
    // generate() bị lặp vô tận 40 phút): `temperature: 0.3` (thấp, để bám
    // sát nội dung chương) kết hợp `repetitionPenalty` MẶC ĐỊNH 1.05 (số
    // dùng chung cho mọi tác vụ, kể cả "viết chương" ở nhiệt độ cao hơn
    // hẳn) là đúng công thức dễ gây model suy biến thành lặp — nhiệt độ
    // càng thấp (càng gần chọn token xác suất cao nhất mỗi bước) càng cần
    // phạt lặp MẠNH hơn để bù, không phải giữ nguyên/yếu hơn. Tăng riêng
    // cho đúng tác vụ tóm tắt này lên 1.2 — KHÔNG đụng tới cài đặt "Phạt
    // lặp từ" của người dùng (dùng cho việc VIẾT chương, màn
    // `GenerationSettingsScreen`, xem mục 4.7).
    //
    // `isCancelled`: tác vụ này chạy NỀN, im lặng (không `onChunk` hiện
    // chữ lên UI) — khác hẳn lúc người dùng đang trực tiếp xem "Đắp thịt"
    // chạy, nơi mục H CỐ TÌNH bỏ mọi giới hạn thời gian (chấp nhận model
    // chậm, không muốn cắt oan lệnh còn sống). Tác vụ NGẦM này không có lý
    // do tương tự để được treo vô thời hạn — 1 lệnh tóm tắt 300 token bị
    // lặp có thể chiếm mất slot model LOCAL (cap=1) hàng chục phút, chặn
    // đứng lệnh "Đắp thịt"/"Viết tiếp" thật của người dùng đang xếp hàng
    // phía sau (đúng nguyên nhân sự cố "không thể tạo chương truyện" đã
    // xác nhận). Trần 3 phút đủ rộng cho 1 lượt tóm tắt bình thường (300
    // token) ngay cả trên model/máy chậm nhất đã đo (mục F/G/H) — quá
    // hạn, `generateWithOptionalTranslation` tự `break` khỏi stream, kích
    // hoạt đúng đường dọn dẹp `cancelGenerate()` có sẵn ở
    // `local_provider.dart` (nhánh `finally`, `!doneReceived`), không cần
    // thêm cơ chế huỷ nào mới. Không thay thế cho bản vá native/Dart ở
    // `looksLikeRepetitionLoop()` (mục Z) — đây là lớp phòng vệ ĐỘC LẬP
    // thứ 2, phòng trường hợp 1 kiểu suy biến khác trong tương lai vẫn lọt
    // qua cả 2 tầng phát hiện lặp.
    final stopwatch = Stopwatch()..start();
    final result = await TranslationService(SettingsService(), novelId: chapter.novelId).generateWithOptionalTranslation(
      mainProvider: provider,
      systemPrompt: 'Bạn là biên tập viên tóm tắt tiểu thuyết. Chỉ trả lời bằng đoạn tóm tắt, '
          'không thêm lời dẫn hay tiêu đề.',
      userPrompt: 'Tóm tắt chương sau trong 3-5 câu, giữ đúng tên riêng nhân vật/địa danh, '
          'nêu rõ sự kiện chính và thay đổi trạng thái nhân vật (nếu có):\n\n${chapter.content}',
      maxTokens: 300,
      temperature: 0.3,
      repetitionPenalty: 1.2,
      isCancelled: () => stopwatch.elapsed > const Duration(minutes: 3),
    );
    return result.trim();
  }
}
