import '../models/story_models.dart';
import '../services/ai_provider.dart';
import 'settings_service.dart';
import 'translation_service.dart';

// Tóm tắt tự động là lớp "bộ nhớ nén" giúp RagService không phải nhét
// nguyên văn hàng nghìn chữ của mỗi chương vào ngữ cảnh. Chạy sau khi
// người dùng lưu chương, không chặn UI.
class SummaryService {
  Future<String> summarizeChapter(Chapter chapter, AIProvider provider) async {
    if (chapter.content.trim().isEmpty) return '';
    // ĐÃ SỬA (phát hiện qua rà soát toàn hệ thống theo yêu cầu người dùng):
    // trước đây gọi thẳng provider.generate(), BỎ QUA dịch thuật trung
    // gian — nội dung chương (chapter.content) là văn bản TIẾNG VIỆT thật
    // sự (khác hẳn document_service.dart, nơi văn bản gốc là ngoại ngữ
    // chưa dịch, KHÔNG được đi qua bước này vì sẽ dịch sai) — nên tóm tắt
    // chương đúng phải đi qua cùng pipeline dịch thuật như mọi tác vụ AI
    // khác dùng nội dung tiếng Việt của người dùng, nếu người dùng đã bật.
    final result = await TranslationService(SettingsService(), novelId: chapter.novelId).generateWithOptionalTranslation(
      mainProvider: provider,
      systemPrompt: 'Bạn là biên tập viên tóm tắt tiểu thuyết. Chỉ trả lời bằng đoạn tóm tắt, '
          'không thêm lời dẫn hay tiêu đề.',
      userPrompt: 'Tóm tắt chương sau trong 3-5 câu, giữ đúng tên riêng nhân vật/địa danh, '
          'nêu rõ sự kiện chính và thay đổi trạng thái nhân vật (nếu có):\n\n${chapter.content}',
      maxTokens: 300,
      temperature: 0.3,
    );
    return result.trim();
  }
}
