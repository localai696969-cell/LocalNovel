import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ĐÃ THÊM (theo yêu cầu người dùng: "tất cả các màn hình có tính năng
// zoom không" — trước đây KHÔNG có, kiểm tra toàn bộ code không thấy bất
// kỳ đâu điều chỉnh cỡ chữ). "Zoom" thật sự (pinch 2 ngón) trên từng ô
// nhập liệu/danh sách rủi ro xung đột với các cử chỉu đã có sẵn ở đó (kéo
// chọn văn bản, kéo để cuộn danh sách...) — cố làm vội dễ gây lỗi mới ở
// những màn vốn đã phức tạp (`chapter_editor_screen.dart`). Chọn cách AN
// TOÀN HƠN, áp dụng ĐƯỢC THẬT cho MỌI màn hình cùng lúc: 1 mức "cỡ chữ"
// toàn app (dùng cơ chế `textScaler` chuẩn của Flutter — vốn được THIẾT
// KẾ SẴN để hoạt động nhất quán trên mọi widget hiển thị chữ, không cần
// tự sửa từng màn), điều chỉnh qua 1 thanh trượt, lưu bền qua
// SharedPreferences — không phải pinch-zoom thật, nhưng giải quyết đúng
// nhu cầu gốc (chữ trên máy nhỏ khó đọc) một cách nhất quán và an toàn
// hơn nhiều so với gắn pinch-gesture vội vàng vào từng nơi.
class TextScaleService {
  TextScaleService._();
  static final TextScaleService instance = TextScaleService._();

  static const _key = 'app_text_scale_factor';
  static const double min = 0.85;
  static const double max = 1.6;
  static const double defaultScale = 1.0;

  final ValueNotifier<double> scale = ValueNotifier<double>(defaultScale);
  bool _loaded = false;

  Future<void> loadOnce() async {
    if (_loaded) return;
    _loaded = true;
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getDouble(_key);
    if (saved != null) scale.value = saved.clamp(min, max);
  }

  Future<void> setScale(double value) async {
    final clamped = value.clamp(min, max);
    scale.value = clamped;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_key, clamped);
  }
}

// ĐÃ THÊM (theo phản hồi người dùng: "phần tăng kích cỡ chữ ở màn hình
// khung chat sao không thấy" — đúng, trước đây hộp thoại này được viết
// riêng, gắn cứng vào MỘT MÌNH `NovelListScreen` (màn "Truyện của bạn" —
// màn TRƯỚC KHI vào 1 truyện cụ thể). Một khi đã mở 1 truyện (chat, viết
// chương...) thì không còn đường nào quay lại màn đó để chỉnh mà không
// thoát cả truyện ra — nút cỡ chữ coi như "biến mất" với người dùng đang
// làm việc trong truyện. Tách hộp thoại ra hàm dùng chung ở đây, gọi được
// từ BẤT KỲ màn hình nào (đã gắn thêm vào `chat_screen.dart`; các màn
// khác — chương, Bách khoa... — có thể gắn thêm tương tự bằng cách gọi
// đúng hàm này, không cần chép lại code).
void showTextScaleDialog(BuildContext context) {
  showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Cỡ chữ'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Áp dụng cho MỌI màn hình trong app (không chỉ màn này) — kể cả chương, chat, '
            'Bách khoa, Cài đặt...',
            style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
          ),
          const SizedBox(height: 16),
          ValueListenableBuilder<double>(
            valueListenable: TextScaleService.instance.scale,
            builder: (context, value, _) {
              return Column(
                children: [
                  Text('Aa', style: TextStyle(fontSize: 16 * value)),
                  Slider(
                    value: value,
                    min: TextScaleService.min,
                    max: TextScaleService.max,
                    divisions: 15,
                    label: '${(value * 100).round()}%',
                    onChanged: (v) => TextScaleService.instance.setScale(v),
                  ),
                ],
              );
            },
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => TextScaleService.instance.setScale(TextScaleService.defaultScale),
          child: const Text('Về mặc định'),
        ),
        FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Xong')),
      ],
    ),
  );
}
