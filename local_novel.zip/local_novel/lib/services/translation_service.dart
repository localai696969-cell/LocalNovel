import 'ai_provider.dart';
import 'device_profile_service.dart';
import 'providers/local_provider.dart';
import 'settings_service.dart';

// Dịch thuật trung gian — TÙY CHỌN, mặc định TẮT. Giải quyết vấn đề:
// nhiều model viết truyện hay (văn phong tốt) không được huấn luyện
// nhiều trên dữ liệu tiếng Việt, nên viết/chat trực tiếp bằng tiếng
// Việt dễ ra câu ngô nghê, lặp từ vô nghĩa, hoặc ký tự lạ. Giải pháp:
// dịch input sang ngôn ngữ model hiểu tốt (thường là tiếng Anh) → để
// model chính sinh văn bản bằng ngôn ngữ đó → dịch kết quả về tiếng Việt.
//
// LUÔN CHẠY TUẦN TỰ, không bao giờ giữ 2 model cùng chạy suy luận song
// song (dù có thể cùng NẰM trong RAM) — đúng yêu cầu đã thống nhất:
// dịch xong mới tới model chính, model chính xong mới dịch ngược lại.
//
// Việc GIỮ hay XẢ model dịch giữa các bước là quyết định theo RAM máy,
// không hardcode: máy nhiều RAM (>= ramKeepResidentThresholdMb) giữ
// nguyên model dịch trong RAM suốt phiên làm việc (đỡ phải nạp lại nhiều
// lần), máy ít RAM thì xả ngay sau mỗi lần dùng.
class TranslationService {
  final SettingsService settings;
  static const int ramKeepResidentThresholdMb = 6000; // dưới mức này thì luôn xả sau khi dùng

  TranslationService(this.settings);

  Future<bool> get isEnabled async => settings.loadTranslationEnabled();

  LocalLlamaProvider? _translationProvider;

  Future<LocalLlamaProvider> _getTranslationProvider() async {
    final path = await settings.loadTranslationModelPath();
    if (path == null || path.isEmpty) {
      throw Exception(
        'Chưa chọn model dịch thuật. Vào Cài đặt → Dịch thuật trung gian → chọn 1 model nhỏ (khuyến nghị 0.3B-1.5B).',
      );
    }
    if (_translationProvider == null || _translationProvider!.modelPath != path) {
      _translationProvider = LocalLlamaProvider(modelPath: path, slot: MnnSlots.translation);
    }
    return _translationProvider!;
  }

  Future<bool> _shouldKeepResident() async {
    final mode = await settings.loadTranslationKeepResidentMode();
    if (mode == 'always') return true;
    if (mode == 'never') return false;
    // 'auto': tự đoán theo tổng RAM máy.
    final ramMb = await DeviceProfileService().readTotalRamMb();
    return ramMb >= ramKeepResidentThresholdMb;
  }

  // Dịch một đoạn văn bản theo 1 chiều. direction=true: Việt -> ngôn ngữ
  // đích (trước khi đưa vào model chính). direction=false: ngôn ngữ đích
  // -> Việt (sau khi model chính trả lời xong).
  Future<String> translate(String text, {required bool toTarget}) async {
    if (text.trim().isEmpty) return text;
    final provider = await _getTranslationProvider();
    final targetLanguage = await settings.loadTranslationTargetLanguage();
    final stylePrompt = await settings.loadTranslationStylePrompt();

    final instruction = toTarget
        ? 'Dịch đoạn văn bản tiếng Việt sau sang $targetLanguage. $stylePrompt '
            'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.'
        : 'Dịch đoạn văn bản $targetLanguage sau sang tiếng Việt tự nhiên, đúng văn phong tiểu thuyết. $stylePrompt '
            'Chỉ trả về đúng bản dịch, không giải thích, không thêm ghi chú.';

    final result = await provider.generate(
      systemPrompt: instruction,
      userPrompt: text,
      temperature: 0.3, // dịch thuật cần chính xác, không cần sáng tạo
      maxTokens: (text.length * 2).clamp(256, 4096),
    );
    return result.trim();
  }

  // Bọc toàn bộ luồng: dịch câu hỏi -> gọi model chính -> dịch kết quả.
  // Nếu tính năng đang TẮT, chạy thẳng model chính như bình thường,
  // không qua bước dịch nào (không phạt hiệu năng khi không cần dùng).
  // ĐÃ SỬA (2026-08-02, phát hiện qua câu hỏi trực tiếp của người dùng về
  // hạ tầng dịch thuật trung gian): trước đây hàm này chỉ nhận
  // temperature/maxTokens, ÂM THẦM BỎ QUA topP/topK/repetitionPenalty ở
  // CẢ HAI nhánh (có dịch/không dịch) — người dùng chỉnh các tham số này
  // trong Cài đặt sẽ không có tác dụng thật với bất kỳ lệnh nào đi qua
  // hàm dùng chung này. Giờ nhận đủ và truyền xuyên suốt.
  Future<String> generateWithOptionalTranslation({
    required AIProvider mainProvider,
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    void Function(String stage)? onStage,
  }) async {
    final enabled = await isEnabled;
    if (!enabled) {
      onStage?.call('Đang sinh văn bản...');
      return mainProvider.generate(
        systemPrompt: systemPrompt,
        userPrompt: userPrompt,
        temperature: temperature,
        maxTokens: maxTokens,
        topP: topP,
        topK: topK,
        repetitionPenalty: repetitionPenalty,
      );
    }

    final keepResident = await _shouldKeepResident();

    // Gộp 3 bước (dịch → sinh → dịch ngược) vào ĐÚNG 1 phiên Foreground
    // Service: start() 1 lần ở đây, mỗi bước bên dưới chỉ updateStage() nội
    // dung thông báo, endPipeline() ở finally khi cả 3 bước xong (hoặc lỗi
    // giữa chừng) — không còn khoảng hở start/stop giữa từng bước như trước.
    const stage1 = 'Đang dịch câu hỏi sang ngôn ngữ model hiểu tốt...';
    await LocalLlamaProvider.beginPipeline(stage1);
    try {
      onStage?.call(stage1);
      final translatedPrompt = await translate(userPrompt, toTarget: true);
      if (!keepResident) await (await _getTranslationProvider()).unload();

      const stage2 = 'Đang sinh văn bản...';
      await LocalLlamaProvider.updatePipelineStage(stage2);
      onStage?.call(stage2);
      final rawResult = await mainProvider.generate(
        systemPrompt: systemPrompt,
        userPrompt: translatedPrompt,
        temperature: temperature,
        maxTokens: maxTokens,
        topP: topP,
        topK: topK,
        repetitionPenalty: repetitionPenalty,
      );

      const stage3 = 'Đang dịch kết quả về tiếng Việt...';
      await LocalLlamaProvider.updatePipelineStage(stage3);
      onStage?.call(stage3);
      final finalResult = await translate(rawResult, toTarget: false);
      if (!keepResident) await (await _getTranslationProvider()).unload();

      return finalResult;
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }
}

// Hằng số slot dùng chung — tránh gõ nhầm số 0/1 rải rác khắp code.
class MnnSlots {
  static const int main = 0;
  static const int translation = 1;
}
