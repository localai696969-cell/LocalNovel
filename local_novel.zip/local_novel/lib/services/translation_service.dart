import 'ai_provider.dart';
import 'device_profile_service.dart';
import 'providers/local_provider.dart';
import 'settings_service.dart';

// Dịch thuật trung gian — TÙY CHỌN, mặc định TẮT. Giải quyết vấn đề:
// nhiều model viết truyện hay (văn phong tốt) không được huấn luyện
// nhiều trên dữ liệu tiếng Việt, nên viết/chat trực tiếp bằng tiếng
// Việt dễ ra câu ngô nghê, lặp từ vô nghĩa, hoặc ký tự lạ. Giải pháp:
// dịch input sang ngôn ngữ model hiểu tốt (thường là tiếng Anh) → để
// model chính sinh văn bản bằng ngôn ngữ đó → dịch kết quả về tiếng Việt.
//
// LUÔN CHẠY TUẦN TỰ, không bao giờ giữ 2 model cùng chạy suy luận song
// song (dù có thể cùng NẰM trong RAM) — đúng yêu cầu đã thống nhất:
// dịch xong mới tới model chính, model chính xong mới dịch ngược lại.
//
// Việc GIỮ hay XẢ model dịch giữa các bước là quyết định theo RAM máy,
// không hardcode: máy nhiều RAM (>= ramKeepResidentThresholdMb) giữ
// nguyên model dịch trong RAM suốt phiên làm việc (đỡ phải nạp lại nhiều
// lần), máy ít RAM thì xả ngay sau mỗi lần dùng.
class TranslationService {
  final SettingsService settings;
  static const int ramKeepResidentThresholdMb = 6000; // dưới mức này thì luôn xả sau khi dùng

  // ĐÃ THÊM (v15 — theo yêu cầu người dùng: "tất cả" cài đặt kể cả dịch
  // thuật cũng riêng từng truyện): mọi cài đặt dịch thuật (bật/tắt, model,
  // ngôn ngữ đích, prompt, keep-resident) giờ đọc/ghi qua `novelId` này.
  final String novelId;

  TranslationService(this.settings, {required this.novelId});

  Future<bool> get isEnabled async => settings.loadTranslationEnabled(novelId);

  LocalLlamaProvider? _translationProvider;

  // Model dùng để dịch ngôn ngữ (nên nhỏ: 0.3B–1.5B)
  Future<LocalLlamaProvider> _getTranslationProvider() async {
    final path = await settings.loadTranslationModelPath(novelId);
    if (path == null || path.isEmpty) {
      throw Exception(
        'Chưa chọn model dịch thuật. Vào Cài đặt → Dịch thuật trung gian → chọn 1 model nhỏ (khuyến nghị 0.3B-1.5B).',
      );
    }
    if (_translationProvider == null || _translationProvider!.modelPath != path) {
      _translationProvider = LocalLlamaProvider(modelPath: path, slot: MnnSlots.translation, novelId: novelId);
    }
    return _translationProvider!;
  }

  Future<bool> _shouldKeepResident() async {
    final mode = await settings.loadTranslationKeepResidentMode(novelId);
    if (mode == 'always') return true;
    if (mode == 'never') return false;
    // 'auto': tự đoán theo tổng RAM máy.
    final ramMb = await DeviceProfileService().readTotalRamMb();
    return ramMb >= ramKeepResidentThresholdMb;
  }

  // Dịch một đoạn văn bản theo 1 chiều.
  // toTarget=true: Việt → ngôn ngữ trung gian (trước khi đưa vào model chính).
  // toTarget=false: ngôn ngữ trung gian → Việt (sau khi model chính trả về).
  // ĐÃ SỬA (theo phản hồi người dùng: "cái dịch thuật trung gian sao không
  // stream được, khi chỉ cần stream khi model dịch ra màn hình" — ĐÚNG,
  // nhận xét trước đó của Claude sai): chỉ CHIỀU `toTarget=false` (dịch
  // NGƯỢC về tiếng Việt) là chiều NGƯỜI DÙNG THỰC SỰ NHÌN THẤY kết quả —
  // chiều `toTarget=true` chỉ dịch HƯỚNG DẪN/Bible cho model đọc, không
  // hiện ra màn hình, không cần stream. Thêm `onChunk` tùy chọn — model
  // dịch bằng chính `LocalLlamaProvider` (luôn hỗ trợ `generateStream`),
  // không có lý do kỹ thuật nào để không stream được.
  Future<String> translate(
    String text, {
    required bool toTarget,
    void Function(String textSoFar)? onChunk,
    // ĐÃ THÊM: cho phép nơi gọi huỷ giữa chừng khi đang stream (xem
    // `generateWithOptionalTranslation`/chat_screen.dart — nút "X" ở màn
    // "Tác vụ nền"). Chỉ có tác dụng thật ở nhánh streaming (`onChunk !=
    // null`) — nhánh không streaming đợi cả khối nên không có điểm dừng
    // giữa chừng an toàn nào để kiểm tra.
    bool Function()? isCancelled,
  }) async {
    if (text.trim().isEmpty) return text;
    final provider = await _getTranslationProvider();
    final targetLanguage = await settings.loadTranslationTargetLanguage(novelId);
    final stylePrompt = await settings.loadTranslationStylePrompt(novelId);

    // Dùng prompt riêng cho từng chiều nếu người dùng đã tùy chỉnh.
    // {targetLanguage} là placeholder tự thay — cho phép prompt có ngôn ngữ
    // đích rõ ràng mà không cần người dùng gõ tên ngôn ngữ 2 lần.
    String instruction;
    if (toTarget) {
      final raw = await settings.loadTranslationPromptToTarget(novelId);
      instruction = raw.replaceAll('{targetLanguage}', targetLanguage);
      if (stylePrompt.isNotEmpty) instruction = '$instruction $stylePrompt';
    } else {
      final raw = await settings.loadTranslationPromptFromTarget(novelId);
      instruction = raw.replaceAll('{targetLanguage}', targetLanguage);
      if (stylePrompt.isNotEmpty) instruction = '$instruction $stylePrompt';
    }

    // ĐÃ SỬA: trần cũ 4096 token đủ cho userPrompt thông thường (1 câu
    // lệnh/1 đoạn văn), nhưng từ khi systemPrompt (chứa TOÀN BỘ Story
    // Bible liên quan — có thể dài tới contextBudgetChars=3500 ký tự
    // của RagService cộng thêm phần hướng dẫn) CŨNG được dịch qua hàm
    // này (xem sửa ở generateWithOptionalTranslation bên dưới), văn bản
    // cần dịch có thể dài hơn nhiều — nới trần lên 8192 để tránh cắt cụt
    // Bible giữa chừng, gây model chính chỉ nhận được nửa luật thế giới.
    final maxTokens = (text.length * 2).clamp(256, 8192);

    if (onChunk == null) {
      final result = await provider.generate(
        systemPrompt: instruction,
        userPrompt: text,
        temperature: 0.3, // dịch thuật cần chính xác, không cần sáng tạo
        maxTokens: maxTokens,
      );
      return result.trim();
    }

    // Nhánh streaming — CHỈ dùng khi nơi gọi thật sự cần hiện kết quả lên
    // màn hình (chiều dịch ngược). `onChunk` nhận toàn bộ text ĐÃ NHẬN
    // ĐƯỢC tính tới thời điểm đó (không phải chỉ phần mới), giống hệt quy
    // ước `onCheckpoint`/`onChunk` đã dùng ở các hàm khác trong file này.
    final buffer = StringBuffer();
    await for (final chunk in provider.generateStream(
      systemPrompt: instruction,
      userPrompt: text,
      temperature: 0.3,
      maxTokens: maxTokens,
    )) {
      buffer.write(chunk);
      onChunk(buffer.toString());
      // ĐÃ THÊM: kiểm tra NGAY SAU mỗi đoạn nhận được, giống đúng cách
      // `generateResumableWithOptionalTranslation()` đã làm cho batch
      // remote — `break` khỏi `await for` khiến consumer NGỪNG LẮNG NGHE
      // stream của `LocalLlamaProvider.generateStream()`, tự động kích
      // hoạt nhánh "huỷ giữa chừng" đã có sẵn ở đó (gọi `cancelGenerate`
      // native), không cần thêm cơ chế huỷ riêng ở đây.
      if (isCancelled?.call() ?? false) break;
    }
    return buffer.toString().trim();
  }

  // Bọc toàn bộ luồng: dịch câu hỏi → gọi model chính → dịch kết quả.
  // Nếu tính năng đang TẮT, chạy thẳng model chính như bình thường,
  // không qua bước dịch nào (không phạt hiệu năng khi không cần dùng).
  //
  // ĐÃ SỬA TẬN GỐC (rà soát toàn hệ thống theo yêu cầu người dùng, phát
  // hiện lỗ hổng THỨ 3 cùng họ với 2 lỗ hổng Foreground Service trước đó):
  // trước đây hàm này CHỈ dịch `userPrompt`, còn `systemPrompt` — nơi
  // RagService nhét TOÀN BỘ Story Bible liên quan (nhân vật, luật thế
  // giới, thuật ngữ, tuyến truyện, văn phong, dàn ý — xem rag_service.dart
  // buildSystemPrompt()/buildContext(), style_service.dart
  // buildFleshOutPrompt()) — đi THẲNG, NGUYÊN VĂN TIẾNG VIỆT sang model
  // chính, không qua dịch. Tính năng dịch thuật trung gian tồn tại chính
  // vì "model chính không giỏi tiếng Việt" (xem comment đầu file) — nghĩa
  // là khi bật tính năng này, model chính CŨNG không hiểu tốt phần Bible
  // tiếng Việt bị bỏ quên trong systemPrompt, khiến Bible gần như vô hiệu
  // ĐÚNG lúc cần nó nhất (dùng model ngoại lai mạnh, không rành tiếng
  // Việt). Ảnh hưởng "Viết tiếp", "Đắp thịt"/"Tạo chương hàng loạt", "Áp
  // dụng ghi chú sửa", "Trợ lý AI" (chat) — 5/7 nơi gọi hàm này. Chỉ
  // "Kiểm tra tính nhất quán" và "Tóm tắt chương" thoát được vì tự đẩy tay
  // nội dung dài sang userPrompt thay vì systemPrompt.
  //
  // Sửa 1 LẦN DUY NHẤT ở đây theo đúng nguyên tắc đã áp dụng cho lỗ hổng
  // Foreground Service: dịch CẢ systemPrompt (nếu có nội dung) lẫn
  // userPrompt trước khi gọi model chính — mọi nơi gọi hàm này (hiện tại
  // và sau này) tự động được bảo vệ, không cần tự nhớ "phải nhét Bible
  // vào userPrompt mới được dịch" như cách né tạm trước đây.
  // Chỉ dịch systemPrompt theo chiều toTarget — đây là hướng dẫn CHO
  // model, không hiển thị lại cho người dùng, nên không cần dịch ngược.
  Future<String> generateWithOptionalTranslation({
    required AIProvider mainProvider,
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    void Function(String stage)? onStage,
    // ĐÃ THÊM (theo phản hồi người dùng — xem giải thích đầy đủ ở
    // `translate()`): hiện chữ dần lên UI ngay khi có, thay vì đợi cả khối.
    // Hoạt động ở CẢ 2 nhánh — tắt dịch thuật (stream thẳng model chính) VÀ
    // bật dịch thuật (stream đúng bước dịch NGƯỢC — bước duy nhất người
    // dùng thực sự nhìn thấy kết quả).
    void Function(String textSoFar)? onChunk,
    // ĐÃ THÊM (sửa bug thật: nút "X" ở màn "Tác vụ nền" trước đây không
    // dừng được chat local đang stream — xem `background_task_manager.dart`
    // + `chat_screen.dart`): kiểm tra định kỳ, cho phép dừng SỚM giữa
    // chừng ở bước streaming. KHÔNG có tác dụng ở bước "sinh văn bản"
    // KHÔNG streaming của nhánh CÓ dịch thuật bên dưới (`mainProvider.generate()`
    // đợi cả khối, không có điểm dừng an toàn giữa chừng) — giới hạn thật,
    // giống đúng giới hạn đã ghi nhận ở `generateResumableWithOptionalTranslation`.
    bool Function()? isCancelled,
  }) async {
    final enabled = await isEnabled;
    if (!enabled) {
      const stage = 'Đang sinh văn bản...';
      await LocalLlamaProvider.beginPipeline(stage);
      try {
        onStage?.call(stage);
        // ĐÃ SỬA (mục Z tài liệu kiến trúc, 2026-09-08 — lỗi THẬT xác nhận
        // qua debug log): nhánh `onChunk == null` trước đây gọi thẳng
        // `mainProvider.generate()` (đợi cả khối, KHÔNG streaming) — HOÀN
        // TOÀN bỏ qua tham số `isCancelled` dù hàm đã khai báo sẵn, vì
        // `generate()` không có điểm dừng giữa chừng nào. 2 nơi DUY NHẤT
        // gọi đúng nhánh này (`SummaryService.summarizeChapter()` và
        // `RagService.updateCumulativeStorySummary()` — xem sửa kèm ở 2
        // file đó) đều là tác vụ NỀN, im lặng, không có `onChunk` hiện
        // chữ lên UI — và cả 2 đều dính sự cố thật: model rơi vào lặp vô
        // tận ở nhiệt độ thấp, cả 2 tầng phát hiện lặp (native lẫn Dart,
        // xem mục Z ở `mnn_bridge.cpp`/native) cộng hưởng bỏ sót/chậm bắt,
        // chiếm mất slot model LOCAL (cap=1, `BackgroundTaskManager`)
        // hàng chục phút — chặn đứng lệnh "Đắp thịt"/"Viết tiếp" THẬT của
        // người dùng đang xếp hàng phía sau (đúng triệu chứng "không thể
        // tạo chương truyện" đã báo). Giờ LUÔN đi qua `generateStream()` +
        // kiểm tra `isCancelled` mỗi token, kể cả khi không có `onChunk`
        // — hành vi hiện tại KHÔNG đổi với mọi nơi gọi CHƯA truyền
        // `isCancelled` (mặc định null → `isCancelled?.call() ?? false`
        // luôn false → không bao giờ `break` sớm, y hệt trước đây).
        final buffer = StringBuffer();
        await for (final chunk in mainProvider.generateStream(
          systemPrompt: systemPrompt,
          userPrompt: userPrompt,
          temperature: temperature,
          maxTokens: maxTokens,
          topP: topP,
          topK: topK,
          repetitionPenalty: repetitionPenalty,
        )) {
          buffer.write(chunk);
          onChunk?.call(buffer.toString());
          if (isCancelled?.call() ?? false) break;
        }
        return buffer.toString();
      } finally {
        await LocalLlamaProvider.endPipeline();
      }
    }

    final keepResident = await _shouldKeepResident();

    // Gộp 4 bước (dịch system+user → sinh → dịch ngược) vào ĐÚNG 1 phiên
    // Foreground Service: start() 1 lần ở đây, mỗi bước bên dưới chỉ
    // updateStage() nội dung thông báo, endPipeline() ở finally khi cả 4
    // bước xong (hoặc lỗi giữa chừng) — không còn khoảng hở start/stop
    // giữa từng bước như trước.
    const stage1 = 'Đang dịch ngữ cảnh Story Bible + câu hỏi sang ngôn ngữ model hiểu tốt...';
    await LocalLlamaProvider.beginPipeline(stage1);
    try {
      onStage?.call(stage1);
      // systemPrompt rỗng (vd 1 số tác vụ nội bộ không cần) thì bỏ qua
      // dịch, tránh gọi model dịch với chuỗi rỗng vô nghĩa.
      final translatedSystemPrompt =
          systemPrompt.trim().isEmpty ? systemPrompt : await translate(systemPrompt, toTarget: true);
      final translatedPrompt = await translate(userPrompt, toTarget: true);
      if (!keepResident) await (await _getTranslationProvider()).unload();

      const stage2 = 'Đang sinh văn bản...';
      await LocalLlamaProvider.updatePipelineStage(stage2);
      onStage?.call(stage2);
      // ĐÃ SỬA (2026-08-29 — theo phản hồi người dùng: "ngồi nhìn không
      // thấy [tiến trình ở đâu] ức chế quá"): trước đây dùng
      // `mainProvider.generate()` — CHỜ CẢ KHỐI, không có cách nào biết
      // đang tới đâu trong lúc chờ, có thể kéo dài rất lâu với model
      // chậm (không còn giới hạn thời gian nào từ khi bỏ lớp "trì trệ" —
      // xem mục H). Đổi sang `generateStream()` (giống hệt cách
      // `generateResumableWithOptionalTranslation()` bên dưới đã làm
      // ĐÚNG từ trước, function NÀY trước giờ lại thiếu) — gọi lại
      // `onStage` MỖI KHI có đoạn mới, kèm số ký tự đã sinh được tính
      // tới thời điểm đó, để nơi gọi (đã sẵn `onStage` cập nhật UI, xem
      // chat_screen.dart/chapter_editor_screen.dart) tự động thấy số
      // đang tăng dần — không cần sửa gì thêm ở tầng màn hình. Cố tình
      // KHÔNG đẩy nội dung thô (chưa dịch) qua `onChunk` — `onChunk` giữ
      // đúng hợp đồng cũ "chỉ text đã dịch, tiếng Việt" (xem mục 267-271
      // dưới), tránh làm người dùng thấy chữ nước ngoài lạ giữa chừng.
      final rawBuffer = StringBuffer();
      await for (final chunk in mainProvider.generateStream(
        systemPrompt: translatedSystemPrompt,
        userPrompt: translatedPrompt,
        temperature: temperature,
        maxTokens: maxTokens,
        topP: topP,
        topK: topK,
        repetitionPenalty: repetitionPenalty,
      )) {
        rawBuffer.write(chunk);
        onStage?.call('Đang sinh văn bản... (đã sinh ${rawBuffer.length} ký tự)');
        if (isCancelled?.call() ?? false) break;
      }
      final rawResult = rawBuffer.toString();

      const stage3 = 'Đang dịch kết quả về tiếng Việt...';
      await LocalLlamaProvider.updatePipelineStage(stage3);
      onStage?.call(stage3);
      // ĐÃ SỬA (theo phản hồi người dùng — xem giải thích ở `translate()`):
      // đây là bước DUY NHẤT người dùng thực sự nhìn thấy kết quả khi dịch
      // thuật trung gian bật — truyền `onChunk` xuống để stream đúng bước
      // này, thay vì đợi dịch xong cả khối rồi mới trả về 1 lần.
      final finalResult = await translate(rawResult, toTarget: false, onChunk: onChunk, isCancelled: isCancelled);
      if (!keepResident) await (await _getTranslationProvider()).unload();

      return finalResult;
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }

  // ĐÃ THÊM (theo yêu cầu người dùng: "cần cách để streaming theo kiểu
  // local model, model sinh chữ đến đâu thì truyền về chương chỗ đó, dẫn
  // đến khi sập ở 99% thì không cần chạy lại từ đầu chương"):
  //
  // `generateWithOptionalTranslation()` ở trên gọi `mainProvider.generate()`
  // — HTTP không streaming, chỉ trả kết quả về Dart khi xong 100%. Nếu GPU
  // remote (Colab...) sập giữa chừng, Dart chưa từng nhận được 1 ký tự nào
  // đã sinh trên server — mất sạch, phải viết lại từ đầu chương.
  //
  // Hàm này dùng `mainProvider.generateStream()` (CÙNG 1 interface
  // `AIProvider` mà model LOCAL vẫn dùng để chat — nay áp dụng luôn cho
  // remote) — nhận từng đoạn chữ NGAY KHI model sinh ra, gọi `onCheckpoint`
  // định kỳ để nơi gọi lưu tạm xuống DB (cột `Chapter.generationCheckpoint`
  // — xem `ChapterBatchService`). Nếu lỗi giữa chừng (GPU sập), phần ĐÃ
  // NHẬN ĐƯỢC tính tới thời điểm đó vẫn còn nguyên trong tay Dart (không
  // cần server gửi lại) — checkpoint cuối cùng được lưu ngay cả khi lỗi.
  //
  // RESUME: truyền `resumeFrom` = checkpoint đã lưu từ lần chạy trước —
  // hàm sẽ nối thêm hướng dẫn "viết tiếp, không lặp lại" vào prompt rồi
  // gửi model, model viết tiếp NGAY SAU đoạn đã có (không viết lại từ
  // đầu). `resumeFrom` giữ NGUYÊN không dịch (nó đã ở đúng ngôn ngữ model
  // chính hiểu — có thể là ngôn ngữ trung gian nếu đang resume 1 phiên đã
  // bật dịch thuật) — chỉ phần hướng dẫn mới (tiếng Việt) được dịch, y hệt
  // cách xử lý systemPrompt/userPrompt ở hàm generate() thường.
  //
  // Việc dịch kết quả về tiếng Việt (nếu bật dịch thuật trung gian) CHỈ
  // làm 1 LẦN DUY NHẤT, sau khi có đủ toàn bộ văn bản thô (kể cả phần nối
  // từ resume) — không dịch từng đoạn nhỏ giữa chừng (dịch 1 câu bị cắt
  // giữa chừng dễ sai ngữ cảnh, và dịch lại nhiều lần rất tốn thời gian).
  // ĐÃ THÊM (theo yêu cầu người dùng — "hủy giữa chừng lúc đang batch tạo
  // chương, không phải đợi xong toàn bộ"): trước đây `isCancelled` (ở
  // `ChapterBatchService`) chỉ được kiểm tra GIỮA 2 CHƯƠNG (trước khi bắt
  // đầu chương tiếp theo), không có cách dừng 1 chương ĐANG stream dở —
  // vì `generateWithOptionalTranslation()` (bản không streaming) chỉ trả
  // kết quả sau khi có đủ 100%, không có điểm nào giữa chừng để hỏi "có bị
  // huỷ chưa". Hàm streaming này thì CÓ điểm hỏi tự nhiên — đúng chỗ vốn
  // đã lưu checkpoint định kỳ (`maybeCheckpoint`) — nên thêm `isCancelled`
  // ở đây, kiểm tra ngay sau mỗi chunk nhận được. Bị huỷ giữa chừng: LƯU
  // checkpoint tại đúng điểm dừng (không mất phần đã sinh), rồi ném
  // `GenerationCancelledException` thay vì trả String bình thường — để nơi
  // gọi (`ChapterBatchService`) phân biệt được "bị huỷ" (không phải lỗi,
  // không tính là bất thường) với "GPU sập/lỗi thật".
  Future<String> generateResumableWithOptionalTranslation({
    required AIProvider mainProvider,
    required String systemPrompt,
    required String userPrompt,
    String? resumeFrom,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    void Function(String stage)? onStage,
    void Function(String rawSoFar)? onCheckpoint,
    bool Function()? isCancelled,
    // ĐÃ THÊM (theo phản hồi người dùng — xem giải thích ở `translate()`):
    // KHÁC với `onCheckpoint` (text THÔ, ngôn ngữ trung gian, dùng để lưu
    // resume) — callback này nhận text TIẾNG VIỆT đã dịch, CHỈ để hiện lên
    // UI, không dùng cho resume (dịch lại từ raw checkpoint mỗi lần resume
    // vẫn rẻ hơn nhiều so với việc lưu/đồng bộ 2 phiên bản checkpoint).
    void Function(String textSoFar)? onTranslatedChunk,
  }) async {
    final enabled = await isEnabled;
    final hasResume = resumeFrom != null && resumeFrom.trim().isNotEmpty;
    // Đánh dấu bằng tiếng Việt, CHỈ áp vào phần được dịch (nếu có) — không
    // bao giờ áp vào resumeFrom (đã đúng ngôn ngữ đích, dịch lại sẽ sai).
    const continuationMarker = '\n\n[ĐÃ VIẾT DỞ MỘT PHẦN Ở DƯỚI — HÃY VIẾT TIẾP NGAY SAU ĐÓ CHO TỚI KHI '
        'HOÀN CHỈNH, KHÔNG LẶP LẠI, KHÔNG TÓM TẮT LẠI PHẦN ĐÃ CÓ:]';

    Future<String> runStream(String effectiveSystemPrompt, String effectiveUserPrompt) async {
      var raw = resumeFrom ?? '';
      var charsSinceCheckpoint = 0;
      var lastCheckpoint = DateTime.now();
      const checkpointInterval = Duration(seconds: 4);
      const checkpointMinNewChars = 120;
      void maybeCheckpoint({bool force = false}) {
        if (onCheckpoint == null) return;
        final now = DateTime.now();
        if (force || (charsSinceCheckpoint >= checkpointMinNewChars && now.difference(lastCheckpoint) >= checkpointInterval)) {
          onCheckpoint(raw);
          lastCheckpoint = now;
          charsSinceCheckpoint = 0;
        }
      }

      try {
        await for (final chunk in mainProvider.generateStream(
          systemPrompt: effectiveSystemPrompt,
          userPrompt: effectiveUserPrompt,
          temperature: temperature,
          maxTokens: maxTokens,
          topP: topP,
          topK: topK,
          repetitionPenalty: repetitionPenalty,
        )) {
          raw += chunk;
          charsSinceCheckpoint += chunk.length;
          maybeCheckpoint();
          // Kiểm tra NGAY SAU mỗi chunk — điểm dừng an toàn gần nhất có
          // thể có (không dừng giữa lúc đang chờ network, chỉ dừng ngay
          // sau khi đã nhận trọn 1 đoạn), `break` ở đây tự huỷ luôn
          // subscription của Stream đang lắng nghe (Dart tự làm khi thoát
          // khỏi vòng `await for`), không cần gọi gì thêm.
          if (isCancelled?.call() ?? false) {
            maybeCheckpoint(force: true);
            throw GenerationCancelledException(rawSoFar: raw);
          }
        }
      } on GenerationCancelledException {
        rethrow;
      } catch (_) {
        // Lỗi giữa chừng (vd GPU remote sập) — LƯU LẠI đúng phần đã nhận
        // được trước khi ném lỗi tiếp, để nơi gọi có checkpoint mới nhất.
        maybeCheckpoint(force: true);
        rethrow;
      }
      return raw;
    }

    if (!enabled) {
      const stage = 'Đang sinh văn bản...';
      await LocalLlamaProvider.beginPipeline(stage);
      try {
        onStage?.call(stage);
        final finalUserPrompt = hasResume ? '$userPrompt$continuationMarker\n\n$resumeFrom' : userPrompt;
        // Không bật dịch thuật → raw ĐÃ đúng tiếng Việt luôn, không cần dịch.
        return await runStream(systemPrompt, finalUserPrompt);
      } finally {
        await LocalLlamaProvider.endPipeline();
      }
    }

    final keepResident = await _shouldKeepResident();
    const stage1 = 'Đang dịch ngữ cảnh Story Bible + câu hỏi sang ngôn ngữ model hiểu tốt...';
    await LocalLlamaProvider.beginPipeline(stage1);
    try {
      onStage?.call(stage1);
      final translatedSystemPrompt =
          systemPrompt.trim().isEmpty ? systemPrompt : await translate(systemPrompt, toTarget: true);
      final userPromptToTranslate = hasResume ? '$userPrompt$continuationMarker' : userPrompt;
      final translatedUserPromptBase = await translate(userPromptToTranslate, toTarget: true);
      // resumeFrom nối vào SAU dịch — giữ nguyên, không dịch lại.
      final finalUserPrompt = hasResume ? '$translatedUserPromptBase\n\n$resumeFrom' : translatedUserPromptBase;
      if (!keepResident) await (await _getTranslationProvider()).unload();

      const stage2 = 'Đang sinh văn bản...';
      await LocalLlamaProvider.updatePipelineStage(stage2);
      onStage?.call(stage2);
      final rawResult = await runStream(translatedSystemPrompt, finalUserPrompt);

      const stage3 = 'Đang dịch kết quả về tiếng Việt...';
      await LocalLlamaProvider.updatePipelineStage(stage3);
      onStage?.call(stage3);
      final finalResult = await translate(rawResult, toTarget: false, onChunk: onTranslatedChunk);
      if (!keepResident) await (await _getTranslationProvider()).unload();

      return finalResult;
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }
}

// Hằng số slot dùng chung — tránh gõ nhầm số 0/1 rải rác khắp code.
class MnnSlots {
  static const int main = 0;
  static const int translation = 1;
}

// ĐÃ THÊM (theo yêu cầu người dùng — huỷ giữa chừng khi đang stream, xem
// giải thích ở `generateResumableWithOptionalTranslation`): mang theo
// đúng phần văn bản thô ĐÃ NHẬN ĐƯỢC tính tới thời điểm bị huỷ — nơi bắt
// exception này không cần đọc lại DB để biết checkpoint cuối, có sẵn luôn
// trong tay (dù `onCheckpoint` cũng đã lưu y hệt xuống DB tại đúng thời
// điểm này rồi — 2 đường lấy cùng 1 giá trị, không mâu thuẫn nhau).
class GenerationCancelledException implements Exception {
  final String rawSoFar;
  GenerationCancelledException({required this.rawSoFar});
  @override
  String toString() => 'GenerationCancelledException(đã nhận ${rawSoFar.length} ký tự trước khi huỷ)';
}
