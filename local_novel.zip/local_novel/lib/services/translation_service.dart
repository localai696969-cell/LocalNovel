import 'ai_provider.dart';
import 'device_profile_service.dart';
import 'providers/local_provider.dart';
import 'settings_service.dart';

// Dịch thuật trung gian — TÙY CHỌN, mặc định TẮT. Giải quyết vấn đề:
// nhiều model viết truyện hay (văn phong tốt) không được huấn luyện
// nhiều trên dữ liệu tiếng Việt, nên viết/chat trực tiếp bằng tiếng
// Việt dễ ra câu ngô nghê, lặp từ vô nghĩa, hoặc ký tự lạ. Giải pháp:
// dịch input sang ngôn ngữ model hiểu tốt (thường là tiếng Anh) → để
// model chính sinh văn bản bằng ngôn ngữ đó → dịch kết quả về tiếng Việt.
//
// LUÔN CHẠY TUẦN TỰ, không bao giờ giữ 2 model cùng chạy suy luận song
// song (dù có thể cùng NẰM trong RAM) — đúng yêu cầu đã thống nhất:
// dịch xong mới tới model chính, model chính xong mới dịch ngược lại.
//
// Việc GIỮ hay XẢ model dịch giữa các bước là quyết định theo RAM máy,
// không hardcode: máy nhiều RAM (>= ramKeepResidentThresholdMb) giữ
// nguyên model dịch trong RAM suốt phiên làm việc (đỡ phải nạp lại nhiều
// lần), máy ít RAM thì xả ngay sau mỗi lần dùng.
class TranslationService {
  final SettingsService settings;
  static const int ramKeepResidentThresholdMb = 6000; // dưới mức này thì luôn xả sau khi dùng

  TranslationService(this.settings);

  Future<bool> get isEnabled async => settings.loadTranslationEnabled();

  LocalLlamaProvider? _translationProvider;

  // Model dùng để dịch ngôn ngữ (nên nhỏ: 0.3B–1.5B)
  Future<LocalLlamaProvider> _getTranslationProvider() async {
    final path = await settings.loadTranslationModelPath();
    if (path == null || path.isEmpty) {
      throw Exception(
        'Chưa chọn model dịch thuật. Vào Cài đặt → Dịch thuật trung gian → chọn 1 model nhỏ (khuyến nghị 0.3B-1.5B).',
      );
    }
    if (_translationProvider == null || _translationProvider!.modelPath != path) {
      _translationProvider = LocalLlamaProvider(modelPath: path, slot: MnnSlots.translation);
    }
    return _translationProvider!;
  }

  Future<bool> _shouldKeepResident() async {
    final mode = await settings.loadTranslationKeepResidentMode();
    if (mode == 'always') return true;
    if (mode == 'never') return false;
    // 'auto': tự đoán theo tổng RAM máy.
    final ramMb = await DeviceProfileService().readTotalRamMb();
    return ramMb >= ramKeepResidentThresholdMb;
  }

  // Dịch một đoạn văn bản theo 1 chiều.
  // toTarget=true: Việt → ngôn ngữ trung gian (trước khi đưa vào model chính).
  // toTarget=false: ngôn ngữ trung gian → Việt (sau khi model chính trả về).
  Future<String> translate(String text, {required bool toTarget}) async {
    if (text.trim().isEmpty) return text;
    final provider = await _getTranslationProvider();
    final targetLanguage = await settings.loadTranslationTargetLanguage();
    final stylePrompt = await settings.loadTranslationStylePrompt();

    // Dùng prompt riêng cho từng chiều nếu người dùng đã tùy chỉnh.
    // {targetLanguage} là placeholder tự thay — cho phép prompt có ngôn ngữ
    // đích rõ ràng mà không cần người dùng gõ tên ngôn ngữ 2 lần.
    String instruction;
    if (toTarget) {
      final raw = await settings.loadTranslationPromptToTarget();
      instruction = raw.replaceAll('{targetLanguage}', targetLanguage);
      if (stylePrompt.isNotEmpty) instruction = '$instruction $stylePrompt';
    } else {
      final raw = await settings.loadTranslationPromptFromTarget();
      instruction = raw.replaceAll('{targetLanguage}', targetLanguage);
      if (stylePrompt.isNotEmpty) instruction = '$instruction $stylePrompt';
    }

    final result = await provider.generate(
      systemPrompt: instruction,
      userPrompt: text,
      temperature: 0.3, // dịch thuật cần chính xác, không cần sáng tạo
      // ĐÃ SỬA: trần cũ 4096 token đủ cho userPrompt thông thường (1 câu
      // lệnh/1 đoạn văn), nhưng từ khi systemPrompt (chứa TOÀN BỘ Story
      // Bible liên quan — có thể dài tới contextBudgetChars=3500 ký tự
      // của RagService cộng thêm phần hướng dẫn) CŨNG được dịch qua hàm
      // này (xem sửa ở generateWithOptionalTranslation bên dưới), văn bản
      // cần dịch có thể dài hơn nhiều — nới trần lên 8192 để tránh cắt cụt
      // Bible giữa chừng, gây model chính chỉ nhận được nửa luật thế giới.
      maxTokens: (text.length * 2).clamp(256, 8192),
    );
    return result.trim();
  }

  // Bọc toàn bộ luồng: dịch câu hỏi → gọi model chính → dịch kết quả.
  // Nếu tính năng đang TẮT, chạy thẳng model chính như bình thường,
  // không qua bước dịch nào (không phạt hiệu năng khi không cần dùng).
  //
  // ĐÃ SỬA TẬN GỐC (rà soát toàn hệ thống theo yêu cầu người dùng, phát
  // hiện lỗ hổng THỨ 3 cùng họ với 2 lỗ hổng Foreground Service trước đó):
  // trước đây hàm này CHỈ dịch `userPrompt`, còn `systemPrompt` — nơi
  // RagService nhét TOÀN BỘ Story Bible liên quan (nhân vật, luật thế
  // giới, thuật ngữ, tuyến truyện, văn phong, dàn ý — xem rag_service.dart
  // buildSystemPrompt()/buildContext(), style_service.dart
  // buildFleshOutPrompt()) — đi THẲNG, NGUYÊN VĂN TIẾNG VIỆT sang model
  // chính, không qua dịch. Tính năng dịch thuật trung gian tồn tại chính
  // vì "model chính không giỏi tiếng Việt" (xem comment đầu file) — nghĩa
  // là khi bật tính năng này, model chính CŨNG không hiểu tốt phần Bible
  // tiếng Việt bị bỏ quên trong systemPrompt, khiến Bible gần như vô hiệu
  // ĐÚNG lúc cần nó nhất (dùng model ngoại lai mạnh, không rành tiếng
  // Việt). Ảnh hưởng "Viết tiếp", "Đắp thịt"/"Tạo chương hàng loạt", "Áp
  // dụng ghi chú sửa", "Trợ lý AI" (chat) — 5/7 nơi gọi hàm này. Chỉ
  // "Kiểm tra tính nhất quán" và "Tóm tắt chương" thoát được vì tự đẩy tay
  // nội dung dài sang userPrompt thay vì systemPrompt.
  //
  // Sửa 1 LẦN DUY NHẤT ở đây theo đúng nguyên tắc đã áp dụng cho lỗ hổng
  // Foreground Service: dịch CẢ systemPrompt (nếu có nội dung) lẫn
  // userPrompt trước khi gọi model chính — mọi nơi gọi hàm này (hiện tại
  // và sau này) tự động được bảo vệ, không cần tự nhớ "phải nhét Bible
  // vào userPrompt mới được dịch" như cách né tạm trước đây.
  // Chỉ dịch systemPrompt theo chiều toTarget — đây là hướng dẫn CHO
  // model, không hiển thị lại cho người dùng, nên không cần dịch ngược.
  Future<String> generateWithOptionalTranslation({
    required AIProvider mainProvider,
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    void Function(String stage)? onStage,
  }) async {
    final enabled = await isEnabled;
    if (!enabled) {
      const stage = 'Đang sinh văn bản...';
      await LocalLlamaProvider.beginPipeline(stage);
      try {
        onStage?.call(stage);
        return await mainProvider.generate(
          systemPrompt: systemPrompt,
          userPrompt: userPrompt,
          temperature: temperature,
          maxTokens: maxTokens,
          topP: topP,
          topK: topK,
          repetitionPenalty: repetitionPenalty,
        );
      } finally {
        await LocalLlamaProvider.endPipeline();
      }
    }

    final keepResident = await _shouldKeepResident();

    // Gộp 4 bước (dịch system+user → sinh → dịch ngược) vào ĐÚNG 1 phiên
    // Foreground Service: start() 1 lần ở đây, mỗi bước bên dưới chỉ
    // updateStage() nội dung thông báo, endPipeline() ở finally khi cả 4
    // bước xong (hoặc lỗi giữa chừng) — không còn khoảng hở start/stop
    // giữa từng bước như trước.
    const stage1 = 'Đang dịch ngữ cảnh Story Bible + câu hỏi sang ngôn ngữ model hiểu tốt...';
    await LocalLlamaProvider.beginPipeline(stage1);
    try {
      onStage?.call(stage1);
      // systemPrompt rỗng (vd 1 số tác vụ nội bộ không cần) thì bỏ qua
      // dịch, tránh gọi model dịch với chuỗi rỗng vô nghĩa.
      final translatedSystemPrompt =
          systemPrompt.trim().isEmpty ? systemPrompt : await translate(systemPrompt, toTarget: true);
      final translatedPrompt = await translate(userPrompt, toTarget: true);
      if (!keepResident) await (await _getTranslationProvider()).unload();

      const stage2 = 'Đang sinh văn bản...';
      await LocalLlamaProvider.updatePipelineStage(stage2);
      onStage?.call(stage2);
      final rawResult = await mainProvider.generate(
        systemPrompt: translatedSystemPrompt,
        userPrompt: translatedPrompt,
        temperature: temperature,
        maxTokens: maxTokens,
        topP: topP,
        topK: topK,
        repetitionPenalty: repetitionPenalty,
      );

      const stage3 = 'Đang dịch kết quả về tiếng Việt...';
      await LocalLlamaProvider.updatePipelineStage(stage3);
      onStage?.call(stage3);
      final finalResult = await translate(rawResult, toTarget: false);
      if (!keepResident) await (await _getTranslationProvider()).unload();

      return finalResult;
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }
}

// Hằng số slot dùng chung — tránh gõ nhầm số 0/1 rải rác khắp code.
class MnnSlots {
  static const int main = 0;
  static const int translation = 1;
}
