import 'package:http/http.dart' as http;
import 'package:html/parser.dart' as html_parser;

class WebSearchResult {
  final String title;
  final String snippet;
  final String url;
  WebSearchResult({required this.title, required this.snippet, required this.url});
}

// ĐÃ THÊM (theo yêu cầu): tìm kiếm web THỦ CÔNG — chỉ chạy khi người dùng
// chủ động bật (xem nút bật/tắt trong chat_screen.dart), KHÔNG tự động
// chạy nền, KHÔNG chặn màu đợi cho những tin nhắn không cần. Dùng endpoint
// HTML rút gọn của DuckDuckGo (html.duckduckgo.com/html/) — không cần đăng
// ký API key, không cần cấu hình gì thêm, phù hợp mục tiêu "cắm là chạy"
// của app. Đánh đổi: đây là parse HTML bằng CSS selector cố định, nếu
// DuckDuckGo đổi cấu trúc trang, việc trích xuất có thể ngừng hoạt động —
// khi đó hàm trả về danh sách rỗng thay vì crash, và chỗ gọi nó (chat_screen.dart)
// sẽ báo rõ "không tìm được kết quả" cho người dùng biết, không âm thầm im lặng.
class WebSearchService {
  static const _endpoint = 'https://html.duckduckgo.com/html/';

  Future<List<WebSearchResult>> search(String query, {int maxResults = 5}) async {
    final uri = Uri.parse(_endpoint).replace(queryParameters: {'q': query});
    final response = await http.post(
      uri,
      headers: {'User-Agent': 'Mozilla/5.0 (Android 13) LocalNovelApp'},
    ).timeout(const Duration(seconds: 15));

    if (response.statusCode != 200) {
      throw Exception('Tìm kiếm web thất bại (mã lỗi ${response.statusCode})');
    }

    final doc = html_parser.parse(response.body);
    final results = <WebSearchResult>[];
    final resultNodes = doc.querySelectorAll('.result__body');
    for (final node in resultNodes) {
      if (results.length >= maxResults) break;
      final titleEl = node.querySelector('.result__title a.result__a');
      final snippetEl = node.querySelector('.result__snippet');
      final title = titleEl?.text.trim() ?? '';
      final snippet = snippetEl?.text.trim() ?? '';
      final href = titleEl?.attributes['href'] ?? '';
      if (title.isEmpty) continue;
      results.add(WebSearchResult(title: title, snippet: snippet, url: _cleanDdgUrl(href)));
    }
    return results;
  }

  // DuckDuckGo bọc link thật qua redirect nội bộ dạng //duckduckgo.com/l/?uddg=<url mã hoá>
  // — giải mã ra link gốc để hiển thị/dùng cho model tham chiếu cho đúng.
  String _cleanDdgUrl(String href) {
    try {
      final uri = Uri.parse(href.startsWith('//') ? 'https:$href' : href);
      final real = uri.queryParameters['uddg'];
      return real != null ? Uri.decodeFull(real) : href;
    } catch (_) {
      return href;
    }
  }

  // Định dạng kết quả thành 1 khối text để nhét vào system prompt — cùng
  // phong cách với ngữ cảnh tài liệu đính kèm (buildQaContext) và Story
  // Bible (buildContext) đã có sẵn trong app, để model xử lý nhất quán.
  String formatForPrompt(List<WebSearchResult> results, String query) {
    if (results.isEmpty) {
      return 'Đã tìm kiếm web cho "$query" nhưng KHÔNG tìm được kết quả nào — '
          'trả lời dựa trên kiến thức sẵn có, nói rõ là không có thông tin web mới nếu liên quan.';
    }
    final buffer = StringBuffer('Kết quả tìm kiếm web cho "$query" (dùng để tham khảo, '
        'không nhất thiết chính xác 100% — nêu rõ nguồn nếu trích dẫn):\n\n');
    for (var i = 0; i < results.length; i++) {
      final r = results[i];
      buffer.writeln('${i + 1}. ${r.title}');
      if (r.snippet.isNotEmpty) buffer.writeln('   ${r.snippet}');
      buffer.writeln('   Nguồn: ${r.url}');
      buffer.writeln();
    }
    return buffer.toString();
  }
}
