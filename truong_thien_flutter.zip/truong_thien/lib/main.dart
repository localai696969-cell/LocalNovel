import 'package:flutter/material.dart';
import 'screens/chapters_screen.dart';
import 'screens/story_bible_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/settings_screen.dart';

void main() {
  runApp(const TruongThienApp());
}

class TruongThienApp extends StatelessWidget {
  const TruongThienApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Trường Thiên',
      theme: ThemeData(colorSchemeSeed: const Color(0xFFA32D2D), useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: const Color(0xFFA32D2D),
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const RootScreen(),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int index = 0;

  final screens = const [
    ChaptersScreen(),
    StoryBibleScreen(),
    ChatScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: index, children: screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Chương'),
          NavigationDestination(icon: Icon(Icons.auto_stories_outlined), label: 'Bách khoa'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Trợ lý AI'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Cài đặt'),
        ],
      ),
    );
  }
}
