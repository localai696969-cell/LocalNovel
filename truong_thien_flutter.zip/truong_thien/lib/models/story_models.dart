// Các model dữ liệu cốt lõi cho Story Bible.
// Mỗi entry đều có `keywords` — danh sách từ khóa kích hoạt, dùng cho
// cơ chế "lorebook" (giống NovelAI/NovelCrafter): khi từ khóa xuất hiện
// trong ngữ cảnh đang viết, entry này sẽ tự động được nạp vào prompt AI.

class Character {
  final String id;
  String name;
  String role; // ví dụ: nhân vật chính, phản diện, phụ
  String description;
  String voiceStyle; // giọng nói / cách xưng hô đặc trưng
  List<String> keywords;
  DateTime updatedAt;

  Character({
    required this.id,
    required this.name,
    required this.role,
    required this.description,
    this.voiceStyle = '',
    List<String>? keywords,
    DateTime? updatedAt,
  })  : keywords = keywords ?? [name],
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'role': role,
        'description': description,
        'voice_style': voiceStyle,
        'keywords': keywords.join(','),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Character.fromMap(Map<String, dynamic> m) => Character(
        id: m['id'],
        name: m['name'],
        role: m['role'],
        description: m['description'],
        voiceStyle: m['voice_style'] ?? '',
        keywords: (m['keywords'] as String).split(',').where((e) => e.isNotEmpty).toList(),
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

class WorldRule {
  final String id;
  String title;
  String content;
  bool isHardRule; // luật tuyệt đối, không bao giờ được vi phạm
  List<String> keywords;

  WorldRule({
    required this.id,
    required this.title,
    required this.content,
    this.isHardRule = true,
    List<String>? keywords,
  }) : keywords = keywords ?? [];

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'content': content,
        'is_hard_rule': isHardRule ? 1 : 0,
        'keywords': keywords.join(','),
      };

  factory WorldRule.fromMap(Map<String, dynamic> m) => WorldRule(
        id: m['id'],
        title: m['title'],
        content: m['content'],
        isHardRule: m['is_hard_rule'] == 1,
        keywords: (m['keywords'] as String).split(',').where((e) => e.isNotEmpty).toList(),
      );
}

class TimelineEvent {
  final String id;
  int chapterNumber;
  String summary; // tóm tắt sự kiện, dùng cho ngữ cảnh nén
  DateTime? inStoryDate; // thời gian trong truyện (nếu có lịch riêng)

  TimelineEvent({
    required this.id,
    required this.chapterNumber,
    required this.summary,
    this.inStoryDate,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'chapter_number': chapterNumber,
        'summary': summary,
        'in_story_date': inStoryDate?.toIso8601String(),
      };

  factory TimelineEvent.fromMap(Map<String, dynamic> m) => TimelineEvent(
        id: m['id'],
        chapterNumber: m['chapter_number'],
        summary: m['summary'],
        inStoryDate: m['in_story_date'] != null ? DateTime.parse(m['in_story_date']) : null,
      );
}

class StyleProfile {
  final String id;
  String name;
  // Người dùng có thể mô tả văn phong bằng lời ("giọng cổ trang, câu dài,
  // nhiều ẩn dụ") hoặc dán mẫu văn CỦA CHÍNH HỌ để AI phân tích ra mô tả.
  // profileDescription luôn là mô tả bằng lời (kết quả phân tích hoặc
  // do người dùng tự viết) — không lưu nguyên văn tác phẩm của người khác.
  String profileDescription;
  DateTime updatedAt;

  StyleProfile({
    required this.id,
    required this.name,
    required this.profileDescription,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'profile_description': profileDescription,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory StyleProfile.fromMap(Map<String, dynamic> m) => StyleProfile(
        id: m['id'],
        name: m['name'],
        profileDescription: m['profile_description'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}

class ChatMessageRecord {
  final String id;
  final bool fromUser;
  String text;
  final String? providerLabel; // model nào đã trả lời — hiển thị khi đổi model giữa chừng
  final DateTime createdAt;

  ChatMessageRecord({
    required this.id,
    required this.fromUser,
    required this.text,
    this.providerLabel,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'from_user': fromUser ? 1 : 0,
        'text': text,
        'provider_label': providerLabel,
        'created_at': createdAt.toIso8601String(),
      };

  factory ChatMessageRecord.fromMap(Map<String, dynamic> m) => ChatMessageRecord(
        id: m['id'],
        fromUser: m['from_user'] == 1,
        text: m['text'],
        providerLabel: m['provider_label'],
        createdAt: DateTime.parse(m['created_at']),
      );
}

class Chapter {
  final String id;
  int number;
  String title;
  String content;
  String? autoSummary; // tóm tắt 3-5 câu, sinh tự động sau khi lưu chương
  bool consistencyChecked;
  String? consistencyWarning;
  DateTime updatedAt;

  Chapter({
    required this.id,
    required this.number,
    required this.title,
    required this.content,
    this.autoSummary,
    this.consistencyChecked = false,
    this.consistencyWarning,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  int get wordCount => content.trim().isEmpty ? 0 : content.trim().split(RegExp(r'\s+')).length;

  Map<String, dynamic> toMap() => {
        'id': id,
        'number': number,
        'title': title,
        'content': content,
        'auto_summary': autoSummary,
        'consistency_checked': consistencyChecked ? 1 : 0,
        'consistency_warning': consistencyWarning,
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Chapter.fromMap(Map<String, dynamic> m) => Chapter(
        id: m['id'],
        number: m['number'],
        title: m['title'],
        content: m['content'],
        autoSummary: m['auto_summary'],
        consistencyChecked: m['consistency_checked'] == 1,
        consistencyWarning: m['consistency_warning'],
        updatedAt: DateTime.parse(m['updated_at']),
      );
}
