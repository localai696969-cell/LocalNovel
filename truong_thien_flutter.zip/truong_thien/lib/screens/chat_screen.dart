import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import '../services/settings_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final db = DatabaseService.instance;
  List<ChatMessageRecord> messages = [];
  final inputCtrl = TextEditingController();
  bool sending = false;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  // Nạp lại toàn bộ hội thoại đã lưu — dù người dùng vừa đổi provider
  // ở màn Cài đặt, chuyển tab, hay tắt mở lại app, hội thoại vẫn còn
  // nguyên. "Bối cảnh" thật sự (Story Bible/RAG) không nằm trong đây,
  // nó luôn được RagService đọc lại từ database, độc lập với việc đang
  // dùng provider/model nào — nên đổi model giữa chừng không cần tạo
  // lại gì cả.
  Future<void> _loadHistory() async {
    final saved = await db.allChatMessages();
    setState(() {
      messages = saved;
      loading = false;
    });
  }

  Future<void> _clearHistory() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa lịch sử chat?'),
        content: const Text('Chỉ xóa hội thoại trong khung chat này. Story Bible và các chương không bị ảnh hưởng.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirm == true) {
      await db.clearChatMessages();
      setState(() => messages = []);
    }
  }

  Future<void> _send() async {
    final text = inputCtrl.text.trim();
    if (text.isEmpty || sending) return;

    final userMsg = ChatMessageRecord(id: const Uuid().v4(), fromUser: true, text: text);
    await db.upsertChatMessage(userMsg);
    setState(() {
      messages.add(userMsg);
      inputCtrl.clear();
      sending = true;
    });

    final provider = await SettingsService().currentProvider();
    final reply = ChatMessageRecord(id: const Uuid().v4(), fromUser: false, text: '', providerLabel: provider.name);
    setState(() => messages.add(reply));

    try {
      final rag = RagService(db, await SettingsService().currentEmbeddingService(),
          contextBudgetChars: await SettingsService().loadRagBudget());
      final systemPrompt = await rag.buildSystemPrompt(
        userInstruction: 'Trả lời như một biên tập viên tư vấn viết truyện, tham chiếu đúng Story Bible.',
        currentText: text,
      );
      final stream = provider.generateStream(systemPrompt: systemPrompt, userPrompt: text);
      await for (final chunk in stream) {
        setState(() => reply.text += chunk);
      }
    } catch (e) {
      setState(() => reply.text = 'Lỗi: $e');
    } finally {
      await db.upsertChatMessage(reply); // lưu bản hoàn chỉnh sau khi stream xong
      setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trợ lý AI'),
        actions: [
          IconButton(onPressed: _clearHistory, icon: const Icon(Icons.delete_outline), tooltip: 'Xóa lịch sử chat'),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: messages.isEmpty
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                              'Hỏi trợ lý về truyện của bạn. Có thể đổi model AI bất kỳ lúc nào ở Cài đặt '
                              'mà không mất hội thoại này hay Story Bible.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: messages.length,
                          itemBuilder: (context, i) {
                            final m = messages[i];
                            return Align(
                              alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                              child: Column(
                                crossAxisAlignment: m.fromUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.symmetric(vertical: 4),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                                    decoration: BoxDecoration(
                                      color: m.fromUser
                                          ? Theme.of(context).colorScheme.primaryContainer
                                          : Colors.grey.shade100,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Text(m.text.isEmpty ? '...' : m.text),
                                  ),
                                  if (!m.fromUser && m.providerLabel != null)
                                    Padding(
                                      padding: const EdgeInsets.only(left: 4, bottom: 4),
                                      child: Text(
                                        m.providerLabel!,
                                        style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(children: [
                      Expanded(
                        child: TextField(
                          controller: inputCtrl,
                          decoration: const InputDecoration(hintText: 'Hỏi trợ lý về truyện của bạn...'),
                          onSubmitted: (_) => _send(),
                        ),
                      ),
                      IconButton(onPressed: _send, icon: const Icon(Icons.send)),
                    ]),
                  ),
                ),
              ],
            ),
    );
  }
}
