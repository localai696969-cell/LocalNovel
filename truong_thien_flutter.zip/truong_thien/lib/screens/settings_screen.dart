import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../services/ai_provider.dart';
import '../services/settings_service.dart';
import '../services/database_service.dart';
import '../services/rag_service.dart';
import 'local_optimization_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final settings = SettingsService();
  AIProviderType selected = AIProviderType.localLlama;

  String localModelPath = '';
  final anthropicKeyCtrl = TextEditingController();
  final anthropicModelCtrl = TextEditingController(text: 'claude-sonnet-5');
  final openAiUrlCtrl = TextEditingController(text: 'https://api.openai.com/v1');
  final openAiKeyCtrl = TextEditingController();
  final openAiModelCtrl = TextEditingController(text: 'gpt-4o');

  @override
  void initState() {
    super.initState();
    settings.loadProviderType().then((t) => setState(() => selected = t));
    settings.loadLocalModelPath().then((p) => setState(() => localModelPath = p));
  }

  Future<void> _pickModelFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['gguf'],
    );
    final path = result?.files.single.path;
    if (path != null) {
      setState(() => localModelPath = path);
      await settings.saveLocalModelPath(path);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt AI')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.speed_outlined),
              title: const Text('Tối ưu AI local cho máy này'),
              subtitle: const Text('Nhận diện chip, gợi ý cấu hình, đo tốc độ thực tế'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LocalOptimizationScreen())),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'App không thêm bộ lọc nội dung riêng. Khi dùng API của một hãng, '
            'chính sách nội dung của hãng đó vẫn áp dụng phía máy chủ của họ.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          RadioListTile(
            title: const Text('AI local (nhúng thẳng trong app)'),
            subtitle: const Text('Offline hoàn toàn, chạy trong cùng tiến trình app — không cần server hay Termux'),
            value: AIProviderType.localLlama,
            groupValue: selected,
            onChanged: (v) => setState(() => selected = v!),
          ),
          if (selected == AIProviderType.localLlama)
            Padding(
              padding: const EdgeInsets.only(left: 16, bottom: 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  localModelPath.isEmpty ? 'Chưa chọn file model' : localModelPath,
                  style: TextStyle(fontSize: 12, color: localModelPath.isEmpty ? Colors.red : Colors.grey),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                OutlinedButton.icon(
                  onPressed: _pickModelFile,
                  icon: const Icon(Icons.file_open_outlined),
                  label: const Text('Chọn file .gguf trên máy'),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Tải file .gguf bằng trình duyệt vào bộ nhớ máy trước (ví dụ từ Hugging Face), '
                  'rồi chọn ở đây. Số luồng/context/GPU layer chỉnh ở "Tối ưu AI local cho máy này" bên trên.',
                  style: TextStyle(fontSize: 11, color: Colors.grey),
                ),
              ]),
            ),
          RadioListTile(
            title: const Text('Anthropic API (Claude)'),
            value: AIProviderType.anthropicApi,
            groupValue: selected,
            onChanged: (v) => setState(() => selected = v!),
          ),
          if (selected == AIProviderType.anthropicApi)
            Padding(
              padding: const EdgeInsets.only(left: 16, bottom: 16),
              child: Column(children: [
                TextField(
                  controller: anthropicKeyCtrl,
                  decoration: const InputDecoration(labelText: 'API key'),
                  obscureText: true,
                ),
                TextField(
                  controller: anthropicModelCtrl,
                  decoration: const InputDecoration(labelText: 'Model'),
                ),
              ]),
            ),
          RadioListTile(
            title: const Text('API tương thích OpenAI'),
            subtitle: const Text('OpenAI hoặc endpoint khác bạn tự cấu hình'),
            value: AIProviderType.openaiCompatibleApi,
            groupValue: selected,
            onChanged: (v) => setState(() => selected = v!),
          ),
          if (selected == AIProviderType.openaiCompatibleApi)
            Padding(
              padding: const EdgeInsets.only(left: 16, bottom: 16),
              child: Column(children: [
                TextField(
                  controller: openAiUrlCtrl,
                  decoration: const InputDecoration(labelText: 'Base URL'),
                ),
                TextField(
                  controller: openAiKeyCtrl,
                  decoration: const InputDecoration(labelText: 'API key'),
                  obscureText: true,
                ),
                TextField(
                  controller: openAiModelCtrl,
                  decoration: const InputDecoration(labelText: 'Model'),
                ),
              ]),
            ),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: _save,
            child: const Text('Lưu cài đặt'),
          ),
          const Divider(height: 32),
          const Text(
            'Nếu vừa đổi provider AI, hoặc dữ liệu Story Bible/chương cũ chưa từng '
            'được lập chỉ mục, bấm nút dưới để tính lại toàn bộ embedding.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: reindexing ? null : _reindexAll,
            icon: reindexing
                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
            label: Text(reindexing ? 'Đang tái lập chỉ mục...' : 'Tái lập chỉ mục toàn bộ'),
          ),
        ],
      ),
    );
  }

  bool reindexing = false;

  Future<void> _reindexAll() async {
    setState(() => reindexing = true);
    try {
      final db = DatabaseService.instance;
      final rag = RagService(db, await settings.currentEmbeddingService(), contextBudgetChars: await settings.loadRagBudget());
      for (final c in await db.allCharacters()) {
        await rag.indexCharacter(c);
      }
      for (final r in await db.allWorldRules()) {
        await rag.indexWorldRule(r);
      }
      for (final ch in await db.allChapters()) {
        await rag.indexChapter(ch);
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã tái lập chỉ mục xong')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) setState(() => reindexing = false);
    }
  }

  Future<void> _save() async {
    await settings.saveProviderType(selected);
    await settings.saveAnthropicConfig(apiKey: anthropicKeyCtrl.text, model: anthropicModelCtrl.text);
    await settings.saveOpenAiConfig(
      baseUrl: openAiUrlCtrl.text,
      apiKey: openAiKeyCtrl.text,
      model: openAiModelCtrl.text,
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu')));
    }
  }
}
