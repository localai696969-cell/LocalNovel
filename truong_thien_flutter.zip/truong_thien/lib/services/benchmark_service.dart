import 'dart:math';
import '../services/ai_provider.dart';

class BenchmarkResult {
  final double tokensPerSecond;
  final int wordCount;
  final Duration elapsed;
  BenchmarkResult(this.tokensPerSecond, this.wordCount, this.elapsed);
}

// Đo tốc độ bằng một prompt cố định, ngắn gọn, không phụ thuộc Story
// Bible — mục đích là đo hiệu năng thô của provider/model đang chọn,
// không phải đo chất lượng RAG.
class BenchmarkService {
  static const _testPrompt =
      'Viết một đoạn văn khoảng 150 từ mô tả một khu chợ đêm nhộn nhịp, có mùi thức ăn và ánh đèn lồng.';

  Future<BenchmarkResult> run(AIProvider provider) async {
    final stopwatch = Stopwatch()..start();
    int wordCount = 0;
    final stream = provider.generateStream(
      systemPrompt: 'Bạn là trợ lý viết văn. Chỉ trả lời bằng đoạn văn được yêu cầu.',
      userPrompt: _testPrompt,
      maxTokens: 300,
    );
    await for (final chunk in stream) {
      wordCount += chunk.trim().isEmpty ? 0 : chunk.split(RegExp(r'\s+')).length;
    }
    stopwatch.stop();
    final seconds = max(stopwatch.elapsedMilliseconds / 1000, 0.001);
    // Ước lượng thô: 1 từ tiếng Việt ~ 1.3-1.5 token trung bình với hầu
    // hết tokenizer BPE — dùng hệ số 1.4 để quy đổi ra tok/s tương đối
    // dễ so sánh với số liệu benchmark llama.cpp thường thấy.
    final estimatedTokens = wordCount * 1.4;
    return BenchmarkResult(estimatedTokens / seconds, wordCount, stopwatch.elapsed);
  }
}
