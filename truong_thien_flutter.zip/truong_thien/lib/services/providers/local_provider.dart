import 'dart:async';
import 'package:fllama/fllama.dart';
import '../ai_provider.dart';

// Chạy model NGAY TRONG tiến trình app, qua FFI (Dart gọi thẳng hàm C++
// của llama.cpp được fllama biên dịch sẵn thành thư viện native đóng gói
// trong APK). Không có server, không có port, không cần Termux — đây là
// lý do bản này thực sự là "một file APK duy nhất".
//
// Vì cùng tiến trình, threads/contextSize/numGpuLayers có thể đổi ngay
// trước mỗi lần sinh văn bản, không cần khởi động lại gì — khác hẳn giới
// hạn của bản dùng llama-server độc lập trước đây.
class LocalLlamaProvider implements AIProvider {
  final String modelPath; // đường dẫn file .gguf trên máy, người dùng tự chọn
  final int threads;
  final int contextSize;
  final int numGpuLayers; // 99 = thử offload toàn bộ sang GPU (Adreno/Mali qua OpenCL)

  LocalLlamaProvider({
    required this.modelPath,
    this.threads = 4,
    this.contextSize = 2048,
    this.numGpuLayers = 99,
  });

  @override
  String get name => 'AI local (nhúng trong APK)';

  @override
  String get description => 'Chạy hoàn toàn offline, ngay trong app, không cần server hay Termux.';

  @override
  Future<bool> isReady() async => modelPath.isNotEmpty;

  List<Message> _messages(String systemPrompt, String userPrompt) => [
        Message(Role.system, systemPrompt),
        Message(Role.user, userPrompt),
      ];

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
  }) async {
    final completer = Completer<String>();
    final request = OpenAiRequest(
      modelPath: modelPath,
      messages: _messages(systemPrompt, userPrompt),
      maxTokens: maxTokens,
      temperature: temperature,
      numGpuLayers: numGpuLayers,
      contextSize: contextSize,
    );
    await fllamaChat(request, (response, responseJson, done) {
      if (done && !completer.isCompleted) completer.complete(response);
    });
    return completer.future;
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
  }) {
    // fllama trả về TOÀN BỘ văn bản tích lũy mỗi lần callback được gọi
    // (không phải delta như API HTTP kiểu OpenAI) — cần tự tính phần mới
    // để giữ đúng hành vi "stream từng đoạn" cho phần còn lại của app.
    final controller = StreamController<String>();
    String previous = '';
    final request = OpenAiRequest(
      modelPath: modelPath,
      messages: _messages(systemPrompt, userPrompt),
      maxTokens: maxTokens,
      temperature: temperature,
      numGpuLayers: numGpuLayers,
      contextSize: contextSize,
    );
    fllamaChat(request, (response, responseJson, done) {
      if (response.length > previous.length) {
        controller.add(response.substring(previous.length));
        previous = response;
      }
      if (done) controller.close();
    });
    return controller.stream;
  }
}
