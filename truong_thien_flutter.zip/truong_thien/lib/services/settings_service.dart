import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ai_provider.dart';
import 'embedding_service.dart';
import 'providers/local_provider.dart';
import 'providers/anthropic_provider.dart';
import 'providers/openai_compatible_provider.dart';

class SettingsService {
  static const _secure = FlutterSecureStorage();

  static const _kProviderType = 'provider_type';
  static const _kLocalModelPath = 'local_model_path';
  static const _kLocalThreads = 'local_threads';
  static const _kLocalContext = 'local_context';
  static const _kLocalGpuLayers = 'local_gpu_layers';
  static const _kAnthropicKey = 'anthropic_key';
  static const _kAnthropicModel = 'anthropic_model';
  static const _kOpenAiBaseUrl = 'openai_base_url';
  static const _kOpenAiKey = 'openai_key';
  static const _kOpenAiModel = 'openai_model';
  static const _kRagBudget = 'rag_context_budget';

  Future<void> saveProviderType(AIProviderType type) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kProviderType, type.name);
  }

  Future<AIProviderType> loadProviderType() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kProviderType);
    return AIProviderType.values.firstWhere(
      (t) => t.name == raw,
      orElse: () => AIProviderType.localLlama,
    );
  }

  // ---------- Local (nhúng trong APK qua FFI) ----------
  Future<void> saveLocalModelPath(String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kLocalModelPath, path);
  }

  Future<String> loadLocalModelPath() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kLocalModelPath) ?? '';
  }

  // Ba tham số này đổi ngay lập tức không cần khởi động lại gì, vì
  // model chạy cùng tiến trình với app.
  Future<void> saveLocalInferenceConfig({
    required int threads,
    required int contextSize,
    required int numGpuLayers,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kLocalThreads, threads);
    await prefs.setInt(_kLocalContext, contextSize);
    await prefs.setInt(_kLocalGpuLayers, numGpuLayers);
  }

  Future<({int threads, int contextSize, int numGpuLayers})> loadLocalInferenceConfig() async {
    final prefs = await SharedPreferences.getInstance();
    return (
      threads: prefs.getInt(_kLocalThreads) ?? 4,
      contextSize: prefs.getInt(_kLocalContext) ?? 2048,
      numGpuLayers: prefs.getInt(_kLocalGpuLayers) ?? 99,
    );
  }

  // ---------- API providers ----------
  Future<void> saveAnthropicConfig({required String apiKey, required String model}) async {
    await _secure.write(key: _kAnthropicKey, value: apiKey);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kAnthropicModel, model);
  }

  Future<void> saveOpenAiConfig({
    required String baseUrl,
    required String apiKey,
    required String model,
  }) async {
    await _secure.write(key: _kOpenAiKey, value: apiKey);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kOpenAiBaseUrl, baseUrl);
    await prefs.setString(_kOpenAiModel, model);
  }

  Future<void> saveRagBudget(int chars) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kRagBudget, chars);
  }

  Future<int> loadRagBudget() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_kRagBudget) ?? 3500;
  }

  // Dựng provider đang được chọn, sẵn sàng dùng ngay.
  Future<AIProvider> currentProvider() async {
    final type = await loadProviderType();
    switch (type) {
      case AIProviderType.localLlama:
        final path = await loadLocalModelPath();
        final cfg = await loadLocalInferenceConfig();
        return LocalLlamaProvider(
          modelPath: path,
          threads: cfg.threads,
          contextSize: cfg.contextSize,
          numGpuLayers: cfg.numGpuLayers,
        );
      case AIProviderType.anthropicApi:
        final key = await _secure.read(key: _kAnthropicKey) ?? '';
        final prefs = await SharedPreferences.getInstance();
        final model = prefs.getString(_kAnthropicModel) ?? 'claude-sonnet-5';
        return AnthropicProvider(apiKey: key, modelId: model);
      case AIProviderType.openaiCompatibleApi:
        final key = await _secure.read(key: _kOpenAiKey) ?? '';
        final prefs = await SharedPreferences.getInstance();
        final url = prefs.getString(_kOpenAiBaseUrl) ?? 'https://api.openai.com/v1';
        final model = prefs.getString(_kOpenAiModel) ?? 'gpt-4o';
        return OpenAICompatibleProvider(baseUrl: url, apiKey: key, modelId: model);
    }
  }

  // Embedding cho RAG: llama.cpp nhúng qua fllama hiện chưa expose API
  // embedding ở tầng cao, nên dùng vector "hashing" thuần Dart — luôn
  // chạy được, không phụ thuộc thêm gì. Nếu sau này fllama hỗ trợ
  // embedding trực tiếp, có thể thay ở đúng một chỗ này.
  Future<EmbeddingService> currentEmbeddingService() async {
    return HashingEmbeddingService();
  }
}
